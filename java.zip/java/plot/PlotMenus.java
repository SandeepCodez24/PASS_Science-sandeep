package plot;

import java.util.List;
import java.util.function.BiConsumer;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.NumberAxis;
import javafx.scene.control.Button;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import ui.UI_Main;
import ui.managers.ThemeManager;

/**
 * Manages creation of menu buttons (Axis, 2D, 3D, Grid, Save).
 */
public class PlotMenus {

    public static final class SaveParams {
        public final int width;
        public final int height;
        public final String format;

        public SaveParams(int width, int height, String format) {
            this.width = width;
            this.height = height;
            this.format = format;
        }
    }

    private final UI_Main controller;
    private final NumberAxis xAxis;
    private final NumberAxis yAxis;
    private final Stage stage;
    private VBox axisStrip;
    private double zLowerBound = 0;
    private double zUpperBound = 1;

    // Variable selectors kept as fields so PlotWindow can refresh them
    private ComboBox<String> xSelect;
    private ComboBox<String> ySelect;
    private ComboBox<String> zSelect;

    // handler to notify when an axis variable is selected
    private BiConsumer<String, String> axisSelectHandler;
    private boolean suppressAxisSelectionEvents;

    public PlotMenus(UI_Main controller, NumberAxis xAxis, NumberAxis yAxis, Stage stage) {
        this.controller = controller;
        this.xAxis = xAxis;
        this.yAxis = yAxis;
        this.stage = stage;
    }

    /**
     * Builds an Axis toolbar button that toggles the axis strip.
     */
    public Button buildAxisButton(java.util.function.Consumer<Void> onToggle) {
        Button axisButton = new Button("Axis");
        axisButton.setOnAction(e -> onToggle.accept(null));
        return axisButton;
    }

    /**
     * Builds an Axis settings strip (hide/show) with limits and padding controls.
     */
    public VBox buildAxisStrip(BiConsumer<String, String> onAxisSelected) {
        // remember handler so other methods can trigger a selection
        this.axisSelectHandler = onAxisSelected;

        TextField minX = new TextField();
        TextField maxX = new TextField();
        TextField minY = new TextField();
        TextField maxY = new TextField();
        TextField minZ = new TextField();
        TextField maxZ = new TextField();
        minX.setPromptText("0");
        maxX.setPromptText("1");
        minY.setPromptText("0");
        maxY.setPromptText("1");
        minZ.setPromptText("0");
        maxZ.setPromptText("1");

        // Mode selectors allow quick switching between Auto, Manual, and Fit Data
        ComboBox<String> xMode = new ComboBox<>();
        ComboBox<String> yMode = new ComboBox<>();
        ComboBox<String> zMode = new ComboBox<>();

        // Variable selectors list workspace variables under "Select"
        List<String> vars = controller.getVariableNames();
        xSelect = new ComboBox<>();
        ySelect = new ComboBox<>();
        zSelect = new ComboBox<>();
        if (vars != null && !vars.isEmpty()) {
            xSelect.getItems().addAll(vars);
            ySelect.getItems().addAll(vars);
            zSelect.getItems().addAll(vars);
        }
        xSelect.setPromptText("null");
        ySelect.setPromptText("null");
        zSelect.setPromptText("null");
        xSelect.setPrefWidth(120);
        ySelect.setPrefWidth(120);
        zSelect.setPrefWidth(120);

        xMode.getItems().addAll("Auto", "Manual", "Fit Data");
        yMode.getItems().addAll("Auto", "Manual", "Fit Data");
        zMode.getItems().addAll("Auto", "Manual", "Fit Data");
        xMode.setPrefWidth(96);
        yMode.setPrefWidth(96);
        zMode.setPrefWidth(96);
        xMode.setValue(xAxis.isAutoRanging() ? "Auto" : "Manual");
        yMode.setValue("Manual");
        zMode.setValue("Auto");

        minX.setPrefWidth(68);
        maxX.setPrefWidth(68);
        minY.setPrefWidth(68);
        maxY.setPrefWidth(68);
        minZ.setPrefWidth(68);
        maxZ.setPrefWidth(68);

        TextField dotionPadding = new TextField("8");
        dotionPadding.setPrefWidth(60);

        HBox xRow = new HBox(6, new Label("Axis X"), new Label("Min"), minX, new Label("Max"), maxX, new Label("Select"), xSelect, xMode);
        HBox yRow = new HBox(6, new Label("Axis Y"), new Label("Min"), minY, new Label("Max"), maxY, new Label("Select"), ySelect, yMode);
        HBox zRow = new HBox(6, new Label("Axis Z"), new Label("Min"), minZ, new Label("Max"), maxZ, new Label("Select"), zSelect, zMode);
        HBox paddingRow = new HBox(6, new Label("Dotion padding"), dotionPadding);

        xRow.setAlignment(Pos.CENTER_LEFT);
        yRow.setAlignment(Pos.CENTER_LEFT);
        zRow.setAlignment(Pos.CENTER_LEFT);
        paddingRow.setAlignment(Pos.CENTER_LEFT);

        // Navigation buttons in a single row so the options read left to right.
        Button navX = new Button("Axis X");
        Button navY = new Button("Axis Y");
        Button navZ = new Button("Axis Z");
        Button navPadding = new Button("Padding");

        navX.setPrefWidth(90);
        navY.setPrefWidth(90);
        navZ.setPrefWidth(90);
        navPadding.setPrefWidth(90);

        HBox navRow = new HBox(6, navX, navY, navZ, navPadding);
        navRow.setAlignment(Pos.CENTER_LEFT);

        VBox sections = new VBox(8, xRow, yRow, zRow, paddingRow);
        sections.setAlignment(Pos.CENTER_LEFT);

        axisStrip = new VBox(8, navRow, sections);
        axisStrip.setAlignment(Pos.CENTER_LEFT);
        axisStrip.setPadding(new Insets(8, 12, 8, 12));
        axisStrip.getStyleClass().add("plot-annotation-box");
        axisStrip.setVisible(false);
        axisStrip.setManaged(false);

        Runnable applyBounds = () -> {
            // X axis mode handling
            String xm = xMode.getValue();
            if ("Auto".equalsIgnoreCase(xm) || "Fit Data".equalsIgnoreCase(xm)) {
                xAxis.setAutoRanging(true);
            } else {
                xAxis.setAutoRanging(false);
                xAxis.setLowerBound(PlotUtilities.parseDoubleOr(minX.getText(), xAxis.getLowerBound()));
                xAxis.setUpperBound(PlotUtilities.parseDoubleOr(maxX.getText(), xAxis.getUpperBound()));
            }

            // Y axis mode handling
            String ym = yMode.getValue();
            if ("Auto".equalsIgnoreCase(ym) || "Fit Data".equalsIgnoreCase(ym)) {
                yAxis.setAutoRanging(true);
            } else {
                yAxis.setAutoRanging(false);
                yAxis.setLowerBound(PlotUtilities.parseDoubleOr(minY.getText(), yAxis.getLowerBound()));
                yAxis.setUpperBound(PlotUtilities.parseDoubleOr(maxY.getText(), yAxis.getUpperBound()));
            }

            // Z axis - stored locally
            String zm = zMode.getValue();
            if ("Auto".equalsIgnoreCase(zm) || "Fit Data".equalsIgnoreCase(zm)) {
                // keep z bounds as-is when auto
            } else {
                zLowerBound = PlotUtilities.parseDoubleOr(minZ.getText(), zLowerBound);
                zUpperBound = PlotUtilities.parseDoubleOr(maxZ.getText(), zUpperBound);
            }

            double dPad = PlotUtilities.parseDoubleOr(dotionPadding.getText(), xAxis.getTickLabelGap());
            xAxis.setTickLabelGap(dPad);
            yAxis.setTickLabelGap(dPad);
        };

        minX.textProperty().addListener((obs, oldVal, newVal) -> {
            if (!"Manual".equalsIgnoreCase(xMode.getValue()) && newVal != null && !newVal.isBlank()) {
                xMode.setValue("Manual");
            }
            applyBounds.run();
        });
        maxX.textProperty().addListener((obs, oldVal, newVal) -> {
            if (!"Manual".equalsIgnoreCase(xMode.getValue()) && newVal != null && !newVal.isBlank()) {
                xMode.setValue("Manual");
            }
            applyBounds.run();
        });
        minY.textProperty().addListener((obs, oldVal, newVal) -> {
            if (!"Manual".equalsIgnoreCase(yMode.getValue()) && newVal != null && !newVal.isBlank()) {
                yMode.setValue("Manual");
            }
            applyBounds.run();
        });
        maxY.textProperty().addListener((obs, oldVal, newVal) -> {
            if (!"Manual".equalsIgnoreCase(yMode.getValue()) && newVal != null && !newVal.isBlank()) {
                yMode.setValue("Manual");
            }
            applyBounds.run();
        });
        minZ.textProperty().addListener((obs, oldVal, newVal) -> {
            if (!"Manual".equalsIgnoreCase(zMode.getValue()) && newVal != null && !newVal.isBlank()) {
                zMode.setValue("Manual");
            }
            applyBounds.run();
        });
        maxZ.textProperty().addListener((obs, oldVal, newVal) -> {
            if (!"Manual".equalsIgnoreCase(zMode.getValue()) && newVal != null && !newVal.isBlank()) {
                zMode.setValue("Manual");
            }
            applyBounds.run();
        });
        dotionPadding.textProperty().addListener((obs, oldVal, newVal) -> applyBounds.run());

        // Mode toggles enable/disable manual inputs
        xMode.valueProperty().addListener((obs, oldVal, newVal) -> {
            boolean manual = "Manual".equalsIgnoreCase(newVal);
            minX.setDisable(!manual);
            maxX.setDisable(!manual);
            applyBounds.run();
        });

        yMode.valueProperty().addListener((obs, oldVal, newVal) -> {
            boolean manual = "Manual".equalsIgnoreCase(newVal);
            minY.setDisable(!manual);
            maxY.setDisable(!manual);
            applyBounds.run();
        });

        zMode.valueProperty().addListener((obs, oldVal, newVal) -> {
            boolean manual = "Manual".equalsIgnoreCase(newVal);
            minZ.setDisable(!manual);
            maxZ.setDisable(!manual);
            applyBounds.run();
        });

        // Variable selection: populate axis labels and notify with the current X/Y pair
        xSelect.valueProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null && !newVal.isBlank()) {
                xAxis.setLabel(newVal);
                notifyAxisSelection();
            }
        });

        ySelect.valueProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null && !newVal.isBlank()) {
                yAxis.setLabel(newVal);
                notifyAxisSelection();
            }
        });

        zSelect.valueProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null && !newVal.isBlank()) {
                // For Z we don't change chart axes in 2D view, but we can notify
                notifyAxisSelection();
            }
        });

        applyBounds.run();

        // Nav button actions: show only the related section for quick access
        navX.setOnAction(e -> {
            sections.setVisible(true); sections.setManaged(true);
            xRow.setVisible(true); xRow.setManaged(true);
            yRow.setVisible(false); yRow.setManaged(false);
            zRow.setVisible(false); zRow.setManaged(false);
            paddingRow.setVisible(false); paddingRow.setManaged(false);
            setHighlightX(true);
            // mark selected nav button visually
            navX.getStyleClass().remove("nav-selected");
            if (!navX.getStyleClass().contains("nav-selected")) navX.getStyleClass().add("nav-selected");
            navY.getStyleClass().remove("nav-selected");
            navZ.getStyleClass().remove("nav-selected");
            navPadding.getStyleClass().remove("nav-selected");
        });
        navY.setOnAction(e -> {
            sections.setVisible(true); sections.setManaged(true);
            xRow.setVisible(false); xRow.setManaged(false);
            yRow.setVisible(true); yRow.setManaged(true);
            zRow.setVisible(false); zRow.setManaged(false);
            paddingRow.setVisible(false); paddingRow.setManaged(false);
            setHighlightY(true);
            navY.getStyleClass().remove("nav-selected");
            if (!navY.getStyleClass().contains("nav-selected")) navY.getStyleClass().add("nav-selected");
            navX.getStyleClass().remove("nav-selected");
            navZ.getStyleClass().remove("nav-selected");
            navPadding.getStyleClass().remove("nav-selected");
        });
        navZ.setOnAction(e -> {
            sections.setVisible(true); sections.setManaged(true);
            xRow.setVisible(false); xRow.setManaged(false);
            yRow.setVisible(false); yRow.setManaged(false);
            zRow.setVisible(true); zRow.setManaged(true);
            paddingRow.setVisible(false); paddingRow.setManaged(false);
            clearAxisHighlights();
            navZ.getStyleClass().remove("nav-selected");
            if (!navZ.getStyleClass().contains("nav-selected")) navZ.getStyleClass().add("nav-selected");
            navX.getStyleClass().remove("nav-selected");
            navY.getStyleClass().remove("nav-selected");
            navPadding.getStyleClass().remove("nav-selected");
        });
        navPadding.setOnAction(e -> {
            sections.setVisible(true); sections.setManaged(true);
            xRow.setVisible(false); xRow.setManaged(false);
            yRow.setVisible(false); yRow.setManaged(false);
            zRow.setVisible(false); zRow.setManaged(false);
            paddingRow.setVisible(true); paddingRow.setManaged(true);
            clearAxisHighlights();
            navPadding.getStyleClass().remove("nav-selected");
            if (!navPadding.getStyleClass().contains("nav-selected")) navPadding.getStyleClass().add("nav-selected");
            navX.getStyleClass().remove("nav-selected");
            navY.getStyleClass().remove("nav-selected");
            navZ.getStyleClass().remove("nav-selected");
        });

        // Start with sections hidden - only show navigation buttons
        sections.setVisible(false); sections.setManaged(false);
        xRow.setVisible(false); xRow.setManaged(false);
        yRow.setVisible(false); yRow.setManaged(false);
        zRow.setVisible(false); zRow.setManaged(false);
        paddingRow.setVisible(false); paddingRow.setManaged(false);

        // Leave Select dropdowns unselected by default.
        // Users will choose variables explicitly from the menu.

        return axisStrip;
    }

    /**
     * Update the variable lists shown in the Select dropdowns.
     */
    public void setVariableList(List<String> vars) {
        if (xSelect != null) {
            xSelect.getItems().setAll(vars == null ? List.of() : vars);
        }
        if (ySelect != null) {
            ySelect.getItems().setAll(vars == null ? List.of() : vars);
        }
        if (zSelect != null) {
            zSelect.getItems().setAll(vars == null ? List.of() : vars);
        }

        // Keep Select dropdowns unselected by default when the variable list updates.
    }

    private void notifyAxisSelection() {
        if (suppressAxisSelectionEvents || axisSelectHandler == null) {
            return;
        }

        String xName = xSelect == null ? null : xSelect.getValue();
        String yName = ySelect == null ? null : ySelect.getValue();
        if (xName != null || yName != null) {
            axisSelectHandler.accept(xName, yName);
        }
    }

    /**
     * Remove any highlighting classes from axes.
     */
    private void clearAxisHighlights() {
        try {
            xAxis.getStyleClass().remove("highlight-x");
        } catch (Exception ex) {
            // ignore
        }
        try {
            yAxis.getStyleClass().remove("highlight-y");
        } catch (Exception ex) {
            // ignore
        }
    }

    private void setHighlightX(boolean on) {
        if (on) {
            clearAxisHighlights();
            if (!xAxis.getStyleClass().contains("highlight-x")) xAxis.getStyleClass().add("highlight-x");
        } else {
            xAxis.getStyleClass().remove("highlight-x");
        }
    }

    private void setHighlightY(boolean on) {
        if (on) {
            clearAxisHighlights();
            if (!yAxis.getStyleClass().contains("highlight-y")) yAxis.getStyleClass().add("highlight-y");
        } else {
            yAxis.getStyleClass().remove("highlight-y");
        }
    }

    /**
     * Toggles axis strip visibility.
     */
    public void toggleAxisStrip() {
        if (axisStrip == null) return;
        boolean show = !axisStrip.isVisible();
        axisStrip.setVisible(show);
        axisStrip.setManaged(show);
        if (!show) {
            clearAxisHighlights();
        }
    }

    /**
     * Hides axis strip.
     */
    public void hideAxisStrip() {
        if (axisStrip == null) return;
        axisStrip.setVisible(false);
        axisStrip.setManaged(false);
        clearAxisHighlights();
        // clear any nav-selected class on nav buttons
        try {
            if (axisStrip.getChildren() != null && !axisStrip.getChildren().isEmpty()) {
                java.lang.Object first = axisStrip.getChildren().get(0);
                if (first instanceof HBox) {
                    HBox navRow = (HBox) first;
                    for (javafx.scene.Node n : navRow.getChildren()) {
                        if (n instanceof Button) {
                            ((Button) n).getStyleClass().remove("nav-selected");
                        }
                    }
                }
            }
        } catch (Exception ex) {
            // ignore
        }
    }

    /**
     * Builds the Axis menu with variable selection.
     */
    public MenuButton buildAxisMenu(java.util.function.Consumer<String> onPlotSelected) {
        MenuButton axisMenu = new MenuButton("Axis");
        List<String> vars = controller.getVariableNames();

        MenuItem selectItem = new MenuItem("Select");
        selectItem.setOnAction(e -> showAxisSelectDialog(vars, onPlotSelected));
        axisMenu.getItems().add(selectItem);

        if (!vars.isEmpty()) {
            axisMenu.getItems().add(new SeparatorMenuItem());
        }

        for (String v : vars) {
            MenuItem item = new MenuItem(v);
            item.setOnAction(e -> {
                xAxis.setLabel(v);
                yAxis.setLabel(v + " Value");
                onPlotSelected.accept(v);
            });
            axisMenu.getItems().add(item);
        }

        return axisMenu;
    }

    /**
     * Shows the axis selection dialog.
     */
    private void showAxisSelectDialog(List<String> vars, java.util.function.Consumer<String> onPlotSelected) {
        ComboBox<String> xVar = new ComboBox<>();
        ComboBox<String> yVar = new ComboBox<>();
        ComboBox<String> zVar = new ComboBox<>();

        xVar.getItems().addAll(vars);
        yVar.getItems().addAll(vars);
        zVar.getItems().addAll(vars);

        xVar.setPromptText("null");
        yVar.setPromptText("null");
        zVar.setPromptText("null");

        TextField minX = new TextField(String.valueOf(xAxis.getLowerBound()));
        TextField maxX = new TextField(String.valueOf(xAxis.getUpperBound()));
        TextField minY = new TextField(String.valueOf(yAxis.getLowerBound()));
        TextField maxY = new TextField(String.valueOf(yAxis.getUpperBound()));
        TextField minZ = new TextField("0");
        TextField maxZ = new TextField("1");

        minX.setPrefWidth(70);
        maxX.setPrefWidth(70);
        minY.setPrefWidth(70);
        maxY.setPrefWidth(70);
        minZ.setPrefWidth(70);
        maxZ.setPrefWidth(70);

        HBox rowX = new HBox(8, new Label("Select X"), xVar, new Label("X limit"), minX, new Label("to"), maxX);
        HBox rowY = new HBox(8, new Label("Select Y"), yVar, new Label("Y limit"), minY, new Label("to"), maxY);
        HBox rowZ = new HBox(8, new Label("Select Z"), zVar, new Label("Z limit"), minZ, new Label("to"), maxZ);

        rowX.setAlignment(Pos.CENTER_LEFT);
        rowY.setAlignment(Pos.CENTER_LEFT);
        rowZ.setAlignment(Pos.CENTER_LEFT);

        Button apply = new Button("Apply");
        Button cancel = new Button("Cancel");
        HBox actions = new HBox(8, apply, cancel);
        actions.setAlignment(Pos.CENTER_RIGHT);

        VBox box = new VBox(10, rowX, rowY, rowZ, actions);
        box.setPadding(new Insets(12));
        box.setStyle("-fx-background-color:#e6e9ec;");

        Stage dialog = new Stage();
        dialog.setTitle("Axis Selection");
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.initOwner(stage);
        Scene scene = new Scene(box, 560, 180);
        ThemeManager.registerScene(scene);
        dialog.setScene(scene);

        apply.setOnAction(e -> {
            String xName = xVar.getValue();
            String yName = yVar.getValue();
            String zName = zVar.getValue();

            if (xName != null) {
                xAxis.setLabel(xName);
            }
            if (yName != null) {
                yAxis.setLabel(yName);
            }

            xAxis.setLowerBound(PlotUtilities.parseDoubleOr(minX.getText(), xAxis.getLowerBound()));
            xAxis.setUpperBound(PlotUtilities.parseDoubleOr(maxX.getText(), xAxis.getUpperBound()));
            yAxis.setLowerBound(PlotUtilities.parseDoubleOr(minY.getText(), yAxis.getLowerBound()));
            yAxis.setUpperBound(PlotUtilities.parseDoubleOr(maxY.getText(), yAxis.getUpperBound()));

            if (yName != null) {
                onPlotSelected.accept(yName);
            }

            if (zName != null && !zName.isBlank()) {
                // Could be used for 3D plot title
            }

            dialog.close();
        });

        cancel.setOnAction(e -> dialog.close());

        dialog.show();
    }

    /**
     * Builds the 2D menu with chart type options.
     */
    public MenuButton build2DMenu(java.util.function.Consumer<String> onTypeSelected, Runnable onClear,
                                   Runnable onCustomize) {
        MenuButton menu = new MenuButton("2D");

        MenuItem clear = new MenuItem("Clear Plot");
        MenuItem customize = new MenuItem("Customize Axis");

        clear.setOnAction(e -> onClear.run());
        customize.setOnAction(e -> onCustomize.run());

        Menu plotTypes = new Menu("Plot Types");
        List<String> plotNames = List.of(
                "Plot", "Area", "Fill", "Stack Plot", "Bar Chart", "Histogram", "Errorbar",
                "Scatter", "Bubble", "Violin", "Box Plot", "Contour", "Heatmap", "Polar",
                "Pie Chart", "Vector Field", "Innovation Plot", "Surf", "Mesh", "Quiver",
                "Stem", "Stairs", "Semilog X", "Semilog Y", "Log Log");

        for (String name : plotNames) {
            MenuItem item = new MenuItem(name);
            String type = PlotUtilities.normalizePlotType(name);
            item.setOnAction(e -> onTypeSelected.accept(type));
            plotTypes.getItems().add(item);
        }

        menu.getItems().addAll(plotTypes, new SeparatorMenuItem(), clear, customize);
        return menu;
    }

    /**
     * Builds the 3D menu.
     */
    public MenuButton build3DMenu(Runnable onShow3D) {
        MenuButton menu = new MenuButton("3D");
        MenuItem standard = new MenuItem("Standard 3D");
        standard.setOnAction(e -> onShow3D.run());
        menu.getItems().add(standard);
        return menu;
    }

    /**
     * Builds the Grid menu for grid customization.
     */
    public MenuButton buildGridMenu(java.util.function.Consumer<ColorPicker> onCustomize) {
        MenuButton menu = new MenuButton("Grid");
        MenuItem customize = new MenuItem("Customize");

        customize.setOnAction(e -> {
            ColorPicker color = new ColorPicker();
            Slider width = new Slider(0.5, 5, 1);

            VBox box = new VBox(10,
                    new Label("Grid Color"), color,
                    new Label("Grid Width"), width);

            box.setStyle("-fx-background-color:#0aa6a6; -fx-padding:15;");

            Stage dialog = new Stage();
            dialog.initModality(Modality.APPLICATION_MODAL);
            dialog.initOwner(stage);
            Scene scene = new Scene(box, 300, 250);
            ThemeManager.registerScene(scene);
            dialog.setScene(scene);
            // Notify when the color changes (live preview)
            color.setOnAction(e2 -> {
                if (onCustomize != null) {
                    onCustomize.accept(color);
                }
            });

            dialog.show();
        });

        menu.getItems().add(customize);
        return menu;
    }

    /**
     * Opens the axis customization dialog used by the 2D menu.
     */
    public void showCustomizeDialog() {
        List<String> vars = controller.getVariableNames();
        showAxisSelectDialog(vars == null ? List.of() : vars, onPlotSelected -> {
            if (axisSelectHandler != null) {
                axisSelectHandler.accept(xSelect == null ? null : xSelect.getValue(), ySelect == null ? null : ySelect.getValue());
            }
        });
    }

    /**
     * Builds the Save menu used by the plot window.
     */
    public MenuButton buildSaveMenu(java.util.function.Consumer<String> onSave,
                                    Runnable onCustomize) {
        MenuButton menu = new MenuButton("Save");

        MenuItem png = new MenuItem("PNG");
        MenuItem jpg = new MenuItem("JPG");
        MenuItem custom = new MenuItem("Custom Size");

        png.setOnAction(e -> onSave.accept("png"));
        jpg.setOnAction(e -> onSave.accept("jpg"));
        custom.setOnAction(e -> onCustomize.run());

        menu.getItems().addAll(png, jpg, new SeparatorMenuItem(), custom);
        return menu;
    }

    /**
     * Opens the custom save dialog used by the plot window.
     */
    public void showCustomizeSaveDialog(java.util.function.Consumer<SaveParams> onApply) {
        if (onApply == null) {
            return;
        }

        TextField widthField = new TextField("1200");
        TextField heightField = new TextField("800");
        ComboBox<String> formatBox = new ComboBox<>();
        formatBox.getItems().addAll("png", "jpg");
        formatBox.setValue("png");

        widthField.setPrefWidth(90);
        heightField.setPrefWidth(90);

        HBox widthRow = new HBox(8, new Label("Width"), widthField);
        HBox heightRow = new HBox(8, new Label("Height"), heightField);
        HBox formatRow = new HBox(8, new Label("Format"), formatBox);
        widthRow.setAlignment(Pos.CENTER_LEFT);
        heightRow.setAlignment(Pos.CENTER_LEFT);
        formatRow.setAlignment(Pos.CENTER_LEFT);

        Button apply = new Button("Apply");
        Button cancel = new Button("Cancel");
        HBox actions = new HBox(8, apply, cancel);
        actions.setAlignment(Pos.CENTER_RIGHT);

        VBox box = new VBox(10, widthRow, heightRow, formatRow, actions);
        box.setPadding(new Insets(12));
        box.setStyle("-fx-background-color:#e6e9ec;");

        Stage dialog = new Stage();
        dialog.setTitle("Custom Save");
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.initOwner(stage);
        Scene scene = new Scene(box, 320, 170);
        ThemeManager.registerScene(scene);
        dialog.setScene(scene);

        apply.setOnAction(e -> {
            int width = (int) PlotUtilities.parseDoubleOr(widthField.getText(), 1200);
            int height = (int) PlotUtilities.parseDoubleOr(heightField.getText(), 800);
            String format = formatBox.getValue() == null ? "png" : formatBox.getValue();
            onApply.accept(new SaveParams(width, height, format));
            dialog.close();
        });

        cancel.setOnAction(e -> dialog.close());

        dialog.show();
    }
}
