package plot;

import java.util.function.BiConsumer;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

/**
 * Embedded 3D plot configuration panel.
 */
public class Plot3D {

    /**
     * Builds the embedded 3D configuration panel.
     */
    public VBox build(BiConsumer<String, String> callback, Runnable onDismiss) {

        // Plot Type ComboBox
        ComboBox<String> plotType = new ComboBox<>();

        plotType.getItems().addAll(
                "3D Line",
                "3D Scatter",
                "Surface",
                "Wireframe",
                "Contour 3D",
                "Mesh",
                "3D Bar",
                "Voxel",
                "3D Stem",
                "3D Quiver",
                "Tri-Surface",
                "Ribbon");

        plotType.setValue("3D Line");
        plotType.setPrefWidth(140);

        // Style ComboBox
        ComboBox<String> style = new ComboBox<>();

        style.getItems().addAll(
                "Solid",
                "Dashed",
                "Dotted",
                "Dash-dot",
                "None");

        style.setValue("Solid");
        style.setPrefWidth(140);

        // Title
        Label title = new Label("3D Plot Configuration");

        title.setStyle("""
                -fx-font-size: 14px;
                -fx-font-weight: bold;
            -fx-text-fill: white;
                """);

        // Labels
        Label typeLabel = new Label("Type:");
        typeLabel.setStyle("-fx-text-fill: white;");

        Label styleLabel = new Label("Style:");
        styleLabel.setStyle("-fx-text-fill: white;");

        // Configuration row
        HBox configRow = new HBox(10);

        configRow.setAlignment(Pos.CENTER_LEFT);

        configRow.getChildren().addAll(
                typeLabel,
                plotType,
                styleLabel,
                style);

        // Main layout
        VBox content = new VBox(8);
        content.setPadding(new Insets(10));
        content.setStyle("""
            -fx-background-color:#0aa6a6;
                -fx-background-radius: 8;
                -fx-border-radius: 8;
                -fx-padding: 12;
                """);

        // Buttons
        Button applyBtn = new Button("Apply");
        Button cancelBtn = new Button("Cancel");

        applyBtn.setPrefWidth(65);
        cancelBtn.setPrefWidth(65);

        applyBtn.setStyle("-fx-padding: 6px 12px;");
        cancelBtn.setStyle("-fx-padding: 6px 12px;");

        HBox buttons = new HBox(10, applyBtn, cancelBtn);
        buttons.setAlignment(Pos.CENTER_RIGHT);

        content.getChildren().addAll(
                title,
                configRow,
                buttons);

        // Apply action
        applyBtn.setOnAction(e -> {
            String type = plotType.getValue();
            String selectedStyle = style.getValue();

            if (type != null && selectedStyle != null) {
                callback.accept(
                        normalizeType(type),
                        selectedStyle.toLowerCase());
            }

            if (onDismiss != null) onDismiss.run();
            else {
                content.setVisible(false);
                content.setManaged(false);
            }
        });

        // Cancel action
        cancelBtn.setOnAction(e -> {
            if (onDismiss != null) onDismiss.run();
            else {
                content.setVisible(false);
                content.setManaged(false);
            }
        });

        return content;
    }

    /**
     * Converts display names into backend-friendly names.
     */
    private String normalizeType(String type) {

        if (type == null)
            return "";

        return switch (type) {

            case "3D Line" -> "line3d";
            case "3D Scatter" -> "scatter3d";
            case "Contour 3D" -> "contour3d";
            case "3D Bar" -> "bar3d";
            case "3D Stem" -> "stem3d";
            case "3D Quiver" -> "quiver3d";
            case "Tri-Surface" -> "trisurface";

            default -> type.toLowerCase()
                    .replace(" ", "_");
        };
    }
}