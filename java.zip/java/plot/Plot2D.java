package plot;

import java.util.function.BiConsumer;
import java.util.function.Consumer;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

/**
 * Embedded 2D plot configuration panel.
 */
public class Plot2D {

    /**
     * Builds the embedded 2D configuration panel.
     * Replaces the Type selector with a Weight selector and keeps Style.
     */
        public VBox build(BiConsumer<String, String> callback, Consumer<String> weightCallback, Consumer<String> hatchCallback, Runnable onDismiss) {

        // Style ComboBox
        ComboBox<String> style = new ComboBox<>();
        style.getItems().addAll(
                "Solid",
                "Dashed",
                "Dotted",
                "Dash-dot");

        style.setValue("Solid");
        style.setPrefWidth(120);

        // Weight ComboBox (replaces the Type control)
        ComboBox<String> weight = new ComboBox<>();
        weight.getItems().addAll(
                "1/4 pt",
                "1/2 pt",
                "3/4 pt",
                "1 pt",
                "1 1/2 pt",
                "2 1/4 pt",
                "3 pt",
                "4 1/2 pt",
                "6 pt",
                "More Lines...");

        weight.setValue("1 pt");
        weight.setPrefWidth(120);

        // Hatching ComboBox (for bar chart hatching styles)
        ComboBox<String> hatching = new ComboBox<>();
        hatching.getItems().addAll(
                "None",
                "Hatching",
                "Cross-hatching",
                "Circularism",
                "Contouring",
                "Scribbles",
                "Stippling",
                "Short Dashes",
                "Blending",
                "3s",
                "Zig Zags",
                "Diagonal",
                "Cross",
                "Dots",
                "Horizontal");
        hatching.setValue("None");
        hatching.setPrefWidth(120);

        Runnable applySelection = () -> {
            if (callback == null) return;
            String selectedStyle = style.getValue();
            // Type selection removed — pass null for type
            if (selectedStyle != null) callback.accept(null, selectedStyle.toLowerCase());
        };

                style.valueProperty().addListener((obs, oldVal, newVal) -> applySelection.run());
                weight.valueProperty().addListener((obs, oldVal, newVal) -> {
                        if (weightCallback != null) weightCallback.accept(weight.getValue());
                });
                hatching.valueProperty().addListener((obs, oldVal, newVal) -> {
                        if (hatchCallback != null) hatchCallback.accept(hatching.getValue());
                });

        // Labels
        Label title = new Label("2D Plot Configuration");
        title.setStyle("""
                -fx-font-size: 14px;
                -fx-font-weight: bold;
                -fx-text-fill: white;
                """);

        Label weightLabel = new Label("Weight:");
        weightLabel.setStyle("-fx-text-fill: white;");

        Label styleLabel = new Label("Style:");
        styleLabel.setStyle("-fx-text-fill: white;");

        // Configuration row
        HBox configRow = new HBox(10);
        configRow.setAlignment(Pos.CENTER_LEFT);

        configRow.getChildren().addAll(
                weightLabel,
                weight,
                styleLabel,
                style);

        // Buttons
        Button applyBtn = new Button("Apply");
        Button cancelBtn = new Button("Cancel");

        applyBtn.setPrefWidth(65);
        cancelBtn.setPrefWidth(65);

        applyBtn.setStyle("-fx-padding: 6px 12px;");
        cancelBtn.setStyle("-fx-padding: 6px 12px;");

        HBox buttons = new HBox(10, applyBtn, cancelBtn);
        buttons.setAlignment(Pos.CENTER_RIGHT);

        // Main layout
        VBox content = new VBox(8);

        content.setPadding(new Insets(10));

        content.setStyle("""
                -fx-background-color:#0aa6a6;
                -fx-background-radius: 8;
                -fx-border-radius: 8;
                -fx-padding: 12;
                """);

        // Hatching row below weights and style
        HBox hatchRow = new HBox(10);
        hatchRow.setAlignment(Pos.CENTER_LEFT);
        Label hatchLabel = new Label("Hatching:");
        hatchLabel.setStyle("-fx-text-fill: white;");
        hatchRow.getChildren().addAll(hatchLabel, hatching);

        content.getChildren().addAll(
                title,
                configRow,
                hatchRow,
                buttons);

                // Apply action
                applyBtn.setOnAction(e -> {
                        applySelection.run();
                        if (onDismiss != null) onDismiss.run();
                        else { content.setVisible(false); content.setManaged(false); }
                });

                // Cancel action
                cancelBtn.setOnAction(e -> {
                        if (onDismiss != null) onDismiss.run();
                        else { content.setVisible(false); content.setManaged(false); }
                });

        return content;
    }
}