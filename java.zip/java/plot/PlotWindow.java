package plot;

import java.io.File;
import java.util.List;

import javafx.application.Platform;
import plot.plotwindow.PlotWindowDialogsSupport;
import plot.plotwindow.PlotWindowGridSupport;
import plot.plotwindow.PlotWindowInteractionSupport;
import plot.plotwindow.PlotWindowLayoutSupport;
import plot.plotwindow.PlotWindowLifecycleSupport;
import plot.plotwindow.PlotWindowSelectionSupport;
import plot.plotwindow.PlotWindowState;
import ui.UI_Main;
import ui.settings.connector_cpp.UPIPoint;
import ui.settings.connector_cpp.UPIVariable;

public class PlotWindow {
    private final PlotWindowState state;
    private final PlotWindowGridSupport gridSupport;
    private final PlotWindowDialogsSupport dialogsSupport;
    private final PlotWindowInteractionSupport interactionSupport;
    private final PlotWindowSelectionSupport selectionSupport;
    private final PlotWindowLayoutSupport layoutSupport;
    private final PlotWindowLifecycleSupport lifecycleSupport;

    public PlotWindow(UI_Main controller, File currentFolder) {
        this.state = new PlotWindowState(controller, currentFolder);
        this.gridSupport = new PlotWindowGridSupport(state);
        this.dialogsSupport = new PlotWindowDialogsSupport(state, gridSupport);
        this.interactionSupport = new PlotWindowInteractionSupport(state, dialogsSupport);
        this.selectionSupport = new PlotWindowSelectionSupport(state, dialogsSupport, gridSupport);
        this.layoutSupport = new PlotWindowLayoutSupport(state, selectionSupport, dialogsSupport, gridSupport,
                interactionSupport);
        this.lifecycleSupport = new PlotWindowLifecycleSupport(state, layoutSupport, gridSupport, selectionSupport);
    }

    public void show() {
        lifecycleSupport.show();
    }

    public void showLivePoints(List<UPIPoint> points) {
        lifecycleSupport.showLivePoints(points);
    }

    public void showLivePoints(List<UPIPoint> points, List<UPIVariable> variables) {
        lifecycleSupport.showLivePoints(points, variables);
    }

    public void setBarMode() {
        state.chartOps.changeChartType("bar");
    }

    public void setLineMode() {
        state.chartOps.changeChartType("line");
    }

    public void showBarPoints(List<UPIPoint> points, List<UPIVariable> vars) {
        // Keep workspace variables in sync (LINE path does this in
        // PlotWindowLifecycleSupport.showLivePoints(points, variables)).
        try {
            selectionSupport.updateVariableSidebar(vars);
        } catch (Exception ignore) {
        }

        state.chartOps.drawBarPoints(points, vars);

        // drawBarPoints() replaces the visible chart node (centerPane child).
        // Re-attach chart-corner controls/overlays so they don't disappear for bar
        // plots.
        try {
            Platform.runLater(layoutSupport::updateChartCornerVisibility);
        } catch (Exception ignore) {
        }
    }

}
