package multiphysics;

import java.io.InputStream;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.Window;

/**
 * Small Multiphysics licence-information window opened from the Home ribbon.
 */
public final class UI_MP_Main {

    private static final String NAVY_BLUE = "#004073";
    private static final String ICON_PATH = "/icons/ic_18_nc.PNG";

    private static Stage window;

    private UI_MP_Main() {
    }

    /**
     * Opens the Multiphysics information window. If it is already open, the
     * existing window is brought to the front instead of creating a duplicate.
     *
     * @param owner main Astra application window
     */
    public static void open(Window owner) {
        if (window != null && window.isShowing()) {
            window.toFront();
            window.requestFocus();
            return;
        }

        window = new Stage();
        window.setTitle("Multiphysics");
        window.setResizable(false);
        window.initModality(Modality.WINDOW_MODAL);

        applyWindowIcon(window);

        if (owner != null) {
            window.initOwner(owner);
        }

        Label title = new Label("Multiphysics");
        title.setStyle("-fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: bold;");

        HBox titleBar = new HBox(title);
        titleBar.setAlignment(Pos.CENTER_LEFT);
        titleBar.setPadding(new Insets(9, 14, 9, 14));
        titleBar.setStyle("-fx-background-color: " + NAVY_BLUE + ";");

        Label message = new Label("Multiphysics is Licensed Version");
        message.setStyle("-fx-font-size: 15px; -fx-font-weight: bold;");

        StackPane content = new StackPane(message);
        content.setPadding(new Insets(34, 30, 34, 30));
        content.setMinSize(390, 120);

        HBox footerBar = new HBox();
        footerBar.setMinHeight(27);
        footerBar.setPrefHeight(27);
        footerBar.setStyle("-fx-background-color: " + NAVY_BLUE + ";");

        BorderPane root = new BorderPane();
        root.setTop(titleBar);
        root.setCenter(content);
        root.setBottom(footerBar);

        Scene scene = new Scene(root, 450, 205);
        if (owner != null && owner.getScene() != null) {
            scene.getStylesheets().addAll(owner.getScene().getStylesheets());
        }

        window.setScene(scene);
        window.setOnHidden(event -> window = null);
        window.show();
        window.centerOnScreen();
    }

    /**
     * Loads the Neural Code icon from the classpath and applies it to the stage.
     * Failure to load is non-fatal: the window simply keeps the default icon.
     *
     * @param stage stage to decorate
     */
    private static void applyWindowIcon(Stage stage) {
        try (InputStream in = UI_MP_Main.class.getResourceAsStream(ICON_PATH)) {
            if (in == null) {
                System.err.println("Window icon not found on classpath: " + ICON_PATH);
                return;
            }
            Image icon = new Image(in);
            if (!icon.isError()) {
                stage.getIcons().add(icon);
            }
        } catch (Exception ex) {
            System.err.println("Failed to load window icon: " + ex.getMessage());
        }
    }
}