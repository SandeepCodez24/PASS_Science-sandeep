package language.replace;

import java.util.HashMap;
import java.util.Map;

public class Telugu {

    // ---- Telugu symbol maps ----
    public static final Map<String, String> TELUGU_VOWEL_MAP = new HashMap<>();
    public static final Map<String, String> TELUGU_CONSONANT_MAP = new HashMap<>();

    // ---- symbol initialization ----
    static {
        // Telugu vowels (Svarāksharalu)
        TELUGU_VOWEL_MAP.put("\\var(\\telugu(\\a))", "అ");
        TELUGU_VOWEL_MAP.put("\\var(\\telugu(\\aa))", "ఆ");
        TELUGU_VOWEL_MAP.put("\\var(\\telugu(\\i))", "ఇ");
        TELUGU_VOWEL_MAP.put("\\var(\\telugu(\\ii))", "ఈ");
        TELUGU_VOWEL_MAP.put("\\var(\\telugu(\\u))", "ఉ");
        TELUGU_VOWEL_MAP.put("\\var(\\telugu(\\uu))", "ఊ");
        TELUGU_VOWEL_MAP.put("\\var(\\telugu(\\ru))", "ఋ");
        TELUGU_VOWEL_MAP.put("\\var(\\telugu(\\e))", "ఎ");
        TELUGU_VOWEL_MAP.put("\\var(\\telugu(\\ee))", "ఏ");
        TELUGU_VOWEL_MAP.put("\\var(\\telugu(\\ai))", "ఐ");
        TELUGU_VOWEL_MAP.put("\\var(\\telugu(\\o))", "ఒ");
        TELUGU_VOWEL_MAP.put("\\var(\\telugu(\\oo))", "ఓ");
        TELUGU_VOWEL_MAP.put("\\var(\\telugu(\\au))", "ఔ");
        TELUGU_VOWEL_MAP.put("\\var(\\telugu(\\am))", "అం");
        TELUGU_VOWEL_MAP.put("\\var(\\telugu(\\ah))", "అః");

        // Telugu consonants
        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\k))", "క");
        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\kh))", "ఖ");
        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\g))", "గ");
        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\gh))", "ఘ");
        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\ng))", "ఙ");

        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\ch))", "చ");
        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\chh))", "ఛ");
        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\j))", "జ");
        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\jh))", "ఝ");
        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\ny))", "ఞ");

        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\t))", "ట");
        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\th))", "ఠ");
        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\d))", "డ");
        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\dh))", "ఢ");
        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\n))", "ణ");

        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\t2))", "త");
        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\th2))", "థ");
        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\d2))", "ద");
        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\dh2))", "ధ");
        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\n2))", "న");

        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\p))", "ప");
        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\ph))", "ఫ");
        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\b))", "బ");
        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\bh))", "భ");
        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\m))", "మ");

        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\y))", "య");
        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\r))", "ర");
        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\l))", "ల");
        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\v))", "వ");
        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\sh))", "శ");
        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\ss))", "ష");
        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\s))", "స");
        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\h))", "హ");
        TELUGU_CONSONANT_MAP.put("\\var(\\telugu(\\ll))", "ళ");
    }
}
