package language.replace;

import java.util.HashMap;
import java.util.Map;

public class Malayalam {
    // ---- Malayalam symbol maps ----
    public static final Map<String, String> MALAYALAM_VOWEL_MAP = new HashMap<>();
    public static final Map<String, String> MALAYALAM_CONSONANT_MAP = new HashMap<>();

    // ---- symbol initialization ----
    static {
        // Malayalam vowels (Svarākṣaraṅṅaḷ – 12)
        MALAYALAM_VOWEL_MAP.put("\\var(\\malayalam(\\a))", "അ");
        MALAYALAM_VOWEL_MAP.put("\\var(\\malayalam(\\aa))", "ആ"); // malayalam
        MALAYALAM_VOWEL_MAP.put("\\var(\\malayalam(\\e))", "ഇ");
        MALAYALAM_VOWEL_MAP.put("\\var(\\malayalam(\\ee))", "ഈ");
        MALAYALAM_VOWEL_MAP.put("\\var(\\malayalam(\\u))", "ഉ");
        MALAYALAM_VOWEL_MAP.put("\\var(\\malayalam(\\uu))", "ഊ");
        MALAYALAM_VOWEL_MAP.put("\\var(\\malayalam(\\ea))", "എ");
        MALAYALAM_VOWEL_MAP.put("\\var(\\malayalam(\\eaa))", "ഏ");
        MALAYALAM_VOWEL_MAP.put("\\var(\\malayalam(\\i))", "ഐ");
        MALAYALAM_VOWEL_MAP.put("\\var(\\malayalam(\\o))", "ഒ");
        MALAYALAM_VOWEL_MAP.put("\\var(\\malayalam(\\oo))", "ഓ");
        MALAYALAM_VOWEL_MAP.put("\\var(\\malayalam(\\au))", "ഔ");
        MALAYALAM_VOWEL_MAP.put("\\var(\\malayalam(\\akg))", "ஃ");
        
        // // ---- malayalam consonants (sample – extend freely) ----
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ik))", "ക്");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ing))", "ങ്");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ich))", "ച്");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ina))", "ഞ്");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\id))", "ട്");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\iN))", "ണ്");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ith))", "ത്");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\iNn))", "ന്");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ip))", "പ്");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\im))", "ം"); // pay attention
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\iy))", "യ്");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ir))", "ര്");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\il))", "ല്");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\iv))", "വ്");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\izh))", "ഴ്");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\iL))", "ള്");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\iR))", "റ്");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\in))", "ന്");
        /////// group 01
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ka))", "ക");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\kha))", "ഖ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ga))", "ഗ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\gha))", "ഘ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\nga))", "ങ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\cha))", "ച");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\chha))", "ഛ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ja))", "ജ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\jha))", "ഝ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\gna))", "ഞ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\tta))", "ട");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ttha))", "ഠ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dda))", "ഡ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ddha))", "ഢ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Na))", "ണ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\tha))", "ത");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\thha))", "ഥ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dha))", "ദ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dhha))", "ധ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\na))", "ന");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\pa))", "പ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\pha))", "ഫ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ba))", "ബ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\bha))", "ഭ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ma))", "മ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ya))", "യ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ra))", "ര");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\la))", "ല");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\va))", "വ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\sha))", "ശ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ssa))", "ഷ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\sa))", "സ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ha))", "ഹ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\La))", "ള");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\zha))", "ഴ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Ra))", "റ");

        ////// group 2
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\kaa))", "കാ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\khaa))", "ഖാ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\gaa))", "ഗാ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ghaa))", "ഘാ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ngaa))", "ങാ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\chaa))", "ചാ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\chhaa))", "ഛാ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\jaa))", "ജാ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\jhaa))", "ഝാ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\gnaa))", "ഞാ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ttaa))", "ടാ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\tthaa))", "ഠാ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ddaa))", "ഡാ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ddhaa))", "ഢാ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Naa))", "ണാ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\thaa))", "താ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\thhaa))", "ഥാ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dhaa))", "ദാ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dhhaa))", "ധാ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\naa))", "നാ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\paa))", "പാ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\phaa))", "ഫാ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\baa))", "ബാ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\bhaa))", "ഭാ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\maa))", "മാ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\yaa))", "യാ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\raa))", "രാ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\laa))", "ലാ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\vaa))", "വാ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\shaa))", "ശാ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ssaa))", "ഷാ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\saa))", "സാ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\haa))", "ഹാ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Laa))", "ളാ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\zhaa))", "ഴാ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Raa))", "റാ");
        /////// group 03
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ki))", "കി");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\khi))", "ഖി");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\gi))", "ഗി");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ghi))", "ഘി");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ngi))", "ങി");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\chi))", "ചി");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\chhi))", "ഛി");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ji))", "ജി");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\jhi))", "ഝി");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\gni))", "ഞി");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\tti))", "ടി");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\tthi))", "ഠി");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ddi))", "ഡി");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ddhi))", "ഢി");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Ni))", "ണി");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\thi))", "തി");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\thhi))", "ഥി");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dhi))", "ദി");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dhhi))", "ധി");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ni))", "നി");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\pi))", "പി");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\phi))", "ഫി");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\bi))", "ബി");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\bhi))", "ഭി");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\mi))", "മി");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\yi))", "യി");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ri))", "രി");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\li))", "ലി");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\vi))", "വി");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\shi))", "ശി");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ssi))", "ഷി");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\si))", "സി");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\hi))", "ഹി");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Li))", "ളി");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\zhi))", "ഴി");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Ri))", "റി");
        ////// Group 04
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\kii))", "കീ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\khii))", "ഖീ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\gii))", "ഗീ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ghii))", "ഘീ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ngii))", "ങീ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\chii))", "ചീ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\chhii))", "ഛീ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\jii))", "ജീ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\jhii))", "ഝീ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\gnii))", "ഞീ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ttii))", "ടീ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\tthii))", "ഠീ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ddii))", "ഡീ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ddhii))", "ഢീ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Nii))", "ണീ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\thii))", "തീ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\thhii))", "ഥീ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dhii))", "ദീ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dhhii))", "ധീ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\nii))", "നീ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\pii))", "പീ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\phii))", "ഫീ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\bii))", "ബീ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\bhii))", "ഭീ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\mii))", "മീ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\yii))", "യീ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\rii))", "രീ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\lii))", "ലീ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\vii))", "വീ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\shii))", "ശീ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ssii))", "ഷീ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\sii))", "സീ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\hii))", "ഹീ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Lii))", "ളീ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\zhii))", "ഴീ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Rii))", "റീ");
        /////// Group 05 
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ku))", "കു");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\khu))", "ഖു");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\gu))", "ഗു");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ghu))", "ഘു");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ngu))", "ങു");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\chu))", "ചു");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\chhu))", "ഛു");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ju))", "ജു");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\jhu))", "ഝു");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\gnu))", "ഞു");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ttu))", "ടു");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\tthu))", "ഠു");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ddu))", "ഡു");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ddhu))", "ഢു");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Nu))", "ണു");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\thu))", "തു");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\thhu))", "ഥു");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dhu))", "ദു");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dhhu))", "ധു");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\nu))", "നു");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\pu))", "പു");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\phu))", "ഫു");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\bu))", "ബു");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\bhu))", "ഭു");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\mu))", "മു");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\yu))", "യു");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ru))", "രു");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\lu))", "ലു");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\vu))", "വു");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\shu))", "ശു");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\sshu))", "ഷു");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\su))", "സു");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\hu))", "ഹു");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Lu))", "ളു");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\zhu))", "ഴു");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Ru))", "റു");
        ///// Group 06 
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\kuu))", "കൂ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\khuu))", "ഖൂ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\guu))", "ഗൂ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ghuu))", "ഘൂ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\nguu))", "ങൂ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\chuu))", "ചൂ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\chhuu))", "ഛൂ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\juu))", "ജൂ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\jhuu))", "ഝൂ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\gnuu))", "ഞൂ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ttuu))", "ടൂ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\tthuu))", "ഠൂ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dduu))", "ഡൂ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ddhuu))", "ഢൂ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Nuu))", "ണൂ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\thuu))", "തൂ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\thhuu))", "ഥൂ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dhuu))", "ദൂ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dhhuu))", "ധൂ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\nuu))", "നൂ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\puu))", "പൂ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\phuu))", "ഫൂ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\buu))", "ബൂ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\bhuu))", "ഭൂ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\muu))", "മൂ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\yuu))", "യൂ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ruu))", "രൂ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\luu))", "ലൂ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\vuu))", "വൂ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\shuu))", "ശൂ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\sshuu))", "ഷൂ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\suu))", "സൂ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\huu))", "ഹൂ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Luu))", "ളൂ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\zhuu))", "ഴൂ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Ruu))", "റൂ"); 
        ///// Group 07
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ke))", "കെ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\khe))", "ഖെ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ge))", "ഗെ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ghe))", "ഘെ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\nge))", "ങെ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\che))", "ചെ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\chhe))", "ഛെ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\je))", "ജെ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\jhe))", "ഝെ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\gne))", "ഞെ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\te))", "ടെ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\tte))", "ഠെ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\de))", "ഡെ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dhe))", "ഢെ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Ne))", "ണെ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\the))", "തെ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\thhe))", "ഥെ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dhe2))", "ദെ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dhhe))", "ധെ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ne))", "നെ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\pe))", "പെ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\phe))", "ഫെ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\be))", "ബെ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\bhe))", "ഭെ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\me))", "മെ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ye))", "യെ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\re))", "രെ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\le))", "ലെ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ve))", "വെ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\she))", "ശെ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\sshe))", "ഷെ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\se))", "സെ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\he))", "ഹെ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Le))", "ളെ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\zhe))", "ഴെ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Re))", "റെ");
        ///// Group 08
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\kea))", "കേ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\khea))", "ഖേ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\gea))", "ഗേ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ghea))", "ഘേ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ngea))", "ങേ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\chea))", "ചേ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\chhea))", "ഛേ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\jea))", "ജേ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\jhea))", "ഝേ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\gnea))", "ഞേ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\tea))", "ടേ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ttea))", "ഠേ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dea))", "ഡേ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dhea))", "ഢേ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Nea))", "ണേ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\thea))", "തേ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\thhea))", "ഥേ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dhea2))", "ദേ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dhhea))", "ധേ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\nea))", "നേ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\pea))", "പേ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\phea))", "ഫേ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\bea))", "ബേ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\bhea))", "ഭേ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\mea))", "മേ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\yea))", "യേ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\rea))", "രേ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\lea))", "ലേ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\vea))", "വേ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\shea))", "ശേ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\sshea))", "ഷേ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\sea))", "സേ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\hea))", "ഹേ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Lea))", "ളേ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\zhea))", "ഴേ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Rea))", "റേ");
        ////// Group 09
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\kai))", "കൈ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\khai))", "ഖൈ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\gai))", "ഗൈ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ghai))", "ഘൈ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ngai))", "ങൈ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\chai))", "ചൈ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\chhai))", "ഛൈ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\jai))", "ജൈ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\jhai))", "ഝൈ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\gnai))", "ഞൈ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\tai))", "ടൈ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ttai))", "ഠൈ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dai))", "ഡൈ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dhai))", "ഢൈ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Nai))", "ണൈ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\thai))", "തൈ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\thhai))", "ഥൈ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dhai2))", "ദൈ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dhhai))", "ധൈ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\nai))", "നൈ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\pai))", "പൈ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\phai))", "ഫൈ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\bai))", "ബൈ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\bhai))", "ഭൈ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\mai))", "മൈ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\yai))", "യൈ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\rai))", "രൈ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\lai))", "ലൈ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\vai))", "വൈ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\shai))", "ശൈ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\sshai))", "ഷൈ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\sai))", "സൈ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\hai))", "ഹൈ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Lai))", "ളൈ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\zhai))", "ഴൈ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Rai))", "റൈ");
        ////// Group 10 
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ko))", "കൊ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\kho))", "ഖൊ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\go))", "ഗൊ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\gho))", "ഘൊ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ngo))", "ങൊ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\cho))", "ചൊ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\chho))", "ഛൊ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\jo))", "ജൊ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\jho))", "ഝൊ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\gno))", "ഞൊ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\to))", "ടൊ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\tto))", "ഠൊ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\do))", "ഡൊ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dho))", "ഢൊ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\No))", "ണൊ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\tho))", "തൊ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\thho))", "ഥൊ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dho2))", "ദൊ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dhho))", "ധൊ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\no))", "നൊ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\po))", "പൊ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\pho))", "ഫൊ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\bo))", "ബൊ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\bho))", "ഭൊ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\mo))", "മൊ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\yo))", "യൊ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ro))", "രൊ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\lo))", "ലൊ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\vo))", "വൊ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\sho))", "ശൊ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ssho))", "ഷൊ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\so))", "സൊ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ho))", "ഹൊ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Lo))", "ളൊ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\zho))", "ഴൊ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Ro))", "റൊ");
        ////// Group 11 
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\koa))", "കോ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\khoa))", "ഖോ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\goa))", "ഗോ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ghoa))", "ഘോ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ngoa))", "ങോ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\choa))", "ചോ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\chhoa))", "ഛോ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\joa))", "ജോ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\jhoa))", "ഝോ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\gnoa))", "ഞോ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\toa))", "ടോ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ttoa))", "ഠോ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\doa))", "ഡോ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dhoa))", "ഢോ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Noa))", "ണോ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\thoa))", "തോ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\thhoa))", "ഥോ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dhoa2))", "ദോ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dhhoa))", "ധോ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\noa))", "നോ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\poa))", "പോ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\phoa))", "ഫോ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\boa))", "ബോ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\bhoa))", "ഭോ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\moa))", "മോ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\yoa))", "യോ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\roa))", "രോ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\loa))", "ലോ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\voa))", "വോ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\shoa))", "ശോ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\sshoa))", "ഷോ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\soa))", "സോ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\hoa))", "ഹോ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Loa))", "ളോ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\zhoa))", "ഴോ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Roa))", "റോ");
        ////// Group 12
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\kau))", "കൗ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\khau))", "ഖൗ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\gau))", "ഗൗ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ghau))", "ഘൗ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ngau))", "ങൗ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\chau))", "ചൗ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\chhau))", "ഛൗ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\jau))", "ജൗ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\jhau))", "ഝൗ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\gnau))", "ഞൗ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\tau))", "ടൗ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\ttau))", "ഠൗ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dau))", "ഡൗ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dhau))", "ഢൗ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Nau))", "ണൗ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\thau))", "തൗ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\thhau))", "ഥൗ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dhau2))", "ദൗ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\dhhau))", "ധൗ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\nau))", "നൗ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\pau))", "പൗ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\phau))", "ഫൗ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\bau))", "ബൗ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\bhau))", "ഭൗ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\mau))", "മൗ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\yau))", "യൗ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\rau))", "രൗ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\lau))", "ലൗ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\vau))", "വൗ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\shau))", "ശൗ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\sshau))", "ഷൗ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\sau))", "സൗ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\hau))", "ഹൗ");

        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Lau))", "ളൗ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\zhau))", "ഴൗ");
        MALAYALAM_CONSONANT_MAP.put("\\var(\\malayalam(\\Rau))", "റൗ");
    }
}
