package language.replace;

import java.util.HashMap;
import java.util.Map;

public class Tamil {
    // ---- Tamil symbol maps ----
    public static final Map<String, String> TAMIL_VOWEL_MAP = new HashMap<>();
    public static final Map<String, String> TAMIL_CONSONANT_MAP = new HashMap<>();

    // ---- symbol initialization ----
    static {
        // Tamil vowels (Uyir Ezhuthukkal – 12)
        TAMIL_VOWEL_MAP.put("\\var(\\tamil(\\a))", "அ");
        TAMIL_VOWEL_MAP.put("\\var(\\tamil(\\aa))", "ஆ");
        TAMIL_VOWEL_MAP.put("\\var(\\tamil(\\e))", "இ");
        TAMIL_VOWEL_MAP.put("\\var(\\tamil(\\ee))", "ஈ");
        TAMIL_VOWEL_MAP.put("\\var(\\tamil(\\u))", "உ");
        TAMIL_VOWEL_MAP.put("\\var(\\tamil(\\uu))", "ஊ");
        TAMIL_VOWEL_MAP.put("\\var(\\tamil(\\ea))", "எ");
        TAMIL_VOWEL_MAP.put("\\var(\\tamil(\\eaa))", "ஏ");
        TAMIL_VOWEL_MAP.put("\\var(\\tamil(\\i))", "ஐ");
        TAMIL_VOWEL_MAP.put("\\var(\\tamil(\\o))", "ஒ");
        TAMIL_VOWEL_MAP.put("\\var(\\tamil(\\oo))", "ஓ");
        TAMIL_VOWEL_MAP.put("\\var(\\tamil(\\au))", "ஔ");
        TAMIL_VOWEL_MAP.put("\\var(\\tamil(\\akg))", "ஃ");
        
        // ---- Tamil consonants (sample – extend freely) ----
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ik))", "க்");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ing))", "ங்");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ich))", "ச்");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ina))", "ஞ்");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\id))", "ட்");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\iN))", "ண்");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ith))", "த்");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\iNn))", "ந்");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ip))", "ப்");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\im))", "ம்");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\iy))", "ய்");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ir))", "ர்");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\il))", "ல்");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\iv))", "வ்");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\izh))", "ழ்");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\iL))", "ள்");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\iR))", "ற்");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\in))", "ன்");

        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ka))", "க");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\nga))", "ங");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\cha))", "ச");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\gna))", "ஞ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\da))", "ட");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Na))", "ண");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\tha))", "த");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Nha))", "ந");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\pa))", "ப");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ma))", "ம");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ya))", "ய");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ra))", "ர");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\la))", "ல");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\va))", "வ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\zha))", "ழ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\La))", "ள");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Ra))", "ற");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\na))", "ன");


        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\kaa))", "கா");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ngaa))", "ஙா");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\chaa))", "சா");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\gnaa))", "ஞா");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\daa))", "டா");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Naa))", "ணா");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\thaa))", "தா");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Nhaa))", "நா");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\paa))", "பா");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\maa))", "மா");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\yaa))", "யா");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\raa))", "ரா");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\laa))", "லா");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\vaa))", "வா");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\zhaa))", "ழா");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Laa))", "ளா");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Raa))", "றா");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\naa))", "னா");

        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ki))", "கி");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ngi))", "ஙி");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\chi))", "சி");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\gni))", "ஞி");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\di))", "டி");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Ni))", "ணி");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\thi))", "தி");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Nhi))", "நி");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\pi))", "பி");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\mi))", "மி");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\yi))", "யி");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ri))", "ரி");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\li))", "லி");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\vi))", "வி");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\zhi))", "ழி");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Li))", "ளி");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Ri))", "றி");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ni))", "னி");

        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\kii))", "கீ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ngii))", "ஙீ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\chii))", "சீ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\gnii))", "ஞீ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\dii))", "டீ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Nii))", "ணீ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\thii))", "தீ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Nhii))", "நீ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\pii))", "பீ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\mii))", "மீ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\yii))", "யீ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\rii))", "ரீ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\lii))", "லீ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\vii))", "வீ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\zhii))", "ழீ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Lii))", "ளீ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Rii))", "றீ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\nii))", "னீ");

        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ku))", "கு");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ngu))", "ஙு");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\chu))", "சு");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\gnu))", "ஞு");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\du))", "டு");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Nu))", "ணு");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\thu))", "து");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Nhu))", "நு");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\pu))", "பு");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\mu))", "மு");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\yu))", "யு");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ru))", "ரு");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\lu))", "லு");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\vu))", "வு");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\zhu))", "ழு");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Lu))", "ளு");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Ru))", "று");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\nu))", "னு");

        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\kuu))", "கூ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\nguu))", "ஙூ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\chuu))", "சூ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\gnuu))", "ஞூ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\duu))", "டூ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Nuu))", "ணூ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\thuu))", "தூ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Nhuu))", "நூ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\puu))", "பூ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\muu))", "மூ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\yuu))", "யூ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ruu))", "ரூ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\luu))", "லூ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\vuu))", "வூ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\zhuu))", "ழூ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Luu))", "ளூ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Ruu))", "றூ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\nuu))", "னூ");

        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ke))", "கெ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\nge))", "ஙெ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\che))", "செ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\gne))", "ஞெ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\de))", "டெ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Ne))", "ணெ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\the))", "தெ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Nhe))", "நெ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\pe))", "பெ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\me))", "மெ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ye))", "யெ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\re))", "ரெ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\le))", "லெ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ve))", "வெ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\zhe))", "ழெ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Le))", "ளெ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Re))", "றெ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ne))", "னெ");

        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\kea))", "கே");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ngea))", "ஙே");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\chea))", "சே");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\gnea))", "ஞே");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\dea))", "டே");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Nea))", "ணே");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\thea))", "தே");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Nhea))", "நே");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\pea))", "பே");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\mea))", "மே");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\yea))", "யே");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\rea))", "ரே");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\lea))", "லே");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\vea))", "வே");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\zhea))", "ழே");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Lea))", "ளே");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Rea))", "றே");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\nea))", "னே");

        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\kai))", "கை");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ngai))", "ஙை");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\chai))", "சை");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\gnai))", "ஞை");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\dai))", "டை");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Nai))", "ணை");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\thai))", "தை");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Nhai))", "நை");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\pai))", "பை");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\mai))", "மை");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\yai))", "யை");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\rai))", "ரை");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\lai))", "லை");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\vai))", "வை");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\zhai))", "ழை");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Lai))", "ளை");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Rai))", "றை");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\nai))", "னை");

        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ko))", "கொ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ngo))", "ஙொ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\cho))", "சொ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\gno))", "ஞொ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\do))", "டொ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\No))", "ணொ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\tho))", "தொ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Nho))", "நொ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\po))", "பொ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\mo))", "மொ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\yo))", "யொ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ro))", "ரொ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\lo))", "லொ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\vo))", "வொ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\zho))", "ழொ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Lo))", "ளொ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Ro))", "றொ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\no))", "னொ");

        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\koa))", "கோ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ngoa))", "ஙோ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\choa))", "சோ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\gnoa))", "ஞோ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\doa))", "டோ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Noa))", "ணோ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\thoa))", "தோ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Nhoa))", "நோ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\poa))", "போ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\moa))", "மோ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\yoa))", "யோ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\roa))", "ரோ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\loa))", "லோ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\voa))", "வோ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\zhoa))", "ழோ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Loa))", "ளோ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Roa))", "றோ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\noa))", "னொ");

        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\kau))", "கௌ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\ngau))", "ஙௌ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\chau))", "சௌ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\gnau))", "ஞௌ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\dau))", "டௌ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Nau))", "ணௌ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\thau))", "தௌ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Nhau))", "நௌ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\pau))", "பௌ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\mau))", "மௌ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\yau))", "யௌ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\rau))", "ரௌ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\lau))", "லௌ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\vau))", "வௌ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\zhan))", "ழௌ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Lau))", "ளௌ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\Rau))", "றௌ");
        TAMIL_CONSONANT_MAP.put("\\var(\\tamil(\\nau))", "னௌ");
    }

    
}
