package language.replace;

import java.util.HashMap;
import java.util.Map;

public class Uniconstant{

    // ---- symbol map ----
    public static final Map<String, String> SYMBOL_MAP = new HashMap<>();

    // ---- helper methods ----
    private static void put(String token) {
        // Preferred command shape: \\con(\\token)
        // Inserts the name nc.exe knows (constants_builtin.cpp): uc_token.
        SYMBOL_MAP.put("\\con(\\" + token + ")", "uc_" + token);
    }

    // ---- symbol initialization ----
    static {
        put("pi");
        put("gravity");
        put("gasconst");
        put("avogadro");
        put("planck");                 // Planck constant h
        put("hbar");                   // reduced Planck constant
        put("gravitational");
        put("stefanboltzmann");
        put("coulomb");
        put("electronmass");
        put("protonmass");
        put("neutronmass");
        put("molarmass");
        put("elementarycharge");
        put("faraday");
        put("speedoflight");           // speed of light
        put("boltzmann");              // Boltzmann constant
        put("vacuumpermittivity");     // ε₀
        put("vacuumpermeability");     // μ₀
        put("finestructure");          // α
        put("rydberg");                // R∞
        put("bohrradius");             // a₀
        put("hartreeenergy");          // Eₕ
        put("magneticfluxquantum");    // Φ₀
    }
}
