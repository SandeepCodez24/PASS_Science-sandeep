package language.replace;

import java.util.HashMap;
import java.util.Map;

public class Uniconstant{

    // ---- symbol map ----
    public static final Map<String, String> SYMBOL_MAP = new HashMap<>();

    // ---- helper methods ----
    private static void put(String token, String symbol) {
        // Preferred command shape: \\con(\\token)
        SYMBOL_MAP.put("\\con(\\" + token + ")", symbol);
    }

    // ---- symbol initialization ----
    static {
        put("pi", "𝝅");                // bold italic pi
        put("gravity", "𝒈");
        put("gasconst", "𝑹");
        put("avagadro", "𝑵ₐ");
        put("planck", "ℏ");            // already unique
        put("gravitational", "𝑮");
        put("stefanboltzmann", "𝝈");
        put("coulomb", "𝒌ₑ");
        put("electronmass", "𝒎ₑ");
        put("protonmass", "𝒎ₚ");
        put("neutronmass", "𝒎ₙ");
        put("molarmass", "𝑴");
        put("elementarycharge", "𝒆");
        put("faraday", "𝑭");
        put("speedoflight", "𝒄");          // speed of light
        put("boltzmann", "𝒌");             // Boltzmann constant
        put("vacuumpermittivity", "𝜺₀");   // ε₀
        put("vacuumpermeability", "𝝁₀");   // μ₀
        put("finestructure", "𝜶");         // α
        put("rydberg", "𝑹∞");              // R∞
        put("faraday", "𝑭");               // F
        put("bohrradius", "𝒂₀");          // a₀
        put("hartreeenergy", "𝑬ₕ");       // Eₕ
        put("magneticfluxquantum", "𝝓₀");  // Φ₀
    }
}