package language.replace;

import java.util.HashMap;
import java.util.Map;

public class Greek {
   // ---- symbol map ----
   public static final Map<String, String> SYMBOL_MAP = new HashMap<>();

   // ---- constructors ----
   public Greek() {
   }

   // ---- symbol initialization ----
   static {
      SYMBOL_MAP.put("\\var(\\alpha)", "α");
      SYMBOL_MAP.put("\\var(\\beta)", "β");
      SYMBOL_MAP.put("\\var(\\gamma)", "γ");
      SYMBOL_MAP.put("\\var(\\delta)", "δ");
      SYMBOL_MAP.put("\\var(\\epsilon)", "ε");
      SYMBOL_MAP.put("\\var(\\zeta)", "ζ");
      SYMBOL_MAP.put("\\var(\\eta)", "η");
      SYMBOL_MAP.put("\\var(\\theta)", "θ");
      SYMBOL_MAP.put("\\var(\\iota)", "ι");
      SYMBOL_MAP.put("\\var(\\kappa)", "κ");
      SYMBOL_MAP.put("\\var(\\lambda)", "λ");
      SYMBOL_MAP.put("\\var(\\mu)", "μ");
      SYMBOL_MAP.put("\\var(\\nu)", "ν");
      SYMBOL_MAP.put("\\var(\\xi)", "ξ");
      SYMBOL_MAP.put("\\var(\\omicron)", "ο");
      SYMBOL_MAP.put("\\var(\\pi)", "π");
      SYMBOL_MAP.put("\\var(\\rho)", "ρ");
      SYMBOL_MAP.put("\\var(\\sigma)", "σ");
      SYMBOL_MAP.put("\\var(\\tau)", "τ");
      SYMBOL_MAP.put("\\var(\\upsilon)", "υ");
      SYMBOL_MAP.put("\\var(\\phi)", "φ");
      SYMBOL_MAP.put("\\var(\\chi)", "χ");
      SYMBOL_MAP.put("\\var(\\psi)", "ψ");
      SYMBOL_MAP.put("\\var(\\omega)", "ω");
   }
}
