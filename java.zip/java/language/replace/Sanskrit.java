package language.replace;

import java.util.HashMap;
import java.util.Map;

public class Sanskrit {

    // ---- symbol map ----
    public static final Map<String, String> SYMBOL_MAP = new HashMap<>();

    // ---- helper methods ----
    private static void put(String token, String symbol) {
        // Preferred Tamil-style command shape: \var(\sanskrit(\\token))
        SYMBOL_MAP.put("\\var(\\sanskrit(\\" + token + "))", symbol);
        // Backward-compatible legacy command: \var(\sanskrit(token))
        SYMBOL_MAP.put("\\var(\\sanskrit(" + token + "))", symbol);
    }

    // ---- symbol initialization ----
    static {

        // ===== VOWELS (स्वर) =====
        put("a", "अ");
        put("aa", "आ");
        put("i", "इ");
        put("ii", "ई");
        put("u", "उ");
        put("uu", "ऊ");
        put("r", "ऋ");
        put("rr", "ॠ");
        put("l", "ऌ");
        put("ll", "ॡ");
        put("e", "ए");
        put("ai", "ऐ");
        put("o", "ओ");
        put("au", "औ");

        // ===== CONSONANTS (व्यंजन) =====
        put("ka", "क");
        put("kha", "ख");
        put("ga", "ग");
        put("gha", "घ");
        put("nga", "ङ");

        put("cha", "च");
        put("chha", "छ");
        put("ja", "ज");
        put("jha", "झ");
        put("nya", "ञ");

        put("tta", "ट");
        put("ttha", "ठ");
        put("dda", "ड");
        put("ddha", "ढ");
        put("nna", "ण");

        put("ta", "त");
        put("tha", "थ");
        put("da", "द");
        put("dha", "ध");
        put("na", "न");

        put("pa", "प");
        put("pha", "फ");
        put("ba", "ब");
        put("bha", "भ");
        put("ma", "म");

        put("ya", "य");
        put("ra", "र");
        put("la", "ल");
        put("va", "व");

        put("sha", "श");
        put("ssha", "ष");
        put("sa", "स");
        put("ha", "ह");

        // ===== COMPOUND LETTERS (संयुक्ताक्षर) =====
        put("ksha", "क्ष");
        put("tra", "त्र");
        put("gya", "ज्ञ");

        // ===== SPECIAL SYMBOLS =====
        put("om", "ॐ");
    }
}

        // put("am", "ं");
        // put("ah", "ः");