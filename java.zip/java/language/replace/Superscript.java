package language.replace;

import java.util.HashMap;
import java.util.Map;

public class Superscript {

    private static final Map<Character, String> SUPERSCRIPT_MAP = new HashMap<>();

    static {
        // Digits ONLY (like subscript)
        SUPERSCRIPT_MAP.put('0', "⁰");
        SUPERSCRIPT_MAP.put('1', "¹");
        SUPERSCRIPT_MAP.put('2', "²");
        SUPERSCRIPT_MAP.put('3', "³");
        SUPERSCRIPT_MAP.put('4', "⁴");
        SUPERSCRIPT_MAP.put('5', "⁵");
        SUPERSCRIPT_MAP.put('6', "⁶");
        SUPERSCRIPT_MAP.put('7', "⁷");
        SUPERSCRIPT_MAP.put('8', "⁸");
        SUPERSCRIPT_MAP.put('9', "⁹");
    }

    // ---- helpers ----

    public static boolean hasUnicode(char ch) {
        return SUPERSCRIPT_MAP.containsKey(ch);
    }

    public static String unicode(char ch) {
        return SUPERSCRIPT_MAP.get(ch);
    }

    // Single-character CSS superscript helper
    public static String styledSuperscript(char ch) {
        // Use single markers like subscript for consistency with regex patterns
        return "\u200C" + ch + "\u200C";
    }

    // Multi-character superscript helper (for ^{...})
    public static String styledSuperscriptText(String text) {
        StringBuilder sb = new StringBuilder();
        sb.append("\u200C\u200C\u200C"); // Multi-letter group marker start

        for (char ch : text.toCharArray()) {
            if (SUPERSCRIPT_MAP.containsKey(ch)) {
                sb.append(SUPERSCRIPT_MAP.get(ch));
            } else {
                sb.append(ch);
            }
        }
        sb.append("\u200C\u200C\u200C"); // Multi-letter group marker end
        return sb.toString();
    }
}
