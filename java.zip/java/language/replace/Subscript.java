package language.replace;

import java.util.HashMap;
import java.util.Map;

public class Subscript {

    private static final Map<Character, String> SUBSCRIPT_MAP = new HashMap<>();

    static {
        // Digits ONLY
        SUBSCRIPT_MAP.put('0', "₀");
        SUBSCRIPT_MAP.put('1', "₁");
        SUBSCRIPT_MAP.put('2', "₂");
        SUBSCRIPT_MAP.put('3', "₃");
        SUBSCRIPT_MAP.put('4', "₄");
        SUBSCRIPT_MAP.put('5', "₅");
        SUBSCRIPT_MAP.put('6', "₆");
        SUBSCRIPT_MAP.put('7', "₇");
        SUBSCRIPT_MAP.put('8', "₈");
        SUBSCRIPT_MAP.put('9', "₉");
    }

    // ---- single character helpers ----

    public static boolean hasNumericSubscript(char ch) {
        return SUBSCRIPT_MAP.containsKey(ch);
    }

    public static String numericSubscript(char ch) {
        return SUBSCRIPT_MAP.get(ch);
    }

    public static String styledSubscript(char ch) {
        // Single letter → CSS-based subscript with single marker
        // Use ZERO WIDTH JOINER so the subscript joins visually with the base character
        return "\u200D" + ch + "\u200D";
    }

    // ---- multi-character helper (for _{...}) ----

    public static String styledSubscriptText(String text) {
        StringBuilder sb = new StringBuilder();
        sb.append("\u200D\u200D\u200D");  // Multi-letter group marker start

        for (char ch : text.toCharArray()) {
            if (SUBSCRIPT_MAP.containsKey(ch)) {
                // digits → Unicode subscripts
                sb.append(SUBSCRIPT_MAP.get(ch));
            } else {
                // everything else → CSS-based
                sb.append(ch);
            }
        }
        sb.append("\u200D\u200D\u200D");  // Multi-letter group marker end
        return sb.toString();
    }
}
