package language.language_ui.handler;

import org.fxmisc.richtext.CodeArea;
import language.replace.Subscript;

final class SubscriptModeHandler {
    private static final String SUBSCRIPT_MODE_KEY = "subscriptMode";
    private static final String SUBSCRIPT_MODE_START_KEY = "subscriptModeStart";
    private static final String SUBSCRIPT_MODE_MARKER_START_KEY = "subscriptModeMarkerStart";
    private static final String SUBSCRIPT_MODE_STARTED_KEY = "subscriptModeStarted";
    private static final String SUBSCRIPT_MODE_RAW_KEY = "subscriptModeRaw";
    private static final String SUBSCRIPT_MODE_RENDERED_LEN_KEY = "subscriptModeRenderedLen";

    private SubscriptModeHandler() {
    }

    static boolean isSubscriptMode(CodeArea editor) {
        return Boolean.TRUE.equals(editor.getProperties().get(SUBSCRIPT_MODE_KEY));
    }

    static void enterSubscriptMode(CodeArea editor, int caret, int markerStart) {
        editor.getProperties().put(SUBSCRIPT_MODE_KEY, Boolean.TRUE);
        editor.getProperties().put(SUBSCRIPT_MODE_START_KEY, markerStart);
        editor.getProperties().put(SUBSCRIPT_MODE_MARKER_START_KEY, markerStart);
        editor.getProperties().put(SUBSCRIPT_MODE_STARTED_KEY, Boolean.FALSE);
        editor.getProperties().put(SUBSCRIPT_MODE_RAW_KEY, "");
        editor.getProperties().put(SUBSCRIPT_MODE_RENDERED_LEN_KEY, 2);
    }

    static void exitSubscriptMode(CodeArea editor) {
        editor.getProperties().put(SUBSCRIPT_MODE_KEY, Boolean.FALSE);
        editor.getProperties().remove(SUBSCRIPT_MODE_START_KEY);
        editor.getProperties().remove(SUBSCRIPT_MODE_MARKER_START_KEY);
        editor.getProperties().remove(SUBSCRIPT_MODE_STARTED_KEY);
        editor.getProperties().remove(SUBSCRIPT_MODE_RAW_KEY);
        editor.getProperties().remove(SUBSCRIPT_MODE_RENDERED_LEN_KEY);
    }

    static void handleSubscriptModeBackspace(CodeArea editor) {
        String raw = (String) editor.getProperties().get(SUBSCRIPT_MODE_RAW_KEY);
        Integer modeStart = (Integer) editor.getProperties().get(SUBSCRIPT_MODE_START_KEY);
        Integer renderedLen = (Integer) editor.getProperties().get(SUBSCRIPT_MODE_RENDERED_LEN_KEY);
        if (raw != null && !raw.isEmpty() && modeStart != null) {
            int editorLength = editor.getLength();
            if (modeStart < 0 || modeStart > editorLength) {
                exitSubscriptMode(editor);
                return;
            }
            String updatedRaw = raw.substring(0, raw.length() - 1);
            editor.getProperties().put(SUBSCRIPT_MODE_RAW_KEY, updatedRaw);
            String rebuilt = updatedRaw.isEmpty()
                    ? ""
                    : Subscript.styledSubscriptText(SymbolReplacer.replaceSymbols(updatedRaw));
            int expectedEnd = modeStart + (renderedLen != null ? renderedLen : 0);
            int replaceEnd = Math.min(editorLength, Math.max(modeStart, expectedEnd));
            EditorTextUtils.replace(editor, modeStart, replaceEnd, rebuilt);
            editor.getProperties().put(SUBSCRIPT_MODE_RENDERED_LEN_KEY, rebuilt.length());
            if (updatedRaw.isEmpty()) {
                exitSubscriptMode(editor);
            }
        }
    }

    static void handleSubscriptModeInput(CodeArea editor, int caret, String lineText, int modeStart, int lineStart) {
        if (lineText.isEmpty()) {
            return;
        }
        Integer markerStart = (Integer) editor.getProperties().get(SUBSCRIPT_MODE_MARKER_START_KEY);
        Boolean started = (Boolean) editor.getProperties().get(SUBSCRIPT_MODE_STARTED_KEY);
        String raw = (String) editor.getProperties().get(SUBSCRIPT_MODE_RAW_KEY);
        if (started == null) {
            started = Boolean.FALSE;
            editor.getProperties().put(SUBSCRIPT_MODE_STARTED_KEY, Boolean.FALSE);
        }
        if (raw == null) {
            raw = "";
            editor.getProperties().put(SUBSCRIPT_MODE_RAW_KEY, raw);
        }

        // -----------------------------------------------------------------
        // FAST-TYPING FIX (dropped alternate letters, e.g. "actions" -> "cins")
        //
        // The old code appended ONLY the last character of the line and then
        // replaced the whole [modeStart, caret] region with the re-rendered
        // group. This runs on KEY_RELEASED. When several key presses are
        // coalesced by JavaFX before the KEY_RELEASED handlers run, the
        // document already holds every typed character, but only the last one
        // was captured -- and the region replace then wiped the intermediate
        // plain characters -> every other letter vanished.
        //
        // Fix: read the ENTIRE run of freshly typed plain characters sitting
        // between the already-committed group and the live caret, and process
        // ALL of them in order. This is correct at any typing speed because it
        // is driven by the actual document content, not by a single key event.
        // -----------------------------------------------------------------
        String fullText = editor.getText();
        if (fullText == null) {
            return;
        }
        int liveCaret = editor.getCaretPosition();
        if (liveCaret < caret) {
            liveCaret = caret;
        }
        if (liveCaret > fullText.length()) {
            liveCaret = fullText.length();
        }

        // Length of the already-committed portion inside the group:
        //  - not started yet -> the two literal "__" marker characters
        //  - started         -> the styled render of the current raw
        int committedLen = Boolean.TRUE.equals(started)
                ? Subscript.styledSubscriptText(raw).length()
                : 2;
        int contentEnd = modeStart + committedLen;
        if (contentEnd < 0 || contentEnd > liveCaret) {
            return;
        }

        String pending = fullText.substring(contentEnd, liveCaret);
        if (pending.isEmpty()) {
            return;
        }

        StringBuilder rawBuilder = new StringBuilder(raw);
        for (int idx = 0; idx < pending.length(); idx++) {
            char ch = pending.charAt(idx);
            if (ch == ' ' || EditorTextUtils.isModeExitOperator(ch)) {
                exitSubscriptOnBoundary(editor, modeStart, liveCaret,
                        rawBuilder.toString(), ch, pending.substring(idx + 1));
                return;
            }
            if (ch == '\u200D' || ch == '\u200C' || ch == '{' || ch == '}') {
                continue;
            }
            rawBuilder.append(ch);
        }

        String newRaw = SymbolReplacer.replaceSymbols(rawBuilder.toString());
        editor.getProperties().put(SUBSCRIPT_MODE_RAW_KEY, newRaw);
        String styledSubscript = Subscript.styledSubscriptText(newRaw);
        EditorTextUtils.replace(editor, modeStart, liveCaret, styledSubscript);
        editor.getProperties().put(SUBSCRIPT_MODE_STARTED_KEY, Boolean.TRUE);
        editor.getProperties().remove(SUBSCRIPT_MODE_MARKER_START_KEY);
        editor.getProperties().put(SUBSCRIPT_MODE_RENDERED_LEN_KEY, styledSubscript.length());
    }

    // Commits whatever has been typed so far and leaves subscript mode when a
    // space or an operator terminates the group. A space is consumed; an
    // operator is kept (it belongs to the surrounding expression). Any text the
    // user managed to type AFTER the boundary (possible under fast typing) is
    // preserved as ordinary text.
    private static void exitSubscriptOnBoundary(CodeArea editor, int modeStart, int endRegion,
            String rawSoFar, char boundaryCh, String afterBoundary) {
        String newRaw = SymbolReplacer.replaceSymbols(rawSoFar);
        String styled = newRaw.isEmpty() ? "" : Subscript.styledSubscriptText(newRaw);
        String trailing = (boundaryCh == ' ') ? afterBoundary : (boundaryCh + afterBoundary);

        int editorLength = editor.getLength();
        int start = Math.max(0, Math.min(modeStart, editorLength));
        int end = Math.max(start, Math.min(endRegion, editorLength));
        editor.replaceText(start, end, styled + trailing);
        editor.moveTo(Math.min(editor.getLength(), start + styled.length() + trailing.length()));
        editor.requestFollowCaret();
        exitSubscriptMode(editor);
    }
}
