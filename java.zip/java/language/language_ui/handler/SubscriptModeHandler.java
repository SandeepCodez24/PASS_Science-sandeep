package language.language_ui.handler;

import org.fxmisc.richtext.CodeArea;
import language.replace.Subscript;

final class SubscriptModeHandler {

    private static final String SUBSCRIPT_MODE_KEY = "subscriptMode";
    private static final String SUBSCRIPT_MODE_START_KEY = "subscriptModeStart";
    private static final String SUBSCRIPT_MODE_MARKER_START_KEY = "subscriptModeMarkerStart";
    private static final String SUBSCRIPT_MODE_STARTED_KEY = "subscriptModeStarted";
    private static final String SUBSCRIPT_MODE_RAW_KEY = "subscriptModeRaw";
    private static final String SUBSCRIPT_MODE_RENDERED_LEN_KEY = "subscriptModeRenderedLen";

    private SubscriptModeHandler() {
    }

    static boolean isSubscriptMode(CodeArea editor) {
        return Boolean.TRUE.equals(editor.getProperties().get(SUBSCRIPT_MODE_KEY));
    }

    static void enterSubscriptMode(CodeArea editor, int caret, int markerStart) {
        editor.getProperties().put(SUBSCRIPT_MODE_KEY, Boolean.TRUE);
        editor.getProperties().put(SUBSCRIPT_MODE_START_KEY, markerStart);
        editor.getProperties().put(SUBSCRIPT_MODE_MARKER_START_KEY, markerStart);
        editor.getProperties().put(SUBSCRIPT_MODE_STARTED_KEY, Boolean.FALSE);
        editor.getProperties().put(SUBSCRIPT_MODE_RAW_KEY, "");
        editor.getProperties().put(SUBSCRIPT_MODE_RENDERED_LEN_KEY, 2);
    }

    static void exitSubscriptMode(CodeArea editor) {
        editor.getProperties().put(SUBSCRIPT_MODE_KEY, Boolean.FALSE);
        editor.getProperties().remove(SUBSCRIPT_MODE_START_KEY);
        editor.getProperties().remove(SUBSCRIPT_MODE_MARKER_START_KEY);
        editor.getProperties().remove(SUBSCRIPT_MODE_STARTED_KEY);
        editor.getProperties().remove(SUBSCRIPT_MODE_RAW_KEY);
        editor.getProperties().remove(SUBSCRIPT_MODE_RENDERED_LEN_KEY);
    }

    static void handleSubscriptModeBackspace(CodeArea editor) {
        String raw = (String) editor.getProperties().get(SUBSCRIPT_MODE_RAW_KEY);
        Integer modeStart = (Integer) editor.getProperties().get(SUBSCRIPT_MODE_START_KEY);
        Integer renderedLen = (Integer) editor.getProperties().get(SUBSCRIPT_MODE_RENDERED_LEN_KEY);

        if (raw != null && !raw.isEmpty() && modeStart != null) {
            int editorLength = editor.getLength();
            if (modeStart < 0 || modeStart > editorLength) {
                exitSubscriptMode(editor);
                return;
            }

            String updatedRaw = raw.substring(0, raw.length() - 1);
            editor.getProperties().put(SUBSCRIPT_MODE_RAW_KEY, updatedRaw);

            String rebuilt = updatedRaw.isEmpty()
                    ? ""
                    : Subscript.styledSubscriptText(SymbolReplacer.replaceSymbols(updatedRaw));

            int expectedEnd = modeStart + (renderedLen != null ? renderedLen : 0);
            int replaceEnd = Math.min(editorLength, Math.max(modeStart, expectedEnd));
            EditorTextUtils.replace(editor, modeStart, replaceEnd, rebuilt);
            editor.getProperties().put(SUBSCRIPT_MODE_RENDERED_LEN_KEY, rebuilt.length());

            if (updatedRaw.isEmpty()) {
                exitSubscriptMode(editor);
            }
        }
    }

    static void handleSubscriptModeInput(CodeArea editor, int caret, String lineText, int modeStart, int lineStart) {
        if (lineText.isEmpty()) {
            return;
        }

        Integer markerStart = (Integer) editor.getProperties().get(SUBSCRIPT_MODE_MARKER_START_KEY);
        Boolean started = (Boolean) editor.getProperties().get(SUBSCRIPT_MODE_STARTED_KEY);
        String raw = (String) editor.getProperties().get(SUBSCRIPT_MODE_RAW_KEY);

        if (started == null) {
            started = Boolean.FALSE;
            editor.getProperties().put(SUBSCRIPT_MODE_STARTED_KEY, Boolean.FALSE);
        }
        if (raw == null) {
            raw = "";
            editor.getProperties().put(SUBSCRIPT_MODE_RAW_KEY, raw);
        }

        int typedCharIndex = caret - 1;
        if (typedCharIndex < modeStart) {
            return;
        }

        char ch = lineText.charAt(lineText.length() - 1);

        if (ch == ' ' || EditorTextUtils.isModeExitOperator(ch)) {
            int liveCaret = editor.getCaretPosition();
            if (!started && markerStart != null && markerStart >= 0 && markerStart + 2 <= editor.getLength()) {
                editor.replaceText(markerStart, markerStart + 2, "");
                liveCaret = Math.max(markerStart, liveCaret - 2);
            }
            if (ch == ' ' && liveCaret > 0) {
                editor.replaceText(liveCaret - 1, liveCaret, "");
                liveCaret = liveCaret - 1;
            }
            editor.moveTo(Math.max(0, Math.min(editor.getLength(), liveCaret)));
            editor.requestFollowCaret();
            exitSubscriptMode(editor);
            return;
        }

        if (ch == '\u200D' || ch == '\u200C' || ch == '{' || ch == '}') {
            return;
        }

        raw = raw + ch;
        String replaced = SymbolReplacer.replaceSymbols(raw);
        if (!replaced.equals(raw)) {
            raw = replaced;
        }
        editor.getProperties().put(SUBSCRIPT_MODE_RAW_KEY, raw);

        String styledSubscript = Subscript.styledSubscriptText(replaced);
        EditorTextUtils.replace(editor, modeStart, caret, styledSubscript);
        editor.getProperties().put(SUBSCRIPT_MODE_STARTED_KEY, Boolean.TRUE);
        editor.getProperties().remove(SUBSCRIPT_MODE_MARKER_START_KEY);
        editor.getProperties().put(SUBSCRIPT_MODE_RENDERED_LEN_KEY, styledSubscript.length());
    }
}

