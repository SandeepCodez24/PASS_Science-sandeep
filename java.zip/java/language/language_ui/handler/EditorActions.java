package language.language_ui.handler;

import org.fxmisc.richtext.CodeArea;

import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import language.replace.Sanskrit;
import language.replace.Superscript;
import language.replace.Telugu;

public class EditorActions {

    // ---- handleReplacement (overload 1) ----
    // Entry point for handling symbol replacement with editor instance only
    public static void handleReplacement(CodeArea editor) {
        handleReplacement(editor, null);
    }

    // ---- handleReplacement (overload 2) ----
    // Main replacement handler - routes text input to appropriate language-specific
    // handlers
    public static void handleReplacement(CodeArea editor, KeyEvent keyEvent) {
        int caret = editor.getCaretPosition();
        int lineIndex = editor.getCurrentParagraph();
        int lineStart = editor.getAbsolutePosition(lineIndex, 0);
        String lineText = editor.getText(lineStart, caret);
        boolean subscriptMode = SubscriptModeHandler.isSubscriptMode(editor);
        boolean superscriptMode = SuperscriptModeHandler.isSuperscriptMode(editor);

        if (keyEvent != null) {
            KeyCode code = keyEvent.getCode();
            if (code == KeyCode.BACK_SPACE) {
                if (subscriptMode) {
                    SubscriptModeHandler.handleSubscriptModeBackspace(editor);
                } else if (superscriptMode) {
                    SuperscriptModeHandler.handleSuperscriptModeBackspace(editor);
                } else {
                    if (EditorTextUtils.repairBackspaceAtStyledGroupEnd(editor, true)
                            || EditorTextUtils.repairBackspaceAtStyledGroupEnd(editor, false)) {
                        return;
                    }
                }
                return;
            }

            if (code == KeyCode.DELETE || code == KeyCode.LEFT || code == KeyCode.RIGHT
                    || code == KeyCode.UP || code == KeyCode.DOWN || code == KeyCode.HOME
                    || code == KeyCode.END || code == KeyCode.PAGE_UP || code == KeyCode.PAGE_DOWN) {
                return;
            }

            if (isNonTextKey(code)) {
                return;
            }
        }

        if (!subscriptMode && lineText.endsWith("__")) {
            int markerStart = caret - 2;
            SubscriptModeHandler.enterSubscriptMode(editor, caret, markerStart);
            return;
        }

        if (!superscriptMode && lineText.endsWith("^^")) {
            int markerStart = caret - 2;
            SuperscriptModeHandler.enterSuperscriptMode(editor, caret, markerStart);
            return;
        }

        if (subscriptMode) {
            Integer modeStart = (Integer) editor.getProperties().get("subscriptModeStart");
            if (modeStart == null) {
                modeStart = caret - 1;
                editor.getProperties().put("subscriptModeStart", modeStart);
            }
            SubscriptModeHandler.handleSubscriptModeInput(editor, caret, lineText, modeStart, lineStart);
            return;
        }

        if (superscriptMode) {
            Integer modeStart = (Integer) editor.getProperties().get("superscriptModeStart");
            if (modeStart == null) {
                modeStart = caret - 1;
                editor.getProperties().put("superscriptModeStart", modeStart);
            }
            SuperscriptModeHandler.handleSuperscriptModeInput(editor, caret, lineText, modeStart);
            return;
        }

        handleGreekSuperscript(editor, lineText, lineStart, caret);
        if (shouldReturn())
            return;

        handleGreekSymbol(editor, lineText, lineStart, caret);
        if (shouldReturn())
            return;

        handleUniconstant(editor, lineText, lineStart, caret);
        if (shouldReturn())
            return;

        handleSanskritSymbol(editor, lineText, lineStart, caret);
        if (shouldReturn())
            return;

        handleSuperscriptBraces(editor, lineText, lineStart, caret);
        if (shouldReturn())
            return;

        handleSubscriptBraces(editor, lineText, lineStart, caret);
        if (shouldReturn())
            return;

        handleTamilVowel(editor, lineText, lineStart, caret);
        if (shouldReturn())
            return;

        handleTamilConsonant(editor, lineText, lineStart, caret);

        handleMalayalamVowel(editor, lineText, lineStart, caret);
        if (shouldReturn())
            return;

        handleMalayalamConsonant(editor, lineText, lineStart, caret);
        if (shouldReturn())
            return;

        handleTeluguVowel(editor, lineText, lineStart, caret);
        if (shouldReturn())
            return;

        handleTeluguConsonant(editor, lineText, lineStart, caret);
    }

    // ---- isNonTextKey ----
    // Identifies modifier and navigation keys that should not trigger replacements
    private static boolean isNonTextKey(KeyCode code) {
        return code == KeyCode.SHIFT
                || code == KeyCode.CONTROL
                || code == KeyCode.ALT
                || code == KeyCode.ALT_GRAPH
                || code == KeyCode.META
                || code == KeyCode.CAPS
                || code == KeyCode.TAB
                || code == KeyCode.ENTER
                || code == KeyCode.ESCAPE
                || code == KeyCode.F1
                || code == KeyCode.F2
                || code == KeyCode.F3
                || code == KeyCode.F4
                || code == KeyCode.F5
                || code == KeyCode.F6
                || code == KeyCode.F7
                || code == KeyCode.F8
                || code == KeyCode.F9
                || code == KeyCode.F10
                || code == KeyCode.F11
                || code == KeyCode.F12;
    }

    // ---- shouldReturn ----
    // Helper to control flow - currently always returns false for fallthrough logic
    private static boolean shouldReturn() {
        return false;
    }

    // ---- handleGreekSuperscript ----
    // Detects Greek letter sequences and converts to styled superscript
    private static void handleGreekSuperscript(CodeArea editor, String lineText, int lineStart, int caret) {
        if (SymbolReplacer.shouldReplaceGreekSuperscript(lineText)) {
            String key = SymbolReplacer.getGreekSuperscriptReplacement(lineText);
            String value = SymbolReplacer.replaceGreekSymbols(key);
            char ch = value.charAt(0);
            String styled = Superscript.styledSuperscript(ch);
            EditorTextUtils.replace(
                    editor,
                    lineStart + lineText.length() - (key.length() + 1),
                    caret,
                    styled);
        }
    }

    // ---- handleGreekSymbol ----
    // Replaces Greek letter mnemonics with Unicode Greek characters
    private static void handleGreekSymbol(CodeArea editor, String lineText, int lineStart, int caret) {
        if (isInsideUniconstant(lineText)) {
            return;
        }
        if (SymbolReplacer.shouldReplaceGreekSymbol(lineText)) {
            String key = SymbolReplacer.getGreekSymbolReplacement(lineText);
            String value = SymbolReplacer.replaceGreekSymbols(key);
            EditorTextUtils.replace(
                    editor,
                    lineStart + lineText.length() - key.length(),
                    caret,
                    value);
        }
    }

    // ---- isInsideUniconstant ----
    // Checks if cursor position is inside \\unicon(...) block (skip replacements
    // inside)
    private static boolean isInsideUniconstant(String lineText) {
        int openIndex = lineText.lastIndexOf("\\unicon(");
        if (openIndex == -1) {
            return false;
        }
        int closeIndex = lineText.lastIndexOf(')');
        return closeIndex < openIndex;
    }

    // ---- handleSuperscriptBraces ----
    // Handles ^{...} syntax - converts content to styled superscript block
    private static void handleSuperscriptBraces(CodeArea editor, String lineText, int lineStart, int caret) {
        int openBraceSup = lineText.lastIndexOf("^{");
        if (openBraceSup != -1 && lineText.endsWith("}") && openBraceSup < lineText.length() - 2) {
            String content = lineText.substring(openBraceSup + 2, lineText.length() - 1);
            if (!content.isBlank()) {
                String replaced = SymbolReplacer.replaceSymbols(content);
                String styled = Superscript.styledSuperscriptText(replaced);
                EditorTextUtils.replace(editor, lineStart + openBraceSup, caret, styled);
            }
        }
    }

    // ---- handleSubscriptBraces ----
    // Handles __{...} syntax - converts content to styled subscript block
    private static void handleSubscriptBraces(CodeArea editor, String lineText, int lineStart, int caret) {
        int openBrace = lineText.lastIndexOf("__{");
        if (openBrace != -1 && lineText.endsWith("}") && openBrace < lineText.length() - 2) {
            String content = lineText.substring(openBrace + 3, lineText.length() - 1);
            if (!content.isBlank()) {
                String replaced = SymbolReplacer.replaceSymbols(content);
                String styled = language.replace.Subscript.styledSubscriptText(replaced);
                EditorTextUtils.replace(editor, lineStart + openBrace, caret, styled);
            }
        }
    }

    // ---- handleTamilVowel ----
    // Detects and replaces Tamil vowel sequences with proper Unicode characters
    private static void handleTamilVowel(CodeArea editor, String lineText, int lineStart, int caret) {
        if (SymbolReplacer.shouldReplaceTamilVowel(lineText)) {
            String key = SymbolReplacer.getTamilVowelReplacement(lineText);
            String value = language.replace.Tamil.TAMIL_VOWEL_MAP.get(key);
            EditorTextUtils.replace(editor, lineStart + lineText.length() - key.length(), caret, value);
        }
    }

    // ---- handleTamilConsonant ----
    // Detects and replaces Tamil consonant sequences with proper Unicode characters
    private static void handleTamilConsonant(CodeArea editor, String lineText, int lineStart, int caret) {
        if (SymbolReplacer.shouldReplaceTamilConsonant(lineText)) {
            String key = SymbolReplacer.getTamilConsonantReplacement(lineText);
            String value = language.replace.Tamil.TAMIL_CONSONANT_MAP.get(key);
            EditorTextUtils.replace(editor, lineStart + lineText.length() - key.length(), caret, value);
        }
    }

    // ---- handleMalayalamVowel ----
    // Detects and replaces Malayalam vowel sequences with proper Unicode characters
    private static void handleMalayalamVowel(CodeArea editor, String lineText, int lineStart, int caret) {
        if (SymbolReplacer.shouldReplaceMalayalamVowel(lineText)) {
            String key = SymbolReplacer.getMalayalamVowelReplacement(lineText);
            String value = language.replace.Malayalam.MALAYALAM_VOWEL_MAP.get(key);
            EditorTextUtils.replace(editor, lineStart + lineText.length() - key.length(), caret, value);
        }
    }

    // ---- handleMalayalamConsonant ----
    // Detects and replaces Malayalam consonant sequences with proper Unicode
    // characters
    private static void handleMalayalamConsonant(CodeArea editor, String lineText, int lineStart, int caret) {
        if (SymbolReplacer.shouldReplaceMalayalamConsonant(lineText)) {
            String key = SymbolReplacer.getMalayalamConsonantReplacement(lineText);
            String value = language.replace.Malayalam.MALAYALAM_CONSONANT_MAP.get(key);
            EditorTextUtils.replace(editor, lineStart + lineText.length() - key.length(), caret, value);
        }
    }

    // ---- handleTeluguVowel ----
    // Detects and replaces Telugu vowel sequences with proper Unicode characters
    private static void handleTeluguVowel(CodeArea editor, String lineText, int lineStart, int caret) {
        if (SymbolReplacer.shouldReplaceTeluguVowel(lineText)) {
            String key = SymbolReplacer.getTeluguVowelReplacement(lineText);
            String value = Telugu.TELUGU_VOWEL_MAP.get(key);
            EditorTextUtils.replace(editor, lineStart + lineText.length() - key.length(), caret, value);
        }
    }

    // ---- handleTeluguConsonant ----
    // Detects and replaces Telugu consonant sequences with proper Unicode
    // characters
    private static void handleTeluguConsonant(CodeArea editor, String lineText, int lineStart, int caret) {
        if (SymbolReplacer.shouldReplaceTeluguConsonant(lineText)) {
            String key = SymbolReplacer.getTeluguConsonantReplacement(lineText);
            String value = Telugu.TELUGU_CONSONANT_MAP.get(key);
            EditorTextUtils.replace(editor, lineStart + lineText.length() - key.length(), caret, value);
        }
    }

    // ---- handleUniconstant ----
    // Handles \\con(...) syntax - converts Unicode escape sequences to characters
    private static void handleUniconstant(CodeArea editor, String lineText, int lineStart, int caret) {
        if (SymbolReplacer.shouldReplaceUniconstant(lineText)) {
            String key = SymbolReplacer.getUniconstantReplacement(lineText);
            String value = language.replace.Uniconstant.SYMBOL_MAP.get(key);
            if (value != null) {
                EditorTextUtils.replace(editor, lineStart + lineText.length() - key.length(), caret, value);
            }
        }
    }

    // ---- handleSanskritSymbol ----
    // Detects and replaces Sanskrit mnemonic sequences wrapped in
    // \\var(\\sanskrit(...))
    private static void handleSanskritSymbol(CodeArea editor, String lineText, int lineStart, int caret) {
        if (SymbolReplacer.shouldReplaceSanskritSymbol(lineText)) {
            String key = SymbolReplacer.getSanskritSymbolReplacement(lineText);
            String value = Sanskrit.SYMBOL_MAP.get(key);
            if (value != null) {
                EditorTextUtils.replace(editor, lineStart + lineText.length() - key.length(), caret, value);
            }
        }
    }

    // ---- isTamilChar ----
    // Checks if character is in Tamil Unicode range (U+0B80 to U+0BFF)
    private static boolean isTamilChar(char ch) {
        return ch >= '\u0B80' && ch <= '\u0BFF';
    }

    // ---- isGreekChar ----
    // Checks if character is lowercase or uppercase Greek letter (α-ω, Α-Ω)
    private static boolean isGreekChar(char ch) {
        return (ch >= '\u03B1' && ch <= '\u03C9') || (ch >= '\u0391' && ch <= '\u03A9');
    }

}
