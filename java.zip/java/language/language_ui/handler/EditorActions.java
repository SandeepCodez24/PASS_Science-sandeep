package language.language_ui.handler;

import org.fxmisc.richtext.CodeArea;

import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import language.replace.Malayalam;
import language.replace.Sanskrit;
import language.replace.Subscript;
import language.replace.Superscript;
import language.replace.Tamil;
import language.replace.Telugu;
import language.replace.Uniconstant;

public class EditorActions {

    // ---- handleReplacement (overload 1) ----
    // Entry point for handling symbol replacement with editor instance only
    public static void handleReplacement(CodeArea editor) {
        handleReplacement(editor, null);
    }

    // ---- Atomic caret / delete over a finished sub/superscript ----
    // Once a subscript/superscript value is assigned it behaves as a SINGLE
    // unit: one Left/Right steps past the whole element and one Backspace/Delete
    // removes the whole element (markers + content), instead of walking through
    // each hidden marker.
    //
    // MUST be registered as a KEY_PRESSED event *filter* (see
    // EditorSuggestionHandler.wireCodeAreaSuggestions). The default caret move /
    // delete happens on KEY_PRESSED, so consuming on KEY_RELEASED would be too
    // late. Returns true when it handled (and consumed) the event.
    public static boolean handleStyledGroupNavigation(CodeArea editor, KeyEvent keyEvent) {
        if (keyEvent == null) {
            return false;
        }
        KeyCode code = keyEvent.getCode();
        if (code != KeyCode.LEFT && code != KeyCode.RIGHT
                && code != KeyCode.BACK_SPACE && code != KeyCode.DELETE) {
            return false;
        }

        boolean plainMods = !keyEvent.isShiftDown() && !keyEvent.isControlDown()
                && !keyEvent.isAltDown() && !keyEvent.isMetaDown();
        boolean noSelection = editor.getSelection().getLength() == 0;
        boolean midGroup = SubscriptModeHandler.isSubscriptMode(editor)
                || SuperscriptModeHandler.isSuperscriptMode(editor);
        if (midGroup || !noSelection || !plainMods) {
            return false;
        }

        int caretPos = editor.getCaretPosition();
        if (code == KeyCode.LEFT) {
            int start = EditorTextUtils.styledGroupStartBefore(editor, caretPos);
            if (start >= 0) {
                editor.moveTo(start);
                editor.requestFollowCaret();
                keyEvent.consume();
                return true;
            }
        } else if (code == KeyCode.RIGHT) {
            int end = EditorTextUtils.styledGroupEndAfter(editor, caretPos);
            if (end >= 0) {
                editor.moveTo(end);
                editor.requestFollowCaret();
                keyEvent.consume();
                return true;
            }
        } else if (code == KeyCode.BACK_SPACE) {
            int start = EditorTextUtils.styledGroupStartBefore(editor, caretPos);
            if (start >= 0) {
                editor.deleteText(start, caretPos);
                editor.moveTo(start);
                editor.requestFollowCaret();
                keyEvent.consume();
                return true;
            }
        } else if (code == KeyCode.DELETE) {
            int end = EditorTextUtils.styledGroupEndAfter(editor, caretPos);
            if (end >= 0) {
                editor.deleteText(caretPos, end);
                editor.requestFollowCaret();
                keyEvent.consume();
                return true;
            }
        }
        return false;
    }

    // ---- handleReplacement (overload 2) ----
    // Main replacement handler - routes text input to appropriate language-specific
    // handlers
    public static void handleReplacement(CodeArea editor, KeyEvent keyEvent) {
        int caret = editor.getCaretPosition();
        int lineIndex = editor.getCurrentParagraph();
        int lineStart = editor.getAbsolutePosition(lineIndex, 0);
        String lineText = editor.getText(lineStart, caret);
        boolean subscriptMode = SubscriptModeHandler.isSubscriptMode(editor);
        boolean superscriptMode = SuperscriptModeHandler.isSuperscriptMode(editor);

        if (keyEvent != null) {
            KeyCode code = keyEvent.getCode();

            // NOTE: atomic caret/delete over a finished sub/superscript group
            // is handled earlier on KEY_PRESSED via
            // handleStyledGroupNavigation(...) (registered as an event filter),
            // because default caret move/delete happens on KEY_PRESSED. Here on
            // KEY_RELEASED we only deal with in-mode editing below.
            if (code == KeyCode.BACK_SPACE) {
                if (subscriptMode) {
                    SubscriptModeHandler.handleSubscriptModeBackspace(editor);
                } else if (superscriptMode) {
                    SuperscriptModeHandler.handleSuperscriptModeBackspace(editor);
                } else if (!EditorTextUtils.repairBackspaceAtStyledGroupEnd(editor, true)) {
                    EditorTextUtils.repairBackspaceAtStyledGroupEnd(editor, false);
                }
                return;
            }

            if (code == KeyCode.DELETE || code == KeyCode.LEFT || code == KeyCode.RIGHT
                    || code == KeyCode.UP || code == KeyCode.DOWN || code == KeyCode.HOME
                    || code == KeyCode.END || code == KeyCode.PAGE_UP || code == KeyCode.PAGE_DOWN) {
                return;
            }

            if (isNonTextKey(code)) {
                return;
            }
        }

        if (!subscriptMode && lineText.endsWith("__")) {
            SubscriptModeHandler.enterSubscriptMode(editor, caret - 2);
            return;
        }

        if (!superscriptMode && lineText.endsWith("^^")) {
            SuperscriptModeHandler.enterSuperscriptMode(editor, caret - 2);
            return;
        }

        if (subscriptMode) {
            int modeStart = SubscriptModeHandler.resolveModeStart(editor, caret);
            SubscriptModeHandler.handleSubscriptModeInput(editor, caret, lineText, modeStart);
            return;
        }

        if (superscriptMode) {
            int modeStart = SuperscriptModeHandler.resolveModeStart(editor, caret);
            SuperscriptModeHandler.handleSuperscriptModeInput(editor, caret, lineText, modeStart);
            return;
        }

        // First match wins. Every handler below computes its offsets from the
        // same lineText/caret snapshot taken at the top of this method; once one
        // of them has edited the document that snapshot is stale, so letting a
        // second handler run on it could replace the wrong span. The next key
        // release re-reads the document, so nothing is missed by stopping here.
        if (handleGreekSuperscript(editor, lineText, lineStart, caret)
                || handleGreekSymbol(editor, lineText, lineStart, caret)
                || handleUniconstant(editor, lineText, lineStart, caret)
                || handleSanskritSymbol(editor, lineText, lineStart, caret)
                || handleSuperscriptBraces(editor, lineText, lineStart, caret)
                || handleSubscriptBraces(editor, lineText, lineStart, caret)
                || handleTamilVowel(editor, lineText, lineStart, caret)
                || handleTamilConsonant(editor, lineText, lineStart, caret)
                || handleMalayalamVowel(editor, lineText, lineStart, caret)
                || handleMalayalamConsonant(editor, lineText, lineStart, caret)
                || handleTeluguVowel(editor, lineText, lineStart, caret)) {
            return;
        }
        handleTeluguConsonant(editor, lineText, lineStart, caret);
    }

    // ---- isNonTextKey ----
    // Identifies modifier and navigation keys that should not trigger replacements
    private static boolean isNonTextKey(KeyCode code) {
        return code == KeyCode.SHIFT
                || code == KeyCode.CONTROL
                || code == KeyCode.ALT
                || code == KeyCode.ALT_GRAPH
                || code == KeyCode.META
                || code == KeyCode.CAPS
                || code == KeyCode.TAB
                || code == KeyCode.ENTER
                || code == KeyCode.ESCAPE
                || code == KeyCode.F1
                || code == KeyCode.F2
                || code == KeyCode.F3
                || code == KeyCode.F4
                || code == KeyCode.F5
                || code == KeyCode.F6
                || code == KeyCode.F7
                || code == KeyCode.F8
                || code == KeyCode.F9
                || code == KeyCode.F10
                || code == KeyCode.F11
                || code == KeyCode.F12;
    }

    // ---- replaceTail ----
    // Replaces the last keyLength characters before the caret with value.
    // Returns false (and changes nothing) when the lookup produced no value,
    // so a missing map entry can never reach the editor as a null.
    private static boolean replaceTail(CodeArea editor, String lineText, int lineStart, int caret,
            int keyLength, String value) {
        if (value == null) {
            return false;
        }
        EditorTextUtils.replace(editor, lineStart + lineText.length() - keyLength, caret, value);
        return true;
    }

    // ---- handleGreekSuperscript ----
    // Detects Greek letter sequences and converts to styled superscript
    private static boolean handleGreekSuperscript(CodeArea editor, String lineText, int lineStart, int caret) {
        if (!SymbolReplacer.shouldReplaceGreekSuperscript(lineText)) {
            return false;
        }
        String key = SymbolReplacer.getGreekSuperscriptReplacement(lineText);
        if (key == null) {
            return false;
        }
        String value = SymbolReplacer.replaceGreekSymbols(key);
        if (value == null || value.isEmpty()) {
            return false;
        }
        String styled = Superscript.styledSuperscript(value.charAt(0));
        // key.length() + 1: the key plus the '^' that introduced it
        return replaceTail(editor, lineText, lineStart, caret, key.length() + 1, styled);
    }

    // ---- handleGreekSymbol ----
    // Replaces Greek letter mnemonics with Unicode Greek characters
    private static boolean handleGreekSymbol(CodeArea editor, String lineText, int lineStart, int caret) {
        if (isInsideUniconstant(lineText) || !SymbolReplacer.shouldReplaceGreekSymbol(lineText)) {
            return false;
        }
        String key = SymbolReplacer.getGreekSymbolReplacement(lineText);
        if (key == null) {
            return false;
        }
        return replaceTail(editor, lineText, lineStart, caret, key.length(),
                SymbolReplacer.replaceGreekSymbols(key));
    }

    // ---- isInsideUniconstant ----
    // Checks if cursor position is inside \\unicon(...) block (skip replacements
    // inside)
    private static boolean isInsideUniconstant(String lineText) {
        int openIndex = lineText.lastIndexOf("\\unicon(");
        if (openIndex == -1) {
            return false;
        }
        int closeIndex = lineText.lastIndexOf(')');
        return closeIndex < openIndex;
    }

    // ---- handleSuperscriptBraces ----
    // Handles ^{...} syntax - converts content to styled superscript block
    private static boolean handleSuperscriptBraces(CodeArea editor, String lineText, int lineStart, int caret) {
        int openBraceSup = lineText.lastIndexOf("^{");
        if (openBraceSup == -1 || !lineText.endsWith("}") || openBraceSup >= lineText.length() - 2) {
            return false;
        }
        String content = lineText.substring(openBraceSup + 2, lineText.length() - 1);
        if (content.isBlank()) {
            return false;
        }
        String replaced = SymbolReplacer.replaceSymbols(content);
        String styled = Superscript.styledSuperscriptText(replaced);
        EditorTextUtils.replace(editor, lineStart + openBraceSup, caret, styled);
        return true;
    }

    // ---- handleSubscriptBraces ----
    // Handles __{...} syntax - converts content to styled subscript block
    private static boolean handleSubscriptBraces(CodeArea editor, String lineText, int lineStart, int caret) {
        int openBrace = lineText.lastIndexOf("__{");
        if (openBrace == -1 || !lineText.endsWith("}") || openBrace >= lineText.length() - 2) {
            return false;
        }
        String content = lineText.substring(openBrace + 3, lineText.length() - 1);
        if (content.isBlank()) {
            return false;
        }
        String replaced = SymbolReplacer.replaceSymbols(content);
        String styled = Subscript.styledSubscriptText(replaced);
        EditorTextUtils.replace(editor, lineStart + openBrace, caret, styled);
        return true;
    }

    // ---- handleTamilVowel ----
    // Detects and replaces Tamil vowel sequences with proper Unicode characters
    private static boolean handleTamilVowel(CodeArea editor, String lineText, int lineStart, int caret) {
        if (!SymbolReplacer.shouldReplaceTamilVowel(lineText)) {
            return false;
        }
        String key = SymbolReplacer.getTamilVowelReplacement(lineText);
        return key != null && replaceTail(editor, lineText, lineStart, caret, key.length(),
                Tamil.TAMIL_VOWEL_MAP.get(key));
    }

    // ---- handleTamilConsonant ----
    // Detects and replaces Tamil consonant sequences with proper Unicode characters
    private static boolean handleTamilConsonant(CodeArea editor, String lineText, int lineStart, int caret) {
        if (!SymbolReplacer.shouldReplaceTamilConsonant(lineText)) {
            return false;
        }
        String key = SymbolReplacer.getTamilConsonantReplacement(lineText);
        return key != null && replaceTail(editor, lineText, lineStart, caret, key.length(),
                Tamil.TAMIL_CONSONANT_MAP.get(key));
    }

    // ---- handleMalayalamVowel ----
    // Detects and replaces Malayalam vowel sequences with proper Unicode characters
    private static boolean handleMalayalamVowel(CodeArea editor, String lineText, int lineStart, int caret) {
        if (!SymbolReplacer.shouldReplaceMalayalamVowel(lineText)) {
            return false;
        }
        String key = SymbolReplacer.getMalayalamVowelReplacement(lineText);
        return key != null && replaceTail(editor, lineText, lineStart, caret, key.length(),
                Malayalam.MALAYALAM_VOWEL_MAP.get(key));
    }

    // ---- handleMalayalamConsonant ----
    // Detects and replaces Malayalam consonant sequences with proper Unicode
    // characters
    private static boolean handleMalayalamConsonant(CodeArea editor, String lineText, int lineStart, int caret) {
        if (!SymbolReplacer.shouldReplaceMalayalamConsonant(lineText)) {
            return false;
        }
        String key = SymbolReplacer.getMalayalamConsonantReplacement(lineText);
        return key != null && replaceTail(editor, lineText, lineStart, caret, key.length(),
                Malayalam.MALAYALAM_CONSONANT_MAP.get(key));
    }

    // ---- handleTeluguVowel ----
    // Detects and replaces Telugu vowel sequences with proper Unicode characters
    private static boolean handleTeluguVowel(CodeArea editor, String lineText, int lineStart, int caret) {
        if (!SymbolReplacer.shouldReplaceTeluguVowel(lineText)) {
            return false;
        }
        String key = SymbolReplacer.getTeluguVowelReplacement(lineText);
        return key != null && replaceTail(editor, lineText, lineStart, caret, key.length(),
                Telugu.TELUGU_VOWEL_MAP.get(key));
    }

    // ---- handleTeluguConsonant ----
    // Detects and replaces Telugu consonant sequences with proper Unicode
    // characters
    private static boolean handleTeluguConsonant(CodeArea editor, String lineText, int lineStart, int caret) {
        if (!SymbolReplacer.shouldReplaceTeluguConsonant(lineText)) {
            return false;
        }
        String key = SymbolReplacer.getTeluguConsonantReplacement(lineText);
        return key != null && replaceTail(editor, lineText, lineStart, caret, key.length(),
                Telugu.TELUGU_CONSONANT_MAP.get(key));
    }

    // ---- handleUniconstant ----
    // Handles \\con(...) syntax - converts Unicode escape sequences to characters
    private static boolean handleUniconstant(CodeArea editor, String lineText, int lineStart, int caret) {
        if (!SymbolReplacer.shouldReplaceUniconstant(lineText)) {
            return false;
        }
        String key = SymbolReplacer.getUniconstantReplacement(lineText);
        return key != null && replaceTail(editor, lineText, lineStart, caret, key.length(),
                Uniconstant.SYMBOL_MAP.get(key));
    }

    // ---- handleSanskritSymbol ----
    // Detects and replaces Sanskrit mnemonic sequences wrapped in
    // \\var(\\sanskrit(...))
    private static boolean handleSanskritSymbol(CodeArea editor, String lineText, int lineStart, int caret) {
        if (!SymbolReplacer.shouldReplaceSanskritSymbol(lineText)) {
            return false;
        }
        String key = SymbolReplacer.getSanskritSymbolReplacement(lineText);
        return key != null && replaceTail(editor, lineText, lineStart, caret, key.length(),
                Sanskrit.SYMBOL_MAP.get(key));
    }
}
