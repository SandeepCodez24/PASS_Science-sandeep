package language.language_ui.handler;

import org.fxmisc.richtext.CodeArea;

import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import language.replace.Malayalam;
import language.replace.Sanskrit;
import language.replace.Tamil;
import language.replace.Telugu;
import language.replace.Uniconstant;
import ui.editor.ScriptedCaret;

/**
 * Live symbol replacement while typing in a {@code .nc} editor, and the
 * caret's behaviour over subscripts and superscripts.
 *
 * <h3>Subscripts and superscripts (changed)</h3>
 * <p>
 * There is no subscript or superscript "mode" any more. {@code A_$1} is typed
 * character by character and stays in the document as typed; the highlighter
 * draws it as A&#8321; as soon as the name is complete
 * ({@code UPITokenMaker}). So nothing here rewrites the text for them: the
 * old {@code __} / {@code ^^} triggers, the {@code __{..}} / {@code ^{..}}
 * braces and {@code ^\mu} are gone, and so are the zero-width joiners they
 * inserted.
 * </p>
 * <p>
 * A scripted name is one unit from outside -- one Backspace after it, or one
 * Delete before its script, removes the whole script -- and is edited from
 * inside by stepping in with the arrows; nothing is ever joined into a
 * script by a deletion: {@link ScriptedCaret}.
 * </p>
 */
public class EditorActions {

    // ---- handleReplacement (overload 1) ----
    // Entry point for handling symbol replacement with editor instance only
    public static void handleReplacement(CodeArea editor) {
        handleReplacement(editor, null);
    }

    // ---- Caret and editing keys over a subscript / superscript ----
    // See ScriptedCaret: whole-script Backspace / Delete from outside,
    // step-in editing with the arrows, no deletion ever joins text into a
    // script. MUST be called
    // from a KEY_PRESSED event *filter* (see
    // EditorSuggestionHandler.wireCodeAreaSuggestions): the default caret
    // move happens on KEY_PRESSED. Returns true when it handled (and
    // consumed) the event.
    public static boolean handleStyledGroupNavigation(CodeArea editor, KeyEvent keyEvent) {
        return ScriptedCaret.handleKey(editor, keyEvent);
    }

    // ---- handleReplacement (overload 2) ----
    // Main replacement handler - routes text input to appropriate language-specific
    // handlers
    public static void handleReplacement(CodeArea editor, KeyEvent keyEvent) {
        int caret = editor.getCaretPosition();
        int lineIndex = editor.getCurrentParagraph();
        int lineStart = editor.getAbsolutePosition(lineIndex, 0);
        String lineText = editor.getText(lineStart, caret);

        if (keyEvent != null) {
            KeyCode code = keyEvent.getCode();
            if (code == KeyCode.BACK_SPACE || code == KeyCode.DELETE || code == KeyCode.LEFT
                    || code == KeyCode.RIGHT || code == KeyCode.UP || code == KeyCode.DOWN
                    || code == KeyCode.HOME || code == KeyCode.END || code == KeyCode.PAGE_UP
                    || code == KeyCode.PAGE_DOWN || isNonTextKey(code)) {
                return;
            }
        }

        // First match wins. Every handler below computes its offsets from the
        // same lineText/caret snapshot taken at the top of this method; once one
        // of them has edited the document that snapshot is stale, so letting a
        // second handler run on it could replace the wrong span. The next key
        // release re-reads the document, so nothing is missed by stopping here.
        if (handleGreekSymbol(editor, lineText, lineStart, caret)
                || handleUniconstant(editor, lineText, lineStart, caret)
                || handleSanskritSymbol(editor, lineText, lineStart, caret)
                || handleTamilVowel(editor, lineText, lineStart, caret)
                || handleTamilConsonant(editor, lineText, lineStart, caret)
                || handleMalayalamVowel(editor, lineText, lineStart, caret)
                || handleMalayalamConsonant(editor, lineText, lineStart, caret)
                || handleTeluguVowel(editor, lineText, lineStart, caret)) {
            return;
        }
        handleTeluguConsonant(editor, lineText, lineStart, caret);
    }

    // ---- isNonTextKey ----
    // Identifies modifier and navigation keys that should not trigger replacements
    private static boolean isNonTextKey(KeyCode code) {
        return code == KeyCode.SHIFT
                || code == KeyCode.CONTROL
                || code == KeyCode.ALT
                || code == KeyCode.ALT_GRAPH
                || code == KeyCode.META
                || code == KeyCode.CAPS
                || code == KeyCode.TAB
                || code == KeyCode.ENTER
                || code == KeyCode.ESCAPE
                || code == KeyCode.F1
                || code == KeyCode.F2
                || code == KeyCode.F3
                || code == KeyCode.F4
                || code == KeyCode.F5
                || code == KeyCode.F6
                || code == KeyCode.F7
                || code == KeyCode.F8
                || code == KeyCode.F9
                || code == KeyCode.F10
                || code == KeyCode.F11
                || code == KeyCode.F12;
    }

    // ---- replaceTail ----
    // Replaces the last keyLength characters before the caret with value.
    // Returns false (and changes nothing) when the lookup produced no value,
    // so a missing map entry can never reach the editor as a null.
    private static boolean replaceTail(CodeArea editor, String lineText, int lineStart, int caret,
            int keyLength, String value) {
        if (value == null) {
            return false;
        }
        EditorTextUtils.replace(editor, lineStart + lineText.length() - keyLength, caret, value);
        return true;
    }

    // ---- handleGreekSymbol ----
    // Replaces Greek letter mnemonics with Unicode Greek characters
    private static boolean handleGreekSymbol(CodeArea editor, String lineText, int lineStart, int caret) {
        if (isInsideUniconstant(lineText) || !SymbolReplacer.shouldReplaceGreekSymbol(lineText)) {
            return false;
        }
        String key = SymbolReplacer.getGreekSymbolReplacement(lineText);
        if (key == null) {
            return false;
        }
        return replaceTail(editor, lineText, lineStart, caret, key.length(),
                SymbolReplacer.replaceGreekSymbols(key));
    }

    // ---- isInsideUniconstant ----
    // Checks if cursor position is inside \\unicon(...) block (skip replacements
    // inside)
    private static boolean isInsideUniconstant(String lineText) {
        int openIndex = lineText.lastIndexOf("\\unicon(");
        if (openIndex == -1) {
            return false;
        }
        int closeIndex = lineText.lastIndexOf(')');
        return closeIndex < openIndex;
    }

    // ---- handleTamilVowel ----
    // Detects and replaces Tamil vowel sequences with proper Unicode characters
    private static boolean handleTamilVowel(CodeArea editor, String lineText, int lineStart, int caret) {
        if (!SymbolReplacer.shouldReplaceTamilVowel(lineText)) {
            return false;
        }
        String key = SymbolReplacer.getTamilVowelReplacement(lineText);
        return key != null && replaceTail(editor, lineText, lineStart, caret, key.length(),
                Tamil.TAMIL_VOWEL_MAP.get(key));
    }

    // ---- handleTamilConsonant ----
    // Detects and replaces Tamil consonant sequences with proper Unicode characters
    private static boolean handleTamilConsonant(CodeArea editor, String lineText, int lineStart, int caret) {
        if (!SymbolReplacer.shouldReplaceTamilConsonant(lineText)) {
            return false;
        }
        String key = SymbolReplacer.getTamilConsonantReplacement(lineText);
        return key != null && replaceTail(editor, lineText, lineStart, caret, key.length(),
                Tamil.TAMIL_CONSONANT_MAP.get(key));
    }

    // ---- handleMalayalamVowel ----
    // Detects and replaces Malayalam vowel sequences with proper Unicode characters
    private static boolean handleMalayalamVowel(CodeArea editor, String lineText, int lineStart, int caret) {
        if (!SymbolReplacer.shouldReplaceMalayalamVowel(lineText)) {
            return false;
        }
        String key = SymbolReplacer.getMalayalamVowelReplacement(lineText);
        return key != null && replaceTail(editor, lineText, lineStart, caret, key.length(),
                Malayalam.MALAYALAM_VOWEL_MAP.get(key));
    }

    // ---- handleMalayalamConsonant ----
    // Detects and replaces Malayalam consonant sequences with proper Unicode
    // characters
    private static boolean handleMalayalamConsonant(CodeArea editor, String lineText, int lineStart, int caret) {
        if (!SymbolReplacer.shouldReplaceMalayalamConsonant(lineText)) {
            return false;
        }
        String key = SymbolReplacer.getMalayalamConsonantReplacement(lineText);
        return key != null && replaceTail(editor, lineText, lineStart, caret, key.length(),
                Malayalam.MALAYALAM_CONSONANT_MAP.get(key));
    }

    // ---- handleTeluguVowel ----
    // Detects and replaces Telugu vowel sequences with proper Unicode characters
    private static boolean handleTeluguVowel(CodeArea editor, String lineText, int lineStart, int caret) {
        if (!SymbolReplacer.shouldReplaceTeluguVowel(lineText)) {
            return false;
        }
        String key = SymbolReplacer.getTeluguVowelReplacement(lineText);
        return key != null && replaceTail(editor, lineText, lineStart, caret, key.length(),
                Telugu.TELUGU_VOWEL_MAP.get(key));
    }

    // ---- handleTeluguConsonant ----
    // Detects and replaces Telugu consonant sequences with proper Unicode
    // characters
    private static boolean handleTeluguConsonant(CodeArea editor, String lineText, int lineStart, int caret) {
        if (!SymbolReplacer.shouldReplaceTeluguConsonant(lineText)) {
            return false;
        }
        String key = SymbolReplacer.getTeluguConsonantReplacement(lineText);
        return key != null && replaceTail(editor, lineText, lineStart, caret, key.length(),
                Telugu.TELUGU_CONSONANT_MAP.get(key));
    }

    // ---- handleUniconstant ----
    // Handles \\con(...) syntax - converts Unicode escape sequences to characters
    private static boolean handleUniconstant(CodeArea editor, String lineText, int lineStart, int caret) {
        if (!SymbolReplacer.shouldReplaceUniconstant(lineText)) {
            return false;
        }
        String key = SymbolReplacer.getUniconstantReplacement(lineText);
        return key != null && replaceTail(editor, lineText, lineStart, caret, key.length(),
                Uniconstant.SYMBOL_MAP.get(key));
    }

    // ---- handleSanskritSymbol ----
    // Detects and replaces Sanskrit mnemonic sequences wrapped in
    // \\var(\\sanskrit(...))
    private static boolean handleSanskritSymbol(CodeArea editor, String lineText, int lineStart, int caret) {
        if (!SymbolReplacer.shouldReplaceSanskritSymbol(lineText)) {
            return false;
        }
        String key = SymbolReplacer.getSanskritSymbolReplacement(lineText);
        return key != null && replaceTail(editor, lineText, lineStart, caret, key.length(),
                Sanskrit.SYMBOL_MAP.get(key));
    }
}
