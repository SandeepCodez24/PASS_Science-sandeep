package language.language_ui.handler;

import org.fxmisc.richtext.CodeArea;
import language.replace.Superscript;

final class SuperscriptModeHandler {
    private static final String SUPERSCRIPT_MODE_KEY = "superscriptMode";
    private static final String SUPERSCRIPT_MODE_START_KEY = "superscriptModeStart";
    private static final String SUPERSCRIPT_MODE_MARKER_START_KEY = "superscriptModeMarkerStart";
    private static final String SUPERSCRIPT_MODE_STARTED_KEY = "superscriptModeStarted";
    private static final String SUPERSCRIPT_MODE_RAW_KEY = "superscriptModeRaw";

    private SuperscriptModeHandler() {
    }

    static boolean isSuperscriptMode(CodeArea editor) {
        return Boolean.TRUE.equals(editor.getProperties().get(SUPERSCRIPT_MODE_KEY));
    }

    static void enterSuperscriptMode(CodeArea editor, int caret, int markerStart) {
        editor.getProperties().put(SUPERSCRIPT_MODE_KEY, Boolean.TRUE);
        editor.getProperties().put(SUPERSCRIPT_MODE_START_KEY, markerStart);
        editor.getProperties().put(SUPERSCRIPT_MODE_MARKER_START_KEY, markerStart);
        editor.getProperties().put(SUPERSCRIPT_MODE_STARTED_KEY, Boolean.FALSE);
        editor.getProperties().put(SUPERSCRIPT_MODE_RAW_KEY, "");
    }

    static void exitSuperscriptMode(CodeArea editor) {
        editor.getProperties().put(SUPERSCRIPT_MODE_KEY, Boolean.FALSE);
        editor.getProperties().remove(SUPERSCRIPT_MODE_START_KEY);
        editor.getProperties().remove(SUPERSCRIPT_MODE_MARKER_START_KEY);
        editor.getProperties().remove(SUPERSCRIPT_MODE_STARTED_KEY);
        editor.getProperties().remove(SUPERSCRIPT_MODE_RAW_KEY);
    }

    static void handleSuperscriptModeBackspace(CodeArea editor) {
        String raw = (String) editor.getProperties().get(SUPERSCRIPT_MODE_RAW_KEY);
        Integer modeStart = (Integer) editor.getProperties().get(SUPERSCRIPT_MODE_START_KEY);
        if (raw != null && !raw.isEmpty() && modeStart != null) {
            int editorLength = editor.getLength();
            if (modeStart < 0 || modeStart > editorLength) {
                exitSuperscriptMode(editor);
                return;
            }
            String updatedRaw = raw.substring(0, raw.length() - 1);
            editor.getProperties().put(SUPERSCRIPT_MODE_RAW_KEY, updatedRaw);
            String rebuilt = updatedRaw.isEmpty()
                    ? ""
                    : Superscript.styledSuperscriptText(SymbolReplacer.replaceSymbols(updatedRaw));
            int replaceEnd = Math.min(editorLength, Math.max(modeStart, editor.getCaretPosition()));
            EditorTextUtils.replace(editor, modeStart, replaceEnd, rebuilt);
            if (updatedRaw.isEmpty()) {
                exitSuperscriptMode(editor);
            }
        }
    }

    static void handleSuperscriptModeInput(CodeArea editor, int caret, String lineText, int modeStart) {
        if (lineText.isEmpty()) {
            return;
        }
        Integer markerStart = (Integer) editor.getProperties().get(SUPERSCRIPT_MODE_MARKER_START_KEY);
        Boolean started = (Boolean) editor.getProperties().get(SUPERSCRIPT_MODE_STARTED_KEY);
        String raw = (String) editor.getProperties().get(SUPERSCRIPT_MODE_RAW_KEY);
        if (started == null) {
            started = Boolean.FALSE;
            editor.getProperties().put(SUPERSCRIPT_MODE_STARTED_KEY, Boolean.FALSE);
        }
        if (raw == null) {
            raw = "";
            editor.getProperties().put(SUPERSCRIPT_MODE_RAW_KEY, raw);
        }

        // -----------------------------------------------------------------
        // FAST-TYPING FIX (dropped alternate letters) -- see the detailed
        // explanation in SubscriptModeHandler.handleSubscriptModeInput. We
        // process the ENTIRE run of freshly typed plain characters between the
        // committed group and the live caret, rather than only the last one.
        // -----------------------------------------------------------------
        String fullText = editor.getText();
        if (fullText == null) {
            return;
        }
        int liveCaret = editor.getCaretPosition();
        if (liveCaret < caret) {
            liveCaret = caret;
        }
        if (liveCaret > fullText.length()) {
            liveCaret = fullText.length();
        }

        int committedLen = Boolean.TRUE.equals(started)
                ? Superscript.styledSuperscriptText(raw).length()
                : 2;
        int contentEnd = modeStart + committedLen;
        if (contentEnd < 0 || contentEnd > liveCaret) {
            return;
        }

        String pending = fullText.substring(contentEnd, liveCaret);
        if (pending.isEmpty()) {
            return;
        }

        StringBuilder rawBuilder = new StringBuilder(raw);
        for (int idx = 0; idx < pending.length(); idx++) {
            char ch = pending.charAt(idx);
            if (ch == ' ' || EditorTextUtils.isModeExitOperator(ch)) {
                exitSuperscriptOnBoundary(editor, modeStart, liveCaret,
                        rawBuilder.toString(), ch, pending.substring(idx + 1));
                return;
            }
            if (ch == '\u200D' || ch == '\u200C' || ch == '{' || ch == '}') {
                continue;
            }
            rawBuilder.append(ch);
        }

        String newRaw = SymbolReplacer.replaceSymbols(rawBuilder.toString());
        editor.getProperties().put(SUPERSCRIPT_MODE_RAW_KEY, newRaw);
        String styledSuperscript = Superscript.styledSuperscriptText(newRaw);
        EditorTextUtils.replace(editor, modeStart, liveCaret, styledSuperscript);
        editor.getProperties().put(SUPERSCRIPT_MODE_STARTED_KEY, Boolean.TRUE);
        editor.getProperties().remove(SUPERSCRIPT_MODE_MARKER_START_KEY);
    }

    // Commits whatever has been typed so far and leaves superscript mode when a
    // space or an operator terminates the group. A space is consumed; an
    // operator is kept. Any text typed after the boundary (fast typing) is
    // preserved.
    private static void exitSuperscriptOnBoundary(CodeArea editor, int modeStart, int endRegion,
            String rawSoFar, char boundaryCh, String afterBoundary) {
        String newRaw = SymbolReplacer.replaceSymbols(rawSoFar);
        String styled = newRaw.isEmpty() ? "" : Superscript.styledSuperscriptText(newRaw);
        String trailing = (boundaryCh == ' ') ? afterBoundary : (boundaryCh + afterBoundary);

        int editorLength = editor.getLength();
        int start = Math.max(0, Math.min(modeStart, editorLength));
        int end = Math.max(start, Math.min(endRegion, editorLength));
        editor.replaceText(start, end, styled + trailing);
        editor.moveTo(Math.min(editor.getLength(), start + styled.length() + trailing.length()));
        editor.requestFollowCaret();
        exitSuperscriptMode(editor);
    }
}
