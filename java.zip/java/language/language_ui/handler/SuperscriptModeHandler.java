package language.language_ui.handler;

import org.fxmisc.richtext.CodeArea;

import language.replace.Superscript;

final class SuperscriptModeHandler {

    private static final String SUPERSCRIPT_MODE_KEY = "superscriptMode";
    private static final String SUPERSCRIPT_MODE_START_KEY = "superscriptModeStart";
    private static final String SUPERSCRIPT_MODE_MARKER_START_KEY = "superscriptModeMarkerStart";
    private static final String SUPERSCRIPT_MODE_STARTED_KEY = "superscriptModeStarted";
    private static final String SUPERSCRIPT_MODE_RAW_KEY = "superscriptModeRaw";

    private SuperscriptModeHandler() {
    }

    static boolean isSuperscriptMode(CodeArea editor) {
        return Boolean.TRUE.equals(editor.getProperties().get(SUPERSCRIPT_MODE_KEY));
    }

    static void enterSuperscriptMode(CodeArea editor, int caret, int markerStart) {
        editor.getProperties().put(SUPERSCRIPT_MODE_KEY, Boolean.TRUE);
        editor.getProperties().put(SUPERSCRIPT_MODE_START_KEY, markerStart);
        editor.getProperties().put(SUPERSCRIPT_MODE_MARKER_START_KEY, markerStart);
        editor.getProperties().put(SUPERSCRIPT_MODE_STARTED_KEY, Boolean.FALSE);
        editor.getProperties().put(SUPERSCRIPT_MODE_RAW_KEY, "");
    }

    static void exitSuperscriptMode(CodeArea editor) {
        editor.getProperties().put(SUPERSCRIPT_MODE_KEY, Boolean.FALSE);
        editor.getProperties().remove(SUPERSCRIPT_MODE_START_KEY);
        editor.getProperties().remove(SUPERSCRIPT_MODE_MARKER_START_KEY);
        editor.getProperties().remove(SUPERSCRIPT_MODE_STARTED_KEY);
        editor.getProperties().remove(SUPERSCRIPT_MODE_RAW_KEY);
    }

    static void handleSuperscriptModeBackspace(CodeArea editor) {
        String raw = (String) editor.getProperties().get(SUPERSCRIPT_MODE_RAW_KEY);
        Integer modeStart = (Integer) editor.getProperties().get(SUPERSCRIPT_MODE_START_KEY);

        if (raw != null && !raw.isEmpty() && modeStart != null) {
            int editorLength = editor.getLength();
            if (modeStart < 0 || modeStart > editorLength) {
                exitSuperscriptMode(editor);
                return;
            }

            String updatedRaw = raw.substring(0, raw.length() - 1);
            editor.getProperties().put(SUPERSCRIPT_MODE_RAW_KEY, updatedRaw);

            String rebuilt = updatedRaw.isEmpty()
                    ? ""
                    : Superscript.styledSuperscriptText(SymbolReplacer.replaceSymbols(updatedRaw));

            int replaceEnd = Math.min(editorLength, Math.max(modeStart, editor.getCaretPosition()));
            EditorTextUtils.replace(editor, modeStart, replaceEnd, rebuilt);

            if (updatedRaw.isEmpty()) {
                exitSuperscriptMode(editor);
            }
        }
    }

    static void handleSuperscriptModeInput(CodeArea editor, int caret, String lineText, int modeStart) {
        if (lineText.isEmpty()) {
            return;
        }

        Integer markerStart = (Integer) editor.getProperties().get(SUPERSCRIPT_MODE_MARKER_START_KEY);
        Boolean started = (Boolean) editor.getProperties().get(SUPERSCRIPT_MODE_STARTED_KEY);
        String raw = (String) editor.getProperties().get(SUPERSCRIPT_MODE_RAW_KEY);

        if (started == null) {
            started = Boolean.FALSE;
            editor.getProperties().put(SUPERSCRIPT_MODE_STARTED_KEY, Boolean.FALSE);
        }
        if (raw == null) {
            raw = "";
            editor.getProperties().put(SUPERSCRIPT_MODE_RAW_KEY, raw);
        }

        int typedCharIndex = caret - 1;
        if (typedCharIndex < modeStart) {
            return;
        }

        char ch = lineText.charAt(lineText.length() - 1);

        if (ch == ' ' || EditorTextUtils.isModeExitOperator(ch)) {
            int liveCaret = editor.getCaretPosition();
            if (!started && markerStart != null && markerStart >= 0 && markerStart + 2 <= editor.getLength()) {
                editor.replaceText(markerStart, markerStart + 2, "");
                liveCaret = Math.max(markerStart, liveCaret - 2);
            }
            if (ch == ' ' && liveCaret > 0) {
                editor.replaceText(liveCaret - 1, liveCaret, "");
                liveCaret = liveCaret - 1;
            }
            editor.moveTo(Math.max(0, Math.min(editor.getLength(), liveCaret)));
            editor.requestFollowCaret();
            exitSuperscriptMode(editor);
            return;
        }

        if (ch == '\u200D' || ch == '\u200C' || ch == '{' || ch == '}') {
            return;
        }

        raw = raw + ch;
        String replaced = SymbolReplacer.replaceSymbols(raw);
        if (!replaced.equals(raw)) {
            raw = replaced;
        }
        editor.getProperties().put(SUPERSCRIPT_MODE_RAW_KEY, raw);

        String styledSuperscript = Superscript.styledSuperscriptText(replaced);
        EditorTextUtils.replace(editor, modeStart, caret, styledSuperscript);
        editor.getProperties().put(SUPERSCRIPT_MODE_STARTED_KEY, Boolean.TRUE);
        editor.getProperties().remove(SUPERSCRIPT_MODE_MARKER_START_KEY);
    }
}

