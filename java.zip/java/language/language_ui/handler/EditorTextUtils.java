package language.language_ui.handler;

import org.fxmisc.richtext.CodeArea;

final class EditorTextUtils {

    private EditorTextUtils() {
    }

    static void replace(CodeArea editor, int start, int end, String value) {
        editor.replaceText(start, end, value);
        editor.moveTo(start + value.length());
        editor.requestFollowCaret();
    }

    static boolean isModeExitOperator(char ch) {
        return ch == '+' || ch == '-' || ch == '=' || ch == '*' || ch == '/';
    }

    static boolean repairBackspaceAtStyledGroupEnd(CodeArea editor, boolean subscript) {
        char marker = subscript ? '\u200D' : '\u200C';
        String triple = "" + marker + marker + marker;

        int caret = editor.getCaretPosition();
        if (caret <= 0) {
            return false;
        }

        String text = editor.getText();
        if (text == null || text.isEmpty()) {
            return false;
        }

        int runStart = caret;
        while (runStart > 0 && text.charAt(runStart - 1) == marker && (caret - runStart) < 3) {
            runStart--;
        }
        int markersBeforeCaret = caret - runStart;
        if (markersBeforeCaret < 1 || markersBeforeCaret > 2) {
            return false;
        }

        int start = text.lastIndexOf(triple, runStart - 1);
        if (start < 0) {
            return false;
        }

        int contentStart = start + 3;
        if (contentStart > runStart) {
            return false;
        }

        String content = text.substring(contentStart, runStart);
        String updatedContent = content.isEmpty() ? "" : content.substring(0, content.length() - 1);
        String rebuilt = updatedContent.isEmpty()
                ? ""
                : (subscript
                ? language.replace.Subscript.styledSubscriptText(updatedContent)
                : language.replace.Superscript.styledSuperscriptText(updatedContent));

        editor.replaceText(start, caret, rebuilt);
        editor.moveTo(start + rebuilt.length());
        editor.requestFollowCaret();
        return true;
    }
}

