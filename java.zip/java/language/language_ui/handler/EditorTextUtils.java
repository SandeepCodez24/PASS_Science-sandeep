package language.language_ui.handler;

import org.fxmisc.richtext.CodeArea;

import language.semantic.CodeSegments;

final class EditorTextUtils {

    private EditorTextUtils() {
    }

    static void replace(CodeArea editor, int start, int end, String value) {
        editor.replaceText(start, end, value);
        editor.moveTo(start + value.length());
        editor.requestFollowCaret();
    }

    /**
     * True when the caret sits inside a string literal: after an opening
     * {@code "} or {@code '} that has not been closed. A literal carried over
     * from earlier lines with {@code ~~} counts. Inside a comment this is
     * false.
     *
     * <p>
     * Inside a string, sub/superscript typing ({@code __}, {@code ^^},
     * {@code __{...}}, {@code ^{...}}, {@code ^\mu}) is left as plain text:
     * a string holds text exactly as typed, and the syntax checker reports a
     * sub/superscript found inside one.
     *
     * @param editor the editor
     * @param caret  the caret offset
     * @return whether the caret is inside an open string literal
     */
    static boolean caretInsideString(CodeArea editor, int caret) {
        String text = editor.getText();
        if (text == null || text.isEmpty()) {
            return false;
        }
        int end = Math.max(0, Math.min(caret, text.length()));
        int start = text.lastIndexOf('\n', end - 1) + 1;
        // Walk back over lines that end in the ~~ continuation.
        while (start > 0) {
            int prevStart = text.lastIndexOf('\n', start - 2) + 1;
            String previous = text.substring(prevStart, start - 1).stripTrailing();
            if (!previous.endsWith("~~")) {
                break;
            }
            start = prevStart;
        }
        return CodeSegments.endsInsideString(text.substring(start, end));
    }

    static boolean isModeExitOperator(char ch) {
        return ch == '+' || ch == '-' || ch == '=' || ch == '*' || ch == '/';
    }

    static boolean repairBackspaceAtStyledGroupEnd(CodeArea editor, boolean subscript) {
        char marker = subscript ? '\u200D' : '\u200C';
        String triple = "" + marker + marker + marker;

        int caret = editor.getCaretPosition();
        if (caret <= 0) {
            return false;
        }

        String text = editor.getText();
        if (text == null || text.isEmpty()) {
            return false;
        }

        int runStart = caret;
        while (runStart > 0 && text.charAt(runStart - 1) == marker && (caret - runStart) < 3) {
            runStart--;
        }
        int markersBeforeCaret = caret - runStart;
        if (markersBeforeCaret < 1 || markersBeforeCaret > 2) {
            return false;
        }

        int start = text.lastIndexOf(triple, runStart - 1);
        if (start < 0) {
            return false;
        }

        int contentStart = start + 3;
        if (contentStart > runStart) {
            return false;
        }

        String content = text.substring(contentStart, runStart);
        String updatedContent = content.isEmpty() ? "" : content.substring(0, content.length() - 1);
        String rebuilt = updatedContent.isEmpty()
                ? ""
                : (subscript
                ? language.replace.Subscript.styledSubscriptText(updatedContent)
                : language.replace.Superscript.styledSuperscriptText(updatedContent));

        editor.replaceText(start, caret, rebuilt);
        editor.moveTo(start + rebuilt.length());
        editor.requestFollowCaret();
        return true;
    }

    // ------------------------------------------------------------------
    // Atomic navigation / deletion over a whole styled sub/superscript
    // group. A rendered group looks like  MARKER(s) + content + MARKER(s) ,
    // where MARKER is U+200D (subscript) or U+200C (superscript) and the
    // opening/closing marker runs are the same length (1 for a single
    // character, 3 for a multi-character group). These helpers let the
    // caret jump/delete the entire element in a single key press instead of
    // stepping through each hidden marker.
    // ------------------------------------------------------------------

    static boolean isStyledMarker(char c) {
        return c == '\u200D' || c == '\u200C';
    }

    /**
     * If a styled sub/superscript group ends exactly at {@code caret},
     * returns the offset where that whole group starts; otherwise -1.
     */
    static int styledGroupStartBefore(CodeArea editor, int caret) {
        if (caret <= 0) {
            return -1;
        }
        String text = editor.getText();
        if (text == null || caret > text.length()) {
            return -1;
        }
        char m = text.charAt(caret - 1);
        if (!isStyledMarker(m)) {
            return -1;
        }
        int i = caret;
        int trailing = 0;
        while (i > 0 && text.charAt(i - 1) == m && trailing < 3) {
            i--;
            trailing++;
        }
        while (i > 0 && text.charAt(i - 1) != m && text.charAt(i - 1) != '\n') {
            i--;
        }
        int leading = 0;
        while (i > 0 && text.charAt(i - 1) == m && leading < trailing) {
            i--;
            leading++;
        }
        if (leading == 0) {
            return -1; // no opening marker run -> not a well-formed group
        }
        return i;
    }

    /**
     * If a styled sub/superscript group starts exactly at {@code caret},
     * returns the offset where that whole group ends; otherwise -1.
     */
    static int styledGroupEndAfter(CodeArea editor, int caret) {
        String text = editor.getText();
        if (text == null) {
            return -1;
        }
        int n = text.length();
        if (caret < 0 || caret >= n) {
            return -1;
        }
        char m = text.charAt(caret);
        if (!isStyledMarker(m)) {
            return -1;
        }
        int i = caret;
        int leading = 0;
        while (i < n && text.charAt(i) == m && leading < 3) {
            i++;
            leading++;
        }
        while (i < n && text.charAt(i) != m && text.charAt(i) != '\n') {
            i++;
        }
        int trailing = 0;
        while (i < n && text.charAt(i) == m && trailing < leading) {
            i++;
            trailing++;
        }
        if (trailing == 0) {
            return -1; // no closing marker run -> not a well-formed group
        }
        return i;
    }
}

