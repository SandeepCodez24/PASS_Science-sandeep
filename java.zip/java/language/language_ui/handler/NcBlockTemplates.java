package language.language_ui.handler;

import java.util.List;

import language.syntax.syntax_checker.BlockHeaderGrammar;

/**
 * The one source of Neural Code block skeletons.
 *
 * <p>
 * Used by the editor's autofill (a header completed with {@code :}) and by the
 * Home ribbon's New &rarr; function / class menu, so both always write exactly
 * the same code. Change a placeholder or the class layout here and both follow.
 *
 * <h3>What is generated</h3>
 *
 * <pre>
 *   function ASD = f(x):          if x &gt; 3:          class A(x):
 *      |                             |                   function base(x):
 *   fnend                         iend                      # define base variables here
 *                                                        fnend
 *                                                     
 *                                                        function info():
 *                                                           # define the fundamental information here
 *                                                        fnend
 *                                                     csend
 * </pre>
 *
 * Three spaces per level throughout. The class body's placeholder in
 * {@code base} is returned as a selection, so the user's first keystroke
 * replaces it.
 */
public final class NcBlockTemplates {

    private NcBlockTemplates() {
    }

    /** Spaces per indentation level. */
    public static final int INDENT_SIZE = 3;

    /** One indentation level. */
    public static final String INDENT = " ".repeat(INDENT_SIZE);

    /** Placeholder written inside a class's {@code base} function. */
    public static final String BASE_PLACEHOLDER = "# define base variables here";

    /** Placeholder written inside a class's {@code info} function. */
    public static final String INFO_PLACEHOLDER = "# define the fundamental information here";

    /** Placeholder written inside a function created from the New menu. */
    public static final String FUNCTION_PLACEHOLDER = "# operation for mapping input and output args";

    /**
     * When true, {@code class A(x, y):} generates {@code function base(x, y):};
     * when false, {@code base} is always generated with empty parentheses.
     */
    public static final boolean COPY_CLASS_ARGS_INTO_BASE = true;

    /**
     * Text to insert directly after a header's colon, plus where the caret or
     * selection should land. Offsets are relative to the start of
     * {@link #text()}.
     */
    public static final class Skeleton {
        private final String text;
        private final int selectionStart;
        private final int selectionEnd;

        private Skeleton(String text, int selectionStart, int selectionEnd) {
            this.text = text;
            this.selectionStart = selectionStart;
            this.selectionEnd = selectionEnd;
        }

        /** @return the text to insert after the colon */
        public String text() {
            return text;
        }

        /** @return where the caret goes (start of the selection) */
        public int selectionStart() {
            return selectionStart;
        }

        /** @return end of the selection; equal to the start for a plain caret */
        public int selectionEnd() {
            return selectionEnd;
        }
    }

    /**
     * The body and closer for a freshly completed header.
     *
     * @param header the header on the line being completed; must open a block
     * @param indent the header line's leading spaces
     * @return the skeleton, or null when the header opens no block
     */
    public static Skeleton bodyFor(BlockHeaderGrammar.Header header, String indent) {
        if (header == null || !header.kind().opensBlock()) {
            return null;
        }
        if (header.kind() == BlockHeaderGrammar.Kind.CLASS) {
            return classBody(indent, header.parameters());
        }
        String inner = indent + INDENT;
        String text = "\n" + inner + "\n" + indent + header.kind().closer();
        int caret = 1 + inner.length();
        return new Skeleton(text, caret, caret);
    }

    /**
     * @param indent     the class header's leading spaces
     * @param parameters the class's parameters
     * @return the {@code base} / {@code info} / {@code csend} body
     */
    public static Skeleton classBody(String indent, List<String> parameters) {
        String level1 = indent + INDENT;
        String level2 = level1 + INDENT;
        String baseArgs = COPY_CLASS_ARGS_INTO_BASE && parameters != null
                ? String.join(", ", parameters)
                : "";

        StringBuilder text = new StringBuilder();
        text.append('\n').append(level1).append("function base(").append(baseArgs).append("):");
        text.append('\n').append(level2);
        int placeholderStart = text.length();
        text.append(BASE_PLACEHOLDER);
        int placeholderEnd = text.length();
        text.append('\n').append(level1).append("fnend");
        text.append('\n');
        text.append('\n').append(level1).append("function info():");
        text.append('\n').append(level2).append(INFO_PLACEHOLDER);
        text.append('\n').append(level1).append("fnend");
        text.append('\n').append(indent).append("csend");

        return new Skeleton(text.toString(), placeholderStart, placeholderEnd);
    }

    /** @return the whole-file template for Home &rarr; New &rarr; function */
    public static String functionFileTemplate() {
        return "function [output_arg] = FunctionName(input_args):\n"
                + INDENT + FUNCTION_PLACEHOLDER + "\n"
                + "fnend\n";
    }

    /** @return the whole-file template for Home &rarr; New &rarr; class */
    public static String classFileTemplate() {
        return "class ClassName(input_args):"
                + classBody("", List.of("input_args")).text()
                + "\n";
    }
}
