package language.language_ui.handler;

import java.util.List;

import language.syntax.syntax_checker.structure.BlockHeaderGrammar;

/**
 * The one source of Neural Code block skeletons.
 *
 * <p>
 * Used by the editor's autofill (a header completed with {@code :}) and by the
 * Home ribbon's New &rarr; function / class menu, so both always write exactly
 * the same code. Change a placeholder or the class layout here and both follow.
 *
 * <h3>What is generated</h3>
 *
 * <pre>
 *   function ASD = f(x):          if x &gt; 3:          class A():
 *      |                             |                   function base(value=0):
 *   fnend                         iend                      base.value = value;
 *                                                        fnend
 *                                                     csend
 * </pre>
 *
 * Three spaces per level throughout. The constructor's body line is returned
 * as a selection, so the user's first keystroke replaces it.
 *
 * <h3>What changed (functions and classes)</h3>
 * <ul>
 * <li><b>No {@code info} function any more.</b> {@code X.info} is built in
 * ({@code nc.exe} lists a class's functions with it), and a class may not
 * define a method named {@code info}; the old skeleton wrote one into every
 * new class, which is now an error.</li>
 * <li><b>The class's brackets are not copied into {@code base}.</b> They name
 * the parent class ({@code class Square(Shape):}), not the constructor's
 * inputs.</li>
 * <li><b>Templates show a default value</b> so the feature is found:
 * {@code function y = FunctionName(x, scale=1):} and
 * {@code function base(value=0):}.</li>
 * </ul>
 */
public final class NcBlockTemplates {

    private NcBlockTemplates() {
    }

    /** Spaces per indentation level. */
    public static final int INDENT_SIZE = 3;

    /** One indentation level. */
    public static final String INDENT = " ".repeat(INDENT_SIZE);

    /** The constructor written into a new class: one input with a default. */
    public static final String BASE_HEADER = "function base(value=0):";

    /** The constructor's body line; selected, so the first keystroke replaces it. */
    public static final String BASE_BODY = "base.value = value;";

    /** The header of a function created from the New menu. */
    public static final String FUNCTION_HEADER = "function y = FunctionName(x, scale=1):";

    /** The body of a function created from the New menu. */
    public static final String FUNCTION_BODY = "y = x * scale;";

    /** @deprecated the constructor now has a real body line; see {@link #BASE_BODY}. */
    @Deprecated
    public static final String BASE_PLACEHOLDER = BASE_BODY;

    /** @deprecated classes no longer get an {@code info} function ({@code X.info} is built in). */
    @Deprecated
    public static final String INFO_PLACEHOLDER = "";

    /** @deprecated see {@link #FUNCTION_BODY}. */
    @Deprecated
    public static final String FUNCTION_PLACEHOLDER = FUNCTION_BODY;

    /** @deprecated a class's brackets name its parent, so they are never copied into {@code base}. */
    @Deprecated
    public static final boolean COPY_CLASS_ARGS_INTO_BASE = false;

    /**
     * Text to insert directly after a header's colon, plus where the caret or
     * selection should land. Offsets are relative to the start of
     * {@link #text()}.
     */
    public static final class Skeleton {
        private final String text;
        private final int selectionStart;
        private final int selectionEnd;

        private Skeleton(String text, int selectionStart, int selectionEnd) {
            this.text = text;
            this.selectionStart = selectionStart;
            this.selectionEnd = selectionEnd;
        }

        /** @return the text to insert after the colon */
        public String text() {
            return text;
        }

        /** @return where the caret goes (start of the selection) */
        public int selectionStart() {
            return selectionStart;
        }

        /** @return end of the selection; equal to the start for a plain caret */
        public int selectionEnd() {
            return selectionEnd;
        }
    }

    /**
     * The body and closer for a freshly completed header.
     *
     * @param header the header on the line being completed; must open a block
     * @param indent the header line's leading spaces
     * @return the skeleton, or null when the header opens no block
     */
    public static Skeleton bodyFor(BlockHeaderGrammar.Header header, String indent) {
        if (header == null || !header.kind().opensBlock()) {
            return null;
        }
        if (header.kind() == BlockHeaderGrammar.Kind.CLASS) {
            return classBody(indent, header.parameters());
        }
        String inner = indent + INDENT;
        String text = "\n" + inner + "\n" + indent + header.kind().closer();
        int caret = 1 + inner.length();
        return new Skeleton(text, caret, caret);
    }

    /**
     * @param indent     the class header's leading spaces
     * @param parameters the class's parents; not used in the body (they are
     *                   not the constructor's inputs), kept for callers
     * @return the {@code base} constructor and the {@code csend}
     */
    public static Skeleton classBody(String indent, List<String> parameters) {
        String level1 = indent + INDENT;
        String level2 = level1 + INDENT;

        StringBuilder text = new StringBuilder();
        text.append('\n').append(level1).append(BASE_HEADER);
        text.append('\n').append(level2);
        int bodyStart = text.length();
        text.append(BASE_BODY);
        int bodyEnd = text.length();
        text.append('\n').append(level1).append("fnend");
        text.append('\n').append(indent).append("csend");

        return new Skeleton(text.toString(), bodyStart, bodyEnd);
    }

    /** @return the whole-file template for Home &rarr; New &rarr; function */
    public static String functionFileTemplate() {
        return FUNCTION_HEADER + "\n"
                + INDENT + FUNCTION_BODY + "\n"
                + "fnend\n";
    }

    /** @return the whole-file template for Home &rarr; New &rarr; class */
    public static String classFileTemplate() {
        return "class ClassName():"
                + classBody("", List.of()).text()
                + "\n";
    }
}
