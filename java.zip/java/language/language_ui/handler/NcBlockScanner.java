package language.language_ui.handler;

import java.util.ArrayDeque;
import java.util.Deque;

import language.syntax.syntax_checker.BlockHeaderGrammar;

/**
 * Lightweight block-structure queries the editor needs while the user types.
 *
 * <p>
 * The error checker answers "is this file right?"; this class answers the two
 * questions the keyboard handlers ask about a file that is, by definition,
 * half-written:
 * <ul>
 * <li>{@link #isBlockClosed(String, int)} -- does the header on this line
 * already have its closer? Autofill must not add a second {@code fnend} when
 * the user merely retypes a colon.</li>
 * <li>{@link #closerTargetIndent(String, int, String)} -- how far in should
 * this {@code fnend} sit? The answer is the indentation of the block it
 * closes, not "one level less than wherever the caret happened to be".</li>
 * </ul>
 *
 * <h3>Matching rule</h3>
 * A closer closes the innermost open block of its kind <b>at its own
 * indentation</b>, falling back to the innermost block of its kind at any
 * indentation. The indentation preference is what lets a new {@code if b:}
 * typed inside an existing {@code if a: ... iend} be recognised as still open:
 * the {@code iend} at column 0 belongs to {@code if a}, not to the new block at
 * column 3.
 *
 * <p>
 * Headers are recognised by {@link BlockHeaderGrammar}, the same grammar the
 * checker uses, so the editor and the checker agree on what a block is.
 */
public final class NcBlockScanner {

    private NcBlockScanner() {
    }

    private static final class Open {
        final int line;
        final String closer;
        final int indent;

        Open(int line, String closer, int indent) {
            this.line = line;
            this.closer = closer;
            this.indent = indent;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Line cleaning
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * One physical line with its comment removed and every string body blanked
     * to spaces, character for character. The quote characters stay.
     *
     * <p>
     * Mirrors {@code SourceModel}: {@code "} and {@code '} both delimit strings
     * and only the opening quote can close a literal; {@code #} and {@code \\}
     * start a comment only outside a literal.
     *
     * @param line one physical line
     * @return the masked, comment-free text (not trimmed)
     */
    public static String logicalCode(String line) {
        return clean(line, true);
    }

    /**
     * As {@link #logicalCode(String)} but with string literals kept intact, so
     * offsets line up with the masked view while literal contents survive.
     *
     * @param line one physical line
     * @return the comment-free text (not trimmed)
     */
    public static String codeWithoutComment(String line) {
        return clean(line, false);
    }

    private static String clean(String line, boolean mask) {
        if (line == null || line.isEmpty()) {
            return "";
        }
        StringBuilder out = new StringBuilder(line.length());
        char openQuote = 0;
        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (openQuote != 0) {
                if (ch == openQuote && !isEscaped(line, i)) {
                    openQuote = 0;
                    out.append(ch);
                } else {
                    out.append(mask ? ' ' : ch);
                }
                continue;
            }
            if ((ch == '"' || ch == '\'') && !isEscaped(line, i)) {
                openQuote = ch;
                out.append(ch);
                continue;
            }
            if (ch == '#') {
                break;
            }
            if (ch == '\\' && i + 1 < line.length() && line.charAt(i + 1) == '\\') {
                break;
            }
            out.append(ch);
        }
        return out.toString();
    }

    private static boolean isEscaped(String text, int index) {
        int count = 0;
        for (int i = index - 1; i >= 0 && text.charAt(i) == '\\'; i--) {
            count++;
        }
        return count % 2 != 0;
    }

    /**
     * @param line any text
     * @return the run of leading spaces
     */
    public static String leadingSpaces(String line) {
        if (line == null) {
            return "";
        }
        int length = 0;
        while (length < line.length() && line.charAt(length) == ' ') {
            length++;
        }
        return line.substring(0, length);
    }

    /**
     * @param line one physical line
     * @return the header on it, or null
     */
    public static BlockHeaderGrammar.Header headerOf(String line) {
        return BlockHeaderGrammar.parse(logicalCode(line));
    }

    /**
     * @param line one physical line
     * @return the lower-cased closer word when the line is a closer, else null
     */
    public static String closerOf(String line) {
        String word = BlockHeaderGrammar.firstWord(logicalCode(line).trim());
        return BlockHeaderGrammar.isCloser(word) ? word : null;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Structure queries
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Whether the block opened on {@code openerLine} already has a closer.
     *
     * @param document   the full text, as it will read after the pending edit
     * @param openerLine zero-based line of the header
     * @return true when a closer further down belongs to that header
     */
    public static boolean isBlockClosed(String document, int openerLine) {
        String[] lines = document.split("\n", -1);
        Deque<Open> stack = new ArrayDeque<>();

        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            String closer = closerOf(line);
            if (closer != null) {
                Open closed = closeMatching(stack, closer, leadingSpaces(line).length());
                if (closed != null && closed.line == openerLine) {
                    return true;
                }
                continue;
            }
            BlockHeaderGrammar.Header header = headerOf(line);
            if (header != null && header.kind().opensBlock()) {
                stack.push(new Open(i, header.kind().closer(), leadingSpaces(line).length()));
            }
        }
        return false;
    }

    /**
     * The indentation a closer should sit at: that of the block it closes.
     *
     * @param document   the full text
     * @param closerLine zero-based line holding the closer
     * @param closer     the lower-cased closer word
     * @return the target column, or -1 when no open block expects this closer
     */
    public static int closerTargetIndent(String document, int closerLine, String closer) {
        String[] lines = document.split("\n", -1);
        Deque<Open> stack = new ArrayDeque<>();
        int limit = Math.min(closerLine, lines.length);

        for (int i = 0; i < limit; i++) {
            String line = lines[i];
            String lineCloser = closerOf(line);
            if (lineCloser != null) {
                closeMatching(stack, lineCloser, leadingSpaces(line).length());
                continue;
            }
            BlockHeaderGrammar.Header header = headerOf(line);
            if (header != null && header.kind().opensBlock()) {
                stack.push(new Open(i, header.kind().closer(), leadingSpaces(line).length()));
            }
        }

        // The closer being typed has no trustworthy indentation yet, so the
        // innermost open block of its kind is the one it closes.
        for (Open open : stack) {
            if (open.closer.equals(closer)) {
                return open.indent;
            }
        }
        return -1;
    }

    /**
     * Pops the block this closer ends (plus any unclosed blocks above it).
     *
     * @return the closed block, or null when the closer is orphaned
     */
    private static Open closeMatching(Deque<Open> stack, String closer, int indent) {
        Open nearest = null;
        Open exact = null;
        for (Open open : stack) { // top of stack first
            if (!open.closer.equals(closer)) {
                continue;
            }
            if (nearest == null) {
                nearest = open;
            }
            if (open.indent == indent) {
                exact = open;
                break;
            }
        }
        Open target = exact != null ? exact : nearest;
        if (target == null) {
            return null;
        }
        Open popped;
        do {
            popped = stack.pop();
        } while (popped != target);
        return target;
    }
}
