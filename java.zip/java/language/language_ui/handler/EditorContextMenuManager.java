package language.language_ui.handler;

import org.fxmisc.richtext.CodeArea;

import javafx.geometry.Pos;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.input.ContextMenuEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;

public final class EditorContextMenuManager {

    private static ContextMenu currentOpenMenu = null;

    private EditorContextMenuManager() {
    }

    public static void install(CodeArea editor) {
        installCommon(editor::getSelectedText, editor::cut, editor::copy, editor::paste, editor::isEditable, editor::setEditable,
                editor::setOnContextMenuRequested, editor);
        // Add mouse click handler to close menu when clicking inside editor
        editor.addEventFilter(MouseEvent.MOUSE_PRESSED, e -> closeCurrentMenu());
    }

    public static void install(TextArea editor) {
        installCommon(editor::getSelectedText, editor::cut, editor::copy, editor::paste, editor::isEditable, editor::setEditable,
                editor::setOnContextMenuRequested, editor);
        // Add mouse click handler to close menu when clicking inside editor
        editor.addEventFilter(MouseEvent.MOUSE_PRESSED, e -> closeCurrentMenu());
    }

    private static <T> void installCommon(TextSupplier selectedText,
                                          Action cutAction,
                                          Action copyAction,
                                          Action pasteAction,
                                          BooleanSupplier editableSupplier,
                                          BooleanConsumer editableSetter,
                                          ContextMenuHandler<T> contextMenuHandler,
                                          T editor) {
        contextMenuHandler.set((ContextMenuEvent event) -> {
            // Close any previously open menu
            if (currentOpenMenu != null) {
                currentOpenMenu.hide();
            }
            
            ContextMenu menu = new ContextMenu();
            menu.setStyle("-fx-background-color: white; -fx-background-insets: 0; -fx-padding: 4 0 4 0;"
                    + "-fx-selection-bar: #d9d9d9; -fx-selection-bar-non-focused: #d9d9d9;"
                    + "-fx-selection-bar-text: #4f4f4f;");
            
            // Ensure menu closes when clicking outside or pressing Escape
            menu.setAutoHide(true);
            menu.setHideOnEscape(true);

            MenuItem cut = createMenuItem("Cut", "Ctrl+X");
            MenuItem copy = createMenuItem("Copy", "Ctrl+C");
            MenuItem paste = createMenuItem("Paste", "Ctrl+V");
            MenuItem freeze = createMenuItem("Freeze", "Alt+F");
            MenuItem defreeze = createMenuItem("Defreeze", "Alt+D");

            cut.setDisable(selectedText.get().isEmpty());
            copy.setDisable(selectedText.get().isEmpty());

            cut.setOnAction(e -> cutAction.run());
            copy.setOnAction(e -> copyAction.run());
            paste.setOnAction(e -> pasteAction.run());
            freeze.setOnAction(e -> editableSetter.accept(false));
            defreeze.setOnAction(e -> editableSetter.accept(true));

            freeze.setDisable(!editableSupplier.getAsBoolean());
            defreeze.setDisable(editableSupplier.getAsBoolean());

            menu.getItems().addAll(cut, copy, paste, new SeparatorMenuItem(), freeze, defreeze);
            
            // Track when menu closes
            menu.setOnHidden(e -> {
                if (currentOpenMenu == menu) {
                    currentOpenMenu = null;
                }
            });
            
            currentOpenMenu = menu;
            menu.show(((javafx.scene.Node) editor), event.getScreenX(), event.getScreenY());
            event.consume();
        });
    }

    private static void closeCurrentMenu() {
        if (currentOpenMenu != null) {
            currentOpenMenu.hide();
        }
    }

    private static MenuItem createMenuItem(String labelText, String shortcutText) {
        Label label = new Label(labelText);
        label.setStyle("-fx-text-fill: #4f4f4f; -fx-font-size: 14px;");

        Label shortcut = new Label(shortcutText);
        shortcut.setStyle("-fx-text-fill: #9e9e9e; -fx-font-size: 13px; -fx-padding: 0 0 0 16;");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        HBox row = new HBox(8, label, spacer, shortcut);
        row.setAlignment(Pos.CENTER_LEFT);
        row.setMinWidth(190);
        row.setStyle("-fx-background-color: transparent; -fx-padding: 2 10 2 10;");

        MenuItem item = new MenuItem();
        item.setGraphic(row);
        return item;
    }

    @FunctionalInterface
    private interface Action {
        void run();
    }

    @FunctionalInterface
    private interface TextSupplier {
        String get();
    }

    @FunctionalInterface
    private interface BooleanSupplier {
        boolean getAsBoolean();
    }

    @FunctionalInterface
    private interface BooleanConsumer {
        void accept(boolean value);
    }

    @FunctionalInterface
    private interface ContextMenuHandler<T> {
        void set(javafx.event.EventHandler<ContextMenuEvent> handler);
    }
}