package language.language_ui.handler;

import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Supplier;

import org.fxmisc.richtext.CodeArea;

import javafx.scene.Node;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ContextMenuEvent;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.MouseEvent;
import ui.directory.DirectoryFont;
import ui.directory.DirectoryTreeContextMenu;
import ui.editor.EditorTextOperations;
import ui.editor.search.EditorSearch;

/**
 * The editor's right-click menu.
 *
 * <pre>
 *   Cut                    Ctrl+X
 *   Copy                   Ctrl+C
 *   Paste                  Ctrl+V
 *   ------------------------------
 *   Comment Out            Ctrl+/
 *   Uncomment Out          Ctrl+/
 *   ------------------------------
 *   Search                 Ctrl+F
 *   Replace                Ctrl+H
 * </pre>
 *
 * <h3>Search and Replace</h3>
 * <p>
 * Both open the find / replace bar at the top right of the editor
 * ({@link EditorSearch}); Replace unfolds its Replace row as well. A one-line
 * selection is put into the Find field.
 * </p>
 *
 * <h3>The empty editor area</h3>
 * <p>
 * With no file open, the editor area is an empty tab pane and used to answer a
 * right-click with nothing. {@link #showEmptyAreaMenu} gives it the same menu,
 * with every row disabled except Search, which then searches the root folder.
 * </p>
 *
 * <h3>Font and look: the same as the File Explorer's menu</h3>
 * <p>
 * A {@code ContextMenu} takes its CSS from the node it opens on. Opened on the
 * editor, it inherited the editor's monospaced font -- the {@code .code-area}
 * rule and the editor's inline font style -- which is why this menu looked
 * different from the explorer's. It now gets exactly what the explorer's menu
 * gets: the explorer's style class ({@link DirectoryTreeContextMenu#MENU_CLASS})
 * for its colours in both themes, and the explorer rows' font
 * ({@link DirectoryFont}) applied inline to the menu and every row, which beats
 * anything inherited. The old hard-coded white background and grey text are
 * gone, so the menu also follows the dark theme now.
 * </p>
 *
 * <h3>Shortcuts</h3>
 * <p>
 * Each shortcut is shown at the right of its row through the item's
 * accelerator, as in the explorer. The menu is shown, never attached, so those
 * accelerators are display only and are not registered with the scene; the
 * keys themselves are handled by the editor (Ctrl+X/C/V natively, Ctrl+/ by
 * the key filter in {@code EditorTabFactory}). On macOS they show as Command.
 * </p>
 *
 * <h3>Comment Out / Uncomment Out</h3>
 * <p>
 * These replace the old Freeze / Defreeze, which were never comment commands:
 * they switched the whole editor to read-only and back, and showed Alt+F /
 * Alt+D, keys nothing handled. Both now act on the selected lines, or the
 * caret's line, through {@link EditorTextOperations}:
 * </p>
 * <ul>
 * <li><b>Comment Out</b> adds the {@code \\ } prefix; enabled while at least
 * one line with content in the range has no prefix.</li>
 * <li><b>Uncomment Out</b> removes it; enabled while at least one line in the
 * range carries it.</li>
 * </ul>
 * <p>
 * Both show Ctrl+/, because Ctrl+/ is the one key for both: it comments the
 * lines when they are not all commented and uncomments them when they are.
 * </p>
 */
public final class EditorContextMenuManager {

    /** Ctrl+X, shown on Cut. */
    public static final KeyCombination CUT = new KeyCodeCombination(KeyCode.X, KeyCombination.SHORTCUT_DOWN);

    /** Ctrl+C, shown on Copy. */
    public static final KeyCombination COPY = new KeyCodeCombination(KeyCode.C, KeyCombination.SHORTCUT_DOWN);

    /** Ctrl+V, shown on Paste. */
    public static final KeyCombination PASTE = new KeyCodeCombination(KeyCode.V, KeyCombination.SHORTCUT_DOWN);

    /** Ctrl+/, shown on both Comment Out and Uncomment Out. */
    public static final KeyCombination COMMENT = new KeyCodeCombination(KeyCode.SLASH, KeyCombination.SHORTCUT_DOWN);

    /** Ctrl+F, shown on Search. */
    public static final KeyCombination SEARCH = new KeyCodeCombination(KeyCode.F, KeyCombination.SHORTCUT_DOWN);

    /** Ctrl+H, shown on Replace. */
    public static final KeyCombination REPLACE = new KeyCodeCombination(KeyCode.H, KeyCombination.SHORTCUT_DOWN);

    private static ContextMenu currentOpenMenu = null;

    private EditorContextMenuManager() {
    }

    /**
     * Installs the menu on a {@code .nc} editor.
     *
     * @param editor the CodeArea
     */
    public static void install(CodeArea editor) {
        if (editor == null) {
            return;
        }
        Target target = new Target(
                editor,
                editor::getSelectedText,
                editor::isEditable,
                editor::cut,
                editor::copy,
                editor::paste,
                () -> EditorTextOperations.canCommentOut(editor),
                () -> EditorTextOperations.canUncommentOut(editor),
                () -> EditorTextOperations.commentOutCodeArea(editor),
                () -> EditorTextOperations.uncommentOutCodeArea(editor));
        editor.setOnContextMenuRequested(event -> show(target, event));
        // Close the menu when clicking inside the editor.
        editor.addEventFilter(MouseEvent.MOUSE_PRESSED, e -> closeCurrentMenu());
    }

    /**
     * Installs the menu on a plain-text editor.
     *
     * @param editor the TextArea
     */
    public static void install(TextArea editor) {
        if (editor == null) {
            return;
        }
        Target target = new Target(
                editor,
                editor::getSelectedText,
                editor::isEditable,
                editor::cut,
                editor::copy,
                editor::paste,
                () -> EditorTextOperations.canCommentOut(editor),
                () -> EditorTextOperations.canUncommentOut(editor),
                () -> EditorTextOperations.commentOutTextArea(editor),
                () -> EditorTextOperations.uncommentOutTextArea(editor));
        editor.setOnContextMenuRequested(event -> show(target, event));
        editor.addEventFilter(MouseEvent.MOUSE_PRESSED, e -> closeCurrentMenu());
    }

    // =====================================================================
    // Building and showing
    // =====================================================================

    /**
     * Builds the menu fresh for each right-click, so every row's enabled state
     * reflects the selection and the clipboard at that moment.
     */
    private static void show(Target target, ContextMenuEvent event) {
        closeCurrentMenu();

        String selected = target.selectedText().get();
        boolean hasSelection = selected != null && !selected.isEmpty();
        boolean editable = target.editable().getAsBoolean();

        MenuItem cut = item("Cut", CUT, target.cut());
        MenuItem copy = item("Copy", COPY, target.copy());
        MenuItem paste = item("Paste", PASTE, target.paste());
        MenuItem commentOut = item("Comment Out", COMMENT, target.commentOut());
        MenuItem uncommentOut = item("Uncomment Out", COMMENT, target.uncommentOut());
        MenuItem search = item("Search", SEARCH, () -> EditorSearch.open(false));
        MenuItem replace = item("Replace", REPLACE, () -> EditorSearch.open(true));

        cut.setDisable(!editable || !hasSelection);
        copy.setDisable(!hasSelection);
        paste.setDisable(!editable || !Clipboard.getSystemClipboard().hasString());
        commentOut.setDisable(!editable || !target.canCommentOut().getAsBoolean());
        uncommentOut.setDisable(!editable || !target.canUncommentOut().getAsBoolean());
        replace.setDisable(!editable);

        ContextMenu menu = newMenu();
        menu.getItems().addAll(cut, copy, paste, new SeparatorMenuItem(), commentOut, uncommentOut,
                new SeparatorMenuItem(), search, replace);
        open(menu, target.node(), event);
    }

    /**
     * The right-click menu of the empty editor area, shown while no file is
     * open. It lists the editor's usual rows so the menu looks the same
     * everywhere, but only Search is enabled: there is no text to cut, paste
     * or comment, and Search then looks through the root folder.
     *
     * @param owner    the node the menu opens on (the editor's tab pane)
     * @param event    the right-click
     * @param onSearch what Search does
     */
    public static void showEmptyAreaMenu(Node owner, ContextMenuEvent event, Runnable onSearch) {
        if (owner == null || event == null) {
            return;
        }
        closeCurrentMenu();

        MenuItem cut = item("Cut", CUT, () -> { });
        MenuItem copy = item("Copy", COPY, () -> { });
        MenuItem paste = item("Paste", PASTE, () -> { });
        MenuItem commentOut = item("Comment Out", COMMENT, () -> { });
        MenuItem uncommentOut = item("Uncomment Out", COMMENT, () -> { });
        MenuItem search = item("Search", SEARCH, onSearch == null ? () -> { } : onSearch);
        MenuItem replace = item("Replace", REPLACE, () -> { });
        for (MenuItem off : List.of(cut, copy, paste, commentOut, uncommentOut, replace)) {
            off.setDisable(true);
        }

        ContextMenu menu = newMenu();
        menu.getItems().addAll(cut, copy, paste, new SeparatorMenuItem(), commentOut, uncommentOut,
                new SeparatorMenuItem(), search, replace);
        open(menu, owner, event);
    }

    private static ContextMenu newMenu() {
        ContextMenu menu = new ContextMenu();
        menu.getStyleClass().add(DirectoryTreeContextMenu.MENU_CLASS);
        menu.setAutoHide(true);
        menu.setHideOnEscape(true);
        return menu;
    }

    private static void open(ContextMenu menu, Node owner, ContextMenuEvent event) {
        applyFont(menu);
        menu.setOnHidden(e -> {
            if (currentOpenMenu == menu) {
                currentOpenMenu = null;
            }
        });
        currentOpenMenu = menu;
        menu.show(owner, event.getScreenX(), event.getScreenY());
        event.consume();
    }

    private static void closeCurrentMenu() {
        if (currentOpenMenu != null) {
            currentOpenMenu.hide();
        }
    }

    /**
     * The explorer rows' font, inline on the menu and on every row. Inline is
     * the one kind of rule the editor's inherited monospaced font cannot win
     * against.
     */
    private static void applyFont(ContextMenu menu) {
        String style = DirectoryFont.current().css();
        menu.setStyle(style);
        applyFont(menu.getItems(), style);
    }

    private static void applyFont(List<MenuItem> items, String style) {
        for (MenuItem item : items) {
            item.setStyle(style);
        }
    }

    private static MenuItem item(String label, KeyCombination shortcut, Runnable action) {
        MenuItem item = new MenuItem(label);
        // Display only: the menu is shown, never attached, so this does not
        // register a scene-wide accelerator.
        item.setAccelerator(shortcut);
        item.setOnAction(event -> action.run());
        return item;
    }

    // =====================================================================
    // What the menu acts on
    // =====================================================================

    /**
     * The editor behind a menu, as the handful of operations the menu needs,
     * so one builder serves both the CodeArea and the TextArea.
     */
    private record Target(
            Node node,
            Supplier<String> selectedText,
            BooleanSupplier editable,
            Runnable cut,
            Runnable copy,
            Runnable paste,
            BooleanSupplier canCommentOut,
            BooleanSupplier canUncommentOut,
            Runnable commentOut,
            Runnable uncommentOut) {
    }
}
