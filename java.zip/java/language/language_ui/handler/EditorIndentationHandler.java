package language.language_ui.handler;

import java.util.function.BooleanSupplier;

import org.fxmisc.richtext.CodeArea;

import javafx.scene.control.IndexRange;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import language.syntax.syntax_checker.BlockHeaderGrammar;
import ui.ui_functions.suggestion_functions.SuggestionSettings;

/**
 * Three-space automatic indentation and block autofill for the NC CodeArea.
 *
 * <h3>Bug fixed: Enter after {@code fnend} jumped into the next line</h3>
 * Pressing Enter at the end of {@code fnend} used to land the caret inside the
 * following line ({@code pu|blish}) instead of on a new empty line. The cause
 * was two handlers editing the same text without knowing about each other:
 * <ol>
 * <li>The Enter filter inserted {@code "\n" + indent} and then moved the caret
 * to an offset it had computed <i>before</i> the insert.</li>
 * <li>The insert fired the text listener. The caret had not moved yet, so the
 * text before it still read {@code "   fnend"}, and the closer auto-dedent ran
 * a second time -- removing three more spaces from the {@code fnend} line.</li>
 * <li>Everything after that point shifted left by three characters, so the
 * pre-computed caret offset now pointed three characters past the new empty
 * line: exactly the third position of the next line.</li>
 * </ol>
 * The fix has three parts, any one of which would have prevented the bug:
 * <ul>
 * <li>every edit this class makes runs under a guard the listener honours;</li>
 * <li>the closer dedent is <b>idempotent</b>: it sets the closer to the
 * indentation of the block it closes rather than subtracting a level each time
 * it fires;</li>
 * <li>the caret is placed from the offsets of the edit actually made.</li>
 * </ul>
 *
 * <h3>Enter rules</h3>
 * <ul>
 * <li>after a header ending in {@code :} (including {@code else:} /
 * {@code elseif ...:}): one level deeper;</li>
 * <li>after a closer: the closer is first put at its block's indentation, and
 * the new line takes that same indentation -- 3 spaces after a method's
 * {@code fnend} inside a class, column 0 after {@code csend} or a top-level
 * {@code fnend};</li>
 * <li>anywhere else: the current line's indentation.</li>
 * </ul>
 * Enter always creates a new line; it never moves into an existing one. While
 * the suggestion popup is open, Enter accepts the highlighted row instead.
 *
 * <h3>Autofill on {@code :}</h3>
 * Typing the colon that completes an {@code if}, {@code for}, {@code while},
 * {@code function} or {@code class} header inserts the matching body and closer
 * from {@link NcBlockTemplates}. It happens only when
 * <ul>
 * <li>the colon is typed at the end of the line, outside any string literal
 * and outside any open bracket (so the range colon in {@code [1:10]} never
 * triggers it),</li>
 * <li>the completed header is well formed ({@link BlockHeaderGrammar}),
 * and</li>
 * <li>the block does not already have its closer
 * ({@link NcBlockScanner#isBlockClosed}), so retyping a colon on an existing
 * header never adds a second {@code fnend}.</li>
 * </ul>
 * The colon and the skeleton are two separate undo steps: one Ctrl+Z removes
 * the skeleton and leaves the colon the user typed.
 *
 * <p>
 * Autofill is a user setting ("End auto fill suggestions" in the suggestion
 * popup's menu and in Settings &rarr; Syntax) and is <b>off by default</b>.
 * When it is off, the colon is typed as an ordinary character and Enter still
 * indents the next line one level deeper -- only the closer is not written.
 *
 * <h3>Tab and Shift+Tab</h3>
 * Both snap to the 3-space grid rather than adding or removing a flat three
 * spaces, so a line that is off the grid is brought back onto it:
 *
 * <pre>
 *   text at column 5 (4 spaces)   Tab &rarr; column 7 (6)    Shift+Tab &rarr; column 4 (3)
 *   text at column 4 (3 spaces)   Tab &rarr; column 7 (6)    Shift+Tab &rarr; column 1 (0)
 * </pre>
 *
 * <ul>
 * <li><b>Tab, no selection, caret in the indentation</b> (or on a blank line):
 * the line's indentation moves to the next grid stop.</li>
 * <li><b>Tab, no selection, caret inside the text</b>: spaces are inserted at
 * the caret up to the next grid stop, the usual soft-tab behaviour.</li>
 * <li><b>Tab with a selection</b>: every selected line moves to its own next
 * grid stop; blank lines are left alone. A selection that ends at column 0 of
 * a line does not include that line.</li>
 * <li><b>Shift+Tab</b>: the current or selected lines move back to their
 * previous grid stop, wherever the caret is.</li>
 * <li><b>Popup open</b>: Tab accepts the highlighted suggestion; Shift+Tab
 * closes the popup and dedents.</li>
 * </ul>
 * Each press is a single undo step, however many lines it touched. Shift+Tab
 * is consumed, so it no longer moves keyboard focus out of the editor, and the
 * raw tab character is never inserted.
 */
public final class EditorIndentationHandler {

    public static final int INDENT_SIZE = NcBlockTemplates.INDENT_SIZE;
    private static final String INDENT = NcBlockTemplates.INDENT;

    /** Set while this class is editing, so its own text listener stays quiet. */
    private static final String GUARD_KEY = "ncIndentDedenting";

    /**
     * Editor property holding a {@link BooleanSupplier} that reports whether the
     * suggestion popup is showing. Set by {@code EditorSuggestionHandler}.
     */
    public static final String POPUP_SHOWING_KEY = "nc.suggestionPopupShowing";

    /**
     * Editor property holding a {@link Runnable} that accepts the highlighted
     * suggestion. Set by {@code EditorSuggestionHandler}.
     */
    public static final String POPUP_ACCEPT_KEY = "nc.suggestionPopupAccept";

    /**
     * Editor property holding a {@link Runnable} that closes the suggestion
     * popup without accepting. Set by {@code EditorSuggestionHandler}.
     */
    public static final String POPUP_HIDE_KEY = "nc.suggestionPopupHide";

    private static final String SUBSCRIPT_MODE_KEY = "subscriptMode";
    private static final String SUPERSCRIPT_MODE_KEY = "superscriptMode";

    private EditorIndentationHandler() {
    }

    public static void install(CodeArea editor) {
        editor.addEventFilter(KeyEvent.KEY_PRESSED, event -> {
            if (event.getCode() != KeyCode.ENTER
                    || event.isControlDown()
                    || event.isAltDown()
                    || event.isMetaDown()) {
                return;
            }
            // The filter runs before every key handler, so an open popup has to
            // be served here or Enter would never reach it.
            if (isPopupShowing(editor)) {
                Object accept = editor.getProperties().get(POPUP_ACCEPT_KEY);
                if (accept instanceof Runnable action) {
                    action.run();
                    event.consume();
                }
                return;
            }
            if (handleEnter(editor)) {
                event.consume();
            }
        });

        editor.addEventFilter(KeyEvent.KEY_TYPED, event -> {
            if (!":".equals(event.getCharacter())
                    || event.isControlDown()
                    || event.isAltDown()
                    || event.isMetaDown()) {
                return;
            }
            if (tryAutofill(editor)) {
                event.consume();
            }
        });

        // Tab / Shift+Tab. A filter, so it runs before the CodeArea's own
        // handling and before the scene's focus traversal, which is what used
        // to swallow Shift+Tab.
        editor.addEventFilter(KeyEvent.KEY_PRESSED, event -> {
            if (event.getCode() != KeyCode.TAB
                    || event.isControlDown()
                    || event.isAltDown()
                    || event.isMetaDown()) {
                return;
            }
            event.consume();
            if (isPopupShowing(editor)) {
                if (!event.isShiftDown()) {
                    Object accept = editor.getProperties().get(POPUP_ACCEPT_KEY);
                    if (accept instanceof Runnable action) {
                        action.run();
                    }
                    return;
                }
                Object hide = editor.getProperties().get(POPUP_HIDE_KEY);
                if (hide instanceof Runnable action) {
                    action.run();
                }
            }
            if (isStyledModeActive(editor)) {
                // A subscript / superscript group is being typed; its handlers
                // track offsets that an indent edit would invalidate.
                return;
            }
            if (event.isShiftDown()) {
                shiftLines(editor, false);
            } else {
                handleTab(editor);
            }
        });

        // The KEY_TYPED "\t" that follows every Tab press would otherwise
        // insert a real tab character after our spaces.
        editor.addEventFilter(KeyEvent.KEY_TYPED, event -> {
            if ("\t".equals(event.getCharacter())) {
                event.consume();
            }
        });

        // When a closer is completed, move it to its block's indentation.
        editor.textProperty().addListener((obs, oldText, newText) -> autoDedentCloser(editor));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Tab / Shift+Tab
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Tab without a multi-line selection: re-indent when the caret is in the
     * indentation, soft-tab when it is inside the text.
     */
    private static void handleTab(CodeArea editor) {
        IndexRange selection = editor.getSelection();
        if (selection.getLength() > 0) {
            shiftLines(editor, true);
            return;
        }

        String text = editor.getText();
        int caret = clamp(editor.getCaretPosition(), text.length());
        int lineStart = lineStartOf(text, caret);
        int lineEnd = lineEndOf(text, caret);
        String line = text.substring(lineStart, lineEnd);
        int leadChars = leadingWhitespaceLength(line);

        if (caret - lineStart <= leadChars) {
            // Caret within the indentation (or the line is blank).
            shiftLines(editor, true);
            return;
        }

        int column = caret - lineStart;
        int spaces = nextStop(column) - column;
        runGuarded(editor, () -> {
            editor.getUndoManager().preventMerge();
            editor.insertText(caret, " ".repeat(spaces));
            editor.getUndoManager().preventMerge();
        });
        editor.requestFollowCaret();
    }

    /**
     * Moves every line covered by the caret or selection to its next
     * ({@code indent}) or previous grid stop, as one edit and one undo step,
     * and carries the selection along.
     *
     * @param editor the editor
     * @param indent true for Tab, false for Shift+Tab
     */
    private static void shiftLines(CodeArea editor, boolean indent) {
        String text = editor.getText();
        int anchor = clamp(editor.getAnchor(), text.length());
        int caret = clamp(editor.getCaretPosition(), text.length());
        int selStart = Math.min(anchor, caret);
        int selEnd = Math.max(anchor, caret);

        int blockStart = lineStartOf(text, selStart);
        // A selection dragged to column 0 of the next line does not own that
        // line -- the same rule the comment toggle follows.
        int effectiveEnd = selEnd;
        if (selEnd > selStart && selEnd > blockStart && text.charAt(selEnd - 1) == '\n') {
            effectiveEnd = selEnd - 1;
        }
        int blockEnd = lineEndOf(text, effectiveEnd);
        boolean multiLine = text.substring(blockStart, blockEnd).indexOf('\n') >= 0;

        String[] lines = text.substring(blockStart, blockEnd).split("\n", -1);
        int[] oldLead = new int[lines.length];
        int[] newLead = new int[lines.length];
        StringBuilder rebuilt = new StringBuilder();
        boolean changed = false;

        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            int lead = leadingWhitespaceLength(line);
            int width = indentWidth(line, lead);
            boolean blank = lead == line.length();
            oldLead[i] = lead;

            int target;
            if (blank && multiLine) {
                // Blank lines inside a block selection are left exactly as
                // they are: indenting them would only create trailing spaces.
                target = -1;
            } else if (indent) {
                target = nextStop(width);
            } else {
                target = previousStop(width);
            }

            if (target < 0 || (target == width && lead == width)) {
                newLead[i] = lead;
                rebuilt.append(line);
            } else {
                newLead[i] = target;
                rebuilt.append(" ".repeat(target)).append(line, lead, line.length());
                changed = true;
            }
            if (i < lines.length - 1) {
                rebuilt.append('\n');
            }
        }

        if (!changed) {
            return;
        }

        boolean hasSelection = selEnd > selStart;
        int newAnchor = mapOffset(anchor, blockStart, lines, oldLead, newLead, hasSelection);
        int newCaret = mapOffset(caret, blockStart, lines, oldLead, newLead, hasSelection);
        String replacement = rebuilt.toString();

        runGuarded(editor, () -> {
            editor.getUndoManager().preventMerge();
            editor.replaceText(blockStart, blockEnd, replacement);
            editor.getUndoManager().preventMerge();
            editor.selectRange(newAnchor, newCaret);
        });
        editor.requestFollowCaret();
    }

    /**
     * Where an offset lands after its line's indentation changed.
     * <ul>
     * <li>With a selection, a position at column 0 stays at column 0, so a
     * whole-line selection stays whole; a position inside the old indentation
     * is clamped into the new one.</li>
     * <li>Without a selection, a caret anywhere in the indentation goes to the
     * end of the new indentation, ready to type.</li>
     * <li>A position in the text always moves with the text.</li>
     * </ul>
     */
    private static int mapOffset(int offset, int blockStart, String[] lines,
            int[] oldLead, int[] newLead, boolean hasSelection) {
        if (offset < blockStart) {
            return offset;
        }
        int oldLineStart = blockStart;
        int newLineStart = blockStart;
        for (int i = 0; i < lines.length; i++) {
            int oldLineEnd = oldLineStart + lines[i].length();
            int newLineLength = lines[i].length() - oldLead[i] + newLead[i];
            if (offset <= oldLineEnd) {
                int column = offset - oldLineStart;
                int delta = newLead[i] - oldLead[i];
                int mapped;
                if (!hasSelection && column <= oldLead[i]) {
                    mapped = newLead[i];
                } else if (column == 0) {
                    mapped = 0;
                } else if (column < oldLead[i]) {
                    mapped = Math.max(0, Math.min(column + delta, newLead[i]));
                } else {
                    mapped = column + delta;
                }
                return newLineStart + mapped;
            }
            oldLineStart = oldLineEnd + 1;
            newLineStart = newLineStart + newLineLength + 1;
        }
        // Past the block: shift by the block's total change in length.
        int totalDelta = 0;
        for (int i = 0; i < lines.length; i++) {
            totalDelta += newLead[i] - oldLead[i];
        }
        return offset + totalDelta;
    }

    /** @return the first grid stop strictly after {@code width} */
    static int nextStop(int width) {
        return (Math.max(0, width) / INDENT_SIZE + 1) * INDENT_SIZE;
    }

    /** @return the last grid stop strictly before {@code width}, or 0 */
    static int previousStop(int width) {
        if (width <= 0) {
            return 0;
        }
        return ((width - 1) / INDENT_SIZE) * INDENT_SIZE;
    }

    /** Characters of leading spaces and tabs. */
    private static int leadingWhitespaceLength(String line) {
        int length = 0;
        while (length < line.length() && (line.charAt(length) == ' ' || line.charAt(length) == '\t')) {
            length++;
        }
        return length;
    }

    /**
     * Visual width of the leading whitespace. A stray tab counts as one full
     * level, and is replaced by spaces as soon as the line is re-indented.
     */
    private static int indentWidth(String line, int leadChars) {
        int width = 0;
        for (int i = 0; i < leadChars; i++) {
            width += line.charAt(i) == '\t' ? INDENT_SIZE : 1;
        }
        return width;
    }

    private static boolean isStyledModeActive(CodeArea editor) {
        return Boolean.TRUE.equals(editor.getProperties().get(SUBSCRIPT_MODE_KEY))
                || Boolean.TRUE.equals(editor.getProperties().get(SUPERSCRIPT_MODE_KEY));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Enter
    // ─────────────────────────────────────────────────────────────────────────

    private static boolean handleEnter(CodeArea editor) {
        if (editor.getSelection().getLength() > 0) {
            return false;
        }

        String text = editor.getText();
        int caret = clamp(editor.getCaretPosition(), text.length());
        int lineStart = lineStartOf(text, caret);
        int lineEnd = lineEndOf(text, caret);
        String beforeCaret = text.substring(lineStart, caret);
        String afterCaret = text.substring(caret, lineEnd);

        String currentIndent = NcBlockScanner.leadingSpaces(beforeCaret);
        String logical = NcBlockScanner.logicalCode(beforeCaret).trim();
        String firstWord = BlockHeaderGrammar.firstWord(logical);

        String lineIndent = currentIndent;
        String nextIndent = currentIndent;

        if (BlockHeaderGrammar.isCloser(firstWord) && logical.equalsIgnoreCase(firstWord)) {
            // Settle the closer first, then continue at the same level.
            int target = NcBlockScanner.closerTargetIndent(text, lineIndexOf(text, lineStart), firstWord);
            if (target >= 0) {
                lineIndent = " ".repeat(target);
            }
            nextIndent = lineIndent;
        } else if (logical.endsWith(":")) {
            BlockHeaderGrammar.Header header = BlockHeaderGrammar.parse(logical);
            if (header != null) {
                nextIndent = currentIndent + INDENT;
            }
        }

        // Text that moves to the new line loses its leading spaces; the new
        // line's indentation replaces them.
        int movedSpaces = NcBlockScanner.leadingSpaces(afterCaret).length();

        // One edit, placed from the offsets of that edit. The line's own text is
        // rewritten only when a closer has to move; otherwise the edit starts at
        // the caret, so styling and fold state on the line are left alone.
        boolean reindent = !lineIndent.equals(currentIndent);
        int editStart = reindent ? lineStart : caret;
        String replacement = (reindent ? lineIndent + beforeCaret.substring(currentIndent.length()) : "")
                + "\n"
                + nextIndent;

        runGuarded(editor, () -> {
            editor.replaceText(editStart, caret + movedSpaces, replacement);
            editor.moveTo(editStart + replacement.length());
        });
        editor.requestFollowCaret();
        return true;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Closer dedent
    // ─────────────────────────────────────────────────────────────────────────

    private static void autoDedentCloser(CodeArea editor) {
        if (Boolean.TRUE.equals(editor.getProperties().get(GUARD_KEY))) {
            return;
        }

        String text = editor.getText();
        int caret = editor.getCaretPosition();
        if (caret < 0 || caret > text.length()) {
            return;
        }

        int lineStart = lineStartOf(text, caret);
        String beforeCaret = text.substring(lineStart, caret);
        String closer = beforeCaret.trim().toLowerCase();
        if (!BlockHeaderGrammar.isCloser(closer)) {
            return;
        }
        // Only when the caret sits right after the word, not in the middle of
        // a longer identifier that merely starts with a closer.
        if (caret < text.length() && isIdentifierChar(text.charAt(caret))) {
            return;
        }

        String indent = NcBlockScanner.leadingSpaces(beforeCaret);
        int target = NcBlockScanner.closerTargetIndent(text, lineIndexOf(text, lineStart), closer);
        if (target < 0 || target == indent.length()) {
            // Orphaned closer (left as typed) or already in place. Setting an
            // absolute target rather than subtracting a level is what makes a
            // second, unexpected call harmless.
            return;
        }

        String reindented = " ".repeat(target);
        int newCaret = caret + (target - indent.length());
        runGuarded(editor, () -> {
            editor.replaceText(lineStart, lineStart + indent.length(), reindented);
            editor.moveTo(newCaret);
        });
        editor.requestFollowCaret();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Autofill
    // ─────────────────────────────────────────────────────────────────────────

    private static boolean tryAutofill(CodeArea editor) {
        // User setting, off by default: the colon is then typed normally.
        if (!SuggestionSettings.isEndAutofillEnabled()) {
            return false;
        }
        if (editor.getSelection().getLength() > 0) {
            return false;
        }
        if (Boolean.TRUE.equals(editor.getProperties().get(SUBSCRIPT_MODE_KEY))
                || Boolean.TRUE.equals(editor.getProperties().get(SUPERSCRIPT_MODE_KEY))) {
            return false;
        }

        String text = editor.getText();
        int caret = clamp(editor.getCaretPosition(), text.length());
        int lineStart = lineStartOf(text, caret);
        int lineEnd = lineEndOf(text, caret);
        String beforeCaret = text.substring(lineStart, caret);
        String afterCaret = text.substring(caret, lineEnd);

        // The colon must end the line (trailing spaces are fine).
        if (!afterCaret.isBlank()) {
            return false;
        }

        String logicalBefore = NcBlockScanner.logicalCode(beforeCaret);
        // Inside an open string literal (or a comment) the colon is text, not
        // syntax: the masked view of the line then does not end with it.
        boolean colonIsCode = NcBlockScanner.logicalCode(beforeCaret + ":").trim().endsWith(":");
        if (!colonIsCode) {
            return false;
        }
        // A second colon ('if x::') is a typo, not a header being completed.
        if (logicalBefore.trim().endsWith(":")) {
            return false;
        }
        // Inside an open bracket the colon is a range separator: 'for i = [1:'.
        if (!bracketsClosed(logicalBefore)) {
            return false;
        }

        BlockHeaderGrammar.Header header = BlockHeaderGrammar.parse(logicalBefore.trim() + ":");
        if (header == null || !header.kind().opensBlock() || !header.isValid()) {
            return false;
        }

        String prospective = text.substring(0, caret) + ":" + text.substring(caret);
        int headerLine = lineIndexOf(text, lineStart);
        if (NcBlockScanner.isBlockClosed(prospective, headerLine)) {
            return false;
        }

        String indent = NcBlockScanner.leadingSpaces(beforeCaret);
        NcBlockTemplates.Skeleton skeleton = NcBlockTemplates.bodyFor(header, indent);
        if (skeleton == null) {
            return false;
        }

        int bodyStart = caret + 1;
        runGuarded(editor, () -> {
            editor.getUndoManager().preventMerge();
            editor.insertText(caret, ":");
            editor.getUndoManager().preventMerge();
            editor.insertText(bodyStart, skeleton.text());
            editor.getUndoManager().preventMerge();

            int selectionStart = bodyStart + skeleton.selectionStart();
            int selectionEnd = bodyStart + skeleton.selectionEnd();
            if (selectionEnd > selectionStart) {
                // Anchor at the end, caret at the start, so the first keystroke
                // replaces the placeholder and anything reading "text before
                // the caret" sees only the indentation.
                editor.selectRange(selectionEnd, selectionStart);
            } else {
                editor.moveTo(selectionStart);
            }
        });
        editor.requestFollowCaret();
        return true;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Helpers
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * True while this class is making one of its own edits (Enter, Tab,
     * Shift+Tab, closer dedent, autofill). The suggestion trigger uses it to
     * stay closed: re-indenting a line is not the user typing a word.
     *
     * @param editor the editor
     * @return whether an indentation edit is in progress
     */
    public static boolean isApplyingEdit(CodeArea editor) {
        return editor != null && Boolean.TRUE.equals(editor.getProperties().get(GUARD_KEY));
    }

    private static boolean isPopupShowing(CodeArea editor) {
        Object supplier = editor.getProperties().get(POPUP_SHOWING_KEY);
        return supplier instanceof BooleanSupplier showing && showing.getAsBoolean();
    }

    private static void runGuarded(CodeArea editor, Runnable edit) {
        Object previous = editor.getProperties().put(GUARD_KEY, Boolean.TRUE);
        try {
            edit.run();
        } finally {
            if (previous == null) {
                editor.getProperties().remove(GUARD_KEY);
            } else {
                editor.getProperties().put(GUARD_KEY, previous);
            }
        }
    }

    private static int clamp(int value, int max) {
        return Math.max(0, Math.min(value, max));
    }

    private static int lineStartOf(String text, int caret) {
        if (caret <= 0) {
            return 0;
        }
        return text.lastIndexOf('\n', caret - 1) + 1;
    }

    private static int lineEndOf(String text, int caret) {
        int end = text.indexOf('\n', caret);
        return end < 0 ? text.length() : end;
    }

    private static int lineIndexOf(String text, int offset) {
        int count = 0;
        for (int i = 0; i < offset && i < text.length(); i++) {
            if (text.charAt(i) == '\n') {
                count++;
            }
        }
        return count;
    }

    /**
     * True when every bracket in the masked text is closed. Round and square
     * brackets may pair with each other (NC's interval forms), so only the depth
     * is tracked.
     */
    private static boolean bracketsClosed(String masked) {
        int depth = 0;
        for (int i = 0; i < masked.length(); i++) {
            char ch = masked.charAt(i);
            if (ch == '(' || ch == '[' || ch == '{') {
                depth++;
            } else if (ch == ')' || ch == ']' || ch == '}') {
                depth--;
                if (depth < 0) {
                    return false;
                }
            }
        }
        return depth == 0;
    }

    private static boolean isIdentifierChar(char ch) {
        return Character.isLetterOrDigit(ch) || ch == '_';
    }
}
