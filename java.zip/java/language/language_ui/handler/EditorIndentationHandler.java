package language.language_ui.handler;

import java.util.Set;

import org.fxmisc.richtext.CodeArea;

import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;

/** Adds three-space automatic indentation to the NC CodeArea editor. */
public final class EditorIndentationHandler {
    public static final int INDENT_SIZE = 3;
    private static final String INDENT = " ".repeat(INDENT_SIZE);
    private static final Set<String> CLOSERS = Set.of("iend", "fend", "wend", "fnend", "csend");

    private EditorIndentationHandler() {
    }

    public static void install(CodeArea editor) {
        editor.addEventFilter(KeyEvent.KEY_PRESSED, event -> {
            if (event.getCode() == KeyCode.ENTER
                    && !event.isControlDown()
                    && !event.isAltDown()
                    && !event.isMetaDown()
                    && handleEnter(editor)) {
                event.consume();
            }
        });

        // When a closer is completed, move it back by one indentation level.
        editor.textProperty().addListener((obs, oldText, newText) -> autoDedentCloser(editor));
    }

    private static boolean handleEnter(CodeArea editor) {
        if (editor.getSelection().getLength() > 0) {
            return false;
        }

        int caret = editor.getCaretPosition();
        String text = editor.getText();
        int lineStart = text.lastIndexOf('\n', Math.max(0, caret - 1)) + 1;
        String beforeCaret = text.substring(lineStart, caret);
        String logical = stripTrailingComment(beforeCaret).trim();

        String currentIndent = leadingSpaces(beforeCaret);
        String nextIndent = currentIndent;
        if (isBlockOpener(logical)) {
            nextIndent += INDENT;
        }

        editor.insertText(caret, "\n" + nextIndent);
        editor.moveTo(caret + 1 + nextIndent.length());
        editor.requestFollowCaret();
        return true;
    }

    private static void autoDedentCloser(CodeArea editor) {
        if (Boolean.TRUE.equals(editor.getProperties().get("ncIndentDedenting"))) {
            return;
        }

        int caret = editor.getCaretPosition();
        String text = editor.getText();
        if (caret < 0 || caret > text.length()) {
            return;
        }

        int lineStart = text.lastIndexOf('\n', Math.max(0, caret - 1)) + 1;
        String beforeCaret = text.substring(lineStart, caret);
        String trimmed = beforeCaret.trim().toLowerCase();
        if (!CLOSERS.contains(trimmed)) {
            return;
        }

        String indent = leadingSpaces(beforeCaret);
        if (indent.length() < INDENT_SIZE || indent.length() % INDENT_SIZE != 0) {
            return;
        }

        String reduced = indent.substring(0, indent.length() - INDENT_SIZE);
        editor.getProperties().put("ncIndentDedenting", Boolean.TRUE);
        try {
            editor.replaceText(lineStart, lineStart + indent.length(), reduced);
            editor.moveTo(caret - INDENT_SIZE);
            editor.requestFollowCaret();
        } finally {
            editor.getProperties().remove("ncIndentDedenting");
        }
    }

    private static boolean isBlockOpener(String logical) {
        if (!logical.endsWith(":")) {
            return false;
        }
        String word = firstWord(logical);
        return Set.of("if", "else", "elseif", "elif", "for", "while", "function", "class").contains(word);
    }

    private static String firstWord(String line) {
        int end = 0;
        while (end < line.length()) {
            char ch = line.charAt(end);
            if (!Character.isLetter(ch) && ch != '_') {
                break;
            }
            end++;
        }
        return line.substring(0, end).toLowerCase();
    }

    private static String leadingSpaces(String line) {
        int length = 0;
        while (length < line.length() && line.charAt(length) == ' ') {
            length++;
        }
        return line.substring(0, length);
    }

    private static String stripTrailingComment(String line) {
        boolean inSingleQuote = false;
        boolean inDoubleQuote = false;
        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (ch == '"' && !isEscaped(line, i) && !inSingleQuote) {
                inDoubleQuote = !inDoubleQuote;
            } else if (ch == '\'' && !isEscaped(line, i) && !inDoubleQuote) {
                inSingleQuote = !inSingleQuote;
            } else if (!inSingleQuote && !inDoubleQuote && ch == '#') {
                return line.substring(0, i);
            }
        }
        return line;
    }

    private static boolean isEscaped(String text, int index) {
        int count = 0;
        for (int i = index - 1; i >= 0 && text.charAt(i) == '\\'; i--) {
            count++;
        }
        return count % 2 != 0;
    }
}
