package language.language_ui.handler;

import language.replace.Greek;
import language.replace.Malayalam;
import language.replace.Sanskrit;
import language.replace.Tamil;
import language.replace.Telugu;
import language.replace.Uniconstant;

final class SymbolReplacer {

    private SymbolReplacer() {
    }

    static String replaceSymbols(String text) {
        String replaced = replaceGreekSymbols(text);
        for (var e : Tamil.TAMIL_VOWEL_MAP.entrySet()) {
            replaced = replaced.replace(e.getKey(), e.getValue());
        }
        for (var e : Tamil.TAMIL_CONSONANT_MAP.entrySet()) {
            replaced = replaced.replace(e.getKey(), e.getValue());
        }
        for (var e : Sanskrit.SYMBOL_MAP.entrySet()) {
            replaced = replaced.replace(e.getKey(), e.getValue());
        }
        for (var e : Malayalam.MALAYALAM_VOWEL_MAP.entrySet()) {
            replaced = replaced.replace(e.getKey(), e.getValue());
        }
        for (var e : Malayalam.MALAYALAM_CONSONANT_MAP.entrySet()) {
            replaced = replaced.replace(e.getKey(), e.getValue());
        }
        for (var e : Telugu.TELUGU_VOWEL_MAP.entrySet()) {
            replaced = replaced.replace(e.getKey(), e.getValue());
        }
        for (var e : Telugu.TELUGU_CONSONANT_MAP.entrySet()) {
            replaced = replaced.replace(e.getKey(), e.getValue());
        }
        for (var e : Uniconstant.SYMBOL_MAP.entrySet()) {
            replaced = replaced.replace(e.getKey(), e.getValue());
        }
        return replaced;
    }

    static String replaceGreekSymbols(String text) {
        String replaced = text;
        for (var e : Greek.SYMBOL_MAP.entrySet()) {
            replaced = replaced.replace(e.getKey(), e.getValue());
        }
        return replaced;
    }

    static boolean shouldReplaceGreekSuperscript(String lineText) {
        for (var e : Greek.SYMBOL_MAP.entrySet()) {
            if (lineText.endsWith("^" + e.getKey())) {
                return true;
            }
        }
        return false;
    }

    static String getGreekSuperscriptReplacement(String lineText) {
        for (var e : Greek.SYMBOL_MAP.entrySet()) {
            if (lineText.endsWith("^" + e.getKey())) {
                return e.getKey();
            }
        }
        return null;
    }

    static boolean shouldReplaceGreekSymbol(String lineText) {
        for (var e : Greek.SYMBOL_MAP.entrySet()) {
            if (lineText.endsWith(e.getKey())) {
                return true;
            }
        }
        return false;
    }

    static String getGreekSymbolReplacement(String lineText) {
        for (var e : Greek.SYMBOL_MAP.entrySet()) {
            if (lineText.endsWith(e.getKey())) {
                return e.getKey();
            }
        }
        return null;
    }

    static boolean shouldReplaceTamilVowel(String lineText) {
        for (var e : Tamil.TAMIL_VOWEL_MAP.entrySet()) {
            if (lineText.endsWith(e.getKey())) {
                return true;
            }
        }
        return false;
    }

    static String getTamilVowelReplacement(String lineText) {
        for (var e : Tamil.TAMIL_VOWEL_MAP.entrySet()) {
            if (lineText.endsWith(e.getKey())) {
                return e.getKey();
            }
        }
        return null;
    }

    static boolean shouldReplaceTamilConsonant(String lineText) {
        for (var e : Tamil.TAMIL_CONSONANT_MAP.entrySet()) {
            if (lineText.endsWith(e.getKey())) {
                return true;
            }
        }
        return false;
    }

    static String getTamilConsonantReplacement(String lineText) {
        for (var e : Tamil.TAMIL_CONSONANT_MAP.entrySet()) {
            if (lineText.endsWith(e.getKey())) {
                return e.getKey();
            }
        }
        return null;
    }


    static boolean shouldReplaceSanskritSymbol(String lineText) {
        for (var e : Sanskrit.SYMBOL_MAP.entrySet()) {
            if (lineText.endsWith(e.getKey())) {
                return true;
            }
        }
        return false;
    }

    static String getSanskritSymbolReplacement(String lineText) {
        for (var e : Sanskrit.SYMBOL_MAP.entrySet()) {
            if (lineText.endsWith(e.getKey())) {
                return e.getKey();
            }
        }
        return null;
    }

    static boolean shouldReplaceMalayalamVowel(String lineText) {
        for (var e : Malayalam.MALAYALAM_VOWEL_MAP.entrySet()) {
            if (lineText.endsWith(e.getKey())) {
                return true;
            }
        }
        return false;
    }

    static String getMalayalamVowelReplacement(String lineText) {
        for (var e : Malayalam.MALAYALAM_VOWEL_MAP.entrySet()) {
            if (lineText.endsWith(e.getKey())) {
                return e.getKey();
            }
        }
        return null;
    }

    static boolean shouldReplaceMalayalamConsonant(String lineText) {
        for (var e : Malayalam.MALAYALAM_CONSONANT_MAP.entrySet()) {
            if (lineText.endsWith(e.getKey())) {
                return true;
            }
        }
        return false;
    }

    static String getMalayalamConsonantReplacement(String lineText) {
        for (var e : Malayalam.MALAYALAM_CONSONANT_MAP.entrySet()) {
            if (lineText.endsWith(e.getKey())) {
                return e.getKey();
            }
        }
        return null;
    }

    static boolean shouldReplaceTeluguVowel(String lineText) {
        for (var e : Telugu.TELUGU_VOWEL_MAP.entrySet()) {
            if (lineText.endsWith(e.getKey())) {
                return true;
            }
        }
        return false;
    }

    static String getTeluguVowelReplacement(String lineText) {
        for (var e : Telugu.TELUGU_VOWEL_MAP.entrySet()) {
            if (lineText.endsWith(e.getKey())) {
                return e.getKey();
            }
        }
        return null;
    }

    static boolean shouldReplaceTeluguConsonant(String lineText) {
        for (var e : Telugu.TELUGU_CONSONANT_MAP.entrySet()) {
            if (lineText.endsWith(e.getKey())) {
                return true;
            }
        }
        return false;
    }

    static String getTeluguConsonantReplacement(String lineText) {
        for (var e : Telugu.TELUGU_CONSONANT_MAP.entrySet()) {
            if (lineText.endsWith(e.getKey())) {
                return e.getKey();
            }
        }
        return null;
    }
    static boolean shouldReplaceUniconstant(String lineText) {
        for (var e : Uniconstant.SYMBOL_MAP.entrySet()) {
            if (lineText.endsWith(e.getKey())) {
                return true;
            }
        }
        return false;
    }

    static String getUniconstantReplacement(String lineText) {
        for (var e : Uniconstant.SYMBOL_MAP.entrySet()) {
            if (lineText.endsWith(e.getKey())) {
                return e.getKey();
            }
        }
        return null;
    }
}

