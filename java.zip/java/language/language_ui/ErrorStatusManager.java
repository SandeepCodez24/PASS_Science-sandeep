package language.language_ui;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import org.fxmisc.richtext.CodeArea;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.OverrunStyle;
import javafx.scene.control.PopupControl;
import javafx.scene.control.TextInputControl;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.util.Duration;
import language.syntax.syntax_checker.ErrorChecker;
import language.syntax.syntax_checker.ErrorClassifier;
import ui.design.Dim;
import ui.design.Typography;
import ui.design.UIScale;

/**
 * Error and warning presentation: the footer counters and the left gutter
 * marker with its tooltip.
 *
 * <h3>What changed (tooltip font and shape)</h3>
 * <ul>
 * <li><b>The tooltip used the editor's monospaced font.</b> A tooltip inherits
 * its font from the node it is installed on, and the gutter sits inside the
 * code editor, whose inline style is the code family. The role styles only
 * named a family when it differed from the UI family, so nothing overrode the
 * inherited one. Every label in the tooltip -- and the tooltip itself -- now
 * names the system UI family explicitly, at the File Directory's size for the
 * heading and message and the breadcrumb's size for the caption.</li>
 * <li><b>The dark-theme card grew tall.</b> Messages were wrapping labels, and
 * a wrapping label reports its preferred height for a width the popup has not
 * given it yet, which a theme's own {@code .tooltip} rules could turn into a
 * very tall, mostly empty card. Messages are now broken into lines here, by
 * measuring the text in its real font against
 * {@code Dim.Editor.ISSUE_TOOLTIP_MAX_WIDTH}; the labels never wrap, and the
 * card and its content are pinned to their preferred size. Both themes now
 * get the same compact card that hugs its text.</li>
 * <li><b>The bar is 3 px tall</b> ({@code Dim.Editor.ISSUE_BAR_HEIGHT}).</li>
 * </ul>
 *
 * <h3>What changed (issue bar and readable tooltip)</h3>
 * <ul>
 * <li><b>The dot is now a bar.</b> The round {@code ●} glyph is replaced by a
 * short horizontal dash, {@code Dim.Editor.ISSUE_BAR_WIDTH} ×
 * {@code ISSUE_BAR_HEIGHT} (8 × 3 px), crimson for an error and amber for a
 * warning. It is a {@link Region} coloured from the theme CSS
 * ({@code .gutter-issue-bar-error} / {@code -warning} in
 * {@code editor_*.css}), not a text glyph, so its size no longer depends on a
 * font.</li>
 * <li><b>The whole error column answers the pointer.</b> A 2-pixel bar is too
 * small to aim at, so the bar sits in a cell that fills the error column and
 * the tooltip is installed on that cell (and, as before, on the line
 * number).</li>
 * <li><b>The tooltip is readable and says which kind of error it is.</b> It
 * was JavaFX's default near-black box with 10 px text. It now carries a "Line
 * n" caption and, for every category on the line, a heading ("Syntax Error",
 * "Undefined Variable Error", ...) with the explanation beneath, beside a
 * stripe in the issue's colour. Colours come from
 * {@code .nc-issue-tooltip} in the theme CSS, so it follows light and dark;
 * fonts are the {@code EDITOR_ISSUE_*} roles in {@link Typography}; spacing is
 * in {@code Editor_dim}. It opens after
 * {@code Dim.Editor.ISSUE_TOOLTIP_DELAY_MS} instead of a full second.</li>
 * <li><b>One source of truth.</b> What the gutter shows comes from
 * {@link ErrorClassifier}, the same classification the Command Window prints
 * when a run is refused and the counters count, so the three never
 * disagree.</li>
 * <li><b>Counter tooltips list the four categories</b> instead of the nine
 * analyzer names.</li>
 * </ul>
 *
 * <h3>Kept from earlier versions</h3>
 * <ul>
 * <li>{@link #createLineNumberGraphic(CodeArea, int)} still returns an
 * {@link HBox} of marker + number and stores the number under
 * {@link #LINE_NUMBER_KEY}; {@code ui.editor.EditorGutter} rearranges it into
 * fixed columns exactly as before.</li>
 * <li>The analysis runs once per document, not once per rendered line: the
 * classification is cached against the text that produced it.</li>
 * <li>The {@code error-line} paragraph class is added and removed without
 * touching any other class, so folds survive typing.</li>
 * </ul>
 */
public final class ErrorStatusManager {

    private static final String ERROR_BUTTON_KEY = "errorButton";
    private static final String WARNING_BUTTON_KEY = "warningButton";

    /** The one paragraph style class this class owns. */
    private static final String ERROR_LINE = "error-line";

    /**
     * Key under which {@link #createLineNumberGraphic} stores the line-number
     * label in the returned HBox's properties, so the gutter can find it
     * without relying on child order.
     */
    public static final String LINE_NUMBER_KEY = "gutter.lineNumber";

    /**
     * Style class on the line-number label. Its colour comes from this class
     * in {@code themes/editorColor/editor_*.css}.
     */
    public static final String LINE_NUMBER_STYLE_CLASS = "gutter-line-number";

    // ---- style classes; colours for all of them are in editor_*.css ----------

    /** The cell filling the error column; transparent, it only catches the pointer. */
    public static final String ISSUE_CELL_STYLE_CLASS = "gutter-issue-cell";
    /** The bar itself. */
    public static final String ISSUE_BAR_STYLE_CLASS = "gutter-issue-bar";
    /** Added to the bar on an error line: crimson. */
    public static final String ISSUE_BAR_ERROR_STYLE_CLASS = "gutter-issue-bar-error";
    /** Added to the bar on a warning-only line: amber. */
    public static final String ISSUE_BAR_WARNING_STYLE_CLASS = "gutter-issue-bar-warning";

    /** On the Tooltip: replaces the default dark box with the themed card. */
    public static final String TOOLTIP_STYLE_CLASS = "nc-issue-tooltip";
    private static final String CAPTION_STYLE_CLASS = "nc-issue-caption";
    private static final String TITLE_STYLE_CLASS = "nc-issue-title";
    private static final String MESSAGE_STYLE_CLASS = "nc-issue-message";
    private static final String ACCENT_STYLE_CLASS = "nc-issue-accent";

    private ErrorStatusManager() {
        // Utility class
    }

    // =====================================================================
    // Status box (top right)
    // =====================================================================

    public static HBox createTopRightStatusBox() {
        Label errorButton = createStatusLabel("\u2716 0");
        Label warningButton = createStatusLabel("\u26A0 0");

        applyErrorButtonStyle(errorButton, 0);
        applyWarningButtonStyle(warningButton, 0);

        errorButton.setTooltip(new Tooltip(emptyCategoryText()));
        warningButton.setTooltip(new Tooltip("Warnings: 0"));

        HBox box = new HBox(8, errorButton, warningButton);
        box.setAlignment(Pos.CENTER_RIGHT);
        box.getProperties().put(ERROR_BUTTON_KEY, errorButton);
        box.getProperties().put(WARNING_BUTTON_KEY, warningButton);
        return box;
    }

    // =====================================================================
    // Gutter cell
    // =====================================================================

    /**
     * Builds the left gutter cell for one line: the issue marker followed by
     * the line number.
     *
     * <p>
     * The marker is a cell that fills the error column; on a line with issues
     * it holds the crimson (error) or amber (warning) bar and carries the
     * tooltip. {@code ui.editor.EditorGutter} lays the returned HBox out into
     * fixed columns and appends the fold marker; use
     * {@link #lineNumberOf(HBox)} to find the number label in it.
     *
     * @param editor the editor
     * @param index  zero-based paragraph index
     * @return the gutter cell
     */
    public static HBox createLineNumberGraphic(CodeArea editor, int index) {
        Label lineNumber = new Label(String.valueOf(index + 1));
        lineNumber.setMinWidth(18);
        lineNumber.setAlignment(Pos.CENTER_RIGHT);

        // One cached classification for the whole document, queried per line.
        ErrorClassifier.Classification classification = ErrorClassifier.classify(editor.getText());
        List<ErrorClassifier.Issue> issues = classification.issuesOn(index);

        StackPane marker = new StackPane();
        marker.getStyleClass().add(ISSUE_CELL_STYLE_CLASS);
        marker.setAlignment(Pos.CENTER);
        marker.setMinWidth(Dim.Editor.ISSUE_BAR_WIDTH);
        // Grows to fill the error column and the row height, so the whole
        // column -- not just the 2-pixel bar -- opens the tooltip.
        marker.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
        marker.setPickOnBounds(true);

        if (issues.isEmpty()) {
            lineNumber.setTooltip(null);
        } else {
            boolean error = classification.isErrorLine(index);
            marker.getChildren().add(createIssueBar(error));

            Tooltip tooltip = createIssueTooltip(index, issues);
            Tooltip.install(marker, tooltip);
            lineNumber.setTooltip(tooltip);
        }

        // Font only. The colour is in the theme CSS (.gutter-line-number), so
        // the gutter can change the size here without losing it.
        lineNumber.getStyleClass().add(LINE_NUMBER_STYLE_CLASS);
        lineNumber.setStyle("-fx-font-family: " + Typography.familyCss(Typography.uiFamily()) + ";"
                + " -fx-font-size: "
                + UIScale.fmt(Typography.size(Typography.Role.EDITOR_LINE_NUMBER)) + "px;");

        HBox gutter = new HBox(Dim.Editor.GUTTER_COLUMN_SPACING, marker, lineNumber);
        gutter.setAlignment(Pos.CENTER_RIGHT);
        // Default gap for a caller that uses this cell as it is. EditorGutter
        // replaces the padding with its own fixed layout.
        gutter.setPadding(new Insets(0, 20, 0, 0));
        gutter.getStyleClass().add("line-number-gutter");
        gutter.getProperties().put(LINE_NUMBER_KEY, lineNumber);
        return gutter;
    }

    /**
     * @param error true for the crimson error bar, false for the amber warning bar
     * @return the fixed-size bar
     */
    private static Region createIssueBar(boolean error) {
        Region bar = new Region();
        bar.getStyleClass().addAll(ISSUE_BAR_STYLE_CLASS,
                error ? ISSUE_BAR_ERROR_STYLE_CLASS : ISSUE_BAR_WARNING_STYLE_CLASS);
        double width = Dim.Editor.ISSUE_BAR_WIDTH;
        double height = Dim.Editor.ISSUE_BAR_HEIGHT;
        bar.setMinSize(width, height);
        bar.setPrefSize(width, height);
        bar.setMaxSize(width, height);
        // The cell answers the pointer; the bar must not steal it.
        bar.setMouseTransparent(true);
        return bar;
    }

    /**
     * The themed tooltip for one line:
     *
     * <pre>
     *   Line 9
     *   ▌ Unassigned Variable Error
     *   ▌ 'DD' is declared but never given a value (nothing after '=')
     *   ▌ Syntax Error
     *   ▌ ...
     * </pre>
     *
     * @param index  zero-based line index
     * @param issues the line's issues, at least one
     * @return the tooltip
     */
    private static Tooltip createIssueTooltip(int index, List<ErrorClassifier.Issue> issues) {
        double textWidth = Dim.Editor.ISSUE_TOOLTIP_MAX_WIDTH - 2 * Dim.Editor.ISSUE_TOOLTIP_PADDING
                - Dim.Editor.ISSUE_ACCENT_WIDTH - Dim.Editor.ISSUE_ACCENT_GAP;
        Font messageFont = Typography.font(Typography.Role.EDITOR_ISSUE_TEXT);

        Label caption = fixedLabel("Line " + (index + 1), CAPTION_STYLE_CLASS,
                Typography.Role.EDITOR_ISSUE_CAPTION);

        VBox content = new VBox(Dim.Editor.ISSUE_TOOLTIP_ROW_GAP, caption);
        content.setPadding(new Insets(Dim.Editor.ISSUE_TOOLTIP_PADDING));
        pinToPreferredSize(content);

        for (ErrorClassifier.Issue issue : issues) {
            String tone = issue.isError() ? "error" : "warning";

            Region accent = new Region();
            accent.getStyleClass().addAll(ACCENT_STYLE_CLASS, ACCENT_STYLE_CLASS + "-" + tone);
            accent.setMinWidth(Dim.Editor.ISSUE_ACCENT_WIDTH);
            accent.setPrefWidth(Dim.Editor.ISSUE_ACCENT_WIDTH);
            accent.setMaxWidth(Dim.Editor.ISSUE_ACCENT_WIDTH);
            accent.setMaxHeight(Double.MAX_VALUE);

            Label title = fixedLabel(issue.category().title(), TITLE_STYLE_CLASS,
                    Typography.Role.EDITOR_ISSUE_TITLE);
            title.getStyleClass().add(TITLE_STYLE_CLASS + "-" + tone);

            VBox text = new VBox(Dim.Editor.ISSUE_TOOLTIP_TITLE_GAP, title);
            for (String message : issue.messages()) {
                String wrapped = breakIntoLines(message, messageFont, textWidth);
                text.getChildren().add(fixedLabel(wrapped, MESSAGE_STYLE_CLASS,
                        Typography.Role.EDITOR_ISSUE_TEXT));
            }
            pinToPreferredSize(text);

            HBox row = new HBox(Dim.Editor.ISSUE_ACCENT_GAP, accent, text);
            row.setFillHeight(true);
            pinToPreferredSize(row);
            content.getChildren().add(row);
        }

        Tooltip tooltip = new Tooltip();
        tooltip.getStyleClass().add(TOOLTIP_STYLE_CLASS);
        // Inline, so no theme rule and no inherited editor font can change it.
        tooltip.setStyle("-fx-wrap-text: false; " + uiFontStyle(Typography.Role.EDITOR_ISSUE_TEXT));
        tooltip.setGraphic(content);
        tooltip.setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        tooltip.setMinSize(PopupControl.USE_PREF_SIZE, PopupControl.USE_PREF_SIZE);
        tooltip.setMaxSize(PopupControl.USE_PREF_SIZE, PopupControl.USE_PREF_SIZE);
        tooltip.setShowDelay(Duration.millis(Dim.Editor.ISSUE_TOOLTIP_DELAY_MS));
        tooltip.setShowDuration(Duration.seconds(30));
        tooltip.setHideDelay(Duration.millis(100));
        return tooltip;
    }

    /**
     * A label that never wraps, never truncates and is always exactly as big as
     * its text, in the system UI font for {@code role}.
     */
    private static Label fixedLabel(String text, String styleClass, Typography.Role role) {
        Label label = new Label(text);
        label.getStyleClass().add(styleClass);
        label.setStyle(uiFontStyle(role));
        label.setWrapText(false);
        label.setTextOverrun(OverrunStyle.CLIP);
        label.setMinSize(Region.USE_PREF_SIZE, Region.USE_PREF_SIZE);
        label.setMaxSize(Region.USE_PREF_SIZE, Region.USE_PREF_SIZE);
        return label;
    }

    private static void pinToPreferredSize(Region region) {
        region.setMinSize(Region.USE_PREF_SIZE, Region.USE_PREF_SIZE);
        region.setMaxSize(Region.USE_PREF_SIZE, Region.USE_PREF_SIZE);
    }

    /**
     * The inline font for a tooltip label: family, size and weight, with the
     * family always named. {@link Typography#css} leaves the family out when
     * it is the UI family, expecting {@code .root} to supply it -- but a
     * tooltip in the gutter inherits the editor's monospaced family instead.
     */
    private static String uiFontStyle(Typography.Role role) {
        return "-fx-font-family: " + Typography.familyCss(Typography.family(role)) + "; "
                + Typography.css(role);
    }

    /**
     * Breaks a message into lines no wider than {@code maxWidth}, measured in
     * the font it will be drawn in. Breaks fall between words; a single word
     * longer than the width keeps a line of its own rather than being cut.
     */
    private static String breakIntoLines(String message, Font font, double maxWidth) {
        if (message == null || message.isEmpty()) {
            return "";
        }
        Text probe = new Text();
        probe.setFont(font);

        StringBuilder out = new StringBuilder();
        StringBuilder line = new StringBuilder();
        for (String word : message.split(" ")) {
            if (word.isEmpty()) {
                continue;
            }
            String candidate = line.length() == 0 ? word : line + " " + word;
            probe.setText(candidate);
            if (line.length() > 0 && probe.getLayoutBounds().getWidth() > maxWidth) {
                out.append(line).append('\n');
                line.setLength(0);
                line.append(word);
            } else {
                line.setLength(0);
                line.append(candidate);
            }
        }
        out.append(line);
        return out.toString();
    }

    /**
     * Finds the line-number label in a cell built by
     * {@link #createLineNumberGraphic}.
     *
     * @param gutter the cell
     * @return the label, or null if the cell holds none
     */
    public static Label lineNumberOf(HBox gutter) {
        if (gutter == null) {
            return null;
        }
        Object stored = gutter.getProperties().get(LINE_NUMBER_KEY);
        if (stored instanceof Label label) {
            return label;
        }
        // Fallback: the number has always been the last child.
        int count = gutter.getChildren().size();
        if (count > 0 && gutter.getChildren().get(count - 1) instanceof Label label) {
            return label;
        }
        return null;
    }

    // =====================================================================
    // Error label (top right)
    // =====================================================================

    public static Label createErrorLabel() {
        Label errorLabel = new Label(" Errors: 0 ");
        errorLabel.setVisible(true);
        errorLabel.setManaged(true);
        errorLabel.setMinWidth(120);
        errorLabel.setAlignment(Pos.CENTER_RIGHT);
        applyErrorStyle(errorLabel, 0);
        errorLabel.setTooltip(new Tooltip(emptyCategoryText()));
        return errorLabel;
    }

    public static Label createTopRightErrorLabel() {
        return createErrorLabel();
    }

    public static void bindLiveErrorCount(TextInputControl editor, Label errorLabel) {
        editor.textProperty().addListener((obs, oldText, newText) -> updateErrorLabel(newText, errorLabel));
        updateErrorLabel(editor.getText(), errorLabel);
    }

    // ---------- Real-time error update ----------
    public static void attachRealtimeErrorUpdate(TextInputControl editor, Label errorLabel) {
        bindLiveErrorCount(editor, errorLabel);
    }

    public static void attachRealtimeErrorUpdate(TextInputControl editor, HBox statusBox) {
        editor.textProperty().addListener((obs, oldText, newText) -> updateStatusBox(newText, statusBox));
        updateStatusBox(editor.getText(), statusBox);
    }

    public static void bindLiveErrorCount(CodeArea editor, Label errorLabel) {
        editor.textProperty().addListener((obs, oldText, newText) -> {
            updateErrorLabel(newText, errorLabel);
            updateErrorLineStyles(editor, newText);
        });
        updateErrorLabel(editor.getText(), errorLabel);
        updateErrorLineStyles(editor, editor.getText());
    }

    public static void attachRealtimeErrorUpdate(CodeArea editor, Label errorLabel) {
        bindLiveErrorCount(editor, errorLabel);
    }

    public static void attachRealtimeErrorUpdate(CodeArea editor, HBox statusBox) {
        editor.textProperty().addListener((obs, oldText, newText) -> {
            updateStatusBox(newText, statusBox);
            updateErrorLineStyles(editor, newText);
        });
        updateStatusBox(editor.getText(), statusBox);
        updateErrorLineStyles(editor, editor.getText());
    }

    /**
     * Marks error lines.
     *
     * <h3>Folding note</h3>
     * This used to blank the paragraph style of every non-error line, which
     * would also have cleared the style RichTextFX uses to mark a paragraph as
     * folded -- one keystroke would have sprung every collapsed block open. It
     * now adds or removes {@code error-line} and leaves every other class on
     * the paragraph untouched. See the twin fix in
     * {@code ui.editor.EditorErrorHandler}.
     */
    private static void updateErrorLineStyles(CodeArea editor, String text) {
        Set<Integer> errorLines = ErrorChecker.lineIssues(text).allErrorLines();

        int paragraphCount = editor.getParagraphs().size();
        for (int i = 0; i < paragraphCount; i++) {
            applyErrorLineStyle(editor, i, errorLines.contains(i));
        }
    }

    /**
     * Adds or removes {@code error-line} on one paragraph while preserving
     * every other style class on it (notably RichTextFX's fold marker).
     */
    private static void applyErrorLineStyle(CodeArea editor, int paragraph, boolean isError) {
        Collection<String> current;
        try {
            current = editor.getParagraph(paragraph).getParagraphStyle();
        } catch (Exception e) {
            return;
        }

        boolean hasError = current != null && current.contains(ERROR_LINE);
        if (hasError == isError) {
            return;
        }

        List<String> updated = new ArrayList<>();
        if (current != null) {
            for (String styleClass : current) {
                if (!ERROR_LINE.equals(styleClass)) {
                    updated.add(styleClass);
                }
            }
        }
        if (isError) {
            updated.add(ERROR_LINE);
        }
        editor.setParagraphStyle(paragraph, updated);
    }

    public static void updateErrorLabel(String text, Label errorLabel) {
        ErrorChecker.ErrorReport report = ErrorChecker.analyzeErrors(text == null ? "" : text);
        errorLabel.setText(report.toDisplayText());
        applyErrorStyle(errorLabel, report);
        errorLabel.setTooltip(new Tooltip(report.toTooltipText()));
    }

    private static void applyErrorStyle(Label errorLabel, int count) {
        if (count > 0) {
            errorLabel.setStyle(
                    "-fx-text-fill: white; -fx-font-size: 12; -fx-font-weight: bold; -fx-background-color: #c62828; -fx-background-radius: 4; -fx-padding: 2 8 2 8;");
        } else {
            errorLabel.setStyle(
                    "-fx-text-fill: white; -fx-font-size: 12; -fx-font-weight: bold; -fx-background-color: #2e7d32; -fx-background-radius: 4; -fx-padding: 2 8 2 8;");
        }
    }

    private static void applyErrorStyle(Label errorLabel, ErrorChecker.ErrorReport report) {
        if (report.getErrorCount() > 0) {
            errorLabel.setStyle(
                    "-fx-text-fill: white; -fx-font-size: 12; -fx-font-weight: bold; -fx-background-color: #c62828; -fx-background-radius: 4; -fx-padding: 2 8 2 8;");
        } else if (report.getWarningCount() > 0) {
            errorLabel.setStyle(
                    "-fx-text-fill: black; -fx-font-size: 12; -fx-font-weight: bold; -fx-background-color: #f9a825; -fx-background-radius: 4; -fx-padding: 2 8 2 8;");
        } else {
            errorLabel.setStyle(
                    "-fx-text-fill: white; -fx-font-size: 12; -fx-font-weight: bold; -fx-background-color: #2e7d32; -fx-background-radius: 4; -fx-padding: 2 8 2 8;");
        }
    }

    private static Label createStatusLabel(String text) {
        Label label = new Label(text);
        label.setMinWidth(64);
        label.setAlignment(Pos.CENTER_RIGHT);
        return label;
    }

    private static void updateStatusBox(String text, HBox statusBox) {
        if (statusBox == null) {
            return;
        }
        Object errorObj = statusBox.getProperties().get(ERROR_BUTTON_KEY);
        Object warningObj = statusBox.getProperties().get(WARNING_BUTTON_KEY);
        if (!(errorObj instanceof Label) || !(warningObj instanceof Label)) {
            return;
        }
        Label errorButton = (Label) errorObj;
        Label warningButton = (Label) warningObj;

        ErrorChecker.ErrorReport report = ErrorChecker.analyzeErrors(text == null ? "" : text);
        errorButton.setText("\u2716 " + report.getErrorCount());
        warningButton.setText("\u26A0 " + report.getWarningCount());

        applyErrorButtonStyle(errorButton, report.getErrorCount());
        applyWarningButtonStyle(warningButton, report.getWarningCount());

        errorButton.setTooltip(new Tooltip(report.toCategoryText()));
        warningButton.setTooltip(new Tooltip("Warnings: " + report.getWarningCount()));
    }

    /** "Undefined Variable Errors: 0" ... for a counter that has seen no text yet. */
    private static String emptyCategoryText() {
        StringBuilder text = new StringBuilder();
        for (ErrorClassifier.Category category : ErrorClassifier.Category.values()) {
            if (text.length() > 0) {
                text.append('\n');
            }
            text.append(category.plural()).append(": 0");
        }
        return text.toString();
    }

    private static void applyErrorButtonStyle(Label errorButton, int errorCount) {
        errorButton.setStyle(
                "-fx-text-fill: #d32f2f; -fx-font-size: 12; -fx-font-weight: bold; -fx-background-color: transparent; -fx-padding: 0 4 0 4;");
    }

    private static void applyWarningButtonStyle(Label warningButton, int warningCount) {
        warningButton.setStyle(
                "-fx-text-fill: #f9a825; -fx-font-size: 12; -fx-font-weight: bold; -fx-background-color: transparent; -fx-padding: 0 4 0 4;");
    }
}
