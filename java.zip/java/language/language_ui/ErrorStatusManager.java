package language.language_ui;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import org.fxmisc.richtext.CodeArea;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.TextInputControl;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.HBox;
import language.syntax.syntax_checker.ErrorChecker;
import ui.design.Typography;
import ui.design.UIScale;

/**
 * Error and warning presentation: the footer counters and the left gutter dot.
 *
 * <h3>What changed (operator sequences)</h3>
 * The gutter tooltip names a meaningless operator combination exactly --
 * "'/' cannot follow '*' (only '+' or '-' may come after an operator)",
 * "Too many signs ...", "Line ends with operator '+'" -- and every counter
 * tooltip lists an "Operator sequence errors" line.
 *
 * <h3>Earlier change (powers and separators)</h3>
 * The gutter tooltip now names the exact power fault ("Exponent '^' has no
 * power after it", "Cannot assign to a power ...") and the new missing-separator
 * fault ("Missing ',' or operator between '"text"' and '0'"), and every counter
 * tooltip lists a "Missing separator errors" line.
 *
 * <h3>Earlier change (block headers)</h3>
 * Structural faults are named too -- "'if' block has no closing 'iend'",
 * "'fnend' has no open block to close" -- instead of all reading "invalid
 * indentation".
 *
 * <p>
 * The gutter tooltip names the exact header fault -- "Block header must end
 * with ':'", "Class header must be 'class Name(args):'" and so on -- and every
 * counter tooltip lists the new "Block header errors" line.
 *
 * <h3>Earlier changes</h3>
 * <ul>
 * <li><b>The gutter is no longer quadratic.</b>
 * {@link #createLineNumberGraphic(CodeArea, int)} is called once per rendered
 * line and used to run six separate whole-file analyses each time. It now asks
 * {@link ErrorChecker#lineIssues(String)} for one cached bundle and queries it
 * by line.</li>
 * <li><b>The indentation tooltip told the user the wrong number.</b> It read
 * "use 4 spaces per level"; NC blocks indent by 3, and the analyzer has always
 * enforced 3. Anyone who followed the tooltip produced the error it was
 * describing.</li>
 * <li><b>"Docstring warning" is now "Unterminated string literal"</b>, which is
 * what the check actually detects.</li>
 * </ul>
 */
public final class ErrorStatusManager {

    private static final String ERROR_BUTTON_KEY = "errorButton";
    private static final String WARNING_BUTTON_KEY = "warningButton";

    /** The one paragraph style class this class owns. */
    private static final String ERROR_LINE = "error-line";

    /** Block indentation, kept in step with IndentationSyntaxAnalyzer.INDENT_SIZE. */
    private static final int INDENT_SIZE = 3;

    /**
     * Key under which {@link #createLineNumberGraphic} stores the line-number
     * label in the returned HBox's properties, so the gutter can find it
     * without relying on child order.
     */
    public static final String LINE_NUMBER_KEY = "gutter.lineNumber";

    /**
     * Style class on the line-number label. Its colour comes from this class
     * in {@code themes/editorColor/editor_*.css}.
     */
    public static final String LINE_NUMBER_STYLE_CLASS = "gutter-line-number";

    private ErrorStatusManager() {
        // Utility class
    }

    public static HBox createTopRightStatusBox() {
        Label errorButton = createStatusLabel("\u2716 0");
        Label warningButton = createStatusLabel("\u26A0 0");

        applyErrorButtonStyle(errorButton, 0);
        applyWarningButtonStyle(warningButton, 0);

        errorButton.setTooltip(new Tooltip(
                "Undefined variable errors: 0"
                        + "\nIncomplete line syntax errors: 0"
                        + "\nInvalid exponent syntax errors: 0"
                        + "\nSubscript/superscript errors: 0"
                        + "\nIndentation errors: 0"
                        + "\nBlock header errors: 0"
                        + "\nMissing separator errors: 0"
                        + "\nOperator sequence errors: 0"));
        warningButton.setTooltip(new Tooltip("Unterminated string literals: 0"));

        HBox box = new HBox(8, errorButton, warningButton);
        box.setAlignment(Pos.CENTER_RIGHT);
        box.getProperties().put(ERROR_BUTTON_KEY, errorButton);
        box.getProperties().put(WARNING_BUTTON_KEY, warningButton);
        return box;
    }

    /**
     * Builds the left gutter cell for one line: the error/warning dot followed
     * by the line number.
     *
     * <h3>Folding note</h3>
     * The signature is unchanged -- still {@code (CodeArea, int)}. The fold
     * column is NOT built here and this method takes no factory argument.
     * {@code ui.editor.EditorGutter} rearranges the HBox this method returns
     * into fixed-width columns and appends the fold marker, so the gutter
     * reads dot - number - fold marker - blank strip - code, and this class
     * stays about errors only. Use {@link #lineNumberOf(HBox)} to find the
     * number label in it.
     *
     * @param editor the editor
     * @param index  zero-based paragraph index
     * @return the gutter cell
     */
    public static HBox createLineNumberGraphic(CodeArea editor, int index) {
        Label marker = new Label("\u25CF");
        Label lineNumber = new Label(String.valueOf(index + 1));

        marker.setMinWidth(6);
        lineNumber.setMinWidth(18);
        lineNumber.setAlignment(Pos.CENTER_RIGHT);
        marker.setAlignment(Pos.CENTER);

        // One cached bundle for the whole document, queried per line.
        ErrorChecker.LineIssues issues = ErrorChecker.lineIssues(editor.getText());

        boolean isErrorLine = issues.isErrorLine(index);
        boolean isWarningLine = issues.isWarningLine(index);

        List<String> lineIssues = new ArrayList<>();
        if (issues.hasUndefinedVariable(index)) {
            lineIssues.add("Undefined variable error");
        }
        if (issues.hasIncompleteLine(index)) {
            lineIssues.add("Incomplete line syntax error");
        }
        if (issues.hasInvalidExponent(index)) {
            String reason = issues.exponentMessage(index);
            lineIssues.add(reason != null ? reason : "Invalid exponent syntax error");
        }
        if (issues.hasMissingSeparator(index)) {
            lineIssues.add(issues.separatorMessage(index));
        }
        if (issues.hasOperatorSequence(index)) {
            lineIssues.add(issues.operatorMessage(index));
        }
        if (issues.hasSubscriptSuperscript(index)) {
            lineIssues.add("Invalid subscript/superscript usage");
        }
        if (issues.hasBlockHeader(index)) {
            lineIssues.add(issues.blockHeaderMessage(index));
        }
        if (issues.hasIndentation(index)) {
            String structure = issues.structureMessage(index);
            lineIssues.add(structure != null
                    ? structure
                    : "Invalid indentation: use " + INDENT_SIZE + " spaces per level");
        }
        if (issues.hasUnterminatedString(index)) {
            lineIssues.add("Unterminated string literal");
        }
        String issueText = String.join("\n", lineIssues);

        if (isErrorLine) {
            marker.setStyle("-fx-text-fill: #d32f2f; -fx-font-size: 10px; -fx-font-weight: bold;");
            Tooltip tooltip = new Tooltip(issueText.isEmpty() ? "Error line" : issueText);
            tooltip.setStyle("-fx-font-size: 10px;");
            lineNumber.setTooltip(tooltip);
            marker.setTooltip(tooltip);
        } else if (isWarningLine) {
            marker.setStyle("-fx-text-fill: #f9a825; -fx-font-size: 10px; -fx-font-weight: bold;");
            Tooltip tooltip = new Tooltip(issueText.isEmpty() ? "Warning line" : issueText);
            tooltip.setStyle("-fx-font-size: 10px;");
            lineNumber.setTooltip(tooltip);
            marker.setTooltip(tooltip);
        } else {
            marker.setStyle("-fx-text-fill: transparent; -fx-font-size: 8px;");
            lineNumber.setTooltip(null);
            marker.setTooltip(null);
        }

        // Font only. The colour is in the theme CSS (.gutter-line-number), so
        // the gutter can change the size here without losing it.
        lineNumber.getStyleClass().add(LINE_NUMBER_STYLE_CLASS);
        lineNumber.setStyle("-fx-font-family: " + Typography.familyCss(Typography.uiFamily()) + ";"
                + " -fx-font-size: "
                + UIScale.fmt(Typography.size(Typography.Role.EDITOR_LINE_NUMBER)) + "px;");

        HBox gutter = new HBox(6, marker, lineNumber);
        gutter.setAlignment(Pos.CENTER_RIGHT);
        // Default gap for a caller that uses this cell as it is. EditorGutter
        // replaces the padding with its own fixed layout.
        gutter.setPadding(new Insets(0, 20, 0, 0));
        gutter.getStyleClass().add("line-number-gutter");
        gutter.getProperties().put(LINE_NUMBER_KEY, lineNumber);
        return gutter;
    }

    /**
     * Finds the line-number label in a cell built by
     * {@link #createLineNumberGraphic}.
     *
     * @param gutter the cell
     * @return the label, or null if the cell holds none
     */
    public static Label lineNumberOf(HBox gutter) {
        if (gutter == null) {
            return null;
        }
        Object stored = gutter.getProperties().get(LINE_NUMBER_KEY);
        if (stored instanceof Label label) {
            return label;
        }
        // Fallback: the number has always been the last child.
        int count = gutter.getChildren().size();
        if (count > 0 && gutter.getChildren().get(count - 1) instanceof Label label) {
            return label;
        }
        return null;
    }

    public static Label createErrorLabel() {
        Label errorLabel = new Label(" Errors: 0 ");
        errorLabel.setVisible(true);
        errorLabel.setManaged(true);
        errorLabel.setMinWidth(120);
        errorLabel.setAlignment(Pos.CENTER_RIGHT);
        applyErrorStyle(errorLabel, 0);
        errorLabel.setTooltip(new Tooltip(
                "Unterminated string literals: 0"
                        + "\nUndefined variable errors: 0"
                        + "\nIncomplete line syntax errors: 0"
                        + "\nInvalid exponent syntax errors: 0"
                        + "\nSubscript/superscript errors: 0"
                        + "\nIndentation errors: 0"
                        + "\nBlock header errors: 0"
                        + "\nMissing separator errors: 0"
                        + "\nOperator sequence errors: 0"));
        return errorLabel;
    }

    public static Label createTopRightErrorLabel() {
        return createErrorLabel();
    }

    // ---------- Error Label (top-right) ----------
    public static void bindLiveErrorCount(TextInputControl editor, Label errorLabel) {
        editor.textProperty().addListener((obs, oldText, newText) -> updateErrorLabel(newText, errorLabel));
        updateErrorLabel(editor.getText(), errorLabel);
    }

    // ---------- Real-time error update ----------
    public static void attachRealtimeErrorUpdate(TextInputControl editor, Label errorLabel) {
        bindLiveErrorCount(editor, errorLabel);
    }

    public static void attachRealtimeErrorUpdate(TextInputControl editor, HBox statusBox) {
        editor.textProperty().addListener((obs, oldText, newText) -> updateStatusBox(newText, statusBox));
        updateStatusBox(editor.getText(), statusBox);
    }

    public static void bindLiveErrorCount(CodeArea editor, Label errorLabel) {
        editor.textProperty().addListener((obs, oldText, newText) -> {
            updateErrorLabel(newText, errorLabel);
            updateErrorLineStyles(editor, newText);
        });
        updateErrorLabel(editor.getText(), errorLabel);
        updateErrorLineStyles(editor, editor.getText());
    }

    public static void attachRealtimeErrorUpdate(CodeArea editor, Label errorLabel) {
        bindLiveErrorCount(editor, errorLabel);
    }

    public static void attachRealtimeErrorUpdate(CodeArea editor, HBox statusBox) {
        editor.textProperty().addListener((obs, oldText, newText) -> {
            updateStatusBox(newText, statusBox);
            updateErrorLineStyles(editor, newText);
        });
        updateStatusBox(editor.getText(), statusBox);
        updateErrorLineStyles(editor, editor.getText());
    }

    /**
     * Marks error lines.
     *
     * <h3>Folding note</h3>
     * This used to blank the paragraph style of every non-error line, which
     * would also have cleared the style RichTextFX uses to mark a paragraph as
     * folded -- one keystroke would have sprung every collapsed block open. It
     * now adds or removes {@code error-line} and leaves every other class on
     * the paragraph untouched. See the twin fix in
     * {@code ui.editor.EditorErrorHandler}.
     */
    private static void updateErrorLineStyles(CodeArea editor, String text) {
        Set<Integer> errorLines = ErrorChecker.lineIssues(text).allErrorLines();

        int paragraphCount = editor.getParagraphs().size();
        for (int i = 0; i < paragraphCount; i++) {
            applyErrorLineStyle(editor, i, errorLines.contains(i));
        }
    }

    /**
     * Adds or removes {@code error-line} on one paragraph while preserving
     * every other style class on it (notably RichTextFX's fold marker).
     */
    private static void applyErrorLineStyle(CodeArea editor, int paragraph, boolean isError) {
        Collection<String> current;
        try {
            current = editor.getParagraph(paragraph).getParagraphStyle();
        } catch (Exception e) {
            return;
        }

        boolean hasError = current != null && current.contains(ERROR_LINE);
        if (hasError == isError) {
            return;
        }

        List<String> updated = new ArrayList<>();
        if (current != null) {
            for (String styleClass : current) {
                if (!ERROR_LINE.equals(styleClass)) {
                    updated.add(styleClass);
                }
            }
        }
        if (isError) {
            updated.add(ERROR_LINE);
        }
        editor.setParagraphStyle(paragraph, updated);
    }

    public static void updateErrorLabel(String text, Label errorLabel) {
        ErrorChecker.ErrorReport report = ErrorChecker.analyzeErrors(text == null ? "" : text);
        errorLabel.setText(report.toDisplayText());
        applyErrorStyle(errorLabel, report);
        errorLabel.setTooltip(new Tooltip(report.toTooltipText()));
    }

    private static void applyErrorStyle(Label errorLabel, int count) {
        if (count > 0) {
            errorLabel.setStyle(
                    "-fx-text-fill: white; -fx-font-size: 12; -fx-font-weight: bold; -fx-background-color: #c62828; -fx-background-radius: 4; -fx-padding: 2 8 2 8;");
        } else {
            errorLabel.setStyle(
                    "-fx-text-fill: white; -fx-font-size: 12; -fx-font-weight: bold; -fx-background-color: #2e7d32; -fx-background-radius: 4; -fx-padding: 2 8 2 8;");
        }
    }

    private static void applyErrorStyle(Label errorLabel, ErrorChecker.ErrorReport report) {
        if (report.getErrorCount() > 0) {
            errorLabel.setStyle(
                    "-fx-text-fill: white; -fx-font-size: 12; -fx-font-weight: bold; -fx-background-color: #c62828; -fx-background-radius: 4; -fx-padding: 2 8 2 8;");
        } else if (report.getWarningCount() > 0) {
            errorLabel.setStyle(
                    "-fx-text-fill: black; -fx-font-size: 12; -fx-font-weight: bold; -fx-background-color: #f9a825; -fx-background-radius: 4; -fx-padding: 2 8 2 8;");
        } else {
            errorLabel.setStyle(
                    "-fx-text-fill: white; -fx-font-size: 12; -fx-font-weight: bold; -fx-background-color: #2e7d32; -fx-background-radius: 4; -fx-padding: 2 8 2 8;");
        }
    }

    private static Label createStatusLabel(String text) {
        Label label = new Label(text);
        label.setMinWidth(64);
        label.setAlignment(Pos.CENTER_RIGHT);
        return label;
    }

    private static void updateStatusBox(String text, HBox statusBox) {
        if (statusBox == null) {
            return;
        }
        Object errorObj = statusBox.getProperties().get(ERROR_BUTTON_KEY);
        Object warningObj = statusBox.getProperties().get(WARNING_BUTTON_KEY);
        if (!(errorObj instanceof Label) || !(warningObj instanceof Label)) {
            return;
        }
        Label errorButton = (Label) errorObj;
        Label warningButton = (Label) warningObj;

        ErrorChecker.ErrorReport report = ErrorChecker.analyzeErrors(text == null ? "" : text);
        errorButton.setText("\u2716 " + report.getErrorCount());
        warningButton.setText("\u26A0 " + report.getWarningCount());

        applyErrorButtonStyle(errorButton, report.getErrorCount());
        applyWarningButtonStyle(warningButton, report.getWarningCount());

        errorButton.setTooltip(new Tooltip("Undefined variable errors: " + report.getUndefinedVariableErrors()
                + "\nIncomplete line syntax errors: " + report.getIncompleteLineSyntaxErrors()
                + "\nInvalid exponent syntax errors: " + report.getInvalidExponentErrors()
                + "\nSubscript/superscript errors: " + report.getSubscriptSuperscriptErrors()
                + "\nIndentation errors: " + report.getIndentationErrors()
                + "\nBlock header errors: " + report.getBlockHeaderErrors()
                + "\nMissing separator errors: " + report.getMissingSeparatorErrors()
                + "\nOperator sequence errors: " + report.getOperatorSequenceErrors()));
        warningButton.setTooltip(
                new Tooltip("Unterminated string literals: " + report.getUnterminatedStringErrors()));
    }

    private static void applyErrorButtonStyle(Label errorButton, int errorCount) {
        errorButton.setStyle(
                "-fx-text-fill: #d32f2f; -fx-font-size: 12; -fx-font-weight: bold; -fx-background-color: transparent; -fx-padding: 0 4 0 4;");
    }

    private static void applyWarningButtonStyle(Label warningButton, int warningCount) {
        warningButton.setStyle(
                "-fx-text-fill: #f9a825; -fx-font-size: 12; -fx-font-weight: bold; -fx-background-color: transparent; -fx-padding: 0 4 0 4;");
    }
}
