package language.semantic;

/**
 * The reserved markers that carry subscript / superscript information through
 * the cleaned (machine-readable) form of a Neural Code identifier.
 *
 * <h3>Why the markers are double-underscored</h3>
 * The original scheme used {@code _s} and {@code _t}. Those are ambiguous when
 * decoding back to the visual form, because ordinary identifiers contain the
 * same character pairs:
 *
 * <pre>
 *   var_sigma   -> "var" + subscript "igma"     (wrong: this is sigma)
 *   var_theta   -> "var" + superscript "heta"   (wrong: this is theta)
 *   mass_speed  -> "mass" + subscript "peed"    (wrong: plain user variable)
 * </pre>
 *
 * A dictionary lookup rescues the first two but nothing rescues
 * {@code mass_speed}. Reserving the double underscore removes the ambiguity
 * completely: {@code __} is illegal inside a user-typed identifier, so any
 * {@code __s} / {@code __t} in a cleaned name is unambiguously a marker.
 *
 * <p><b>The C++ side is unaffected</b> — {@code nc.exe} only ever sees a
 * slightly longer identifier string.
 *
 * <p>{@link #LEGACY_SUBSCRIPT} / {@link #LEGACY_SUPERSCRIPT} are still
 * recognised by {@link VariableNameDecoder} so that a {@code variables.txt}
 * written before this change keeps rendering correctly, but they are only
 * honoured directly after a recognised dictionary token (see the decoder).
 */
public final class ScriptMarkers {

    /** Subscript marker in the cleaned form. Everything after it is subscript. */
    public static final String SUBSCRIPT = "__s";

    /** Superscript marker in the cleaned form. Everything after it is superscript. */
    public static final String SUPERSCRIPT = "__t";

    /** Pre-{@code __} marker, decoded only in unambiguous positions. */
    public static final String LEGACY_SUBSCRIPT = "_s";

    /** Pre-{@code __} marker, decoded only in unambiguous positions. */
    public static final String LEGACY_SUPERSCRIPT = "_t";

    /** Zero width joiner: the editor's single-character subscript marker. */
    public static final char ZWJ = '\u200D';

    /** Zero width non-joiner: the editor's single-character superscript marker. */
    public static final char ZWNJ = '\u200C';

    /** Editor marker for a multi-character subscript group. */
    public static final String SUB_GROUP = "\u200D\u200D\u200D";

    /** Editor marker for a multi-character superscript group. */
    public static final String SUP_GROUP = "\u200C\u200C\u200C";

    private ScriptMarkers() {
    }

    /**
     * @param identifier a user-typed identifier
     * @return true when the identifier illegally uses the reserved {@code __}
     *         sequence; wire this into ErrorChecker so the collision can never
     *         come back
     */
    public static boolean usesReservedSequence(String identifier) {
        return identifier != null && identifier.contains("__");
    }
}
