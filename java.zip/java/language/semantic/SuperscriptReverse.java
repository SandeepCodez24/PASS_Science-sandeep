package language.semantic;

import java.util.HashMap;
import java.util.Map;

public class SuperscriptReverse {

    public static final Map<Character, String> REVERSE = new HashMap<>();

    static {
        REVERSE.put('⁰', "0");
        REVERSE.put('¹', "1");
        REVERSE.put('²', "2");
        REVERSE.put('³', "3");
        REVERSE.put('⁴', "4");
        REVERSE.put('⁵', "5");
        REVERSE.put('⁶', "6");
        REVERSE.put('⁷', "7");
        REVERSE.put('⁸', "8");
        REVERSE.put('⁹', "9");
    }

    public static final String MARKER = "\u200C\u200C\u200C";
}
