package language.semantic;

import java.util.HashMap;
import java.util.Map;

/**
 * Unicode superscript character -> the plain character it stands for.
 *
 * <p>Read by {@link SemanticEncoder} when folding a superscript into the
 * cleaned form: a standalone superscript glyph becomes
 * {@code ScriptMarkers.SUPERSCRIPT + plain}.
 *
 * <h3>Letters as well as digits</h3>
 * See the note on {@link SubscriptReverse}: digits-only meant any other
 * superscript glyph leaked into {@code cleaned_Runfile.nc} as a raw non-ASCII
 * character that the lexer cannot read as part of an identifier.
 *
 * <p>Unicode has no superscript form for q. That one must use the editor's
 * styled-group markers, which the encoder handles separately.
 */
public class SuperscriptReverse {

    public static final Map<Character, String> REVERSE = new HashMap<>();

    static {
        // ---- digits ----
        REVERSE.put('\u2070', "0");
        REVERSE.put('\u00B9', "1");
        REVERSE.put('\u00B2', "2");
        REVERSE.put('\u00B3', "3");
        REVERSE.put('\u2074', "4");
        REVERSE.put('\u2075', "5");
        REVERSE.put('\u2076', "6");
        REVERSE.put('\u2077', "7");
        REVERSE.put('\u2078', "8");
        REVERSE.put('\u2079', "9");

        // ---- letters (the subset Unicode defines) ----
        REVERSE.put('\u1D43', "a");
        REVERSE.put('\u1D47', "b");
        REVERSE.put('\u1D9C', "c");
        REVERSE.put('\u1D48', "d");
        REVERSE.put('\u1D49', "e");
        REVERSE.put('\u1DA0', "f");
        REVERSE.put('\u1D4D', "g");
        REVERSE.put('\u02B0', "h");
        REVERSE.put('\u2071', "i");
        REVERSE.put('\u02B2', "j");
        REVERSE.put('\u1D4F', "k");
        REVERSE.put('\u02E1', "l");
        REVERSE.put('\u1D50', "m");
        REVERSE.put('\u207F', "n");
        REVERSE.put('\u1D52', "o");
        REVERSE.put('\u1D56', "p");
        REVERSE.put('\u02B3', "r");
        REVERSE.put('\u02E2', "s");
        REVERSE.put('\u1D57', "t");
        REVERSE.put('\u1D58', "u");
        REVERSE.put('\u1D5B', "v");
        REVERSE.put('\u02B7', "w");
        REVERSE.put('\u02E3', "x");
        REVERSE.put('\u02B8', "y");
        REVERSE.put('\u1DBB', "z");
    }

    /** Editor marker delimiting a multi-character superscript group. */
    public static final String MARKER = "\u200C\u200C\u200C";
}
