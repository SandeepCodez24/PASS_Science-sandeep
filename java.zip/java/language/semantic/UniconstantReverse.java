package language.semantic;

import java.util.HashMap;
import java.util.Map;

public class UniconstantReverse {
    public static final Map<String, String> REVERSE = new HashMap<>();

    static {
        REVERSE.put("𝝅", "uc_pi");
        REVERSE.put("𝒈", "uc_gravity");
        REVERSE.put("𝑹", "uc_gasconst");
        REVERSE.put("𝑵ₐ", "uc_avagadro");
        REVERSE.put("ℏ", "uc_planck");
        REVERSE.put("𝑮", "uc_gravitational");
        REVERSE.put("𝝈", "uc_stefanboltzmann");
        REVERSE.put("𝒌ₑ", "uc_coulomb");
        REVERSE.put("𝒎ₑ", "uc_electronmass");
        REVERSE.put("𝒎ₚ", "uc_protonmass");
        REVERSE.put("𝒎ₙ", "uc_neutronmass");
        REVERSE.put("𝑴", "uc_molarmass");
        REVERSE.put("𝒆", "uc_elementarycharge");
        REVERSE.put("𝑭", "uc_faraday");
        REVERSE.put("𝒄", "uc_speedoflight");
        REVERSE.put("𝒌", "uc_boltzmann");
        REVERSE.put("𝜺₀", "uc_vacuumpermittivity");
        REVERSE.put("𝝁₀", "uc_vacuumpermeability");
        REVERSE.put("𝜶", "uc_finestructure");
        REVERSE.put("𝑹∞", "uc_rydberg");
        REVERSE.put("𝑭", "uc_faraday");
        REVERSE.put("𝒂₀", "uc_bohrradius");
        REVERSE.put("𝑬ₕ", "uc_hartreeenergy");
        REVERSE.put("𝝓₀", "uc_magneticfluxquantum");
        
    }
}
    
