package language.semantic;

import java.util.HashMap;
import java.util.Map;

public class TeluguReverse {
    public static final Map<String, String> REVERSE = new HashMap<>();

    static {
        // Telugu vowels (Svarāksharalu)
        REVERSE.put("అ", "var_telugu_a");
        REVERSE.put("ఆ", "var_telugu_aa");
        REVERSE.put("ఇ", "var_telugu_i");
        REVERSE.put("ఈ", "var_telugu_ii");
        REVERSE.put("ఉ", "var_telugu_u");
        REVERSE.put("ఊ", "var_telugu_uu");
        REVERSE.put("ఋ", "var_telugu_ru");
        REVERSE.put("ఎ", "var_telugu_e");
        REVERSE.put("ఏ", "var_telugu_ee");
        REVERSE.put("ఐ", "var_telugu_ai");
        REVERSE.put("ఒ", "var_telugu_o");
        REVERSE.put("ఓ", "var_telugu_oo");
        REVERSE.put("ఔ", "var_telugu_au");
        REVERSE.put("అం", "var_telugu_am");
        REVERSE.put("అః", "var_telugu_ah");

        // Telugu consonants
        REVERSE.put("క", "var_telugu_k");
        REVERSE.put("ఖ", "var_telugu_kh");
        REVERSE.put("గ", "var_telugu_g");
        REVERSE.put("ఘ", "var_telugu_gh");
        REVERSE.put("ఙ", "var_telugu_ng");

        REVERSE.put("చ", "var_telugu_ch");
        REVERSE.put("ఛ", "var_telugu_chh");
        REVERSE.put("జ", "var_telugu_j");
        REVERSE.put("ఝ", "var_telugu_jh");
        REVERSE.put("ఞ", "var_telugu_ny");

        REVERSE.put("ట", "var_telugu_t");
        REVERSE.put("ఠ", "var_telugu_th");
        REVERSE.put("డ", "var_telugu_d");
        REVERSE.put("ఢ", "var_telugu_dh");
        REVERSE.put("ణ", "var_telugu_n");

        REVERSE.put("త", "var_telugu_t2");
        REVERSE.put("థ", "var_telugu_th2");
        REVERSE.put("ద", "var_telugu_d2");
        REVERSE.put("ధ", "var_telugu_dh2");
        REVERSE.put("న", "var_telugu_n2");

        REVERSE.put("ప", "var_telugu_p");
        REVERSE.put("ఫ", "var_telugu_ph");
        REVERSE.put("బ", "var_telugu_b");
        REVERSE.put("భ", "var_telugu_bh");
        REVERSE.put("మ", "var_telugu_m");

        REVERSE.put("య", "var_telugu_y");
        REVERSE.put("ర", "var_telugu_r");
        REVERSE.put("ల", "var_telugu_l");
        REVERSE.put("వ", "var_telugu_v");
        REVERSE.put("శ", "var_telugu_sh");
        REVERSE.put("ష", "var_telugu_ss");
        REVERSE.put("స", "var_telugu_s");
        REVERSE.put("హ", "var_telugu_h");
        REVERSE.put("ళ", "var_telugu_ll");
    }
}
