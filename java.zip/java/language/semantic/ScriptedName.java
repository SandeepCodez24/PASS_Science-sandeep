package language.semantic;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

/**
 * The one definition of a Neural Code name on the Java side: how a
 * subscript and a superscript are written, how a name splits into its parts,
 * and which names are valid. Its C++ twin is
 * {@code lexer/identifier_rules.cpp} in {@code nc.exe}; both read the same
 * generated tables ({@link IdentifierChars}), so the editor and the
 * interpreter accept exactly the same names and report the same problems.
 *
 * <h3>Writing</h3>
 * <pre>
 *   A_$1          A with subscript 1
 *   A_@2          A with superscript 2
 *   μ_$max_@2     μ with subscript "max" and superscript 2
 *   A__j, A_sj    ordinary names: no '$' or '@', nothing special
 * </pre>
 * Everything typed after {@code _$} belongs to the subscript, up to the end
 * of the name or the {@code _@} that starts the superscript. A plain letter
 * can never follow a subscript on the baseline, so the name needs no closing
 * marker.
 *
 * <h3>One spelling everywhere</h3>
 * The text {@code A_$1} is what the file holds, what the editor's document
 * holds, what goes to {@code nc.exe}, what the interpreter reports back and
 * what the Variable Explorer is keyed on. Nothing is encoded or decoded on
 * the way, so there is nothing to get out of step. Drawing {@code A₁} is
 * purely a matter of styling ({@code UPITokenMaker} hides the two marker
 * characters and lowers the rest; the Explorer renders {@link #parse}'s
 * parts).
 *
 * <h3>Why no other name can look like A₁</h3>
 * {@code $} and {@code @} are not name characters anywhere else, and the
 * characters that could fake the look -- Unicode subscript digits
 * ({@code ₁}), modifier letters ({@code ᵢ}), invisible joiners -- are not
 * name characters at all. So the only way to get a subscript is to write
 * {@code _$}, and {@code A_$1} cannot be confused with {@code A_1},
 * {@code A1}, {@code A_s1} or {@code A₁}.
 */
public final class ScriptedName {

    /** Starts a subscript. */
    public static final String SUB = "_$";

    /** Starts a superscript. */
    public static final String SUP = "_@";

    /** What one part of a name is. */
    public enum Kind {
        /** The name itself, on the baseline. */
        BASE,
        /** Written after {@link #SUB}, drawn lowered. */
        SUBSCRIPT,
        /** Written after {@link #SUP}, drawn raised. */
        SUPERSCRIPT
    }

    /**
     * One part of a name. Offsets are UTF-16 indices into the name.
     *
     * @param kind         what the part is
     * @param markerStart  where its marker ({@code _$} / {@code _@}) starts;
     *                     equal to {@code contentStart} for the base
     * @param contentStart where the part's own text starts
     * @param end          one past its last character
     * @param text         the part's own text (no marker)
     */
    public record Part(Kind kind, int markerStart, int contentStart, int end, String text) {

        /** @return true when the part has text after its marker */
        public boolean hasContent() {
            return end > contentStart;
        }
    }

    /**
     * A name split into its parts.
     *
     * @param name     the name as written
     * @param parts    the base first, then the script parts in written order
     * @param problems why the name is not valid; empty when it is
     */
    public record Parsed(String name, List<Part> parts, List<String> problems) {

        /** Both lists are kept as read-only copies: a parse result never changes. */
        public Parsed {
            parts = List.copyOf(parts);
            problems = List.copyOf(problems);
        }

        // Written out, not generated: the IDE's collection check cannot see a
        // generated accessor hand the list out, and reports it as a list that
        // is read but never filled.

        /** @return the base first, then the script parts in written order (read-only) */
        @Override
        public List<Part> parts() {
            return parts;
        }

        /** @return why the name is not valid; empty when it is (read-only) */
        @Override
        public List<String> problems() {
            return problems;
        }

        /** @return true when the name has a subscript or superscript */
        public boolean hasScripts() {
            return parts.size() > 1;
        }

        /** @return true when the name has no problem */
        public boolean isValid() {
            return problems.isEmpty();
        }
    }

    // A name character for the regular expressions below: any letter, mark or
    // digit, or a '_' that does not start a marker. The regexes only FIND
    // names; whether a found name is valid is decided by parse(), with the
    // exact tables nc.exe uses. The zero-width joiners of the old hidden
    // subscript markers are read as part of a name too, so a name typed in
    // the old way (S + ZWJ + j + ZWJ) is ONE name, reported once as invalid,
    // instead of falling apart into "S" and an undefined "j".
    private static final String CH = "(?:[\\p{L}\\p{M}\\p{N}\\u200C\\u200D]|_(?![$@]))";

    /**
     * Regular expression for a whole name, markers included. It matches
     * {@code A}, {@code A_$1}, {@code μ_$i_@2} and also faulty shapes such as
     * {@code A_$} (so they can be shown and reported, never half-hidden).
     */
    public static final String NAME_REGEX = "[\\p{L}_]" + CH + "*(?:_[$@]" + CH + "*)*";

    /**
     * Regular expression for a name that carries at least one marker, not
     * starting in the middle of another word.
     */
    public static final String SCRIPTED_NAME_REGEX =
            "(?<![\\p{L}\\p{M}\\p{N}_\\u200C\\u200D])[\\p{L}_]" + CH + "*(?:_[$@]" + CH + "*)+";

    /** Compiled {@link #SCRIPTED_NAME_REGEX}. */
    public static final Pattern SCRIPTED_NAME = Pattern.compile(SCRIPTED_NAME_REGEX);

    /**
     * Name prefixes the language keeps for itself. {@code con_} is how a
     * physical constant typed as a symbol ({@code \con(\pi)}) reaches the
     * interpreter; a variable spelt that way would be drawn as the constant.
     */
    private static final List<String> RESERVED_PREFIXES = List.of("con_");

    private ScriptedName() {
    }

    // =====================================================================
    // Parsing
    // =====================================================================

    /**
     * Splits a name into its parts and checks it. Mirrors
     * {@code ncident::scanName} in {@code nc.exe} rule for rule, message for
     * message.
     *
     * @param name a name (not null)
     * @return the parts and any problems
     */
    public static Parsed parse(String name) {
        List<Part> parts = new ArrayList<>(3);
        List<String> problems = new ArrayList<>(1);
        if (name == null || name.isEmpty()) {
            return new Parsed(name == null ? "" : name, List.of(), List.of("a name cannot be empty"));
        }

        Kind part = Kind.BASE;
        int markerStart = 0;
        int contentStart = 0;
        int partLen = 0;
        boolean seenSub = false;
        boolean seenSup = false;
        int prev = 0;

        int i = 0;
        int n = name.length();
        while (i < n) {
            char c = name.charAt(i);
            if (c == '_' && i + 1 < n && (name.charAt(i + 1) == '$' || name.charAt(i + 1) == '@')) {
                boolean sub = name.charAt(i + 1) == '$';
                if (part == Kind.BASE && partLen == 0) {
                    problems.add("a " + (sub ? "subscript (_$)" : "superscript (_@)")
                            + " needs a name in front of it, as in A_$1");
                } else if (part != Kind.BASE && partLen == 0) {
                    problems.add("the " + word(part) + " is empty; write something after the marker");
                }
                if (sub && seenSub) {
                    problems.add("a name can have only one subscript (_$)");
                } else if (sub && seenSup) {
                    problems.add("write the subscript (_$) before the superscript (_@), as in A_$i_@2");
                } else if (!sub && seenSup) {
                    problems.add("a name can have only one superscript (_@)");
                }
                parts.add(new Part(part, markerStart, contentStart, i, name.substring(contentStart, i)));
                part = sub ? Kind.SUBSCRIPT : Kind.SUPERSCRIPT;
                if (sub) {
                    seenSub = true;
                } else {
                    seenSup = true;
                }
                markerStart = i;
                contentStart = i + 2;
                partLen = 0;
                prev = 0;
                i += 2;
                continue;
            }

            int cp = name.codePointAt(i);
            int len = Character.charCount(cp);
            int kind = classify(cp);
            if (kind == 0) {
                if (cp == '$' || cp == '@') {
                    problems.add("'" + (char) cp + "' can only appear in a name as _$ (subscript)"
                            + " or _@ (superscript)");
                } else {
                    problems.add(describeRefusal(cp));
                }
            } else if (cp == '_') {
                if (part != Kind.BASE && partLen == 0) {
                    problems.add("a " + word(part) + " must start with a letter or a digit");
                }
            } else {
                boolean asciiDigit = cp >= '0' && cp <= '9';
                if (partLen == 0 && part == Kind.BASE && kind != IdentifierChars.START) {
                    problems.add("a name must start with a letter or '_'");
                }
                if (partLen == 0 && part != Kind.BASE && kind != IdentifierChars.START && !asciiDigit) {
                    problems.add("a " + word(part) + " must start with a letter or a digit");
                }
                String nfc = nfcProblem(prev, cp);
                if (nfc != null) {
                    problems.add(nfc);
                }
            }
            prev = cp;
            i += len;
            partLen++;
        }
        if (part != Kind.BASE && partLen == 0) {
            problems.add("the " + word(part) + " is empty; write something after the marker");
        }
        parts.add(new Part(part, markerStart, contentStart, n, name.substring(contentStart, n)));

        if (problems.isEmpty()) {
            for (String prefix : RESERVED_PREFIXES) {
                if (name.startsWith(prefix)) {
                    problems.add("names starting with '" + prefix + "' are reserved for the language");
                }
            }
        }
        return new Parsed(name, parts,
                problems.isEmpty() ? List.of() : List.of(problems.get(0)));
    }

    /**
     * @param name a name
     * @return true when it holds a subscript or superscript marker
     */
    public static boolean hasScripts(String name) {
        return name != null && (name.contains(SUB) || name.contains(SUP));
    }

    /**
     * @param name a name
     * @return the first problem with it, or null when it is valid
     */
    public static String problem(String name) {
        List<String> p = parse(name).problems();
        return p.isEmpty() ? null : p.get(0);
    }

    // =====================================================================
    // Plain-text form (tab titles, tooltips, dialogs, print)
    // =====================================================================

    private static final String SUB_FROM = "0123456789+-=()aehijklmnoprstuvxβγρφχ";
    private static final String SUB_TO = "₀₁₂₃₄₅₆₇₈₉₊₋₌₍₎ₐₑₕᵢⱼₖₗₘₙₒₚᵣₛₜᵤᵥₓᵦᵧᵨᵩᵪ";
    private static final String SUP_FROM = "0123456789+-=()abcdefghijklmnoprstuvwxyzABDEGHIJKLMNOPRTUVWβγδθιφχ";
    private static final String SUP_TO = "⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻⁼⁽⁾ᵃᵇᶜᵈᵉᶠᵍʰⁱʲᵏˡᵐⁿᵒᵖʳˢᵗᵘᵛʷˣʸᶻᴬᴮᴰᴱᴳᴴᴵᴶᴷᴸᴹᴺᴼᴾᴿᵀᵁⱽᵂᵝᵞᵟᶿᶥᵠᵡ";

    /**
     * The name as one line of plain text, for places that cannot style text
     * (a tab title, a tooltip, a dialog). A part made only of characters that
     * have a Unicode subscript or superscript form is shown with them
     * ({@code A_$1} reads {@code A₁}); any other part keeps its marker
     * ({@code μ_$max} stays {@code μ_$max}), so the plain form is never
     * ambiguous. Display only: never fed back into code.
     *
     * @param name a name
     * @return its plain-text form
     */
    public static String toPlainText(String name) {
        if (!hasScripts(name)) {
            return name;
        }
        Parsed parsed = parse(name);
        StringBuilder out = new StringBuilder(name.length());
        for (Part p : parsed.parts()) {
            if (p.kind() == Kind.BASE || !p.hasContent()) {
                out.append(name, p.markerStart(), p.end());
                continue;
            }
            String mapped = p.kind() == Kind.SUBSCRIPT
                    ? map(p.text(), SUB_FROM, SUB_TO)
                    : map(p.text(), SUP_FROM, SUP_TO);
            out.append(mapped != null ? mapped : name.substring(p.markerStart(), p.end()));
        }
        return out.toString();
    }

    private static String map(String text, String from, String to) {
        StringBuilder out = new StringBuilder(text.length());
        for (int i = 0; i < text.length(); i++) {
            int at = from.indexOf(text.charAt(i));
            if (at < 0) {
                return null;
            }
            out.appendCodePoint(to.codePointAt(to.offsetByCodePoints(0, at)));
        }
        return out.toString();
    }

    // =====================================================================
    // Characters
    // =====================================================================

    /**
     * @param cp a code point
     * @return {@link IdentifierChars#START}, {@link IdentifierChars#CONT} or 0
     *         (not allowed in a name)
     */
    static int classify(int cp) {
        if (cp < 0x80) {
            if ((cp >= 'A' && cp <= 'Z') || (cp >= 'a' && cp <= 'z') || cp == '_') {
                return IdentifierChars.START;
            }
            return cp >= '0' && cp <= '9' ? IdentifierChars.CONT : 0;
        }
        int[] r = IdentifierChars.RANGES;
        int lo = 0;
        int hi = r.length / 3;
        while (lo < hi) {
            int mid = (lo + hi) >>> 1;
            if (cp < r[mid * 3]) {
                hi = mid;
            } else if (cp > r[mid * 3 + 1]) {
                lo = mid + 1;
            } else {
                return r[mid * 3 + 2];
            }
        }
        return 0;
    }

    /**
     * @param cp a code point
     * @return true when it may appear somewhere in a name
     */
    public static boolean isNameChar(int cp) {
        return classify(cp) != 0;
    }

    /**
     * @param cp a code point
     * @return true for the characters that could fake a subscript or
     *         superscript look ({@code ₁ ¹ ᵢ}) or hide inside a name (ZWJ,
     *         ZWNJ, zero-width space, BOM, ...)
     */
    public static boolean isLookAlikeOrInvisible(int cp) {
        return isInvisible(cp) || isScriptLookAlike(cp);
    }

    /**
     * Why a character is refused in a name, phrased for the user; the same
     * text {@code nc.exe} prints.
     *
     * @param cp a code point that {@link #isNameChar} refuses
     * @return the reason
     */
    public static String describeRefusal(int cp) {
        String label = label(cp);
        if (cp == 0x200C || cp == 0x200D) {
            return "an invisible joiner (" + label + ") cannot be part of a name; it is the old hidden"
                    + " subscript/superscript marker - retype the name with _$ (subscript) or _@ (superscript)";
        }
        if (isInvisible(cp)) {
            return "an invisible character (" + label + ") cannot be part of a name";
        }
        if (isScriptLookAlike(cp)) {
            return "'" + new String(Character.toChars(cp)) + "' (" + label
                    + ") cannot be part of a name; write a subscript as _$ and a superscript as _@ (A_$1, A_@2)";
        }
        int at = Arrays.binarySearch(IdentifierChars.CONFUSABLES, cp);
        if (at >= 0) {
            return "'" + new String(Character.toChars(cp)) + "' (" + label + ") cannot be used in a name: "
                    + IdentifierChars.CONFUSABLE_REASONS[at] + "; use the Latin letter";
        }
        return "the character '" + new String(Character.toChars(cp)) + "' (" + label
                + ") cannot be used in a name";
    }

    private static String nfcProblem(int prev, int cp) {
        if (Arrays.binarySearch(IdentifierChars.NON_NFC, cp) >= 0) {
            return "'" + new String(Character.toChars(cp)) + "' (" + label(cp)
                    + ") is not in normal form; type the letter and its nukta separately";
        }
        if (prev == 0) {
            return null;
        }
        int[] p = IdentifierChars.COMPOSE_PAIRS;
        for (int k = 0; k < p.length; k += 3) {
            if (p[k] == prev && p[k + 1] == cp) {
                return "'" + new String(Character.toChars(prev)) + new String(Character.toChars(cp))
                        + "' must be written as the single character '"
                        + new String(Character.toChars(p[k + 2])) + "' (" + label(p[k + 2]) + ")";
            }
        }
        int a = combiningClass(prev);
        int b = combiningClass(cp);
        if (a > 0 && b > 0 && a > b) {
            return "the marks " + label(prev) + " and " + label(cp) + " are in the wrong order";
        }
        return null;
    }

    private static int combiningClass(int cp) {
        int[] m = IdentifierChars.MARK_CLASSES;
        for (int k = 0; k < m.length; k += 2) {
            if (m[k] == cp) {
                return m[k + 1];
            }
        }
        return 0;
    }

    private static boolean isInvisible(int cp) {
        return cp == 0x00AD || cp == 0x034F || cp == 0x061C || cp == 0x180E
                || (cp >= 0x200B && cp <= 0x200F) || (cp >= 0x202A && cp <= 0x202E)
                || (cp >= 0x2060 && cp <= 0x2064) || (cp >= 0x2066 && cp <= 0x2069)
                || cp == 0xFEFF || (cp >= 0xFE00 && cp <= 0xFE0F);
    }

    private static boolean isScriptLookAlike(int cp) {
        return cp == 0x00B2 || cp == 0x00B3 || cp == 0x00B9
                || (cp >= 0x2070 && cp <= 0x209F)
                || (cp >= 0x1D2C && cp <= 0x1D6A)
                || (cp >= 0x1D9B && cp <= 0x1DBF)
                || (cp >= 0x02B0 && cp <= 0x02B8)
                || (cp >= 0x02E0 && cp <= 0x02E4) || cp == 0x2C7C || cp == 0x2C7D;
    }

    private static String label(int cp) {
        return String.format("U+%04X", cp);
    }

    private static String word(Kind kind) {
        return kind == Kind.SUBSCRIPT ? "subscript (_$)" : "superscript (_@)";
    }

    /**
     * Unicode normal form C, the form every name reaches {@code nc.exe} in.
     * Two spellings of the same Tamil or Kannada letter (one character, or
     * its two halves) become one, so they can never be two variables.
     *
     * @param text any text
     * @return its NFC form
     */
    public static String nfc(String text) {
        if (text == null || text.isEmpty() || Normalizer.isNormalized(text, Normalizer.Form.NFC)) {
            return text;
        }
        return Normalizer.normalize(text, Normalizer.Form.NFC);
    }
}
