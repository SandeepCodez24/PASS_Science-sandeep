package language.semantic;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/**
 * Editor text  ->  the text {@code nc.exe} runs.
 *
 * <h3>Names are no longer encoded</h3>
 * <p>
 * {@code nc.exe} reads UTF-8 names and the subscript / superscript markers
 * directly ({@code lexer/identifier_rules.cpp}), so a name goes to the
 * interpreter exactly as it is written and comes back the same way:
 * </p>
 * <pre>
 *   written        sent to nc.exe     reported back     drawn
 *   A_$1           A_$1               A_$1              A₁
 *   μ_$i_@2        μ_$i_@2            μ_$i_@2           μᵢ²
 *   க_$1           க_$1               க_$1              க₁
 *   A__j           A__j               A__j              A__j
 * </pre>
 * <p>
 * The old translations ({@code μ -> var_mu}, the {@code __s} / {@code __t}
 * markers, the zero-width joiners) are gone. Each of them was a second
 * spelling of a name that a user could also type directly, which is how a
 * plain variable could end up looking like a subscripted one.
 * </p>
 *
 * <h3>What is still done</h3>
 * <ul>
 * <li><b>Only code is touched.</b> {@link CodeSegments} copies
 * {@code "..."} / {@code '...'} literals and {@code #} / {@code \\} comments
 * through unchanged.</li>
 * <li><b>Complex literals:</b> {@code 5i} is written {@code 5j}
 * ({@link ComplexLiteral}).</li>
 * <li><b>Physical constants</b> saved as symbols by older versions, when
 * {@code \con(\pi)} still inserted 𝝅, go to the interpreter under their
 * {@code uc_} names ({@link UniconstantReverse}), so those scripts still
 * run. {@code \con(\pi)} now inserts {@code uc_pi} itself.</li>
 * <li><b>Unicode normal form C</b> ({@link ScriptedName#nfc}): the two
 * spellings of a Tamil or Kannada letter (one character, or its two halves)
 * become one, so they can never be two different variables.</li>
 * </ul>
 * <p>
 * Nothing is removed or repaired silently any more: a stray zero-width
 * joiner, a {@code ₁} or a malformed {@code A_$} reaches {@code nc.exe} as
 * written and is reported there (and by the editor's checker), instead of
 * being quietly turned into a different name.
 * </p>
 */
public final class SemanticEncoder {

    /** Constant symbols, longest first. */
    private static final List<Map.Entry<String, String>> SYMBOLS = buildSymbolTable();

    private SemanticEncoder() {
    }

    /**
     * Encodes editor text into the text the interpreter runs.
     *
     * @param uiText the text as shown in the editor
     * @return the text to run
     */
    public static String encode(String uiText) {
        if (uiText == null || uiText.isEmpty()) {
            return uiText == null ? "" : uiText;
        }
        // Strings and comments are copied unchanged; only code is encoded.
        return CodeSegments.mapCode(uiText, SemanticEncoder::encodeCode);
    }

    /**
     * Encodes one stretch of code: no string literal and no comment in it.
     *
     * @param code a code segment
     * @return its encoded form
     */
    static String encodeCode(String code) {
        if (code == null || code.isEmpty()) {
            return code == null ? "" : code;
        }
        // 1. Complex literals: 5i -> 5j, while digits are still plain.
        String result = ComplexLiteral.rewriteCode(code);

        // 2. Physical-constant symbols, longest first.
        for (Map.Entry<String, String> entry : SYMBOLS) {
            if (result.contains(entry.getKey())) {
                result = result.replace(entry.getKey(), entry.getValue());
            }
        }

        // 3. One spelling per letter.
        return ScriptedName.nfc(result);
    }

    /**
     * Encodes just one name -- used by the Command Window for
     * {@code clear <name>}.
     *
     * @param visualName the name as the user typed it
     * @return the name the interpreter knows it by
     */
    public static String encodeName(String visualName) {
        return visualName == null ? null : encode(visualName).trim();
    }

    // -----------------------------------------------------------------
    // Internals
    // -----------------------------------------------------------------

    private static List<Map.Entry<String, String>> buildSymbolTable() {
        List<Map.Entry<String, String>> entries = new ArrayList<>(UniconstantReverse.REVERSE.entrySet());
        entries.sort(Comparator
                .comparingInt((Map.Entry<String, String> e) -> e.getKey().length())
                .reversed()
                .thenComparing(Map.Entry::getKey));
        return List.copyOf(entries);
    }
}
