package language.semantic;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Visual (editor) form  ->  cleaned (machine-readable) form.
 *
 * <p>This is the encoder that produces the identifiers written into
 * {@code cleaned_Runfile.nc} and therefore the identifiers {@code nc.exe}
 * reports back in {@code variables.txt}. {@link VariableNameDecoder} is its
 * exact inverse and is what the Variable Explorer uses to draw names.
 *
 * <h3>What changed from the previous version</h3>
 * <ol>
 *   <li><b>Longest-key-first replacement.</b> The old code iterated the
 *       {@code HashMap}s directly, so for Tamil the single-letter rule
 *       {@code க -> var_tamil_ka} could fire before the two-codepoint rule
 *       {@code கா -> var_tamil_kaa}, leaving the mangled result
 *       {@code var_tamil_kaா}. Keys are now applied longest-first.</li>
 *   <li><b>Single-character script markers are handled.</b>
 *       {@code Subscript.styledSubscript(ch)} emits {@code ZWJ ch ZWJ}, but the
 *       old encoder only looked for the <em>triple</em> group marker. Single
 *       markers therefore survived into the cleaned file as raw zero-width
 *       joiners, producing an identifier {@code nc.exe} cannot lex.</li>
 *   <li><b>Markers are now {@code __s} / {@code __t}</b> (see
 *       {@link ScriptMarkers}) so decoding is unambiguous.</li>
 *   <li><b>A final sweep strips any stray ZWJ/ZWNJ</b>, so no invisible
 *       character can ever reach the interpreter.</li>
 * </ol>
 */
public final class SemanticEncoder {

    /** All symbol dictionaries, flattened and sorted longest-visual-first. */
    private static final List<Map.Entry<String, String>> SYMBOLS = buildSymbolTable();

    private SemanticEncoder() {
    }

    /**
     * Encodes editor text into its cleaned, ASCII-safe equivalent.
     *
     * @param uiText the text as shown in the editor (may contain Greek, Tamil,
     *               Sanskrit, Malayalam, Telugu, constants and script markers)
     * @return the cleaned text
     */
    public static String encode(String uiText) {
        if (uiText == null || uiText.isEmpty()) {
            return uiText == null ? "" : uiText;
        }

        String result = uiText;

        // 1. Symbol dictionaries, longest visual form first.
        for (Map.Entry<String, String> entry : SYMBOLS) {
            result = result.replace(entry.getKey(), entry.getValue());
        }

        // 2. Multi-character groups first (their marker contains the single one).
        result = encodeGroups(result, ScriptMarkers.SUP_GROUP,
                ScriptMarkers.SUPERSCRIPT, SuperscriptReverse.REVERSE);
        result = encodeGroups(result, ScriptMarkers.SUB_GROUP,
                ScriptMarkers.SUBSCRIPT, SubscriptReverse.REVERSE);

        // 3. Single-character markers: ZWNJ x ZWNJ / ZWJ x ZWJ.
        result = encodeSingles(result, ScriptMarkers.ZWNJ,
                ScriptMarkers.SUPERSCRIPT, SuperscriptReverse.REVERSE);
        result = encodeSingles(result, ScriptMarkers.ZWJ,
                ScriptMarkers.SUBSCRIPT, SubscriptReverse.REVERSE);

        // 4. Bare Unicode sub/superscript digits (typed as ^^2 / __2).
        for (Map.Entry<Character, String> entry : SuperscriptReverse.REVERSE.entrySet()) {
            result = result.replace(String.valueOf(entry.getKey()),
                    ScriptMarkers.SUPERSCRIPT + entry.getValue());
        }
        for (Map.Entry<Character, String> entry : SubscriptReverse.REVERSE.entrySet()) {
            result = result.replace(String.valueOf(entry.getKey()),
                    ScriptMarkers.SUBSCRIPT + entry.getValue());
        }

        // 5. Safety net: nothing invisible may reach nc.exe.
        result = result.replace(String.valueOf(ScriptMarkers.ZWJ), "")
                .replace(String.valueOf(ScriptMarkers.ZWNJ), "");

        return result;
    }

    /**
     * Encodes just one identifier — used by the CLI when the user types
     * {@code clear <name>} with a Greek/Tamil/subscripted name.
     *
     * @param visualName the name as the user typed or sees it
     * @return the cleaned name used as the workspace key
     */
    public static String encodeName(String visualName) {
        return visualName == null ? null : encode(visualName).trim();
    }

    // -----------------------------------------------------------------
    // Internals
    // -----------------------------------------------------------------

    /** Replaces {@code MARKER content MARKER} spans with {@code marker + content}. */
    private static String encodeGroups(String text, String groupMarker,
            String cleanedMarker, Map<Character, String> digitMap) {
        String result = text;
        int guard = 0;
        while (result.contains(groupMarker) && guard++ < 512) {
            int start = result.indexOf(groupMarker);
            int end = result.indexOf(groupMarker, start + groupMarker.length());
            if (end <= start) {
                break;
            }
            String content = result.substring(start + groupMarker.length(), end);
            result = result.substring(0, start)
                    + cleanedMarker + normalizeDigits(content, digitMap)
                    + result.substring(end + groupMarker.length());
        }
        return result;
    }

    /** Replaces {@code M x M} (single marker either side of one char). */
    private static String encodeSingles(String text, char marker,
            String cleanedMarker, Map<Character, String> digitMap) {
        StringBuilder out = new StringBuilder(text.length());
        int i = 0;
        while (i < text.length()) {
            char c = text.charAt(i);
            if (c == marker && i + 2 < text.length() && text.charAt(i + 2) == marker) {
                char inner = text.charAt(i + 1);
                String mapped = digitMap.get(inner);
                out.append(cleanedMarker).append(mapped == null ? String.valueOf(inner) : mapped);
                i += 3;
                continue;
            }
            out.append(c);
            i++;
        }
        return out.toString();
    }

    /** Turns Unicode sub/superscript digits inside a group back into plain digits. */
    private static String normalizeDigits(String content, Map<Character, String> digitMap) {
        StringBuilder out = new StringBuilder(content.length());
        for (char c : content.toCharArray()) {
            String mapped = digitMap.get(c);
            out.append(mapped == null ? String.valueOf(c) : mapped);
        }
        return out.toString();
    }

    /**
     * Flattens every symbol dictionary into one list sorted by descending key
     * length, so a longer visual form is always matched before a shorter one
     * that happens to be its prefix.
     */
    private static List<Map.Entry<String, String>> buildSymbolTable() {
        Map<String, String> merged = new LinkedHashMap<>();
        merged.putAll(GreekReverse.REVERSE);
        merged.putAll(TamilReverse.REVERSE);
        merged.putAll(SanskritReverse.REVERSE);
        merged.putAll(MalayalamReverse.REVERSE);
        merged.putAll(TeluguReverse.REVERSE);
        merged.putAll(UniconstantReverse.REVERSE);

        List<Map.Entry<String, String>> entries = new ArrayList<>(merged.entrySet());
        entries.sort(Comparator
                .comparingInt((Map.Entry<String, String> e) -> e.getKey().length())
                .reversed()
                .thenComparing(Map.Entry::getKey));
        return List.copyOf(entries);
    }

    /** @return the flattened visual-to-cleaned table (used by the decoder). */
    static List<Map.Entry<String, String>> symbolTable() {
        return SYMBOLS;
    }
}
