package language.semantic;

public class SemanticEncoder {

    public static String encode(String uiText) {
        String result = uiText;

        // ---- symbol replacement phase ----
        // Greek
        for (var e : GreekReverse.REVERSE.entrySet()) {
            result = result.replace(e.getKey(), e.getValue());
        }

        // Tamil
        for (var e : TamilReverse.REVERSE.entrySet()) {
            result = result.replace(e.getKey(), e.getValue());
        }

        // Sanskrit
        for (var e : SanskritReverse.REVERSE.entrySet()) {
            result = result.replace(e.getKey(), e.getValue());
        }

        // Malayalam
        for (var e : MalayalamReverse.REVERSE.entrySet()) {
            result = result.replace(e.getKey(), e.getValue());
        }

        // Telugu
        for (var e : TeluguReverse.REVERSE.entrySet()) {
            result = result.replace(e.getKey(), e.getValue());
        }

        // Uni constants
        for (var e : UniconstantReverse.REVERSE.entrySet()) {
            result = result.replace(e.getKey(), e.getValue());
        }

        // --- Superscript reverse ---
        // Styled superscript groups
        while (result.contains(SuperscriptReverse.MARKER)) {
            int start = result.indexOf(SuperscriptReverse.MARKER);
            int end = result.indexOf(SuperscriptReverse.MARKER, start + 3);

            if (end > start) {
                String content = result.substring(start + 3, end);
                String normalized = normalizeGroupContent(content, SuperscriptReverse.REVERSE);
                result = result.substring(0, start)
                        + "_t" + normalized
                        + result.substring(end + 3);
            } else {
                break;
            }
        }

        // ---- apply unicode superscript replacements ----
        for (var e : SuperscriptReverse.REVERSE.entrySet()) {
            result = result.replace(
                    String.valueOf(e.getKey()),
                    "_t" + e.getValue());
        }

        // --- Subscript reverse ---
        // Styled subscript groups
        while (result.contains(SubscriptReverse.MARKER)) {
            int start = result.indexOf(SubscriptReverse.MARKER);
            int end = result.indexOf(SubscriptReverse.MARKER, start + 3);

            if (end > start) {
                String content = result.substring(start + 3, end);
                String normalized = normalizeGroupContent(content, SubscriptReverse.REVERSE);
                result = result.substring(0, start)
                        + "_s" + normalized
                        + result.substring(end + 3);
            } else {
                break;
            }
        }

        // ---- apply unicode subscript replacements ----
        for (var e : SubscriptReverse.REVERSE.entrySet()) {
            result = result.replace(
                    String.valueOf(e.getKey()),
                    "_s" + e.getValue());
        }

        return result;

    }

    private static String normalizeGroupContent(String content, java.util.Map<Character, String> reverseMap) {
        String normalized = content;

        for (var entry : reverseMap.entrySet()) {
            normalized = normalized.replace(
                    String.valueOf(entry.getKey()),
                    entry.getValue());
        }

        return normalized;
    }
}
