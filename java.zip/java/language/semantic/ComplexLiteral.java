package language.semantic;

import java.util.regex.Pattern;

/**
 * Complex numbers: {@code i} in the editor, {@code j} in the interpreter.
 *
 * <h3>The language rule</h3>
 * A number written with {@code i} straight after it is imaginary:
 *
 * <pre>
 *   D = 1+5i;        5i      2.5i     .5i     1e-3i
 * </pre>
 *
 * The {@code i} must touch the number and must not be followed by a letter,
 * digit or {@code _}. So {@code i}, {@code i1} and {@code i2} stay ordinary
 * variables (a loop such as {@code for i = [1:3]:} is unaffected),
 * {@code 5 i} and {@code 5i2} are errors, and {@code 1+i} is the variable
 * {@code i}; the imaginary unit on its own is written {@code 1i}.
 *
 * <h3>Two directions</h3>
 * <ul>
 * <li>{@link #toBackend} rewrites {@code 5i} as {@code 5j} for {@code nc.exe},
 * in code only: {@code "5i"} inside a string is left as typed.</li>
 * <li>{@link #toDisplay} turns what {@code nc.exe} prints back into the
 * editor's form: {@code (1+5j)} becomes {@code 1+5i}, {@code 5j} becomes
 * {@code 5i}.</li>
 * </ul>
 */
public final class ComplexLiteral {

    /** The imaginary unit the user writes. */
    public static final char FRONT_UNIT = 'i';

    /** The imaginary unit the interpreter reads and prints. */
    public static final char BACK_UNIT = 'j';

    /** Integer, decimal or scientific number, unsigned. */
    private static final String NUM = "(?:\\d+(?:\\.\\d*)?|\\.\\d+)(?:[eE][+-]?\\d+)?";

    /** Not part of a name before the number (x2i is a name, not 2i). */
    private static final String NOT_AFTER_NAME = "(?<![\\p{L}\\p{M}\\p{N}_.\\u200C\\u200D])";

    /** Nothing name-like after the unit (5in, 5i2 are not complex). */
    private static final String NOT_BEFORE_NAME = "(?![\\p{L}\\p{M}\\p{N}_\\u200C\\u200D])";

    private static final Pattern FRONT = Pattern.compile(
            NOT_AFTER_NAME + "(" + NUM + ")" + FRONT_UNIT + NOT_BEFORE_NAME);

    /** {@code (1+5j)}, {@code (-2.5-0.5j)}: the backend's printed complex value. */
    private static final Pattern BACK_PAIR = Pattern.compile(
            "\\(\\s*([+-]?" + NUM + ")\\s*([+-])\\s*(" + NUM + ")" + BACK_UNIT + "\\s*\\)");

    /** A bare imaginary part, {@code 5j}. */
    private static final Pattern BACK_SINGLE = Pattern.compile(
            NOT_AFTER_NAME + "(" + NUM + ")" + BACK_UNIT + NOT_BEFORE_NAME);

    private ComplexLiteral() {
    }

    /**
     * Rewrites every imaginary literal in the code of {@code text} for the
     * interpreter. Strings and comments are not touched. Idempotent.
     *
     * @param text editor text, a line or a whole file
     * @return the text with {@code 5i} written as {@code 5j}
     */
    public static String toBackend(String text) {
        if (text == null || text.indexOf(FRONT_UNIT) < 0) {
            return text;
        }
        return CodeSegments.mapCode(text, ComplexLiteral::rewriteCode);
    }

    /**
     * The same rewrite on text already known to be code (no strings in it).
     *
     * @param code one code segment
     * @return the rewritten code
     */
    static String rewriteCode(String code) {
        if (code == null || code.indexOf(FRONT_UNIT) < 0) {
            return code;
        }
        return FRONT.matcher(code).replaceAll("$1" + BACK_UNIT);
    }

    /**
     * Turns interpreter output or a value preview into the editor's form.
     *
     * @param text what {@code nc.exe} printed
     * @return {@code (1+5j)} as {@code 1+5i}, {@code 5j} as {@code 5i}; other text unchanged
     */
    public static String toDisplay(String text) {
        if (text == null || text.indexOf(BACK_UNIT) < 0) {
            return text;
        }
        String out = BACK_PAIR.matcher(text).replaceAll("$1$2$3" + FRONT_UNIT);
        return BACK_SINGLE.matcher(out).replaceAll("$1" + FRONT_UNIT);
    }

    /**
     * @param token one token, e.g. {@code 5i}
     * @return true when it is an imaginary literal as the user writes it
     */
    public static boolean isImaginaryLiteral(String token) {
        return token != null && token.matches(NUM + FRONT_UNIT);
    }
}
