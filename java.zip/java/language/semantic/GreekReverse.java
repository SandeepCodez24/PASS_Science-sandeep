package language.semantic;

import java.util.HashMap;
import java.util.Map;

public class GreekReverse {
    public static final Map<String, String> REVERSE = new HashMap<>();

    static {
        REVERSE.put("α", "var_alpha");
        REVERSE.put("β", "var_beta");
        REVERSE.put("γ", "var_gamma");
        REVERSE.put("δ", "var_delta");
        REVERSE.put("ε", "var_epsilon");
        REVERSE.put("ζ", "var_zeta");
        REVERSE.put("η", "var_eta");
        REVERSE.put("θ", "var_theta");
        REVERSE.put("ι", "var_iota");
        REVERSE.put("κ", "var_kappa");
        REVERSE.put("λ", "var_lambda");
        REVERSE.put("μ", "var_mu");
        REVERSE.put("ν", "var_nu");
        REVERSE.put("ξ", "var_xi");
        REVERSE.put("ο", "var_omicron");
        REVERSE.put("π", "var_pi");
        REVERSE.put("ρ", "var_rho");
        REVERSE.put("σ", "var_sigma");
        REVERSE.put("τ", "var_tau");
        REVERSE.put("υ", "var_upsilon");
        REVERSE.put("φ", "var_phi");
        REVERSE.put("χ", "var_chi");
        REVERSE.put("ψ", "var_psi");
        REVERSE.put("ω", "var_omega");
    }
}