package language.semantic;

import java.util.HashMap;
import java.util.Map;

public class SanskritReverse {
    public static final Map<String, String> REVERSE = new HashMap<>();
    static {
        // ===== VOWELS (स्वर) =====
        REVERSE.put("अ", "var_sanskrit_a");
        REVERSE.put("आ", "var_sanskrit_aa");
        REVERSE.put("इ", "var_sanskrit_i");
        REVERSE.put("ई", "var_sanskrit_ii");
        REVERSE.put("उ", "var_sanskrit_u");
        REVERSE.put("ऊ", "var_sanskrit_uu");
        REVERSE.put("ऋ", "var_sanskrit_r");
        REVERSE.put("ॠ", "var_sanskrit_rr");
        REVERSE.put("ऌ", "var_sanskrit_l");
        REVERSE.put("ॡ", "var_sanskrit_ll");
        REVERSE.put("ए", "var_sanskrit_e");
        REVERSE.put("ऐ", "var_sanskrit_ai");
        REVERSE.put("ओ", "var_sanskrit_o");
        REVERSE.put("औ", "var_sanskrit_au");

        // ===== CONSONANTS (व्यंजन) =====
        REVERSE.put("क", "var_sanskrit_ka");
        REVERSE.put("ख", "var_sanskrit_kha");
        REVERSE.put("ग", "var_sanskrit_ga");
        REVERSE.put("घ", "var_sanskrit_gha");
        REVERSE.put("ङ", "var_sanskrit_nga");

        REVERSE.put("च", "var_sanskrit_cha");
        REVERSE.put("छ", "var_sanskrit_chha");
        REVERSE.put("ज", "var_sanskrit_ja");
        REVERSE.put("झ", "var_sanskrit_jha");
        REVERSE.put("ञ", "var_sanskrit_nya");

        REVERSE.put("ट", "var_sanskrit_tta");
        REVERSE.put("ठ", "var_sanskrit_ttha");
        REVERSE.put("ड", "var_sanskrit_dda");
        REVERSE.put("ढ", "var_sanskrit_ddha");
        REVERSE.put("ण", "var_sanskrit_nna");

        REVERSE.put("त", "var_sanskrit_ta");
        REVERSE.put("थ", "var_sanskrit_tha");
        REVERSE.put("द", "var_sanskrit_da");
        REVERSE.put("ध", "var_sanskrit_dha");
        REVERSE.put("न", "var_sanskrit_na");

        REVERSE.put("प", "var_sanskrit_pa");
        REVERSE.put("फ", "var_sanskrit_pha");
        REVERSE.put("ब", "var_sanskrit_ba");
        REVERSE.put("भ", "var_sanskrit_bha");
        REVERSE.put("म", "var_sanskrit_ma");

        REVERSE.put("य", "var_sanskrit_ya");
        REVERSE.put("र", "var_sanskrit_ra");
        REVERSE.put("ल", "var_sanskrit_la");
        REVERSE.put("व", "var_sanskrit_va");

        REVERSE.put("श", "var_sanskrit_sha");
        REVERSE.put("ष", "var_sanskrit_ssha");
        REVERSE.put("स", "var_sanskrit_sa");
        REVERSE.put("ह", "var_sanskrit_ha");

        // ===== COMPOUND LETTERS (संयुक्ताक्षर) =====
        REVERSE.put("क्ष", "var_sanskrit_ksha");
        REVERSE.put("त्र", "var_sanskrit_tra");
        REVERSE.put("ज्ञ", "var_sanskrit_gya");

        // ===== SPECIAL SYMBOLS =====
        REVERSE.put("ं", "var_sanskrit_am");
        REVERSE.put("ः", "var_sanskrit_ah");
        REVERSE.put("ॐ", "var_sanskrit_om");
    }
}