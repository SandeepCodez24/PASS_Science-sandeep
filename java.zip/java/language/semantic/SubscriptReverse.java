package language.semantic;

import java.util.HashMap;
import java.util.Map;

public class SubscriptReverse {

    public static final Map<Character, String> REVERSE = new HashMap<>();

    static {
        REVERSE.put('₀', "0");
        REVERSE.put('₁', "1");
        REVERSE.put('₂', "2");
        REVERSE.put('₃', "3");
        REVERSE.put('₄', "4");
        REVERSE.put('₅', "5");
        REVERSE.put('₆', "6");
        REVERSE.put('₇', "7");
        REVERSE.put('₈', "8");
        REVERSE.put('₉', "9");
    }

    public static final String MARKER = "\u200D\u200D\u200D";
}
