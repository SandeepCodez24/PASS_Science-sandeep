package language.semantic;

import java.util.HashMap;
import java.util.Map;

/**
 * Unicode subscript character -> the plain character it stands for.
 *
 * <p>Read by {@link SemanticEncoder} when folding a subscript into the cleaned
 * form: a standalone subscript glyph becomes
 * {@code ScriptMarkers.SUBSCRIPT + plain}.
 *
 * <h3>Letters as well as digits</h3>
 * The map used to hold digits only. Any other subscript glyph therefore passed
 * straight through the encoder and landed in {@code cleaned_Runfile.nc} as a
 * raw non-ASCII character, which the lexer cannot read as part of an
 * identifier. Every subscript letter Unicode actually defines is now covered,
 * so a pasted or CLI-entered glyph round-trips instead of corrupting the file.
 *
 * <p>Unicode has no subscript form for b, c, d, f, g, q, w, y or z. Those must
 * be written with the editor's styled-group markers, which the encoder handles
 * separately and which impose no such limit.
 */
public class SubscriptReverse {

    public static final Map<Character, String> REVERSE = new HashMap<>();

    static {
        // ---- digits ----
        REVERSE.put('\u2080', "0");
        REVERSE.put('\u2081', "1");
        REVERSE.put('\u2082', "2");
        REVERSE.put('\u2083', "3");
        REVERSE.put('\u2084', "4");
        REVERSE.put('\u2085', "5");
        REVERSE.put('\u2086', "6");
        REVERSE.put('\u2087', "7");
        REVERSE.put('\u2088', "8");
        REVERSE.put('\u2089', "9");

        // ---- letters (the subset Unicode defines) ----
        REVERSE.put('\u2090', "a");
        REVERSE.put('\u2091', "e");
        REVERSE.put('\u2095', "h");
        REVERSE.put('\u1D62', "i");
        REVERSE.put('\u2C7C', "j");
        REVERSE.put('\u2096', "k");
        REVERSE.put('\u2097', "l");
        REVERSE.put('\u2098', "m");
        REVERSE.put('\u2099', "n");
        REVERSE.put('\u2092', "o");
        REVERSE.put('\u209A', "p");
        REVERSE.put('\u1D63', "r");
        REVERSE.put('\u209B', "s");
        REVERSE.put('\u209C', "t");
        REVERSE.put('\u1D64', "u");
        REVERSE.put('\u1D65', "v");
        REVERSE.put('\u2093', "x");
    }

    /** Editor marker delimiting a multi-character subscript group. */
    public static final String MARKER = "\u200D\u200D\u200D";
}
