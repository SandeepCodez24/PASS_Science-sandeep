package language.semantic;

import java.util.HashMap;
import java.util.Map;

public class MalayalamReverse {
    public static final Map<String, String> REVERSE = new HashMap<>();

    static{
        REVERSE.put("അ", "var_malayalam_a");
        REVERSE.put("ആ", "var_malayalam_aa");
        REVERSE.put("ഇ", "var_malayalam_e");
        REVERSE.put("ഈ", "var_malayalam_ee");
        REVERSE.put("ഉ", "var_malayalam_u");
        REVERSE.put("ഊ", "var_malayalam_uu");
        REVERSE.put("എ", "var_malayalam_ea");
        REVERSE.put("ഏ", "var_malayalam_eaa");
        REVERSE.put("ഐ", "var_malayalam_i");
        REVERSE.put("ഒ", "var_malayalam_o");
        REVERSE.put("ഓ", "var_malayalam_oo");
        REVERSE.put("ഔ", "var_malayalam_ou");
        REVERSE.put("ஃ", "var_malayalam_akg");

                // // ---- malayalam consonants (sample – extend freely) ----
        REVERSE.put("ക്", "var_malayalam_ik");
        REVERSE.put("ങ്", "var_malayalam_ing");
        REVERSE.put("ച്", "var_malayalam_ich");
        REVERSE.put("ഞ്", "var_malayalam_ina");
        REVERSE.put("ട്", "var_malayalam_id");
        REVERSE.put("ണ്", "var_malayalam_iN");
        REVERSE.put("ത്", "var_malayalam_ith");
        REVERSE.put("ന്", "var_malayalam_iNn");
        REVERSE.put("പ്", "var_malayalam_ip");
        REVERSE.put("ം", "var_malayalam_im"); // pay attention
        REVERSE.put("യ്", "var_malayalam_iy");
        REVERSE.put("ര്", "var_malayalam_ir");
        REVERSE.put("ല്", "var_malayalam_il");
        REVERSE.put("വ്", "var_malayalam_iv");
        REVERSE.put("ഴ്", "var_malayalam_izh");
        REVERSE.put("ള്", "var_malayalam_iL");
        REVERSE.put("റ്", "var_malayalam_iR");
        REVERSE.put("ന്", "var_malayalam_in");
        /////// group 01
        REVERSE.put("ക", "var_malayalam_ka");
        REVERSE.put("ഖ", "var_malayalam_kha");
        REVERSE.put("ഗ", "var_malayalam_ga");
        REVERSE.put("ഘ", "var_malayalam_gha");
        REVERSE.put("ങ", "var_malayalam_nga");

        REVERSE.put("ച", "var_malayalam_cha");
        REVERSE.put("ഛ", "var_malayalam_chha");
        REVERSE.put("ജ", "var_malayalam_ja");
        REVERSE.put("ഝ", "var_malayalam_jha");
        REVERSE.put("ഞ", "var_malayalam_gna");

        REVERSE.put("ട", "var_malayalam_tta");
        REVERSE.put("ഠ", "var_malayalam_ttha");
        REVERSE.put("ഡ", "var_malayalam_dda");
        REVERSE.put("ഢ", "var_malayalam_ddha");
        REVERSE.put("ണ", "var_malayalam_Na");

        REVERSE.put("ത", "var_malayalam_tha");
        REVERSE.put("ഥ", "var_malayalam_thha");
        REVERSE.put("ദ", "var_malayalam_dha");
        REVERSE.put("ധ", "var_malayalam_dhha");
        REVERSE.put("ന", "var_malayalam_na");

        REVERSE.put("പ", "var_malayalam_pa");
        REVERSE.put("ഫ", "var_malayalam_pha");
        REVERSE.put("ബ", "var_malayalam_ba");
        REVERSE.put("ഭ", "var_malayalam_bha");
        REVERSE.put("മ", "var_malayalam_ma");

        REVERSE.put("യ", "var_malayalam_ya");
        REVERSE.put("ര", "var_malayalam_ra");
        REVERSE.put("ല", "var_malayalam_la");
        REVERSE.put("വ", "var_malayalam_va");

        REVERSE.put("ശ", "var_malayalam_sha");
        REVERSE.put("ഷ", "var_malayalam_ssa");
        REVERSE.put("സ", "var_malayalam_sa");
        REVERSE.put("ഹ", "var_malayalam_ha");

        REVERSE.put("ള", "var_malayalam_La");
        REVERSE.put("ഴ", "var_malayalam_zha");
        REVERSE.put("റ", "var_malayalam_Ra");

        ////// group 2
        REVERSE.put("കാ", "var_malayalam_kaa");
        REVERSE.put("ഖാ", "var_malayalam_khaa");
        REVERSE.put("ഗാ", "var_malayalam_gaa");
        REVERSE.put("ഘാ", "var_malayalam_ghaa");
        REVERSE.put("ങാ", "var_malayalam_ngaa");

        REVERSE.put("ചാ", "var_malayalam_chaa");
        REVERSE.put("ഛാ", "var_malayalam_chhaa");
        REVERSE.put("ജാ", "var_malayalam_jaa");
        REVERSE.put("ഝാ", "var_malayalam_jhaa");
        REVERSE.put("ഞാ", "var_malayalam_gnaa");

        REVERSE.put("ടാ", "var_malayalam_ttaa");
        REVERSE.put("ഠാ", "var_malayalam_tthaa");
        REVERSE.put("ഡാ", "var_malayalam_ddaa");
        REVERSE.put("ഢാ", "var_malayalam_ddhaa");
        REVERSE.put("ണാ", "var_malayalam_Naa");

        REVERSE.put("താ", "var_malayalam_thaa");
        REVERSE.put("ഥാ", "var_malayalam_thhaa");
        REVERSE.put("ദാ", "var_malayalam_dhaa");
        REVERSE.put("ധാ", "var_malayalam_dhhaa");
        REVERSE.put("നാ", "var_malayalam_naa");

        REVERSE.put("പാ", "var_malayalam_paa");
        REVERSE.put("ഫാ", "var_malayalam_phaa");
        REVERSE.put("ബാ", "var_malayalam_baa");
        REVERSE.put("ഭാ", "var_malayalam_bhaa");
        REVERSE.put("മാ", "var_malayalam_maa");

        REVERSE.put("യാ", "var_malayalam_yaa");
        REVERSE.put("രാ", "var_malayalam_raa");
        REVERSE.put("ലാ", "var_malayalam_laa");
        REVERSE.put("വാ", "var_malayalam_vaa");

        REVERSE.put("ശാ", "var_malayalam_shaa");
        REVERSE.put("ഷാ", "var_malayalam_ssaa");
        REVERSE.put("സാ", "var_malayalam_saa");
        REVERSE.put("ഹാ", "var_malayalam_haa");

        REVERSE.put("ളാ", "var_malayalam_Laa");
        REVERSE.put("ഴാ", "var_malayalam_zhaa");
        REVERSE.put("റാ", "var_malayalam_Ra");
        /////// group 03
        REVERSE.put("കി", "var_malayalam_ki");
        REVERSE.put("ഖി", "var_malayalam_khi");
        REVERSE.put("ഗി", "var_malayalam_gi");
        REVERSE.put("ഘി", "var_malayalam_ghi");
        REVERSE.put("ങി", "var_malayalam_ngi");

        REVERSE.put("ചി", "var_malayalam_chi");
        REVERSE.put("ഛി", "var_malayalam_chhi");
        REVERSE.put("ജി", "var_malayalam_ji");
        REVERSE.put("ഝി", "var_malayalam_jhi");
        REVERSE.put("ഞി", "var_malayalam_gni");

        REVERSE.put("ടി", "var_malayalam_tti");
        REVERSE.put("ഠി", "var_malayalam_tthi");
        REVERSE.put("ഡി", "var_malayalam_ddi");
        REVERSE.put("ഢി", "var_malayalam_ddhi");
        REVERSE.put("ണി", "var_malayalam_Ni");

        REVERSE.put("തി", "var_malayalam_thi");
        REVERSE.put("ഥി", "var_malayalam_thhi");
        REVERSE.put("ദി", "var_malayalam_dhi");
        REVERSE.put("ധി", "var_malayalam_dhhi");
        REVERSE.put("നി", "var_malayalam_ni");

        REVERSE.put("പി", "var_malayalam_pi");
        REVERSE.put("ഫി", "var_malayalam_phi");
        REVERSE.put("ബി", "var_malayalam_bi");
        REVERSE.put("ഭി", "var_malayalam_bhi");
        REVERSE.put("മി", "var_malayalam_mi");

        REVERSE.put("യി", "var_malayalam_yi");
        REVERSE.put("രി", "var_malayalam_ri");
        REVERSE.put("ലി", "var_malayalam_li");
        REVERSE.put("വി", "var_malayalam_vi");

        REVERSE.put("ശി", "var_malayalam_shi");
        REVERSE.put("ഷി", "var_malayalam_ssi");
        REVERSE.put("സി", "var_malayalam_si");
        REVERSE.put("ഹി", "var_malayalam_hi");

        REVERSE.put("ളി", "var_malayalam_Lii");
        REVERSE.put("ഴി", "var_malayalam_zhi");
        REVERSE.put("റി", "var_malayalam_Ri");
        ////// Group 04
        REVERSE.put("കീ", "var_malayalam_kii");
        REVERSE.put("ഖീ", "var_malayalam_khii");
        REVERSE.put("ഗീ", "var_malayalam_gii");
        REVERSE.put("ഘീ", "var_malayalam_ghii");
        REVERSE.put("ങീ", "var_malayalam_ngii");

        REVERSE.put("ചീ", "var_malayalam_chii");
        REVERSE.put("ഛീ", "var_malayalam_chhii");
        REVERSE.put("ജീ", "var_malayalam_jii");
        REVERSE.put("ഝീ", "var_malayalam_jhii");
        REVERSE.put("ഞീ", "var_malayalam_gnii");

        REVERSE.put("ടീ", "var_malayalam_ttii");
        REVERSE.put("ഠീ", "var_malayalam_tthii");
        REVERSE.put("ഡീ", "var_malayalam_ddii");
        REVERSE.put("ഢീ", "var_malayalam_ddhii");
        REVERSE.put("ണീ", "var_malayalam_Nii");

        REVERSE.put("തീ", "var_malayalam_thii");
        REVERSE.put("ഥീ", "var_malayalam_thhii");
        REVERSE.put("ദീ", "var_malayalam_dhii");
        REVERSE.put("ധീ", "var_malayalam_dhhii");
        REVERSE.put("നീ", "var_malayalam_nii");

        REVERSE.put("പീ", "var_malayalam_pii");
        REVERSE.put("ഫീ", "var_malayalam_phii");
        REVERSE.put("ബീ", "var_malayalam_bii");
        REVERSE.put("ഭീ", "var_malayalam_bhii");
        REVERSE.put("മീ", "var_malayalam_mii");

        REVERSE.put("യീ", "var_malayalam_yii");
        REVERSE.put("രീ", "var_malayalam_rii");
        REVERSE.put("ലീ", "var_malayalam_lii");
        REVERSE.put("വീ", "var_malayalam_vii");

        REVERSE.put("ശീ", "var_malayalam_shii");
        REVERSE.put("ഷീ", "var_malayalam_ssii");
        REVERSE.put("സീ", "var_malayalam_sii");
        REVERSE.put("ഹീ", "var_malayalam_hii");

        REVERSE.put("ളീ", "var_malayalam_Lii");
        REVERSE.put("ഴീ", "var_malayalam_zhii");
        REVERSE.put("റീ", "var_malayalam_Rii");
        /////// Group 05 
        REVERSE.put("കു", "var_malayalam_ku");
        REVERSE.put("ഖു", "var_malayalam_khu");
        REVERSE.put("ഗു", "var_malayalam_gu");
        REVERSE.put("ഘു", "var_malayalam_ghu");
        REVERSE.put("ങു", "var_malayalam_ngu");

        REVERSE.put("ചു", "var_malayalam_chu");
        REVERSE.put("ഛു", "var_malayalam_chhu");
        REVERSE.put("ജു", "var_malayalam_ju");
        REVERSE.put("ഝു", "var_malayalam_jhu");
        REVERSE.put("ഞു", "var_malayalam_gnu");

        REVERSE.put("ടു", "var_malayalam_ttu");
        REVERSE.put("ഠു", "var_malayalam_tthu");
        REVERSE.put("ഡു", "var_malayalam_ddu");
        REVERSE.put("ഢു", "var_malayalam_ddhu");
        REVERSE.put("ണു", "var_malayalam_Nu");

        REVERSE.put("തു", "var_malayalam_thu");
        REVERSE.put("ഥു", "var_malayalam_thhu");
        REVERSE.put("ദു", "var_malayalam_dhu");
        REVERSE.put("ധു", "var_malayalam_dhhu");
        REVERSE.put("നു", "var_malayalam_nu");

        REVERSE.put("പു", "var_malayalam_pu");
        REVERSE.put("ഫു", "var_malayalam_phu");
        REVERSE.put("ബു", "var_malayalam_bu");
        REVERSE.put("ഭു", "var_malayalam_bhu");
        REVERSE.put("മു", "var_malayalam_mu");

        REVERSE.put("യു", "var_malayalam_yu");
        REVERSE.put("രു", "var_malayalam_ru");
        REVERSE.put("ലു", "var_malayalam_lu");
        REVERSE.put("വു", "var_malayalam_vu");

        REVERSE.put("ശു", "var_malayalam_shu");
        REVERSE.put("ഷു", "var_malayalam_sshu");
        REVERSE.put("സു", "var_malayalam_su");
        REVERSE.put("ഹു", "var_malayalam_hu");

        REVERSE.put("ളു", "var_malayalam_Lu");
        REVERSE.put("ഴു", "var_malayalam_zhu");
        REVERSE.put("റു", "var_malayalam_Ru");
        ///// Group 06 
        REVERSE.put("കൂ", "var_malayalam_kuu");
        REVERSE.put("ഖൂ", "var_malayalam_khuu");
        REVERSE.put("ഗൂ", "var_malayalam_guu");
        REVERSE.put("ഘൂ", "var_malayalam_ghuu");
        REVERSE.put("ങൂ", "var_malayalam_nguu");

        REVERSE.put("ചൂ", "var_malayalam_chuu");
        REVERSE.put("ഛൂ", "var_malayalam_chhuu");
        REVERSE.put("ജൂ", "var_malayalam_juu");
        REVERSE.put("ഝൂ", "var_malayalam_jhuu");
        REVERSE.put("ഞൂ", "var_malayalam_gnuu");

        REVERSE.put("ടൂ", "var_malayalam_ttuu");
        REVERSE.put("ഠൂ", "var_malayalam_tthuu");
        REVERSE.put("ഡൂ", "var_malayalam_dduu");
        REVERSE.put("ഢൂ", "var_malayalam_ddhuu");
        REVERSE.put("ണൂ", "var_malayalam_Nuu");

        REVERSE.put("തൂ", "var_malayalam_thuu");
        REVERSE.put("ഥൂ", "var_malayalam_thhuu");
        REVERSE.put("ദൂ", "var_malayalam_dhuu");
        REVERSE.put("ധൂ", "var_malayalam_dhhuu");
        REVERSE.put("നൂ", "var_malayalam_nuu");

        REVERSE.put("പൂ", "var_malayalam_puu");
        REVERSE.put("ഫൂ", "var_malayalam_phuu");
        REVERSE.put("ബൂ", "var_malayalam_buu");
        REVERSE.put("ഭൂ", "var_malayalam_bhuu");
        REVERSE.put("മൂ", "var_malayalam_muu");

        REVERSE.put("യൂ", "var_malayalam_yuu");
        REVERSE.put("രൂ", "var_malayalam_ruu");
        REVERSE.put("ലൂ", "var_malayalam_luu");
        REVERSE.put("വൂ", "var_malayalam_vuu");

        REVERSE.put("ശൂ", "var_malayalam_shuu");
        REVERSE.put("ഷൂ", "var_malayalam_sshuu");
        REVERSE.put("സൂ", "var_malayalam_suu");
        REVERSE.put("ഹൂ", "var_malayalam_huu");

        REVERSE.put("ളൂ", "var_malayalam_Luu");
        REVERSE.put("ഴൂ", "var_malayalam_zhuu");
        REVERSE.put("റൂ", "var_malayalam_Ruu"); 
        ///// Group 07
        REVERSE.put("കെ", "var_malayalam_ke");
        REVERSE.put("ഖെ", "var_malayalam_khe");
        REVERSE.put("ഗെ", "var_malayalam_ge");
        REVERSE.put("ഘെ", "var_malayalam_ghe");
        REVERSE.put("ങെ", "var_malayalam_nge");

        REVERSE.put("ചെ", "var_malayalam_che");
        REVERSE.put("ഛെ", "var_malayalam_chhe");
        REVERSE.put("ജെ", "var_malayalam_je");
        REVERSE.put("ഝെ", "var_malayalam_jhe");
        REVERSE.put("ഞെ", "var_malayalam_gne");

        REVERSE.put("ടെ", "var_malayalam_te");
        REVERSE.put("ഠെ", "var_malayalam_tte");
        REVERSE.put("ഡെ", "var_malayalam_de");
        REVERSE.put("ഢെ", "var_malayalam_dhe");
        REVERSE.put("ണെ", "var_malayalam_Ne");

        REVERSE.put("തെ", "var_malayalam_the");
        REVERSE.put("ഥെ", "var_malayalam_thhe");
        REVERSE.put("ദെ", "var_malayalam_dhe2");
        REVERSE.put("ധെ", "var_malayalam_dhhe");
        REVERSE.put("നെ", "var_malayalam_ne");

        REVERSE.put("പെ", "var_malayalam_pe");
        REVERSE.put("ഫെ", "var_malayalam_phe");
        REVERSE.put("ബെ", "var_malayalam_be");
        REVERSE.put("ഭെ", "var_malayalam_bhe");
        REVERSE.put("മെ", "var_malayalam_me");

        REVERSE.put("യെ", "var_malayalam_ye");
        REVERSE.put("രെ", "var_malayalam_re");
        REVERSE.put("ലെ", "var_malayalam_le");
        REVERSE.put("വെ", "var_malayalam_ve");

        REVERSE.put("ശെ", "var_malayalam_she");
        REVERSE.put("ഷെ", "var_malayalam_sshe");
        REVERSE.put("സെ", "var_malayalam_se");
        REVERSE.put("ഹെ", "var_malayalam_he");

        REVERSE.put("ളെ", "var_malayalam_Le");
        REVERSE.put("ഴെ", "var_malayalam_zhe");
        REVERSE.put("റെ", "var_malayalam_Re");
        ///// Group 08
        REVERSE.put("കേ", "var_malayalam_kea");
        REVERSE.put("ഖേ", "var_malayalam_khea");
        REVERSE.put("ഗേ", "var_malayalam_gea");
        REVERSE.put("ഘേ", "var_malayalam_ghea");
        REVERSE.put("ങേ", "var_malayalam_ngea");

        REVERSE.put("ചേ", "var_malayalam_chea");
        REVERSE.put("ഛേ", "var_malayalam_chhea");
        REVERSE.put("ജേ", "var_malayalam_jea");
        REVERSE.put("ഝേ", "var_malayalam_jhea");
        REVERSE.put("ഞേ", "var_malayalam_gnea");

        REVERSE.put("ടേ", "var_malayalam_tea");
        REVERSE.put("ഠേ", "var_malayalam_ttea");
        REVERSE.put("ഡേ", "var_malayalam_dea");
        REVERSE.put("ഢേ", "var_malayalam_dhea");
        REVERSE.put("ണേ", "var_malayalam_Nea");

        REVERSE.put("തേ", "var_malayalam_thea");
        REVERSE.put("ഥേ", "var_malayalam_thhea");
        REVERSE.put("ദേ", "var_malayalam_dhea2");
        REVERSE.put("ധേ", "var_malayalam_dhhea");
        REVERSE.put("നേ", "var_malayalam_nea");

        REVERSE.put("പേ", "var_malayalam_pea");
        REVERSE.put("ഫേ", "var_malayalam_phea");
        REVERSE.put("ബേ", "var_malayalam_bea");
        REVERSE.put("ഭേ", "var_malayalam_bhea");
        REVERSE.put("മേ", "var_malayalam_mea");

        REVERSE.put("യേ", "var_malayalam_yea");
        REVERSE.put("രേ", "var_malayalam_rea");
        REVERSE.put("ലേ", "var_malayalam_lea");
        REVERSE.put("വേ", "var_malayalam_vea");

        REVERSE.put("ശേ", "var_malayalam_shea");
        REVERSE.put("ഷേ", "var_malayalam_sshea");
        REVERSE.put("സേ", "var_malayalam_sea");
        REVERSE.put("ഹേ", "var_malayalam_hea");

        REVERSE.put("ളേ", "var_malayalam_Lea");
        REVERSE.put("ഴേ", "var_malayalam_zhea");
        REVERSE.put("റേ", "var_malayalam_Rea");
        ////// Group 09
        REVERSE.put("കൈ", "var_malayalam_kai");
        REVERSE.put("ഖൈ", "var_malayalam_khai");
        REVERSE.put("ഗൈ", "var_malayalam_gai");
        REVERSE.put("ഘൈ", "var_malayalam_ghai");
        REVERSE.put("ങൈ", "var_malayalam_ngai");

        REVERSE.put("ചൈ", "var_malayalam_chai");
        REVERSE.put("ഛൈ", "var_malayalam_chhai");
        REVERSE.put("ജൈ", "var_malayalam_jai");
        REVERSE.put("ഝൈ", "var_malayalam_jhai");
        REVERSE.put("ഞൈ", "var_malayalam_gnai");

        REVERSE.put("ടൈ", "var_malayalam_tai");
        REVERSE.put("ഠൈ", "var_malayalam_ttaai");
        REVERSE.put("ഡൈ", "var_malayalam_dai");
        REVERSE.put("ഢൈ", "var_malayalam_dhai");
        REVERSE.put("ണൈ", "var_malayalam_Nai");

        REVERSE.put("തൈ", "var_malayalam_thai");
        REVERSE.put("ഥൈ", "var_malayalam_thhai");
        REVERSE.put("ദൈ", "var_malayalam_dhai2");
        REVERSE.put("ധൈ", "var_malayalam_dhhai");
        REVERSE.put("നൈ", "var_malayalam_nai");

        REVERSE.put("പൈ", "var_malayalam_pai");
        REVERSE.put("ഫൈ", "var_malayalam_phai");
        REVERSE.put("ബൈ", "var_malayalam_bai");
        REVERSE.put("ഭൈ", "var_malayalam_bhai");
        REVERSE.put("മൈ", "var_malayalam_mai");

        REVERSE.put("യൈ", "var_malayalam_yai");
        REVERSE.put("രൈ", "var_malayalam_rai");
        REVERSE.put("ലൈ", "var_malayalam_lai");
        REVERSE.put("വൈ", "var_malayalam_vai");

        REVERSE.put("ശൈ", "var_malayalam_shai");
        REVERSE.put("ഷൈ", "var_malayalam_sshai");
        REVERSE.put("സൈ", "var_malayalam_sai");
        REVERSE.put("ഹൈ", "var_malayalam_hai");

        REVERSE.put("ളൈ", "var_malayalam_Lai");
        REVERSE.put("ഴൈ", "var_malayalam_zhai");
        REVERSE.put("റൈ", "var_malayalam_Rai");
        ////// Group 10 
        REVERSE.put("കൊ", "var_malayalam_ko");
        REVERSE.put("ഖൊ", "var_malayalam_kho");
        REVERSE.put("ഗൊ", "var_malayalam_go");
        REVERSE.put("ഘൊ", "var_malayalam_gho");
        REVERSE.put("ങൊ", "var_malayalam_ngo");

        REVERSE.put("ചൊ", "var_malayalam_cho");
        REVERSE.put("ഛൊ", "var_malayalam_chho");
        REVERSE.put("ജൊ", "var_malayalam_jo");
        REVERSE.put("ഝൊ", "var_malayalam_jho");
        REVERSE.put("ഞൊ", "var_malayalam_gno");

        REVERSE.put("ടൊ", "var_malayalam_to");
        REVERSE.put("ഠൊ", "var_malayalam_tto");
        REVERSE.put("ഡൊ", "var_malayalam_do");
        REVERSE.put("ഢൊ", "var_malayalam_dho");
        REVERSE.put("ണൊ", "var_malayalam_No");

        REVERSE.put("തൊ", "var_malayalam_tho");
        REVERSE.put("ഥൊ", "var_malayalam_thho");
        REVERSE.put("ദൊ", "var_malayalam_dho2");
        REVERSE.put("ധൊ", "var_malayalam_dhho");
        REVERSE.put("നൊ", "var_malayalam_no");

        REVERSE.put("പൊ", "var_malayalam_po");
        REVERSE.put("ഫൊ", "var_malayalam_pho");
        REVERSE.put("ബൊ", "var_malayalam_bo");
        REVERSE.put("ഭൊ", "var_malayalam_bho");
        REVERSE.put("മൊ", "var_malayalam_mo");

        REVERSE.put("യൊ", "var_malayalam_yo");
        REVERSE.put("രൊ", "var_malayalam_ro");
        REVERSE.put("ലൊ", "var_malayalam_lo");
        REVERSE.put("വൊ", "var_malayalam_vo");

        REVERSE.put("ശൊ", "var_malayalam_sho");
        REVERSE.put("ഷൊ", "var_malayalam_ssho");
        REVERSE.put("സൊ", "var_malayalam_so");
        REVERSE.put("ഹൊ", "var_malayalam_ho");

        REVERSE.put("ളൊ", "var_malayalam_Lo");
        REVERSE.put("ഴൊ", "var_malayalam_zho");
        REVERSE.put("റൊ", "var_malayalam_Ro");
        ////// Group 11 
        REVERSE.put("കോ", "var_malayalam_koa");
        REVERSE.put("ഖോ", "var_malayalam_khoa");
        REVERSE.put("ഗോ", "var_malayalam_goa");
        REVERSE.put("ഘോ", "var_malayalam_ghoa");
        REVERSE.put("ങോ", "var_malayalam_ngoa");

        REVERSE.put("ചോ", "var_malayalam_choa");
        REVERSE.put("ഛോ", "var_malayalam_chhoa");
        REVERSE.put("ജോ", "var_malayalam_joa");
        REVERSE.put("ഝോ", "var_malayalam_jhoa");
        REVERSE.put("ഞോ", "var_malayalam_gnoa");

        REVERSE.put("ടോ", "var_malayalam_toa");
        REVERSE.put("ഠോ", "var_malayalam_ttoa");
        REVERSE.put("ഡോ", "var_malayalam_doa");
        REVERSE.put("ഢോ", "var_malayalam_dhoa");
        REVERSE.put("ണോ", "var_malayalam_Noa");

        REVERSE.put("തോ", "var_malayalam_thoa");
        REVERSE.put("ഥോ", "var_malayalam_thhoa");
        REVERSE.put("ദോ", "var_malayalam_dhoa2");
        REVERSE.put("ധോ", "var_malayalam_dhhoa");
        REVERSE.put("നോ", "var_malayalam_noa");

        REVERSE.put("പോ", "var_malayalam_poa");
        REVERSE.put("ഫോ", "var_malayalam_phoa");
        REVERSE.put("ബോ", "var_malayalam_boa");
        REVERSE.put("ഭോ", "var_malayalam_bhoa");
        REVERSE.put("മോ", "var_malayalam_moa");

        REVERSE.put("യോ", "var_malayalam_yoa");
        REVERSE.put("രോ", "var_malayalam_roa");
        REVERSE.put("ലോ", "var_malayalam_loa");
        REVERSE.put("വോ", "var_malayalam_voa");

        REVERSE.put("ശോ", "var_malayalam_shoa");
        REVERSE.put("ഷോ", "var_malayalam_sshoa");
        REVERSE.put("സോ", "var_malayalam_soa");
        REVERSE.put("ഹോ", "var_malayalam_hoa");

        REVERSE.put("ളോ", "var_malayalam_Loa");
        REVERSE.put("ഴോ", "var_malayalam_zhoa");
        REVERSE.put("റോ", "var_malayalam_Roa");
        ////// Group 12
        REVERSE.put("കൗ", "var_malayalam_kau");
        REVERSE.put("ഖൗ", "var_malayalam_khau");
        REVERSE.put("ഗൗ", "var_malayalam_gau");
        REVERSE.put("ഘൗ", "var_malayalam_ghau");
        REVERSE.put("ങൗ", "var_malayalam_ngau");

        REVERSE.put("ചൗ", "var_malayalam_chau");
        REVERSE.put("ഛൗ", "var_malayalam_chhau");
        REVERSE.put("ജൗ", "var_malayalam_jau");
        REVERSE.put("ഝൗ", "var_malayalam_jhau");
        REVERSE.put("ഞൗ", "var_malayalam_gnau");

        REVERSE.put("ടൗ", "var_malayalam_tau");
        REVERSE.put("ഠൗ", "var_malayalam_ttau");
        REVERSE.put("ഡൗ", "var_malayalam_dau");
        REVERSE.put("ഢൗ", "var_malayalam_dhau");
        REVERSE.put("ണൗ", "var_malayalam_Nau");

        REVERSE.put("തൗ", "var_malayalam_thau");
        REVERSE.put("ഥൗ", "var_malayalam_thhau");
        REVERSE.put("ദൗ", "var_malayalam_dhau2");
        REVERSE.put("ധൗ", "var_malayalam_dhhau");
        REVERSE.put("നൗ", "var_malayalam_nau");

        REVERSE.put("പൗ", "var_malayalam_pau");
        REVERSE.put("ഫൗ", "var_malayalam_phau");
        REVERSE.put("ബൗ", "var_malayalam_bau");
        REVERSE.put("ഭൗ", "var_malayalam_bhau");
        REVERSE.put("മൗ", "var_malayalam_mau");

        REVERSE.put("യൗ", "var_malayalam_yau");
        REVERSE.put("രൗ", "var_malayalam_rau");
        REVERSE.put("ലൗ", "var_malayalam_lau");
        REVERSE.put("വൗ", "var_malayalam_vau");

        REVERSE.put("ശൗ", "var_malayalam_shau");
        REVERSE.put("ഷൗ", "var_malayalam_sshau");
        REVERSE.put("സൗ", "var_malayalam_sau");
        REVERSE.put("ഹൗ", "var_malayalam_hau");

        REVERSE.put("ളൗ", "var_malayalam_Lau");
        REVERSE.put("ഴൗ", "var_malayalam_zhau");
        REVERSE.put("റൗ", "var_malayalam_Rau");

    }
    
}
