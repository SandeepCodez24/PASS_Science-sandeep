package language.semantic;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.UnaryOperator;

/**
 * Splits Neural Code text into code, string-literal and comment segments, so
 * a rewrite meant for code never touches the inside of a string.
 *
 * <h3>Why this exists</h3>
 * The preprocessor used to encode the whole script, so
 * {@code கி = "சோழ நாடு";} reached the interpreter as
 * {@code var_tamil_ki = "var_tamil_choavar_tamil_zha var_tamil_Nhaavar_tamil_du";}.
 * Every rewrite that turns the visual form into the machine form
 * ({@link SemanticEncoder}, {@link ComplexLiteral}) now runs on
 * {@link Kind#CODE} segments only; strings and comments pass through
 * character for character.
 *
 * <h3>Rules (the same as the syntax checker's {@code SourceModel})</h3>
 * <ul>
 * <li>{@code "} and {@code '} both open a literal; only the quote that opened
 * it closes it, and a quote preceded by an odd number of backslashes is
 * escaped.</li>
 * <li>A {@code '} written directly after a value is the transpose operator,
 * not a quote: {@code A'}, {@code (A*B)'}, {@code A[0,:]'}, {@code A''}. See
 * {@link #isTranspose}.</li>
 * <li>A literal ends at the end of its line, unless that line ends with the
 * {@code ~~} continuation, which carries the literal onto the next line.</li>
 * <li>{@code #} and {@code \\} start a comment only outside a literal; the
 * comment runs to the end of the line.</li>
 * </ul>
 * The quote characters belong to the string segment. Concatenating every
 * segment's text always gives back the input exactly.
 */
public final class CodeSegments {

    /** What a segment holds. */
    public enum Kind {
        /** Ordinary code: names, numbers, operators, newlines. */
        CODE,
        /** A string literal, quotes included. */
        STRING,
        /** A {@code #} or {@code \\} comment, up to (not including) the newline. */
        COMMENT
    }

    /**
     * One segment: {@code [start, end)} of the text it was cut from.
     *
     * @param kind  what it holds
     * @param start first offset
     * @param end   offset after the last character
     */
    public record Segment(Kind kind, int start, int end) {
        /**
         * @param source the text the segment was cut from
         * @return the segment's characters
         */
        public String text(String source) {
            return source.substring(start, end);
        }
    }

    private static final String CONTINUATION = "~~";

    /** Words nc.exe does not read as a value, so a {@code '} after one opens a string: {@code if'a' == x:}. */
    private static final Set<String> KEYWORDS_BEFORE_VALUE = Set.of("if", "elseif", "while", "for", "return", "in");

    private CodeSegments() {
    }

    /**
     * Whether the {@code '} at {@code index}, standing outside any literal, is
     * the transpose operator. The same rule as {@code nc.exe}
     * ({@code lexer.cpp}): it directly follows a value, with no space between.
     * Anywhere else a {@code '} opens a string, so {@code x = 'text'},
     * {@code f(A, 'name')} and {@code A 'text'} are not transposes.
     *
     * <pre>
     *   transpose    A'  x_$1'  5'  (A*B)'  A[0,:]'  |A|'  5!'  A''
     *   string       = 'a'  ( 'a'  , 'a'  A 'a'  "a"'b'  'a''b'  if'a'
     * </pre>
     *
     * @param text          the text being scanned
     * @param index         where the {@code '} stands
     * @param lastTranspose where the scan last found a transpose, or -1: the
     *                      second quote of {@code A''} is one, but the one
     *                      after the string {@code 'a'} is not
     * @return true when it is the transpose operator
     */
    public static boolean isTranspose(CharSequence text, int index, int lastTranspose) {
        int p = index - 1;
        while (p >= 0 && text.charAt(p) == '!') {
            p--; // a factorial ends a value too: 5!'
        }
        if (p < 0) {
            return false;
        }
        char c = text.charAt(p);
        if (c == '\'') {
            return p == lastTranspose;
        }
        if (c == ')' || c == ']' || c == '}') {
            return true;
        }
        if (c == '|') {
            return closesBar(text, p);
        }
        if (c == '.') {
            return p > 0 && Character.isDigit(text.charAt(p - 1)); // 3.'
        }
        if (!isNameChar(c)) {
            return false;
        }
        int start = p;
        while (start > 0 && isNameChar(text.charAt(start - 1))) {
            start--;
        }
        return !KEYWORDS_BEFORE_VALUE.contains(text.subSequence(start, p + 1).toString());
    }

    /** True when the {@code |} at {@code bar} closes an absolute value: an even count on its line so far. */
    private static boolean closesBar(CharSequence text, int bar) {
        int count = 0;
        for (int i = bar; i >= 0 && text.charAt(i) != '\n'; i--) {
            if (text.charAt(i) == '|') {
                count++;
            }
        }
        return count % 2 == 0;
    }

    private static boolean isNameChar(char c) {
        if (Character.isLetterOrDigit(c) || c == '_' || Character.isLowSurrogate(c)) {
            return true;
        }
        int type = Character.getType(c);
        return type == Character.NON_SPACING_MARK || type == Character.COMBINING_SPACING_MARK
                || type == Character.OTHER_NUMBER; // A²'
    }

    /**
     * @param text any Neural Code text (a whole file or one line)
     * @return its segments in order; empty for null or empty text
     */
    public static List<Segment> split(String text) {
        List<Segment> out = new ArrayList<>();
        if (text == null || text.isEmpty()) {
            return out;
        }
        int n = text.length();
        int segStart = 0;
        Kind kind = Kind.CODE;
        char quote = 0;
        int transposeAt = -1;
        int i = 0;

        while (i < n) {
            char c = text.charAt(i);

            if (kind == Kind.STRING) {
                if (c == quote && !isEscaped(text, i)) {
                    i++;
                    add(out, Kind.STRING, segStart, i);
                    segStart = i;
                    kind = Kind.CODE;
                    continue;
                }
                if (c == '\n' && !lineContinues(text, i)) {
                    // Unterminated literal: it ends with its line.
                    add(out, Kind.STRING, segStart, i);
                    segStart = i;
                    kind = Kind.CODE;
                    continue; // the newline itself is code
                }
                i++;
                continue;
            }

            if (kind == Kind.COMMENT) {
                if (c == '\n') {
                    add(out, Kind.COMMENT, segStart, i);
                    segStart = i;
                    kind = Kind.CODE;
                    continue;
                }
                i++;
                continue;
            }

            // CODE
            if (c == '\'' && isTranspose(text, i, transposeAt)) {
                transposeAt = i;
                i++;
                continue;
            }
            if ((c == '"' || c == '\'') && !isEscaped(text, i)) {
                add(out, Kind.CODE, segStart, i);
                segStart = i;
                kind = Kind.STRING;
                quote = c;
                i++;
                continue;
            }
            if (c == '#' || (c == '\\' && i + 1 < n && text.charAt(i + 1) == '\\')) {
                add(out, Kind.CODE, segStart, i);
                segStart = i;
                kind = Kind.COMMENT;
                i++;
                continue;
            }
            i++;
        }
        add(out, kind, segStart, n);
        return out;
    }

    /**
     * Applies {@code rewrite} to every code segment and copies strings and
     * comments unchanged.
     *
     * @param text    the text
     * @param rewrite what to do with code
     * @return the rewritten text
     */
    public static String mapCode(String text, UnaryOperator<String> rewrite) {
        if (text == null || text.isEmpty()) {
            return text == null ? "" : text;
        }
        StringBuilder out = new StringBuilder(text.length() + 16);
        for (Segment segment : split(text)) {
            String piece = segment.text(text);
            out.append(segment.kind() == Kind.CODE ? rewrite.apply(piece) : piece);
        }
        return out.toString();
    }

    /**
     * @param text any text
     * @return true when the end of {@code text} lies inside a string literal
     */
    public static boolean endsInsideString(String text) {
        List<Segment> segments = split(text);
        if (segments.isEmpty()) {
            return false;
        }
        Segment last = segments.get(segments.size() - 1);
        if (last.kind() != Kind.STRING) {
            return false;
        }
        String literal = last.text(text);
        if (literal.length() < 2) {
            return true; // just the opening quote
        }
        char open = literal.charAt(0);
        int close = literal.length() - 1;
        return literal.charAt(close) != open || isEscaped(text, last.end() - 1);
    }

    // ─────────────────────────────────────────────────────────────────────

    private static void add(List<Segment> out, Kind kind, int start, int end) {
        if (end > start) {
            out.add(new Segment(kind, start, end));
        }
    }

    private static boolean isEscaped(String text, int index) {
        int count = 0;
        for (int i = index - 1; i >= 0 && text.charAt(i) == '\\'; i--) {
            count++;
        }
        return count % 2 != 0;
    }

    /** True when the line ending at {@code newline} ends with {@code ~~}. */
    private static boolean lineContinues(String text, int newline) {
        int end = newline;
        while (end > 0 && (text.charAt(end - 1) == ' ' || text.charAt(end - 1) == '\t'
                || text.charAt(end - 1) == '\r')) {
            end--;
        }
        return end >= CONTINUATION.length() && text.startsWith(CONTINUATION, end - CONTINUATION.length());
    }
}
