package language.semantic;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * A name as {@code nc.exe} reports it  ->  the parts the Variable Explorer
 * draws.
 *
 * <h3>Nothing to decode any more</h3>
 * <p>
 * Names reach the interpreter exactly as they are written ({@code A_$1},
 * {@code μ_$i_@2}, {@code க_$1}) and come back the same way, so this class
 * no longer reverses an encoding. It only splits a name into its parts with
 * {@link ScriptedName#parse}, the same rules the editor and {@code nc.exe}
 * use:
 * </p>
 * <pre>
 *   "A_$1"      ->  [ "A" NORMAL, "1" SUBSCRIPT ]
 *   "μ_$i_@2"   ->  [ "μ" NORMAL, "i" SUBSCRIPT, "2" SUPERSCRIPT ]
 *   "A__j"      ->  [ "A__j" NORMAL ]                  (no marker)
 *   "A_sj"      ->  [ "A_sj" NORMAL ]                  (no marker)
 * </pre>
 * <p>
 * Because {@code _$} / {@code _@} can only come from writing a subscript or
 * superscript, a drawn subscript always means the user wrote one: no plain
 * name can come back looking like {@code A₁}. The old {@code var_mu} /
 * {@code __s} / {@code __t} decoding is gone for the same reason -- it is
 * what let a user-typed {@code var_mu} show as μ.
 * </p>
 * <p>
 * One thing is still translated: a physical constant typed as a symbol
 * ({@code \con(\pi)}) reaches the interpreter under its {@code con_} name,
 * and is drawn as its symbol again. {@code con_} is reserved
 * ({@link ScriptedName}), so a variable can never borrow that look.
 * </p>
 * <p>
 * A name that is somehow not valid (it should never reach here; the lexer
 * refuses it) is drawn as written, all on the baseline, never half-styled.
 * </p>
 */
public final class VariableNameDecoder {

    /** Script level of one run of characters within a name. */
    public enum Level {
        /** Baseline text. */
        NORMAL,
        /** Rendered below the baseline. */
        SUBSCRIPT,
        /** Rendered above the baseline. */
        SUPERSCRIPT
    }

    /** One run of characters sharing a script level. */
    public static final class Segment {
        private final String text;
        private final Level level;

        Segment(String text, Level level) {
            this.text = text;
            this.level = level;
        }

        public String getText() {
            return text;
        }

        public Level getLevel() {
            return level;
        }
    }

    /** Prefix of a physical constant's interpreter name. */
    private static final String CONSTANT_PREFIX = "con_";

    private static final Map<String, List<Segment>> CACHE = new ConcurrentHashMap<>();
    private static final int CACHE_LIMIT = 4096;

    /** Interpreter name of a constant -> its symbol; built on first use. */
    private static volatile Map<String, String> constants;

    private VariableNameDecoder() {
    }

    /**
     * Splits a name into renderable segments.
     *
     * @param name the name exactly as {@code nc.exe} reported it
     * @return one or more segments; never null, never empty for a non-empty name
     */
    public static List<Segment> decode(String name) {
        if (name == null || name.isEmpty()) {
            return List.of();
        }
        List<Segment> cached = CACHE.get(name);
        if (cached != null) {
            return cached;
        }
        List<Segment> decoded = decodeUncached(name);
        if (CACHE.size() < CACHE_LIMIT) {
            CACHE.put(name, decoded);
        }
        return decoded;
    }

    /**
     * The name as plain text, for places that cannot style it: tab titles,
     * tooltips, dialogs, print. See {@link ScriptedName#toPlainText}.
     *
     * @param name the name
     * @return the plain-text form
     */
    public static String decodeToPlainText(String name) {
        if (name == null || name.isEmpty()) {
            return name == null ? "" : name;
        }
        String constant = constantSymbol(name);
        return constant != null ? constant : ScriptedName.toPlainText(name);
    }

    /**
     * @param token a word from interpreter output
     * @return the constant's symbol when the word is a constant's
     *         interpreter name ({@code con_pi}), otherwise null
     */
    public static String constantSymbol(String token) {
        if (token == null || !token.startsWith(CONSTANT_PREFIX)) {
            return null;
        }
        return constants().get(token);
    }

    // -----------------------------------------------------------------
    // Internals
    // -----------------------------------------------------------------

    private static List<Segment> decodeUncached(String name) {
        String constant = constantSymbol(name);
        if (constant != null) {
            return List.of(new Segment(constant, Level.NORMAL));
        }
        if (!ScriptedName.hasScripts(name)) {
            return List.of(new Segment(name, Level.NORMAL));
        }
        ScriptedName.Parsed parsed = ScriptedName.parse(name);
        if (!parsed.isValid()) {
            return List.of(new Segment(name, Level.NORMAL));
        }
        List<Segment> segments = new ArrayList<>(parsed.parts().size());
        for (ScriptedName.Part part : parsed.parts()) {
            Level level = switch (part.kind()) {
                case SUBSCRIPT -> Level.SUBSCRIPT;
                case SUPERSCRIPT -> Level.SUPERSCRIPT;
                default -> Level.NORMAL;
            };
            segments.add(new Segment(part.text(), level));
        }
        return List.copyOf(segments);
    }

    private static Map<String, String> constants() {
        Map<String, String> map = constants;
        if (map == null) {
            Map<String, String> built = new LinkedHashMap<>();
            // UniconstantReverse maps symbol -> interpreter name; invert it.
            // First writer wins if two symbols share a name.
            for (Map.Entry<String, String> e : UniconstantReverse.REVERSE.entrySet()) {
                built.putIfAbsent(e.getValue(), e.getKey());
            }
            map = Map.copyOf(built);
            constants = map;
        }
        return map;
    }
}
