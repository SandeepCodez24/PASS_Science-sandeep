package language.semantic;

import java.util.ArrayList;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Cleaned (machine-readable) form  ->  visual form, as structured segments.
 *
 * <p>This is the "reverse writing function" the Variable Explorer needs. It is
 * the exact inverse of {@link SemanticEncoder}: {@code nc.exe} reports
 * {@code var_mu__sj} in {@code variables.txt}, and this class turns that into
 * <code>[ "&#956;" NORMAL, "j" SUBSCRIPT ]</code> so the table can draw
 * &#956;<sub>j</sub>.
 *
 * <p>Segments are returned rather than a marker-laden string so the renderer
 * never has to re-parse anything, and so a name can never be half-decoded.
 *
 * <h3>Decoding rules</h3>
 * <ol>
 *   <li>{@code __s} / {@code __t} switch the script level; per the language
 *       design a script run continues to the end of the identifier.</li>
 *   <li>At every position the longest matching dictionary token wins, so
 *       {@code var_sigma} decodes as &#963; and never as
 *       {@code var} + subscript {@code igma}.</li>
 *   <li>A single underscore is <b>never</b> a marker. {@code \var(\mu)_j} is
 *       meant to read as {@code &#956;_j}, with the underscore intact, so
 *       {@code var_mu_j} renders literally. Decoding legacy {@code _s} /
 *       {@code _t} here would corrupt exactly that: a variable the user wrote
 *       as {@code &#956;_s} would silently come back as &#956; with a
 *       subscript s.</li>
 * </ol>
 *
 * <p>Results are cached: the table redraws a cell on every refresh and the
 * dictionaries are large.
 */
public final class VariableNameDecoder {

    /** Script level of one run of characters within a name. */
    public enum Level {
        /** Baseline text. */
        NORMAL,
        /** Rendered below the baseline. */
        SUBSCRIPT,
        /** Rendered above the baseline. */
        SUPERSCRIPT
    }

    /** One run of characters sharing a script level. */
    public static final class Segment {
        private final String text;
        private final Level level;

        Segment(String text, Level level) {
            this.text = text;
            this.level = level;
        }

        public String getText() {
            return text;
        }

        public Level getLevel() {
            return level;
        }
    }

    /** cleaned token -> visual glyph. */
    private static final Map<String, String> VISUALS = buildVisualMap();

    /** Longest cleaned token, so the greedy match knows where to start. */
    private static final int LONGEST_TOKEN = longestKey(VISUALS);

    private static final Map<String, List<Segment>> CACHE = new ConcurrentHashMap<>();
    private static final int CACHE_LIMIT = 4096;

    private VariableNameDecoder() {
    }

    /**
     * Decodes a cleaned identifier into renderable segments.
     *
     * @param cleanedName the name exactly as {@code nc.exe} reported it
     * @return one or more segments; never null, never empty for a non-blank name
     */
    public static List<Segment> decode(String cleanedName) {
        if (cleanedName == null || cleanedName.isEmpty()) {
            return List.of();
        }
        List<Segment> cached = CACHE.get(cleanedName);
        if (cached != null) {
            return cached;
        }
        List<Segment> decoded = decodeUncached(cleanedName);
        if (CACHE.size() < CACHE_LIMIT) {
            CACHE.put(cleanedName, decoded);
        }
        return decoded;
    }

    /**
     * Flattens the decoded name into a plain string (script runs inlined). Used
     * for tooltips, sorting and copy-to-clipboard, not for the table cell.
     *
     * @param cleanedName the cleaned identifier
     * @return the visual name as plain text
     */
    public static String decodeToPlainText(String cleanedName) {
        StringBuilder out = new StringBuilder();
        for (Segment segment : decode(cleanedName)) {
            out.append(segment.getText());
        }
        return out.toString();
    }

    // -----------------------------------------------------------------
    // Internals
    // -----------------------------------------------------------------

    private static List<Segment> decodeUncached(String name) {
        List<Segment> segments = new ArrayList<>(3);
        StringBuilder buffer = new StringBuilder();
        Level level = Level.NORMAL;

        int i = 0;
        while (i < name.length()) {

            // --- reserved markers -----------------------------------------
            if (name.startsWith(ScriptMarkers.SUBSCRIPT, i)) {
                level = flush(segments, buffer, level, Level.SUBSCRIPT);
                i += ScriptMarkers.SUBSCRIPT.length();
                continue;
            }
            if (name.startsWith(ScriptMarkers.SUPERSCRIPT, i)) {
                level = flush(segments, buffer, level, Level.SUPERSCRIPT);
                i += ScriptMarkers.SUPERSCRIPT.length();
                continue;
            }

            // --- longest dictionary token --------------------------------
            String match = longestTokenAt(name, i);
            if (match != null) {
                buffer.append(visualFor(match));
                i += match.length();
                continue;
            }

            // A single underscore is an ordinary identifier character and is
            // rendered as itself. See the class note on why the legacy markers
            // are no longer decoded.
            buffer.append(name.charAt(i));
            i++;
        }

        flush(segments, buffer, level, level);
        return segments.isEmpty()
                ? List.of(new Segment(name, Level.NORMAL))
                : List.copyOf(segments);
    }

    /** Closes the current run and returns the level the next run starts in. */
    private static Level flush(List<Segment> segments, StringBuilder buffer,
            Level current, Level next) {
        if (buffer.length() > 0) {
            segments.add(new Segment(buffer.toString(), current));
            buffer.setLength(0);
        }
        return next;
    }

    private static String longestTokenAt(String name, int index) {
        int maxLength = Math.min(LONGEST_TOKEN, name.length() - index);
        for (int length = maxLength; length > 0; length--) {
            String candidate = name.substring(index, index + length);
            if (VISUALS.containsKey(candidate)) {
                return candidate;
            }
        }
        return null;
    }

    private static String visualFor(String cleanedToken) {
        String visual = VISUALS.get(cleanedToken);
        return visual == null ? cleanedToken : visual;
    }

    private static int longestKey(Map<String, String> map) {
        int longest = 0;
        for (String key : map.keySet()) {
            longest = Math.max(longest, key.length());
        }
        return longest;
    }

    private static Map<String, String> buildVisualMap() {
        Map<String, String> map = new LinkedHashMap<>();
        // Invert every dictionary. First writer wins: some dictionaries map two
        // different visual glyphs onto the same cleaned token (for example
        // TamilReverse maps both "ங" and "ஙெ" to var_tamil_nga), and the first
        // one listed is the base letter, which is the better rendering.
        putInverted(map, GreekReverse.REVERSE);
        putInverted(map, UniconstantReverse.REVERSE);
        putInverted(map, TamilReverse.REVERSE);
        putInverted(map, SanskritReverse.REVERSE);
        putInverted(map, MalayalamReverse.REVERSE);
        putInverted(map, TeluguReverse.REVERSE);
        return Map.copyOf(map);
    }

    private static void putInverted(Map<String, String> target, Map<String, String> source) {
        for (Map.Entry<String, String> entry : source.entrySet()) {
            target.putIfAbsent(entry.getValue(), entry.getKey());
        }
    }

}
