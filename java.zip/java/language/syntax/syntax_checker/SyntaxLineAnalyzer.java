package language.syntax.syntax_checker;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;

/**
 * Line-level bracket and completeness checks.
 *
 * <h3>Interval brackets</h3>
 * NC treats {@code [a:b]}, {@code (a:b)}, {@code (a:b]} and {@code [a:b)} as
 * four distinct, legal range forms -- closed, open, half-open-left,
 * half-open-right. A round opener may therefore be closed by a square closer
 * and vice versa, but ONLY when the span between them contains a range colon at
 * its own depth. That keeps {@code f(x]} an error while letting {@code (1:2]}
 * through, so genuine typos are still caught. Curly braces never mix: they
 * belong to the subscript/superscript groups and stay strictly paired.
 *
 * <h3>What changed</h3>
 * Every scan now runs on {@link SourceModel}'s masked text. Three bugs fall out
 * of that at once:
 * <ul>
 * <li>{@link #findErrorLines(String)} used to walk the <b>raw</b> document with
 * no comment handling at all, so an unmatched bracket in a comment --
 * {@code \\ # a '(' opening bracket used to...} -- went on the bracket stack
 * and was reported against real code.</li>
 * <li>Quote tracking covered {@code "} only, so an apostrophe in
 * {@code matrix.cpp's} opened a literal that never closed.</li>
 * <li>A line split with {@code ~~} was scanned as two halves, and both halves
 * failed: the first left a bracket or quote open, the second closed one that
 * was never opened. That is two red dots per continuation.</li>
 * </ul>
 * Because masking has already removed every literal, the bracket scanners no
 * longer track quotes themselves -- there is nothing left for them to find.
 */
final class SyntaxLineAnalyzer {

    private SyntaxLineAnalyzer() {
    }

    /** One open bracket on the scan stack. */
    private static final class Bracket {
        final char open;
        final int line;
        /** A ':' seen directly inside this bracket, marking it as a range. */
        boolean sawRangeColon;

        Bracket(char open, int line) {
            this.open = open;
            this.line = line;
        }
    }

    /**
     * @param code raw editor text
     * @return zero-based indices of lines that do not stand on their own
     */
    static Set<Integer> findIncompleteLineSyntaxErrorLines(String code) {
        return findIncompleteLineSyntaxErrorLines(SourceModel.of(code));
    }

    /**
     * @param model the cleaned document
     * @return zero-based indices of lines that do not stand on their own
     */
    static Set<Integer> findIncompleteLineSyntaxErrorLines(SourceModel model) {
        Set<Integer> errorLines = new HashSet<>();

        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed()) {
                continue;
            }

            // A literal left open is an error in its own right, and reporting
            // it here keeps it in the blocking error count rather than only in
            // the warning count.
            if (line.hasUnterminatedString()) {
                errorLines.add(line.index());
                continue;
            }

            String logical = line.masked().trim();
            if (logical.isEmpty()) {
                continue;
            }
            if (looksIncomplete(logical)) {
                errorLines.add(line.index());
            }
        }

        return errorLines;
    }

    /**
     * Cross-line bracket scan: an opener on one line may legitimately close on
     * another, so this walks the whole document and blames the line the opener
     * sat on.
     *
     * @param code raw editor text
     * @return zero-based indices of lines with a bracket fault
     */
    static Set<Integer> findErrorLines(String code) {
        return findErrorLines(SourceModel.of(code));
    }

    /**
     * @param model the cleaned document
     * @return zero-based indices of lines with a bracket fault
     */
    static Set<Integer> findErrorLines(SourceModel model) {
        Set<Integer> errorLines = new HashSet<>();
        ArrayDeque<Bracket> stack = new ArrayDeque<>();

        // Masked, so comments and string bodies are already gone while line
        // numbers still line up with the editor.
        String document = model.maskedDocument();
        int line = 0;

        for (int i = 0; i < document.length(); i++) {
            char ch = document.charAt(i);
            if (ch == '\n') {
                line++;
                continue;
            }

            if (ch == ':') {
                if (!stack.isEmpty()) {
                    stack.peek().sawRangeColon = true;
                }
                continue;
            }
            if (isOpenBracket(ch)) {
                stack.push(new Bracket(ch, line));
                continue;
            }
            if (isCloseBracket(ch)) {
                if (stack.isEmpty()) {
                    errorLines.add(line);
                    continue;
                }
                Bracket opened = stack.pop();
                if (!closes(opened, ch)) {
                    errorLines.add(line);
                }
            }
        }

        for (Bracket unclosed : stack) {
            errorLines.add(unclosed.line);
        }

        // Reported here too, so this entry point is usable on its own.
        errorLines.addAll(DocstringErrorAnalyzer.findUnterminatedStringLines(model));
        return errorLines;
    }

    /**
     * @param code raw editor text
     * @return zero-based indices of {@code ;}-terminated lines that are unbalanced
     */
    static Set<Integer> findErrorLinesAfterSemicolon(String code) {
        return findErrorLinesAfterSemicolon(SourceModel.of(code));
    }

    /**
     * @param model the cleaned document
     * @return zero-based indices of {@code ;}-terminated lines that are unbalanced
     */
    static Set<Integer> findErrorLinesAfterSemicolon(SourceModel model) {
        Set<Integer> errorLines = new HashSet<>();

        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed()) {
                continue;
            }
            String logical = line.masked().trim();
            if (logical.endsWith(";") && !bracketsBalanced(logical)) {
                errorLines.add(line.index());
            }
        }

        return errorLines;
    }

    private static boolean looksIncomplete(String line) {
        String normalized = line;
        if (normalized.endsWith(";")) {
            normalized = normalized.substring(0, normalized.length() - 1).trim();
        }
        if (normalized.isEmpty()) {
            return true;
        }
        if (normalized.endsWith("+") || normalized.endsWith("-") || normalized.endsWith("*")
                || normalized.endsWith("/") || normalized.endsWith("=") || normalized.endsWith(",")
                || normalized.endsWith("(") || normalized.endsWith("[") || normalized.endsWith("{")) {
            return true;
        }
        return !bracketsBalanced(normalized);
    }

    /**
     * Scans one masked logical line and reports whether its brackets close
     * cleanly, allowing the four interval forms described in the class comment.
     */
    private static boolean bracketsBalanced(String line) {
        ArrayDeque<Bracket> stack = new ArrayDeque<>();

        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);

            if (ch == ':') {
                if (!stack.isEmpty()) {
                    stack.peek().sawRangeColon = true;
                }
                continue;
            }
            if (isOpenBracket(ch)) {
                stack.push(new Bracket(ch, 0));
                continue;
            }
            if (isCloseBracket(ch)) {
                if (stack.isEmpty()) {
                    return false;
                }
                Bracket opened = stack.pop();
                if (!closes(opened, ch)) {
                    return false;
                }
            }
        }

        return stack.isEmpty();
    }

    /** True when {@code close} legally terminates {@code opened}. */
    private static boolean closes(Bracket opened, char close) {
        if (opened.open == matchingOpen(close)) {
            return true;
        }
        // Mixed round/square is an interval form, valid only over a range span.
        boolean roundOrSquare = (opened.open == '(' || opened.open == '[')
                && (close == ')' || close == ']');
        return roundOrSquare && opened.sawRangeColon;
    }

    private static boolean isOpenBracket(char ch) {
        return ch == '(' || ch == '[' || ch == '{';
    }

    private static boolean isCloseBracket(char ch) {
        return ch == ')' || ch == ']' || ch == '}';
    }

    private static char matchingOpen(char close) {
        return switch (close) {
            case ')' -> '(';
            case ']' -> '[';
            case '}' -> '{';
            default -> '\0';
        };
    }
}
