package language.syntax.syntax_checker;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;

final class SyntaxLineAnalyzer {

    private SyntaxLineAnalyzer() {
    }

    static Set<Integer> findIncompleteLineSyntaxErrorLines(String code) {
        Set<Integer> errorLines = new HashSet<>();
        if (code == null || code.isEmpty()) {
            return errorLines;
        }
        String[] lines = code.split("\\R", -1);
        Set<Integer> docstringLines = DocstringErrorAnalyzer.findDocstringBlockLines(code);
        for (int i = 0; i < lines.length; i++) {
            String line = SyntaxTextUtils.stripTrailingComment(lines[i]).trim();
            if (line.isEmpty() || docstringLines.contains(i)) {
                continue;
            }
            if (looksIncomplete(line)) {
                errorLines.add(i);
            }
        }
        return errorLines;
    }

    static Set<Integer> findErrorLines(String code) {
        Set<Integer> errorLines = new HashSet<>();
        if (code == null || code.isEmpty()) {
            return errorLines;
        }
        ArrayDeque<Integer> parenStack = new ArrayDeque<>();
        ArrayDeque<Integer> braceStack = new ArrayDeque<>();
        ArrayDeque<Integer> bracketStack = new ArrayDeque<>();
        int line = 0;
        int openQuoteLine = -1;
        for (int i = 0; i < code.length(); i++) {
            char ch = code.charAt(i);
            if (ch == '\n') {
                line++;
                continue;
            }
            if (ch == '"' && !SyntaxTextUtils.isEscaped(code, i)) {
                openQuoteLine = openQuoteLine == -1 ? line : -1;
                continue;
            }
            if (ch == '(') {
                parenStack.push(line);
            } else if (ch == ')') {
                if (parenStack.isEmpty()) {
                    errorLines.add(line);
                } else {
                    parenStack.pop();
                }
            } else if (ch == '{') {
                braceStack.push(line);
            } else if (ch == '}') {
                if (braceStack.isEmpty()) {
                    errorLines.add(line);
                } else {
                    braceStack.pop();
                }
            } else if (ch == '[') {
                bracketStack.push(line);
            } else if (ch == ']') {
                if (bracketStack.isEmpty()) {
                    errorLines.add(line);
                } else {
                    bracketStack.pop();
                }
            }
        }
        if (openQuoteLine != -1) {
            errorLines.add(openQuoteLine);
        }
        errorLines.addAll(parenStack);
        errorLines.addAll(braceStack);
        errorLines.addAll(bracketStack);
        return errorLines;
    }

    static Set<Integer> findErrorLinesAfterSemicolon(String code) {
        Set<Integer> errorLines = new HashSet<>();
        if (code == null || code.isEmpty()) {
            return errorLines;
        }
        String[] lines = code.split("\\R", -1);
        for (int i = 0; i < lines.length; i++) {
            String logicalLine = SyntaxTextUtils.stripTrailingComment(lines[i]).trim();
            if (logicalLine.endsWith(";") && hasLineError(logicalLine)) {
                errorLines.add(i);
            }
        }
        return errorLines;
    }

    private static boolean looksIncomplete(String line) {
        String normalized = line;
        if (normalized.endsWith(";")) {
            normalized = normalized.substring(0, normalized.length() - 1).trim();
        }
        if (normalized.isEmpty()) {
            return true;
        }
        if (normalized.endsWith("+") || normalized.endsWith("-") || normalized.endsWith("*") || normalized.endsWith("/")
                || normalized.endsWith("=") || normalized.endsWith(",") || normalized.endsWith("(") || normalized.endsWith("[")
                || normalized.endsWith("{")) {
            return true;
        }
        int openParen = 0;
        int openBrace = 0;
        int openBracket = 0;
        boolean inSingleQuote = false;
        boolean inDoubleQuote = false;
        for (int i = 0; i < normalized.length(); i++) {
            char ch = normalized.charAt(i);
            if (ch == '"' && !SyntaxTextUtils.isEscaped(normalized, i) && !inSingleQuote) {
                inDoubleQuote = !inDoubleQuote;
                continue;
            }
            if (ch == '\'' && !SyntaxTextUtils.isEscaped(normalized, i) && !inDoubleQuote) {
                inSingleQuote = !inSingleQuote;
                continue;
            }
            if (inSingleQuote || inDoubleQuote) {
                continue;
            }
            if (ch == '(') {
                openParen++;
            } else if (ch == ')') {
                openParen--;
            } else if (ch == '{') {
                openBrace++;
            } else if (ch == '}') {
                openBrace--;
            } else if (ch == '[') {
                openBracket++;
            } else if (ch == ']') {
                openBracket--;
            }
            if (openParen < 0 || openBrace < 0 || openBracket < 0) {
                return true;
            }
        }
        return inSingleQuote || inDoubleQuote || openParen != 0 || openBrace != 0 || openBracket != 0;
    }

    private static boolean hasLineError(String line) {
        int paren = 0;
        int brace = 0;
        int bracket = 0;
        boolean inQuote = false;
        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (ch == '"' && !SyntaxTextUtils.isEscaped(line, i)) {
                inQuote = !inQuote;
                continue;
            }
            if (inQuote) {
                continue;
            }
            if (ch == '(') {
                paren++;
            } else if (ch == ')') {
                paren--;
                if (paren < 0) {
                    return true;
                }
            } else if (ch == '{') {
                brace++;
            } else if (ch == '}') {
                brace--;
                if (brace < 0) {
                    return true;
                }
            } else if (ch == '[') {
                bracket++;
            } else if (ch == ']') {
                bracket--;
                if (bracket < 0) {
                    return true;
                }
            }
        }
        return inQuote || paren != 0 || brace != 0 || bracket != 0;
    }
}
