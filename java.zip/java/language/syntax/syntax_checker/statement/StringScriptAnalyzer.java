package language.syntax.syntax_checker.statement;

import language.semantic.CodeSegments;
import language.syntax.syntax_checker.core.Analyzer;
import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.core.Findings;
import language.syntax.syntax_checker.core.Lexis;
import language.syntax.syntax_checker.core.Rule;
import language.syntax.syntax_checker.core.SourceModel;

/**
 * Reports a Unicode subscript or superscript character written inside a
 * string literal.
 *
 * <pre>
 *   M = "E = mc&#178;";        Unicode superscript in a string  (error)
 *   M = "A_$1 costs $5";       plain text                       (fine)
 *   கி = "சோழ நாடு";       Tamil text in a string           (fine)
 *   M = "ന്&zwj;";             Malayalam ZWJ in a string        (fine)
 * </pre>
 *
 * <p>
 * A subscript or superscript belongs to a <b>name</b> and is written
 * {@code A_$1} / {@code A_@2}; inside quotes those characters are ordinary
 * text, never styled and never reported. The old hidden-marker groups
 * (U+200D / U+200C) are no longer looked for: Malayalam and Sanskrit text use
 * those characters inside ordinary words.
 * </p>
 * <p>
 * Unicode subscript / superscript characters ({@code &#8322;},
 * {@code &#178;}, {@code &#7491;} ...) are reported while
 * {@link #FLAG_UNICODE_SCRIPT_GLYPHS} is true. The check reads
 * {@link SourceModel.Line#code()}, where literals are intact.
 * </p>
 */
public final class StringScriptAnalyzer implements Analyzer {

    static final String MESSAGE =
            "A subscript or superscript cannot be written inside a string (%s); "
                    + "strings hold plain text only";

    /**
     * When true, Unicode subscript / superscript characters typed or pasted
     * into a string ({@code "m²"}) are reported too. Set to false to allow
     * them as ordinary text and report only the editor's styled groups.
     */
    public static final boolean FLAG_UNICODE_SCRIPT_GLYPHS = true;

    /** Longest literal quoted in the message before it is shortened. */
    private static final int MAX_QUOTED = 24;

    @Override
    public void analyze(SourceModel model, CheckContext context, Findings out) {
        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed() || line.isBlank()) {
                continue;
            }
            String literal = firstOffendingLiteral(line.code());
            if (literal != null) {
                out.add(line.index(), Rule.STRING_SCRIPT, String.format(MESSAGE, quote(literal)));
            }
        }
    }

    /**
     * @param code one logical line, comment removed, literals intact
     * @return the first string literal holding a sub/superscript, or null
     */
    static String firstOffendingLiteral(String code) {
        if (code == null || code.isEmpty()) {
            return null;
        }
        int n = code.length();
        int transposeAt = -1;
        int i = 0;
        while (i < n) {
            char c = code.charAt(i);
            if (c == '\'' && CodeSegments.isTranspose(code, i, transposeAt)) {
                transposeAt = i;
                i++;
                continue;
            }
            if ((c == '"' || c == '\'') && !Lexis.isEscaped(code, i)) {
                int end = i + 1;
                while (end < n && !(code.charAt(end) == c && !Lexis.isEscaped(code, end))) {
                    end++;
                }
                int bodyEnd = Math.min(end, n);
                if (holdsScript(code, i + 1, bodyEnd)) {
                    return code.substring(i, Math.min(bodyEnd + 1, n));
                }
                i = bodyEnd + 1;
                continue;
            }
            i++;
        }
        return null;
    }

    /** True when {@code text[from, to)} holds a Unicode script glyph. */
    static boolean holdsScript(String text, int from, int to) {
        if (!FLAG_UNICODE_SCRIPT_GLYPHS) {
            return false;
        }
        for (int k = from; k < to; k++) {
            if (isScriptGlyph(text.charAt(k))) {
                return true;
            }
        }
        return false;
    }

    /** Unicode subscript / superscript digits and letters. */
    static boolean isScriptGlyph(char c) {
        return Lexis.isScriptPostfix(c)
                || (c >= 'ᴬ' && c <= 'ᵪ')   // modifier letters a, b, d, e ...
                || (c >= 'ᶛ' && c <= 'ᶿ')   // modifier letters c, f, z ...
                || c == 'ʰ' || c == 'ʲ' || c == 'ʳ' || c == 'ʷ' || c == 'ʸ'
                || c == 'ˡ' || c == 'ˢ' || c == 'ˣ'
                || c == 'ⱼ';                      // subscript j
    }

    private static String quote(String literal) {
        String visible = Lexis.visible(literal);
        if (visible.length() > MAX_QUOTED) {
            visible = visible.substring(0, MAX_QUOTED - 1) + "…";
        }
        return visible;
    }
}
