package language.syntax.syntax_checker.statement;

import java.util.regex.Pattern;

import language.semantic.CodeSegments;
import language.syntax.syntax_checker.core.Analyzer;
import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.core.Findings;
import language.syntax.syntax_checker.core.Lexis;
import language.syntax.syntax_checker.core.Rule;
import language.syntax.syntax_checker.core.SourceModel;

/**
 * Warns (amber, never blocks a run) about a Windows path that {@code nc.exe}
 * silently changes. NC strings read {@code \t}, {@code \n} and {@code \r} as a
 * tab, a new line and a carriage return ({@code lexer.cpp}); every other
 * backslash is kept, so {@code "D:\data\x.csv"} is fine, but
 * {@code "D:\temp\new.csv"} names another file.
 *
 * <pre>
 *   T = read_csv("D:\temp\new.csv");   '\t' in "D:\temp\new.csv" becomes a tab - write the path with / : "D:/temp/new.csv"
 *   T = read_csv("D:/temp/new.csv");   fine
 *   T = read_csv("a.tsv", dlm="\t");   fine: not a path
 * </pre>
 *
 * A string counts as a path when it holds a backslash and starts with a drive
 * ({@code D:\}), {@code .\} / {@code ..\} or {@code \\}, or ends in a file
 * extension ({@code data\new.csv}). The check reads {@link SourceModel.Line#code()}, where
 * literals are intact.
 */
public final class PathEscapeAnalyzer implements Analyzer {

    static final String MESSAGE = "'\\%s' in \"%s\" becomes %s - write the path with / : \"%s\"";

    private static final Pattern PATH_START = Pattern.compile("^(?:[A-Za-z]:\\\\|\\.{1,2}\\\\|\\\\\\\\)");
    private static final Pattern EXTENSION = Pattern.compile("\\.[A-Za-z0-9]{1,8}$");

    @Override
    public void analyze(SourceModel model, CheckContext context, Findings out) {
        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed() || line.isBlank()) {
                continue;
            }
            String message = firstChangedPath(line.code());
            if (message != null) {
                out.add(line.index(), Rule.PATH_ESCAPE, message);
            }
        }
    }

    /** @return the warning for the first path literal nc.exe would change, or null */
    static String firstChangedPath(String code) {
        int n = code.length();
        int transposeAt = -1;
        int i = 0;
        while (i < n) {
            char c = code.charAt(i);
            if (c == '\'' && CodeSegments.isTranspose(code, i, transposeAt)) {
                transposeAt = i;
                i++;
            } else if ((c == '"' || c == '\'') && !Lexis.isEscaped(code, i)) {
                int end = i + 1;
                while (end < n && !(code.charAt(end) == c && !Lexis.isEscaped(code, end))) {
                    end++;
                }
                String message = judge(code.substring(i + 1, Math.min(end, n)));
                if (message != null) {
                    return message;
                }
                i = end + 1;
            } else {
                i++;
            }
        }
        return null;
    }

    private static String judge(String body) {
        if (body.indexOf('\\') < 0
                || !(PATH_START.matcher(body).find() || EXTENSION.matcher(body).find())) {
            return null;
        }
        for (int k = 0; k + 1 < body.length(); k++) {
            if (body.charAt(k) != '\\') {
                continue;
            }
            char e = body.charAt(k + 1);
            if (e == '\\') {
                k++; // "\\" is one backslash
                continue;
            }
            if (e == 't' || e == 'n' || e == 'r') {
                String becomes = e == 't' ? "a tab" : e == 'n' ? "a new line" : "a carriage return";
                String fixed = body.replace("\\\\", "/").replace('\\', '/');
                return String.format(MESSAGE, e, body, becomes, fixed);
            }
        }
        return null;
    }
}
