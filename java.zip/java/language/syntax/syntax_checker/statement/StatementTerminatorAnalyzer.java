package language.syntax.syntax_checker.statement;

import java.util.ArrayDeque;
import java.util.Deque;

import language.syntax.syntax_checker.core.Analyzer;
import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.core.Findings;
import language.syntax.syntax_checker.core.Lexis;
import language.syntax.syntax_checker.core.Rule;
import language.syntax.syntax_checker.core.SourceModel;

/**
 * What may follow a {@code ;}.
 *
 * <p>
 * {@code ;} ends a statement. Several statements may share a line
 * ({@code A = 1; B = 2;}), but a {@code ;} may never be followed directly by
 * another {@code ;} or by {@code :}, with or without spaces between:
 *
 * <pre>
 *   valid                         error
 *   A = 1;                        A = 1;;          ';;' outside [ ]
 *   A = 1; B = 2;                 A = 1; ;         an empty statement
 *   [1, 2; 3, 4]                  if x;:           ';' before a header's ':'
 *   [1,2;3,4 ;; 5,6;7,8]
 * </pre>
 *
 * A statement that ends without {@code ;} is <b>not</b> an error: its value is
 * echoed in the Command Window, which is sometimes exactly what is wanted.
 *
 * <h3>N-dimensional matrices (changed)</h3>
 * Inside {@code [ ]} a run of <b>adjacent</b> semicolons separates the higher
 * axes of a matrix: {@code ;} rows, {@code ;;} the third axis from the end,
 * {@code ;;;} the fourth, and so on. Every {@code ;} whose innermost open
 * bracket is a {@code [} therefore belongs to the matrix and is left to
 * {@code MatrixAnalyzer}, which also reports {@code [1, 2; ; 3, 4]} (a space
 * between the two {@code ;}) as an empty row. Outside {@code [ ]} a run of
 * two or more is reported with the interpreter's own wording. Bracket depth
 * is measured on the joined line, so a literal split with {@code ~~} is one
 * matrix.
 *
 * <p>
 * Runs on the masked text, so a {@code ;;} inside a string literal is text.
 */
public final class StatementTerminatorAnalyzer implements Analyzer {

    static final String DOUBLE = "'; ;' is an empty statement: remove the extra ';'";
    /** The interpreter's words; {@code %s} is the run as written ({@code ;;}, {@code ;;;} ...). */
    static final String RUN_OUTSIDE_MATRIX = "'%s' is only allowed inside [ ], where it separates the blocks of an "
            + "N-D matrix ([1,2;3,4 ;; 5,6;7,8]) - end a statement with one ';'";
    static final String BEFORE_COLON = "';' cannot be followed by ':'; remove the ';'";

    @Override
    public void analyze(SourceModel model, CheckContext context, Findings out) {
        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed() || line.isBlank() || line.hasUnterminatedString()) {
                continue;
            }
            String message = checkLine(line.masked());
            if (message != null) {
                out.add(line.index(), Rule.STATEMENT_TERMINATOR, message);
            }
        }
    }

    /**
     * @param s one masked logical line
     * @return the first fault, or null
     */
    static String checkLine(String s) {
        Deque<Character> open = new ArrayDeque<>();
        int n = s.length();
        int i = 0;
        while (i < n) {
            char c = s.charAt(i);
            if (Lexis.isOpenBracket(c)) {
                open.push(c);
                i++;
                continue;
            }
            if (Lexis.isCloseBracket(c)) {
                if (!open.isEmpty()) {
                    open.pop(); // mismatches are BracketAnalyzer's
                }
                i++;
                continue;
            }
            if (c != ';') {
                i++;
                continue;
            }

            int runEnd = Lexis.semicolonRunEnd(s, i);
            if (!open.isEmpty() && open.peek() == '[') {
                i = runEnd; // a separator of a matrix literal
                continue;
            }
            if (runEnd - i > 1) {
                return String.format(RUN_OUTSIDE_MATRIX, s.substring(i, runEnd));
            }
            int next = Lexis.nextNonSpace(s, runEnd);
            if (next < n) {
                char after = s.charAt(next);
                if (after == ';') {
                    return DOUBLE;
                }
                if (after == ':') {
                    return BEFORE_COLON;
                }
            }
            i = runEnd;
        }
        return null;
    }
}
