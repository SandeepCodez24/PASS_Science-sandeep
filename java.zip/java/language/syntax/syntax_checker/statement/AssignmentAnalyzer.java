package language.syntax.syntax_checker.statement;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import language.syntax.syntax_checker.core.Analyzer;
import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.core.Findings;
import language.syntax.syntax_checker.core.Lexis;
import language.syntax.syntax_checker.core.Rule;
import language.syntax.syntax_checker.core.SourceModel;
import language.syntax.syntax_checker.core.TargetList;
import language.syntax.syntax_checker.structure.BlockHeaderGrammar;

/**
 * Checks every assignment {@code =} in a file.
 *
 * <h3>Why this class exists</h3>
 * {@code OperatorSequenceAnalyzer} treats {@code =} as one more binary
 * operator, so {@code A1 = ((B+C=E)&&(A+B==C));} read as a perfectly good
 * chain of operand, operator, operand ... and passed, while the interpreter
 * rejected it. No pass enforced what an assignment actually is: <b>one</b>
 * {@code =}, at bracket depth zero, with a variable on its left and a value on
 * its right. This class owns that rule and nothing else.
 *
 * <h3>The rules</h3>
 * Each statement is checked on its own ({@code ;} at depth zero separates
 * statements, so {@code A = 1; B = 2;} is two assignments, not a chain).
 *
 * <pre>
 *   A = 5                     ok
 *   f(x = 2)                  ok      a named value: a name directly inside a call
 *   f(a, y = 3)               ok
 *   f(a = )                   Syntax Error      'a =' needs a value after it
 *   publish(x = 1)            Syntax Error      publish is a statement, not a function
 *   A1 = ((B+C=E) &amp;&amp; ...)    Syntax Error      '=' inside '(...)' that is not a call
 *   (A = 5)                   Syntax Error      same
 *   A[i = 1] = 5              Syntax Error      same, inside '[...]'
 *   f(x+1 = 2)                Syntax Error      only a bare name may take a keyword value
 *   A = B = 5                 Syntax Error      no chained assignment
 *   A+B = C                   Syntax Error      the left side is an expression
 *   5 = A                     Syntax Error      the left side is a number
 *   = 5                       Syntax Error      nothing to assign to
 *   if A = 5:                 Syntax Error      a condition compares with '=='
 *   DD = ;    DD =            Unassigned Variable Error
 * </pre>
 *
 * <h3>Lists of variables (changed)</h3>
 * Several outputs are always written in square brackets. The left side is
 * read by {@link TargetList}, so it may hold rows, indexes, fields and the
 * {@code ~} placeholder, and the right side may be any expression:
 *
 * <pre>
 *   [a, b, c] = [1, 2, "car"]     ok
 *   [x, y, z] = v                 ok      the elements of v
 *   [m11, m12; m21, m22] = M      ok      element by element
 *   [u, ~] = [7, 8]               ok      '~' skips a value
 *   [a, b] = [b, a]               ok      a swap
 *   (z) = 4                       ok      one name in round brackets is z = 4
 *   [a, b; c] = M                 Syntax Error      rows of different length
 *   [~, ~] = f(x)                 Syntax Error      nothing to assign
 *   [k1, k2] = 5                  Syntax Error      one value for two names: use deal(5)
 *   [a, b] = [1, 2, 3]            Syntax Error      two names, three values
 *   (k1, k2) = f(x)               Syntax Error      retired: write [k1, k2] = f(x)
 * </pre>
 *
 * The value count is compared only when the right side is a plain value or
 * a one-row literal of plain values; anything else is split at run time.
 *
 * <h3>What this class leaves to others</h3>
 * <ul>
 * <li>{@code A^2 = 5} -- {@code ExponentAnalyzer} already reports it.</li>
 * <li>{@code f(x) = 3} -- the "assigns to a call" rule in {@code SubscriptSuperscriptAnalyzer}.</li>
 * <li>{@code function ...} and {@code class ...} headers -- their whole shape,
 * default values included, belongs to {@link BlockHeaderGrammar}.</li>
 * <li>{@code ==}, {@code !=}, {@code <=}, {@code >=} and the factorial form
 * {@code !==} are comparisons, never assignments.</li>
 * </ul>
 *
 * <p>
 * Input is {@link SourceModel}'s masked text, so an {@code =} inside a string
 * literal ({@code publish("t = 0")}) or a comment is invisible here, and a line
 * split with {@code ~~} is checked as the one statement it is. At most one
 * fault is reported per line: the first one found.
 */
public final class AssignmentAnalyzer implements Analyzer {

    /** Which of the two user-facing categories a fault belongs to. */
    private enum Kind {
        /** A malformed assignment. */
        SYNTAX,
        /** A name given an {@code =} and then no value. */
        UNASSIGNED
    }

    /** One fault on one line. Immutable. */
    private static final class Fault {
        final Kind kind;
        final String message;

        Fault(Kind kind, String message) {
            this.kind = kind;
            this.message = message;
        }
    }

    // ---- messages ----------------------------------------------------------

    static final String CHAINED =
            "Only one '=' is allowed in a statement; chained assignment (A = B = 5) is not supported";
    static final String INSIDE_BRACKETS =
            "'=' cannot be used inside %s; it assigns a value. Use '==' to compare";
    static final String BAD_KEYWORD_ARGUMENT =
            "Only a plain name may take a value inside a call, as in f(x = 2); '%s' is not a name";
    /** The interpreter's words for {@code f(a=)}. */
    static final String NAMED_WITHOUT_VALUE = "'%s =' needs a value after it";
    static final String NAMED_IN_STATEMENT = "'%s' is a statement, not a function call, so its values cannot be "
            + "named - write %s(%s)";

    /** Statements written like calls; their values can never be named. */
    private static final Set<String> STATEMENT_CALLS = Set.of("publish", "print");
    static final String IN_CONDITION =
            "'=' in the condition of '%s' assigns a value; use '==' to compare";
    static final String NO_TARGET = "'=' has nothing on its left to assign to";
    /** The interpreter's words for {@code in = 5}. */
    static final String IN_TARGET = "'in' is a keyword and cannot be used as a variable name";
    static final String NUMBER_TARGET = "Cannot assign to the number '%s'; the left of '=' must be a variable name";
    static final String STRING_TARGET = "Cannot assign to a string; the left of '=' must be a variable name";
    static final String EXPRESSION_TARGET =
            "Cannot assign to the expression '%s'; the left of '=' must be a variable name";
    static final String BRACKET_TARGET =
            "Cannot assign to '%s'; write a single name, or list several names as [a, b] = ...";
    static final String ROUND_LIST = "several outputs are written in square brackets - [%1$s] = ..., not (%1$s) = ...";
    static final String SINGLE_VALUE = "the right side is a single value, but there are %d names - "
            + "to give every name the same value write [...] = deal(value)";
    static final String COUNT_MISMATCH = "%d names need %d values, but the right side (1x%d) has %d elements";
    static final String FOR_TARGET = "'for' needs a single loop variable before '=', e.g. 'for i = [1:10]:'";
    static final String UNASSIGNED = "'%s' is declared but never given a value (nothing after '=')";
    /** The interpreter's words for {@code A[0] ,= 5}; {@code %1$s} is {@code ,=} or {@code ;=}. */
    static final String EXTEND_TARGET =
            "'%1$s' extends a variable - the left side must be a plain name, e.g. M %1$s X";
    /** The interpreter's words for {@code y = [x ,= 3]} and {@code max([1, 2] ,= 3)}. */
    static final String EXTEND_NESTED =
            "'%1$s' is only allowed as an assignment operator - write it as a statement of its own, e.g. M %1$s X";

    /** Longest left side quoted in a message before it is shortened. */
    private static final int QUOTE_LIMIT = 24;

    // ---- shapes ------------------------------------------------------------

    private static final Pattern NAME = Pattern.compile(BlockHeaderGrammar.IDENT);

    private static final Pattern NUMBER = Pattern.compile("\\d+(?:\\.\\d*)?(?:[eE][+-]?\\d+)?|\\.\\d+(?:[eE][+-]?\\d+)?");

    /** {@code (z)}: one name in round brackets, the same as {@code z}. */
    private static final Pattern ROUND_NAME = Pattern.compile("\\(\\s*" + BlockHeaderGrammar.IDENT + "\\s*\\)");

    /** {@code (a, b)}: the retired multi-output form, two names or more. Group 1 is the names. */
    private static final Pattern ROUND_OUTPUTS = Pattern.compile(
            "\\(\\s*(" + BlockHeaderGrammar.IDENT + "(?:\\s*,\\s*" + BlockHeaderGrammar.IDENT + ")+)\\s*\\)");

    /**
     * A value whose shape is one element: a number (complex included), a
     * masked string literal, {@code true} or {@code false}.
     */
    private static final Pattern PLAIN_VALUE = Pattern.compile(
            "[+-]?(?:(?:\\d+(?:\\.\\d*)?|\\.\\d+)(?:[eE][+-]?\\d+)?i?)"
                    + "|\"[^\"]*\"|'[^']*'|true|false");

    /** Access modifiers that may precede a class field's name. */
    private static final Pattern FIELD_MODIFIERS = Pattern.compile("^(?:(?:private|protected)\\s+)+");

    /** Characters that make a left side an expression when they sit at depth zero. */
    private static final String EXPRESSION_CHARS = "+-*/%!&|<>";

    @Override
    public void analyze(SourceModel model, CheckContext context, Findings out) {
        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed() || line.isBlank() || line.hasUnterminatedString()) {
                continue;
            }
            // Reported first, so it is the line's assignment message.
            String extend = checkExtend(line);
            if (extend != null) {
                out.add(line.index(), Rule.ASSIGNMENT, extend);
            }
            Fault fault = checkLine(line.masked());
            if (fault != null) {
                out.add(line.index(), fault.kind == Kind.UNASSIGNED ? Rule.UNASSIGNED : Rule.ASSIGNMENT,
                        fault.message);
            }
        }
    }

    /**
     * @param masked one masked logical line
     * @return the first fault on the line, or null
     */
    private static Fault checkLine(String masked) {
        if (masked == null || masked.indexOf('=') < 0) {
            return null;
        }
        String text = masked.trim();
        if (text.isEmpty()) {
            return null;
        }

        // ---- block headers and closers ----------------------------------
        String firstWord = BlockHeaderGrammar.firstWord(text);
        if (BlockHeaderGrammar.isCloser(firstWord)) {
            return null; // BlockHeaderAnalyzer owns everything after a closer
        }
        BlockHeaderGrammar.Header header = BlockHeaderGrammar.parse(text);
        if (header != null) {
            return checkHeader(header, text, firstWord);
        }

        // ---- ordinary statements ----------------------------------------
        for (String statement : Lexis.splitStatements(text)) {
            Fault fault = checkStatement(statement);
            if (fault != null) {
                return fault;
            }
        }
        return null;
    }

    // =====================================================================
    // Extend operators ,= and ;=
    // =====================================================================

    /**
     * {@code M ,= X} / {@code M ;= X} is a statement of its own with one plain
     * name on its left. The masked view already reads it as {@code M = X}
     * ({@link SourceModel}); this checks what that view cannot show.
     *
     * @return the first fault's message, or null
     */
    private static String checkExtend(SourceModel.Line line) {
        String masked = line.masked();
        for (SourceModel.ExtendOperator op : line.extendOperators()) {
            if (op.nested()) {
                return String.format(EXTEND_NESTED, op.text());
            }
            // The statement starts after the last ';' or ':' at depth zero
            // (a one-line block: `for i = [1:3]: R ;= i; fend`).
            int start = 0;
            for (int i = 0; i < op.offset(); i++) {
                char c = masked.charAt(i);
                if ((c == ';' || c == ':') && Lexis.depthAt(masked, i) == 0) {
                    start = i + 1;
                }
            }
            String target = masked.substring(start, op.offset()).trim();
            if (!NAME.matcher(target).matches()) {
                return String.format(EXTEND_TARGET, op.text());
            }
        }
        return null;
    }

    // =====================================================================
    // Headers
    // =====================================================================

    private static Fault checkHeader(BlockHeaderGrammar.Header header, String text, String firstWord) {
        switch (header.kind()) {
            case FUNCTION, CLASS, ELSE -> {
                // Their shape (defaults and outputs included) is BlockHeaderGrammar's.
                return null;
            }
            default -> {
                // if / elseif / while / for: checked below
            }
        }

        String rest = stripColon(text.substring(firstWord.length()));
        // A one-line block (`while x > 3: x = x - 1; wend`): only the part
        // before the header's ':' is the condition. BlockHeaderAnalyzer
        // reports the one-line block itself.
        int bodyColon = BlockHeaderGrammar.topLevelColon(rest, 0);
        if (bodyColon >= 0) {
            rest = rest.substring(0, bodyColon);
        }
        Scan scan = scan(rest);
        if (scan.fault != null) {
            return scan.fault;
        }

        if (header.kind() == BlockHeaderGrammar.Kind.FOR) {
            if (scan.topLevel.isEmpty()) {
                return null; // a missing '=' is a header-shape question, not this one
            }
            if (scan.topLevel.size() > 1) {
                return syntax(CHAINED);
            }
            String variable = rest.substring(0, scan.topLevel.get(0)).trim();
            return NAME.matcher(variable).matches() ? null : syntax(FOR_TARGET);
        }

        // if / elseif / while: a condition never assigns.
        if (!scan.topLevel.isEmpty()) {
            return syntax(String.format(IN_CONDITION, header.kind().keyword()));
        }
        return null;
    }

    private static String stripColon(String text) {
        String trimmed = text.trim();
        return trimmed.endsWith(":") ? trimmed.substring(0, trimmed.length() - 1) : trimmed;
    }

    // =====================================================================
    // Statements
    // =====================================================================

    private static Fault checkStatement(String statement) {
        String text = statement.trim();
        if (text.isEmpty() || text.indexOf('=') < 0) {
            return null;
        }

        Scan scan = scan(text);
        if (scan.fault != null) {
            return scan.fault;
        }
        if (scan.topLevel.isEmpty()) {
            return null;
        }
        if (scan.topLevel.size() > 1) {
            return syntax(CHAINED);
        }

        int equals = scan.topLevel.get(0);
        String target = text.substring(0, equals).trim();
        String value = text.substring(equals + 1).trim();

        if (target.isEmpty()) {
            return syntax(NO_TARGET);
        }

        Fault targetFault = checkTarget(target);
        if (targetFault != null) {
            return targetFault;
        }

        if (value.isEmpty()) {
            return new Fault(Kind.UNASSIGNED, String.format(UNASSIGNED, quote(target)));
        }
        if (target.charAt(0) == '[') {
            return checkListValue(TargetList.parse(target), value);
        }
        return null;
    }

    /**
     * Compares the number of names with the number of values when the right
     * side shows it: a plain value, or a one-row literal of plain values.
     * {@code [a] = 5} is {@code a = 5}, so one name never mismatches.
     *
     * @param list  a well-formed list of variables
     * @param value the trimmed right side
     * @return a fault, or null
     */
    private static Fault checkListValue(TargetList.Parsed list, String value) {
        int names = list.size();
        if (names < 2 || !list.isSingleRow()) {
            return null;
        }
        if (PLAIN_VALUE.matcher(value).matches()) {
            return syntax(String.format(SINGLE_VALUE, names));
        }
        if (value.charAt(0) != '[' || Lexis.matchingClose(value, 0) != value.length() - 1) {
            return null;
        }
        String inner = value.substring(1, value.length() - 1);
        if (inner.isBlank() || inner.indexOf(';') >= 0) {
            return null; // rows are split row by row; the interpreter counts them
        }
        List<String> elements = Lexis.splitTopLevel(inner, ',');
        for (String element : elements) {
            if (!PLAIN_VALUE.matcher(element.trim()).matches()) {
                return null; // a name or a call may itself be a matrix
            }
        }
        if (elements.size() != names) {
            return syntax(String.format(COUNT_MISMATCH, names, names, elements.size(), elements.size()));
        }
        return null;
    }

    /**
     * @param target the trimmed text left of the statement's {@code =}
     * @return a fault when it cannot receive a value, otherwise null
     */
    private static Fault checkTarget(String target) {
        String name = FIELD_MODIFIERS.matcher(target).replaceFirst("").trim();
        if (name.isEmpty()) {
            return syntax(NO_TARGET);
        }

        if (name.equals("in")) {
            return syntax(IN_TARGET);
        }
        char first = name.charAt(0);
        if (first == '"' || first == '\'') {
            return syntax(STRING_TARGET);
        }
        if (NUMBER.matcher(name).matches()) {
            return syntax(String.format(NUMBER_TARGET, quote(name)));
        }
        if (first == '[') {
            TargetList.Parsed list = TargetList.parse(name);
            return list.isValid() ? null : syntax(list.error());
        }
        if (first == '(') {
            if (ROUND_NAME.matcher(name).matches()) {
                return null; // (z) = 4 is z = 4
            }
            Matcher outputs = ROUND_OUTPUTS.matcher(name);
            if (outputs.matches()) {
                return syntax(String.format(ROUND_LIST, Lexis.visible(outputs.group(1)).replaceAll("\\s*,\\s*", ", ")));
            }
            return syntax(String.format(BRACKET_TARGET, quote(name)));
        }

        // A '^' on the left is ExponentAnalyzer's "assign to a power".
        if (hasTopLevel(name, "^")) {
            return null;
        }
        if (hasTopLevel(name, EXPRESSION_CHARS)) {
            return syntax(String.format(EXPRESSION_TARGET, quote(name)));
        }
        return null;
    }

    // =====================================================================
    // Scanning
    // =====================================================================

    /** One open bracket during a scan. */
    private static final class Open {
        final char bracket;
        final boolean call;
        /** The name before a call's '(', or empty. */
        final String callee;
        /** Where the current argument began: just after '(' or the last ','. */
        int argumentStart;

        Open(char bracket, String callee, int argumentStart) {
            this.bracket = bracket;
            this.call = callee != null;
            this.callee = callee == null ? "" : callee;
            this.argumentStart = argumentStart;
        }
    }

    /** What one scan of a statement found. */
    private static final class Scan {
        final List<Integer> topLevel = new ArrayList<>();
        Fault fault;
    }

    /**
     * Walks a statement once, collecting every assignment {@code =} at depth
     * zero and stopping at the first {@code =} that sits inside brackets and is
     * not a keyword argument.
     */
    private static Scan scan(String s) {
        Scan result = new Scan();
        ArrayDeque<Open> stack = new ArrayDeque<>();
        int n = s.length();

        for (int i = 0; i < n; i++) {
            char c = s.charAt(i);

            if (c == '(' || c == '[' || c == '{') {
                stack.push(new Open(c, c == '(' ? calleeOf(s, i) : null, i + 1));
                continue;
            }
            if (c == ')' || c == ']' || c == '}') {
                if (!stack.isEmpty()) {
                    stack.pop(); // mismatches are BracketAnalyzer's to report
                }
                continue;
            }
            if (c == ',' && !stack.isEmpty()) {
                stack.peek().argumentStart = i + 1;
                continue;
            }
            if (c != '=') {
                continue;
            }

            // ---- is this '=' part of a comparison? ------------------------
            if (i + 1 < n && s.charAt(i + 1) == '=') {
                i++; // '==' (and the tail of '!==' factorial-then-equals)
                continue;
            }
            char before = i > 0 ? s.charAt(i - 1) : ' ';
            if (before == '!' || before == '<' || before == '>' || before == '=') {
                continue; // '!=', '<=', '>='
            }

            // ---- an assignment '=' ----------------------------------------
            if (stack.isEmpty()) {
                result.topLevel.add(i);
                continue;
            }

            Open open = stack.peek();
            if (open.call) {
                String argument = s.substring(open.argumentStart, i).trim();
                if (NAME.matcher(argument).matches()) {
                    if (STATEMENT_CALLS.contains(open.callee.toLowerCase(Locale.ROOT))) {
                        result.fault = syntax(String.format(NAMED_IN_STATEMENT, open.callee, open.callee,
                                quote(argument)));
                        return result;
                    }
                    int value = Lexis.nextNonSpace(s, i + 1);
                    if (value >= n || s.charAt(value) == ',' || s.charAt(value) == ')') {
                        result.fault = syntax(String.format(NAMED_WITHOUT_VALUE, quote(argument)));
                        return result;
                    }
                    continue; // f(x = 2): a named value
                }
                result.fault = syntax(String.format(BAD_KEYWORD_ARGUMENT, quote(argument)));
                return result;
            }
            result.fault = syntax(String.format(INSIDE_BRACKETS, describe(open.bracket)));
            return result;
        }
        return result;
    }

    /**
     * The name of the call the {@code (} at {@code open} belongs to: a name
     * sits directly before it ({@code f(}, {@code publish (}). A keyword such
     * as {@code if (} is not a call; header keywords are removed before the
     * scan.
     *
     * @return the callee, or null when the bracket is not a call
     */
    private static String calleeOf(String s, int open) {
        int p = open - 1;
        while (p >= 0 && Character.isWhitespace(s.charAt(p))) {
            p--;
        }
        if (p < 0 || !Lexis.isIdentPart(s.charAt(p))) {
            return null;
        }
        int start = p;
        while (start >= 0 && Lexis.isIdentPart(s.charAt(start))) {
            start--;
        }
        start++;
        // "2(" is a number before a bracket, not a call.
        return start <= p && Lexis.isIdentStart(s.charAt(start)) ? s.substring(start, p + 1) : null;
    }

    /** True when any of {@code chars} occurs in {@code s} at bracket depth zero. */
    private static boolean hasTopLevel(String s, String chars) {
        int depth = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '(' || c == '[' || c == '{') {
                depth++;
            } else if (c == ')' || c == ']' || c == '}') {
                depth = Math.max(0, depth - 1);
            } else if (depth == 0 && chars.indexOf(c) >= 0) {
                return true;
            }
        }
        return false;
    }

    private static String describe(char bracket) {
        return switch (bracket) {
            case '[' -> "'[...]'";
            case '{' -> "'{...}'";
            default -> "'(...)'";
        };
    }

    /** Shortens long source text for a message and removes the hidden styling markers. */
    private static String quote(String text) {
        String clean = text.replace("\u200C", "").replace("\u200D", "").trim();
        if (clean.length() > QUOTE_LIMIT) {
            return clean.substring(0, QUOTE_LIMIT - 3) + "...";
        }
        return clean;
    }

    private static Fault syntax(String message) {
        return new Fault(Kind.SYNTAX, message);
    }
}
