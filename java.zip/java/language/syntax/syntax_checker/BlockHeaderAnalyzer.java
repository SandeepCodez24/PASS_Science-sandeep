package language.syntax.syntax_checker;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Reports block headers that are incomplete or malformed, on the header line
 * and nowhere else.
 *
 * <h3>Why this is its own check</h3>
 * The missing-colon rule used to live inside
 * {@link IndentationSyntaxAnalyzer}, and only for branch lines. For every other
 * header the colon was the condition for opening a block at all, so
 * {@code function ASD = f(x)} opened nothing: its body was then reported as an
 * unexpected indent and its {@code fnend} as an orphan, while the header line
 * itself stayed clean. The user saw red dots on every line <i>except</i> the
 * one that was wrong.
 *
 * <p>
 * The indentation pass now opens the block regardless (see
 * {@link BlockHeaderGrammar}), and this pass owns every header-shape rule:
 * <ul>
 * <li>the trailing {@code :} on {@code if / elseif / else / for / while /
 * function / class};</li>
 * <li>{@code if}, {@code elseif} and {@code while} carrying a condition, and
 * {@code else} carrying none;</li>
 * <li>the three accepted function shapes and the one class shape.</li>
 * </ul>
 * Each line appears at most once, with one combined message, so a header can
 * never be counted twice by this pass.
 *
 * <h3>Closing lines</h3>
 * A block closer -- {@code iend}, {@code fend}, {@code wend}, {@code fnend},
 * {@code csend} -- must stand alone on its line. Nothing may follow it: not a
 * statement ({@code fnend publish("x");}), not a semicolon ({@code fnend;}),
 * and not a {@code \\} comment. The only thing allowed after a closer is a
 * {@code #} comment ({@code fnend  # end of guarded}).
 *
 * <p>
 * Before this rule, {@code fnend  publish("india...!");} passed without a mark,
 * because every pass recognised the closer by its first word alone and never
 * looked at the rest of the line.
 */
final class BlockHeaderAnalyzer {

    private BlockHeaderAnalyzer() {
    }

    /** The only comment marker allowed after a closer. */
    private static final char CLOSER_COMMENT = '#';

    /**
     * @param code raw editor text
     * @return zero-based line index to message
     */
    static Map<Integer, String> analyze(String code) {
        return analyze(SourceModel.of(code));
    }

    /**
     * @param model the cleaned document
     * @return zero-based line index to a user-facing message, one per faulty header
     */
    static Map<Integer, String> analyze(SourceModel model) {
        Map<Integer, String> faults = new HashMap<>();
        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed() || line.isBlank()) {
                continue;
            }
            // An unterminated literal would make the masked tail meaningless;
            // that line is already reported by the string check.
            if (line.hasUnterminatedString()) {
                continue;
            }
            String closerFault = closerFault(line);
            if (closerFault != null) {
                faults.put(line.index(), closerFault);
                continue;
            }
            BlockHeaderGrammar.Header header = BlockHeaderGrammar.parse(line.masked());
            if (header != null && !header.isValid()) {
                faults.put(line.index(), header.error());
            }
        }
        return Collections.unmodifiableMap(faults);
    }

    /**
     * @param line one logical line
     * @return a message when the line is a closer with something after it,
     *         otherwise null
     */
    private static String closerFault(SourceModel.Line line) {
        String masked = line.masked().trim();
        String word = BlockHeaderGrammar.firstWord(masked);
        if (!BlockHeaderGrammar.isCloser(word)) {
            return null;
        }

        // Code after the closer: a statement, a ';', anything but a comment.
        // The masked view has every comment removed and every string blanked,
        // so this catches `fnend publish("x");` and `fnend;` alike.
        String afterInCode = masked.substring(word.length()).trim();

        // A comment after the closer: only '#' is allowed. The masked view
        // cannot tell '#' from '\\' (both are removed), so the raw line is
        // read for that. A closer continued with '~~' is caught above, since
        // the next line's text is then part of this logical line.
        String raw = line.raw().stripLeading();
        String afterInRaw = raw.length() >= word.length() ? raw.substring(word.length()).trim() : "";

        boolean clean = afterInCode.isEmpty()
                && (afterInRaw.isEmpty() || afterInRaw.charAt(0) == CLOSER_COMMENT);
        if (clean) {
            return null;
        }
        return "Nothing may follow '" + word + "' on its line (only a '#' comment is allowed)";
    }
}
