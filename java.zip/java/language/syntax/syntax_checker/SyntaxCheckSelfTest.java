package language.syntax.syntax_checker;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.core.Rule;

/**
 * Regression cases for the syntax checker. Run it as a plain Java program
 * (VS Code: "Run" above {@code main}); it needs no test library.
 *
 * <p>
 * Every case is a small Neural Code snippet and what the checker must say
 * about it: nothing at all, or a fault of one particular {@link Rule} on one
 * particular line. Add a case here whenever a bug is fixed, so it can never
 * come back unnoticed.
 *
 * <p>
 * Pass a {@code .nc} file as the first argument to also require that the
 * whole file is clean, e.g. the reference script
 * {@code nd_matrix_examples.nc}.
 */
public final class SyntaxCheckSelfTest {

    private static final List<String> FAILURES = new ArrayList<>();
    private static int passed;

    private SyntaxCheckSelfTest() {
    }

    public static void main(String[] args) throws IOException {
        Path folder = Files.createTempDirectory("nc-selftest");
        Files.writeString(folder.resolve("ABC.nc"), "publish(\"abc\");\n", StandardCharsets.UTF_8);
        Path mm = folder.resolve("mm.nc");
        Files.writeString(mm, "", StandardCharsets.UTF_8);
        CheckContext inFolder = CheckContext.forFile(mm);

        absoluteValues();
        operators();
        semicolons();
        scripts(inFolder);
        continuations();
        blocks();
        languageFlags();
        builtinNamedValues();
        complexNumbers();
        strings();
        matrices();
        ndMatrices();
        listsOfVariables();
        defaultsAndNamedValues();
        callMatching();
        classMembers();
        scriptedNames();
        extendOperators();
        textOperands();
        timeValues();
        variadicNamedValues();
        dataIo();
        dictColon();
        backendChanges20261030();
        transpose();
        for (String file : args) {
            clean("whole file " + file, Files.readString(Path.of(file), StandardCharsets.UTF_8));
        }

        System.out.println();
        System.out.println(passed + " passed, " + FAILURES.size() + " failed");
        FAILURES.forEach(f -> System.out.println("  FAIL " + f));
        if (!FAILURES.isEmpty()) {
            System.exit(1);
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // Cases
    // ─────────────────────────────────────────────────────────────────────

    private static final String VARS = "A = 1; B = 2; D = 3; H = 4; U = 5; count = 0; p1count = 1; p2count = 1;\n";

    private static void absoluteValues() {
        clean("abs simple", VARS + "X = |-5|;");
        clean("abs expression and power", VARS + "X = |A-B|^2;");
        clean("double abs", VARS + "X = ||A||;");
        clean("abs OR abs", VARS + "X = |A| || |B|;");
        clean("abs in call", VARS + "publish(|A|, ||B||);");
        clean("abs after if (screenshot line 67)", VARS + "if |U| == |U|:\n   count = count +1;\niend");
        clean("abs after if (screenshot line 75)", VARS + "if |A-B| == |B-A|:\n   count = count +1;\niend");
        clean("abs after return", "function y = f(x):\n   return |x|;\nfnend");

        fault("bar crosses ')' (item 1)", VARS + "A16 = (|D/B)==B)!&(D==|H/D));", Rule.ABSOLUTE_VALUE, 1);
        fault("bar crosses ')' (item 2)", VARS + "A16 = (|D/B)<=B+1)!&(D<=|H/D));", Rule.ABSOLUTE_VALUE, 1);
        fault("item 1 brackets are also unbalanced", VARS + "A16 = (|D/B)==B)!&(D==|H/D));", Rule.INCOMPLETE_LINE, 1);
        fault("(|x)|", VARS + "X = (|A)|;", Rule.ABSOLUTE_VALUE, 1);
        fault("never closed", VARS + "X = |A;", Rule.ABSOLUTE_VALUE, 1);
    }

    private static void operators() {
        fault("single & (item 3)", VARS + "while (1==1)&& (A==A) & p1count && p2count:\n   A = A + 1;\nwend",
                Rule.OPERATOR_SEQUENCE, 1);
        fault("single |", VARS + "X = A | B;", Rule.OPERATOR_SEQUENCE, 1);
        fault("&|", VARS + "X = A &| B;", Rule.OPERATOR_SEQUENCE, 1);
        fault("|&", VARS + "X = A |& B;", Rule.OPERATOR_SEQUENCE, 1);
        fault("dangling && in header", VARS + "while A &&:\n   A = A + 1;\nwend", Rule.OPERATOR_SEQUENCE, 1);
        clean("full logical header", VARS + "while (1==1) && (A==A) && p1count && p2count:\n   A = A + 1;\nwend");
        clean("logical operands of any kind", VARS + "X = p1count && not (A == B) || true;");
        clean("!& and !|", VARS + "X = (A==B) !& (B==D); Y = (A==B) !| (B==D);");
    }

    private static void semicolons() {
        fault(";; outside [ ]", VARS + "X = 1;;", Rule.STATEMENT_TERMINATOR, 1);
        fault(";;; outside [ ]", VARS + "X = 1;;; Y = 2;", Rule.STATEMENT_TERMINATOR, 1);
        fault(";; inside a call is not a matrix", VARS + "X = max(1;;2);", Rule.STATEMENT_TERMINATOR, 1);
        fault("; ;", VARS + "X = 1; ;", Rule.STATEMENT_TERMINATOR, 1);
        fault(";:", VARS + "if A == 1;:\n   X = 1;\niend", Rule.STATEMENT_TERMINATOR, 1);
        clean("two statements on a line", VARS + "X = 1; Y = 2;");
        clean("no trailing ';' echoes, not an error", VARS + "X = 1");
        clean("';;' inside a string", VARS + "publish(\"a;;b\");");
        clean("matrix rows", VARS + "M = [1, 2; 3, 4];");
    }

    private static void scripts(CheckContext inFolder) {
        clean("bare script call", "ABC;", inFolder);
        clean("bare script call, no ';'", "ABC", inFolder);
        clean("function inside a script", "Y = ABC.f(2);", inFolder);
        fault("script with brackets", "ABC();", Rule.SCRIPT_CALL, 0, inFolder);
        fault("script with extension", "ABC.nc;", Rule.SCRIPT_CALL, 0, inFolder);
        fault("script as a value", "X = ABC;", Rule.SCRIPT_CALL, 0, inFolder);
        fault("script calls itself", "mm;", Rule.SCRIPT_CALL, 0, inFolder);
        fault("variable reuses a script name", "ABC = 5;\nABC;", Rule.SCRIPT_CALL, 1, inFolder);
        fault("unknown script", "XYZ;", Rule.UNDEFINED_NAME, 0, inFolder);
        fault("no folder: bare name is undefined", "ABC;", Rule.UNDEFINED_NAME, 0, CheckContext.NONE);
        clean("function of the same name defined here", "function ABC():\n   publish(1);\nfnend\nABC();",
                inFolder);
    }

    private static void continuations() {
        clean("while split under its condition",
                VARS + "while A<0 && ~~\n      B>5:\n   A = A + 1;\nwend");
        clean("while split 3 spaces in (any column is valid)",
                VARS + "while A<0 && ~~\n   B>5:\n   A = A + 1;\nwend");
        clean("string split under its first character", "M = \"I am a ~~\n     message\";");
        clean("string split at any column", "M = \"I am a ~~\n   message\";");
        clean("assignment split under its value", VARS + "T = A + B ~~\n    + D;");
        clean("call split under its first argument", VARS + "publish(\"sum:\", ~~\n        A);");
        clean("for split after '='", "for i = [1, 2, ~~\n        3]:\n   publish(i);\nfend");
        clean("commented-out split while (screenshot)",
                VARS + "\\\\ while (A+B)<D && (A-B)<D && sqrt(A)<B && ~~\n"
                        + "\\\\       A!<D && |-A|<B:\n"
                        + "\\\\    A = 100;\n"
                        + "\\\\    publish(\"passed while primitives\")\n"
                        + "\\\\ wend");
        clean("'#' comment ending in ~~", VARS + "# a note ~~\nA = 2;");
        clean("~~ inside a string still continues", "M = \"a # b ~~\n     c\";");
        clean("if split, three lines", VARS + "if A == 1 ~~\n   || B == 2 ~~\n   || D == 3:\n   A = 2;\niend");
        clean("while not split under its condition, not under 'not'",
                VARS + "while not (A >= 128) && (B >= 128) && ~~\n          (D >= 128):\n   A = A + 1;\nwend");
        clean("while not split under 'not' (any column is valid)",
                VARS + "while not (A >= 128) && ~~\n      (D >= 128):\n   A = A + 1;\nwend");
        // nc.exe: the next line may start anywhere (2026-10-27).
        clean("header split at column 0 and far right",
                """
                function y = f(a=1, ~~
                b=2, ~~
                                         c=3):
                   y = a + b + c;
                fnend
                z = f(1, ~~
                  c=10);""");
        clean("condition split at column 0", VARS + "if A > 2 ~~\n&& A < 100:\n   publish(\"ok\");\niend");
        clean("tab and spaces after ~~", VARS + "T = A + ~~ \t\n\t\tB;");
        clean("~~ on the last line is dropped", VARS + "T = A + B ~~");
        fault("call split over three lines is checked as one call",
                "function y = g(a, b):\n   y = a + b;\nfnend\nz = g(1, ~~\nc=2, ~~\n3);", Rule.CALL_MATCH, 3);
        absent("continuation line indentation is not checked",
                VARS + "if A == 1:\n   T = A + ~~\n B;\niend", Rule.INDENTATION, 2);
        fault("'~~' then a comment is not a continuation", VARS + "T = A + ~~  # note\nB;",
                Rule.OPERATOR_SEQUENCE, 1);
        fault("a comment ending in ~~ does not take the next line (as nc.exe)",
                "# note ~~\nX = undefinedName;", Rule.UNDEFINED_NAME, 1);
        fault("nor does a trailing comment ending in ~~", "A = 1; # note ~~\nX = undefinedName;",
                Rule.UNDEFINED_NAME, 1);
        clean("if not split under its condition",
                VARS + "if not (A == 1) || ~~\n       (B == 2):\n   A = 2;\niend");
        clean("elseif not split under its condition",
                VARS + "if A == 1:\n   A = 2;\nelseif not (B == 2) || ~~\n           (D == 3):\n   A = 3;\niend");
    }

    private static void blocks() {
        String t17 = """
                i1 = 1;
                while i1 <= 2:
                   for i2 = [1:2]:
                      if i2 == 1:
                         publish("while->for->if:", i1, i2);
                      else:
                         publish("while->for->else:", i1, i2);
                      iend
                   fend
                   i1 = i1 + 1;
                wend
                """;
        clean("t17 nested loops", t17);
        fault("missing iend", VARS + "if A == 1:\n   A = 2;\n", Rule.BLOCK_STRUCTURE, 1);
        fault("missing colon", VARS + "if A == 1\n   A = 2;\niend", Rule.BLOCK_HEADER, 1);
        fault("text after closer", VARS + "if A == 1:\n   A = 2;\niend;", Rule.BLOCK_HEADER, 3);
        fault("bad indentation", VARS + "if A == 1:\n    A = 2;\niend", Rule.INDENTATION, 2);

        // Language flags of 2026-10 (nc.exe gives the same messages).
        fault("elif is not a keyword", VARS + "if A == 1:\n   A = 2;\nelif A == 2:\n   A = 3;\niend",
                Rule.BLOCK_HEADER, 3);
        absent("elif keeps the block intact", VARS + "if A == 1:\n   A = 2;\nelif A == 2:\n   A = 3;\niend",
                Rule.INDENTATION, 3);
        fault("one-line if", VARS + "if A: publish(1); iend", Rule.BLOCK_HEADER, 1);
        absent("one-line if is one error", VARS + "if A: publish(1); iend", Rule.BLOCK_STRUCTURE, 1);
        absent("one-line while is not '=' in a condition", VARS + "while A > 3: A = A - 1; wend",
                Rule.ASSIGNMENT, 1);
        fault("MATLAB for range", "for i = 1:3:\n   publish(i);\nfend", Rule.BLOCK_HEADER, 0);
        clean("for in any expression", "for i in [1, 2, 3]:\n   publish(i);\nfend");
        fault("closer as a variable", "iend = 2;", Rule.BLOCK_HEADER, 0);
        absent("closer as a variable is one error", "iend = 2;", Rule.BLOCK_STRUCTURE, 0);
    }

    /** Named values for built-ins, and poly1d calls (nc.exe 2026-10-27; its messages). */
    private static void builtinNamedValues() {
        String ab = "A = [1, 1; 1, 1]; B = [0.95, 1; 1, 1.2];\n";
        clean("allclose by name", ab + "r = allclose(A, B, atol=0.25);");
        clean("named first, plain values fill the rest", ab + "r = allclose(atol=0.2, A, B);");
        clean("plain after named takes the next open input", ab + "r = allclose(A, B, 0.2, atol=0.1);");
        clean("round with its default", "r = round([1.25, 2.5]);");
        clean("round by name", "r = round([1.234, 5.678], decimals=1);");
        clean("max along an axis", "r = max([1, 5; 7, 2], axis=0);");
        clean("angle in degrees", "r = angle([1i, -1], deg=true);");
        clean("an optional input by name", "r = cross([1, 0, 0], [0, 1, 0], axis=1);");
        fault("no input named 'tol'", ab + "allclose(A, B, tol=0.1);", Rule.CALL_MATCH, 1);
        fault("required input not given", ab + "allclose(A, atol=0.1);", Rule.CALL_MATCH, 1);
        fault("same input twice", ab + "allclose(A, B, atol=0.1, atol=0.2);", Rule.CALL_MATCH, 1);
        fault("a built-in without a parameter line", "x = sqrt(x=4);", Rule.CALL_MATCH, 0);
        fault("a family name", "v = exp2(x=3);", Rule.CALL_MATCH, 0);
        fault("the parser's own call", "v = feval(f=1);", Rule.CALL_MATCH, 0);
        fault("axis with two values", ab + "max(A, B, axis=0);", Rule.CALL_MATCH, 1);
        fault("axis not whole", ab + "m = max(A, axis=1.5);", Rule.CALL_MATCH, 1);
        fault("deg not true/false", "q = angle(1i, deg=1);", Rule.CALL_MATCH, 0);
        fault("too many plain values beside a name", "r = lcm(6, B=4, 5);", Rule.CALL_MATCH, 0);
        String own = "function y = allclose(x, y):\n   y = x + y;\nfnend\n";
        clean("a user function wins: its own names", own + "a = allclose(x=1, y=2);");
        fault("a user function wins: no atol", own + ab + "a = allclose(A, B, atol=1);", Rule.CALL_MATCH, 4);

        String p = "P = poly1d([2, 3, 1]);\n";
        clean("poly1d call, index, field", p + "v = P(2); c = P[2]; o = P.order; w = polyval(P, [0, 1]);");
        fault("poly1d by name", p + "P(x=2);", Rule.CALL_MATCH, 1);
        fault("poly1d with two values", p + "P(1, 2);", Rule.CALL_MATCH, 1);
        clean("poly1d made inside an if: not judged",
                "if 1 == 1:\n   P = poly1d([1, 2]);\niend\nP(1, 2);");
        clean("euler_gamma, then replaced", "g = euler_gamma;\neuler_gamma = 5;\nh = euler_gamma;");
    }

    private static void languageFlags() {
        clean("anonymous function inputs", "a = 2;\nf = @(x, y) a * x + y;\nz = f(1, 2);");
        fault("anonymous inputs stay inside", "f = @(x) x * 2;\ny = x;", Rule.UNDEFINED_NAME, 1);
        fault("r is no longer a constant", "y = 2 * pi * r;", Rule.UNDEFINED_NAME, 0);
        fault("constants are case-sensitive", "z = PI;", Rule.UNDEFINED_NAME, 0);
        clean("long constant names", "y = gravity + gas_constant + planck + e + pi;");
        clean("return with a value", "function y = f(x):\n   return x * 2;\nfnend");
        clean("contract message", "function y = f(x):\n   require x > 0, \"x must be positive\";\n   y = x;\nfnend");
        clean("index a call result", "d = dict([\"a\"], [1]);\nk = keys(d)[0];");
        clean("text and collection functions",
                "s = \"abc\"; c = s[0]; t = upper(s) + lower(\"X\"); n = length(s); v = sort([3, 1]);");
    }

    private static void matrices() {
        clean("matrix a,a,a;b,b,b", VARS + "M = [A, A, A; B, B, B; D, D, D];");
        clean("row vector", "M = [1, 2, 3];");
        clean("column vector", "M = [1; 2; 3];");
        clean("empty matrix", "M = [];");
        clean("range in a for header", "for i = [1:2:100]:\n   publish(i);\nfend");
        clean("range rows are not counted", "M = [1:3; 4:6];");
        clean("strings in a matrix", "M = [\"a;b\", \"c,d\"; \"e\", \"f\"];");
        clean("call inside a matrix", VARS + "M = [sqrt(A), max(A, B); 1, 2];");
        clean("function outputs list", "function [a, b] = f(x):\n   a = x; b = x;\nfnend");
        fault("space separated row", "M = [1 2 3];", Rule.MISSING_SEPARATOR, 0);
        fault("space separated rows", "M = [1 2; 3 4];", Rule.MISSING_SEPARATOR, 0);
        fault("old nested form", "M = [[1, 2], [3, 4]];", Rule.MATRIX, 0);
        fault("ragged rows", "M = [1, 2, 3; 4, 5];", Rule.MATRIX, 0);
        fault("empty row at the end", "M = [1, 2;];", Rule.MATRIX, 0);
        clean("';;' between two rows is a 3-D matrix", "M = [1, 2;; 3, 4];");
        fault("empty row in the middle (a space between)", "M = [1, 2; ; 3, 4];", Rule.MATRIX, 0);
        fault("empty element", "M = [1, , 2];", Rule.MATRIX, 0);

        String m = "A = [1, 2, 3; 4, 5, 6; 7, 8, 9];\n";
        clean("element", m + "x = A[1, 2];");
        clean("copy", m + "B = A[::];");
        clean("row m", m + "r = A[1];");
        clean("row m with comma", m + "r = A[1,];");
        clean("column n", m + "c = A[:,2];");
        clean("column n, empty row part", m + "c = A[,2];");
        clean("rows from m", m + "r = A[1:,];");
        clean("columns from n", m + "c = A[,1:];");
        clean("block slice", m + "S = A[0:2, 1:3];");
        clean("variable slice bounds", m + "m1 = 0; m2 = 2; S = A[m1:m2, m1:m2];");
        clean("index assignment", m + "A[2, 3] = 5;");
        clean("dictionary key", "d = {}; d[\"key\"] = 5;");
        fault("empty index", m + "x = A[];", Rule.MATRIX, 1);
        fault("empty row and column", m + "x = A[,];", Rule.MATRIX, 1);
        clean("three keys (the rank is known at run time)", m + "x = A[1, 2, 3];");
        fault("';' in an index", m + "x = A[1; 2];", Rule.MATRIX, 1);
        fault("backwards slice", m + "x = A[3:1, 2];", Rule.MATRIX, 1);
        clean("start:step:end", m + "x = A[0:2:3, 1];");
        fault("three colons in a key", m + "x = A[1:2:3:4, 1];", Rule.MATRIX, 1);
        fault("a step of zero", m + "x = A[0:0:3, 1];", Rule.MATRIX, 1);
        clean("negative end counts from the end", m + "x = A[1:-1, 0];");
        fault("backwards negative slice", m + "x = A[-1:-3, 0];", Rule.MATRIX, 1);
    }

    private static void ndMatrices() {
        String b = """
                B = [1,2,3; 4,5,6; 7,8,9 ;; ~~
                     10,11,12; 13,14,15; 16,17,18 ;; ~~
                     19,20,21; 22,23,24; 25,26,27];
                """;
        clean("3-D literal over ~~ lines, under the first element", b + "publish(shape(B), ndims(B));");
        clean("3-D literal continued under its '['", "B = [1,2;3,4 ;; ~~\n    5,6;7,8];");
        clean("3-D literal continued at any column", "B = [1,2;3,4 ;; ~~\n   5,6;7,8];");
        clean("4-D literal", "Q = [1,2;3,4 ;; 5,6;7,8 ;;; 9,10;11,12 ;; 13,14;15,16];");
        clean("trailing ';;' raises the rank", "T1 = [1,2;3,4;;];");
        clean("trailing ';;;' raises the rank", "T2 = [1,2;;;];");
        clean("slab, element and whole last axis",
                b + "slab = B[1]\none = B[2,0,1];\nr = B[1,2,:];\nc = B[:,1,1];");
        clean("';;' joins matrices", b + "K = [B[0] ;; B[1]];");
        clean("element-wise arithmetic", b + "C = B *. 2 + 1;\nC[0]");
        clean("for over the slabs", b + "total = 0;\nfor s = B:\n   total = total + s[0,0];\nfend");
        clean("N-D zeros and index assignment", "Z = zeros([2,3,4]);\nZ[1,2,3] = 7;");
        clean("reshape", "R = reshape([1:24], [2,3,4]);\nR[1,2,:]");
        clean("text and bool literals", "S = [1, 2; 3, \"car\"]\nF = [true, 2.5]");
        clean("blocks holding names are left to the interpreter", VARS + "M = [A ;; 1, 2];");
        fault("blocks of different shape", "M = [1,2;3,4 ;; 5,6];", Rule.MATRIX, 0);
        fault("4-D blocks of different shape", "M = [1;2 ;; 3;4 ;;; 5;6];", Rule.MATRIX, 0);
        fault("empty block between two ';;'", "M = [1,2 ;; ;; 3,4];", Rule.MATRIX, 0);
        fault("leading ';;'", "M = [;; 1,2];", Rule.MATRIX, 0);
        fault("ragged rows inside one block", "M = [1,2;3 ;; 5,6;7,8];", Rule.MATRIX, 0);
        fault("an empty key among three", b + "x = B[, 1, 2];", Rule.MATRIX, 3);
        clean("';;' in a string", "publish(\"a;;b\");");
    }

    private static void listsOfVariables() {
        clean("literal shaped like the list", "[a, b, c] = [1, 2, \"car\"]\npublish(a, b, c);");
        clean("elements of a vector", "v = [10, 20, 30];\n[x, y, z] = v;\npublish(x, y, z);");
        clean("rows of a matrix", "M = [1,2;3,4];\n[r0, r1] = M\npublish(r0, r1);");
        clean("element by element", "M = [1,2;3,4];\n[m11, m12; m21, m22] = M;\npublish(m11, m12, m21, m22);");
        clean("swap", "a = 1; b = 2;\n[a, b] = [b, a];\npublish(a, b);");
        clean("deal and '~'", "[d1, d2] = deal(0);\n[u, ~] = [7, 8];\npublish(d1, d2, u);");
        clean("'~' first", "[~, i2] = max([3, 9]);\npublish(i2);");
        clean("one name in a list", "[a] = 5;\npublish(a);");
        clean("index and field targets", "A = [1, 2];\n[A[0], b] = deal(0);\npublish(A, b);");
        clean("after another statement on the line", "x = 1; [a, b] = deal(x); publish(a, b);");
        clean("a '[' starting a line is its own statement", "M = [1,2;3,4];\nx = M\n[a, b] = M;\npublish(a, b);");
        clean("function with several outputs",
                """
                function [s1, d1] = sumdiff(p, q):
                   s1 = p + q;
                   d1 = p - q;
                fnend
                [s1, d1] = sumdiff(5, 3);
                publish(s1, d1);""");
        clean("one name in round brackets", "(z) = 4;\npublish(z);");

        fault("one value for two names", "[k1, k2] = 5", Rule.ASSIGNMENT, 0);
        fault("two names, three values", "[a, b] = [1, 2, 3];", Rule.ASSIGNMENT, 0);
        fault("rows of different length", "M = [1,2;3,4];\n[a, b; c] = M;", Rule.ASSIGNMENT, 1);
        absent("a list is not a matrix", "M = [1,2;3,4];\n[a, b; c] = M;", Rule.MATRIX, 1);
        fault("every entry is '~'", "[~, ~] = deal(1);", Rule.ASSIGNMENT, 0);
        fault("a number in the list", "[a, 5] = deal(1);", Rule.ASSIGNMENT, 0);
        fault("';;' in the list", "M = [1,2;3,4];\n[a, b;; c, d] = M;", Rule.ASSIGNMENT, 1);
        fault("retired round outputs", "function [s, d] = f(p):\n   s = p; d = p;\nfnend\n(k1, k2) = f(3);",
                Rule.ASSIGNMENT, 3);
        absent("retired round outputs still define their names",
                "function [s, d] = f(p):\n   s = p; d = p;\nfnend\n(k1, k2) = f(3);\npublish(k1, k2);",
                Rule.UNDEFINED_NAME, 4);
        fault("retired round outputs in a header", "function (B1, B2) = f(x):\n   B1 = x; B2 = x;\nfnend",
                Rule.BLOCK_HEADER, 0);
        fault("the right side is read before the names", "[a, b] = [b, a];", Rule.UNDEFINED_NAME, 0);
    }

    private static final String G = "function y = G(a, b=100, c=1000):\n   y = a + b + c;\nfnend\n";

    private static final String SHAPE = """
            class Shape():
               function base(w, h=1, label="shape"):
                  base.w = w;
                  base.h = h;
                  base.label = label;
               fnend
               function A = area(scale=1):
                  A = base.w * base.h * scale;
               fnend
               function grow(dw=1, dh=1):
                  base.w = base.w + dw;
               fnend
            csend
            """; // 13 lines

    private static void defaultsAndNamedValues() {
        clean("defaults of every kind",
                """
                function f(a=1, b="car", c=[1, 2; 3, 4], d=|-2|, e=sqrt(16), g=2*3 + 1):
                   publish(a, b, c, d, e, g)
                fnend
                f();""");
        clean("',' ':' and brackets inside a default", "function y = f(a=\"x:y\", b=[1, 2]):\n   y = a;\nfnend");
        clean("a default before an input without one", "function K(a=1, b):\n   publish(a, b)\nfnend\nK(b=7);");
        clean("a default uses another input", "function y = area(w, h=w):\n   y = w * h;\nfnend\nz = area(4);");
        clean("a method default reads the object", SHAPE.replace("area(scale=1)", "area(scale=base.w)"));
        clean("header split inside its brackets",
                "function y = g(a=1,   # first\n         b=2,\n   c=3):\n   y = a + b + c;\nfnend\nz = g(1);");
        clean("header split with ~~", "function y = h(a=1, ~~\n               b=2):\n   y = a + b;\nfnend");
        fault("input twice", "function y = Twice(x, x):\n   y = x;\nfnend", Rule.BLOCK_HEADER, 0);
        fault("'=' with no default", "function y = Bad(a, b=):\n   y = a;\nfnend", Rule.BLOCK_HEADER, 0);
        reportedOnce("'=' with no default is reported once", "function y = Bad(a, b=):\n   y = a;\nfnend", 0);
        fault("a default that is not a value", "function y = Bad(a, b=*2):\n   y = a;\nfnend",
                Rule.OPERATOR_SEQUENCE, 0);
        fault("a default using an undefined name", "function y = f(a=q):\n   y = a;\nfnend", Rule.UNDEFINED_NAME, 0);
        clean("named values", G + "r = G(1, c=0); s = G(c=0, a=5); t = G(a = 3);");
        clean("'==' is a comparison, not a name", G + "r = G(1 == 1);");
        clean("a value named like a caller's variable",
                "function C = Add(x1, x2):\n   C = x1 + x2;\nfnend\nx1 = 3;\nr = Add(x2=x1, x1=10);");
        clean("named values nest", G + "r = G(c=G(b=2, 1), 1);");
        clean("subscripted input names", """
                function y = sub(A_$1, A_$2=10):
                   y = A_$1 - A_$2;
                fnend
                r = sub(A_$2=1, 5);""");
        clean("Tamil input names", """
                function y = \u0b95\u0bc2(\u0b85, \u0b86=2):
                   y = \u0b85 + \u0b86;
                fnend
                r = \u0b95\u0bc2(\u0b86=1, 3);""");
        clean("recursion with a named value", """
                function y = fact(n, acc=1):
                   if n <= 1:
                      y = acc;
                   else:
                      y = fact(n - 1, acc=acc * n);
                   iend
                fnend
                r = fact(5);""");
        clean("a list of variables from a call with names",
                "function [q, r] = divide(a, b=1):\n   q = a; r = b;\nfnend\n[q, r] = divide(b=5, 17);");
        fault("publish(x=1)", "x = 1;\npublish(x=1)", Rule.ASSIGNMENT, 1);
        fault("A[i=1]", "A = [1, 2]; i = 0;\ny = A[i=1];", Rule.ASSIGNMENT, 1);
        fault("[a=1]", "a = 1;\nx = [a=1];", Rule.ASSIGNMENT, 1);
        fault("(A = 5)", "A = 1;\nB = (A = 5);", Rule.ASSIGNMENT, 1);
        fault("f(a=)", G + "r = G(a=);", Rule.ASSIGNMENT, 3);
    }

    private static void callMatching() {
        fault("G()", G + "r = G();", Rule.CALL_MATCH, 3);
        fault("too many values", G + "r = G(1, 2, 3, 4);", Rule.CALL_MATCH, 3);
        fault("no input of that name", G + "r = G(d=1);", Rule.CALL_MATCH, 3);
        fault("an input given twice", G + "r = G(a=1, a=2);", Rule.CALL_MATCH, 3);
        fault("names leave too few inputs", G + "r = G(b=1, c=2, 3, 4);", Rule.CALL_MATCH, 3);
        fault("names on a built-in", "r = sqrt(x=4);", Rule.CALL_MATCH, 0);
        clean("plain values fill the open inputs from the left",
                """
                function F(A1, A2, A3, A4, A5):
                   publish(A1, A2, A3, A4, A5)
                fnend
                F(A2=10, A4=15, 1, 2, 3);
                F(1, A3=5, 2, 3, 4);
                F(10, 20, A1=5, 30, 40);
                F(A5=5, A4=4, A3=3, A2=2, A1=1);""");
        String p = "function y = P(a):\n   y = a;\nfnend\nfunction y = P(a, b=2):\n   y = a + b;\nfnend\n";
        clean("two versions, never ambiguous", p + "x = P(1); y = P(9, 9); z = P(a=9, b=1);");
        fault("no version fits", p + "x = P(1, 2, 3);", Rule.CALL_MATCH, 6);
        clean("constructor, method and names", SHAPE + "s = Shape(h=3, 2);\npublish(s.area(), s.area(scale=10))\n"
                + "s.grow(dh=5);");
        fault("method: no input of that name", SHAPE + "s = Shape(2);\na = s.area(size=2);", Rule.CALL_MATCH, 14);
        fault("constructor: missing input", SHAPE + "b = Shape(h=2);", Rule.CALL_MATCH, 13);
        String square = """
                class Square(Shape):
                   function base(side=2):
                      parent(side, h=side, label="square");
                   fnend
                csend
                """;
        clean("parent(...) with names", SHAPE + square + "q = Square(side=7);\npublish(q.area())");
        fault("parent(...) with an unknown name", SHAPE + square.replace("label=", "colour="), Rule.CALL_MATCH, 15);
        clean("an override is matched first", SHAPE + "class Big(Shape):\n   function A = area(scale=2):\n"
                + "      A = scale;\n   fnend\ncsend\nb = Big(1);\nr = b.area(scale=3);");
        clean("every input defaulted: Shape() and a bare call",
                """
                class S():
                   function base(w=1):
                      base.w = w;
                   fnend
                csend
                s = S();
                function y = hh(a=3):
                   y = a;
                fnend
                z = hh;
                hh;""");
        fault("names on a method of a number", "x = 5;\nx.area(scale=1);", Rule.CALL_MATCH, 1);
        clean("an unknown target stays silent", "f = @sin;\nr = f(x=1);\nu = unknown_fn(a=1);");
        clean("a reassigned object stays silent", SHAPE + "s = Shape(1);\ns = 5;\nr = s.area(size=1);");
    }

    private static void classMembers() {
        clean(".base and .info", SHAPE + "Shape.base\nFF = Shape(2, 3);\nFF.base\nShape.info\nI = Shape.info;\n"
                + "J = FF.info();");
        fault("a method named info", """
                class T():
                   function base():
                      base.x = 1;
                   fnend
                   function y = info():
                      y = 1;
                   fnend
                csend""", Rule.RESERVED_MEMBER, 4);
        fault("a field named info", "class T():\n   function base():\n      base.info = 1;\n   fnend\ncsend",
                Rule.RESERVED_MEMBER, 2);
        fault("a field named base", SHAPE + "FF = Shape(2);\nFF.base = 3;", Rule.RESERVED_MEMBER, 14);
        fault(".info with values", SHAPE + "z = Shape.info(1);", Rule.RESERVED_MEMBER, 13);
    }

    private static void complexNumbers() {
        clean("complex number", VARS + "D = 1+5i;");
        clean("imaginary forms", "Z = 5i; W = 2.5i; V = .5i; S = 1e-3i; T = 2.5-0.5i;");
        clean("complex in a call", VARS + "publish(1+5i, A*2i);");
        clean("i is still a loop variable", "for i = [1:3]:\n   publish(i, 2i);\nfend");
        clean("i1 and i2 are names", "i1 = 1; i2 = i1 + 3i;");
        fault("digit after the unit", "X = 5i2;", Rule.MISSING_SEPARATOR, 0);
        fault("space before the unit", "X = 5 i;", Rule.MISSING_SEPARATOR, 0);
        fault("bare i is the variable i", "X = 1+i;", Rule.UNDEFINED_NAME, 0);
        fault("5ix is not complex", "X = 5ix;", Rule.MISSING_SEPARATOR, 0);
    }

    private static void strings() {
        clean("Tamil text in a string", "\u0b95\u0bbf = \"\u0b9a\u0bcb\u0bb4 \u0ba8\u0bbe\u0b9f\u0bc1\";");
        clean("Greek text in a string", "M = '\u03bc and \u03c0';");
        clean("underscores in a string", "M = \"file__name ^^ x\";");
        clean("Malayalam ZWJ in a string", "M = \"\u0d28\u0d4d\u200d\";");
        clean("subscript on a name", "x_$2 = 5;");
        clean("_$ in a string is text", "M = \"x_$2\";");
        clean("_@ and $ in a string are text", "M = 'a_@bc costs $5';");
        fault("unicode superscript in a string", "M = \"mc\u00b2\";", Rule.STRING_SCRIPT, 0);
    }

    private static void scriptedNames() {
        clean("subscript", "A_$1 = 4; B = A_$1 + 2;");
        clean("subscript and superscript", "\u03bc_$i_@2 = 3.2; publish(\u03bc_$i_@2);");
        clean("plain names that used to clash", "A__j = 1; A_sj = 2; A_1 = 3; A1 = 4; A_$j = 5;");
        clean("Tamil name with subscript", "\u0b95\u0bbe_$1 = 0.1; x = \u0b95\u0bbe_$1 * 2;");
        clean("multi-letter subscript", "\u03c6_$max = 3.2; y = \u03c6_$max;");
        clean("in a function header",
                "function y_$1 = f_$a(x_$i):\n   y_$1 = x_$i * 2;\nfnend\nz = f_$a(3);");
        clean("as a loop variable", "for k_$1 = [1:3]:\n   publish(k_$1);\nfend");
        clean("indexed", "A_$1 = [1, 2; 3, 4]; x = A_$1[0, 1];");
        clean("raised to a power", "A_$1 = 2; y = A_$1^2;");
        clean("next to a complex number", "A_$1 = 2; z = 3i + A_$1;");
        clean("in a comment", "# A_$ and $x are fine here\nA = 1;");
        clean("commented-out code", "\\\\ A_$ = 5;\nA = 1;");
        clean("function reference", "f = @sin;");

        fault("empty subscript", "A_$ = 5;", Rule.STYLING, 0);
        fault("empty superscript", "A_$1_@ = 5;", Rule.STYLING, 0);
        fault("two subscripts", "A_$1_$2 = 5;", Rule.STYLING, 0);
        fault("superscript before subscript", "A_@2_$1 = 5;", Rule.STYLING, 0);
        fault("no name before the subscript", "_$1 = 5;", Rule.STYLING, 0);
        fault("Unicode subscript digit in a name", "A\u2081 = 5;", Rule.STYLING, 0);
        fault("Unicode superscript on a name", "x = 2; y = x\u00b2;", Rule.STYLING, 0);
        fault("Unicode superscript on a bracket", "A = 2; y = (A+1)\u00b2;", Rule.STYLING, 0);
        fault("zero-width joiner in a name", "A\u200d1 = 5;", Rule.STYLING, 0);
        fault("old hidden-marker name (one name, one error)", "S\u200d\u200d\u200dj\u200d\u200d\u200d = 45;", Rule.STYLING, 0);
        fault("Greek capital alpha", "\u0391 = 1;", Rule.STYLING, 0);
        fault("'$' inside a name", "A$b = 1;", Rule.STYLING, 0);
        fault("sensor signal reserved", "x = $Sensor1$;", Rule.STYLING, 0);
        fault("actuator signal reserved", "x = @Actuator1@;", Rule.STYLING, 0);
        fault("old brace subscript", "A_{1} = 2;", Rule.STYLING, 0);
        fault("old ^^ superscript", "x = 2; y = x^^2;", Rule.STYLING, 0);
        fault("old ^{} superscript", "x = 2; y = x^{2};", Rule.STYLING, 0);
        fault("reserved constant prefix", "con_x = 1;", Rule.STYLING, 0);
        fault("undefined: A_$2 is not A_$1", "A_$1 = 1; y = A_$2;", Rule.UNDEFINED_NAME, 0);
        fault("undefined: A is not A_$1", "A_$1 = 1; y = A;", Rule.UNDEFINED_NAME, 0);
    }

    private static void extendOperators() {
        clean("',=' adds columns", "M = [1, 2; 3, 4]\nM ,= [5; 6]");
        clean("';=' adds rows", "A = [1, 2, 3]\nA ;= [7, 8, 9]");
        clean("';=' with a trailing ';'", "A = []\nA ;= [1, 2];");
        clean("';=' in a loop body", "R = []\nfor i = [1:3]:\n   R ;= [i, i^2];\nfend");
        clean("',=' then a statement", "v = [1]; v ,= 2; publish(v);");
        clean("',=' inside a string is text", "s = \"a ,= b ;= c\";");
        clean("', =' with a space is not the operator", "x = [1 , 2];");
        fault("extend an undefined name", "U ,= 1", Rule.UNDEFINED_NAME, 0);
        fault("';=' on an undefined name", "U ;= 1", Rule.UNDEFINED_NAME, 0);
        fault("',=' on an index", "A = [1, 2; 3, 4]\nA[0] ,= 5", Rule.ASSIGNMENT, 1);
        fault("',=' on a field", "obj = 1\nobj.f ,= 5", Rule.ASSIGNMENT, 1);
        fault("',=' inside a matrix", "x = [1, 2]\ny = [x ,= 3]", Rule.ASSIGNMENT, 1);
        fault("',=' inside a call", "y = max([1, 2] ,= 3)", Rule.ASSIGNMENT, 0);
        reportedOnce("',=' inside a matrix is reported once", "x = [1, 2]\ny = [x ,= 3]", 1);
    }

    private static void textOperands() {
        clean("text + text joins", "x = \"a\" + \"b\";");
        clean("text == number is just false", "x = \"5\" == 5;");
        clean("a bool counts as a number", "x = 1 + (1 == 1); y = true + true;");
        clean("text compared with text", "x = \"a\" < \"b\";");
        clean("a name given text and a number is not judged", "s = \"5\"; s = 3; y = s + 1;");
        clean("text in a call is not an operand", "x = max(1, 2) + float(\"5\");");
        clean("named text value", "x = average([1, 2], axis=\"all\");");
        fault("text + number", "x = \"5\" + 1", Rule.TEXT_OPERAND, 0);
        fault("number + text", "x = 1 + \"5\"", Rule.TEXT_OPERAND, 0);
        fault("text * number", "x = \"5\" * 2", Rule.TEXT_OPERAND, 0);
        fault("text - text", "x = \"a\" - \"b\"", Rule.TEXT_OPERAND, 0);
        fault("negated text", "x = -\"5\"", Rule.TEXT_OPERAND, 0);
        fault("factorial of text", "x = \"5\"!", Rule.TEXT_OPERAND, 0);
        fault("text < number", "x = \"5\" < 5", Rule.TEXT_OPERAND, 0);
        fault("matrix + text", "x = [1, 2] + \"5\"", Rule.TEXT_OPERAND, 0);
        fault("dec2frac gives text", "x = dec2frac(0.5) + 1", Rule.TEXT_OPERAND, 0);
        fault("a name given only text", "s = \"5\"; y = s + 1;", Rule.TEXT_OPERAND, 0);
    }

    private static void timeValues() {
        clean("a valid timestamp", "t = timestamp(2024, 2, 29, 23, 59, 59);");
        clean("a valid ISO text", "t = to_timestamp(\"2026-10-28T14:30:00.5+05:30\");");
        clean("duration * number + duration", "d = hours(1) * 3 + minutes(2);");
        clean("duration / duration is a number", "x = 3 + hours(1) / minutes(1);");
        clean("timestamp + duration", "t = timestamp(2026, 1, 1) + days(2);");
        clean("a variable named days", "days = 5; y = days + 1;");
        clean("tic() and toc()", "tic(); e = toc();");
        fault("invalid month", "t = timestamp(2026, 13, 1)", Rule.TIME_VALUE, 0);
        fault("invalid day", "t = timestamp(2026, 2, 29)", Rule.TIME_VALUE, 0);
        fault("invalid hour", "t = timestamp(2026, 1, 1, 24, 0, 0)", Rule.TIME_VALUE, 0);
        fault("unparsable ISO text", "t = to_timestamp(\"2026-13-40\")", Rule.TIME_VALUE, 0);
        fault("timestamp + number", "t = timestamp(2026, 1, 1) + 5", Rule.TIME_VALUE, 0);
        fault("duration - number", "d = hours(1) - 3", Rule.TIME_VALUE, 0);
        fault("tic with a value", "tic(1)", Rule.TIME_VALUE, 0);
        fault("toc with a value", "e = toc(5)", Rule.TIME_VALUE, 0);
        fault("get_timestamp with a value", "t = get_timestamp(1)", Rule.TIME_VALUE, 0);
    }

    private static void variadicNamedValues() {
        String ab = "A = [1, 2]; B = [3, 4];\n";
        clean("concat with a named axis", ab + "C = concat(A, B, axis=1);");
        clean("concat with three plain values", ab + "C = concat(A, B, A);");
        clean("where with both named", "x = where([true], x=1, y=2);");
        fault("concat: unknown name", ab + "C = concat(A, B, axs=1);", Rule.CALL_MATCH, 1);
        fault("concat: no plain value", ab + "C = concat(axis=1);", Rule.CALL_MATCH, 1);
        fault("concat: plain value after a named one", ab + "C = concat(A, axis=1, B);", Rule.CALL_MATCH, 1);
        fault("choose: the inputs before '...' are never named", "x = choose(idx=1, [1], [2]);",
                Rule.CALL_MATCH, 0);
        fault("where: y without x", "x = where([true], y=2);", Rule.CALL_MATCH, 0);
    }

    /** read_ / load_ / save_ / io_ (docs/IO_Phase1_Frontend_Handover.md, IO_Phase2_3_Frontend_Handover.md). */
    private static void dataIo() {
        String a = "A = [1, 2; 3, 4];\n";
        clean("read_csv with named options", "T = read_csv(\"a.csv\", rows=[1:10], cols=[\"T\"], hdr=0);");
        clean("read_csv with two outputs", "[T, info] = read_csv(\"a.csv\", sheet=\"ABC\");");
        clean("load_csv, a method and chained fields",
                "D = load_csv(\"a.csv\");\nS = D.sheet(\"ABC\");\nc = D.ABC.cols;");
        clean("info(...) on a loaded MAT file is the built-in", "D = load_mat(\"a.mat\");\nprint(D.info(\"x\"))");
        clean("tab delimiter is not a path", "T = read_csv(\"a.tsv\", dlm=\"\\t\");");
        clean("save_csv with accepted values", a + "n = save_csv(\"o.csv\", A, quote=\"ALL\", compress=\"GZ\", "
                + "max_size=\"5 mb\");");
        clean("save_h5 with a level in range", a + "n = save_h5(\"o.h5\", A, level=9, chunks=[64, 64]);");
        clean("interval (0:1] and a handle @(x, y)", "y = (0:1];\nf = @(x, y) x + y;");
        clean("grouping bracket without a comma", "x = max((1), 2);");
        clean("own save_csv is not the built-in",
                "function n = save_csv(f, quote):\n   n = 1;\nfnend\nn = save_csv(\"o.csv\", quote=\"bad\");");
        fault("read_csv: unknown option", "T = read_csv(\"a.csv\", foo=1);", Rule.CALL_MATCH, 0);
        fault("save_csv: quote outside its choices", a + "n = save_csv(\"o.csv\", A, quote=\"bad\");",
                Rule.IO_OPTION, 1);
        fault("save_tsv: quote given in order", a
                + "n = save_tsv(\"o.tsv\", A, \"\", \"# [Sheet: {name}]\", \"\", \"\\t\", \"auto\", \"bad\");",
                Rule.IO_OPTION, 1);
        fault("save_csv: max_size that is not a size", a + "n = save_csv(\"o.csv\", A, max_size=\"5 megs\");",
                Rule.IO_OPTION, 1);
        fault("save_h5: level out of range", a + "n = save_h5(\"o.h5\", A, level=12);", Rule.IO_OPTION, 1);
        fault("save_xlsb is never built in", a + "n = save_xlsb(\"o.xlsb\", A);", Rule.IO_OPTION, 1);
        fault("dict literal", "d = {\"S1\": 1, \"S2\": 2};", Rule.FOREIGN_LITERAL, 0);
        fault("tuple", "s = (224, 224);", Rule.FOREIGN_LITERAL, 0);
        fault("bare range in a call", "T = read_csv(\"a.csv\", rows=2:500);", Rule.FOREIGN_LITERAL, 0);
        fault("@ after a dot", "D = load_xml(\"a.xml\");\ny = D.book.@id;", Rule.FOREIGN_LITERAL, 1);
        fault("path whose \\t is a tab", "T = read_csv(\"D:\\temp\\new.csv\");", Rule.PATH_ESCAPE, 0);
        clean("a path warning does not block a run", "T = read_csv(\"D:\\temp\\new.csv\");");
        clean("a path without \\t \\n \\r is fine", "T = read_csv(\"D:\\data\\x.csv\");");
        fault(".info(1) on a class of the file is still refused",
                "class P(a):\n   function base(a):\n      base.a = a;\n   fnend\ncsend\np = P(1);\ny = p.info(1);",
                Rule.RESERVED_MEMBER, 6);
    }

    /** A {@code '} directly after a value is the transpose; anywhere else it opens a string (lexer.cpp). */
    private static void transpose() {
        String c = "C = [1,2;3,4];\n";
        clean("transpose of a name", c + "y = C';");
        clean("transpose inside a call", c + "y = max(C', 1);");
        clean("transpose after a string", c + "y = max(\"ab\", C', 1);");
        clean("transpose after a string holding a quote (script_08)", c + "publish(\"C' is\", C', 1);");
        clean("transpose of a bracket", c + "y = (C*C)';");
        clean("transpose of an index", c + "y = C[0,:]';");
        clean("transpose of a matrix", "z = [1,2]';");
        clean("transpose twice", c + "y = C'';");
        clean("two transposes on a line", c + "y = C'*C';");
        clean("transposes in a matrix", c + "y = [C',C'];");
        clean("transpose of a number", "x = 5';");
        clean("transpose of a factorial", "x = 5!';");
        clean("transpose inside bars", c + "y = |C'|;");
        clean("transpose of bars", c + "y = |C|';");
        clean("transpose in a condition", c + "if C' == C':\n   publish(1);\niend");
        clean("a quote in the comment after a transpose", c + "y = C'; # it's a note");
        clean("transpose then a text", c + "publish(C', 'name');");
        clean("a text is still a text", "x = 'text';\npublish(x, 'a');");
        clean("an empty text is still a text", "x = '';");
        clean("a text after a keyword", "b = 'a' in'abc';");
        fault("a space makes it a quote", c + "y = C ';", Rule.STRING_LITERAL, 1);
        fault("an unclosed text", "x = 'abc;", Rule.STRING_LITERAL, 0);
        fault("a value after a transpose", c + "y = C' C;", Rule.MISSING_SEPARATOR, 1);
        fault("indexing a transpose", c + "y = C'[0,0];", Rule.MISSING_SEPARATOR, 1);
        fault("a path after a transpose is still read", c + "T = read_csv(\"D:\\temp\\new.csv\", C');",
                Rule.PATH_ESCAPE, 1);
    }

    /** {@code dict(keys: values)} is nc.exe's own form; only dict's ':' separates values. */
    private static void dictColon() {
        String lists = "En = [\"Name\", \"Age\"];\nEv = [\"Kalam\", 63];\n";
        clean("dict(En:Ev)", lists + "C = dict(En:Ev);\nA1 = C.keys();\npublish(A1);");
        clean("dict in another letter case", lists + "C = DICT(En:Ev);");
        clean("dict with a space before the bracket", lists + "C = dict (En : Ev);");
        clean("dict of literal lists", "C = dict([\"a\", \"b\"]:[1, 2]);");
        clean("dict of ranges", "C = dict([1:3]:[4:6]);");
        clean("dict with a comma still", lists + "C = dict(En, Ev);");
        clean("empty dict", "A = dict();");
        clean("dict(En:Ev) inside another call", lists + "publish(dict(En:Ev));");
        fault("':' in another call", lists + "x = sum(En:Ev);", Rule.FOREIGN_LITERAL, 2);
        fault("':' in a call inside dict", lists + "C = dict(sum(En:Ev):Ev);", Rule.FOREIGN_LITERAL, 2);
        fault("':' in a method named dict", lists + "x = En.dict(En:Ev);", Rule.FOREIGN_LITERAL, 2);
        fault("':' in a name ending in dict", lists + "x = mydict(En:Ev);", Rule.FOREIGN_LITERAL, 2);
    }

    /** docs/Backend_Changes_2026-10-30.md, section 3. */
    private static void backendChanges20261030() {
        String a = "A = [1, 2, 3];\nx = 2;\n";
        clean("if x in A", a + "if x in A:\n   publish(x);\niend");
        clean("if x not in A", a + "if x not in A:\n   publish(x);\niend");
        clean("b = x in A", a + "b = x in A;");
        clean("publish(x not in A)", a + "publish(x not in A);");
        clean("for k in A still loops", a + "for k in A:\n   publish(k);\nfend");
        clean("in on a sum", a + "b = 3+1 in A;");
        clean("in after &&", a + "b = x > 1 && x in A;");
        clean("not as a variable", "not = 5;");
        clean("not as a variable, read back", "not = 5;\ny = not + 1;");
        clean("not with a space before the bracket", "X = 1 && not (1 == 2) || true;");
        faultSays("not between two values", "x = 5 not 6;", Rule.MISSING_SEPARATOR, 0,
                "unexpected 'not' - two values cannot sit next to each other; an operator "
                        + "(+, -, *, /, ^, ...) or ';' is missing after '5'");
        faultSays("in as a variable", "in = 5;", Rule.ASSIGNMENT, 0,
                "'in' is a keyword and cannot be used as a variable name");
        reportedOnce("in as a variable is one message", "in = 5;", 0);
        clean("uc_ constants", "x = uc_pi + uc_gravity + uc_gasconst + uc_avogadro + uc_planck + uc_hbar"
                + " + uc_gravitational + uc_stefanboltzmann + uc_coulomb + uc_electronmass + uc_protonmass"
                + " + uc_neutronmass + uc_molarmass + uc_elementarycharge + uc_faraday + uc_speedoflight"
                + " + uc_boltzmann + uc_vacuumpermittivity + uc_vacuumpermeability + uc_finestructure"
                + " + uc_rydberg + uc_bohrradius + uc_hartreeenergy + uc_magneticfluxquantum;");
        absent("constant symbols of older scripts are not names", "x = 𝝅 + 𝑵ₐ + 𝒌ₑ + 𝑹∞ + ℏ;", Rule.STYLING, 0);
        clean("arc* functions", "x = arcsin(0.5) + arccos(0.5) + arctan(1) + arccosec(2) + arcsec(2) + arccot(1);");
        clean("long matrix names", "M = [1,2;3,4];\nP = pseudo_inverse(M);\nQ = pseudo_inverse(A=M);\nR = conjugate(M);");
        clean("corrected matrix names", "M = [1,2;3,4];\nP = inv(M);\nQ = had_prod(M, M);");
    }

    // ─────────────────────────────────────────────────────────────────────
    // Assertions
    // ─────────────────────────────────────────────────────────────────────

    private static void clean(String name, String code) {
        clean(name, code, CheckContext.NONE);
    }

    private static void clean(String name, String code, CheckContext context) {
        ErrorChecker.LineIssues issues = ErrorChecker.lineIssues(code, context);
        if (issues.allErrorLines().isEmpty()) {
            pass(name);
        } else {
            fail(name, "expected no errors, got " + describe(code, context));
        }
    }

    private static void fault(String name, String code, Rule rule, int line) {
        fault(name, code, rule, line, CheckContext.NONE);
    }

    private static void fault(String name, String code, Rule rule, int line, CheckContext context) {
        Map<Rule, String> onLine = ErrorChecker.lineIssues(code, context).findings(line);
        if (onLine.containsKey(rule)) {
            pass(name + "  ->  " + onLine.get(rule));
        } else {
            fail(name, "expected " + rule + " on line " + line + ", got " + describe(code, context));
        }
    }

    /** The rule reports the line in exactly these words: nc.exe's. */
    private static void faultSays(String name, String code, Rule rule, int line, String message) {
        String said = ErrorChecker.lineIssues(code, CheckContext.NONE).findings(line).get(rule);
        if (message.equals(said)) {
            pass(name + "  ->  " + said);
        } else {
            fail(name, "expected \"" + message + "\", got " + describe(code, CheckContext.NONE));
        }
    }

    /** The line carries exactly one classified issue with exactly one message. */
    private static void reportedOnce(String name, String code, int line) {
        List<ErrorClassifier.Issue> issues = ErrorClassifier.classify(code).issuesOn(line);
        if (issues.size() == 1 && issues.get(0).messages().size() == 1) {
            pass(name + "  ->  " + issues.get(0).message());
        } else {
            fail(name, "expected one message on line " + line + ", got " + describe(code, CheckContext.NONE));
        }
    }

    /** The rule must NOT report the line (other rules may). */
    private static void absent(String name, String code, Rule rule, int line) {
        Map<Rule, String> onLine = ErrorChecker.lineIssues(code, CheckContext.NONE).findings(line);
        if (!onLine.containsKey(rule)) {
            pass(name);
        } else {
            fail(name, "expected no " + rule + " on line " + line + ", got " + onLine.get(rule));
        }
    }

    private static String describe(String code, CheckContext context) {
        StringBuilder text = new StringBuilder();
        for (ErrorClassifier.Issue issue : ErrorClassifier.classify(code, context).issues()) {
            text.append("\n      line ").append(issue.line()).append(' ')
                    .append(issue.category().title()).append(": ").append(issue.message());
        }
        return text.length() == 0 ? "nothing" : text.toString();
    }

    private static void pass(String name) {
        passed++;
        System.out.println("  ok   " + name);
    }

    private static void fail(String name, String why) {
        FAILURES.add(name + ": " + why);
    }
}
