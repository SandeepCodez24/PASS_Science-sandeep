package language.syntax.syntax_checker;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The single entry point the editor, the status bar and the runner all use.
 *
 * <h3>What changed</h3>
 * Every analyzer now shares one {@link SourceModel}, so a comment, a string
 * literal and a {@code ~~} continuation mean the same thing to all of them.
 * The subscript/superscript pass, which used to be the worst offender -- it
 * read raw lines, so it saw comments and string bodies as live code -- is
 * rewritten here:
 *
 * <ul>
 * <li><b>It runs on masked text.</b> This is what fixes
 * {@code publish("sqrt(144) =", sqrt(144));}. The {@code functionAssignment}
 * pattern matched {@code publish(} then took {@code "sqrt(144} as the argument
 * list, closed it on the literal's own {@code )}, and found the {@code =} from
 * inside the string right after it -- so the line read as "a function call
 * being assigned to". With the literal blanked there is no inner bracket and no
 * {@code =}, and the line is correctly silent.</li>
 * <li><b>{@code isFunctionNameInCode} searches the masked document.</b> A name
 * that appears only in a comment no longer counts as a definition.</li>
 * <li><b>Counting and line-finding share one pass.</b> They were two
 * near-identical hundred-line blocks that had already drifted apart -- the
 * counter added several errors per line, the line finder stopped at the first.
 * One pass now produces both, so the number in the status bar and the dots in
 * the gutter cannot disagree.</li>
 * </ul>
 */
public class ErrorChecker {

    public static final class ErrorReport {
        private final int docstringErrors;
        private final int undefinedVariableErrors;
        private final int incompleteLineSyntaxErrors;
        private final int invalidExponentErrors;
        private final int subscriptSuperscriptErrors;
        private final int indentationErrors;

        private ErrorReport(int docstringErrors, int undefinedVariableErrors, int incompleteLineSyntaxErrors,
                int invalidExponentErrors, int subscriptSuperscriptErrors, int indentationErrors) {
            this.docstringErrors = docstringErrors;
            this.undefinedVariableErrors = undefinedVariableErrors;
            this.incompleteLineSyntaxErrors = incompleteLineSyntaxErrors;
            this.invalidExponentErrors = invalidExponentErrors;
            this.subscriptSuperscriptErrors = subscriptSuperscriptErrors;
            this.indentationErrors = indentationErrors;
        }

        /** Lines that leave a string literal open. Kept under the old name for callers. */
        public int getDocstringErrors() {
            return docstringErrors;
        }

        public int getUnterminatedStringErrors() {
            return docstringErrors;
        }

        public int getUndefinedVariableErrors() {
            return undefinedVariableErrors;
        }

        public int getIncompleteLineSyntaxErrors() {
            return incompleteLineSyntaxErrors;
        }

        public int getInvalidExponentErrors() {
            return invalidExponentErrors;
        }

        public int getSubscriptSuperscriptErrors() {
            return subscriptSuperscriptErrors;
        }

        public int getIndentationErrors() {
            return indentationErrors;
        }

        public int getWarningCount() {
            return docstringErrors;
        }

        public int getErrorCount() {
            return undefinedVariableErrors + incompleteLineSyntaxErrors + invalidExponentErrors
                    + subscriptSuperscriptErrors + indentationErrors;
        }

        public int getTotalErrors() {
            return getErrorCount() + getWarningCount();
        }

        public String toDisplayText() {
            return " Errors: " + getErrorCount() + "  Warnings: " + getWarningCount() + " ";
        }

        public String toTooltipText() {
            return "Errors: " + getErrorCount()
                    + "\nWarnings: " + getWarningCount()
                    + "\n\nUnterminated string literals: " + docstringErrors
                    + "\nUndefined variable errors: " + undefinedVariableErrors
                    + "\nIncomplete line syntax errors: " + incompleteLineSyntaxErrors
                    + "\nInvalid exponent syntax errors: " + invalidExponentErrors
                    + "\nSubscript/superscript errors: " + subscriptSuperscriptErrors
                    + "\nIndentation errors: " + indentationErrors;
        }
    }

    /**
     * Every per-line issue set for one document, computed once.
     *
     * <h3>Why this exists</h3>
     * The gutter factory builds one cell per visible line and each cell used to
     * ask for six different error sets, so a 200-line file re-ran the whole
     * analysis 1,200 times per keystroke. Ask for this bundle once and query it
     * per line instead. The result is cached against the text that produced it,
     * so repeated calls with the same text are free.
     */
    public static final class LineIssues {
        private final Set<Integer> undefinedVariable;
        private final Set<Integer> incompleteLine;
        private final Set<Integer> invalidExponent;
        private final Set<Integer> subscriptSuperscript;
        private final Set<Integer> indentation;
        private final Set<Integer> unterminatedString;

        private LineIssues(Set<Integer> undefinedVariable, Set<Integer> incompleteLine,
                Set<Integer> invalidExponent, Set<Integer> subscriptSuperscript,
                Set<Integer> indentation, Set<Integer> unterminatedString) {
            this.undefinedVariable = undefinedVariable;
            this.incompleteLine = incompleteLine;
            this.invalidExponent = invalidExponent;
            this.subscriptSuperscript = subscriptSuperscript;
            this.indentation = indentation;
            this.unterminatedString = unterminatedString;
        }

        public boolean hasUndefinedVariable(int line) {
            return undefinedVariable.contains(line);
        }

        public boolean hasIncompleteLine(int line) {
            return incompleteLine.contains(line);
        }

        public boolean hasInvalidExponent(int line) {
            return invalidExponent.contains(line);
        }

        public boolean hasSubscriptSuperscript(int line) {
            return subscriptSuperscript.contains(line);
        }

        public boolean hasIndentation(int line) {
            return indentation.contains(line);
        }

        public boolean hasUnterminatedString(int line) {
            return unterminatedString.contains(line);
        }

        /** True when the line should carry a red dot. */
        public boolean isErrorLine(int line) {
            return hasUndefinedVariable(line) || hasIncompleteLine(line) || hasInvalidExponent(line)
                    || hasSubscriptSuperscript(line) || hasIndentation(line);
        }

        /** True when the line should carry an amber dot and no red one. */
        public boolean isWarningLine(int line) {
            return !isErrorLine(line) && hasUnterminatedString(line);
        }

        /** Every line carrying at least one error, for paragraph styling. */
        public Set<Integer> allErrorLines() {
            Set<Integer> all = new HashSet<>(undefinedVariable);
            all.addAll(incompleteLine);
            all.addAll(invalidExponent);
            all.addAll(subscriptSuperscript);
            all.addAll(indentation);
            return all;
        }
    }

    private static final Object ISSUE_CACHE_LOCK = new Object();
    private static String cachedIssueSource;
    private static LineIssues cachedIssues;

    /**
     * @param code raw editor text
     * @return every per-line issue set, computed once and cached
     */
    public static LineIssues lineIssues(String code) {
        String key = code == null ? "" : code;
        synchronized (ISSUE_CACHE_LOCK) {
            if (cachedIssues != null && key.equals(cachedIssueSource)) {
                return cachedIssues;
            }
        }

        SourceModel model = SourceModel.of(key);
        LineIssues issues = new LineIssues(
                UndefinedVariableAnalyzer.analyze(model).errorLines,
                SyntaxLineAnalyzer.findIncompleteLineSyntaxErrorLines(model),
                ExponentSyntaxAnalyzer.findInvalidExponentErrorLines(model),
                new HashSet<>(scriptStylingErrors(model).keySet()),
                IndentationSyntaxAnalyzer.analyze(model).errorLines,
                DocstringErrorAnalyzer.findUnterminatedStringLines(model));

        synchronized (ISSUE_CACHE_LOCK) {
            cachedIssueSource = key;
            cachedIssues = issues;
        }
        return issues;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Subscript / superscript styling rules
    // ─────────────────────────────────────────────────────────────────────────

    /** Identifier shape that tolerates the hidden styling markers inside a name. */
    private static final String STYLED_IDENTIFIER = "[A-Za-z_\\u200C\\u200D][A-Za-z0-9_\\u200C\\u200D]*";

    private static final Pattern BRACE_SUB =
            Pattern.compile("\\b(" + STYLED_IDENTIFIER + ")\\s*_\\{([^}]*)\\}");
    private static final Pattern BRACE_SUP =
            Pattern.compile("\\b(" + STYLED_IDENTIFIER + ")\\s*\\^\\{([^}]*)\\}");
    private static final Pattern CALL_BRACE_SUB =
            Pattern.compile("\\b(" + STYLED_IDENTIFIER + ")\\s*\\([^)]*\\)\\s*_\\{([^}]*)\\}");
    private static final Pattern CALL_BRACE_SUP =
            Pattern.compile("\\b(" + STYLED_IDENTIFIER + ")\\s*\\([^)]*\\)\\s*\\^\\{([^}]*)\\}");
    private static final Pattern FUNCTION_ASSIGNMENT = Pattern.compile(
            "\\b(" + STYLED_IDENTIFIER + ")\\s*\\([^)]*\\)"
                    + "(?:\\s*(?:\\u200D{1,3}[^\\u200D\\n\\r=]+\\u200D{1,3}"
                    + "|\\u200C{3}[^\\u200C\\n\\r=]+\\u200C{3}))?\\s*=");

    // Live marker patterns (ZWJ/U+200D for subscript, ZWNJ/U+200C for superscript).
    private static final Pattern LIVE_SUB = Pattern.compile(
            "\\b(" + STYLED_IDENTIFIER + ")(?:\\u200D{1,3}([^\\u200D\\n\\r=]+)\\u200D{1,3})");
    private static final Pattern LIVE_SUP = Pattern.compile(
            "\\b(" + STYLED_IDENTIFIER + ")(?:\\u200C{3}([^\\u200C\\n\\r=]+)\\u200C{3})");
    private static final Pattern CALL_LIVE_SUB = Pattern.compile(
            "\\b(" + STYLED_IDENTIFIER + ")\\s*\\([^)]*\\)(?:\\u200D{1,3}([^\\u200D\\n\\r=]+)\\u200D{1,3})");
    private static final Pattern CALL_LIVE_SUP = Pattern.compile(
            "\\b(" + STYLED_IDENTIFIER + ")\\s*\\([^)]*\\)(?:\\u200C{3}([^\\u200C\\n\\r=]+)\\u200C{3})");

    private static final Pattern FUNCTION_CALL_SHAPE =
            Pattern.compile("\\b[A-Za-z_\\u200C\\u200D][A-Za-z0-9_\\u200C\\u200D]*\\s*\\(");

    // ─────────────────────────────────────────────────────────────────────────
    // Public API
    // ─────────────────────────────────────────────────────────────────────────

    public static int countErrors(String code) {
        return analyzeErrors(code).getTotalErrors();
    }

    /**
     * Runs every check once, against one shared cleaned view of the file.
     *
     * @param code raw editor text
     * @return the full report
     */
    public static ErrorReport analyzeErrors(String code) {
        SourceModel model = SourceModel.of(code);

        int docstringErrors = DocstringErrorAnalyzer.findUnterminatedStringLines(model).size();
        int undefinedVariableErrors = UndefinedVariableAnalyzer.analyze(model).errorCount;
        int incompleteLineSyntaxErrors = SyntaxLineAnalyzer.findIncompleteLineSyntaxErrorLines(model).size();
        int invalidExponentErrors = ExponentSyntaxAnalyzer.findInvalidExponentErrorLines(model).size();
        int subscriptSuperscriptErrors = totalOf(scriptStylingErrors(model));
        int indentationErrors = IndentationSyntaxAnalyzer.analyze(model).errorCount;

        return new ErrorReport(docstringErrors, undefinedVariableErrors, incompleteLineSyntaxErrors,
                invalidExponentErrors, subscriptSuperscriptErrors, indentationErrors);
    }

    public static int countDocstringErrors(String code) {
        return DocstringErrorAnalyzer.countDocstringErrors(code);
    }

    public static Set<Integer> findDocstringErrorLines(String code) {
        return DocstringErrorAnalyzer.findDocstringErrorLines(code);
    }

    public static int countUndefinedVariableErrors(String code) {
        return UndefinedVariableAnalyzer.analyze(SourceModel.of(code)).errorCount;
    }

    public static Set<Integer> findUndefinedVariableErrorLines(String code) {
        return UndefinedVariableAnalyzer.analyze(SourceModel.of(code)).errorLines;
    }

    public static int countIncompleteLineSyntaxErrors(String code) {
        return findIncompleteLineSyntaxErrorLines(code).size();
    }

    public static Set<Integer> findIncompleteLineSyntaxErrorLines(String code) {
        return SyntaxLineAnalyzer.findIncompleteLineSyntaxErrorLines(SourceModel.of(code));
    }

    public static int countInvalidExponentErrors(String code) {
        return findInvalidExponentErrorLines(code).size();
    }

    public static Set<Integer> findInvalidExponentErrorLines(String code) {
        return ExponentSyntaxAnalyzer.findInvalidExponentErrorLines(SourceModel.of(code));
    }

    public static Set<Integer> findErrorLines(String code) {
        return SyntaxLineAnalyzer.findErrorLines(SourceModel.of(code));
    }

    /**
     * Counts only line-level errors from statements completed with {@code ;}.
     *
     * @param code raw editor text
     * @return the count
     */
    public static int countErrorsAfterSemicolon(String code) {
        return findErrorLinesAfterSemicolon(code).size();
    }

    /**
     * @param code raw editor text
     * @return zero-based indices of unbalanced {@code ;}-terminated lines
     */
    public static Set<Integer> findErrorLinesAfterSemicolon(String code) {
        return SyntaxLineAnalyzer.findErrorLinesAfterSemicolon(SourceModel.of(code));
    }

    public static int countIndentationErrors(String code) {
        return IndentationSyntaxAnalyzer.analyze(SourceModel.of(code)).errorCount;
    }

    public static Set<Integer> findIndentationErrorLines(String code) {
        return IndentationSyntaxAnalyzer.analyze(SourceModel.of(code)).errorLines;
    }

    public static int countSubscriptSuperscriptErrors(String code) {
        return totalOf(scriptStylingErrors(SourceModel.of(code)));
    }

    public static Set<Integer> findSubscriptSuperscriptErrorLines(String code) {
        return new HashSet<>(scriptStylingErrors(SourceModel.of(code)).keySet());
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Internals
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Detects invalid uses of subscript/superscript styling:
     * <ul>
     * <li>a function name used as the base of a styled group ({@code sin_{1}})</li>
     * <li>a function call carrying a styled suffix ({@code f(x)_{1}})</li>
     * <li>a function call on the left of an assignment ({@code f(x) = 3})</li>
     * <li>a function call inside styled content ({@code a_{sin(x)}})</li>
     * <li>an empty styled group ({@code a_{}} or {@code a^{}})</li>
     * </ul>
     *
     * @param model the cleaned document
     * @return line index to number of offences on that line
     */
    private static Map<Integer, Integer> scriptStylingErrors(SourceModel model) {
        Map<Integer, Integer> perLine = new HashMap<>();
        String document = model.maskedDocument();

        for (SourceModel.Line sourceLine : model.lines()) {
            if (sourceLine.isAbsorbed() || sourceLine.isBlank()) {
                continue;
            }

            String line = sourceLine.masked();
            int count = 0;

            // At most one per line, matching the original behaviour.
            if (FUNCTION_ASSIGNMENT.matcher(line).find()) {
                count++;
            }

            count += countMatches(CALL_BRACE_SUB, line);
            count += countMatches(CALL_BRACE_SUP, line);
            count += countMatches(CALL_LIVE_SUB, line);
            count += countMatches(CALL_LIVE_SUP, line);

            count += countStyledGroupFaults(BRACE_SUB, line, document);
            count += countStyledGroupFaults(BRACE_SUP, line, document);
            count += countStyledGroupFaults(LIVE_SUB, line, document);
            count += countStyledGroupFaults(LIVE_SUP, line, document);

            if (count > 0) {
                perLine.put(sourceLine.index(), count);
            }
        }

        return perLine;
    }

    private static int countMatches(Pattern pattern, String line) {
        Matcher matcher = pattern.matcher(line);
        int count = 0;
        while (matcher.find()) {
            count++;
        }
        return count;
    }

    private static int countStyledGroupFaults(Pattern pattern, String line, String document) {
        Matcher matcher = pattern.matcher(line);
        int count = 0;
        while (matcher.find()) {
            String base = matcher.group(1);
            String content = matcher.group(2);
            if (isFunctionNameInCode(document, base)) {
                count++;
            }
            if (content == null || content.trim().isEmpty()) {
                count++;
            }
            if (containsFunctionCall(content)) {
                count++;
            }
        }
        return count;
    }

    /**
     * True when {@code name} is called anywhere in the file. The document passed
     * in is masked, so an appearance in a comment or inside a string literal
     * does not count.
     */
    private static boolean isFunctionNameInCode(String document, String name) {
        if (document == null || name == null || name.isEmpty()) {
            return false;
        }
        try {
            Pattern pattern = Pattern.compile("\\b" + Pattern.quote(name) + "\\s*\\(");
            return pattern.matcher(document).find();
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean containsFunctionCall(String text) {
        return text != null && !text.isEmpty() && FUNCTION_CALL_SHAPE.matcher(text).find();
    }

    private static int totalOf(Map<Integer, Integer> perLine) {
        int total = 0;
        for (int value : perLine.values()) {
            total += value;
        }
        return total;
    }
}
