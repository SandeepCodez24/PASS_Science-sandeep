package language.syntax.syntax_checker;

import java.util.Set;
import java.util.regex.Matcher;

public class ErrorChecker {

    public static final class ErrorReport {
        private final int docstringErrors;
        private final int undefinedVariableErrors;
        private final int incompleteLineSyntaxErrors;
        private final int invalidExponentErrors;
        private final int subscriptSuperscriptErrors;

        private ErrorReport(int docstringErrors, int undefinedVariableErrors, int incompleteLineSyntaxErrors,
                int invalidExponentErrors, int subscriptSuperscriptErrors) {
            this.docstringErrors = docstringErrors;
            this.undefinedVariableErrors = undefinedVariableErrors;
            this.incompleteLineSyntaxErrors = incompleteLineSyntaxErrors;
            this.invalidExponentErrors = invalidExponentErrors;
            this.subscriptSuperscriptErrors = subscriptSuperscriptErrors;
        }

        public int getDocstringErrors() {
            return docstringErrors;
        }

        public int getUndefinedVariableErrors() {
            return undefinedVariableErrors;
        }

        public int getIncompleteLineSyntaxErrors() {
            return incompleteLineSyntaxErrors;
        }

        public int getInvalidExponentErrors() {
            return invalidExponentErrors;
        }

        public int getSubscriptSuperscriptErrors() {
            return subscriptSuperscriptErrors;
        }

        public int getWarningCount() {
            return docstringErrors;
        }

        public int getErrorCount() {
            return undefinedVariableErrors + incompleteLineSyntaxErrors + invalidExponentErrors + subscriptSuperscriptErrors;
        }

        public int getTotalErrors() {
            return getErrorCount() + getWarningCount();
        }

        public String toDisplayText() {
            return " Errors: " + getErrorCount() + "  Warnings: " + getWarningCount() + " ";
        }

        public String toTooltipText() {
            return "Errors: " + getErrorCount()
                    + "\nWarnings: " + getWarningCount()
                    + "\n\nDocstring warnings: " + docstringErrors
                    + "\nUndefined variable errors: " + undefinedVariableErrors
                    + "\nIncomplete line syntax errors: " + incompleteLineSyntaxErrors
                    + "\nInvalid exponent syntax errors: " + invalidExponentErrors
                    + "\nSubscript/superscript errors: " + subscriptSuperscriptErrors;
        }
    }

    public static int countErrors(String code) {
        return analyzeErrors(code).getTotalErrors();
    }

    public static ErrorReport analyzeErrors(String code) {
        String safeCode = code == null ? "" : code;
        int docstringErrors = countDocstringErrors(safeCode);
        int undefinedVariableErrors = countUndefinedVariableErrors(safeCode);
        int incompleteLineSyntaxErrors = countIncompleteLineSyntaxErrors(safeCode);
        int invalidExponentErrors = countInvalidExponentErrors(safeCode);
        int subscriptSuperscriptErrors = countSubscriptSuperscriptErrors(safeCode);
        return new ErrorReport(docstringErrors, undefinedVariableErrors, incompleteLineSyntaxErrors, invalidExponentErrors, subscriptSuperscriptErrors);
    }

    /**
     * Detect invalid uses of subscript/superscript styling related to functions.
     * Rules added:
     *  - Using a function name as the base for a subscript/superscript (e.g. sin_{1})
     *  - Using function calls inside subscript/superscript content (e.g. a_{sin(x)})
     *  - Empty subscript/superscript groups (e.g. a_{} or a^{})
     * Returns the total count of offending occurrences.
     */
    private static int countSubscriptSuperscriptErrors(String code) {
        if (code == null || code.isEmpty()) return 0;

        int errors = 0;
        String[] lines = code.split("\\R", -1);

        // Identifier pattern must allow hidden styling markers inside the function name.
        String styledIdentifier = "[A-Za-z_\\u200C\\u200D][A-Za-z0-9_\\u200C\\u200D]*";

        // Patterns to find styled groups: base_{...} and base^{...}
        java.util.regex.Pattern braceSub = java.util.regex.Pattern.compile("\\b(" + styledIdentifier + ")\\s*_\\{([^}]*)\\}");
        java.util.regex.Pattern braceSup = java.util.regex.Pattern.compile("\\b(" + styledIdentifier + ")\\s*\\^\\{([^}]*)\\}");
        java.util.regex.Pattern callBraceSub = java.util.regex.Pattern.compile("\\b(" + styledIdentifier + ")\\s*\\([^)]*\\)\\s*_\\{([^}]*)\\}");
        java.util.regex.Pattern callBraceSup = java.util.regex.Pattern.compile("\\b(" + styledIdentifier + ")\\s*\\([^)]*\\)\\s*\\^\\{([^}]*)\\}");
        java.util.regex.Pattern functionAssignment = java.util.regex.Pattern.compile("\\b(" + styledIdentifier + ")\\s*\\([^)]*\\)(?:\\s*(?:\\u200D{1,3}[^\\u200D\\n\\r=]+\\u200D{1,3}|\\u200C{3}[^\\u200C\\n\\r=]+\\u200C{3}))?\\s*=");

        // Live marker patterns (ZWJ/U+200D for subscript, ZWNJ/U+200C for superscript)
        java.util.regex.Pattern liveSub = java.util.regex.Pattern.compile("\\b(" + styledIdentifier + ")(?:\\u200D{1,3}([^\\u200D\\n\\r=]+)\\u200D{1,3})");
        java.util.regex.Pattern liveSup = java.util.regex.Pattern.compile("\\b(" + styledIdentifier + ")(?:\\u200C{3}([^\\u200C\\n\\r=]+)\\u200C{3})");
        java.util.regex.Pattern callLiveSub = java.util.regex.Pattern.compile("\\b(" + styledIdentifier + ")\\s*\\([^)]*\\)(?:\\u200D{1,3}([^\\u200D\\n\\r=]+)\\u200D{1,3})");
        java.util.regex.Pattern callLiveSup = java.util.regex.Pattern.compile("\\b(" + styledIdentifier + ")\\s*\\([^)]*\\)(?:\\u200C{3}([^\\u200C\\n\\r=]+)\\u200C{3})");

        for (String line : lines) {
            String l = line == null ? "" : line;

            Matcher m = functionAssignment.matcher(l);
            while (m.find()) {
                errors++;
                break;
            }

            m = callBraceSub.matcher(l);
            while (m.find()) {
                // Any function call followed by a subscript group is invalid.
                errors++;
            }

            m = callBraceSup.matcher(l);
            while (m.find()) {
                // Any function call followed by a superscript group is invalid.
                errors++;
            }

            m = braceSub.matcher(l);
            while (m.find()) {
                String base = m.group(1);
                String content = m.group(2);
                if (isFunctionNameInCode(code, base)) errors++;
                if (content == null || content.trim().isEmpty()) errors++;
                if (containsFunctionCall(content)) errors++;
            }

            m = braceSup.matcher(l);
            while (m.find()) {
                String base = m.group(1);
                String content = m.group(2);
                if (isFunctionNameInCode(code, base)) errors++;
                if (content == null || content.trim().isEmpty()) errors++;
                if (containsFunctionCall(content)) errors++;
            }

            m = callLiveSub.matcher(l);
            while (m.find()) {
                // Any function call with styled subscript suffix is invalid.
                errors++;
            }

            m = callLiveSup.matcher(l);
            while (m.find()) {
                // Any function call with styled superscript suffix is invalid.
                errors++;
            }

            m = liveSub.matcher(l);
            while (m.find()) {
                String base = m.group(1);
                String content = m.group(2);
                if (isFunctionNameInCode(code, base)) errors++;
                if (content == null || content.trim().isEmpty()) errors++;
                if (containsFunctionCall(content)) errors++;
            }

            m = liveSup.matcher(l);
            while (m.find()) {
                String base = m.group(1);
                String content = m.group(2);
                if (isFunctionNameInCode(code, base)) errors++;
                if (content == null || content.trim().isEmpty()) errors++;
                if (containsFunctionCall(content)) errors++;
            }
        }

        return errors;
    }

    private static boolean isFunctionNameInCode(String code, String name) {
        if (code == null || name == null || name.isEmpty()) return false;
        try {
            java.util.regex.Pattern p = java.util.regex.Pattern.compile("\\b" + java.util.regex.Pattern.quote(name) + "\\s*\\(");
            return p.matcher(code).find();
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean containsFunctionCall(String text) {
        if (text == null || text.isEmpty()) return false;
        java.util.regex.Pattern p = java.util.regex.Pattern.compile("\\b[A-Za-z_\\u200C\\u200D][A-Za-z0-9_\\u200C\\u200D]*\\s*\\(");
        return p.matcher(text).find();
    }

    public static java.util.Set<Integer> findSubscriptSuperscriptErrorLines(String code) {
        java.util.Set<Integer> linesWithErrors = new java.util.HashSet<>();
        if (code == null || code.isEmpty()) return linesWithErrors;

        String[] lines = code.split("\\R", -1);
        String styledIdentifier = "[A-Za-z_\\u200C\\u200D][A-Za-z0-9_\\u200C\\u200D]*";
        java.util.regex.Pattern braceSub = java.util.regex.Pattern.compile("\\b(" + styledIdentifier + ")\\s*_\\{([^}]*)\\}");
        java.util.regex.Pattern braceSup = java.util.regex.Pattern.compile("\\b(" + styledIdentifier + ")\\s*\\^\\{([^}]*)\\}");
        java.util.regex.Pattern callBraceSub = java.util.regex.Pattern.compile("\\b(" + styledIdentifier + ")\\s*\\([^)]*\\)\\s*_\\{([^}]*)\\}");
        java.util.regex.Pattern callBraceSup = java.util.regex.Pattern.compile("\\b(" + styledIdentifier + ")\\s*\\([^)]*\\)\\s*\\^\\{([^}]*)\\}");
        java.util.regex.Pattern functionAssignment = java.util.regex.Pattern.compile("\\b(" + styledIdentifier + ")\\s*\\([^)]*\\)(?:\\s*(?:\\u200D{1,3}[^\\u200D\\n\\r=]+\\u200D{1,3}|\\u200C{3}[^\\u200C\\n\\r=]+\\u200C{3}))?\\s*=");
        java.util.regex.Pattern liveSub = java.util.regex.Pattern.compile("\\b(" + styledIdentifier + ")(?:\\u200D{1,3}([^\\u200D\\n\\r=]+)\\u200D{1,3})");
        java.util.regex.Pattern liveSup = java.util.regex.Pattern.compile("\\b(" + styledIdentifier + ")(?:\\u200C{3}([^\\u200C\\n\\r=]+)\\u200C{3})");
        java.util.regex.Pattern callLiveSub = java.util.regex.Pattern.compile("\\b(" + styledIdentifier + ")\\s*\\([^)]*\\)(?:\\u200D{1,3}([^\\u200D\\n\\r=]+)\\u200D{1,3})");
        java.util.regex.Pattern callLiveSup = java.util.regex.Pattern.compile("\\b(" + styledIdentifier + ")\\s*\\([^)]*\\)(?:\\u200C{3}([^\\u200C\\n\\r=]+)\\u200C{3})");

        for (int i = 0; i < lines.length; i++) {
            String l = lines[i];
            java.util.regex.Matcher m = functionAssignment.matcher(l);
            if (m.find()) {
                linesWithErrors.add(i);
                continue;
            }

            m = callBraceSub.matcher(l);
            while (m.find()) {
                linesWithErrors.add(i);
                break;
            }
            if (linesWithErrors.contains(i)) continue;

            m = callBraceSup.matcher(l);
            while (m.find()) {
                linesWithErrors.add(i);
                break;
            }
            if (linesWithErrors.contains(i)) continue;

            m = braceSub.matcher(l);
            while (m.find()) {
                String base = m.group(1);
                String content = m.group(2);
                if (isFunctionNameInCode(code, base) || content == null || content.trim().isEmpty() || containsFunctionCall(content)) {
                    linesWithErrors.add(i);
                    break;
                }
            }
            if (linesWithErrors.contains(i)) continue;

            m = braceSup.matcher(l);
            while (m.find()) {
                String base = m.group(1);
                String content = m.group(2);
                if (isFunctionNameInCode(code, base) || content == null || content.trim().isEmpty() || containsFunctionCall(content)) {
                    linesWithErrors.add(i);
                    break;
                }
            }
            if (linesWithErrors.contains(i)) continue;

            m = callLiveSub.matcher(l);
            while (m.find()) {
                linesWithErrors.add(i);
                break;
            }
            if (linesWithErrors.contains(i)) continue;

            m = callLiveSup.matcher(l);
            while (m.find()) {
                linesWithErrors.add(i);
                break;
            }
            if (linesWithErrors.contains(i)) continue;

            m = liveSub.matcher(l);
            while (m.find()) {
                String base = m.group(1);
                String content = m.group(2);
                if (isFunctionNameInCode(code, base) || content == null || content.trim().isEmpty() || containsFunctionCall(content)) {
                    linesWithErrors.add(i);
                    break;
                }
            }
            if (linesWithErrors.contains(i)) continue;

            m = liveSup.matcher(l);
            while (m.find()) {
                String base = m.group(1);
                String content = m.group(2);
                if (isFunctionNameInCode(code, base) || content == null || content.trim().isEmpty() || containsFunctionCall(content)) {
                    linesWithErrors.add(i);
                    break;
                }
            }
        }

        return linesWithErrors;
    }

    /**
     * Count only line-level errors from statements that are completed with ';'.
     */
    public static int countErrorsAfterSemicolon(String code) {
        return findErrorLinesAfterSemicolon(code).size();
    }

    public static int countDocstringErrors(String code) {
        return DocstringErrorAnalyzer.countDocstringErrors(code);
    }

    public static Set<Integer> findDocstringErrorLines(String code) {
        return DocstringErrorAnalyzer.findDocstringErrorLines(code);
    }

    public static int countUndefinedVariableErrors(String code) {
        return UndefinedVariableAnalyzer.analyze(code).errorCount;
    }

    public static Set<Integer> findUndefinedVariableErrorLines(String code) {
        return UndefinedVariableAnalyzer.analyze(code).errorLines;
    }

    public static int countIncompleteLineSyntaxErrors(String code) {
        return findIncompleteLineSyntaxErrorLines(code).size();
    }

    public static Set<Integer> findIncompleteLineSyntaxErrorLines(String code) {
        return SyntaxLineAnalyzer.findIncompleteLineSyntaxErrorLines(code);
    }

    public static int countInvalidExponentErrors(String code) {
        return ExponentSyntaxAnalyzer.countInvalidExponentErrors(code);
    }

    public static Set<Integer> findInvalidExponentErrorLines(String code) {
        return ExponentSyntaxAnalyzer.findInvalidExponentErrorLines(code);
    }

    public static Set<Integer> findErrorLines(String code) {
        return SyntaxLineAnalyzer.findErrorLines(code);
    }

    /**
     * Returns line numbers (0-based) that contain syntax errors, but only for
     * lines that are completed with a trailing ';'.
     */
    public static Set<Integer> findErrorLinesAfterSemicolon(String code) {
        return SyntaxLineAnalyzer.findErrorLinesAfterSemicolon(code);
    }
}

