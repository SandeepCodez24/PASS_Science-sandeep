package language.syntax.syntax_checker;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The single entry point the editor, the status bar and the runner all use.
 *
 * <h3>What changed (calls compared with {@code ==})</h3>
 * The "function call on the left of an assignment" rule used a regex that
 * took the first {@code =} it met after {@code name(...)}, so the first half
 * of {@code ==} counted as an assignment. Every
 * {@code publish("...", sqrt(A+E)==A5);} was reported, while
 * {@code (A+B)+(C+D)==A1} passed only because no name stood before its
 * bracket. The same regex also let {@code [^)]*} run from {@code publish(}
 * across the arguments, which is how {@code e^(A+B)==A14} was caught too.
 * The rule is now {@link #assignsToCall(String)}: split the line into
 * statements, find each one's real top-level assignment with
 * {@link ExponentSyntaxAnalyzer#assignmentIndex(String)} (which already
 * ignores {@code == != <= >=} and any {@code =} inside brackets), and flag the
 * statement only when its left-hand side ends in a call. It depends on no
 * function name, so every built-in and user function behaves inside
 * {@code publish(...)} exactly as it does on a line of its own. A
 * {@code \var(...)} / {@code \con(...)} wrapper on the left is a variable,
 * not a call, and is never flagged.
 *
 * <h3>Earlier change (operator sequences)</h3>
 * A new category from {@link OperatorSequenceAnalyzer}: operator combinations
 * with no meaning. After any operator only a value, or one {@code +} /
 * {@code -} sign before a value, may follow -- so {@code 5*-5} is fine while
 * {@code a*&#47;b}, {@code 5+*5}, {@code 5*+-5}, {@code a ==} and {@code 5!!!}
 * are errors. Like every other error it blocks a run and draws a red dot; see
 * {@link ErrorReport#getOperatorSequenceErrors()} and
 * {@link LineIssues#operatorMessage(int)}.
 *
 * <h3>Earlier change (powers and separators)</h3>
 * <ul>
 * <li><b>Powers.</b> {@link ExponentSyntaxAnalyzer} now accepts any operand
 * on either side of {@code ^} ({@code A^B}, {@code A^sqr(4)},
 * {@code sqr(5)^sqrt(6.3)}), checks the whole line instead of only the part
 * left of {@code =}, and reports {@code A^2 = 5}. Each fault carries its own
 * message, available through {@link LineIssues#exponentMessage(int)}.</li>
 * <li><b>Missing separators.</b> A new category from
 * {@link OperandAdjacencyAnalyzer}: two values side by side with no operator
 * or comma between them -- {@code "text"0}, {@code 2A}, {@code 2(A+B)},
 * {@code f(A B)}. Neural Code has no implicit operation, so this is an error
 * wherever it appears, blocks a run, and draws a red dot. See
 * {@link ErrorReport#getMissingSeparatorErrors()} and
 * {@link LineIssues#separatorMessage(int)}.</li>
 * </ul>
 *
 * <h3>Earlier change (block headers)</h3>
 * A new category, <b>block header errors</b>, comes from
 * {@link BlockHeaderAnalyzer}: a header missing its {@code :} or written in a
 * shape the language does not accept is reported on the header line itself.
 * It is part of {@link ErrorReport#getErrorCount()} and of
 * {@link LineIssues#isErrorLine(int)}, so it blocks a run and draws a red dot
 * like every other error, and {@link LineIssues#blockHeaderMessage(int)} gives
 * the gutter tooltip the exact reason.
 *
 * <h3>Earlier change</h3>
 * Every analyzer now shares one {@link SourceModel}, so a comment, a string
 * literal and a {@code ~~} continuation mean the same thing to all of them.
 * The subscript/superscript pass, which used to be the worst offender -- it
 * read raw lines, so it saw comments and string bodies as live code -- is
 * rewritten here:
 *
 * <ul>
 * <li><b>It runs on masked text.</b> This is what fixes
 * {@code publish("sqrt(144) =", sqrt(144));}. The {@code functionAssignment}
 * pattern matched {@code publish(} then took {@code "sqrt(144} as the argument
 * list, closed it on the literal's own {@code )}, and found the {@code =} from
 * inside the string right after it -- so the line read as "a function call
 * being assigned to". With the literal blanked there is no inner bracket and no
 * {@code =}, and the line is correctly silent.</li>
 * <li><b>{@code isFunctionNameInCode} searches the masked document.</b> A name
 * that appears only in a comment no longer counts as a definition.</li>
 * <li><b>Counting and line-finding share one pass.</b> They were two
 * near-identical hundred-line blocks that had already drifted apart -- the
 * counter added several errors per line, the line finder stopped at the first.
 * One pass now produces both, so the number in the status bar and the dots in
 * the gutter cannot disagree.</li>
 * </ul>
 */
public class ErrorChecker {

    public static final class ErrorReport {
        private final int docstringErrors;
        private final int undefinedVariableErrors;
        private final int incompleteLineSyntaxErrors;
        private final int invalidExponentErrors;
        private final int subscriptSuperscriptErrors;
        private final int indentationErrors;
        private final int blockHeaderErrors;
        private final int missingSeparatorErrors;
        private final int operatorSequenceErrors;

        private ErrorReport(int docstringErrors, int undefinedVariableErrors, int incompleteLineSyntaxErrors,
                int invalidExponentErrors, int subscriptSuperscriptErrors, int indentationErrors,
                int blockHeaderErrors, int missingSeparatorErrors, int operatorSequenceErrors) {
            this.docstringErrors = docstringErrors;
            this.undefinedVariableErrors = undefinedVariableErrors;
            this.incompleteLineSyntaxErrors = incompleteLineSyntaxErrors;
            this.invalidExponentErrors = invalidExponentErrors;
            this.subscriptSuperscriptErrors = subscriptSuperscriptErrors;
            this.indentationErrors = indentationErrors;
            this.blockHeaderErrors = blockHeaderErrors;
            this.missingSeparatorErrors = missingSeparatorErrors;
            this.operatorSequenceErrors = operatorSequenceErrors;
        }

        /** Lines that leave a string literal open. Kept under the old name for callers. */
        public int getDocstringErrors() {
            return docstringErrors;
        }

        public int getUnterminatedStringErrors() {
            return docstringErrors;
        }

        public int getUndefinedVariableErrors() {
            return undefinedVariableErrors;
        }

        public int getIncompleteLineSyntaxErrors() {
            return incompleteLineSyntaxErrors;
        }

        public int getInvalidExponentErrors() {
            return invalidExponentErrors;
        }

        public int getSubscriptSuperscriptErrors() {
            return subscriptSuperscriptErrors;
        }

        public int getIndentationErrors() {
            return indentationErrors;
        }

        /** Headers missing their {@code :} or written in an unaccepted shape. */
        public int getBlockHeaderErrors() {
            return blockHeaderErrors;
        }

        /** Lines with two values side by side and no operator or comma between them. */
        public int getMissingSeparatorErrors() {
            return missingSeparatorErrors;
        }

        /** Lines with a meaningless operator combination ({@code a*&#47;b}, {@code 5*+-5}, {@code a ==}). */
        public int getOperatorSequenceErrors() {
            return operatorSequenceErrors;
        }

        public int getWarningCount() {
            return docstringErrors;
        }

        public int getErrorCount() {
            return undefinedVariableErrors + incompleteLineSyntaxErrors + invalidExponentErrors
                    + subscriptSuperscriptErrors + indentationErrors + blockHeaderErrors
                    + missingSeparatorErrors + operatorSequenceErrors;
        }

        public int getTotalErrors() {
            return getErrorCount() + getWarningCount();
        }

        public String toDisplayText() {
            return " Errors: " + getErrorCount() + "  Warnings: " + getWarningCount() + " ";
        }

        public String toTooltipText() {
            return "Errors: " + getErrorCount()
                    + "\nWarnings: " + getWarningCount()
                    + "\n\nUnterminated string literals: " + docstringErrors
                    + "\nUndefined variable errors: " + undefinedVariableErrors
                    + "\nIncomplete line syntax errors: " + incompleteLineSyntaxErrors
                    + "\nInvalid exponent syntax errors: " + invalidExponentErrors
                    + "\nSubscript/superscript errors: " + subscriptSuperscriptErrors
                    + "\nIndentation errors: " + indentationErrors
                    + "\nBlock header errors: " + blockHeaderErrors
                    + "\nMissing separator errors: " + missingSeparatorErrors
                    + "\nOperator sequence errors: " + operatorSequenceErrors;
        }
    }

    /**
     * Every per-line issue set for one document, computed once.
     *
     * <h3>Why this exists</h3>
     * The gutter factory builds one cell per visible line and each cell used to
     * ask for six different error sets, so a 200-line file re-ran the whole
     * analysis 1,200 times per keystroke. Ask for this bundle once and query it
     * per line instead. The result is cached against the text that produced it,
     * so repeated calls with the same text are free.
     */
    public static final class LineIssues {
        private final Set<Integer> undefinedVariable;
        private final Set<Integer> incompleteLine;
        private final Map<Integer, String> invalidExponent;
        private final Set<Integer> subscriptSuperscript;
        private final Set<Integer> indentation;
        private final Set<Integer> unterminatedString;
        private final Map<Integer, String> blockHeader;
        private final Map<Integer, String> structure;
        private final Map<Integer, String> missingSeparator;
        private final Map<Integer, String> operatorSequence;

        private LineIssues(Set<Integer> undefinedVariable, Set<Integer> incompleteLine,
                Map<Integer, String> invalidExponent, Set<Integer> subscriptSuperscript,
                Set<Integer> indentation, Set<Integer> unterminatedString,
                Map<Integer, String> blockHeader, Map<Integer, String> structure,
                Map<Integer, String> missingSeparator, Map<Integer, String> operatorSequence) {
            this.undefinedVariable = undefinedVariable;
            this.incompleteLine = incompleteLine;
            this.invalidExponent = invalidExponent;
            this.subscriptSuperscript = subscriptSuperscript;
            this.indentation = indentation;
            this.unterminatedString = unterminatedString;
            this.blockHeader = blockHeader;
            this.structure = structure;
            this.missingSeparator = missingSeparator;
            this.operatorSequence = operatorSequence;
        }

        public boolean hasUndefinedVariable(int line) {
            return undefinedVariable.contains(line);
        }

        public boolean hasIncompleteLine(int line) {
            return incompleteLine.contains(line);
        }

        public boolean hasInvalidExponent(int line) {
            return invalidExponent.containsKey(line);
        }

        /**
         * @param line zero-based line index
         * @return why the {@code ^} on that line is wrong, or null
         */
        public String exponentMessage(int line) {
            return invalidExponent.get(line);
        }

        public boolean hasMissingSeparator(int line) {
            return missingSeparator.containsKey(line);
        }

        /**
         * @param line zero-based line index
         * @return which two values touch on that line, or null
         */
        public String separatorMessage(int line) {
            return missingSeparator.get(line);
        }

        public boolean hasOperatorSequence(int line) {
            return operatorSequence.containsKey(line);
        }

        /**
         * @param line zero-based line index
         * @return which operator combination on that line is meaningless, or null
         */
        public String operatorMessage(int line) {
            return operatorSequence.get(line);
        }

        public boolean hasSubscriptSuperscript(int line) {
            return subscriptSuperscript.contains(line);
        }

        public boolean hasIndentation(int line) {
            return indentation.contains(line);
        }

        public boolean hasUnterminatedString(int line) {
            return unterminatedString.contains(line);
        }

        public boolean hasBlockHeader(int line) {
            return blockHeader.containsKey(line);
        }

        /**
         * @param line zero-based line index
         * @return why the header on that line is wrong, or null
         */
        public String blockHeaderMessage(int line) {
            return blockHeader.get(line);
        }

        /**
         * @param line zero-based line index
         * @return the structural fault on that line (unclosed block, orphaned
         *         closer, misplaced branch), or null for a plain indentation
         *         fault or a clean line
         */
        public String structureMessage(int line) {
            return structure.get(line);
        }

        /** True when the line should carry a red dot. */
        public boolean isErrorLine(int line) {
            return hasUndefinedVariable(line) || hasIncompleteLine(line) || hasInvalidExponent(line)
                    || hasSubscriptSuperscript(line) || hasIndentation(line) || hasBlockHeader(line)
                    || hasMissingSeparator(line) || hasOperatorSequence(line);
        }

        /** True when the line should carry an amber dot and no red one. */
        public boolean isWarningLine(int line) {
            return !isErrorLine(line) && hasUnterminatedString(line);
        }

        /** Every line carrying at least one error, for paragraph styling. */
        public Set<Integer> allErrorLines() {
            Set<Integer> all = new HashSet<>(undefinedVariable);
            all.addAll(incompleteLine);
            all.addAll(invalidExponent.keySet());
            all.addAll(subscriptSuperscript);
            all.addAll(indentation);
            all.addAll(blockHeader.keySet());
            all.addAll(missingSeparator.keySet());
            all.addAll(operatorSequence.keySet());
            return all;
        }
    }

    private static final Object ISSUE_CACHE_LOCK = new Object();
    private static String cachedIssueSource;
    private static LineIssues cachedIssues;

    /**
     * @param code raw editor text
     * @return every per-line issue set, computed once and cached
     */
    public static LineIssues lineIssues(String code) {
        String key = code == null ? "" : code;
        synchronized (ISSUE_CACHE_LOCK) {
            if (cachedIssues != null && key.equals(cachedIssueSource)) {
                return cachedIssues;
            }
        }

        SourceModel model = SourceModel.of(key);
        IndentationSyntaxAnalyzer.Result indentation = IndentationSyntaxAnalyzer.analyze(model);
        LineIssues issues = new LineIssues(
                UndefinedVariableAnalyzer.analyze(model).errorLines,
                SyntaxLineAnalyzer.findIncompleteLineSyntaxErrorLines(model),
                ExponentSyntaxAnalyzer.analyze(model),
                new HashSet<>(scriptStylingErrors(model).keySet()),
                indentation.errorLines,
                DocstringErrorAnalyzer.findUnterminatedStringLines(model),
                BlockHeaderAnalyzer.analyze(model),
                indentation.messages,
                OperandAdjacencyAnalyzer.analyze(model),
                OperatorSequenceAnalyzer.analyze(model));

        synchronized (ISSUE_CACHE_LOCK) {
            cachedIssueSource = key;
            cachedIssues = issues;
        }
        return issues;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Subscript / superscript styling rules
    // ─────────────────────────────────────────────────────────────────────────

    /** Identifier shape that tolerates the hidden styling markers inside a name. */
    private static final String STYLED_IDENTIFIER = "[A-Za-z_\\u200C\\u200D][A-Za-z0-9_\\u200C\\u200D]*";

    private static final Pattern BRACE_SUB =
            Pattern.compile("\\b(" + STYLED_IDENTIFIER + ")\\s*_\\{([^}]*)\\}");
    private static final Pattern BRACE_SUP =
            Pattern.compile("\\b(" + STYLED_IDENTIFIER + ")\\s*\\^\\{([^}]*)\\}");
    private static final Pattern CALL_BRACE_SUB =
            Pattern.compile("\\b(" + STYLED_IDENTIFIER + ")\\s*\\([^)]*\\)\\s*_\\{([^}]*)\\}");
    private static final Pattern CALL_BRACE_SUP =
            Pattern.compile("\\b(" + STYLED_IDENTIFIER + ")\\s*\\([^)]*\\)\\s*\\^\\{([^}]*)\\}");
    /**
     * A live styled suffix at the very end of a left-hand side
     * ({@code f(x)} + subscript/superscript markers), removed before the call
     * test so a styled call on the left is still reported.
     */
    private static final Pattern TRAILING_STYLED_SUFFIX = Pattern.compile(
            "\\s*(?:\\u200D{1,3}[^\\u200D\\n\\r=]+\\u200D{1,3}"
                    + "|\\u200C{3}[^\\u200C\\n\\r=]+\\u200C{3})\\s*$");

    // Live marker patterns (ZWJ/U+200D for subscript, ZWNJ/U+200C for superscript).
    private static final Pattern LIVE_SUB = Pattern.compile(
            "\\b(" + STYLED_IDENTIFIER + ")(?:\\u200D{1,3}([^\\u200D\\n\\r=]+)\\u200D{1,3})");
    private static final Pattern LIVE_SUP = Pattern.compile(
            "\\b(" + STYLED_IDENTIFIER + ")(?:\\u200C{3}([^\\u200C\\n\\r=]+)\\u200C{3})");
    private static final Pattern CALL_LIVE_SUB = Pattern.compile(
            "\\b(" + STYLED_IDENTIFIER + ")\\s*\\([^)]*\\)(?:\\u200D{1,3}([^\\u200D\\n\\r=]+)\\u200D{1,3})");
    private static final Pattern CALL_LIVE_SUP = Pattern.compile(
            "\\b(" + STYLED_IDENTIFIER + ")\\s*\\([^)]*\\)(?:\\u200C{3}([^\\u200C\\n\\r=]+)\\u200C{3})");

    private static final Pattern FUNCTION_CALL_SHAPE =
            Pattern.compile("\\b[A-Za-z_\\u200C\\u200D][A-Za-z0-9_\\u200C\\u200D]*\\s*\\(");

    // ─────────────────────────────────────────────────────────────────────────
    // Public API
    // ─────────────────────────────────────────────────────────────────────────

    public static int countErrors(String code) {
        return analyzeErrors(code).getTotalErrors();
    }

    /**
     * Runs every check once, against one shared cleaned view of the file.
     *
     * @param code raw editor text
     * @return the full report
     */
    public static ErrorReport analyzeErrors(String code) {
        SourceModel model = SourceModel.of(code);

        int docstringErrors = DocstringErrorAnalyzer.findUnterminatedStringLines(model).size();
        int undefinedVariableErrors = UndefinedVariableAnalyzer.analyze(model).errorCount;
        int incompleteLineSyntaxErrors = SyntaxLineAnalyzer.findIncompleteLineSyntaxErrorLines(model).size();
        int invalidExponentErrors = ExponentSyntaxAnalyzer.findInvalidExponentErrorLines(model).size();
        int subscriptSuperscriptErrors = totalOf(scriptStylingErrors(model));
        int indentationErrors = IndentationSyntaxAnalyzer.analyze(model).errorCount;
        int blockHeaderErrors = BlockHeaderAnalyzer.analyze(model).size();
        int missingSeparatorErrors = OperandAdjacencyAnalyzer.analyze(model).size();
        int operatorSequenceErrors = OperatorSequenceAnalyzer.analyze(model).size();

        return new ErrorReport(docstringErrors, undefinedVariableErrors, incompleteLineSyntaxErrors,
                invalidExponentErrors, subscriptSuperscriptErrors, indentationErrors, blockHeaderErrors,
                missingSeparatorErrors, operatorSequenceErrors);
    }

    public static int countDocstringErrors(String code) {
        return DocstringErrorAnalyzer.countDocstringErrors(code);
    }

    public static Set<Integer> findDocstringErrorLines(String code) {
        return DocstringErrorAnalyzer.findDocstringErrorLines(code);
    }

    public static int countUndefinedVariableErrors(String code) {
        return UndefinedVariableAnalyzer.analyze(SourceModel.of(code)).errorCount;
    }

    public static Set<Integer> findUndefinedVariableErrorLines(String code) {
        return UndefinedVariableAnalyzer.analyze(SourceModel.of(code)).errorLines;
    }

    public static int countIncompleteLineSyntaxErrors(String code) {
        return findIncompleteLineSyntaxErrorLines(code).size();
    }

    public static Set<Integer> findIncompleteLineSyntaxErrorLines(String code) {
        return SyntaxLineAnalyzer.findIncompleteLineSyntaxErrorLines(SourceModel.of(code));
    }

    public static int countInvalidExponentErrors(String code) {
        return findInvalidExponentErrorLines(code).size();
    }

    public static Set<Integer> findInvalidExponentErrorLines(String code) {
        return ExponentSyntaxAnalyzer.findInvalidExponentErrorLines(SourceModel.of(code));
    }

    public static Set<Integer> findErrorLines(String code) {
        return SyntaxLineAnalyzer.findErrorLines(SourceModel.of(code));
    }

    /**
     * Counts only line-level errors from statements completed with {@code ;}.
     *
     * @param code raw editor text
     * @return the count
     */
    public static int countErrorsAfterSemicolon(String code) {
        return findErrorLinesAfterSemicolon(code).size();
    }

    /**
     * @param code raw editor text
     * @return zero-based indices of unbalanced {@code ;}-terminated lines
     */
    public static Set<Integer> findErrorLinesAfterSemicolon(String code) {
        return SyntaxLineAnalyzer.findErrorLinesAfterSemicolon(SourceModel.of(code));
    }

    public static int countIndentationErrors(String code) {
        return IndentationSyntaxAnalyzer.analyze(SourceModel.of(code)).errorCount;
    }

    public static Set<Integer> findIndentationErrorLines(String code) {
        return IndentationSyntaxAnalyzer.analyze(SourceModel.of(code)).errorLines;
    }

    public static int countBlockHeaderErrors(String code) {
        return BlockHeaderAnalyzer.analyze(SourceModel.of(code)).size();
    }

    public static Set<Integer> findBlockHeaderErrorLines(String code) {
        return new HashSet<>(BlockHeaderAnalyzer.analyze(SourceModel.of(code)).keySet());
    }

    public static int countMissingSeparatorErrors(String code) {
        return OperandAdjacencyAnalyzer.analyze(SourceModel.of(code)).size();
    }

    public static Set<Integer> findMissingSeparatorErrorLines(String code) {
        return new HashSet<>(OperandAdjacencyAnalyzer.analyze(SourceModel.of(code)).keySet());
    }

    public static int countOperatorSequenceErrors(String code) {
        return OperatorSequenceAnalyzer.analyze(SourceModel.of(code)).size();
    }

    public static Set<Integer> findOperatorSequenceErrorLines(String code) {
        return new HashSet<>(OperatorSequenceAnalyzer.analyze(SourceModel.of(code)).keySet());
    }

    public static int countSubscriptSuperscriptErrors(String code) {
        return totalOf(scriptStylingErrors(SourceModel.of(code)));
    }

    public static Set<Integer> findSubscriptSuperscriptErrorLines(String code) {
        return new HashSet<>(scriptStylingErrors(SourceModel.of(code)).keySet());
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Internals
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Detects invalid uses of subscript/superscript styling:
     * <ul>
     * <li>a function name used as the base of a styled group ({@code sin_{1}})</li>
     * <li>a function call carrying a styled suffix ({@code f(x)_{1}})</li>
     * <li>a function call on the left of an assignment ({@code f(x) = 3}); a
     * comparison such as {@code f(x) == 3} is not an assignment</li>
     * <li>a function call inside styled content ({@code a_{sin(x)}})</li>
     * <li>an empty styled group ({@code a_{}} or {@code a^{}})</li>
     * </ul>
     *
     * @param model the cleaned document
     * @return line index to number of offences on that line
     */
    private static Map<Integer, Integer> scriptStylingErrors(SourceModel model) {
        Map<Integer, Integer> perLine = new HashMap<>();
        String document = model.maskedDocument();

        for (SourceModel.Line sourceLine : model.lines()) {
            if (sourceLine.isAbsorbed() || sourceLine.isBlank()) {
                continue;
            }

            String line = sourceLine.masked();
            int count = 0;

            // At most one per line, matching the original behaviour.
            if (assignsToCall(line)) {
                count++;
            }

            count += countMatches(CALL_BRACE_SUB, line);
            count += countMatches(CALL_BRACE_SUP, line);
            count += countMatches(CALL_LIVE_SUB, line);
            count += countMatches(CALL_LIVE_SUP, line);

            count += countStyledGroupFaults(BRACE_SUB, line, document);
            count += countStyledGroupFaults(BRACE_SUP, line, document);
            count += countStyledGroupFaults(LIVE_SUB, line, document);
            count += countStyledGroupFaults(LIVE_SUP, line, document);

            if (count > 0) {
                perLine.put(sourceLine.index(), count);
            }
        }

        return perLine;
    }

    /**
     * True when some statement on the line assigns to a function call:
     * {@code f(x) = 3}, {@code a = 1; g(y) = 2}.
     *
     * <p>
     * Only the statement's own top-level {@code =} counts, so comparisons
     * ({@code sqrt(x) == 2}, {@code f(a) != b}, {@code g(x) >= 1}) and keyword
     * arguments inside brackets ({@code f(x = 2)}) are never mistaken for an
     * assignment. The left-hand side must END in the call: {@code A[f(1)] = 2}
     * assigns to {@code A}, not to {@code f}.
     *
     * @param masked one masked logical line
     * @return true when a call stands on the left of an assignment
     */
    static boolean assignsToCall(String masked) {
        if (masked == null || masked.indexOf('=') < 0) {
            return false;
        }
        for (String statement : splitTopLevelStatements(masked)) {
            int assignment = ExponentSyntaxAnalyzer.assignmentIndex(statement);
            if (assignment < 0) {
                continue;
            }
            String left = TRAILING_STYLED_SUFFIX.matcher(statement.substring(0, assignment)).replaceFirst("");
            if (endsWithCall(left)) {
                return true;
            }
        }
        return false;
    }

    /** Splits on {@code ;} at bracket depth zero. The text is masked, so no quote tracking is needed. */
    private static List<String> splitTopLevelStatements(String line) {
        List<String> parts = new ArrayList<>();
        int depth = 0;
        int start = 0;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == '(' || c == '[' || c == '{') {
                depth++;
            } else if (c == ')' || c == ']' || c == '}') {
                depth = Math.max(0, depth - 1);
            } else if (c == ';' && depth == 0) {
                parts.add(line.substring(start, i));
                start = i + 1;
            }
        }
        parts.add(line.substring(start));
        return parts;
    }

    /**
     * True when {@code text} ends in {@code name(...)}. The bracket is matched
     * by depth, so nested arguments ({@code f(g(x))}) are handled. A name
     * written behind a backslash ({@code \var(\mu)}, {@code \con(\pi)}) is a
     * wrapped variable, not a call.
     */
    private static boolean endsWithCall(String text) {
        int end = text.length() - 1;
        while (end >= 0 && Character.isWhitespace(text.charAt(end))) {
            end--;
        }
        if (end < 0 || text.charAt(end) != ')') {
            return false;
        }

        int depth = 0;
        int open = -1;
        for (int i = end; i >= 0; i--) {
            char c = text.charAt(i);
            if (c == ')' || c == ']' || c == '}') {
                depth++;
            } else if (c == '(' || c == '[' || c == '{') {
                depth--;
                if (depth == 0) {
                    open = i;
                    break;
                }
            }
        }
        if (open < 0 || text.charAt(open) != '(') {
            return false;
        }

        int nameEnd = open - 1;
        while (nameEnd >= 0 && Character.isWhitespace(text.charAt(nameEnd))) {
            nameEnd--;
        }
        int nameStart = nameEnd;
        while (nameStart >= 0 && OperandAdjacencyAnalyzer.isIdentPart(text.charAt(nameStart))) {
            nameStart--;
        }
        nameStart++;
        if (nameStart > nameEnd || !OperandAdjacencyAnalyzer.isIdentStart(text.charAt(nameStart))) {
            return false; // (a, b) = ..., 2(x) = ... : no name before the bracket
        }
        return nameStart == 0 || text.charAt(nameStart - 1) != '\\';
    }

    private static int countMatches(Pattern pattern, String line) {
        Matcher matcher = pattern.matcher(line);
        int count = 0;
        while (matcher.find()) {
            count++;
        }
        return count;
    }

    private static int countStyledGroupFaults(Pattern pattern, String line, String document) {
        Matcher matcher = pattern.matcher(line);
        int count = 0;
        while (matcher.find()) {
            String base = matcher.group(1);
            String content = matcher.group(2);
            if (isFunctionNameInCode(document, base)) {
                count++;
            }
            if (content == null || content.trim().isEmpty()) {
                count++;
            }
            if (containsFunctionCall(content)) {
                count++;
            }
        }
        return count;
    }

    /**
     * True when {@code name} is called anywhere in the file. The document passed
     * in is masked, so an appearance in a comment or inside a string literal
     * does not count.
     */
    private static boolean isFunctionNameInCode(String document, String name) {
        if (document == null || name == null || name.isEmpty()) {
            return false;
        }
        try {
            Pattern pattern = Pattern.compile("\\b" + Pattern.quote(name) + "\\s*\\(");
            return pattern.matcher(document).find();
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean containsFunctionCall(String text) {
        return text != null && !text.isEmpty() && FUNCTION_CALL_SHAPE.matcher(text).find();
    }

    private static int totalOf(Map<Integer, Integer> perLine) {
        int total = 0;
        for (int value : perLine.values()) {
            total += value;
        }
        return total;
    }
}
