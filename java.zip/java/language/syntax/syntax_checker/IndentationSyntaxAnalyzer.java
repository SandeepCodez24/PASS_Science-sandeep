package language.syntax.syntax_checker;

import java.util.ArrayDeque;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Validates the three-space block indentation used by NC source files.
 * Line numbers returned by this class are zero-based, matching CodeArea
 * paragraphs.
 *
 * <h3>Branch lines</h3>
 * {@code else:} and {@code elseif <condition>:} are branch continuations of the
 * enclosing {@code if} block. They do NOT open a block of their own, and they
 * sit at the SAME indentation as the {@code if} that owns them -- not one level
 * in. The body that follows a branch line is indented one level from the
 * branch, which falls out automatically because the {@code if} block stays on
 * the stack.
 *
 * <h3>What changed (header recovery)</h3>
 * <ol>
 * <li><b>A header opens its block even without its colon.</b> The colon used to
 * be the condition for pushing a block, so {@code class SMSC()} opened nothing;
 * its methods were then "unexpected indents" and its {@code csend} an orphan.
 * Headers are now recognised by {@link BlockHeaderGrammar} from their first
 * word, the block is opened, and the missing colon is reported once, on the
 * header line, by {@link BlockHeaderAnalyzer}.</li>
 * <li><b>Header-shape rules moved out.</b> The colon rule and the
 * {@code else}/{@code elseif} condition rules now live in
 * {@link BlockHeaderAnalyzer}. This class checks structure and indentation
 * only, so no header fault is counted by both passes.</li>
 * <li><b>A closer finds its own block.</b> When the innermost block expects a
 * different closer but an outer block expects this one, the inner blocks are
 * the ones missing their terminators: they are reported on their opening lines
 * and the outer block is closed normally. Previously the closer itself was
 * blamed and nothing was popped, so every following closer was blamed too.</li>
 * <li><b>Structural faults say what they are.</b> An unclosed block, an
 * orphaned closer, a branch outside an {@code if} and a branch after
 * {@code else} each carry a message in {@link Result#messages}, so the gutter
 * no longer calls them "invalid indentation".</li>
 * <li><b>Modifier-prefixed methods open a block.</b>
 * {@code private function base(v):} now pushes like any other function.</li>
 * </ol>
 *
 * <p>
 * Structure is read from {@link SourceModel}'s masked text, so a keyword or a
 * colon inside a string literal cannot open or close a block. Indentation is
 * measured on the raw first physical line. Continuation lines folded in by
 * {@code ~~} are skipped entirely.
 */
final class IndentationSyntaxAnalyzer {

    static final int INDENT_SIZE = 3;

    static final class Result {
        final int errorCount;
        final Set<Integer> errorLines;
        /**
         * Specific explanations for structural faults, by line. A line in
         * {@link #errorLines} with no entry here is a plain indentation fault.
         */
        final Map<Integer, String> messages;

        private Result(int errorCount, Set<Integer> errorLines, Map<Integer, String> messages) {
            this.errorCount = errorCount;
            this.errorLines = Collections.unmodifiableSet(errorLines);
            this.messages = Collections.unmodifiableMap(messages);
        }
    }

    private static final class Block {
        final BlockHeaderGrammar.Kind kind;
        final String closer;
        final int indentation;
        final int line;
        /** Set once an {@code else:} branch has been seen for this if block. */
        boolean sawElse;

        Block(BlockHeaderGrammar.Kind kind, int indentation, int line) {
            this.kind = kind;
            this.closer = kind.closer();
            this.indentation = indentation;
            this.line = line;
        }
    }

    private IndentationSyntaxAnalyzer() {
    }

    /**
     * @param code raw editor text
     * @return the indentation report
     */
    static Result analyze(String code) {
        return analyze(SourceModel.of(code));
    }

    /**
     * @param model the cleaned document
     * @return the indentation report
     */
    static Result analyze(SourceModel model) {
        Set<Integer> errorLines = new HashSet<>();
        Map<Integer, String> messages = new HashMap<>();
        ArrayDeque<Block> blocks = new ArrayDeque<>();

        for (SourceModel.Line sourceLine : model.lines()) {
            if (sourceLine.isAbsorbed()) {
                continue;
            }

            String logical = sourceLine.masked().trim();
            if (logical.isEmpty()) {
                continue;
            }

            int i = sourceLine.index();
            String raw = sourceLine.raw();
            int indentation = countLeadingSpaces(raw);
            boolean hasLeadingTab = containsLeadingTab(raw);
            if (hasLeadingTab || indentation % INDENT_SIZE != 0) {
                errorLines.add(i);
            }

            String firstWord = BlockHeaderGrammar.firstWord(logical);
            BlockHeaderGrammar.Header header = BlockHeaderGrammar.parse(logical);

            // ---------- branch continuation: else / elseif ----------
            if (header != null && header.kind().isBranch()) {
                Block owner = blocks.peek();

                if (owner == null || owner.kind != BlockHeaderGrammar.Kind.IF) {
                    // A branch with no open if block directly above it.
                    errorLines.add(i);
                    messages.put(i, "'" + header.kind().keyword() + "' has no open 'if' block above it");
                    continue;
                }

                // Branch sits level with its if, not indented past it.
                if (indentation != owner.indentation) {
                    errorLines.add(i);
                }

                // Nothing may follow a bare else in the same if block.
                if (owner.sawElse) {
                    errorLines.add(i);
                    messages.put(i, "Nothing may follow 'else' in the same 'if' block");
                }

                if (header.kind() == BlockHeaderGrammar.Kind.ELSE) {
                    owner.sawElse = true;
                }

                // The branch does not push a block; the if block it belongs to
                // stays on the stack and keeps owning the closing 'iend'.
                continue;
            }

            // ---------- block closers ----------
            if (BlockHeaderGrammar.isCloser(firstWord)) {
                Block match = findOpenBlock(blocks, firstWord);
                if (match == null) {
                    // Nothing open expects this closer.
                    errorLines.add(i);
                    messages.put(i, "'" + firstWord + "' has no open block to close");
                    continue;
                }

                // Every block above the match was left without its own closer.
                while (blocks.peek() != match) {
                    reportUnclosed(blocks.pop(), errorLines, messages);
                }

                if (indentation != match.indentation) {
                    errorLines.add(i);
                }
                blocks.pop();
                continue;
            }

            // ---------- ordinary statements and block openers ----------
            int expectedIndentation = blocks.isEmpty()
                    ? 0
                    : blocks.peek().indentation + INDENT_SIZE;
            if (indentation != expectedIndentation) {
                errorLines.add(i);
            }

            // Opened with or without its colon: a missing colon is a header
            // fault, reported once by BlockHeaderAnalyzer, never a structural one.
            if (header != null && header.kind().opensBlock()) {
                blocks.push(new Block(header.kind(), indentation, i));
            }
        }

        // An unclosed block is reported on its opening line.
        while (!blocks.isEmpty()) {
            reportUnclosed(blocks.pop(), errorLines, messages);
        }

        return new Result(errorLines.size(), errorLines, messages);
    }

    private static void reportUnclosed(Block block, Set<Integer> errorLines, Map<Integer, String> messages) {
        errorLines.add(block.line);
        messages.put(block.line, "'" + block.kind.keyword() + "' block has no closing '" + block.closer + "'");
    }

    /** The innermost open block expecting {@code closer}, or null. */
    private static Block findOpenBlock(ArrayDeque<Block> blocks, String closer) {
        for (Block block : blocks) {
            if (block.closer.equals(closer)) {
                return block;
            }
        }
        return null;
    }

    private static int countLeadingSpaces(String line) {
        int count = 0;
        while (count < line.length() && line.charAt(count) == ' ') {
            count++;
        }
        return count;
    }

    private static boolean containsLeadingTab(String line) {
        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (ch == '\t') {
                return true;
            }
            if (ch != ' ') {
                return false;
            }
        }
        return false;
    }
}
