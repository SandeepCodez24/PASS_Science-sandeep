package language.syntax.syntax_checker.functions;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

import language.syntax.textcolours.ConversionOperators;
import language.syntax.textcolours.PrimitiveOperators;
import language.syntax.textcolours.library.FunctionLibraries;
import ui.ui_functions.FunctionProvider;

/**
 * Which calls are built in, and which of those accept named values.
 *
 * <p>
 * Named values ({@code f(x=4)}) work only for functions and classes defined
 * in the script; {@code nc.exe} refuses them on a built-in:
 * {@code 'sqrt' is not a function or class defined in this script, so its
 * values cannot be named - give them in order}.
 *
 * <h3>Built-ins that do take names</h3>
 * Since 2026-10-27 every built-in with a parameter line takes named values
 * ({@code allclose(A, B, atol=0.2)}, {@code max(A, axis=0)}). They are the
 * rows of the usage table, {@link BuiltinSignatures} -- the one place that
 * lists them; {@link #namedValueBuiltins()} reads it. A new
 * {@code builtin_signatures.tsv} from {@code nc.exe} is the only change the
 * editor needs.
 *
 * <p>
 * The built-in names come from the same lists the suggestion box and the
 * colouring use: every {@code suggestions_list/*_list.java} file (through
 * {@link FunctionProvider}), the library files, the data conversion words and
 * the called primitives ({@code sqrt}, {@code log}, ...).
 */
public final class BuiltinNames {

    private BuiltinNames() {
    }

    /** @return the built-in functions that accept named values (the usage table's rows) */
    public static Set<String> namedValueBuiltins() {
        Set<String> accepting = new LinkedHashSet<>();
        for (BuiltinSignatures.Signature sig : BuiltinSignatures.all()) {
            if (sig.acceptsNames()) {
                accepting.add(sig.name());
            }
        }
        return accepting;
    }

    /** Calls on any object that are built in: their values cannot be named. */
    public static final Set<String> RESERVED_OBJECT_CALLS = Set.of("lineage", "rewind", "tick");

    private static volatile Set<String> names;

    /** @return every built-in function name (bare, no brackets) */
    public static Set<String> all() {
        Set<String> known = names;
        if (known == null) {
            Set<String> built = new LinkedHashSet<>(FunctionProvider.getDefaultFunctionNames());
            built.addAll(FunctionLibraries.names());
            built.addAll(Arrays.asList(ConversionOperators.WORDS));
            built.addAll(Arrays.asList(PrimitiveOperators.CALLED_WORDS));
            for (BuiltinSignatures.Signature sig : BuiltinSignatures.all()) {
                built.add(sig.name());
            }
            known = Collections.unmodifiableSet(built);
            names = known;
        }
        return known;
    }

    /**
     * @param name a called name
     * @return true when it is a built-in that refuses named values
     */
    public static boolean refusesNames(String name) {
        BuiltinSignatures.Signature sig = BuiltinSignatures.find(name);
        return all().contains(name) && (sig == null || !sig.acceptsNames());
    }
}
