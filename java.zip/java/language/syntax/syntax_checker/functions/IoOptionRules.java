package language.syntax.syntax_checker.functions;

import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * The option values {@code nc.exe}'s data I/O functions refuse, as far as the
 * source shows them: only a value written out ({@code quote="bad"},
 * {@code level=12}) is judged; a variable, an expression or {@code ""} (not
 * given) never is.
 *
 * <p>
 * Every rule is copied from the C++ check in
 * {@code runtime/interpreter/Numpy/importing_data/} (the accepted spellings,
 * upper/lower case, aliases such as {@code compress="yes"}), and each
 * function's rules run in the order {@code nc.exe} runs them, so the first
 * message is the one the run would print. The messages are {@code nc.exe}'s,
 * without its {@code Error: } prefix.
 *
 * <pre>
 *   save_csv(f, T, quote="bad")       save_csv: quote must be "minimal" or "all"
 *   save_csv(f, T, compress="zstd")   save_csv: compress="zstd" is not built in; use "gz" (or "none")
 *   save_png(f, I, max_size="5 megs") save_png: max_size "5 megs" is not a size (e.g. "48kb")
 *   save_h5(f, A, level=12)           save_h5: level must be 0..9
 *   save_xlsb(f, T)                   save_xlsb: writing .xlsb is not built in - save as .xlsx (...)
 * </pre>
 */
public final class IoOptionRules {

    private IoOptionRules() {
    }

    private static final Pattern DELIMITED = Pattern.compile("save_(csv|tsv|txt|dat)");
    private static final Pattern IMAGE = Pattern.compile("(png|jpg|jpeg|tiff|bmp|gif|dicom)");
    private static final Pattern AUDIO = Pattern.compile("(wav|flac|ogg|mp3)");
    private static final Pattern VIDEO = Pattern.compile("(mp4|avi|m4v|mov)");
    private static final Pattern DATABASE = Pattern.compile("(sqlite|postgresql|mysql|oracle|sqlserver)");
    private static final Pattern NUMBER = Pattern.compile("[+-]?(?:\\d+\\.?\\d*|\\.\\d+)(?:[eE][+-]?\\d+)?");

    /** {@code compress=} for csv, json, xml and bin ({@code applyCompression}). */
    private static final Set<String> TEXT_COMPRESS = Set.of(
            "none", "no", "false", "gz", "gzip", "yes", "true", "deflate", "zlib");

    /**
     * @param fn     the called data I/O function
     * @param values per input name, the value's source text (only the inputs
     *               the call gives)
     * @return {@code nc.exe}'s message for the first refused value, or null
     */
    public static String check(String fn, Map<String, String> values) {
        String msg = rules(fn, new Values(values));
        return msg == null ? null : fn + ": " + msg;
    }

    private static String rules(String fn, Values v) {
        int cut = fn.indexOf('_');
        if (cut < 0) {
            return null;
        }
        String op = fn.substring(0, cut);
        String fmt = fn.substring(cut + 1);
        String m;

        if (DELIMITED.matcher(fn).matches()) {
            return first(
                    v.choice("quote", true, Set.of("minimal", "all"), "quote must be \"minimal\" or \"all\""),
                    v.choice("mode", true, Set.of("w", "a"), "mode must be \"w\" (write) or \"a\" (append)"),
                    textCompress(v), commonMaxSize(v));
        }
        switch (fn) {
            case "save_json":
                return first(v.choice("nan_mode", true, Set.of("null", "str"), "nan_mode must be \"null\" or \"str\""),
                        textCompress(v), commonMaxSize(v));
            case "save_xml":
                return textCompress(v);
            case "save_html", "save_htm":
                return v.choice("theme", true, Set.of("navy", "light", "minimal"),
                        "theme must be \"navy\", \"light\" or \"minimal\"");
            case "save_bin", "save_custom":
                m = v.number("align");
                if (m != null && !Set.of("1", "2", "4", "8").contains(whole(m))) {
                    return "align must be 1 (packed), 2, 4 or 8";
                }
                return first(endian(v), textCompress(v));
            case "read_bin", "read_custom":
                return endian(v);
            case "save_xlsb":
                return "writing .xlsb is not built in - save as .xlsx (Excel opens both the same way)";
            case "save_xlsx", "save_xls", "save_xlsm":
                if (v.text("pass") != null) {
                    return "password protection (pass=) is not built in yet - the file would be saved unprotected";
                }
                return first(
                        v.choice("mode", true, Set.of("w", "a"),
                                "mode must be \"w\" (new file) or \"a\" (add sheets to the file)"),
                        v.choice("compress", true, Set.of("no", "none", "false", "yes", "true", "deflate", "zip"),
                                "compress must be \"yes\" or \"no\" for ." + fmt),
                        commonMaxSize(v));
            case "read_mat":
                return v.choice("struct_as", true, Set.of("dict", "object"), "struct_as must be \"dict\" or \"object\"");
            case "save_mat":
                return v.choice("ver", true, Set.of("v5", "v7", "v7.3"), "ver must be \"v5\", \"v7\" or \"v7.3\"");
            case "save_fig":
                return commonMaxSize(v);
            case "save_fits", "save_fit":
                m = v.number("bitpix");
                if (m != null && !Set.of("8", "16", "32", "64", "-32", "-64").contains(whole(m))) {
                    return "bitpix must be 8, 16, 32, 64, -32 (float32) or -64 (float64)";
                }
                return v.choice("compress", true, Set.of("none", "rice", "gzip", "no"),
                        "compress must be \"rice\", \"gzip\" or \"none\"");
            case "save_h5", "save_hdf", "save_he5":
                return first(
                        v.choice("chunks", true, Set.of("none", "contiguous", "false", "auto", "true"),
                                "chunks must be \"auto\", \"none\" or a list of sizes like [64, 64]"),
                        h5Compress(v), level(v),
                        v.choice("mode", true, Set.of("w", "a"), "mode must be \"w\" or \"a\""));
            case "save_nc", "save_cdf":
                return first(
                        v.choice("compress", true, Set.of("gzip", "deflate", "yes", "zlib", "no", "none"),
                                "compress must be \"zlib\" or \"none\""),
                        level(v),
                        v.choice("format", true, Set.of("nc4", "netcdf4", "classic", "64bit"),
                                "format must be \"nc4\", \"classic\" or \"64bit\""));
            case "save_parquet", "save_feather", "save_orc":
                return columnar(fmt, v);
            case "save_shp", "save_shx", "save_dbf":
                return v.choice("geom_type", true,
                        Set.of("point", "multipoint", "line", "linestring", "polyline", "polygon"),
                        "geom_type must be \"point\", \"multipoint\", \"line\" or \"polygon\"");
            case "save_tif", "save_geotiff":
                return v.choice("compress", true, Set.of("deflate", "lzw", "zstd", "none", "packbits", "zlib", "gzip"),
                        "compress must be \"deflate\", \"lzw\", \"zstd\" or \"none\"");
            case "read_gpx":
                return v.choice("layer", true,
                        Set.of("tracks", "waypoints", "routes", "track", "waypoint", "route"),
                        "layer must be \"tracks\", \"waypoints\" or \"routes\"");
            case "read_kml":
                return v.choice("layer", true,
                        Set.of("placemarks", "paths", "polygons", "placemark", "path", "polygon"),
                        "layer must be \"placemarks\", \"paths\" or \"polygons\"");
            case "save_gpx":
                if ("true".equals(v.raw("kmz"))) {
                    return "kmz=true is for save_kml";
                }
                return v.choice("mode_type", true, Set.of("track", "waypoint", "route"),
                        "mode_type must be \"track\", \"waypoint\" or \"route\"");
            case "save_kml":
                m = v.choice("mode_type", true, Set.of("line", "point", "polygon"),
                        "mode_type must be \"line\", \"point\" or \"polygon\"");
                if (m != null) {
                    return m;
                }
                String color = v.text("color");
                if (color != null) {
                    String hex = color.startsWith("#") ? color.substring(1) : color;
                    if (hex.length() != 6 && hex.length() != 8) {
                        return "color must be \"#RRGGBB\" or \"#RRGGBBAA\"";
                    }
                }
                return null;
            case "io_options":
                return v.choice("op", true, Set.of("read", "load", "save"), "op must be \"read\", \"load\" or \"save\"");
            default:
                break;
        }
        if (IMAGE.matcher(fmt).matches()) {
            return "read".equals(op) ? imageRead(v) : "save".equals(op) ? imageSave(fmt, v) : null;
        }
        if (AUDIO.matcher(fmt).matches()) {
            if ("read".equals(op)) {
                return v.choice("dtype", true, Set.of("float32", "float64", "int16"),
                        "dtype must be \"float32\" or \"int16\"");
            }
            if ("save".equals(op)) {
                if (fmt.equals("ogg") || fmt.equals("mp3")) {
                    return "encoding " + (fmt.equals("ogg") ? "Ogg Vorbis/Opus" : "MP3")
                            + " is not built in yet - use save_flac (lossless, small) or save_wav";
                }
                String size = v.text("max_size");
                return size != null && !isByteSize(size) ? "max_size is not a size (e.g. \"2mb\")" : null;
            }
            return null;
        }
        if (VIDEO.matcher(fmt).matches() && "save".equals(op)) {
            return video(v);
        }
        if (DATABASE.matcher(fmt).matches() && "save".equals(op)) {
            return v.choice("mode", true, Set.of("append", "replace", "upsert", "fail"),
                    "mode must be \"append\", \"replace\", \"upsert\" or \"fail\"");
        }
        return null;
    }

    // ─────────────────────────────────────────────────────────────────────
    // Shared rules
    // ─────────────────────────────────────────────────────────────────────

    private static String textCompress(Values v) {
        String c = v.text("compress");
        return c != null && !TEXT_COMPRESS.contains(lower(c))
                ? "compress=\"" + c + "\" is not built in; use \"gz\" (or \"none\")"
                : null;
    }

    private static String commonMaxSize(Values v) {
        String size = v.text("max_size");
        return size != null && !isByteSize(size)
                ? "max_size \"" + size + "\" is not a size (write e.g. \"48kb\", \"5mb\")"
                : null;
    }

    /** {@code endian=}; a dtype starting with {@code <} / {@code >} sets the byte order itself. */
    private static String endian(Values v) {
        String dtype = v.text("dtype");
        if (dtype != null && (dtype.startsWith("<") || dtype.startsWith(">"))) {
            return null;
        }
        return v.choice("endian", true, Set.of("little", "big", "native"), "endian must be \"little\" or \"big\"");
    }

    private static String level(Values v) {
        String n = v.number("level");
        if (n == null) {
            return null;
        }
        double d = Double.parseDouble(n);
        long whole = (long) d; // optInt
        return whole < 0 || whole > 9 ? "level must be 0..9" : null;
    }

    private static String h5Compress(Values v) {
        String c = v.text("compress");
        if (c == null) {
            return null;
        }
        String l = lower(c);
        if (Set.of("zlib", "deflate", "yes").contains(l)) {
            l = "gzip";
        } else if (l.equals("no")) {
            l = "none";
        }
        if (l.equals("zstd")) {
            return "compress=\"zstd\" is not built in - use \"gzip\" or \"lzf\"";
        }
        return Set.of("gzip", "lzf", "none").contains(l) ? null
                : "compress must be \"gzip\", \"lzf\", \"zstd\" or \"none\"";
    }

    private static String columnar(String fmt, Values v) {
        String rows = v.number("group_rows");
        if (rows != null) {
            long g = (long) Double.parseDouble(rows);
            if (g == 0 || g < -1) {
                return "group_rows must be 1 or more";
            }
        }
        String size = v.text("max_size");
        if (size != null && !isByteSize(size)) {
            return "max_size must be a size like \"256mb\"";
        }
        String c = v.text("compress");
        if (c == null) {
            return null;
        }
        String codec = lower(c);
        if (codec.equals("no") || codec.equals("uncompressed")) {
            codec = "none";
        } else if (codec.equals("yes")) {
            codec = "zstd";
        }
        switch (fmt) {
            case "parquet":
                return Set.of("none", "snappy", "gzip", "lz4", "lz4_raw", "zstd").contains(codec) ? null
                        : "compress must be \"zstd\", \"snappy\", \"gzip\", \"lz4\" or \"none\"";
            case "feather":
                return Set.of("lz4", "zstd", "none").contains(codec) ? null
                        : "feather supports compress=\"zstd\", \"lz4\" or \"none\" (Arrow IPC has no " + codec + ")";
            default:
                return Set.of("none", "zlib", "gzip", "snappy", "lz4", "zstd").contains(codec) ? null
                        : "orc supports compress=\"zstd\", \"snappy\", \"lz4\", \"zlib\" or \"none\"";
        }
    }

    private static String imageRead(Values v) {
        return first(
                v.choice("dtype", true, Set.of("uint8", "float32", "float64", "uint16"),
                        "dtype must be \"uint8\" or \"float32\""),
                v.choice("channels", true, Set.of("rgb", "gray", "rgba", "grey"),
                        "channels must be \"rgb\", \"gray\" or \"rgba\""));
    }

    private static String imageSave(String fmt, Values v) {
        String size = v.text("max_size");
        if (size != null && !isByteSize(size)) {
            return "max_size \"" + size + "\" is not a size (e.g. \"48kb\")";
        }
        if (fmt.equals("jpg") || fmt.equals("jpeg")) {
            return v.choice("subsampling", false, Set.of("4:2:0", "4:4:4"),
                    "subsampling must be \"4:2:0\" or \"4:4:4\"");
        }
        if (fmt.equals("tiff") && v.raw("compress") == null) {
            return v.choice("codec", true, Set.of("lzw", "deflate", "none", "packbits"),
                    "codec must be \"lzw\", \"deflate\", \"packbits\" or \"none\"");
        }
        return null;
    }

    private static String video(Values v) {
        String fps = v.number("fps");
        if (fps != null) {
            double d = Double.parseDouble(fps);
            if (!(d > 0) || d > 1000) {
                return "fps must be between 0 and 1000";
            }
        }
        String c = v.text("codec");
        if (c != null) {
            String codec = lower(c);
            if (codec.equals("avc") || codec.equals("x264")) {
                codec = "h264";
            }
            if (codec.equals("mjpg") || codec.equals("jpeg")) {
                codec = "mjpeg";
            }
            if (codec.equals("hevc") || codec.equals("h265") || codec.equals("prores")) {
                return "codec=\"" + codec
                        + "\" is not built in - use \"h264\" (exact YUV 4:2:0, large files) or \"mjpeg\" (compact)";
            }
            if (!codec.equals("h264") && !codec.equals("mjpeg")) {
                return "codec must be \"h264\" or \"mjpeg\" (\"hevc\" / \"prores\" are not built in)";
            }
        }
        String size = v.text("max_size");
        return size != null && !isByteSize(size) ? "max_size must be a size like \"25mb\"" : null;
    }

    // ─────────────────────────────────────────────────────────────────────
    // Helpers
    // ─────────────────────────────────────────────────────────────────────

    /**
     * {@code parseByteSize} of {@code io_common.cpp}: a number, then nothing,
     * {@code b}, {@code bytes}, {@code k}/{@code kb}/{@code kib}, {@code m}...,
     * {@code g}...; case and blanks around the unit do not matter.
     */
    static boolean isByteSize(String text) {
        String t = lower(text.trim());
        int i = 0;
        while (i < t.length() && (Character.isDigit(t.charAt(i)) || t.charAt(i) == '.')) {
            i++;
        }
        if (i == 0) {
            return false;
        }
        String unit = t.substring(i).trim();
        return Set.of("", "b", "bytes", "k", "kb", "kib", "m", "mb", "mib", "g", "gb", "gib").contains(unit);
    }

    private static String first(String... messages) {
        for (String m : messages) {
            if (m != null) {
                return m;
            }
        }
        return null;
    }

    private static String lower(String s) {
        return s.toLowerCase(Locale.ROOT);
    }

    /** {@code "4.0"} becomes {@code "4"}; any other number text is kept. */
    private static String whole(String number) {
        double d = Double.parseDouble(number);
        return d == Math.rint(d) && Math.abs(d) < 1e15 ? Long.toString((long) d) : number;
    }

    /** The values a call gives, read as written. */
    private record Values(Map<String, String> source) {

        /** @return the value's source text, or null when the call does not give it */
        String raw(String input) {
            String s = source.get(input);
            return s == null ? null : s.trim();
        }

        /** @return the text of a quoted literal; null for anything else or for {@code ""} (not given) */
        String text(String input) {
            String s = raw(input);
            if (s == null || s.length() < 2) {
                return null;
            }
            char q = s.charAt(0);
            if ((q != '"' && q != '\'') || s.charAt(s.length() - 1) != q || s.indexOf(q, 1) != s.length() - 1) {
                return null;
            }
            String body = s.substring(1, s.length() - 1);
            return body.isEmpty() ? null : body;
        }

        /** @return the text of a number literal, or null */
        String number(String input) {
            String s = raw(input);
            return s != null && NUMBER.matcher(s).matches() ? s : null;
        }

        /** @return {@code message} when a written-out text is not one of {@code allowed} */
        String choice(String input, boolean anyCase, Set<String> allowed, String message) {
            String t = text(input);
            if (t == null) {
                return null;
            }
            return allowed.contains(anyCase ? lower(t) : t) ? null : message;
        }
    }
}
