package language.syntax.syntax_checker.functions;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * The built-in usage table: the <b>one</b> source of built-in signatures for
 * the checker, the suggestions and the Command Window.
 *
 * <p>
 * Read once from {@code /language/builtin_signatures.tsv} (generated from
 * {@code nc.exe}'s own registry; replace that file when a new one comes). Each
 * row is a function with a parameter line; its {@code usage} text is read
 * into inputs:
 *
 * <pre>
 *   name           must be given                  allclose(A, B, ...)
 *   name=value     has a default                  allclose(..., atol=0.1)
 *   [, name]       may be left out                cross(a, b[, axis])
 *   [, name=]      keyword-only, may be left out  max(A[, B][, axis=])
 *   [x, y] = f()   several results                [q, r] = polydiv(p1, p2)
 *   [, a[, b]]     nested: b only with a          where(cond[, x[, y]])
 *   A1, A2, ...    any number of values (one at least); every input after
 *                  it is named only               concat(A1, A2, ..., axis=0)
 * </pre>
 *
 * The table's {@code keyword_only} column also names keyword-only inputs that
 * have a default ({@code angle(z[, B], deg=false)}); {@code named = no} marks a
 * function that refuses named values ({@code einsum}).
 *
 * <h3>Any number of values (new)</h3>
 * {@code A1, A2, ...} is {@code nc.exe}'s {@code *A} input
 * ({@code param_list.h}). The inputs before it are plain and can never be
 * named; the plain values go to them and then to {@code A}; the inputs after
 * it can only be named. So {@code concat(A, B, 1)} is three matrices, and
 * {@code concat(A, B, axs=1)} is {@code concat: there is no input named 'axs'}.
 *
 * <h3>Named values ({@link #namedValueError})</h3>
 * The rule is {@code nc.exe}'s ({@code callBuiltinNamed} in builtins.cpp,
 * {@code arg_binding.h}): keyword-only values are taken out first; then every
 * named value goes to the input of that name, the plain values fill the open
 * inputs left to right ({@link CallBinder}), and an open input takes its
 * default or, when it may be left out, stays out - but not before an input
 * that is given. The messages are {@code nc.exe}'s, without its
 * {@code Error: } prefix.
 */
public final class BuiltinSignatures {

    /** How an input of a built-in is given. */
    public enum Kind {
        /** {@code name}: must be given. */
        REQUIRED,
        /** {@code name=value}: takes its default when left out. */
        DEFAULTED,
        /** {@code [, name]}: may be left out. */
        OPTIONAL
    }

    /** One input that may be given in order (keyword-only inputs are kept apart). */
    public record Param(String name, Kind kind, String defaultText) {
    }

    /**
     * One row of the table. {@code params} and {@code keywordOnly} are
     * read-only lists filled while the table is read ({@link #parseRow});
     * nothing adds to them afterwards, by design. When {@code variadic},
     * {@code params} are the plain inputs before {@code A1, A2, ...} and
     * {@code keywordOnly} the inputs after it.
     */
    public record Signature(String section, String name, String usage, String description, String numpy,
            @SuppressWarnings("MismatchedQueryAndUpdateOfCollection") List<Param> params,
            List<String> keywordOnly, boolean acceptsNames, boolean variadic) {

        /**
         * @return the usage and the description, as the suggestion popup and
         *         {@code help} show them:
         *         {@code allclose(A, B, atol=0.1, rtol=0) - true if ...}
         */
        public String oneLine() {
            return usage + " - " + description;
        }

        /**
         * @return every input that may be named: in-order inputs, then
         *         keyword-only ones; only the inputs after {@code A1, A2, ...}
         *         for a variadic function
         */
        public List<String> inputNames() {
            List<String> names = new ArrayList<>();
            if (!variadic) {
                params.forEach(p -> names.add(p.name()));
            }
            names.addAll(keywordOnly);
            return names;
        }
    }

    /** The table's location on the class path. */
    public static final String RESOURCE = "/language/builtin_signatures.tsv";

    /**
     * The parser's own calls: never named ({@code feval: its values cannot be
     * named - give them in order}).
     */
    public static final Set<String> PARSER_CALLS = Set.of(
            "deal", "feval", "grad", "taylor_series", "green_integral", "save_workspace", "load_workspace");

    /** {@code exp2}, {@code exp10}, {@code logaddexp2} ...: one value, never named. */
    private static final Pattern FAMILY = Pattern.compile("^(?:exp|logaddexp)\\d+$");

    private static final Pattern NUMBER = Pattern.compile("[+-]?(?:\\d+\\.?\\d*|\\.\\d+)(?:[eE][+-]?\\d+)?");

    private static volatile Map<String, Signature> table;

    private BuiltinSignatures() {
    }

    // ─────────────────────────────────────────────────────────────────────
    // Lookup
    // ─────────────────────────────────────────────────────────────────────

    /**
     * @param name a bare function name
     * @return its row, or null when the table has none
     */
    public static Signature find(String name) {
        return name == null ? null : table().get(name);
    }

    /** @return every row, in table order */
    public static Collection<Signature> all() {
        return table().values();
    }

    /** @return true for {@code exp2}, {@code exp10}, {@code logaddexp2} ... */
    public static boolean isFamilyName(String name) {
        return name != null && FAMILY.matcher(name).matches();
    }

    /**
     * The inputs a call of a built-in may still name, for the suggestion
     * popup: none for a built-in that refuses names.
     *
     * @param name  the called built-in
     * @param named the names the call already gives
     * @return the input names still open, in usage order
     */
    public static List<String> openInputs(String name, Collection<String> named) {
        Signature sig = find(name);
        if (sig == null || !sig.acceptsNames()) {
            return List.of();
        }
        List<String> open = new ArrayList<>();
        for (String input : sig.inputNames()) {
            if (!named.contains(input)) {
                open.add(input);
            }
        }
        return open;
    }

    // ─────────────────────────────────────────────────────────────────────
    // Named values
    // ─────────────────────────────────────────────────────────────────────

    /**
     * Checks a call of a built-in that names at least one value.
     *
     * @param name     the called name (not a function of the script)
     * @param argNames per argument, in written order: {@code ""} for a plain
     *                 value, the name for a named one
     * @param argTexts per argument, the value's text (after {@code name=} for
     *                 a named one); used only for keyword-only literals
     * @param builtin  true when {@code name} is a known built-in at all
     * @return {@code nc.exe}'s message, or null when the call is fine (or not known)
     */
    public static String namedValueError(String name, List<String> argNames, List<String> argTexts,
            boolean builtin) {
        if (PARSER_CALLS.contains(name)) {
            return name + ": its values cannot be named - give them in order";
        }
        if (isFamilyName(name)) {
            return name + ": its value cannot be named - give it in order";
        }
        Signature sig = find(name);
        if (sig == null) {
            return builtin ? name + ": its values cannot be named yet - give them in order" : null;
        }
        if (!sig.acceptsNames()) {
            return name + ": its values cannot be named yet - give them in order";
        }
        return sig.variadic() ? bindVariadic(sig, argNames) : bind(sig, argNames, argTexts);
    }

    /** {@code normalizeVariadicCall} of {@code param_list.h}, with its messages. */
    private static String bindVariadic(Signature sig, List<String> argNames) {
        String usage = " (usage: " + sig.usage() + ")";
        int plain = 0;
        boolean sawNamed = false;
        List<String> named = new ArrayList<>();
        for (String n : argNames) {
            if (n.isEmpty()) {
                if (sawNamed) {
                    return sig.name() + ": a value without a name cannot follow a named one" + usage;
                }
                plain++;
                continue;
            }
            sawNamed = true;
            if (!sig.keywordOnly().contains(n)) {
                return sig.name() + ": there is no input named '" + n + "'" + usage;
            }
            if (named.contains(n)) {
                return sig.name() + ": input '" + n + "' is given twice" + usage;
            }
            named.add(n);
        }
        int needed = sig.params().size() + 1;
        if (plain < needed) {
            return sig.name() + ": at least " + needed + " value(s) are needed" + usage;
        }
        return null;
    }

    private static String bind(Signature sig, List<String> argNames, List<String> argTexts) {
        String name = sig.name();
        String usage = " (usage: " + sig.usage() + ")";

        // 1. Keyword-only values come out first.
        List<String> restNames = new ArrayList<>();
        Map<String, String> keywordValues = new LinkedHashMap<>();
        for (int k = 0; k < argNames.size(); k++) {
            String n = argNames.get(k);
            if (!n.isEmpty() && sig.keywordOnly().contains(n)) {
                if (keywordValues.containsKey(n)) {
                    return name + ": input '" + n + "' is given more than once" + usage;
                }
                keywordValues.put(n, k < argTexts.size() ? argTexts.get(k).trim() : "");
            } else {
                restNames.add(n);
            }
        }

        // 2. The rest against the inputs given in order.
        List<String> inputs = new ArrayList<>();
        boolean[] hasDefault = new boolean[sig.params().size()];
        for (int i = 0; i < sig.params().size(); i++) {
            Param p = sig.params().get(i);
            inputs.add(p.name());
            hasDefault[i] = p.kind() != Kind.REQUIRED;
        }
        CallBinder.Binding binding = CallBinder.bind(inputs, hasDefault, restNames);
        if (!binding.fits()) {
            return name + ": " + binding.error() + usage;
        }

        // 3. An input that may be left out must not be left out before one
        // that is given (nc.exe drops only trailing ones).
        int last = -1;
        boolean[] present = new boolean[inputs.size()];
        for (int i = 0; i < inputs.size(); i++) {
            present[i] = binding.source()[i] >= 0 || sig.params().get(i).kind() == Kind.DEFAULTED;
            if (present[i]) {
                last = i;
            }
        }
        for (int i = 0; i < last; i++) {
            if (!present[i]) {
                String later = "";
                for (int k = i + 1; k <= last; k++) {
                    if (present[k]) {
                        later = inputs.get(k);
                        break;
                    }
                }
                return name + ": input '" + inputs.get(i) + "' must be given too when '" + later + "' is" + usage;
            }
        }

        // 4. The keyword-only rules nc.exe checks itself; a value is judged
        // only when it is written as a literal.
        String axis = keywordValues.get("axis");
        if (axis != null && ("max".equals(name) || "min".equals(name))) {
            int given = 0;
            for (int i = 0; i < inputs.size(); i++) {
                given = present[i] ? i + 1 : given;
            }
            if (given > 1) {
                return name + ": axis works with one value - " + name + "(A, axis=0) - not with "
                        + name + "(A, B)";
            }
            if (isLiteral(axis) && !isWholeLiteral(axis)) {
                return name + ": axis must be a whole number (0, 1, ..., or -1 for the last axis)";
            }
        }
        String deg = keywordValues.get("deg");
        if (deg != null && "angle".equals(name) && isLiteral(deg) && !"true".equals(deg)
                && !"false".equals(deg)) {
            return "angle: deg must be true or false";
        }
        return null;
    }

    /** A number, a text or {@code true}/{@code false} written out. */
    private static boolean isLiteral(String text) {
        return NUMBER.matcher(text).matches() || text.startsWith("\"") || text.startsWith("'")
                || "true".equals(text) || "false".equals(text);
    }

    private static boolean isWholeLiteral(String text) {
        if (!NUMBER.matcher(text).matches()) {
            return false;
        }
        try {
            double d = Double.parseDouble(text);
            return Double.isFinite(d) && d == Math.rint(d);
        } catch (NumberFormatException e) {
            return false;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // Reading the table
    // ─────────────────────────────────────────────────────────────────────

    private static Map<String, Signature> table() {
        Map<String, Signature> t = table;
        if (t == null) {
            synchronized (BuiltinSignatures.class) {
                t = table;
                if (t == null) {
                    t = Collections.unmodifiableMap(load());
                    table = t;
                }
            }
        }
        return t;
    }

    private static Map<String, Signature> load() {
        Map<String, Signature> rows = new LinkedHashMap<>();
        try (InputStream in = BuiltinSignatures.class.getResourceAsStream(RESOURCE)) {
            if (in == null) {
                System.err.println("BuiltinSignatures: " + RESOURCE + " is missing");
                return rows;
            }
            BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            boolean header = true;
            for (String line = reader.readLine(); line != null; line = reader.readLine()) {
                if (line.isBlank() || line.startsWith("#")) {
                    continue;
                }
                if (header) {
                    header = false; // the column names
                    continue;
                }
                String[] cells = line.split("\t", -1);
                if (cells.length < 7) {
                    System.err.println("BuiltinSignatures: skipped a row with " + cells.length + " columns: " + line);
                    continue;
                }
                Signature sig = parseRow(cells);
                if (sig != null) {
                    rows.put(sig.name(), sig);
                }
            }
        } catch (IOException e) {
            System.err.println("BuiltinSignatures: could not read " + RESOURCE + ": " + e.getMessage());
        }
        return rows;
    }

    private static Signature parseRow(String[] cells) {
        String name = cells[1].trim();
        String usage = cells[2].trim();
        List<String> keywordOnly = new ArrayList<>();
        for (String k : cells[5].split(",")) {
            if (!k.isBlank()) {
                keywordOnly.add(k.trim());
            }
        }
        List<Param> params = new ArrayList<>();
        String call = callPart(usage, name);
        int dots = variadicStart(call);
        if (dots >= 0) {
            // `idx, c1, c2, ..., axis=0`: the plain inputs before the
            // repeated one, then the inputs that can only be named.
            List<String> before = splitTopLevel(call.substring(0, dots));
            for (int i = 0; i < before.size() - 2; i++) {
                params.add(new Param(before.get(i), Kind.REQUIRED, null));
            }
            for (String after : splitTopLevel(call.substring(dots + 3))) {
                int eq = after.indexOf('=');
                String input = (eq < 0 ? after : after.substring(0, eq)).trim();
                if (!input.isEmpty() && !keywordOnly.contains(input)) {
                    keywordOnly.add(input);
                }
            }
        } else {
            parseInputs(call, params, keywordOnly, false);
        }
        boolean accepts = !"no".equalsIgnoreCase(cells[6].trim());
        return new Signature(cells[0].trim(), name, usage, cells[3].trim(), cells[4].trim(),
                Collections.unmodifiableList(params), Collections.unmodifiableList(keywordOnly), accepts,
                dots >= 0);
    }

    /**
     * @return the offset of the {@code ...} of {@code A1, A2, ...} at bracket
     *         depth zero and outside quotes, or -1
     */
    private static int variadicStart(String call) {
        char quote = 0;
        int depth = 0;
        for (int i = 0; i + 2 < call.length(); i++) {
            char c = call.charAt(i);
            if (quote != 0) {
                quote = c == quote ? 0 : quote;
            } else if (c == '"' || c == '\'') {
                quote = c;
            } else if (c == '(' || c == '[') {
                depth++;
            } else if (c == ')' || c == ']') {
                depth--;
            } else if (depth == 0 && call.startsWith("...", i)) {
                return i;
            }
        }
        return -1;
    }

    /** The non-blank pieces of {@code text} split on commas outside quotes and brackets. */
    private static List<String> splitTopLevel(String text) {
        List<String> pieces = new ArrayList<>();
        StringBuilder piece = new StringBuilder();
        char quote = 0;
        int depth = 0;
        for (int i = 0; i <= text.length(); i++) {
            char c = i < text.length() ? text.charAt(i) : ',';
            if (quote != 0) {
                quote = c == quote ? 0 : quote;
            } else if (c == '"' || c == '\'') {
                quote = c;
            } else if (c == '(' || c == '[') {
                depth++;
            } else if (c == ')' || c == ']') {
                depth--;
            } else if (c == ',' && depth == 0) {
                if (!piece.toString().isBlank()) {
                    pieces.add(piece.toString().trim());
                }
                piece.setLength(0);
                continue;
            }
            piece.append(c);
        }
        return pieces;
    }

    /** The text inside {@code name( ... )}; the {@code [x, y] =} results are not inputs. */
    private static String callPart(String usage, String name) {
        int at = usage.indexOf(name + "(");
        if (at < 0) {
            return "";
        }
        int open = at + name.length();
        int depth = 0;
        char quote = 0;
        for (int i = open; i < usage.length(); i++) {
            char c = usage.charAt(i);
            if (quote != 0) {
                quote = c == quote ? 0 : quote;
            } else if (c == '"' || c == '\'') {
                quote = c;
            } else if (c == '(') {
                depth++;
            } else if (c == ')' && --depth == 0) {
                return usage.substring(open + 1, i);
            }
        }
        return usage.substring(open + 1);
    }

    /**
     * Reads {@code A, B, atol=0.1} / {@code A[, B][, axis=]}. A {@code [ ... ]}
     * group holds inputs that may be left out, and may hold another group
     * ({@code cond[, x[, y]]}); ending in {@code =} it is keyword-only. A name
     * in {@code keywordOnly} is never an in-order input.
     *
     * @param optional true inside a group: a plain name there may be left out
     */
    private static void parseInputs(String text, List<Param> params, List<String> keywordOnly, boolean optional) {
        StringBuilder piece = new StringBuilder();
        char quote = 0;
        int round = 0;
        for (int i = 0; i <= text.length(); i++) {
            char c = i < text.length() ? text.charAt(i) : ',';
            if (quote != 0) {
                piece.append(c);
                quote = c == quote ? 0 : quote;
                continue;
            }
            if (c == '"' || c == '\'') {
                quote = c;
                piece.append(c);
            } else if (c == '(') {
                round++;
                piece.append(c);
            } else if (c == ')') {
                round--;
                piece.append(c);
            } else if (c == '[' && round == 0) {
                addPlain(piece, params, keywordOnly, optional);
                int close = closingBracket(text, i);
                String group = text.substring(i + 1, close < 0 ? text.length() : close).trim();
                if (group.startsWith(",")) {
                    group = group.substring(1).trim();
                }
                if (group.endsWith("=")) {
                    String kw = group.substring(0, group.length() - 1).trim();
                    if (!keywordOnly.contains(kw)) {
                        keywordOnly.add(kw);
                    }
                } else if (!group.isEmpty()) {
                    parseInputs(group, params, keywordOnly, true);
                }
                i = close < 0 ? text.length() : close;
            } else if (c == ',' && round == 0) {
                addPlain(piece, params, keywordOnly, optional);
            } else {
                piece.append(c);
            }
        }
    }

    /** @return the {@code ]} that closes the {@code [} at {@code open}, quotes skipped, or -1 */
    private static int closingBracket(String text, int open) {
        int depth = 0;
        char quote = 0;
        for (int i = open; i < text.length(); i++) {
            char c = text.charAt(i);
            if (quote != 0) {
                quote = c == quote ? 0 : quote;
            } else if (c == '"' || c == '\'') {
                quote = c;
            } else if (c == '[') {
                depth++;
            } else if (c == ']' && --depth == 0) {
                return i;
            }
        }
        return -1;
    }

    private static void addPlain(StringBuilder piece, List<Param> params, List<String> keywordOnly,
            boolean optional) {
        String p = piece.toString().trim();
        piece.setLength(0);
        if (p.isEmpty() || p.startsWith("\"")) {
            return; // nothing, or a sample text such as einsum's "ij,jk->ik"
        }
        int eq = p.indexOf('=');
        String inputName = (eq < 0 ? p : p.substring(0, eq)).trim();
        if (keywordOnly.contains(inputName)) {
            return;
        }
        if (eq < 0) {
            params.add(new Param(inputName, optional ? Kind.OPTIONAL : Kind.REQUIRED, null));
        } else {
            params.add(new Param(inputName, Kind.DEFAULTED, p.substring(eq + 1).trim()));
        }
    }
}
