package language.syntax.syntax_checker.functions;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import language.syntax.syntax_checker.core.Analyzer;
import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.core.Findings;
import language.syntax.syntax_checker.core.Lexis;
import language.syntax.syntax_checker.core.Rule;
import language.syntax.syntax_checker.core.SourceModel;
import language.syntax.syntax_checker.core.TargetList;
import language.syntax.syntax_checker.structure.BlockHeaderGrammar;

/**
 * Checks every call whose definition the file holds against that definition,
 * the way {@code nc.exe} matches it: names first, then plain values from the
 * left, then defaults ({@link CallBinder}).
 *
 * <h3>What is checked</h3>
 * <table>
 * <caption>Calls and what they are matched against</caption>
 * <tr><td>{@code f(...)}</td><td>the versions of function {@code f} in this file</td></tr>
 * <tr><td>{@code Shape(...)}</td><td>the constructors ({@code function base}) of {@code Shape}, then of its
 * parents, nearest first</td></tr>
 * <tr><td>{@code s.area(...)}</td><td>the methods named {@code area} of {@code s}'s class and its parents, when
 * {@code s}'s class is known: {@code s = Shape(...)} is its only assignment in that scope, or {@code s} is
 * {@code base} inside a method</td></tr>
 * <tr><td>{@code parent(...)}</td><td>inside a constructor: the constructors of the class's parent</td></tr>
 * <tr><td>{@code allclose(A, B, atol=0.2)}</td><td>a built-in with a parameter line: matched against its
 * usage ({@link BuiltinSignatures}), keyword-only inputs ({@code max(A, axis=0)}) included</td></tr>
 * <tr><td>{@code sqrt(x=4)}</td><td>any other built-in: its values cannot be named ({@link BuiltinNames})</td></tr>
 * <tr><td>{@code P(2)}</td><td>{@code P} holds a poly1d ({@code P = poly1d(...)}, its only assignment, not
 * inside an if / for / while): exactly one plain value</td></tr>
 * <tr><td>{@code x.area(scale=1)}</td><td>{@code x} is a number, text or matrix: {@code .area} would be a
 * built-in, whose values cannot be named</td></tr>
 * </table>
 *
 * A call fits when <b>any</b> version fits. With one version, the error is
 * that version's own ({@code input 'a' was not given ...}); with several, it
 * lists them ({@code no version of function 'f' fits this call; it has ...}).
 * Versions differ in their number of inputs, so two fitting versions never use
 * the same number of defaults: a call is never ambiguous.
 *
 * <h3>When the checker stays silent</h3>
 * A false error is worse than none, so nothing is reported when the target
 * cannot be known for sure: a name the file also assigns (it may hold
 * {@code @f}, or a variable may shadow a class), an object assigned more than
 * once in its scope, a class whose parent is not in this file, a script's
 * function ({@code ABC.f(...)}), a class with no constructor of its own or
 * inherited, a call on an unknown receiver.
 *
 * <p>
 * Messages carry {@code nc.exe}'s texts: the target's label, what is wrong,
 * and the header it was matched against:
 * {@code function 'G': input 'a' was not given and has no default value (defined as y = G(a, b=100, c=1000))}.
 */
public final class CallAnalyzer implements Analyzer {

    /** {@code name =} at the start of an argument; {@code ==} is a comparison. */
    private static final Pattern NAMED = Pattern.compile("^(" + BlockHeaderGrammar.IDENT + ")\\s*=(?!=)");

    /** Words that may stand before {@code (} without being a call. */
    private static final Set<String> NOT_CALLS = Set.of(
            "if", "elseif", "elif", "while", "for", "return", "not", "and", "or", "in", "is_in",
            "is_not_in", "publish", "print", "function", "class");

    /** nc.exe's words for {@code P(x=2)} / {@code P(1, 2)} on a poly1d variable. */
    static final String POLY1D_CALL = "%s is a poly1d: it takes one value in order, e.g. %s(2)";
    static final String NOT_AN_OBJECT = "'%s' is not an object, so '.%s(...)' is a built-in, whose values cannot "
            + "be named - give them in order";
    static final String RESERVED_CALL = "'.%s(...)' is built in, so its values cannot be named - give them in order";

    /** What a variable is known to hold at a call. */
    private enum Kind {
        /** Not known: assigned more than once, from a call, an input ... */
        UNKNOWN,
        /** A number, a text, true/false, a matrix or a dict: never an object. */
        NOT_OBJECT,
        /** An object of a class in this file. */
        INSTANCE,
        /** A poly1d value: {@code P = poly1d([2, 3, 1])}, callable as {@code P(x)}. */
        POLY1D
    }

    private record Known(Kind kind, String className) {
        static final Known UNKNOWN = new Known(Kind.UNKNOWN, null);
    }

    /** One open block while walking. */
    private record Frame(String closer, String declaringClass, Scope scope) {
    }

    /**
     * One function body (or the file): the variables it assigns, each with
     * what it holds when it is assigned exactly once.
     */
    private static final class Scope {
        final String ownerClass;
        final String functionName;
        final Map<String, Known> variables = new HashMap<>();

        Scope(String ownerClass, String functionName) {
            this.ownerClass = ownerClass;
            this.functionName = functionName;
        }

        void assign(String name, Known what) {
            variables.merge(name, what, (was, now) -> Known.UNKNOWN);
        }

        Known lookup(String name) {
            if ("base".equals(name) && ownerClass != null) {
                return new Known(Kind.INSTANCE, ownerClass);
            }
            return variables.getOrDefault(name, Known.UNKNOWN);
        }

        boolean isConstructor() {
            return ownerClass != null && "base".equals(functionName);
        }
    }

    @Override
    public void analyze(SourceModel model, CheckContext context, Findings out) {
        ScriptDefinitions defs = ScriptDefinitions.of(model);
        Map<Integer, Scope> scopes = collectScopes(model, defs);

        Deque<Frame> frames = new ArrayDeque<>();
        Scope file = scopes.get(-1);
        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed() || line.isBlank()) {
                continue;
            }
            String masked = line.masked();
            String first = BlockHeaderGrammar.firstWord(masked.trim());
            if (BlockHeaderGrammar.isCloser(first)) {
                pop(frames, first);
                continue;
            }
            BlockHeaderGrammar.Header header = BlockHeaderGrammar.parse(masked);
            if (header != null && header.kind() == BlockHeaderGrammar.Kind.CLASS) {
                frames.push(new Frame("csend", header.name(), current(frames, file)));
                continue;
            }
            if (header != null && header.kind() == BlockHeaderGrammar.Kind.FUNCTION) {
                Scope body = scopes.getOrDefault(line.index(), new Scope(null, null));
                frames.push(new Frame("fnend", null, body));
                continue; // the header itself is BlockHeaderGrammar's
            }
            if (header != null && header.kind().opensBlock()) {
                frames.push(new Frame(header.kind().closer(), null, current(frames, file)));
            }
            String message = checkLine(masked, current(frames, file), defs, context);
            if (message != null) {
                out.add(line.index(), Rule.CALL_MATCH, message);
            }
        }
    }

    // =====================================================================
    // One line
    // =====================================================================

    /** @return the first call on the line that does not fit, or null */
    private static String checkLine(String m, Scope scope, ScriptDefinitions defs, CheckContext context) {
        for (int open = m.indexOf('('); open >= 0; open = m.indexOf('(', open + 1)) {
            int nameEnd = Lexis.prevNonSpace(m, open - 1) + 1;
            int nameStart = nameEnd;
            while (nameStart > 0 && Lexis.isIdentPart(m.charAt(nameStart - 1))) {
                nameStart--;
            }
            if (nameStart == nameEnd || !Lexis.isIdentStart(m.charAt(nameStart))) {
                continue;
            }
            String name = m.substring(nameStart, nameEnd);
            if (NOT_CALLS.contains(name)) {
                continue;
            }
            int close = Lexis.matchingClose(m, open);
            if (close < 0) {
                return null; // unbalanced: BracketAnalyzer's
            }
            String inner = m.substring(open + 1, close);
            List<String> argNames = argumentNames(inner);
            if (argNames == null) {
                continue; // an empty argument: another check reports it
            }
            List<String> argTexts = argumentValues(inner);

            String message;
            int dot = Lexis.prevNonSpace(m, nameStart - 1);
            if (dot >= 0 && m.charAt(dot) == '.') {
                message = checkMethod(m, dot, name, argNames, scope, defs);
            } else {
                message = checkCall(name, argNames, argTexts, scope, defs, context);
            }
            if (message != null) {
                return message;
            }
        }
        return null;
    }

    /**
     * @return one entry per argument: {@code ""} for a plain value, the name
     *         for a named one; null when an argument is empty ({@code f(1,,2)})
     */
    private static List<String> argumentNames(String inner) {
        List<String> names = new ArrayList<>();
        if (inner.isBlank()) {
            return names;
        }
        for (String argument : Lexis.splitTopLevel(inner, ',')) {
            String a = argument.trim();
            if (a.isEmpty()) {
                return null;
            }
            Matcher named = NAMED.matcher(a);
            names.add(named.find() ? named.group(1) : "");
        }
        return names;
    }

    /** Per argument, its value's text: what follows {@code name =} for a named one. */
    private static List<String> argumentValues(String inner) {
        List<String> values = new ArrayList<>();
        if (inner.isBlank()) {
            return values;
        }
        for (String argument : Lexis.splitTopLevel(inner, ',')) {
            String a = argument.trim();
            Matcher named = NAMED.matcher(a);
            values.add(named.find() ? a.substring(named.end()).trim() : a);
        }
        return values;
    }

    private static boolean anyNamed(List<String> argNames) {
        for (String n : argNames) {
            if (!n.isEmpty()) {
                return true;
            }
        }
        return false;
    }

    /** {@code f(...)}, {@code Shape(...)}, {@code parent(...)}, {@code sqrt(...)}. */
    private static String checkCall(String name, List<String> argNames, List<String> argTexts, Scope scope,
            ScriptDefinitions defs, CheckContext context) {
        // A variable holding a poly1d wins over a function of the same name.
        if (scope.lookup(name).kind() == Kind.POLY1D) {
            return argNames.size() == 1 && argNames.get(0).isEmpty() ? null
                    : String.format(POLY1D_CALL, name, name);
        }
        if ("parent".equals(name) && scope.isConstructor() && !defs.isAssigned(name)) {
            ScriptDefinitions.ClassDef own = defs.classDef(scope.ownerClass);
            String parent = own == null ? null : own.parent();
            if (parent == null || defs.classDef(parent) == null || defs.chainLeavesFile(parent)) {
                return null;
            }
            return match(constructorsOf(parent, defs), argNames,
                    "the constructor of parent class '" + parent + "'");
        }
        if (defs.isAssigned(name) || context.scripts().contains(name)) {
            return null; // may be a variable, a handle or a script where it is called
        }
        if (defs.isFunction(name)) {
            return match(defs.functions(name), argNames, "function '" + name + "'");
        }
        if (defs.classDef(name) != null) {
            if (defs.chainLeavesFile(name)) {
                return null;
            }
            return match(constructorsOf(name, defs), argNames, "the constructor of class '" + name + "'");
        }
        if (anyNamed(argNames)) {
            // A built-in: its usage line decides (nc.exe's callBuiltinNamed).
            return BuiltinSignatures.namedValueError(name, argNames, argTexts,
                    BuiltinNames.all().contains(name));
        }
        return null;
    }

    /** {@code receiver.method(...)}. */
    private static String checkMethod(String m, int dot, String method, List<String> argNames, Scope scope,
            ScriptDefinitions defs) {
        if ("base".equals(method) || "info".equals(method)) {
            return null; // .base / .info: ClassMemberAnalyzer's
        }
        int receiverEnd = Lexis.prevNonSpace(m, dot - 1) + 1;
        int receiverStart = receiverEnd;
        while (receiverStart > 0 && Lexis.isIdentPart(m.charAt(receiverStart - 1))) {
            receiverStart--;
        }
        if (receiverStart == receiverEnd || !Lexis.isIdentStart(m.charAt(receiverStart))) {
            return null; // (expr).m(), a[0].m(): not known
        }
        int before = Lexis.prevNonSpace(m, receiverStart - 1);
        if (before >= 0 && m.charAt(before) == '.') {
            return null; // a.b.m(): not known
        }
        String receiver = m.substring(receiverStart, receiverEnd);
        Known known = scope.lookup(receiver);

        if (known.kind() == Kind.NOT_OBJECT) {
            return anyNamed(argNames) ? String.format(NOT_AN_OBJECT, receiver, method) : null;
        }
        if (known.kind() != Kind.INSTANCE || defs.chainLeavesFile(known.className())) {
            return null;
        }
        List<ScriptDefinitions.Version> versions = new ArrayList<>();
        for (ScriptDefinitions.ClassDef c : defs.chain(known.className())) {
            versions.addAll(c.methods(method));
        }
        if (versions.isEmpty()) {
            if (BuiltinNames.RESERVED_OBJECT_CALLS.contains(method) && anyNamed(argNames)) {
                return String.format(RESERVED_CALL, method);
            }
            return null;
        }
        String owner = versions.get(0).owner();
        return match(versions, argNames, "method '" + method + "' of class '" + owner + "'");
    }

    /** The constructors of a class and its parents, nearest first. */
    private static List<ScriptDefinitions.Version> constructorsOf(String className, ScriptDefinitions defs) {
        List<ScriptDefinitions.Version> versions = new ArrayList<>();
        for (ScriptDefinitions.ClassDef c : defs.chain(className)) {
            versions.addAll(c.constructors());
        }
        return versions;
    }

    /**
     * @return null when some version fits; otherwise the error, worded as
     *         {@code nc.exe} words it
     */
    private static String match(List<ScriptDefinitions.Version> versions, List<String> argNames, String label) {
        if (versions.isEmpty()) {
            return null; // nothing to match against: not known
        }
        CallBinder.Binding only = null;
        for (ScriptDefinitions.Version version : versions) {
            CallBinder.Binding binding = CallBinder.bind(version.inputs(), version.hasDefault(), argNames);
            if (binding.fits()) {
                return null;
            }
            only = binding;
        }
        if (versions.size() == 1) {
            return label + ": " + only.error() + " (defined as " + versions.get(0).definedAs() + ")";
        }
        List<String> shapes = new ArrayList<>();
        versions.forEach(v -> shapes.add(v.definedAs()));
        return "no version of " + label + " fits this call; it has " + String.join(", ", shapes);
    }

    // =====================================================================
    // What each variable holds
    // =====================================================================

    /**
     * Reads every scope once: the file (key -1) and each function body (key:
     * its header's line). A variable assigned exactly once in its scope keeps
     * what that assignment gave it; any second assignment makes it unknown.
     */
    private static Map<Integer, Scope> collectScopes(SourceModel model, ScriptDefinitions defs) {
        Map<Integer, Scope> scopes = new HashMap<>();
        Scope file = new Scope(null, null);
        scopes.put(-1, file);
        Deque<Frame> frames = new ArrayDeque<>();
        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed() || line.isBlank()) {
                continue;
            }
            String masked = line.masked();
            String first = BlockHeaderGrammar.firstWord(masked.trim());
            if (BlockHeaderGrammar.isCloser(first)) {
                pop(frames, first);
                continue;
            }
            BlockHeaderGrammar.Header header = BlockHeaderGrammar.parse(masked);
            Scope scope = current(frames, file);
            if (header != null && header.kind() == BlockHeaderGrammar.Kind.CLASS) {
                frames.push(new Frame("csend", header.name(), scope));
                continue;
            }
            if (header != null && header.kind() == BlockHeaderGrammar.Kind.FUNCTION) {
                String declaring = frames.isEmpty() ? null : frames.peek().declaringClass();
                Scope body = new Scope(declaring, header.name());
                for (String input : header.parameters()) {
                    body.assign(input, Known.UNKNOWN);
                }
                for (String output : header.outputs()) {
                    body.assign(output, Known.UNKNOWN);
                }
                scopes.put(line.index(), body);
                frames.push(new Frame("fnend", null, body));
                continue;
            }
            if (header != null && header.kind().opensBlock()) {
                frames.push(new Frame(header.kind().closer(), null, scope));
                if (header.kind() == BlockHeaderGrammar.Kind.FOR) {
                    int equals = Lexis.assignmentIndex(masked.trim());
                    if (equals > 0) {
                        scope.assign(masked.trim().substring(3, equals).trim(), Known.UNKNOWN);
                    }
                }
                continue;
            }
            boolean nested = insideControlBlock(frames);
            for (String statement : Lexis.splitStatements(masked)) {
                recordAssignment(statement.trim(), scope, defs, nested);
            }
        }
        return scopes;
    }

    /**
     * True inside an if / for / while of the current function (or the file):
     * an assignment there may not run, so it proves nothing about the
     * variable's kind at a later call.
     */
    private static boolean insideControlBlock(Deque<Frame> frames) {
        for (Frame frame : frames) {
            if ("fnend".equals(frame.closer()) || "csend".equals(frame.closer())) {
                return false;
            }
            return true; // the innermost frame is an if / for / while
        }
        return false;
    }

    private static void recordAssignment(String text, Scope scope, ScriptDefinitions defs, boolean nested) {
        int equals = Lexis.assignmentIndex(text);
        if (equals <= 0) {
            return;
        }
        String left = text.substring(0, equals).trim();
        String right = text.substring(equals + 1).trim();
        if (left.startsWith("[")) {
            for (TargetList.Target target : TargetList.parse(left).targets()) {
                if (!target.root().isEmpty()) {
                    scope.assign(target.root(), Known.UNKNOWN);
                }
            }
            return;
        }
        if (!Lexis.isIdentifier(left)) {
            // A[i] = v, obj.f = v: the variable changes but keeps its kind,
            // except that an element store proves nothing; leave it as it is.
            int end = left.isEmpty() || !Lexis.isIdentStart(left.charAt(0)) ? 0 : Lexis.scanIdent(left, 0);
            if (end > 0 && !"base".equals(left.substring(0, end))) {
                scope.variables.putIfAbsent(left.substring(0, end), Known.UNKNOWN);
            }
            return;
        }
        Known kind = kindOf(right, defs);
        // A poly1d made inside an if / for / while: not known for sure.
        scope.assign(left, nested && kind.kind() == Kind.POLY1D ? Known.UNKNOWN : kind);
    }

    /** What a right side gives: an object of a class here, a plain value, or unknown. */
    private static Known kindOf(String right, ScriptDefinitions defs) {
        if (right.isEmpty()) {
            return Known.UNKNOWN;
        }
        char c = right.charAt(0);
        if (Character.isDigit(c) || c == '.' || c == '"' || c == '\'' || c == '[' || c == '{'
                || ((c == '-' || c == '+') && right.length() > 1 && Character.isDigit(right.charAt(1)))
                || right.equals("true") || right.equals("false")) {
            return new Known(Kind.NOT_OBJECT, null);
        }
        if (Lexis.isIdentStart(c)) {
            int nameEnd = Lexis.scanIdent(right, 0);
            int open = Lexis.nextNonSpace(right, nameEnd);
            String name = right.substring(0, nameEnd);
            boolean wholeCall = open < right.length() && right.charAt(open) == '('
                    && Lexis.matchingClose(right, open) == right.length() - 1;
            if (wholeCall && defs.classDef(name) != null && !defs.isAssigned(name)) {
                return new Known(Kind.INSTANCE, name);
            }
            // poly1d(...) - unless the script defines or assigns its own poly1d.
            if (wholeCall && "poly1d".equals(name) && !defs.isFunction(name) && defs.classDef(name) == null
                    && !defs.isAssigned(name)) {
                return new Known(Kind.POLY1D, null);
            }
        }
        return Known.UNKNOWN;
    }

    // =====================================================================
    // Helpers
    // =====================================================================

    private static Scope current(Deque<Frame> frames, Scope file) {
        for (Frame frame : frames) {
            if ("fnend".equals(frame.closer())) {
                return frame.scope();
            }
        }
        return file;
    }

    private static void pop(Deque<Frame> frames, String closer) {
        for (Frame frame : frames) {
            if (frame.closer().equals(closer)) {
                Frame popped;
                do {
                    popped = frames.pop();
                } while (popped != frame);
                return;
            }
        }
    }
}
