package language.syntax.syntax_checker.functions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import language.syntax.syntax_checker.core.Analyzer;
import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.core.Findings;
import language.syntax.syntax_checker.core.Lexis;
import language.syntax.syntax_checker.core.Rule;
import language.syntax.syntax_checker.core.SourceModel;
import language.syntax.syntax_checker.structure.BlockHeaderGrammar;

/**
 * Checks the written-out option values of every data I/O call
 * ({@code read_*}, {@code load_*}, {@code save_*}, {@code io_*}: the rows of
 * the usage table's {@code importing_data} section) against
 * {@link IoOptionRules}.
 *
 * <p>
 * The values are matched to the inputs exactly as {@code nc.exe} matches them
 * ({@link CallBinder}): {@code save_csv("a.csv", T, quote="all")} and
 * {@code save_csv("a.csv", T, "", "# [Sheet: {name}]", "", ",", "auto", "all")}
 * both give {@code quote}. A call that does not bind is
 * {@link CallAnalyzer}'s to report; a name the script defines or assigns
 * itself is never read as the built-in.
 */
public final class IoOptionAnalyzer implements Analyzer {

    /** The usage table's section of the data I/O functions. */
    static final String SECTION = "importing_data";

    /** {@code name =} at the start of an argument; {@code ==} is a comparison. */
    private static final Pattern NAMED = Pattern.compile("^(" + BlockHeaderGrammar.IDENT + ")\\s*=(?!=)");

    @Override
    public void analyze(SourceModel model, CheckContext context, Findings out) {
        ScriptDefinitions defs = ScriptDefinitions.of(model);
        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed() || line.isBlank()) {
                continue;
            }
            String message = checkLine(line.masked(), line.code(), defs);
            if (message != null) {
                out.add(line.index(), Rule.IO_OPTION, message);
            }
        }
    }

    /**
     * @param m    the masked line (string bodies blank)
     * @param code the same line with its literals intact (same offsets)
     * @return the first refused value on the line, or null
     */
    private static String checkLine(String m, String code, ScriptDefinitions defs) {
        if (m.length() != code.length()) {
            return null;
        }
        for (int open = m.indexOf('('); open >= 0; open = m.indexOf('(', open + 1)) {
            int nameEnd = Lexis.prevNonSpace(m, open - 1) + 1;
            int nameStart = nameEnd;
            while (nameStart > 0 && Lexis.isIdentPart(m.charAt(nameStart - 1))) {
                nameStart--;
            }
            if (nameStart == nameEnd) {
                continue;
            }
            int before = Lexis.prevNonSpace(m, nameStart - 1);
            if (before >= 0 && m.charAt(before) == '.') {
                continue; // a method: D.read(...)
            }
            String name = m.substring(nameStart, nameEnd);
            BuiltinSignatures.Signature sig = BuiltinSignatures.find(name);
            if (sig == null || !SECTION.equals(sig.section()) || defs.isAssigned(name) || defs.isFunction(name)
                    || defs.classDef(name) != null) {
                continue;
            }
            int close = Lexis.matchingClose(m, open);
            if (close < 0) {
                return null; // unbalanced: BracketAnalyzer's
            }
            Map<String, String> values = bind(sig, m.substring(open + 1, close), code.substring(open + 1, close));
            String message = values == null ? null : IoOptionRules.check(name, values);
            if (message != null) {
                return message;
            }
        }
        return null;
    }

    /** @return per given input, its value's source text; null when the call does not bind */
    private static Map<String, String> bind(BuiltinSignatures.Signature sig, String maskedInner, String codeInner) {
        List<String> argNames = new ArrayList<>();
        List<String> argValues = new ArrayList<>();
        if (!maskedInner.isBlank()) {
            int start = 0;
            for (String part : Lexis.splitTopLevel(maskedInner, ',')) {
                String raw = codeInner.substring(start, start + part.length());
                start += part.length() + 1;
                String a = part.trim();
                if (a.isEmpty()) {
                    return null;
                }
                Matcher named = NAMED.matcher(a);
                if (named.find()) {
                    argNames.add(named.group(1));
                    int eq = raw.indexOf('=');
                    argValues.add(raw.substring(eq + 1).trim());
                } else {
                    argNames.add("");
                    argValues.add(raw.trim());
                }
            }
        }
        List<String> inputs = new ArrayList<>();
        boolean[] hasDefault = new boolean[sig.params().size()];
        for (int i = 0; i < sig.params().size(); i++) {
            inputs.add(sig.params().get(i).name());
            hasDefault[i] = sig.params().get(i).kind() != BuiltinSignatures.Kind.REQUIRED;
        }
        CallBinder.Binding binding = CallBinder.bind(inputs, hasDefault, argNames);
        if (!binding.fits()) {
            return null;
        }
        Map<String, String> values = new HashMap<>();
        for (int i = 0; i < inputs.size(); i++) {
            int source = binding.source()[i];
            if (source >= 0) {
                values.put(inputs.get(i), argValues.get(source));
            }
        }
        return values;
    }
}
