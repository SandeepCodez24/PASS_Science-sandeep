package language.syntax.syntax_checker.functions;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import language.syntax.syntax_checker.core.Lexis;
import language.syntax.syntax_checker.core.SourceModel;
import language.syntax.syntax_checker.core.TargetList;
import language.syntax.syntax_checker.structure.BlockHeaderGrammar;
import language.syntax.syntax_checker.structure.FunctionSignature;

/**
 * Every function, class, constructor and method a file defines, read once
 * from its headers -- what the call checker matches calls against.
 *
 * <h3>Versions</h3>
 * A function may have several versions with different numbers of inputs
 * ({@code combine(a)}, {@code combine(a, b)}). A later definition with the
 * same number of inputs <b>replaces</b> the earlier one, as in
 * {@code nc.exe}. A class's {@code function base(...)} is its constructor;
 * its other functions are its methods; its first parent is
 * {@code class Square(Shape):}'s {@code Shape}.
 *
 * <h3>Names that are also variables</h3>
 * {@link #isAssigned(String)} tells whether a name is ever given a value in
 * the file (left of {@code =}, a list of variables, a {@code for} variable,
 * an input). Such a name may hold a function handle or shadow a class at the
 * point of a call, which the checker cannot know, so it stays silent for it.
 *
 * <p>
 * Built from the cleaned {@link SourceModel}, so a header split over several
 * lines inside its brackets is one header here. The most recent result is
 * cached against the model.
 */
public final class ScriptDefinitions {

    /** One version of a function, constructor or method. */
    public static final class Version {
        private final FunctionSignature signature;
        private final String owner;
        private final int line;

        Version(FunctionSignature signature, String owner, int line) {
            this.signature = signature;
            this.owner = owner;
            this.line = line;
        }

        /** @return the header as read */
        public FunctionSignature signature() {
            return signature;
        }

        /** @return the class that defines it, or null for a plain function */
        public String owner() {
            return owner;
        }

        /** @return the zero-based line of its header */
        public int line() {
            return line;
        }

        /** @return the input names, in header order */
        public List<String> inputs() {
            return signature.inputNames();
        }

        /** @return per input, whether it has a default */
        public boolean[] hasDefault() {
            List<FunctionSignature.Input> inputs = signature.inputs();
            boolean[] defaults = new boolean[inputs.size()];
            for (int i = 0; i < defaults.length; i++) {
                defaults[i] = inputs.get(i).hasDefault();
            }
            return defaults;
        }

        /**
         * @return the {@code (defined as ...)} text: {@code y = G(a, b=100)}
         *         for a function or method, {@code Shape(w, h=1)} for a
         *         constructor
         */
        public String definedAs() {
            if (owner != null && "base".equals(signature.name())) {
                String call = signature.callText();
                return owner + call.substring(call.indexOf('('));
            }
            return signature.text();
        }
    }

    /** One class: its parent, constructors and methods. */
    public static final class ClassDef {
        private final String name;
        private final String parent;
        private final int line;
        private final Map<Integer, Version> constructors = new LinkedHashMap<>();
        private final Map<String, Map<Integer, Version>> methods = new LinkedHashMap<>();

        ClassDef(String name, String parent, int line) {
            this.name = name;
            this.parent = parent;
            this.line = line;
        }

        public String name() {
            return name;
        }

        /** @return the parent class name, or null */
        public String parent() {
            return parent;
        }

        /** @return the zero-based line of the header */
        public int line() {
            return line;
        }

        /** @return its own constructors (one per number of inputs) */
        public List<Version> constructors() {
            return List.copyOf(constructors.values());
        }

        /**
         * @param method a method name
         * @return its own versions of that method; empty when it has none
         */
        public List<Version> methods(String method) {
            Map<Integer, Version> versions = methods.get(method);
            return versions == null ? List.of() : List.copyOf(versions.values());
        }

        /** @return the names of its own methods */
        public Set<String> methodNames() {
            return Collections.unmodifiableSet(methods.keySet());
        }
    }

    private final Map<String, Map<Integer, Version>> functions = new LinkedHashMap<>();
    private final Map<String, ClassDef> classes = new LinkedHashMap<>();
    private final Set<String> assigned = new HashSet<>();

    private ScriptDefinitions() {
    }

    // =====================================================================
    // Queries
    // =====================================================================

    /**
     * @param name a function name
     * @return its versions (one per number of inputs); empty when undefined
     */
    public List<Version> functions(String name) {
        Map<Integer, Version> versions = functions.get(name);
        return versions == null ? List.of() : List.copyOf(versions.values());
    }

    /** @return true when a top-level function of that name exists */
    public boolean isFunction(String name) {
        return functions.containsKey(name);
    }

    /**
     * @param name a class name
     * @return the class, or null
     */
    public ClassDef classDef(String name) {
        return name == null ? null : classes.get(name);
    }

    /** @return every class, in header order */
    public List<ClassDef> classes() {
        return List.copyOf(classes.values());
    }

    /**
     * The class and its parents, nearest first. A parent that is not
     * defined in the file ends the chain; a loop is cut.
     *
     * @param name a class name
     * @return the chain; empty when the class is not defined here
     */
    public List<ClassDef> chain(String name) {
        List<ClassDef> chain = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        ClassDef current = classDef(name);
        while (current != null && seen.add(current.name())) {
            chain.add(current);
            current = classDef(current.parent());
        }
        return chain;
    }

    /** @return true when the chain reaches a parent that is not defined in this file */
    public boolean chainLeavesFile(String name) {
        List<ClassDef> chain = chain(name);
        if (chain.isEmpty()) {
            return true;
        }
        String last = chain.get(chain.size() - 1).parent();
        return last != null && !last.isBlank() && classDef(last) == null;
    }

    /**
     * @param name a name
     * @return true when the file ever gives it a value, so it may be a
     *         variable (or a handle) where it is called
     */
    public boolean isAssigned(String name) {
        return assigned.contains(name);
    }

    // =====================================================================
    // Building
    // =====================================================================

    private static final Object CACHE_LOCK = new Object();
    private static SourceModel cachedModel;
    private static ScriptDefinitions cached;

    /**
     * @param model a cleaned document
     * @return its definitions; never null
     */
    public static ScriptDefinitions of(SourceModel model) {
        synchronized (CACHE_LOCK) {
            if (model == cachedModel && cached != null) {
                return cached;
            }
        }
        ScriptDefinitions built = build(model);
        synchronized (CACHE_LOCK) {
            cachedModel = model;
            cached = built;
        }
        return built;
    }

    /** One open block while reading. */
    private record Frame(String closer, ClassDef declaring) {
    }

    private static ScriptDefinitions build(SourceModel model) {
        ScriptDefinitions defs = new ScriptDefinitions();
        Deque<Frame> frames = new ArrayDeque<>();
        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed() || line.isBlank()) {
                continue;
            }
            String masked = line.masked().trim();
            String first = BlockHeaderGrammar.firstWord(masked);
            if (BlockHeaderGrammar.isCloser(first)) {
                pop(frames, first);
                continue;
            }
            BlockHeaderGrammar.Header header = BlockHeaderGrammar.parse(line.masked(), line.code());
            if (header != null && header.kind() == BlockHeaderGrammar.Kind.CLASS) {
                ClassDef declared = null;
                if (header.name() != null) {
                    String parent = header.parameters().isEmpty() ? null : header.parameters().get(0);
                    declared = new ClassDef(header.name(), parent, line.index());
                    defs.classes.put(declared.name(), declared);
                }
                frames.push(new Frame("csend", declared));
                continue;
            }
            if (header != null && header.kind() == BlockHeaderGrammar.Kind.FUNCTION) {
                defs.addFunction(header, frames.peek(), line.index());
                frames.push(new Frame("fnend", null));
                continue;
            }
            if (header != null && header.kind().opensBlock()) {
                frames.push(new Frame(header.kind().closer(), null));
                if (header.kind() == BlockHeaderGrammar.Kind.FOR) {
                    defs.recordForVariable(masked);
                }
                continue;
            }
            for (String statement : Lexis.splitStatements(line.masked())) {
                defs.recordAssignment(statement);
            }
        }
        return defs;
    }

    private void addFunction(BlockHeaderGrammar.Header header, Frame enclosing, int line) {
        FunctionSignature signature = header.signature();
        if (signature == null || signature.name() == null || signature.error() != null) {
            return; // a broken header is BlockHeaderGrammar's to report; no call is checked against it
        }
        assigned.addAll(signature.inputNames());
        assigned.addAll(signature.outputs());
        int count = signature.inputs().size();
        ClassDef owner = enclosing == null ? null : enclosing.declaring();
        if (owner == null) {
            functions.computeIfAbsent(signature.name(), k -> new LinkedHashMap<>())
                    .put(count, new Version(signature, null, line));
        } else if ("base".equals(signature.name())) {
            owner.constructors.put(count, new Version(signature, owner.name(), line));
        } else {
            owner.methods.computeIfAbsent(signature.name(), k -> new LinkedHashMap<>())
                    .put(count, new Version(signature, owner.name(), line));
        }
    }

    private void recordForVariable(String masked) {
        int equals = Lexis.assignmentIndex(masked);
        if (equals > 0) {
            String variable = masked.substring("for".length(), equals).trim();
            if (Lexis.isIdentifier(variable)) {
                assigned.add(variable);
            }
        }
    }

    private void recordAssignment(String statement) {
        String text = statement.trim();
        int equals = Lexis.assignmentIndex(text);
        if (equals <= 0) {
            return;
        }
        String left = text.substring(0, equals).trim();
        if (left.startsWith("[")) {
            for (TargetList.Target target : TargetList.parse(left).targets()) {
                if (!target.root().isEmpty()) {
                    assigned.add(target.root());
                }
            }
            return;
        }
        if (left.startsWith("(") && left.endsWith(")")) {
            left = left.substring(1, left.length() - 1);
            for (String name : left.split(",")) {
                if (Lexis.isIdentifier(name.trim())) {
                    assigned.add(name.trim());
                }
            }
            return;
        }
        int end = Lexis.isIdentStart(left.isEmpty() ? ' ' : left.charAt(0)) ? Lexis.scanIdent(left, 0) : 0;
        if (end > 0) {
            assigned.add(left.substring(0, end));
        }
    }

    private static void pop(Deque<Frame> frames, String closer) {
        for (Frame frame : frames) {
            if (frame.closer().equals(closer)) {
                Frame popped;
                do {
                    popped = frames.pop();
                } while (popped != frame);
                return;
            }
        }
    }
}
