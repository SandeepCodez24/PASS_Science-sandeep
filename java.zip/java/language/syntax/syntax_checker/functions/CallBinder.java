package language.syntax.syntax_checker.functions;

import java.util.Arrays;
import java.util.List;

/**
 * Matches the values of one call to one version of a function, exactly as
 * {@code nc.exe} does. This is the most important rule of named values, so it
 * is kept apart, small and literal.
 *
 * <ol>
 * <li><b>Named values first.</b> Each goes to the input of that name.</li>
 * <li><b>Then the plain values</b>, in written order, fill the inputs still
 * open, from left to right -- wherever in the call they stand. In
 * {@code F(10, 20, A1=5, 30, 40)} the {@code 10} goes to {@code A2}, because
 * {@code A1} is already taken by name.</li>
 * <li>Every input still open takes its <b>default</b>; an open input with no
 * default is an error.</li>
 * </ol>
 *
 * <pre>
 *   function y = G(a, b=100, c=1000):
 *   G(1)          a=1                  2 defaults
 *   G(c=0, a=5)   a=5, c=0             1 default
 *   G(1, a=2)     a=2, b=1             1 default
 *   G()           input 'a' was not given and has no default value
 *   G(1, 2, 3, 4) it takes 3 inputs, but 4 values were given
 *   G(d=1)        there is no input named 'd' - its inputs are a, b, c
 *   G(a=1, a=2)   input 'a' is given more than once
 *   G(b=1, c=2, 3, 4)  it takes 3 inputs; 2 are given by name, which leaves 1 for 2 plain values
 * </pre>
 *
 * The texts are {@code nc.exe}'s; the caller puts the function's label in
 * front and its header behind ({@code function 'G': ... (defined as ...)}).
 */
public final class CallBinder {

    private CallBinder() {
    }

    /**
     * The outcome of one match.
     *
     * @param error        why the call does not fit, or null when it does
     * @param source       per input, the argument it takes (-1: its default)
     * @param defaultsUsed how many inputs took their default
     */
    public record Binding(String error, int[] source, int defaultsUsed) {

        /** @return true when the call fits this version */
        public boolean fits() {
            return error == null;
        }
    }

    /**
     * @param inputs     the version's input names, in header order
     * @param hasDefault per input, whether it has a default
     * @param argNames   the call's arguments in written order; {@code ""}
     *                   for a plain value, the name for a named one
     * @return the binding, or the error
     */
    public static Binding bind(List<String> inputs, boolean[] hasDefault, List<String> argNames) {
        int n = inputs.size();
        int[] source = new int[n];
        Arrays.fill(source, -1);
        boolean[] filled = new boolean[n];

        // Pass 1: named values.
        int plain = 0;
        int named = 0;
        for (int k = 0; k < argNames.size(); k++) {
            String name = argNames.get(k);
            if (name.isEmpty()) {
                plain++;
                continue;
            }
            named++;
            int j = inputs.indexOf(name);
            if (j < 0) {
                return error("there is no input named '" + name + "' - "
                        + (n == 0 ? "it takes no inputs" : "its inputs are " + String.join(", ", inputs)));
            }
            if (filled[j]) {
                return error("input '" + name + "' is given more than once");
            }
            filled[j] = true;
            source[j] = k;
        }

        int open = 0;
        for (boolean f : filled) {
            if (!f) {
                open++;
            }
        }
        if (plain > open) {
            return error(named == 0
                    ? "it takes " + count(n, "input") + ", but " + count(plain, "value") + " "
                            + (plain == 1 ? "was" : "were") + " given"
                    : "it takes " + count(n, "input") + "; " + named + " " + (named == 1 ? "is" : "are")
                            + " given by name, which leaves " + open + " for " + count(plain, "plain value"));
        }

        // Pass 2: plain values fill the open inputs from the left.
        int j = 0;
        for (int k = 0; k < argNames.size(); k++) {
            if (!argNames.get(k).isEmpty()) {
                continue;
            }
            while (filled[j]) {
                j++;
            }
            filled[j] = true;
            source[j] = k;
        }

        // Pass 3: defaults.
        int defaultsUsed = 0;
        for (int i = 0; i < n; i++) {
            if (filled[i]) {
                continue;
            }
            if (!hasDefault[i]) {
                return error("input '" + inputs.get(i) + "' was not given and has no default value");
            }
            defaultsUsed++;
        }
        return new Binding(null, source, defaultsUsed);
    }

    private static Binding error(String message) {
        return new Binding(message, new int[0], 0);
    }

    /** {@code 1 input}, {@code 3 inputs}. */
    private static String count(int n, String noun) {
        return n + " " + noun + (n == 1 ? "" : "s");
    }
}
