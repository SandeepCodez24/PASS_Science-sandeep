package language.syntax.syntax_checker.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import language.semantic.CodeSegments;

/**
 * The one shared view of a source file that every analyzer reads from.
 *
 * <h3>Order of operations (this order matters)</h3>
 * <ol>
 * <li><b>Continuations first</b>, exactly as {@code nc.exe} joins them
 * ({@code line_continuation.h}). A physical line whose last non-blank
 * characters are {@code ~~} (blanks after it are allowed) continues on the
 * next line: the {@code ~~} and the blanks before it are removed, the next
 * line's leading spaces and tabs are removed, and the two are joined with
 * <b>one space</b>. This repeats while the joined line still ends in
 * {@code ~~}. A {@code ~~} on the last line of the file is dropped.
 *
 * <p>
 * {@code ~~} at the end of a line continues inside a string (that is how a
 * long message is split), but not inside a comment: in {@code # note ~~} or a
 * commented-out split line ({@code \\ while A < B && ~~}) it is comment text,
 * and the next line stands on its own -- as in {@code nc.exe} since
 * 2026-10-28 ({@code line_continuation.h}). {@code x = 1 + ~~  # note} does
 * not continue either: that line does not end in {@code ~~}.
 *
 * <pre>
 *   X = "I am a long ~~
 *   message";                &rarr; X = "I am a long message";
 *   z = f(1, ~~
 *             c=10)          &rarr; z = f(1, c=10)
 * </pre>
 *
 * Where a continuation line starts means nothing: it opens or closes no
 * block and its indentation is not checked. Every check reads the joined
 * text, and an error is reported on the first physical line.</li>
 *
 * <li><b>Headers split inside their brackets (new).</b> A {@code function}
 * or {@code class} header whose {@code (} is still open at the end of a line
 * goes on on the next line, without {@code ~~}, as {@code nc.exe} reads a
 * line break inside {@code ( ... )} as a space:
 *
 * <pre>
 *   function y = f(a=1,
 *                  b=2):      &rarr; function y = f(a=1, b=2):
 * </pre>
 *
 * Each line's comment is dropped before it is joined, and the next line is
 * joined after one space with its own indentation removed. Such a line is
 * {@link Line#isBracketJoined()}: it is part of the header, and no
 * indentation rule applies to it. {@code ~~} works inside a header too.</li>
 *
 * <li><b>Strings next.</b> {@code "} and {@code '} are both delimiters and
 * each may appear inside the other; only the quote that opened a literal
 * closes it. A {@code '} directly after a value is the transpose operator
 * ({@link CodeSegments#isTranspose}), and the masked view shows it as a space:
 * every check then reads {@code C'} as the value {@code C}.</li>
 *
 * <li><b>Comments next.</b> {@code #} and {@code \\} begin a comment only
 * outside a literal.</li>
 *
 * <li><b>Absolute values next.</b> {@link AbsoluteBars} rewrites matched
 * {@code |...|} pairs as {@code (...)} in the masked view and records any bar
 * that is never closed or crosses a bracket.</li>
 *
 * <li><b>Extend operators last (new).</b> {@code M ,= X} is {@code M = [M, X]}
 * and {@code M ;= X} is {@code M = [M; X]}. A {@code ,} directly followed by
 * {@code =}, or a single {@code ;} directly followed by {@code =}, is one
 * operator ({@code M , = X} is not). The masked view reads it as a plain
 * assignment so no check takes {@code ;=} for the end of a statement: at
 * bracket depth zero the {@code ,} / {@code ;} becomes a space
 * ({@code M  = X}); inside a bracket, where it is never allowed, it becomes
 * {@code , } so only the extend check reports it. Each one is recorded in
 * {@link Line#extendOperators()}.</li>
 * </ol>
 *
 * <h3>Views per line</h3>
 * {@link Line#code()} has the comment removed and literals intact.
 * {@link Line#masked()} is the same text with every string <i>body</i> blanked
 * to spaces, character for character, and absolute values resolved.
 * {@link Line#head()} is the masked view of the <b>first physical line
 * alone</b>, whose offsets match the editor's columns; the editor's Enter key
 * reads it to place the caret on a new continuation line
 * ({@code ContinuationAnchor}).
 *
 * <h3>Line numbering</h3>
 * Indices are zero-based and match CodeArea paragraphs. A continuation group
 * is reported on the line that started it; the lines it swallowed are marked
 * {@link Line#isAbsorbed()} and carry empty text but keep their
 * {@link Line#raw()} text.
 */
public final class SourceModel {

    /** The long-line continuation token, valid only as the last token on a line. */
    public static final String CONTINUATION = "~~";

    /**
     * One extend operator, {@code ,=} or {@code ;=}, as written.
     *
     * @param offset where its {@code ,} / {@code ;} stands in {@link Line#masked()}
     * @param symbol {@code ','} or {@code ';'}
     * @param nested true when it stands inside a bracket, where it is never allowed
     */
    public record ExtendOperator(int offset, char symbol, boolean nested) {

        /** @return {@code ",="} or {@code ";="} */
        public String text() {
            return symbol + "=";
        }
    }

    /** One editor paragraph, cleaned. */
    public static final class Line {

        private final int index;
        private final int endIndex;
        private final int ownerIndex;
        private final String raw;
        private final String code;
        private final String masked;
        private final String head;
        private final boolean unterminatedString;
        private final List<AbsoluteBars.Fault> absoluteFaults;
        private final List<ExtendOperator> extendOperators;
        private final boolean bracketJoined;

        private Line(int index, int endIndex, int ownerIndex, String raw, String code, String masked,
                String head, boolean unterminatedString, List<AbsoluteBars.Fault> absoluteFaults,
                List<ExtendOperator> extendOperators, boolean bracketJoined) {
            this.index = index;
            this.endIndex = endIndex;
            this.ownerIndex = ownerIndex;
            this.raw = raw;
            this.code = code;
            this.masked = masked;
            this.head = head;
            this.unterminatedString = unterminatedString;
            this.absoluteFaults = absoluteFaults;
            this.extendOperators = extendOperators;
            this.bracketJoined = bracketJoined;
        }

        private static Line absorbed(int index, int owner, String raw, boolean bracketJoined) {
            return new Line(index, index, owner, raw, "", "", "", false, List.of(), List.of(), bracketJoined);
        }

        /**
         * True for a line folded into a function or class header because the
         * header's {@code (} was still open (no {@code ~~}). Its indentation
         * is free.
         */
        public boolean isBracketJoined() {
            return bracketJoined;
        }

        /** Zero-based index of this line, matching the CodeArea paragraph. */
        public int index() {
            return index;
        }

        /** Index of the last physical line folded into this one. */
        public int endIndex() {
            return endIndex;
        }

        /** True when this physical line was folded into an earlier one. */
        public boolean isAbsorbed() {
            return ownerIndex >= 0;
        }

        /** The line that swallowed this one, or -1. */
        public int ownerIndex() {
            return ownerIndex;
        }

        /** True when this line continues onto at least one following line. */
        public boolean isContinued() {
            return endIndex > index;
        }

        /** The untouched physical line. */
        public String raw() {
            return raw;
        }

        /** Continuations joined and comment removed; string literals intact. */
        public String code() {
            return code;
        }

        /** As {@link #code()}, string bodies blanked and absolute values resolved. */
        public String masked() {
            return masked;
        }

        /**
         * The masked first physical line on its own (the {@code ~~} removed),
         * with offsets equal to editor columns. Equal to {@link #masked()} for
         * a line that does not continue.
         */
        public String head() {
            return head;
        }

        /** True when a quote opened on this line and never closed. */
        public boolean hasUnterminatedString() {
            return unterminatedString;
        }

        /** Absolute values on this line that are never closed or cross a bracket. */
        public List<AbsoluteBars.Fault> absoluteFaults() {
            return absoluteFaults;
        }

        /** The {@code ,=} / {@code ;=} operators on this line, left to right. */
        public List<ExtendOperator> extendOperators() {
            return extendOperators;
        }

        /** True when nothing but whitespace survives cleaning. */
        public boolean isBlank() {
            return masked.trim().isEmpty();
        }
    }

    private final List<Line> lines;

    private SourceModel(List<Line> lines) {
        this.lines = Collections.unmodifiableList(lines);
    }

    private static final Object CACHE_LOCK = new Object();
    private static String cachedSource;
    private static SourceModel cachedModel;

    /**
     * Cleans a whole document. The most recent result is cached; the model is
     * immutable, so sharing it is safe.
     *
     * @param code raw editor text (may be null)
     * @return the cleaned model; never null
     */
    public static SourceModel of(String code) {
        String key = code == null ? "" : code;
        synchronized (CACHE_LOCK) {
            if (cachedModel != null && key.equals(cachedSource)) {
                return cachedModel;
            }
        }
        SourceModel model = build(key);
        synchronized (CACHE_LOCK) {
            cachedSource = key;
            cachedModel = model;
        }
        return model;
    }

    /** Every line, in order, including absorbed continuation lines. */
    public List<Line> lines() {
        return lines;
    }

    /** Number of physical lines, always equal to the editor's paragraph count. */
    public int size() {
        return lines.size();
    }

    /**
     * @param index zero-based line index
     * @return that line, or null when out of range
     */
    public Line line(int index) {
        return index >= 0 && index < lines.size() ? lines.get(index) : null;
    }

    /** The whole document in masked form, newlines preserved. */
    public String maskedDocument() {
        StringBuilder document = new StringBuilder();
        for (int i = 0; i < lines.size(); i++) {
            if (i > 0) {
                document.append('\n');
            }
            document.append(lines.get(i).masked());
        }
        return document.toString();
    }

    // ─────────────────────────────────────────────────────────────────────
    // Building
    // ─────────────────────────────────────────────────────────────────────

    private static SourceModel build(String code) {
        List<Line> built = new ArrayList<>();
        if (code.isEmpty()) {
            return new SourceModel(built);
        }

        String[] raw = code.split("\\R", -1);
        Line[] result = new Line[raw.length];

        int i = 0;
        while (i < raw.length) {
            int start = i;
            int end = i;
            StringBuilder joined = new StringBuilder();
            String firstSegment = null;
            boolean[] byBracket = new boolean[raw.length];

            while (true) {
                String current = raw[end];
                String trimmed = stripTrailingWhitespace(current);
                // A line joined onto the one above - after '~~', or inside a
                // header's open bracket - loses its leading spaces and tabs:
                // where it starts means nothing (nc.exe, line_continuation.h).
                String piece = end > start ? current.stripLeading() : current;

                // A line whose last non-blank characters are '~~' continues -
                // inside a string too - unless the '~~' is part of a comment
                // ('# note ~~', '\\ while A < B && ~~'): then it is comment
                // text and the next line is a line of its own, as in nc.exe.
                boolean marker = trimmed.endsWith(CONTINUATION)
                        && !endsInComment(joined + stripTrailingWhitespace(piece));
                boolean continues = marker && end + 1 < raw.length;

                if (marker && !continues) {
                    // '~~' on the last line of the file is simply dropped.
                    piece = stripTrailingWhitespace(piece);
                    piece = piece.substring(0, piece.length() - CONTINUATION.length());
                }

                if (!continues) {
                    // A function / class header with its '(' still open goes
                    // on on the next line; the comment of this line is not
                    // part of it.
                    String withoutComment = withoutComment(piece);
                    if (end + 1 < raw.length && !isInsideString(joined)
                            && opensHeaderBracket(joined + withoutComment)) {
                        if (firstSegment == null) {
                            firstSegment = withoutComment;
                        }
                        joined.append(withoutComment).append(' ');
                        end++;
                        byBracket[end] = true;
                        continue;
                    }
                    joined.append(piece);
                    break;
                }
                String withoutMarker = piece.substring(0, piece.length()
                        - (current.length() - trimmed.length()) - CONTINUATION.length());
                if (firstSegment == null) {
                    firstSegment = withoutMarker;
                }
                // The '~~' and the blanks before it are removed, and the two
                // lines are joined with exactly one space - as nc.exe does.
                joined.append(stripTrailingWhitespace(withoutMarker)).append(' ');
                end++;
            }

            Cleaned cleaned = clean(joined.toString());
            String head = firstSegment == null ? cleaned.masked : clean(firstSegment).masked;
            result[start] = new Line(start, end, -1, raw[start], cleaned.code, cleaned.masked,
                    head, cleaned.unterminatedString, cleaned.absoluteFaults, cleaned.extendOperators, false);
            for (int absorbed = start + 1; absorbed <= end; absorbed++) {
                result[absorbed] = Line.absorbed(absorbed, start, raw[absorbed], byBracket[absorbed]);
            }
            i = end + 1;
        }

        Collections.addAll(built, result);
        return new SourceModel(built);
    }

    private record Cleaned(String code, String masked, boolean unterminatedString,
            List<AbsoluteBars.Fault> absoluteFaults, List<ExtendOperator> extendOperators) {
    }

    /**
     * One left-to-right pass producing both views at once, so they cannot
     * disagree about where a string starts.
     */
    private static Cleaned clean(String text) {
        StringBuilder masked = new StringBuilder(text.length());
        char openQuote = 0;
        int transposeAt = -1;
        int commentAt = -1;

        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);

            if (openQuote != 0) {
                if (ch == openQuote && !Lexis.isEscaped(text, i)) {
                    openQuote = 0;
                    masked.append(ch);
                } else {
                    masked.append(' ');
                }
                continue;
            }
            if (ch == '\'' && CodeSegments.isTranspose(text, i, transposeAt)) {
                transposeAt = i;
                masked.append(' ');
                continue;
            }
            if ((ch == '"' || ch == '\'') && !Lexis.isEscaped(text, i)) {
                openQuote = ch;
                masked.append(ch);
                continue;
            }
            if (ch == '#' || (ch == '\\' && i + 1 < text.length() && text.charAt(i + 1) == '\\')) {
                commentAt = i;
                break;
            }
            masked.append(ch);
        }

        String code = commentAt >= 0 ? text.substring(0, commentAt) : text;
        AbsoluteBars.Resolution bars = AbsoluteBars.resolve(masked.toString());
        StringBuilder extended = new StringBuilder(bars.masked());
        List<ExtendOperator> operators = resolveExtendOperators(extended);
        return new Cleaned(code, extended.toString(), openQuote != 0, bars.faults(), operators);
    }

    /**
     * Finds every {@code ,=} / {@code ;=} in masked text and rewrites it in
     * place, offsets kept: {@code M ,= X} becomes {@code M  = X} at bracket
     * depth zero, and {@code [x ,= 3]} becomes {@code [x ,  3]} inside a
     * bracket. A {@code ;=} after another {@code ;} is not one.
     */
    private static List<ExtendOperator> resolveExtendOperators(StringBuilder masked) {
        List<ExtendOperator> found = new ArrayList<>();
        int depth = 0;
        for (int i = 0; i + 1 < masked.length(); i++) {
            char c = masked.charAt(i);
            if (Lexis.isOpenBracket(c)) {
                depth++;
            } else if (Lexis.isCloseBracket(c)) {
                depth = Math.max(0, depth - 1);
            } else if ((c == ',' || (c == ';' && (i == 0 || masked.charAt(i - 1) != ';')))
                    && masked.charAt(i + 1) == '=') {
                boolean nested = depth > 0;
                found.add(new ExtendOperator(i, c, nested));
                if (nested) {
                    masked.setCharAt(i, ',');
                    masked.setCharAt(i + 1, ' ');
                } else {
                    masked.setCharAt(i, ' ');
                }
                i++;
            }
        }
        return found.isEmpty() ? List.of() : Collections.unmodifiableList(found);
    }

    /** The text up to its {@code #} / {@code \\} comment (outside literals), trailing spaces removed. */
    private static String withoutComment(String text) {
        char openQuote = 0;
        int transposeAt = -1;
        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);
            if (openQuote != 0) {
                if (ch == openQuote && !Lexis.isEscaped(text, i)) {
                    openQuote = 0;
                }
                continue;
            }
            if (ch == '\'' && CodeSegments.isTranspose(text, i, transposeAt)) {
                transposeAt = i;
                continue;
            }
            if ((ch == '"' || ch == '\'') && !Lexis.isEscaped(text, i)) {
                openQuote = ch;
                continue;
            }
            if (ch == '#' || (ch == '\\' && i + 1 < text.length() && text.charAt(i + 1) == '\\')) {
                return stripTrailingWhitespace(text.substring(0, i));
            }
        }
        return stripTrailingWhitespace(text);
    }

    /** True when {@code text} is a function / class header whose round bracket is still open. */
    private static boolean opensHeaderBracket(String text) {
        return Lexis.opensHeaderBracket(clean(text).masked);
    }

    /** True when the end of {@code text} lies inside a {@code #} or {@code \\} comment. */
    private static boolean endsInComment(String text) {
        return scanEnd(text) == END_IN_COMMENT;
    }

    /** True when a string literal is still open at the end of {@code text}. */
    private static boolean isInsideString(CharSequence text) {
        return scanEnd(text.toString()) == END_IN_STRING;
    }

    private static final int END_IN_CODE = 0;
    private static final int END_IN_STRING = 1;
    private static final int END_IN_COMMENT = 2;

    /**
     * Where the end of {@code text} lies: in code, inside a string literal, or
     * inside a comment. A comment runs to the end of the text, and its markers
     * count only outside a literal.
     */
    private static int scanEnd(String s) {
        char openQuote = 0;
        int transposeAt = -1;
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (openQuote != 0) {
                if (ch == openQuote && !Lexis.isEscaped(s, i)) {
                    openQuote = 0;
                }
                continue;
            }
            if (ch == '\'' && CodeSegments.isTranspose(s, i, transposeAt)) {
                transposeAt = i;
                continue;
            }
            if ((ch == '"' || ch == '\'') && !Lexis.isEscaped(s, i)) {
                openQuote = ch;
                continue;
            }
            if (ch == '#' || (ch == '\\' && i + 1 < s.length() && s.charAt(i + 1) == '\\')) {
                return END_IN_COMMENT;
            }
        }
        return openQuote != 0 ? END_IN_STRING : END_IN_CODE;
    }

    private static String stripTrailingWhitespace(String text) {
        int end = text.length();
        while (end > 0 && Character.isWhitespace(text.charAt(end - 1))) {
            end--;
        }
        return text.substring(0, end);
    }
}
