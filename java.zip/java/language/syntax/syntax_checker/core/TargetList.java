package language.syntax.syntax_checker.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The one reading of a <b>list of variables</b> -- the square-bracket left
 * side of a destructuring assignment -- shared by every check that has to
 * know what it defines.
 *
 * <pre>
 *   [a, b, c] = [1, 2, "car"]       each name gets its own value
 *   [Q, R] = qr(A)                  several results of a call
 *   [a, b; c, d] = M                rows of names: M must be 2x2
 *   [~, i] = f(A)                   '~' skips a value
 *   [A[0], obj.x] = deal(0)         an index or a field may receive a value
 * </pre>
 *
 * <h3>Grammar</h3>
 * Entries are separated by {@code ,} and rows by a <b>single</b> {@code ;}
 * ({@code ;;} has no meaning in a list). An entry is a name, a name with
 * one or more indexes ({@code A[i]}, {@code A[i][j]}), a dotted field path
 * ({@code obj.field}), or {@code ~}. Every row holds the same number of
 * entries, and at least one entry is not {@code ~}.
 *
 * <h3>Where it is used</h3>
 * {@code AssignmentAnalyzer} reports a malformed list,
 * {@code UndefinedVariableAnalyzer} defines its names, and
 * {@code MatrixAnalyzer} leaves the bracket alone, since it is not a matrix.
 * Before this class the left side was a regular expression of
 * comma-separated names in {@code AssignmentAnalyzer} only, so
 * {@code [a, b; c, d] = M} and {@code [u, ~] = v} were refused there and
 * their names were never defined anywhere else.
 *
 * <p>
 * Input is masked text (string bodies blanked), as everywhere in the checker.
 */
public final class TargetList {

    private TargetList() {
    }

    /** The placeholder that skips one value. */
    public static final String SKIP = "~";

    // ---- messages (worded as the interpreter words them) --------------------

    static final String RAGGED =
            "every row of a list of variables needs the same number of names, e.g. [a, b; c, d] = M";
    static final String ALL_SKIPPED = "every entry of the list is '~' - there is nothing to assign";
    static final String EMPTY_LIST = "the list of variables is empty - write at least one name, e.g. [a, b] = f(...)";
    static final String EMPTY_ENTRY = "a name is missing in the list of variables (row %d): remove the extra ',' or ';'";
    static final String DOUBLE_SEPARATOR =
            "rows of a list of variables are separated by one ';' - ';;' has no meaning here";
    static final String BAD_ENTRY =
            "'%s' cannot receive a value: a list of variables holds names, A[...], obj.field or '~'";

    /** What one entry of the list is. */
    public enum Kind {
        /** {@code a} */
        NAME,
        /** {@code A[i]}, {@code A[i][j]}: changes {@code A}. */
        INDEXED,
        /** {@code obj.field}: changes {@code obj}. */
        FIELD,
        /** {@code ~} */
        SKIP
    }

    /**
     * One entry of the list.
     *
     * @param text   the entry as written, trimmed
     * @param kind   what it is
     * @param root   the variable it assigns to or changes ({@code A} for
     *               {@code A[i]}); empty for {@code ~}
     * @param suffix what follows the root ({@code [i]}, {@code .field});
     *               names in it are references, not definitions
     */
    public record Target(String text, Kind kind, String root, String suffix) {
    }

    /** The whole list: its rows, or the first reason it is malformed. Immutable. */
    public static final class Parsed {
        private final List<List<Target>> rows;
        private final String error;

        private Parsed(List<List<Target>> rows, String error) {
            this.rows = Collections.unmodifiableList(rows);
            this.error = error;
        }

        /** @return the rows; on an error, the entries that could be read */
        public List<List<Target>> rows() {
            return rows;
        }

        /** @return what is wrong, or null when the list is well formed */
        public String error() {
            return error;
        }

        public boolean isValid() {
            return error == null;
        }

        /** @return every entry, row after row */
        public List<Target> targets() {
            List<Target> all = new ArrayList<>();
            rows.forEach(all::addAll);
            return all;
        }

        /** @return how many entries the list holds, {@code ~} included */
        public int size() {
            return targets().size();
        }

        /** @return true when the list is one row */
        public boolean isSingleRow() {
            return rows.size() == 1;
        }
    }

    // =====================================================================
    // Recognising a list on the left of '='
    // =====================================================================

    /**
     * True when the statement's left side is a bracket of targets: the
     * statement starts with {@code [}, and its matching {@code ]} is directly
     * followed by an assignment {@code =}.
     *
     * @param statement one masked statement
     * @return true for {@code [a, b] = ...}
     */
    public static boolean startsStatement(String statement) {
        if (statement == null) {
            return false;
        }
        int open = Lexis.nextNonSpace(statement, 0);
        return open < statement.length() && statement.charAt(open) == '[' && closesBeforeAssignment(statement, open);
    }

    /**
     * True when the {@code [} at {@code open} begins a list of variables:
     * it is the first thing in its statement (start of the text, or after a
     * {@code ;} at bracket depth zero) and its matching {@code ]} is
     * followed by an assignment {@code =}.
     *
     * @param s    one masked logical line
     * @param open offset of a {@code [}
     * @return true for the {@code [} of {@code x = 1; [a, b] = f()}
     */
    public static boolean isListOpen(String s, int open) {
        if (s == null || open < 0 || open >= s.length() || s.charAt(open) != '[') {
            return false;
        }
        int before = Lexis.prevNonSpace(s, open - 1);
        if (before >= 0 && (s.charAt(before) != ';' || Lexis.depthAt(s, before) != 0)) {
            return false;
        }
        return closesBeforeAssignment(s, open);
    }

    private static boolean closesBeforeAssignment(String s, int open) {
        int close = Lexis.matchingClose(s, open);
        if (close < 0) {
            return false;
        }
        int next = Lexis.nextNonSpace(s, close + 1);
        return next < s.length() && s.charAt(next) == '='
                && (next + 1 >= s.length() || s.charAt(next + 1) != '=');
    }

    // =====================================================================
    // Parsing
    // =====================================================================

    /**
     * Reads a list of variables.
     *
     * @param bracket the left side, {@code [} and {@code ]} included
     * @return the parsed list; never null
     */
    public static Parsed parse(String bracket) {
        String text = bracket == null ? "" : bracket.trim();
        List<List<Target>> rows = new ArrayList<>();
        if (text.length() < 2 || text.charAt(0) != '[' || Lexis.matchingClose(text, 0) != text.length() - 1) {
            return new Parsed(rows, String.format(BAD_ENTRY, text));
        }
        String inner = text.substring(1, text.length() - 1);
        if (inner.isBlank()) {
            return new Parsed(rows, EMPTY_LIST);
        }

        String error = null;
        List<String> rowTexts = Lexis.splitTopLevel(inner, ';');
        for (int r = 0; r < rowTexts.size(); r++) {
            List<Target> row = new ArrayList<>();
            String rowText = rowTexts.get(r);
            if (rowText.isBlank()) {
                // ';;' reads as an empty row between two ';'.
                error = first(error, adjacentSemicolons(inner) ? DOUBLE_SEPARATOR : String.format(EMPTY_ENTRY, r + 1));
                rows.add(row);
                continue;
            }
            for (String entry : Lexis.splitTopLevel(rowText, ',')) {
                String value = entry.trim();
                if (value.isEmpty()) {
                    error = first(error, String.format(EMPTY_ENTRY, r + 1));
                    continue;
                }
                Target target = target(value);
                if (target == null) {
                    error = first(error, String.format(BAD_ENTRY, Lexis.visible(value)));
                    continue;
                }
                row.add(target);
            }
            rows.add(row);
        }

        if (error == null) {
            int width = rows.get(0).size();
            for (List<Target> row : rows) {
                if (row.size() != width) {
                    error = RAGGED;
                    break;
                }
            }
        }
        if (error == null && rows.stream().flatMap(List::stream).allMatch(t -> t.kind() == Kind.SKIP)) {
            error = ALL_SKIPPED;
        }
        return new Parsed(rows, error);
    }

    /**
     * Reads one entry: {@code ~}, a name, a name with indexes, or a dotted
     * field path. Anything else (a number, a call, an expression) is null.
     */
    static Target target(String value) {
        if (SKIP.equals(value)) {
            return new Target(value, Kind.SKIP, "", "");
        }
        if (!Lexis.isIdentStart(value.charAt(0))) {
            return null;
        }
        int rootEnd = Lexis.scanIdent(value, 0);
        String root = value.substring(0, rootEnd);
        if (Lexis.KEYWORDS.contains(root)) {
            return null;
        }
        Kind kind = Kind.NAME;
        int i = rootEnd;
        while (i < value.length()) {
            char c = value.charAt(i);
            if (c == '[') {
                int close = Lexis.matchingClose(value, i);
                if (close < 0) {
                    return null;
                }
                if (kind == Kind.NAME) {
                    kind = Kind.INDEXED;
                }
                i = close + 1;
            } else if (c == '.') {
                int nameStart = i + 1;
                if (nameStart >= value.length() || !Lexis.isIdentStart(value.charAt(nameStart))) {
                    return null;
                }
                kind = Kind.FIELD;
                i = Lexis.scanIdent(value, nameStart);
            } else {
                return null; // '(', an operator, a space between two names ...
            }
        }
        return new Target(value, kind, root, value.substring(rootEnd));
    }

    // =====================================================================
    // Helpers
    // =====================================================================

    private static String first(String current, String candidate) {
        return current != null ? current : candidate;
    }

    private static boolean adjacentSemicolons(String inner) {
        int depth = 0;
        for (int i = 0; i + 1 < inner.length(); i++) {
            char c = inner.charAt(i);
            if (Lexis.isOpenBracket(c)) {
                depth++;
            } else if (Lexis.isCloseBracket(c)) {
                depth = Math.max(0, depth - 1);
            } else if (c == ';' && depth == 0 && inner.charAt(i + 1) == ';') {
                return true;
            }
        }
        return false;
    }
}
