package language.syntax.syntax_checker.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * The lexical facts every check agrees on: what a name is made of, which words
 * are keywords, where a statement's assignment is.
 *
 * <p>
 * These used to be scattered: the identifier rules lived in
 * {@code OperandAdjacencyAnalyzer} and were borrowed by three other classes,
 * {@code assignmentIndex} lived in {@code ExponentSyntaxAnalyzer}, three
 * analyzers each had their own keyword list, and four had their own
 * statement splitter. A difference between any two copies was a bug the user
 * could see, so there is now one copy, here.
 */
public final class Lexis {

    private Lexis() {
    }

    /**
     * Words after which a <b>value</b> is expected: an operator straight after
     * one has nothing on its left, a {@code |} straight after one opens an
     * absolute value, and a value next to one is not "two values side by
     * side". {@code true}, {@code false} and {@code null} are values, not
     * keywords, and {@code publish} is a call, so none of them is here.
     */
    public static final Set<String> KEYWORDS = Set.of(
            "if", "elseif", "elif", "else", "for", "while", "return", "break", "continue",
            "and", "or", "not", "is_in", "is_not_in", "in", "new", "clear", "let",
            "function", "class", "private", "protected", "abstract", "reversible",
            "require", "ensure", "loop",
            "iend", "wend", "fend", "fnend", "csend", "end", "endif", "endfor", "endwhile");

    // ─────────────────────────────────────────────────────────────────────
    // Character classes
    // ─────────────────────────────────────────────────────────────────────

    /**
     * The zero-width joiners U+200D / U+200C. They were the old hidden
     * subscript / superscript markers; a subscript is now written {@code A_$1}
     * and neither character may appear in a name. They are still read as part
     * of a name here, so a pasted name holding one stays ONE name for every
     * check and is reported once, by {@code SubscriptSuperscriptAnalyzer}.
     */
    public static boolean isMarker(char c) {
        return c == '\u200D' || c == '\u200C';
    }

    /** Unicode superscript / subscript digits and letters that attach to a value. */
    public static boolean isScriptPostfix(char c) {
        return c == '\u00B2' || c == '\u00B3' || c == '\u00B9' || (c >= '\u2070' && c <= '\u209F');
    }

    /** First character of a name: any letter (any script), {@code _}, or a styling marker. */
    public static boolean isIdentStart(char c) {
        return Character.isLetter(c) || c == '_' || isMarker(c);
    }

    /**
     * Any later character of a name. Combining marks are needed for Tamil,
     * Malayalam and Telugu consonant-vowel forms. {@code $} and {@code @}
     * are read as part of a name so {@code A_$1} and {@code A_@2} are one
     * name each; where they may stand ({@code _$}, {@code _@} only) is
     * {@code language.semantic.ScriptedName}'s rule, checked by
     * {@code SubscriptSuperscriptAnalyzer}. Unicode script digits
     * ({@code x²}) are read the same way, and reported there.
     */
    public static boolean isIdentPart(char c) {
        if (Character.isLetterOrDigit(c) || c == '_' || c == '$' || c == '@' || isMarker(c)
                || isScriptPostfix(c)) {
            return true;
        }
        int type = Character.getType(c);
        return type == Character.NON_SPACING_MARK
                || type == Character.COMBINING_SPACING_MARK
                || type == Character.ENCLOSING_MARK;
    }

    /**
     * @param text a candidate name
     * @return true when the whole text is one name
     */
    public static boolean isIdentifier(String text) {
        if (text == null || text.isEmpty() || !isIdentStart(text.charAt(0))) {
            return false;
        }
        for (int i = 1; i < text.length(); i++) {
            if (!isIdentPart(text.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    /**
     * @param text  the text to inspect
     * @param index position of the character in question
     * @return true when an odd number of backslashes immediately precede it
     */
    public static boolean isEscaped(String text, int index) {
        int count = 0;
        for (int i = index - 1; i >= 0 && text.charAt(i) == '\\'; i--) {
            count++;
        }
        return count % 2 != 0;
    }

    // ─────────────────────────────────────────────────────────────────────
    // Small scanners
    // ─────────────────────────────────────────────────────────────────────

    /** @return the end offset of the name starting at {@code i} */
    public static int scanIdent(String s, int i) {
        int j = i;
        while (j < s.length() && isIdentPart(s.charAt(j))) {
            j++;
        }
        return j;
    }

    /** @return the first non-whitespace offset at or after {@code from}, or {@code s.length()} */
    public static int nextNonSpace(String s, int from) {
        int i = Math.max(0, from);
        while (i < s.length() && Character.isWhitespace(s.charAt(i))) {
            i++;
        }
        return i;
    }

    /** @return the last non-whitespace offset at or before {@code from}, or -1 */
    public static int prevNonSpace(String s, int from) {
        int i = Math.min(from, s.length() - 1);
        while (i >= 0 && Character.isWhitespace(s.charAt(i))) {
            i--;
        }
        return i;
    }

    /** @return the run of leading spaces (tabs are not counted) */
    public static int leadingSpaces(String line) {
        int count = 0;
        while (line != null && count < line.length() && line.charAt(count) == ' ') {
            count++;
        }
        return count;
    }

    /** @return true when the leading whitespace contains a tab */
    public static boolean hasLeadingTab(String line) {
        if (line == null) {
            return false;
        }
        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (ch == '\t') {
                return true;
            }
            if (ch != ' ') {
                return false;
            }
        }
        return false;
    }

    // ─────────────────────────────────────────────────────────────────────
    // Numbers and complex literals
    // ─────────────────────────────────────────────────────────────────────

    /**
     * True when the {@code i} at {@code j}, written straight after a number,
     * makes that number imaginary: {@code 5i}, {@code 2.5i}, {@code 1e-3i}.
     * Nothing name-like may follow it, so {@code 5in} and {@code 5i2} are not
     * complex. A caller asks this only when a number ends at {@code j}.
     *
     * @param s the text
     * @param j offset just after the number's digits / exponent
     * @return true when {@code s.charAt(j)} is the imaginary unit
     */
    public static boolean isImaginaryUnit(String s, int j) {
        return j < s.length() && s.charAt(j) == 'i'
                && (j + 1 >= s.length() || !isIdentPart(s.charAt(j + 1)));
    }

    /** A whole number literal, optional imaginary unit included, not part of a name. */
    private static final Pattern NUMBER_LITERAL = Pattern.compile(
            "(?<![\\p{L}\\p{M}\\p{N}_.$@\\u200C\\u200D])"
                    + "(?:\\d+(?:\\.\\d*)?|\\.\\d+)(?:[eE][+-]?\\d+)?i?"
                    + "(?![\\p{L}\\p{M}\\p{N}_\\u200C\\u200D])");

    /**
     * Blanks every number literal to spaces, character for character, so a
     * name scanner cannot read the {@code i} of {@code 5i} or the {@code E}
     * of {@code 1E5} as a variable. Offsets are kept.
     *
     * @param s masked text
     * @return the text with its number literals blanked
     */
    public static String blankNumbers(String s) {
        if (s == null || s.isEmpty()) {
            return s;
        }
        return NUMBER_LITERAL.matcher(s).replaceAll(m -> " ".repeat(m.group().length()));
    }

    /** @return the text with the hidden styling markers removed, for messages */
    public static String visible(String text) {
        return text == null ? "" : text.replace("\u200C", "").replace("\u200D", "");
    }

    /**
     * Offset of the statement's assignment {@code =} at bracket depth zero, or
     * -1. {@code ==}, {@code !=}, {@code <=} and {@code >=} are comparisons,
     * and an {@code =} inside brackets (a keyword argument) is not the
     * statement's assignment.
     *
     * @param s one masked statement or line
     * @return the offset, or -1
     */
    public static int assignmentIndex(String s) {
        int depth = 0;
        int n = s.length();
        for (int i = 0; i < n; i++) {
            char c = s.charAt(i);
            if (c == '(' || c == '[' || c == '{') {
                depth++;
            } else if (c == ')' || c == ']' || c == '}') {
                depth = Math.max(0, depth - 1);
            } else if (c == '=' && depth == 0) {
                char before = i > 0 ? s.charAt(i - 1) : ' ';
                char after = i + 1 < n ? s.charAt(i + 1) : ' ';
                if (after == '=' || before == '=' || before == '!' || before == '<' || before == '>') {
                    if (after == '=') {
                        i++;
                    }
                    continue;
                }
                return i;
            }
        }
        return -1;
    }

    /**
     * Splits a masked line on {@code ;} at bracket depth zero. The text is
     * masked, so no quote tracking is needed. A {@code ;} or {@code ;;}
     * inside {@code [ ]} separates the rows or blocks of a matrix and never
     * ends a statement.
     *
     * @param line one masked logical line
     * @return the statements, untrimmed; always at least one entry
     */
    public static List<String> splitStatements(String line) {
        return splitTopLevel(line, ';');
    }

    // ─────────────────────────────────────────────────────────────────────
    // Brackets
    // ─────────────────────────────────────────────────────────────────────

    /** {@code private} / {@code protected} / {@code abstract} before a method header. */
    private static final Pattern HEADER_MODIFIERS = Pattern.compile(
            "^(?:(?:private|protected|abstract)\\s+)+", Pattern.CASE_INSENSITIVE);

    /**
     * True when masked text is a {@code function} or {@code class} header
     * whose round bracket is still open at its end, so the header goes on on
     * the next line ({@code nc.exe} reads a line break inside {@code ( ... )}
     * as a space). The one definition of that rule: {@code SourceModel} joins
     * the lines with it, and the editor, the CLI and the step runner ask it
     * through {@code BlockHeaderGrammar.opensBracketHeader}.
     *
     * @param masked a line, or the lines joined so far: comment removed,
     *               string bodies blanked
     * @return true when the next line belongs to this header
     */
    public static boolean opensHeaderBracket(String masked) {
        if (masked == null) {
            return false;
        }
        String text = masked.trim();
        java.util.regex.Matcher modifiers = HEADER_MODIFIERS.matcher(text);
        String rest = modifiers.find() ? text.substring(modifiers.end()) : text;
        int wordEnd = 0;
        while (wordEnd < rest.length()
                && (Character.isLetterOrDigit(rest.charAt(wordEnd)) || rest.charAt(wordEnd) == '_')) {
            wordEnd++;
        }
        String word = rest.substring(0, wordEnd).toLowerCase(java.util.Locale.ROOT);
        if (!word.equals("function") && !word.equals("class")) {
            return false;
        }
        int depth = 0;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '(') {
                depth++;
            } else if (c == ')') {
                depth = Math.max(0, depth - 1);
            }
        }
        return depth > 0;
    }

    /** @return true for {@code (}, {@code [} and {@code {} */
    public static boolean isOpenBracket(char c) {
        return c == '(' || c == '[' || c == '{';
    }

    /** @return true for {@code )}, {@code ]} and {@code }} */
    public static boolean isCloseBracket(char c) {
        return c == ')' || c == ']' || c == '}';
    }

    /**
     * Splits on {@code separator} where no bracket is open. Round and square
     * closers both count, so NC's interval forms ({@code [a:b)}) balance.
     *
     * @param s         masked text
     * @param separator the character to split on
     * @return the parts, untrimmed; always at least one entry
     */
    public static List<String> splitTopLevel(String s, char separator) {
        List<String> parts = new ArrayList<>();
        int depth = 0;
        int start = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (isOpenBracket(c)) {
                depth++;
            } else if (isCloseBracket(c)) {
                depth = Math.max(0, depth - 1);
            } else if (c == separator && depth == 0) {
                parts.add(s.substring(start, i));
                start = i + 1;
            }
        }
        parts.add(s.substring(start));
        return parts;
    }

    /**
     * @param s    masked text
     * @param open offset of an opening bracket
     * @return the offset of the bracket that closes it, or -1
     */
    public static int matchingClose(String s, int open) {
        int depth = 0;
        for (int i = open; i < s.length(); i++) {
            char c = s.charAt(i);
            if (isOpenBracket(c)) {
                depth++;
            } else if (isCloseBracket(c)) {
                depth--;
                if (depth == 0) {
                    return i;
                }
                if (depth < 0) {
                    return -1;
                }
            }
        }
        return -1;
    }

    /**
     * @param s     masked text
     * @param index an offset into it
     * @return how many brackets are open just before {@code index}
     */
    public static int depthAt(String s, int index) {
        int depth = 0;
        for (int i = 0; i < index && i < s.length(); i++) {
            char c = s.charAt(i);
            if (isOpenBracket(c)) {
                depth++;
            } else if (isCloseBracket(c)) {
                depth = Math.max(0, depth - 1);
            }
        }
        return depth;
    }

    /**
     * @param s     masked text
     * @param start offset of a {@code ;}
     * @return the offset just after the run of adjacent {@code ;} starting there
     */
    public static int semicolonRunEnd(String s, int start) {
        int end = start;
        while (end < s.length() && s.charAt(end) == ';') {
            end++;
        }
        return end;
    }
}
