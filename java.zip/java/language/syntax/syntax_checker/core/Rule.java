package language.syntax.syntax_checker.core;

/**
 * Every rule the syntax checker enforces, each tied to the user-facing group
 * it is reported under.
 *
 * <p>
 * The declaration order is the order in which messages for one line are listed
 * in the gutter tooltip and the Command Window, so the most fundamental fault
 * (an unknown name, an open string) is read first.
 *
 * <p>
 * Adding a rule is three steps: a constant here, an {@link Analyzer} that
 * reports it, and one line in {@code ErrorChecker}'s pipeline. Nothing else
 * needs to know about it.
 */
public enum Rule {

    // ── Undefined Variable ───────────────────────────────────────────────
    /** A name used before anything defines it. */
    UNDEFINED_NAME(Group.UNDEFINED_VARIABLE),

    // ── Function Call ────────────────────────────────────────────────────
    /**
     * A call that does not fit the function, constructor or method it calls:
     * an unknown input name, an input given twice, too many values, a
     * missing input with no default, or a named value on a built-in.
     */
    CALL_MATCH(Group.FUNCTION_CALL),
    /**
     * A time value that is wrong in the source: {@code timestamp(2026, 13, 1)},
     * {@code to_timestamp("2026-13-40")}, {@code hours(1) - 3}, {@code toc(5)}.
     */
    TIME_VALUE(Group.FUNCTION_CALL),
    /**
     * A data I/O option written with a value nc.exe refuses:
     * {@code save_csv(f, T, quote="bad")}, {@code max_size="5 megs"},
     * {@code save_h5(f, A, level=12)}, or a call that is never built in
     * ({@code save_xlsb}, {@code save_mp3}).
     */
    IO_OPTION(Group.FUNCTION_CALL),

    // ── Unassigned Variable ──────────────────────────────────────────────
    /** {@code DD = ;}: a name given an {@code =} and then no value. */
    UNASSIGNED(Group.UNASSIGNED_VARIABLE),

    // ── Syntax ───────────────────────────────────────────────────────────
    /** A string literal that opens and never closes. */
    STRING_LITERAL(Group.SYNTAX),
    /** {@code ;;} outside {@code [ ]}, {@code ; ;} and {@code ;:}. */
    STATEMENT_TERMINATOR(Group.SYNTAX),
    /** Unbalanced brackets, a trailing {@code ,}, an empty statement. */
    INCOMPLETE_LINE(Group.SYNTAX),
    /** An absolute value {@code |x|} that is never closed or crosses a bracket. */
    ABSOLUTE_VALUE(Group.SYNTAX),
    /**
     * A malformed assignment: {@code (A = 5)}, {@code A = B = 5}, {@code A+B = C},
     * a malformed list of variables ({@code [a, b; c] = M}, {@code [k1, k2] = 5})
     * or the retired {@code (a, b) = f(x)}.
     */
    ASSIGNMENT(Group.SYNTAX),
    /** A {@code ^} with no base or no power, or a power on the left of {@code =}. */
    EXPONENT(Group.SYNTAX),
    /** Two values side by side with no operator or comma: {@code 2A}, {@code f(A B)}. */
    MISSING_SEPARATOR(Group.SYNTAX),
    /**
     * A malformed matrix: rows of different length, N-D blocks of different
     * shape, the old nested {@code [[..],[..]]} form, an empty row, block or
     * element, or an invalid index such as {@code A[]}, {@code B[, 1, 2]} or
     * {@code A[3:1, 2]}. Any number of keys is valid ({@code B[i, j, k]}).
     */
    MATRIX(Group.SYNTAX),
    /** Meaningless or invalid operators: {@code a*&#47;b}, {@code a &amp; b}, {@code a ==}. */
    STRING_SCRIPT(Group.SYNTAX),
    OPERATOR_SEQUENCE(Group.SYNTAX),
    /**
     * Text used as a number: {@code "5" + 1}, {@code "5" * 2}, {@code -"5"},
     * {@code "5" < 5}. Only {@code +} between two texts joins them.
     */
    TEXT_OPERAND(Group.SYNTAX),
    /** A function call on the left of {@code =}. */
    ASSIGN_TO_CALL(Group.SYNTAX),
    /** Invalid subscript/superscript usage. */
    STYLING(Group.SYNTAX),
    /**
     * A name {@code nc.exe} keeps for itself after a dot: a method named
     * {@code info}, a field named {@code base} or {@code info}, values given
     * to {@code X.info} / {@code X.base}.
     */
    RESERVED_MEMBER(Group.SYNTAX),
    /** A script called the wrong way: {@code ABC()}, {@code ABC.nc}, {@code X = ABC}. */
    SCRIPT_CALL(Group.SYNTAX),
    /** A block header that is incomplete or malformed, or text after a closer. */
    BLOCK_HEADER(Group.SYNTAX),
    /** An unclosed block, an orphaned closer, a misplaced {@code else}. */
    BLOCK_STRUCTURE(Group.SYNTAX),
    /**
     * Python forms NC does not have: a dict literal {@code {"a": 1}}, a tuple
     * {@code (64, 64)}, a bare range in brackets {@code rows=2:500}, and
     * {@code .@id} after a dot.
     */
    FOREIGN_LITERAL(Group.SYNTAX),
    /**
     * A warning, not an error: a Windows path whose {@code \t}, {@code \n} or
     * {@code \r} nc.exe reads as a tab / new line ({@code "D:\temp\new.csv"}).
     */
    PATH_ESCAPE(Group.SYNTAX, true),

    // ── Indentation ──────────────────────────────────────────────────────
    /**
     * Leading spaces of an ordinary line. (A {@code ~~} continuation line may
     * start anywhere, so it has no rule of its own any more.)
     */
    INDENTATION(Group.INDENTATION);

    /** The four categories the user sees. */
    public enum Group {
        UNDEFINED_VARIABLE,
        FUNCTION_CALL,
        SYNTAX,
        UNASSIGNED_VARIABLE,
        INDENTATION
    }

    private final Group group;
    private final boolean warning;

    Rule(Group group) {
        this(group, false);
    }

    Rule(Group group, boolean warning) {
        this.group = group;
        this.warning = warning;
    }

    /** @return the user-facing group this rule reports under */
    public Group group() {
        return group;
    }

    /** @return true for a rule that warns (amber bar) and never blocks a run */
    public boolean isWarning() {
        return warning;
    }
}
