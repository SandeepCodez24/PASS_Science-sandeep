package language.syntax.syntax_checker.structure;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import language.syntax.syntax_checker.core.Lexis;

/**
 * The single definition of what a Neural Code block header looks like.
 *
 * <p>
 * Three places need this answer and must never disagree: the error checker
 * ({@link BlockHeaderAnalyzer}, {@link IndentationAnalyzer}), the editor's autofill
 * ({@code EditorIndentationHandler}) and the suggestion discovery
 * ({@code VariableDiscoveryEngine}). Before this class each kept its own idea of
 * "a header", which is how a header missing its colon came to be silently
 * ignored by one pass and blamed on the wrong lines by another.
 *
 * <h3>Accepted header shapes</h3>
 *
 * <pre>
 *   if &lt;condition&gt;:                 elseif &lt;condition&gt;:        else:
 *   while &lt;condition&gt;:              for &lt;loop range&gt;:
 *
 *   function name(args):
 *   function out = name(args):
 *   function [a, b] = name(args):      several outputs: always square brackets
 *   function (a, b) = name(args):      &larr; REJECTED (retired): use [a, b]
 *   function y = f(a, b=2, c="car"):   inputs may have default values</pre>
 *
 * <p>
 * A function's inputs are read by {@link FunctionSignature}: {@code name} or
 * {@code name = expression}, in any order, split only at commas outside
 * brackets and strings. {@link Header#signature()} hands the result on, so the
 * checker, the call matching and the suggestions read defaults the same way.
 * A header may be written over several lines inside its brackets
 * ({@link #opensBracketHeader}); {@code SourceModel} and the editor join them.
 *
 * <pre>
 *
 *   class Name(args):                  &larr; the only class form
 * </pre>
 *
 * {@code args} is empty or a comma-separated list of identifiers. A function
 * may be prefixed by {@code private}, {@code protected} or {@code abstract} when
 * it is a class method; the modifiers do not change the shape.
 *
 * <h3>Recovery, not rejection</h3>
 * {@link #parse(String)} recognises a header by its first word alone, so a line
 * such as {@code function ASD = f(x)} is still reported as a {@code FUNCTION}
 * header -- with {@link Header#hasColon()} false and an error message. Callers
 * therefore keep opening the block, and one missing colon produces one error on
 * its own line instead of a cascade through the body and the closer.
 *
 * <p>
 * Input is expected to be a single <b>masked</b> logical line (string bodies
 * blanked, comment removed), as produced by {@code SourceModel.Line#masked()}.
 */
public final class BlockHeaderGrammar {

    private BlockHeaderGrammar() {
    }

    /** Every header keyword, with the closer it expects. */
    public enum Kind {
        IF("if", "iend"),
        FOR("for", "fend"),
        WHILE("while", "wend"),
        FUNCTION("function", "fnend"),
        CLASS("class", "csend"),
        /** Branch of an {@code if}; opens no block of its own. */
        ELSE("else", null),
        /** Branch of an {@code if}; opens no block of its own. */
        ELSEIF("elseif", null);

        private final String keyword;
        private final String closer;

        Kind(String keyword, String closer) {
            this.keyword = keyword;
            this.closer = closer;
        }

        /** @return the keyword that introduces the header */
        public String keyword() {
            return keyword;
        }

        /** @return the terminator this header needs, or null for a branch */
        public String closer() {
            return closer;
        }

        /** @return true when the header opens a block that needs a closer */
        public boolean opensBlock() {
            return closer != null;
        }

        /** @return true for {@code else} / {@code elseif} */
        public boolean isBranch() {
            return closer == null;
        }
    }

    /** One recognised header line. Immutable. */
    public static final class Header {
        private final Kind kind;
        private final boolean hasColon;
        private final String error;
        private final String name;
        private final List<String> parameters;
        private final List<String> outputs;
        private final FunctionSignature signature;

        private Header(Kind kind, boolean hasColon, String error, String name,
                List<String> parameters, List<String> outputs, FunctionSignature signature) {
            this.kind = kind;
            this.hasColon = hasColon;
            this.error = error;
            this.name = name;
            this.parameters = Collections.unmodifiableList(parameters);
            this.outputs = Collections.unmodifiableList(outputs);
            this.signature = signature;
        }

        /** @return the header kind */
        public Kind kind() {
            return kind;
        }

        /** @return true when the line ends with {@code :} */
        public boolean hasColon() {
            return hasColon;
        }

        /** @return a user-facing description of what is wrong, or null */
        public String error() {
            return error;
        }

        /** @return true when the header is complete and well formed */
        public boolean isValid() {
            return error == null;
        }

        /**
         * @return the function or class name when the shape could be read,
         *         otherwise null (always null for if/for/while/else/elseif)
         */
        public String name() {
            return name;
        }

        /**
         * @return the declared parameters -- for a function its input
         *         <b>names</b> (defaults left out), for a class its parents;
         *         empty when none or unreadable
         */
        public List<String> parameters() {
            return parameters;
        }

        /**
         * @return a function header's full signature, inputs and defaults
         *         included; null for any other header
         */
        public FunctionSignature signature() {
            return signature;
        }

        /** @return the declared outputs of a function; empty when none */
        public List<String> outputs() {
            return outputs;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Shapes
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * An identifier in any supported script. Combining marks are required for
     * Tamil / Malayalam / Telugu consonant-vowel forms, and a name may carry a
     * subscript and a superscript ({@code y_$1}, {@code f_@2}), so {@code $}
     * and {@code @} are read as part of it, as {@code Lexis} reads them.
     * Whether such a name is well formed is checked by
     * {@code SubscriptSuperscriptAnalyzer}. The zero-width joiners stay
     * readable here so a pasted one is reported there, once.
     */
    public static final String IDENT = "[\\p{L}_\\u200C\\u200D][\\p{L}\\p{M}\\p{N}_$@\\u200C\\u200D]*";

    private static final String IDENT_LIST = "(?:" + IDENT + "(?:\\s*,\\s*" + IDENT + ")*)";

    private static final Pattern MODIFIERS = Pattern.compile(
            "^(?:(?:private|protected|abstract)\\s+)+", Pattern.CASE_INSENSITIVE);


    private static final Pattern CLASS_SHAPE = Pattern.compile(
            "^(?<name>" + IDENT + ")\\s*\\(\\s*(?<params>" + IDENT_LIST + ")?\\s*\\)$");

    // ─────────────────────────────────────────────────────────────────────────
    // Public API
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Reads one masked logical line.
     *
     * @param maskedLine the line with its comment removed and string bodies blanked
     * @return the header, or null when the line is not a block header
     */
    public static Header parse(String maskedLine) {
        return parse(maskedLine, maskedLine);
    }

    /**
     * Reads one logical line, taking the texts of a function's defaults from
     * the unmasked code so they keep their strings ({@code c="car"}).
     *
     * @param maskedLine the line with its comment removed and string bodies blanked
     * @param codeLine   the same line with literals intact (same length); when
     *                   it does not line up, the masked line is used for both
     * @return the header, or null when the line is not a block header
     */
    public static Header parse(String maskedLine, String codeLine) {
        if (maskedLine == null) {
            return null;
        }
        int lead = Lexis.nextNonSpace(maskedLine, 0);
        int tail = Lexis.prevNonSpace(maskedLine, maskedLine.length() - 1) + 1;
        if (lead >= tail) {
            return null;
        }
        String text = maskedLine.substring(lead, tail);
        String code = codeLine != null && codeLine.length() == maskedLine.length()
                ? codeLine.substring(lead, tail)
                : text;

        int start = 0;
        Matcher modifiers = MODIFIERS.matcher(text);
        if (modifiers.find()) {
            start = modifiers.end();
        }
        String afterModifiers = text.substring(start);
        String afterModifiersCode = code.substring(start);

        String word = firstWord(afterModifiers);
        Kind kind = kindFor(word);
        if (kind == null) {
            return null;
        }
        // `private mean, std;` is a field declaration, not a header. Only a
        // function may carry access modifiers.
        if (start > 0 && kind != Kind.FUNCTION) {
            return null;
        }

        boolean hasColon = afterModifiers.endsWith(":");
        // A one-line block, `if x: publish(1); iend`: the header's ':' is
        // followed by code. nc.exe refuses it with the same message, so the
        // line gets that message instead of "must end with ':'".
        int bodyColon = hasColon ? -1 : topLevelColon(afterModifiers, word.length());
        boolean oneLineBlock = bodyColon >= 0;
        if (oneLineBlock) {
            hasColon = true;
        }
        String body = oneLineBlock ? afterModifiers.substring(0, bodyColon)
                : hasColon ? afterModifiers.substring(0, afterModifiers.length() - 1) : afterModifiers;
        // Keywords are ASCII, so the lower-cased word has the source length.
        String rest = body.substring(word.length()).trim();

        List<String> messages = new ArrayList<>();
        String name = null;
        List<String> parameters = new ArrayList<>();
        List<String> outputs = new ArrayList<>();
        FunctionSignature signature = null;

        // Python's spelling, read as the elseif it stands for (so the block
        // around it stays intact) and reported - nc.exe refuses it.
        if (word.equals(ELIF)) {
            messages.add("'elif' is not an NC keyword - write 'elseif'");
        }
        if (oneLineBlock) {
            messages.add("The body of '" + kind.keyword() + "' goes on the lines below its header, "
                    + "not after the ':' (and its closer on a line of its own)");
        }

        switch (kind) {
            case IF, WHILE, ELSEIF -> {
                if (rest.isEmpty()) {
                    messages.add("'" + kind.keyword() + "' needs a condition");
                }
            }
            case ELSE -> {
                if (!rest.isEmpty()) {
                    messages.add("'else' takes no condition; use 'elseif <condition>:'");
                }
            }
            case FOR -> {
                if (rest.isEmpty()) {
                    messages.add("'for' needs a loop range, e.g. 'for i = [1:10]:'");
                } else if (topLevelColon(rest, 0) >= 0) {
                    // MATLAB's `for i = 1:3` - the range needs brackets here.
                    messages.add("A range in a 'for' header is written in brackets, e.g. 'for i = [1:3]:'");
                }
            }
            case FUNCTION -> {
                int restAt = word.length();
                int restEnd = body.length();
                signature = FunctionSignature.parse(body.substring(restAt, restEnd),
                        afterModifiersCode.substring(restAt, restEnd));
                if (signature.name() != null) {
                    name = signature.name();
                    parameters.addAll(signature.inputNames());
                    outputs.addAll(signature.outputs());
                }
                if (signature.error() != null) {
                    messages.add(signature.error());
                }
            }
            case CLASS -> {
                Matcher shape = CLASS_SHAPE.matcher(rest);
                if (shape.matches()) {
                    name = shape.group("name");
                    splitInto(shape.group("params"), parameters);
                } else {
                    messages.add("Class header must be 'class Name(args):'");
                }
            }
            default -> {
                // no further shape rules
            }
        }

        if (!hasColon) {
            messages.add("Block header must end with ':'");
        }

        String error = messages.isEmpty() ? null : String.join("; ", messages);
        return new Header(kind, hasColon, error, name, parameters, outputs, signature);
    }

    /**
     * True when a masked logical line is a {@code function} or {@code class}
     * header whose round bracket is still open at its end: the header goes on
     * on the next line, as {@code nc.exe} reads a line break inside
     * {@code ( ... )} as a space.
     *
     * <pre>
     *   function y = f(a=1,        &larr; true
     *                  b=2):
     * </pre>
     *
     * @param maskedLine a line (or the lines joined so far), comment removed,
     *                   string bodies blanked
     * @return true when the next line belongs to this header
     */
    public static boolean opensBracketHeader(String maskedLine) {
        return Lexis.opensHeaderBracket(maskedLine);
    }

    /**
     * @param word a lower-cased first word
     * @return the header kind it introduces, or null
     */
    public static Kind kindFor(String word) {
        if (word == null || word.isEmpty()) {
            return null;
        }
        if (word.equals(ELIF)) {
            return Kind.ELSEIF; // reported by parse()
        }
        for (Kind kind : Kind.values()) {
            if (kind.keyword().equals(word)) {
                return kind;
            }
        }
        return null;
    }

    /**
     * @param word a lower-cased first word
     * @return true for {@code iend}, {@code fend}, {@code wend}, {@code fnend}, {@code csend}
     */
    public static boolean isCloser(String word) {
        if (word == null || word.isEmpty()) {
            return false;
        }
        for (Kind kind : Kind.values()) {
            if (word.equals(kind.closer())) {
                return true;
            }
        }
        return false;
    }

    /**
     * The leading word of a trimmed line, lower-cased. Letters, digits and
     * underscores all belong to the word, so {@code for2} and {@code if_ok} are
     * never mistaken for keywords.
     *
     * @param line a line with no leading whitespace
     * @return the lower-cased first word; empty when the line starts otherwise
     */
    public static String firstWord(String line) {
        if (line == null) {
            return "";
        }
        int end = 0;
        while (end < line.length()) {
            char ch = line.charAt(end);
            if (!Character.isLetterOrDigit(ch) && ch != '_') {
                break;
            }
            end++;
        }
        return line.substring(0, end).toLowerCase(Locale.ROOT);
    }

    /**
     * True when a header line also ends with its own closer - a one-line
     * block, {@code if x: publish(1); iend} - so it opens no block.
     *
     * @param maskedLine the header line, masked
     * @param kind       the header's kind
     */
    public static boolean closesOnItsOwnLine(String maskedLine, Kind kind) {
        if (maskedLine == null || !kind.opensBlock()) {
            return false;
        }
        String text = maskedLine.trim();
        String closer = kind.closer();
        if (text.length() <= closer.length()
                || !text.toLowerCase(Locale.ROOT).endsWith(closer)) {
            return false;
        }
        char before = text.charAt(text.length() - closer.length() - 1);
        return !Character.isLetterOrDigit(before) && before != '_';
    }

    /**
     * True for {@code iend = 2;} - a closer word followed by an assignment,
     * i.e. a keyword used as a variable name.
     *
     * @param maskedLine a masked line
     */
    public static boolean isCloserAssignment(String maskedLine) {
        if (maskedLine == null) {
            return false;
        }
        String text = maskedLine.trim();
        String word = firstWord(text);
        if (!isCloser(word)) {
            return false;
        }
        String after = text.substring(word.length()).trim();
        return after.startsWith("=") && !after.startsWith("==");
    }

    /** Python's {@code elif}: not a keyword, read as {@code elseif} and reported. */
    private static final String ELIF = "elif";

    /**
     * The first {@code :} at bracket depth zero from {@code from} on that has
     * code after it, or -1. On a masked line, so a ':' in a string is blank.
     * The ':' of a range in brackets ({@code [1:3]}, {@code A[1:2]}) is
     * inside a bracket and never counts. On a header, this is where a
     * one-line block's body starts.
     *
     * @param text a masked line, or part of one
     * @param from where to start looking
     */
    public static int topLevelColon(String text, int from) {
        int depth = 0;
        for (int i = Math.max(0, from); i < text.length(); i++) {
            char ch = text.charAt(i);
            if (ch == '(' || ch == '[' || ch == '{') {
                depth++;
            } else if ((ch == ')' || ch == ']' || ch == '}') && depth > 0) {
                depth--;
            } else if (ch == ':' && depth == 0 && !text.substring(i + 1).isBlank()) {
                return i;
            }
        }
        return -1;
    }

    private static void splitInto(String commaSeparated, List<String> target) {
        if (commaSeparated == null || commaSeparated.isBlank()) {
            return;
        }
        for (String part : commaSeparated.split(",")) {
            String trimmed = part.trim();
            if (!trimmed.isEmpty()) {
                target.add(trimmed);
            }
        }
    }
}
