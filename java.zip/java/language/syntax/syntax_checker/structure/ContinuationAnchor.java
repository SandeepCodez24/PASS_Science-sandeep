package language.syntax.syntax_checker.structure;

import java.util.Set;

import language.syntax.syntax_checker.core.Lexis;

/**
 * Where the editor puts the caret on a new {@code ~~} continuation line.
 *
 * <p>
 * This is a typing aid only. {@code nc.exe} does not care where a
 * continuation line starts (it removes the line's leading blanks and joins it
 * with one space), so the checker no longer tests the column -- the old
 * {@code ContinuationAlignmentAnalyzer} and its "Continuation line must start
 * under the value it continues" error are gone. The editor's Enter key still
 * lines the new line up under the value the first line began, because that
 * reads well:
 *
 * <pre>
 *   while X &lt; 0 &amp;&amp; Y &gt; 2 ~~         Total = A + B ~~
 *         &amp;&amp; Z == 3:                        + C;
 * </pre>
 *
 * <table>
 * <caption>Where the value begins</caption>
 * <tr><th>First line</th><th>Column</th></tr>
 * <tr><td>{@code if / elseif / while} (also {@code if not ...})</td>
 * <td>first character after the keyword (after {@code not})</td></tr>
 * <tr><td>{@code for i = ...}</td><td>first character after {@code =}</td></tr>
 * <tr><td>{@code return ...}</td><td>first character after the keyword</td></tr>
 * <tr><td>{@code function ...(} / {@code class ...(}</td>
 * <td>first character after the open {@code (}</td></tr>
 * <tr><td>an assignment {@code X = ...}</td><td>first character after {@code =}</td></tr>
 * <tr><td>a call {@code name(...}</td><td>first character after its {@code (}</td></tr>
 * <tr><td>anything else</td><td>one level (three spaces) in</td></tr>
 * </table>
 *
 * A matrix literal left open ({@code B = [1,2;3,4 ;; ~~}) continues under its
 * first element; a string split across the lines continues inside its quote.
 */
public final class ContinuationAnchor {

    private static final Set<String> CONDITION_KEYWORDS = Set.of("if", "elseif", "while", "return");

    /** Condition openers that may be followed by {@code not} as part of the opener. */
    private static final Set<String> NEGATABLE = Set.of("if", "elseif", "while");

    /** The second word of {@code if not} / {@code while not}. */
    private static final String NOT = "not";

    private ContinuationAnchor() {
    }

    /**
     * @param head   the masked first physical line, without its {@code ~~}
     *               (offsets are columns)
     * @param indent its leading spaces
     * @return the column the editor puts a continuation line at
     */
    public static int column(String head, int indent) {
        int column = valueColumn(head, indent);
        if (column < head.length() && head.charAt(column) == '['
                && Lexis.matchingClose(head, column) < 0) {
            int element = Lexis.nextNonSpace(head, column + 1);
            if (element < head.length()) {
                return element;
            }
        }
        return column;
    }

    /** The column of the value the first line began; see the class comment. */
    private static int valueColumn(String head, int indent) {
        int fallback = indent + IndentationAnalyzer.INDENT_SIZE;
        int start = Lexis.nextNonSpace(head, 0);
        if (start >= head.length()) {
            return fallback;
        }

        // Access modifiers on a method header are not the value.
        String text = head.substring(start);
        String word = BlockHeaderGrammar.firstWord(text);
        while (word.equals("private") || word.equals("protected") || word.equals("abstract")) {
            start = Lexis.nextNonSpace(head, start + word.length());
            word = BlockHeaderGrammar.firstWord(head.substring(start));
        }

        int column;
        if (CONDITION_KEYWORDS.contains(word)) {
            column = Lexis.nextNonSpace(head, start + word.length());
            // 'while not (...)': 'not' belongs to the opener, the value starts after it.
            if (NEGATABLE.contains(word) && column < head.length()
                    && NOT.equals(BlockHeaderGrammar.firstWord(head.substring(column)))) {
                column = Lexis.nextNonSpace(head, column + NOT.length());
            }
        } else if (word.equals("for")) {
            int equals = Lexis.assignmentIndex(head.substring(start));
            column = equals < 0
                    ? Lexis.nextNonSpace(head, start + word.length())
                    : Lexis.nextNonSpace(head, start + equals + 1);
        } else if (word.equals("function") || word.equals("class")) {
            int open = outermostOpenRound(head, start);
            column = open < 0 ? Lexis.nextNonSpace(head, start + word.length()) : Lexis.nextNonSpace(head, open + 1);
        } else {
            int equals = Lexis.assignmentIndex(head.substring(start));
            if (equals >= 0) {
                column = Lexis.nextNonSpace(head, start + equals + 1);
            } else if (Lexis.isIdentStart(head.charAt(start)) && !Lexis.KEYWORDS.contains(word)) {
                int nameEnd = Lexis.scanIdent(head, start);
                int open = Lexis.nextNonSpace(head, nameEnd);
                column = open < head.length() && head.charAt(open) == '('
                        ? Lexis.nextNonSpace(head, open + 1)
                        : -1;
            } else {
                column = -1;
            }
        }

        if (column < 0 || column >= head.length()) {
            return fallback; // nothing on the first line to line up with
        }
        // A string split across the lines lines up with its own text, so the
        // column moves inside the opening quote. A value that merely starts
        // with a complete string ('publish("sum:", ~~') does not.
        char first = head.charAt(column);
        boolean quote = first == '"' || first == '\'';
        return quote && endsInsideString(head) ? column + 1 : column;
    }

    /**
     * True when a string literal is still open at the end of the masked head.
     * String bodies are blank in the masked text, so only delimiters remain.
     */
    private static boolean endsInsideString(String head) {
        char open = 0;
        for (int i = 0; i < head.length(); i++) {
            char c = head.charAt(i);
            if (open == 0 && (c == '"' || c == '\'')) {
                open = c;
            } else if (c == open) {
                open = 0;
            }
        }
        return open != 0;
    }

    /** The outermost {@code (} still open at the end of {@code head}, or -1. */
    private static int outermostOpenRound(String head, int from) {
        int depth = 0;
        int outermost = -1;
        for (int i = from; i < head.length(); i++) {
            char c = head.charAt(i);
            if (c == '(') {
                if (depth == 0) {
                    outermost = i;
                }
                depth++;
            } else if (c == ')') {
                depth = Math.max(0, depth - 1);
                if (depth == 0) {
                    outermost = -1;
                }
            }
        }
        return depth > 0 ? outermost : -1;
    }
}
