package language.syntax.syntax_checker.structure;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import language.syntax.syntax_checker.core.Lexis;

/**
 * What a {@code function} header declares: its outputs, its name and its
 * inputs, each input with an optional default value.
 *
 * <pre>
 *   function f(a=1, b=2, c="car"):          no output, three defaults
 *   function y = area(w, h=w):              a default may use another input
 *   function [q, r] = divide(a, b=1):       several outputs
 *   function K(a=1, b):                     a default may come first
 *   function y = f(a="x:y", b=[1, 2]):      ',' ':' '"' and brackets inside a default
 *   function A = area(scale=base.w):        a method's default may read the object
 * </pre>
 *
 * <h3>How the inputs are read</h3>
 * The text between the name's {@code (} and its matching {@code )} is split
 * at commas that sit at bracket depth zero, on the <b>masked</b> line (string
 * bodies blanked), so a comma, colon or bracket inside a string or a matrix
 * never ends an input. An input is {@code name} or {@code name = expression};
 * the expression is any value, and is checked by the same expression rules as
 * every other line (brackets, operators, undefined names). The texts kept for
 * messages and suggestions come from the unmasked code at the same offsets, so
 * {@code c="car"} reads {@code c="car"}, not {@code c="   "}.
 *
 * <h3>Errors, worded as {@code nc.exe} words them</h3>
 * <pre>
 *   function y = f(a, b=):    input 'b' of function 'f' has '=' but no default value after it
 *   function y = f(a, a):     input 'a' appears twice in the header of function 'f'
 *   function (a, b) = f(x):   the outputs of a function are written in square brackets - ...
 * </pre>
 *
 * <h3>Signature text</h3>
 * {@link #text()} is the header as written after {@code function}, without
 * its {@code :} and with every run of whitespace collapsed to one space:
 * {@code y = G(a, b=100, c=1000)}. It is the {@code (defined as ...)} part of
 * a call error and the hint the suggestion popup shows.
 */
public final class FunctionSignature {

    /** One input of a header. */
    public record Input(String name, String defaultText) {

        /** @return true when the input has {@code = default} */
        public boolean hasDefault() {
            return defaultText != null;
        }

        /** @return {@code name} or {@code name=default}, for display */
        @Override
        public String toString() {
            return hasDefault() ? name + "=" + defaultText : name;
        }
    }

    // ---- messages ----------------------------------------------------------

    static final String NO_NAME = "Function header needs a name: 'function name(args):'";
    static final String MALFORMED = "Malformed function header; use 'name(args)', "
            + "'out = name(args)' or '[a, b] = name(args)'";
    static final String EMPTY_DEFAULT = "input '%s' of function '%s' has '=' but no default value after it";
    static final String TWICE = "input '%s' appears twice in the header of function '%s'";
    static final String BAD_INPUT = "'%s' is not a valid input of function '%s' - write a name, or name=default";
    static final String EMPTY_INPUT = "an input of function '%s' is missing - remove the extra ','";
    static final String TEXT_AFTER = "Malformed function header: nothing may follow ')' except ':'";
    static final String PAREN_OUTPUTS = "the outputs of a function are written in square brackets - "
            + "function [%1$s] = %2$s, not function (%1$s) = %2$s";

    private static final Pattern NAME = Pattern.compile(BlockHeaderGrammar.IDENT);

    /** {@code name =} at the start of an input; group 1 is the name. {@code ==} is not it. */
    private static final Pattern NAMED = Pattern.compile("^(" + BlockHeaderGrammar.IDENT + ")\\s*=(?!=)");

    private final String name;
    private final List<String> outputs;
    private final List<Input> inputs;
    private final String text;
    private final String error;

    private FunctionSignature(String name, List<String> outputs, List<Input> inputs, String text, String error) {
        this.name = name;
        this.outputs = Collections.unmodifiableList(outputs);
        this.inputs = Collections.unmodifiableList(inputs);
        this.text = text;
        this.error = error;
    }

    /** @return the function's name, or null when it could not be read */
    public String name() {
        return name;
    }

    /** @return the declared outputs, in order; empty when none */
    public List<String> outputs() {
        return outputs;
    }

    /** @return the declared inputs, in order */
    public List<Input> inputs() {
        return inputs;
    }

    /** @return the input names, in order */
    public List<String> inputNames() {
        List<String> names = new ArrayList<>(inputs.size());
        inputs.forEach(i -> names.add(i.name()));
        return names;
    }

    /** @return {@code y = G(a, b=100, c=1000)}: the header after {@code function}, whitespace collapsed */
    public String text() {
        return text;
    }

    /** @return {@code G(a, b=100, c=1000)}: the call shape, without outputs */
    public String callText() {
        StringBuilder call = new StringBuilder(name == null ? "" : name).append('(');
        for (int i = 0; i < inputs.size(); i++) {
            call.append(i > 0 ? ", " : "").append(inputs.get(i));
        }
        return call.append(')').toString();
    }

    /** @return the first fault, or null when the header is well formed */
    public String error() {
        return error;
    }

    // =====================================================================
    // Parsing
    // =====================================================================

    /**
     * Reads the part of a header after {@code function} (modifiers and the
     * keyword removed, the closing {@code :} removed).
     *
     * @param masked the text, string bodies blanked
     * @param code   the same text with literals intact (same offsets); may
     *               be the masked text when no other is at hand
     * @return the signature; {@link #error()} says what is wrong
     */
    public static FunctionSignature parse(String masked, String code) {
        String m = masked == null ? "" : masked;
        String c = code == null || code.length() != m.length() ? m : code;
        int start = Lexis.nextNonSpace(m, 0);
        int end = Lexis.prevNonSpace(m, m.length() - 1) + 1;
        String text = collapse(c.substring(start, Math.max(start, end)));
        List<String> outputs = new ArrayList<>();
        List<Input> inputs = new ArrayList<>();

        if (start >= end) {
            return new FunctionSignature(null, outputs, inputs, text, NO_NAME);
        }

        // ---- outputs: [a, b] =   or   y =   or   (a, b) = (retired) --------
        String retired = null;
        int at = start;
        char first = m.charAt(at);
        if (first == '[' || first == '(') {
            int close = Lexis.matchingClose(m, at);
            int equals = close < 0 ? -1 : Lexis.nextNonSpace(m, close + 1);
            if (close < 0 || equals >= end || m.charAt(equals) != '=') {
                return new FunctionSignature(null, outputs, inputs, text, MALFORMED);
            }
            String list = c.substring(at + 1, close);
            if (first == '(') {
                // Retired, but still read to the end: the outputs and inputs
                // are known, so the body is not a cascade of undefined names.
                String rest = collapse(c.substring(Lexis.nextNonSpace(m, equals + 1), end));
                String call = rest.replaceAll("\\(.*", "(...)");
                retired = String.format(PAREN_OUTPUTS,
                        list.isBlank() ? "a, b" : collapse(list).replaceAll("\\s*,\\s*", ", "),
                        call.isEmpty() ? "name(...)" : call);
            }
            for (String output : list.split(",")) {
                String o = output.trim();
                if (!NAME.matcher(o).matches()) {
                    return new FunctionSignature(null, outputs, inputs, text, retired != null ? retired : MALFORMED);
                }
                outputs.add(o);
            }
            at = Lexis.nextNonSpace(m, equals + 1);
        } else {
            int nameEnd = scanName(m, at);
            int next = Lexis.nextNonSpace(m, nameEnd);
            if (nameEnd > at && next < end && m.charAt(next) == '='
                    && (next + 1 >= m.length() || m.charAt(next + 1) != '=')) {
                outputs.add(c.substring(at, nameEnd));
                at = Lexis.nextNonSpace(m, next + 1);
            }
        }

        // ---- name ( inputs ) -------------------------------------------------
        int nameEnd = scanName(m, at);
        if (nameEnd == at) {
            return new FunctionSignature(null, outputs, inputs, text, at >= end ? NO_NAME : MALFORMED);
        }
        String name = c.substring(at, nameEnd);
        int open = Lexis.nextNonSpace(m, nameEnd);
        if (open >= end || m.charAt(open) != '(') {
            return new FunctionSignature(name, outputs, inputs, text, MALFORMED);
        }
        int close = Lexis.matchingClose(m, open);
        if (close < 0 || close >= end) {
            return new FunctionSignature(name, outputs, inputs, text, MALFORMED);
        }
        if (Lexis.nextNonSpace(m, close + 1) < end) {
            return new FunctionSignature(name, outputs, inputs, text, TEXT_AFTER);
        }

        String error = readInputs(m, c, open + 1, close, name, inputs);
        return new FunctionSignature(name, outputs, inputs, text, retired != null ? retired : error);
    }

    /** Splits {@code m[from, to)} into inputs; returns the first fault or null. */
    private static String readInputs(String m, String c, int from, int to, String function, List<Input> inputs) {
        String innerMasked = m.substring(from, to);
        if (innerMasked.isBlank()) {
            return null; // f()
        }
        String error = null;
        Set<String> seen = new HashSet<>();
        int pieceStart = 0;
        for (String piece : Lexis.splitTopLevel(innerMasked, ',')) {
            int offset = from + pieceStart;
            pieceStart += piece.length() + 1;
            String pm = piece.trim();
            if (pm.isEmpty()) {
                error = first(error, String.format(EMPTY_INPUT, function));
                continue;
            }
            int lead = Lexis.nextNonSpace(piece, 0);
            String pc = c.substring(offset + lead, offset + lead + pm.length());

            String inputName;
            String defaultText = null;
            Matcher named = NAMED.matcher(pm);
            if (named.find()) {
                inputName = pc.substring(0, named.end(1));
                String value = pc.substring(named.end()).trim();
                if (value.isEmpty()) {
                    error = first(error, String.format(EMPTY_DEFAULT, inputName, function));
                }
                defaultText = collapse(value);
            } else if (NAME.matcher(pm).matches()) {
                inputName = pc;
            } else {
                error = first(error, String.format(BAD_INPUT, collapse(pc), function));
                continue;
            }
            if (!seen.add(inputName)) {
                error = first(error, String.format(TWICE, inputName, function));
            }
            inputs.add(new Input(inputName, defaultText));
        }
        return error;
    }

    // =====================================================================
    // Helpers
    // =====================================================================

    /** @return the end of the name starting at {@code at}, or {@code at} when none starts there */
    private static int scanName(String s, int at) {
        if (at >= s.length() || !Lexis.isIdentStart(s.charAt(at))) {
            return at;
        }
        return Lexis.scanIdent(s, at);
    }

    private static String first(String current, String candidate) {
        return current != null ? current : candidate;
    }

    /** Every run of whitespace as one space, trimmed. */
    static String collapse(String text) {
        return text == null ? "" : text.trim().replaceAll("\\s+", " ");
    }
}
