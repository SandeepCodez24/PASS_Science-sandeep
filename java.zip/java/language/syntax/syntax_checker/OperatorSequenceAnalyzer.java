package language.syntax.syntax_checker;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Reports operator combinations that have no meaning.
 *
 * <h3>The rule</h3>
 * After any operator the next thing must be a value, or a <b>single</b> sign
 * ({@code +} / {@code -}) followed by a value. {@code +} and {@code -} are the
 * only symbols that may describe the sign of what follows them; every other
 * operator needs a value on its left.
 *
 * <pre>
 *   valid                         error
 *   5*-5      5*+5    5^-1        a*&#47;b     a*%b     5+*5     5-*5
 *   5+-5      5--5    a = -b      5*+-5    --5      a+^b     a = *b
 *   a >= -1   f(-2, +3)           a ==     b = 2 +  * 5      f(a+)
 *   5!        5!!     (a+b)!      5!!!     5*!3     a = !b
 *   a//b      a != b  a !&amp; b      a///b
 *   (a+b)!==c  5!!==c
 * </pre>
 *
 * <h3>Operators</h3>
 * Binary: {@code + - * / ^ % // = == != > < >= <= && || !& !|} (and single
 * {@code &} / {@code |}, read as binary so they are never mistaken for a
 * value). Postfix: {@code !} (factorial), at most twice in a row. The two-
 * character forms are read as one token, so {@code ==} or {@code //} is never
 * two operators. {@code ^^} (superscript shorthand) is styling, not an
 * operator, and is skipped; {@code __} is part of a name; {@code ~~} is removed
 * by {@link SourceModel} before this class sees the line.
 *
 * <h3>Factorial before {@code ==}</h3>
 * {@code (P+Q)!==A10} used to be read longest-match-first as {@code !=}
 * followed by a stray {@code =}, which is an error whichever way it is
 * spaced. With a value on the left it is now read as factorial then
 * {@code ==}, i.e. {@code (P+Q)! == A10}. Neural Code has no {@code !==}
 * operator, so this reading can never hide a real one. {@code a!=b} keeps its
 * meaning: a {@code !} is taken as factorial ahead of {@code !=} only when a
 * second {@code =} follows.
 *
 * <h3>Spacing</h3>
 * Spaces never matter: {@code 2 * + 5} is read exactly like {@code 2*+5}.
 *
 * <h3>Who reports what</h3>
 * <ul>
 * <li>A fault whose operator is {@code ^} is left to
 * {@link ExponentSyntaxAnalyzer}, which already names it precisely ("no base",
 * "no power"). Reporting it here too would count one mistake twice.</li>
 * <li>A line ending in an operator is reported here, with the operator named.
 * {@link SyntaxLineAnalyzer} no longer treats a trailing operator as an
 * "incomplete line", for the same reason.</li>
 * </ul>
 *
 * <p>
 * The check runs on {@link SourceModel}'s masked text, so an operator inside a
 * string literal or a comment is invisible.
 */
final class OperatorSequenceAnalyzer {

    static final String AFTER_OPERATOR =
            "'%s' cannot follow '%s' (only '+' or '-' may come after an operator)";
    static final String TOO_MANY_SIGNS =
            "Too many signs: only one '+' or '-' may stand before a value";
    static final String NO_VALUE_BEFORE = "Operator '%s' has no value before it";
    static final String NO_VALUE_AFTER = "Operator '%s' has no value after it";
    static final String SIGN_NO_VALUE = "Sign '%s' has no value after it";
    static final String DANGLING = "Line ends with operator '%s'";
    static final String FACTORIAL_LIMIT = "Factorial '!' may repeat at most twice (5!! is the limit)";
    static final String FACTORIAL_PREFIX = "'!' is a postfix factorial and needs a value before it";

    /** Longest run of postfix factorials accepted ({@code 5!!}). */
    private static final int MAX_FACTORIALS = 2;

    /** Two-character operators, read as a single token. */
    private static final String[] COMPOUND = { "==", "!=", ">=", "<=", "&&", "||", "!&", "!|", "//" };

    /** Single-character binary operators ({@code +} and {@code -} are handled as signs too). */
    private static final String SINGLE_BINARY = "+-*/^%=<>&|";

    /**
     * Words after which an expression begins. A value is expected next, so an
     * operator straight after one ({@code if * a:}) has nothing on its left.
     */
    private static final Set<String> KEYWORDS = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(
            "if", "elseif", "elif", "else", "for", "while", "return", "break", "continue",
            "and", "or", "not", "is_in", "is_not_in", "in", "new", "let",
            "function", "class", "private", "protected", "abstract", "reversible",
            "require", "ensure", "loop",
            "iend", "wend", "fend", "fnend", "csend", "end", "endif", "endfor", "endwhile")));

    private OperatorSequenceAnalyzer() {
    }

    // ─────────────────────────────────────────────────────────────────────
    // Public (package) surface
    // ─────────────────────────────────────────────────────────────────────

    /**
     * @param code raw editor text
     * @return zero-based line index to message
     */
    static Map<Integer, String> analyze(String code) {
        return analyze(SourceModel.of(code));
    }

    /**
     * @param model the cleaned document
     * @return zero-based line index to a user-facing message, one per faulty line
     */
    static Map<Integer, String> analyze(SourceModel model) {
        Map<Integer, String> faults = new HashMap<>();
        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed() || line.isBlank() || line.hasUnterminatedString()) {
                continue;
            }
            String message = checkLine(line.masked());
            if (message != null) {
                faults.put(line.index(), message);
            }
        }
        return Collections.unmodifiableMap(faults);
    }

    // ─────────────────────────────────────────────────────────────────────
    // Line check
    // ─────────────────────────────────────────────────────────────────────

    /** Scan state for one logical line. */
    private static final class State {
        /** True at the start of an expression: a value (or one sign) must come next. */
        boolean expectValue = true;
        /** The binary operator still waiting for its right-hand value, or null. */
        String pendingOperator;
        /** Signs seen since the last value or operator. */
        int signs;
        /** The last sign seen, for the message. */
        String lastSign;

        void value() {
            expectValue = false;
            pendingOperator = null;
            signs = 0;
            lastSign = null;
        }

        void restart() {
            expectValue = true;
            pendingOperator = null;
            signs = 0;
            lastSign = null;
        }
    }

    /**
     * @param s one masked logical line
     * @return the first fault on the line, or null
     */
    static String checkLine(String s) {
        if (s == null) {
            return null;
        }
        String trimmed = s.trim();
        if (trimmed.isEmpty() || trimmed.startsWith("@")) {
            return null; // CLI-style command line
        }
        if (trimmed.equals("clear") || trimmed.startsWith("clear ")) {
            return null; // clear A B
        }

        State st = new State();
        int n = s.length();
        int i = 0;

        while (i < n) {
            char c = s.charAt(i);

            if (Character.isWhitespace(c)) {
                i++;
                continue;
            }

            // ── Values ────────────────────────────────────────────────────
            if (c == '"' || c == '\'') {
                int close = s.indexOf(c, i + 1);
                i = close < 0 ? n : close + 1;
                st.value();
                continue;
            }
            if (Character.isDigit(c) || (c == '.' && i + 1 < n && Character.isDigit(s.charAt(i + 1)))) {
                i = scanNumber(s, i);
                st.value();
                continue;
            }
            if (c == '\\' && i + 1 < n && OperandAdjacencyAnalyzer.isIdentStart(s.charAt(i + 1))) {
                i = scanIdent(s, i + 1);
                st.value();
                continue;
            }
            if (OperandAdjacencyAnalyzer.isIdentStart(c)) {
                int end = scanIdent(s, i);
                if (KEYWORDS.contains(s.substring(i, end))) {
                    st.restart();
                } else {
                    st.value();
                }
                i = end;
                continue;
            }

            // ── Brackets and separators ───────────────────────────────────
            if (c == '(' || c == '[' || c == '{') {
                st.restart();
                i++;
                continue;
            }
            if (c == ')' || c == ']' || c == '}') {
                String fault = missingRightValue(st);
                if (fault != null) {
                    return fault;
                }
                st.value();
                i++;
                while (i < n && OperandAdjacencyAnalyzer.isScriptPostfix(s.charAt(i))) {
                    i++;
                }
                continue;
            }
            if (c == ',' || c == ';' || c == ':') {
                String fault = missingRightValue(st);
                if (fault != null) {
                    return fault;
                }
                st.restart();
                i++;
                continue;
            }

            // ── @name(...) annotation mid-line: skipped whole ─────────────
            if (c == '@') {
                i = skipAnnotation(s, i);
                continue;
            }

            // ── '^^' superscript shorthand: styling, not an operator ──────
            if (c == '^' && i + 1 < n && s.charAt(i + 1) == '^') {
                i += 2;
                continue;
            }

            // ── '^{...}' brace superscript: the '^' is styling too ────────
            if (c == '^') {
                int next = nextNonSpace(s, i + 1);
                if (next < n && s.charAt(next) == '{') {
                    i++;
                    continue;
                }
            }

            // ── '!' ───────────────────────────────────────────────────────
            if (c == '!' && (!startsCompound(s, i) || (!st.expectValue && factorialBeforeEquals(s, i)))) {
                if (st.expectValue) {
                    return FACTORIAL_PREFIX;
                }
                int run = 0;
                int j = i;
                while (j < n && s.charAt(j) == '!' && (!startsCompound(s, j) || factorialBeforeEquals(s, j))) {
                    run++;
                    j++;
                }
                if (run > MAX_FACTORIALS) {
                    return FACTORIAL_LIMIT;
                }
                i = j; // still just after a value
                continue;
            }

            // ── Operators ─────────────────────────────────────────────────
            String op = readOperator(s, i);
            if (op != null) {
                String fault = acceptOperator(st, op);
                if (fault != null) {
                    return fault;
                }
                i += op.length();
                continue;
            }

            // Anything else ('.', '~', unknown symbols) is neutral here.
            i++;
        }

        // ── End of line ───────────────────────────────────────────────────
        if (st.signs > 0) {
            return String.format(SIGN_NO_VALUE, st.lastSign);
        }
        if (st.pendingOperator != null && !"^".equals(st.pendingOperator)) {
            return String.format(DANGLING, st.pendingOperator);
        }
        return null;
    }

    /**
     * Applies one operator to the state.
     *
     * @return the fault, or null when the operator is legal here
     */
    private static String acceptOperator(State st, String op) {
        boolean sign = op.equals("+") || op.equals("-");

        if (!st.expectValue) {
            // A value is on the left: this is a binary operator.
            st.expectValue = true;
            st.pendingOperator = op;
            st.signs = 0;
            st.lastSign = null;
            return null;
        }

        if (sign) {
            if (st.signs >= 1) {
                if ("^".equals(st.pendingOperator)) {
                    // ExponentSyntaxAnalyzer reports "no power after '^'".
                    st.restart();
                    return null;
                }
                return TOO_MANY_SIGNS;
            }
            st.signs++;
            st.lastSign = op;
            return null;
        }

        // A non-sign operator where a value was expected.
        if ("^".equals(op) || "^".equals(st.pendingOperator)) {
            // Left to ExponentSyntaxAnalyzer, so one mistake is counted once.
            st.restart();
            return null;
        }
        if (st.signs > 0) {
            return String.format(AFTER_OPERATOR, op, st.lastSign);
        }
        if (st.pendingOperator != null) {
            return String.format(AFTER_OPERATOR, op, st.pendingOperator);
        }
        return String.format(NO_VALUE_BEFORE, op);
    }

    /**
     * Called when a closing bracket or a separator arrives: an operator or a
     * sign still waiting for its value is a fault ({@code f(a+)}, {@code a*;}).
     */
    private static String missingRightValue(State st) {
        if (st.signs > 0) {
            return String.format(SIGN_NO_VALUE, st.lastSign);
        }
        if (st.pendingOperator != null && !"^".equals(st.pendingOperator)) {
            return String.format(NO_VALUE_AFTER, st.pendingOperator);
        }
        return null;
    }

    // ─────────────────────────────────────────────────────────────────────
    // Tokens
    // ─────────────────────────────────────────────────────────────────────

    /** True when a two-character operator begins at {@code i}. */
    private static boolean startsCompound(String s, int i) {
        for (String compound : COMPOUND) {
            if (s.startsWith(compound, i)) {
                return true;
            }
        }
        return false;
    }

    /**
     * True when the {@code !} at {@code i} begins {@code !==}: a factorial
     * followed by {@code ==}, not {@code !=} followed by a stray {@code =}.
     */
    private static boolean factorialBeforeEquals(String s, int i) {
        return s.startsWith("!==", i);
    }

    /** The operator at {@code i}, longest match first, or null. */
    private static String readOperator(String s, int i) {
        for (String compound : COMPOUND) {
            if (s.startsWith(compound, i)) {
                return compound;
            }
        }
        char c = s.charAt(i);
        return SINGLE_BINARY.indexOf(c) >= 0 ? String.valueOf(c) : null;
    }

    private static int scanIdent(String s, int i) {
        int j = i;
        while (j < s.length() && OperandAdjacencyAnalyzer.isIdentPart(s.charAt(j))) {
            j++;
        }
        return j;
    }

    /** Digits, fraction, exponent (so the '-' in 1.5e-3 is part of the number). */
    private static int scanNumber(String s, int i) {
        int n = s.length();
        int j = i;
        while (j < n && Character.isDigit(s.charAt(j))) {
            j++;
        }
        if (j < n && s.charAt(j) == '.' && j + 1 < n && Character.isDigit(s.charAt(j + 1))) {
            j++;
            while (j < n && Character.isDigit(s.charAt(j))) {
                j++;
            }
        } else if (j < n && s.charAt(j) == '.' && (j + 1 >= n || !OperandAdjacencyAnalyzer.isIdentStart(s.charAt(j + 1)))) {
            j++; // "3." followed by an operator or the end
        }
        if (j < n && (s.charAt(j) == 'e' || s.charAt(j) == 'E')) {
            int k = j + 1;
            if (k < n && (s.charAt(k) == '+' || s.charAt(k) == '-')) {
                k++;
            }
            if (k < n && Character.isDigit(s.charAt(k))) {
                j = k;
                while (j < n && Character.isDigit(s.charAt(j))) {
                    j++;
                }
            }
        }
        // Super/subscript digits and styled groups written on the number.
        while (j < n && (OperandAdjacencyAnalyzer.isScriptPostfix(s.charAt(j))
                || OperandAdjacencyAnalyzer.isMarker(s.charAt(j)))) {
            j++;
            while (j < n && OperandAdjacencyAnalyzer.isIdentPart(s.charAt(j))) {
                j++;
            }
        }
        return j;
    }

    private static int skipAnnotation(String s, int at) {
        int n = s.length();
        int j = at + 1;
        while (j < n && OperandAdjacencyAnalyzer.isIdentPart(s.charAt(j))) {
            j++;
        }
        int k = nextNonSpace(s, j);
        if (k < n && s.charAt(k) == '(') {
            int depth = 0;
            for (int m = k; m < n; m++) {
                char c = s.charAt(m);
                if (c == '(') {
                    depth++;
                } else if (c == ')' && --depth == 0) {
                    return m + 1;
                }
            }
            return n;
        }
        return j;
    }

    private static int nextNonSpace(String s, int from) {
        int i = from;
        while (i < s.length() && Character.isWhitespace(s.charAt(i))) {
            i++;
        }
        return i;
    }
}
