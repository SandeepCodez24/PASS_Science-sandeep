package language.syntax.syntax_checker;

import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

final class ExponentSyntaxAnalyzer {

    // Single '^' is valid only when followed by a numeric exponent like ^2, ^-3, ^+10.
    // '^^' is reserved for superscript mode and is not treated as this error.
    private static final Pattern INVALID_SINGLE_CARET_PATTERN = Pattern.compile("\\^(?!\\^)(?!\\s*[+-]?\\d)");

    private ExponentSyntaxAnalyzer() {
    }

    static Set<Integer> findInvalidExponentErrorLines(String code) {
        Set<Integer> errorLines = new HashSet<>();
        if (code == null || code.isEmpty()) {
            return errorLines;
        }

        String[] lines = code.split("\\R", -1);
        Set<Integer> docstringLines = DocstringErrorAnalyzer.findDocstringBlockLines(code);

        for (int i = 0; i < lines.length; i++) {
            if (docstringLines.contains(i)) {
                continue;
            }

            String line = SyntaxTextUtils.stripTrailingComment(lines[i]);
            String sanitized = stripStringLiterals(line);
            sanitized = trimToAssignmentLeftSide(sanitized);
            if (INVALID_SINGLE_CARET_PATTERN.matcher(sanitized).find()) {
                errorLines.add(i);
            }
        }

        return errorLines;
    }

    static int countInvalidExponentErrors(String code) {
        return findInvalidExponentErrorLines(code).size();
    }

    private static String stripStringLiterals(String text) {
        StringBuilder builder = new StringBuilder(text.length());
        boolean inSingleQuote = false;
        boolean inDoubleQuote = false;

        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);
            if (ch == '"' && !SyntaxTextUtils.isEscaped(text, i) && !inSingleQuote) {
                inDoubleQuote = !inDoubleQuote;
                builder.append(' ');
                continue;
            }
            if (ch == '\'' && !SyntaxTextUtils.isEscaped(text, i) && !inDoubleQuote) {
                inSingleQuote = !inSingleQuote;
                builder.append(' ');
                continue;
            }

            builder.append((inSingleQuote || inDoubleQuote) ? ' ' : ch);
        }

        return builder.toString();
    }

    private static String trimToAssignmentLeftSide(String text) {
        int equalsIndex = indexOfAssignment(text);
        if (equalsIndex < 0) {
            return text;
        }
        return text.substring(0, equalsIndex);
    }

    private static int indexOfAssignment(String line) {
        int equalsIndex = line.indexOf('=');
        if (equalsIndex < 0) {
            return -1;
        }
        if (equalsIndex + 1 < line.length() && line.charAt(equalsIndex + 1) == '=') {
            return -1;
        }
        if (equalsIndex > 0 && line.charAt(equalsIndex - 1) == '=') {
            return -1;
        }
        return equalsIndex;
    }
}