package language.syntax.syntax_checker;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Checks every power operator {@code ^} on a line.
 *
 * <h3>What was wrong</h3>
 * The old rule accepted a {@code ^} only when a digit followed it
 * ({@code ^2}, {@code ^-3}), so {@code A^B}, {@code A^sqr(4)} and
 * {@code sqr(5)^sqrt(6.3)} were all reported, although the interpreter runs
 * every one of them. It also cut each line at its {@code =} and looked only at
 * the part on the left, so the right-hand side of an assignment was never
 * checked at all: {@code A14 = e^(A-B);} passed while
 * {@code publish(A^B,0);} failed. Too strict and too blind at once.
 *
 * <h3>The rule now</h3>
 * A {@code ^} is a binary operator, so it needs an operand on each side.
 * <ul>
 * <li><b>Base</b> (before it): a number, a name (Greek, Tamil and styled names
 * included), a closing {@code )} {@code ]} {@code }}, or a postfix
 * {@code !}.</li>
 * <li><b>Power</b> (after it): a number, a name, a function call, an opening
 * {@code (} or {@code [}, a {@code \var(} / {@code \con(} form, or any of
 * those behind a run of unary {@code +} / {@code -} signs. The run has no
 * limit, so {@code 5^-6}, {@code 5^++6} and {@code 5^----6} are all powers;
 * only one sign used to be skipped, and the rest of the run was reported as
 * "no power after '^'".</li>
 * <li><b>Not on the left of an assignment.</b> {@code A^2 = 5} assigns to a
 * power, which is meaningless, and is an error.</li>
 * </ul>
 * {@code ^^} (superscript mode) and {@code ^{...}} (brace superscript) are
 * styling syntax, not powers, and are left to {@link ErrorChecker}'s
 * subscript/superscript rules exactly as before.
 *
 * <p>
 * The whole line is checked, on {@link SourceModel}'s masked text, so a
 * {@code ^} inside {@code publish("2^10 =", 2^10)}'s literal is invisible and
 * the real {@code 2^10} is still checked.
 */
final class ExponentSyntaxAnalyzer {

    static final String NO_BASE = "Exponent '^' has no base before it";
    static final String NO_POWER = "Exponent '^' has no power after it";
    static final String ASSIGN_TO_POWER = "Cannot assign to a power: '^' is on the left of '='";

    private ExponentSyntaxAnalyzer() {
    }

    /**
     * @param code raw editor text
     * @return zero-based indices of lines with an invalid exponent
     */
    static Set<Integer> findInvalidExponentErrorLines(String code) {
        return findInvalidExponentErrorLines(SourceModel.of(code));
    }

    /**
     * @param model the cleaned document
     * @return zero-based indices of lines with an invalid exponent
     */
    static Set<Integer> findInvalidExponentErrorLines(SourceModel model) {
        return new HashSet<>(analyze(model).keySet());
    }

    /**
     * @param code raw editor text
     * @return how many lines carry an invalid exponent
     */
    static int countInvalidExponentErrors(String code) {
        return analyze(SourceModel.of(code)).size();
    }

    /**
     * @param model the cleaned document
     * @return zero-based line index to the reason, one entry per faulty line
     */
    static Map<Integer, String> analyze(SourceModel model) {
        Map<Integer, String> faults = new HashMap<>();
        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed() || line.isBlank() || line.hasUnterminatedString()) {
                continue;
            }
            String message = checkLine(line.masked());
            if (message != null) {
                faults.put(line.index(), message);
            }
        }
        return Collections.unmodifiableMap(faults);
    }

    /**
     * @param s one masked logical line
     * @return the first fault on the line, or null when every {@code ^} is sound
     */
    static String checkLine(String s) {
        if (s == null || s.indexOf('^') < 0) {
            return null;
        }
        int n = s.length();
        int assignment = assignmentIndex(s);

        for (int i = 0; i < n; i++) {
            if (s.charAt(i) != '^') {
                continue;
            }
            // '^^' is the superscript-mode marker, not two powers.
            if (i + 1 < n && s.charAt(i + 1) == '^') {
                i++;
                continue;
            }
            int right = nextNonSpace(s, i + 1);
            // '^{...}' is a brace superscript, checked by ErrorChecker.
            if (right < n && s.charAt(right) == '{') {
                continue;
            }
            if (!hasBase(s, i)) {
                return NO_BASE;
            }
            if (!hasPower(s, right)) {
                return NO_POWER;
            }
            if (assignment >= 0 && i < assignment) {
                return ASSIGN_TO_POWER;
            }
        }
        return null;
    }

    private static boolean hasBase(String s, int caret) {
        int p = prevNonSpace(s, caret - 1);
        if (p < 0) {
            return false;
        }
        char c = s.charAt(p);
        return OperandAdjacencyAnalyzer.isIdentPart(c)
                || c == ')' || c == ']' || c == '}' || c == '!';
    }

    private static boolean hasPower(String s, int at) {
        int n = s.length();
        if (at >= n) {
            return false;
        }
        char c = s.charAt(at);
        // The whole run of signs is skipped: ^--6, ^+-+6, ^----6.
        while (c == '+' || c == '-') {
            at = nextNonSpace(s, at + 1);
            if (at >= n) {
                return false;
            }
            c = s.charAt(at);
        }
        if (c == '.') {
            return at + 1 < n && Character.isDigit(s.charAt(at + 1));
        }
        return Character.isDigit(c)
                || OperandAdjacencyAnalyzer.isIdentStart(c)
                || c == '(' || c == '[' || c == '\\';
    }

    /**
     * Offset of the assignment {@code =} at bracket depth zero, or -1. The
     * comparison forms {@code ==}, {@code !=}, {@code <=}, {@code >=} are not
     * assignments, and an {@code =} inside brackets (a default argument, a
     * keyword argument) is not the statement's assignment either.
     */
    static int assignmentIndex(String s) {
        int depth = 0;
        int n = s.length();
        for (int i = 0; i < n; i++) {
            char c = s.charAt(i);
            if (c == '(' || c == '[' || c == '{') {
                depth++;
            } else if (c == ')' || c == ']' || c == '}') {
                depth = Math.max(0, depth - 1);
            } else if (c == '=' && depth == 0) {
                char before = i > 0 ? s.charAt(i - 1) : ' ';
                char after = i + 1 < n ? s.charAt(i + 1) : ' ';
                if (after == '=' || before == '=' || before == '!' || before == '<' || before == '>') {
                    if (after == '=') {
                        i++;
                    }
                    continue;
                }
                return i;
            }
        }
        return -1;
    }

    private static int nextNonSpace(String s, int from) {
        int i = from;
        while (i < s.length() && Character.isWhitespace(s.charAt(i))) {
            i++;
        }
        return i;
    }

    private static int prevNonSpace(String s, int from) {
        int i = from;
        while (i >= 0 && Character.isWhitespace(s.charAt(i))) {
            i--;
        }
        return i;
    }
}
