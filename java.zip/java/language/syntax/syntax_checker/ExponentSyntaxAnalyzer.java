package language.syntax.syntax_checker;

import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Flags a bare {@code ^} that is not followed by a numeric exponent.
 *
 * <p>
 * Cleaning is no longer done here: the line arrives from {@link SourceModel}
 * already joined across {@code ~~}, stripped of its comment and masked, so a
 * caret inside {@code publish("2^10 =", 2^10)}'s literal is invisible and the
 * real {@code 2^10} is still checked.
 */
final class ExponentSyntaxAnalyzer {

    // Single '^' is valid only when followed by a numeric exponent like ^2, ^-3,
    // ^+10. '^^' is reserved for superscript mode and is not treated as this error.
    private static final Pattern INVALID_SINGLE_CARET_PATTERN = Pattern.compile("\\^(?!\\^)(?!\\s*[+-]?\\d)");

    private ExponentSyntaxAnalyzer() {
    }

    /**
     * @param code raw editor text
     * @return zero-based indices of lines with an invalid exponent
     */
    static Set<Integer> findInvalidExponentErrorLines(String code) {
        return findInvalidExponentErrorLines(SourceModel.of(code));
    }

    /**
     * @param model the cleaned document
     * @return zero-based indices of lines with an invalid exponent
     */
    static Set<Integer> findInvalidExponentErrorLines(SourceModel model) {
        Set<Integer> errorLines = new HashSet<>();

        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed() || line.isBlank()) {
                continue;
            }

            String sanitized = trimToAssignmentLeftSide(line.masked());
            if (INVALID_SINGLE_CARET_PATTERN.matcher(sanitized).find()) {
                errorLines.add(line.index());
            }
        }

        return errorLines;
    }

    /**
     * @param code raw editor text
     * @return how many lines carry an invalid exponent
     */
    static int countInvalidExponentErrors(String code) {
        return findInvalidExponentErrorLines(code).size();
    }

    private static String trimToAssignmentLeftSide(String text) {
        int equalsIndex = indexOfAssignment(text);
        return equalsIndex < 0 ? text : text.substring(0, equalsIndex);
    }

    private static int indexOfAssignment(String line) {
        int equalsIndex = line.indexOf('=');
        if (equalsIndex < 0) {
            return -1;
        }
        if (equalsIndex + 1 < line.length() && line.charAt(equalsIndex + 1) == '=') {
            return -1;
        }
        if (equalsIndex > 0 && line.charAt(equalsIndex - 1) == '=') {
            return -1;
        }
        return equalsIndex;
    }
}
