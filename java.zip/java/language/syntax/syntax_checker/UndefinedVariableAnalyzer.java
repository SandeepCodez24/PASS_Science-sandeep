package language.syntax.syntax_checker;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import ui.managers.LanguageDesignManager;

final class UndefinedVariableAnalyzer {

    static final class Result {
        final int errorCount;
        final Set<Integer> errorLines;

        private Result(int errorCount, Set<Integer> errorLines) {
            this.errorCount = errorCount;
            this.errorLines = errorLines;
        }
    }

    private static final Pattern IDENTIFIER_PATTERN = Pattern.compile("(?U)[\\p{L}_][\\p{L}\\p{N}_]*");
    private static final Set<String> KEYWORDS = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(
            "print", "if", "else", "elseif", "elif", "for", "while", "return", "break", "continue",
            "true", "false", "null", "and", "or", "not", "is_in", "is_not_in", "new","clear","iend", "wend", "fend")));

    private UndefinedVariableAnalyzer() {
    }

    static Result analyze(String code) {
        if (code == null || code.isEmpty()) {
            return new Result(0, new HashSet<>());
        }

        int errors = 0;
        Set<Integer> errorLines = new HashSet<>();
        Set<String> knownVariables = new HashSet<>();
        String[] lines = code.split("\\R", -1);
        Set<Integer> docstringLines = DocstringErrorAnalyzer.findDocstringBlockLines(code);

        for (int i = 0; i < lines.length; i++) {
            if (docstringLines.contains(i)) {
                continue;
            }

            int lineErrors = 0;
            String normalizedLine = normalizeVariableNames(SyntaxTextUtils.stripTrailingComment(lines[i]));
            for (String statement : splitStatements(normalizedLine)) {
                String line = statement.trim();
                if (line.isEmpty()) {
                    continue;
                }

                if (line.startsWith("print")) {
                    String printedValue = extractPrintArgument(line);
                    String normalizedPrintedValue = normalizeVariableName(printedValue);
                    if (normalizedPrintedValue != null
                            && isPotentialIdentifier(normalizedPrintedValue)
                            && !knownVariables.contains(normalizedPrintedValue)) {
                        lineErrors++;
                    }
                    continue;
                }

                int equalsIndex = indexOfAssignment(line);
                if (equalsIndex >= 0) {
                    String leftSide = normalizeVariableName(line.substring(0, equalsIndex).trim());
                    String rightSide = line.substring(equalsIndex + 1).trim();
                    if (!leftSide.isEmpty()) {
                        knownVariables.add(leftSide);
                    }
                    lineErrors += countUndefinedIdentifiers(rightSide, knownVariables);
                } else {
                    lineErrors += countUndefinedIdentifiers(line, knownVariables);
                }
            }

            if (lineErrors > 0) {
                errorLines.add(i);
            }
            errors += lineErrors;
        }

        return new Result(errors, errorLines);
    }

    private static int countUndefinedIdentifiers(String text, Set<String> knownVariables) {
        if (text == null || text.isEmpty()) {
            return 0;
        }

        String sanitizedText = normalizeVariableNames(stripStringLiterals(text));
        int errors = 0;
        Matcher matcher = IDENTIFIER_PATTERN.matcher(sanitizedText);
        Set<String> seen = new HashSet<>();
        while (matcher.find()) {
            String identifier = matcher.group();
            if (KEYWORDS.contains(identifier) || knownVariables.contains(identifier) || seen.contains(identifier)) {
                continue;
            }
            if (isFunctionLike(sanitizedText, matcher.end())) {
                continue;
            }

            seen.add(identifier);
            errors++;
        }
        return errors;
    }

    private static java.util.List<String> splitStatements(String line) {
        if (line == null || line.isEmpty()) {
            return Collections.singletonList("");
        }

        java.util.List<String> statements = new java.util.ArrayList<>();
        StringBuilder current = new StringBuilder(line.length());
        boolean inSingleQuote = false;
        boolean inDoubleQuote = false;

        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (ch == '"' && !SyntaxTextUtils.isEscaped(line, i) && !inSingleQuote) {
                inDoubleQuote = !inDoubleQuote;
                current.append(ch);
                continue;
            }
            if (ch == '\'' && !SyntaxTextUtils.isEscaped(line, i) && !inDoubleQuote) {
                inSingleQuote = !inSingleQuote;
                current.append(ch);
                continue;
            }

            if (ch == ';' && !inSingleQuote && !inDoubleQuote) {
                statements.add(current.toString());
                current.setLength(0);
                continue;
            }

            current.append(ch);
        }

        statements.add(current.toString());
        return statements;
    }

    private static String stripStringLiterals(String text) {
        StringBuilder builder = new StringBuilder(text.length());
        boolean inSingleQuote = false;
        boolean inDoubleQuote = false;

        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);
            if (ch == '"' && !SyntaxTextUtils.isEscaped(text, i) && !inSingleQuote) {
                inDoubleQuote = !inDoubleQuote;
                builder.append(' ');
                continue;
            }
            if (ch == '\'' && !SyntaxTextUtils.isEscaped(text, i) && !inDoubleQuote) {
                inSingleQuote = !inSingleQuote;
                builder.append(' ');
                continue;
            }

            builder.append((inSingleQuote || inDoubleQuote) ? ' ' : ch);
        }

        return builder.toString();
    }

    private static boolean isFunctionLike(String text, int end) {
        int nextIndex = end;
        while (nextIndex < text.length() && Character.isWhitespace(text.charAt(nextIndex))) {
            nextIndex++;
        }
        return nextIndex < text.length() && text.charAt(nextIndex) == '(';
    }

    private static boolean isPotentialIdentifier(String text) {
        return text != null && IDENTIFIER_PATTERN.matcher(text).matches() && !KEYWORDS.contains(text);
    }

    private static String normalizeVariableNames(String text) {
        return LanguageDesignManager.normalizeMarkersForVariables(text);
    }

    private static String normalizeVariableName(String text) {
        if (text == null || text.isEmpty()) {
            return text;
        }
        return normalizeVariableNames(text).trim();
    }

    private static String extractPrintArgument(String line) {
        int start = line.indexOf('(');
        int end = line.lastIndexOf(')');
        if (start == -1 || end == -1 || end <= start) {
            return null;
        }

        String argument = line.substring(start + 1, end).trim();
        if ((argument.startsWith("\"") && argument.endsWith("\""))
                || (argument.startsWith("'") && argument.endsWith("'"))) {
            return null;
        }
        return argument;
    }

    private static int indexOfAssignment(String line) {
        int equalsIndex = line.indexOf('=');
        if (equalsIndex < 0) {
            return -1;
        }
        if (equalsIndex + 1 < line.length() && line.charAt(equalsIndex + 1) == '=') {
            return -1;
        }
        if (equalsIndex > 0 && line.charAt(equalsIndex - 1) == '=') {
            return -1;
        }
        return equalsIndex;
    }
}
