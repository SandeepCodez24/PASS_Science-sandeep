package language.syntax.syntax_checker;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import ui.managers.LanguageDesignManager;

/**
 * Reports references to names that no open scope defines.
 *
 * <h3>What changed</h3>
 * This was the only analyzer that already understood {@code ~~} continuations,
 * comments and string literals -- it had its own private copy of each. All
 * three now come from {@link SourceModel}, so this file can never again be the
 * only one that is right. Two behavioural changes came with the move:
 *
 * <ul>
 * <li><b>{@code publish} is the print statement.</b> There was a special branch
 * for lines starting with {@code print} that pulled out the text between the
 * first {@code (} and the last {@code )} and checked it as a single name. For
 * {@code publish(a, b, c)} that produced the string {@code "a, b, c"}, which is
 * not identifier-shaped, so the branch checked nothing at all and every
 * argument of every multi-argument call went unexamined. The branch is gone;
 * the general path below checks each argument properly.</li>
 * <li><b>Masked text throughout.</b> Names are matched against text whose
 * string bodies are already blanked, so the words in
 * {@code publish("total is", t)} are not read as variables.</li>
 * </ul>
 */
final class UndefinedVariableAnalyzer {

    static final class Result {
        final int errorCount;
        final Set<Integer> errorLines;

        private Result(int errorCount, Set<Integer> errorLines) {
            this.errorCount = errorCount;
            this.errorLines = errorLines;
        }
    }

    private static final Pattern IDENTIFIER_PATTERN = Pattern.compile("(?U)[\\p{L}_][\\p{L}\\p{N}_]*");

    // A `for` header DECLARES its loop variable, which the generic `=`-based
    // heuristic below cannot see: for `for i = [12:23]:` it would take
    // everything left of the `=` and register the compound string "for i" as
    // the variable, leaving the real loop variable `i` unknown and every later
    // `publish(i)` flagged as undefined. Matched before that heuristic so the
    // loop variable is captured on its own. The trailing `:` is optional --
    // both `for i = [lo:hi]:` and the older colon-less `for i = [lo:hi]` are
    // valid -- and `:?` keeps it out of both capture groups.
    private static final Pattern FOR_HEADER_PATTERN = Pattern
            .compile("(?U)^for\\s+([\\p{L}_][\\p{L}\\p{N}_]*)\\s*=\\s*(.*?)\\s*:?\\s*$");

    // A `class` header declares the class name (later used as a constructor,
    // `r = Reading(23.5)`) and optionally names a parent class. Both are type
    // names, not undefined variables. `abstract`/`reversible` may prefix it.
    // The trailing `(?:@name(...))?` allows a class annotation such as
    // `class Controller() @rate(10Hz)` (Temporal Determinism).
    private static final Pattern CLASS_HEADER_PATTERN = Pattern.compile(
            "(?U)^(?:(?:abstract|reversible)\\s+)*class\\s+([\\p{L}_][\\p{L}\\p{N}_]*)"
                    + "\\s*(?:\\(([^)]*)\\))?\\s*(?:@[\\p{L}_][\\p{L}\\p{N}_]*\\s*\\([^)]*\\)\\s*)?:?\\s*$");

    // A class field declaration: `private mean, std;` / `protected count;`.
    // These declare names with no `=`, so without this they read as bare
    // references to undefined variables.
    private static final Pattern FIELD_DECLARATION_PATTERN = Pattern.compile(
            "(?U)^(?:private|protected)\\s+([\\p{L}_][\\p{L}\\p{N}_]*(?:\\s*,\\s*[\\p{L}_][\\p{L}\\p{N}_]*)*)\\s*$");

    // `function ...` in any of its four header shapes, optionally prefixed by
    // an access modifier when the function is a class method
    // (`private function base(v)`). The remainder after the keyword is parsed
    // procedurally by parseFunctionHeader().
    private static final Pattern FUNCTION_HEADER_PATTERN = Pattern
            .compile("(?U)^(?:(?:private|protected|abstract)\\s+)*function\\b\\s*(.*)$");

    // A multi-output call binds several NEW names at once:
    // `(sum1, prod1) = arithmetics(3, 4);`. The generic `=` heuristic would
    // register the single compound string "(sum1, prod1)", leaving both real
    // names unknown for every later line that uses them.
    private static final Pattern MULTI_OUTPUT_ASSIGN_PATTERN = Pattern.compile(
            "(?U)^\\(\\s*([\\p{L}_][\\p{L}\\p{N}_]*(?:\\s*,\\s*[\\p{L}_][\\p{L}\\p{N}_]*)+)\\s*\\)\\s*=\\s*(.*)$");

    private static final Pattern LEADING_IDENTIFIER_PATTERN =
            Pattern.compile("(?U)^([\\p{L}_][\\p{L}\\p{N}_]*)");

    // Every reserved word the lexer recognises plus every block terminator the
    // parser accepts. Anything missing here is read as a bare variable
    // reference and reported as undefined -- which is why `function`, `class`,
    // `fnend`, `csend`, `require`, `ensure` and the access modifiers each used
    // to produce an error on their own line. `base` is the reserved instance
    // self-reference inside a class body, not a user variable.
    //
    // `print` stays in the list purely so older scripts do not light up red.
    // `publish` is the statement the language uses now.
    private static final Set<String> KEYWORDS = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(
            "print", "publish", "if", "else", "elseif", "elif", "for", "while", "return", "break", "continue",
            "true", "false", "null", "and", "or", "not", "is_in", "is_not_in", "new", "clear",
            "iend", "wend", "fend", "fnend", "csend", "end", "endif", "endfor", "endwhile",
            "function", "class", "loop", "in", "base",
            "private", "protected", "abstract", "require", "ensure", "reversible")));

    // Names the parser resolves itself, so they are never user variables: the
    // physical unit constants and the built-in math/physics constants table.
    // Without these, `d = 5 * m;` reported `m` as undefined and every
    // unit-bearing line was blocked.
    private static final Set<String> BUILTIN_CONSTANTS = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(
            "m", "s", "kg", "N", "Pa",
            "pi", "e", "g", "r", "avogadro", "h", "sigma", "k_e", "m_e", "m_p", "e_charge",
            "grav_const", "\u03C0", "gravity", "gas_constant", "planck", "planck_constant",
            "gravitational_constant", "\u03C3", "stefan_boltzmann", "ke", "coulomb_const",
            "me", "electron_mass", "mp", "proton_mass", "echarge", "elementary_charge", "g_const")));

    /** The three name groups a `function` header introduces. */
    private static final class FunctionHeader {
        final String name;
        final List<String> outputs;
        final List<String> parameters;

        FunctionHeader(String name, List<String> outputs, List<String> parameters) {
            this.name = name;
            this.outputs = outputs;
            this.parameters = parameters;
        }
    }

    private UndefinedVariableAnalyzer() {
    }

    /**
     * @param code raw editor text
     * @return the undefined-variable report
     */
    static Result analyze(String code) {
        return analyze(SourceModel.of(code));
    }

    /**
     * @param model the cleaned document
     * @return the undefined-variable report
     */
    static Result analyze(SourceModel model) {
        int errors = 0;
        Set<Integer> errorLines = new HashSet<>();
        if (model.size() == 0) {
            return new Result(0, errorLines);
        }

        // Scope stack. Index 0 is the file-level scope; a `function` or `class`
        // header pushes a scope that `fnend`/`csend` pops, so parameters and
        // body locals are visible inside the body without leaking out of it. A
        // lookup walks every open scope, so a body can still reference
        // file-level variables declared above it.
        Deque<Set<String>> scopes = new ArrayDeque<>();
        scopes.push(new HashSet<>());

        // Stack depth at each open `class` header, so `csend` knows how far to
        // unwind (see the terminator handling below).
        Deque<Integer> classScopeDepths = new ArrayDeque<>();

        // The language allows calling a function or constructing a class that
        // is defined LATER in the file (parser pass 1 pre-registers
        // forward-referenced definitions), so collect every declared name
        // before the line-by-line walk rather than only as it is reached.
        collectDeclaredNames(model, scopes.peek());

        for (SourceModel.Line sourceLine : model.lines()) {
            if (sourceLine.isAbsorbed() || sourceLine.isBlank()) {
                continue;
            }

            int lineErrors = 0;
            String normalizedLine = normalizeVariableNames(sourceLine.masked());

            for (String statement : splitStatements(normalizedLine)) {
                String line = statement.trim();
                if (line.isEmpty()) {
                    continue;
                }

                // Closing a function/class body ends its scope. `csend` unwinds
                // back to the depth recorded when the class opened, so a method
                // body left unclosed inside it cannot strand a scope and leak
                // its parameters into the rest of the file.
                String lowerLine = line.toLowerCase();
                if (lowerLine.equals("fnend")) {
                    if (scopes.size() > 1) {
                        scopes.pop();
                    }
                    continue;
                }
                if (lowerLine.equals("csend")) {
                    int target = classScopeDepths.isEmpty() ? 1 : classScopeDepths.pop();
                    while (scopes.size() > Math.max(target, 1)) {
                        scopes.pop();
                    }
                    continue;
                }

                // `function` header: the output name(s) and every parameter are
                // declared here. Without this the generic `=` heuristic
                // registers the compound string "function B" and the real
                // output `B` plus every parameter stay unknown, so the whole
                // body reports undefined-variable errors.
                Matcher functionHeaderMatcher = FUNCTION_HEADER_PATTERN.matcher(line);
                if (functionHeaderMatcher.matches()) {
                    FunctionHeader header = parseFunctionHeader(functionHeaderMatcher.group(1));
                    Set<String> bodyScope = new HashSet<>();
                    if (header != null) {
                        scopes.peek().add(header.name);
                        bodyScope.addAll(header.outputs);
                        bodyScope.addAll(header.parameters);
                    }
                    scopes.push(bodyScope);
                    continue;
                }

                // `class` header: the class name is a type (used later as a
                // constructor), and a parent name in parentheses is another
                // type -- neither is an undefined variable. The body scope
                // carries `base`, the reserved instance self-reference.
                Matcher classHeaderMatcher = CLASS_HEADER_PATTERN.matcher(line);
                if (classHeaderMatcher.matches()) {
                    scopes.peek().add(normalizeVariableName(classHeaderMatcher.group(1)));
                    classScopeDepths.push(scopes.size());
                    Set<String> bodyScope = new HashSet<>();
                    bodyScope.add("base");
                    String parent = classHeaderMatcher.group(2);
                    if (parent != null && !parent.trim().isEmpty()) {
                        scopes.peek().add(normalizeVariableName(parent.trim()));
                    }
                    scopes.push(bodyScope);
                    continue;
                }

                // Class field declaration: `private mean, std;` declares names
                // without an `=`, so register them rather than reading them as
                // references to undefined variables.
                Matcher fieldDeclarationMatcher = FIELD_DECLARATION_PATTERN.matcher(line);
                if (fieldDeclarationMatcher.matches()) {
                    for (String fieldName : fieldDeclarationMatcher.group(1).split(",")) {
                        String declared = normalizeVariableName(fieldName.trim());
                        if (!declared.isEmpty()) {
                            scopes.peek().add(declared);
                        }
                    }
                    continue;
                }

                // `for` header: register only the loop variable as known, and
                // check the range expression separately so a genuinely
                // undefined bound (`for i = [1:hi]:`) is still reported.
                Matcher forHeaderMatcher = FOR_HEADER_PATTERN.matcher(line);
                if (forHeaderMatcher.matches()) {
                    String loopVar = normalizeVariableName(forHeaderMatcher.group(1));
                    String rangeExpr = forHeaderMatcher.group(2);
                    if (!loopVar.isEmpty()) {
                        scopes.peek().add(loopVar);
                    }
                    lineErrors += countUndefinedIdentifiers(rangeExpr, scopes);
                    continue;
                }

                // Multi-output call: `(sum1, prod1) = arithmetics(3, 4);` binds
                // every name in the parenthesised list.
                Matcher multiOutputMatcher = MULTI_OUTPUT_ASSIGN_PATTERN.matcher(line);
                if (multiOutputMatcher.matches()) {
                    lineErrors += countUndefinedIdentifiers(multiOutputMatcher.group(2), scopes);
                    for (String outputName : multiOutputMatcher.group(1).split(",")) {
                        String bound = normalizeVariableName(outputName.trim());
                        if (!bound.isEmpty()) {
                            scopes.peek().add(bound);
                        }
                    }
                    continue;
                }

                // The text is already masked, so an `=` inside a literal
                // (`publish("t=0-ran:", r0)`) cannot be mistaken for an
                // assignment.
                int equalsIndex = indexOfAssignment(line);
                if (equalsIndex >= 0) {
                    String leftSide = normalizeVariableName(line.substring(0, equalsIndex).trim());
                    String rightSide = line.substring(equalsIndex + 1).trim();

                    // Register the ROOT name, not the whole left-hand side:
                    // `A["name"] = ...`, `A[3][4] = ...` and `obj.field = ...`
                    // all define/modify `A`/`obj`. Registering the compound
                    // text instead left the real variable unknown, so a later
                    // `publish(A)` was reported as undefined.
                    String root = rootIdentifier(leftSide);
                    if (root != null && !root.isEmpty()) {
                        scopes.peek().add(root);
                        // Index expressions on the left are real references:
                        // the `i` in `A[i] = 1` still has to be defined.
                        lineErrors += countUndefinedIdentifiers(leftSide.substring(root.length()), scopes);
                    } else if (!leftSide.isEmpty()) {
                        scopes.peek().add(leftSide);
                    }

                    lineErrors += countUndefinedIdentifiers(rightSide, scopes);
                } else {
                    lineErrors += countUndefinedIdentifiers(line, scopes);
                }
            }

            if (lineErrors > 0) {
                errorLines.add(sourceLine.index());
            }
            errors += lineErrors;
        }

        return new Result(errors, errorLines);
    }

    /**
     * Pre-pass for forward references: a function or class may be called before
     * the line that defines it, so every declared name is seeded into the
     * file-level scope up front.
     */
    private static void collectDeclaredNames(SourceModel model, Set<String> globalScope) {
        for (SourceModel.Line sourceLine : model.lines()) {
            if (sourceLine.isAbsorbed() || sourceLine.isBlank()) {
                continue;
            }
            String line = normalizeVariableNames(sourceLine.masked()).trim();
            if (line.isEmpty()) {
                continue;
            }

            Matcher classMatcher = CLASS_HEADER_PATTERN.matcher(line);
            if (classMatcher.matches()) {
                globalScope.add(normalizeVariableName(classMatcher.group(1)));
                continue;
            }

            Matcher functionMatcher = FUNCTION_HEADER_PATTERN.matcher(line);
            if (functionMatcher.matches()) {
                FunctionHeader header = parseFunctionHeader(functionMatcher.group(1));
                if (header != null) {
                    globalScope.add(header.name);
                }
            }
        }
    }

    /**
     * Parses the text after the `function` keyword. Handles all four header
     * shapes the parser accepts: {@code (S,P) = name(a,b)}, {@code B = name(a)},
     * {@code name(a)} and a bare {@code name}. Returns null when the header is
     * malformed, in which case the caller still pushes an empty body scope
     * rather than letting the generic `=` heuristic mangle the line.
     */
    private static FunctionHeader parseFunctionHeader(String remainder) {
        if (remainder == null) {
            return null;
        }

        String rest = remainder.trim();
        List<String> outputs = new ArrayList<>();

        if (rest.startsWith("(")) {
            // (B1, B2) = name(...) -- parenthesised output list.
            int close = rest.indexOf(')');
            if (close < 0) {
                return null;
            }
            addSplitNames(rest.substring(1, close), outputs);
            rest = rest.substring(close + 1).trim();
            if (!rest.startsWith("=")) {
                return null;
            }
            rest = rest.substring(1).trim();
        } else {
            int equalsIndex = indexOfAssignment(rest);
            if (equalsIndex >= 0) {
                // B = name(...) -- single output.
                addSplitNames(rest.substring(0, equalsIndex), outputs);
                rest = rest.substring(equalsIndex + 1).trim();
            }
        }

        Matcher nameMatcher = LEADING_IDENTIFIER_PATTERN.matcher(rest);
        if (!nameMatcher.find()) {
            return null;
        }
        String name = nameMatcher.group(1);

        List<String> parameters = new ArrayList<>();
        String afterName = rest.substring(nameMatcher.end()).trim();
        if (afterName.startsWith("(")) {
            int close = afterName.indexOf(')');
            if (close >= 0) {
                addSplitNames(afterName.substring(1, close), parameters);
            }
        }

        return new FunctionHeader(name, outputs, parameters);
    }

    private static void addSplitNames(String commaSeparated, List<String> target) {
        for (String part : commaSeparated.split(",")) {
            String name = normalizeVariableName(part.trim());
            if (name != null && !name.isEmpty() && isPotentialIdentifier(name)) {
                target.add(name);
            }
        }
    }

    /**
     * The variable a left-hand side actually defines: the leading identifier,
     * with any index or field suffix dropped. {@code A["name"]}, {@code A[3][4]}
     * and {@code obj.field} all resolve to {@code A}/{@code obj}. Returns null
     * when the text does not start with an identifier.
     */
    private static String rootIdentifier(String text) {
        if (text == null || text.isEmpty()) {
            return null;
        }
        Matcher matcher = LEADING_IDENTIFIER_PATTERN.matcher(text);
        return matcher.find() ? matcher.group(1) : null;
    }

    /** True when {@code name} is defined in any open scope. */
    private static boolean isKnown(String name, Deque<Set<String>> scopes) {
        for (Set<String> scope : scopes) {
            if (scope.contains(name)) {
                return true;
            }
        }
        return false;
    }

    private static int countUndefinedIdentifiers(String text, Deque<Set<String>> scopes) {
        if (text == null || text.isEmpty()) {
            return 0;
        }

        String sanitizedText = normalizeVariableNames(text);
        int errors = 0;
        Matcher matcher = IDENTIFIER_PATTERN.matcher(sanitizedText);
        Set<String> seen = new HashSet<>();
        while (matcher.find()) {
            String identifier = matcher.group();
            if (KEYWORDS.contains(identifier) || BUILTIN_CONSTANTS.contains(identifier)
                    || isKnown(identifier, scopes) || seen.contains(identifier)) {
                continue;
            }
            if (isFunctionLike(sanitizedText, matcher.end())) {
                continue;
            }
            // A field name is not a variable: in `base.mean` or `a.value` only
            // the root (`base`, `a`) has to be defined. Without this, every
            // field read reported its field name as undefined.
            if (isFieldAccess(sanitizedText, matcher.start())) {
                continue;
            }

            seen.add(identifier);
            errors++;
        }
        return errors;
    }

    /**
     * Splits one masked line into statements on {@code ;}. The masked text
     * carries no string literals, so no quote tracking is needed here any more.
     */
    private static List<String> splitStatements(String line) {
        if (line == null || line.isEmpty()) {
            return Collections.singletonList("");
        }
        return Arrays.asList(line.split(";", -1));
    }

    private static boolean isFunctionLike(String text, int end) {
        int nextIndex = end;
        while (nextIndex < text.length() && Character.isWhitespace(text.charAt(nextIndex))) {
            nextIndex++;
        }
        return nextIndex < text.length() && text.charAt(nextIndex) == '(';
    }

    /** True when the identifier starting at {@code start} is preceded by a `.`, i.e. it is a field name. */
    private static boolean isFieldAccess(String text, int start) {
        int previousIndex = start - 1;
        while (previousIndex >= 0 && Character.isWhitespace(text.charAt(previousIndex))) {
            previousIndex--;
        }
        return previousIndex >= 0 && text.charAt(previousIndex) == '.';
    }

    private static boolean isPotentialIdentifier(String text) {
        return text != null && IDENTIFIER_PATTERN.matcher(text).matches() && !KEYWORDS.contains(text);
    }

    private static String normalizeVariableNames(String text) {
        return LanguageDesignManager.normalizeMarkersForVariables(text);
    }

    private static String normalizeVariableName(String text) {
        if (text == null || text.isEmpty()) {
            return text;
        }
        return normalizeVariableNames(text).trim();
    }

    // Scans every `=` in the line and returns the first one that is a genuine
    // assignment. Checking only the first `=` (and only for a neighbouring `=`)
    // let `<=`, `>=` and `!=` pass as assignments, so `while i <= 3:` was
    // mis-read as assigning to "while i <" -- that garbage name went into the
    // scope and the header's own reference to `i` was never checked.
    private static int indexOfAssignment(String line) {
        int equalsIndex = line.indexOf('=');
        while (equalsIndex >= 0) {
            boolean nextIsEquals = equalsIndex + 1 < line.length() && line.charAt(equalsIndex + 1) == '=';
            char prevChar = equalsIndex > 0 ? line.charAt(equalsIndex - 1) : '\0';
            boolean isComparisonOperator = nextIsEquals
                    || prevChar == '='
                    || prevChar == '<'
                    || prevChar == '>'
                    || prevChar == '!';
            if (!isComparisonOperator) {
                return equalsIndex;
            }
            equalsIndex = line.indexOf('=', equalsIndex + 1);
        }
        return -1;
    }
}
