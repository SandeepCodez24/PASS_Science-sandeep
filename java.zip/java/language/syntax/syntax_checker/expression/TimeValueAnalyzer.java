package language.syntax.syntax_checker.expression;

import java.time.YearMonth;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import language.syntax.syntax_checker.core.Analyzer;
import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.core.Findings;
import language.syntax.syntax_checker.core.Rule;
import language.syntax.syntax_checker.core.SourceModel;
import language.syntax.syntax_checker.expression.ExpressionTokens.Token;
import language.syntax.syntax_checker.structure.BlockHeaderGrammar;

/**
 * The time mistakes that can be seen in the source ({@code nc.exe}'s
 * {@code timestamp} and {@code duration} values, 2026-10-28). Only literal
 * values are judged; everything else is a run-time question.
 *
 * <pre>
 *   timestamp(2026, 13, 1)        time error: invalid month 13 (expected 1–12)
 *   timestamp(2026, 2, 29)        time error: invalid day 29 for 2026-02 (expected 1–28)
 *   to_timestamp("2026-13-40")    time error: cannot parse "2026-13-40" as timestamp (...)
 *   timestamp(...) + 5            time error: cannot combine timestamp and number — use seconds(5), ...
 *   hours(1) - 3                  time error: cannot combine duration and number — ...
 *   tic(1)  toc(5)                time error: tic takes no arguments - ...
 *   get_timestamp(x)              time error: get_timestamp takes no arguments - ...
 *   today(1, 2)                   time error: usage: today() or today(zone) - ...
 * </pre>
 *
 * A name the script defines itself (a function, or a variable such as
 * {@code days = 5}) is never read as the time function. The messages are
 * {@code nc.exe}'s ({@code ops/time}), without its {@code Error: } prefix.
 */
public final class TimeValueAnalyzer implements Analyzer {

    static final String PREFIX = "time error: ";
    static final String INVALID_PART = PREFIX + "invalid %s %s (expected %s)";
    static final String INVALID_DAY = PREFIX + "invalid day %s for %04d-%02d (expected 1–%d)";
    static final String CANNOT_PARSE = PREFIX + "cannot parse \"%s\" as timestamp "
            + "(expected ISO 8601, e.g. \"2026-10-28 14:30:00\")";
    static final String COMBINE = PREFIX + "cannot combine %s and %s — use seconds(%3$s), minutes(%3$s), "
            + "hours(%3$s) or days(%3$s)";
    static final String TIC = PREFIX + "tic takes no arguments - usage: tic() ... toc()";
    static final String TOC = PREFIX + "toc takes no arguments - there is one stopwatch: tic() starts it, "
            + "toc() reads it";
    static final String GET_TIMESTAMP = PREFIX + "get_timestamp takes no arguments - usage: get_timestamp()";
    static final String TODAY = PREFIX + "usage: today() or today(zone) - e.g. today(\"UTC\")";

    /** Calls whose value is a timestamp. */
    private static final Set<String> TIMESTAMPS = Set.of(
            "timestamp", "to_timestamp", "today", "get_timestamp", "set_time", "set_date");
    /** Calls whose value is a duration. */
    private static final Set<String> DURATIONS = Set.of("seconds", "minutes", "hours", "days");
    /** Operators that bind tighter than {@code +} / {@code -} and may change the kind of a value. */
    private static final Set<String> TIGHTER = Set.of("*", "/", "%", "//", "^", "*.", "/.", "^.", ".");

    private static final Pattern INTEGER = Pattern.compile("\\d+");

    /** {@code name =} at the start of a statement: the script's own variable. */
    private static final Pattern ASSIGNED = Pattern.compile(
            "(?:^|[;:])\\s*(" + BlockHeaderGrammar.IDENT + ")\\s*=(?!=)");

    @Override
    public void analyze(SourceModel model, CheckContext context, Findings out) {
        Set<String> own = ownNames(model);
        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed() || line.isBlank() || line.hasUnterminatedString()) {
                continue;
            }
            String code = line.code();
            if (code.length() != line.masked().length()) {
                continue;
            }
            String message = checkLine(ExpressionTokens.of(line.masked(), code), own);
            if (message != null) {
                out.add(line.index(), Rule.TIME_VALUE, message);
            }
        }
    }

    private static String checkLine(List<Token> tokens, Set<String> own) {
        for (int k = 0; k < tokens.size(); k++) {
            String name = calledTimeFunction(tokens, k, own);
            if (name != null) {
                String message = checkCall(name, ExpressionTokens.arguments(tokens, k + 1));
                if (message != null) {
                    return message;
                }
                continue;
            }
            Token token = tokens.get(k);
            if ((token.is("+") || token.is("-")) && k > 0 && ExpressionTokens.endsValue(tokens.get(k - 1))) {
                String message = checkCombine(tokens, k, own);
                if (message != null) {
                    return message;
                }
            }
        }
        return null;
    }

    /** The time function called at token {@code k} ({@code name(}), or null. */
    private static String calledTimeFunction(List<Token> tokens, int k, Set<String> own) {
        Token token = tokens.get(k);
        if (token.kind() != ExpressionTokens.Kind.NAME || k + 1 >= tokens.size() || !tokens.get(k + 1).is("(")
                || (k > 0 && tokens.get(k - 1).is(".")) || own.contains(token.text())) {
            return null;
        }
        String name = token.text();
        return TIMESTAMPS.contains(name) || DURATIONS.contains(name) || name.equals("tic") || name.equals("toc")
                ? name
                : null;
    }

    // =====================================================================
    // Calls
    // =====================================================================

    private static String checkCall(String name, List<List<Token>> args) {
        if (args == null) {
            return null;
        }
        return switch (name) {
            case "tic" -> args.isEmpty() ? null : TIC;
            case "toc" -> args.isEmpty() ? null : TOC;
            case "get_timestamp" -> args.isEmpty() ? null : GET_TIMESTAMP;
            case "today" -> args.size() > 1 ? TODAY : null;
            case "timestamp" -> checkTimestamp(args);
            case "to_timestamp" -> args.isEmpty() || args.get(0).size() != 1
                    || args.get(0).get(0).kind() != ExpressionTokens.Kind.STRING
                    ? null
                    : checkIsoText(args.get(0).get(0).body());
            default -> null;
        };
    }

    /** {@code timestamp(year, month, day[, hour, minute, second][, zone])}, literal parts only. */
    private static String checkTimestamp(List<List<Token>> args) {
        if (args.size() < 3 || args.size() > 7) {
            return null;
        }
        Long year = integer(args.get(0));
        if (year == null || year < 1000 || year > 9999) {
            return null; // nc.exe reports the year itself; not judged here
        }
        Long month = integer(args.get(1));
        if (month == null) {
            return null;
        }
        if (month < 1 || month > 12) {
            return String.format(INVALID_PART, "month", month, "1–12");
        }
        Long day = integer(args.get(2));
        if (day == null) {
            return null;
        }
        int lastDay = YearMonth.of(year.intValue(), month.intValue()).lengthOfMonth();
        if (day < 1 || day > lastDay) {
            return String.format(INVALID_DAY, day, year, month, lastDay);
        }
        if (args.size() < 6) {
            return null;
        }
        String[][] parts = { { "hour", "0–23" }, { "minute", "0–59" } };
        long[] limits = { 23, 59 };
        for (int i = 0; i < parts.length; i++) {
            Long value = integer(args.get(3 + i));
            if (value == null) {
                return null;
            }
            if (value < 0 || value > limits[i]) {
                return String.format(INVALID_PART, parts[i][0], value, parts[i][1]);
            }
        }
        Long second = integer(args.get(5));
        if (second != null && (second < 0 || second >= 60)) {
            return String.format(INVALID_PART, "second", second, "0 ≤ s < 60");
        }
        return null;
    }

    /** A whole number written out ({@code 13}, {@code -1}), or null. */
    private static Long integer(List<Token> arg) {
        boolean negative = arg.size() == 2 && arg.get(0).is("-");
        if (arg.size() != (negative ? 2 : 1)) {
            return null;
        }
        Token number = arg.get(arg.size() - 1);
        if (number.kind() != ExpressionTokens.Kind.NUMBER || !INTEGER.matcher(number.text()).matches()
                || number.text().length() > 9) {
            return null;
        }
        long value = Long.parseLong(number.text());
        return negative ? -value : value;
    }

    /**
     * {@code parseTimestamp} of {@code ops/time/time.cpp}: {@code YYYY-MM-DD},
     * then optionally {@code T} / space and {@code hh:mm[:ss[.fff]]}, then
     * optionally {@code Z} or {@code ±hh[:mm]}, every field a real date and
     * time.
     */
    private static final Pattern ISO = Pattern.compile(
            "(\\d{4})-(\\d{2})-(\\d{2})"
                    + "(?:[Tt ](\\d{2}):(\\d{2})(?::(\\d{2})(?:[.,]\\d+)?)?)?"
                    + "(?:[Zz]|[+-](\\d{2}):?(\\d{2})?)?");

    private static String checkIsoText(String text) {
        Matcher m = ISO.matcher(text.strip());
        if (!m.matches()) {
            return String.format(CANNOT_PARSE, text);
        }
        int year = Integer.parseInt(m.group(1));
        int month = Integer.parseInt(m.group(2));
        int day = Integer.parseInt(m.group(3));
        boolean valid = month >= 1 && month <= 12 && day >= 1
                && day <= YearMonth.of(Math.max(year, 1), month).lengthOfMonth()
                && partAtMost(m.group(4), 23) && partAtMost(m.group(5), 59) && partAtMost(m.group(6), 59)
                && partAtMost(m.group(7), 23) && partAtMost(m.group(8), 59);
        return valid ? null : String.format(CANNOT_PARSE, text);
    }

    private static boolean partAtMost(String digits, int max) {
        return digits == null || Integer.parseInt(digits) <= max;
    }

    // =====================================================================
    // timestamp / duration + number
    // =====================================================================

    /** The {@code +} / {@code -} at {@code k} with a time value on one side and a number on the other. */
    private static String checkCombine(List<Token> tokens, int k, Set<String> own) {
        String left = timeBefore(tokens, k - 1, own);
        String right = timeAfter(tokens, k + 1, own);
        if (left != null && right == null) {
            String number = numberAfter(tokens, k + 1);
            return number == null ? null : String.format(COMBINE, left, "number", number);
        }
        if (right != null && left == null) {
            String number = numberBefore(tokens, k - 1);
            return number == null ? null : String.format(COMBINE, "number", right, number);
        }
        return null;
    }

    /** {@code "timestamp"} / {@code "duration"} for a time call ending at {@code close}, or null. */
    private static String timeBefore(List<Token> tokens, int close, Set<String> own) {
        if (!tokens.get(close).is(")")) {
            return null;
        }
        int open = ExpressionTokens.matchingOpen(tokens, close);
        if (open < 1) {
            return null;
        }
        String name = calledTimeFunction(tokens, open - 1, own);
        if (name == null || (open >= 2 && TIGHTER.contains(tokens.get(open - 2).text()))) {
            return null; // `x / hours(1) - 3` is a number
        }
        return kindOf(name);
    }

    private static String timeAfter(List<Token> tokens, int start, Set<String> own) {
        if (start >= tokens.size()) {
            return null;
        }
        String name = calledTimeFunction(tokens, start, own);
        if (name == null) {
            return null;
        }
        int close = ExpressionTokens.matchingClose(tokens, start + 1);
        if (close < 0 || (close + 1 < tokens.size() && TIGHTER.contains(tokens.get(close + 1).text()))) {
            return null; // `3 + hours(1) / minutes(1)` is a number
        }
        return kindOf(name);
    }

    private static String kindOf(String name) {
        return TIMESTAMPS.contains(name) ? "timestamp" : DURATIONS.contains(name) ? "duration" : null;
    }

    /** A number written out right after the operator and not part of a tighter operation. */
    private static String numberAfter(List<Token> tokens, int start) {
        if (start >= tokens.size() || tokens.get(start).kind() != ExpressionTokens.Kind.NUMBER) {
            return null;
        }
        if (start + 1 < tokens.size()) {
            Token next = tokens.get(start + 1);
            if (TIGHTER.contains(next.text()) || next.is("(") || next.is("[") || next.is("!")) {
                return null;
            }
        }
        return tokens.get(start).text();
    }

    private static String numberBefore(List<Token> tokens, int end) {
        if (end < 0 || tokens.get(end).kind() != ExpressionTokens.Kind.NUMBER) {
            return null;
        }
        if (end > 0 && TIGHTER.contains(tokens.get(end - 1).text())) {
            return null;
        }
        return tokens.get(end).text();
    }

    // =====================================================================
    // Names the script defines itself
    // =====================================================================

    private static Set<String> ownNames(SourceModel model) {
        Set<String> own = new HashSet<>();
        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed() || line.isBlank()) {
                continue;
            }
            String masked = line.masked().trim();
            BlockHeaderGrammar.Header header = BlockHeaderGrammar.parse(masked);
            if (header != null && header.kind() == BlockHeaderGrammar.Kind.FUNCTION && header.name() != null) {
                own.add(header.name());
            }
            Matcher m = ASSIGNED.matcher(masked);
            while (m.find()) {
                own.add(m.group(1));
            }
        }
        return own;
    }
}
