package language.syntax.syntax_checker.expression;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import language.syntax.syntax_checker.core.Analyzer;
import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.core.Findings;
import language.syntax.syntax_checker.core.Lexis;
import language.syntax.syntax_checker.core.Rule;
import language.syntax.syntax_checker.core.SourceModel;
import language.syntax.syntax_checker.core.TargetList;
import language.syntax.syntax_checker.expression.ExpressionTokens.Token;
import language.syntax.syntax_checker.structure.BlockHeaderGrammar;
import ui.ui_functions.suggestion_functions.LiteralTypeInference;
import ui.ui_functions.suggestion_functions.SuggestionKind;

/**
 * Text never acts as a number ({@code nc.exe} since 2026-10-28): arithmetic
 * between text and a number is an error, and only {@code +} between two texts
 * has a meaning (it joins them).
 *
 * <pre>
 *   "a" + "b"         ok       joins text
 *   "5" == 5          ok       simply false
 *   1 + true          ok       a bool counts as 1 / 0
 *   "5" + 1           Syntax Error    '+' cannot combine text with a number ...
 *   1 + "5"           Syntax Error    '+' cannot combine a number with text ...
 *   "5" * 2           Syntax Error    '*' is not defined for text ...
 *   "a" - "b"         Syntax Error    only '+' joins text
 *   -"5"   "5"!       Syntax Error    negation / factorial of text
 *   "5" &lt; 5           Syntax Error    cannot order-compare string with number
 *   dec2frac(0.5) + 1 Syntax Error    dec2frac gives text - frac2deci(...) or float(...)
 * </pre>
 *
 * <h3>Only what the source shows</h3>
 * An operand is known only when it is written as a literal ({@code "5"},
 * {@code 2.5}, {@code true}, a matrix literal {@code [1, 2]}), is a call to
 * {@code dec2frac}, or is a plain name that is only ever given one kind of
 * literal in the file ({@link LiteralTypeInference}). A name defined any
 * other way - a loop variable, an input, a list of variables, {@code ,=} -
 * is unknown, and an unknown operand is never reported. The operand next to
 * the operator is what is read; operators that bind tighter keep its kind
 * ({@code "5" + 1 * 2}), so this is enough for the cases worth reporting.
 *
 * <p>
 * The messages are the ones {@code nc.exe} prints, so one mistake reads the
 * same in the editor and in the Command Window.
 */
public final class TextOperandAnalyzer implements Analyzer {

    // ---- messages (as nc.exe, parser_expression.cpp) -------------------

    static final String ONLY_PLUS_JOINS = "'%s' is not defined for text - only '+' joins text (%s + %s)";
    static final String TEXT_PLUS = "'+' cannot combine text with %s - the left value is text, so '+' joins text: "
            + "write %s + str(%s)";
    static final String TEXT_PLUS_NUMERIC = ", or float(%s) + %s to add the numbers";
    static final String VALUE_PLUS = "'+' cannot combine %s with text - the left value is %s, so '+' adds numbers: "
            + "convert the text first, e.g. %s + float(%s)";
    static final String VALUE_PLUS_JOIN = ", or join as text with str(%s) + %s";
    static final String CONVERT_FIRST = "'%s' is not defined for text - convert it first, e.g. %s";
    static final String NOT_A_NUMBER = "'%s' is not defined for text - %s is not a number";
    static final String NEGATION = "'-' (negation) is not defined for text - convert it first, e.g. -float(%s)";
    static final String FACTORIAL = "'!' (factorial) requires a number, not text - convert it first, e.g. float(%s)!";
    static final String ORDER = "cannot order-compare %s with %s";
    /** Hint for {@code dec2frac(...)}, whose result is fraction text such as {@code "1/2"}. */
    static final String DEC2FRAC = "'%s' cannot combine text with a number - %s gives text such as \"1/2\": "
            + "convert it first with frac2deci(%2$s) or float(%2$s)";

    /** Arithmetic operators that refuse text (all but '+' refuse it on both sides). */
    private static final Set<String> ARITHMETIC = Set.of(
            "+", "-", "*", "/", "%", "//", "^", "*.", "/.", "^.");
    private static final Set<String> ORDERING = Set.of("<", ">", "<=", ">=");

    /** Text {@code nc.exe} could read as a number: a decimal or a fraction. */
    private static final Pattern NUMERIC_TEXT = Pattern.compile(
            "\\s*[+-]?(?:\\d+(?:\\.\\d*)?|\\.\\d+)(?:[eE][+-]?\\d+)?\\s*"
                    + "|\\s*[+-]?\\d+\\s*/\\s*[+-]?\\d+\\s*");

    private static final Pattern NAME = Pattern.compile(BlockHeaderGrammar.IDENT);

    // ---- operands ------------------------------------------------------

    private enum Kind { TEXT, NUMBER, BOOL, MATRIX, DEC2FRAC }

    /**
     * A known operand.
     *
     * @param kind   what it is
     * @param source how {@code nc.exe} would quote it in a message
     * @param text   the text itself, for {@link Kind#TEXT}
     */
    private record Operand(Kind kind, String source, String text) {
    }

    @Override
    public void analyze(SourceModel model, CheckContext context, Findings out) {
        Map<String, Operand> literals = literalVariables(model);
        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed() || line.isBlank() || line.hasUnterminatedString()) {
                continue;
            }
            String code = line.code();
            if (code.length() != line.masked().length()) {
                continue; // offsets would not match; never guess
            }
            String message = checkLine(ExpressionTokens.of(line.masked(), code), literals);
            if (message != null) {
                out.add(line.index(), Rule.TEXT_OPERAND, message);
            }
        }
    }

    // =====================================================================
    // One line
    // =====================================================================

    private static String checkLine(List<Token> tokens, Map<String, Operand> literals) {
        for (int k = 0; k < tokens.size(); k++) {
            Token token = tokens.get(k);
            if (token.kind() != ExpressionTokens.Kind.SYMBOL) {
                continue;
            }
            String op = token.text();
            boolean valueBefore = k > 0 && ExpressionTokens.endsValue(tokens.get(k - 1));

            if (op.equals("-") && !valueBefore) {
                Operand inner = operandAfter(tokens, k + 1, literals);
                if (inner != null && inner.kind() == Kind.TEXT) {
                    return String.format(NEGATION, inner.source());
                }
                continue;
            }
            if (op.equals("!") && valueBefore) {
                Operand inner = operandBefore(tokens, k - 1, literals);
                if (inner != null && inner.kind() == Kind.TEXT) {
                    return String.format(FACTORIAL, inner.source());
                }
                continue;
            }
            if (!valueBefore || (!ARITHMETIC.contains(op) && !ORDERING.contains(op))) {
                continue;
            }
            Operand left = operandBefore(tokens, k - 1, literals);
            Operand right = operandAfter(tokens, k + 1, literals);
            if (left == null || right == null) {
                continue;
            }
            // `"a" + 1 * 2`: the value on each side is the whole part that
            // binds tighter than this operator, so the message quotes it all.
            left = widened(left, tokens, widenBefore(tokens, k - 1, precedence(op)), k - 1);
            right = widened(right, tokens, k + 1, widenAfter(tokens, k + 1, precedence(op)));
            if (right.kind() == Kind.MATRIX) {
                right = new Operand(Kind.MATRIX, "B", null);
            }
            String message = ORDERING.contains(op) ? orderMessage(left, right) : arithmeticMessage(op, left, right);
            if (message != null) {
                return message;
            }
        }
        return null;
    }

    /** 0 comparisons, 1 {@code + -}, 2 {@code * / % //}, 3 {@code ^}; -1 for anything else. */
    private static int precedence(String op) {
        if (ORDERING.contains(op)) {
            return 0;
        }
        return switch (op) {
            case "+", "-" -> 1;
            case "*", "/", "%", "//", "*.", "/." -> 2;
            case "^", "^." -> 3;
            default -> -1;
        };
    }

    /** Index of the last token of the primary value starting at {@code start}. */
    private static int primaryEnd(List<Token> tokens, int start) {
        Token t = tokens.get(start);
        if ((t.is("-") || t.is("+")) && start + 1 < tokens.size()) {
            return primaryEnd(tokens, start + 1);
        }
        int end = start;
        if (t.is("(") || t.is("[") || t.is("{")) {
            end = ExpressionTokens.matchingClose(tokens, start);
        } else if (t.kind() == ExpressionTokens.Kind.NAME && start + 1 < tokens.size() && tokens.get(start + 1).is("(")) {
            end = ExpressionTokens.matchingClose(tokens, start + 1);
        }
        return end < 0 ? tokens.size() - 1 : end;
    }

    /** Index of the first token of the primary value ending at {@code end}. */
    private static int primaryStart(List<Token> tokens, int end) {
        Token t = tokens.get(end);
        if (t.is(")") || t.is("]") || t.is("}")) {
            int open = ExpressionTokens.matchingOpen(tokens, end);
            if (open < 0) {
                return end;
            }
            return open > 0 && tokens.get(open).is("(") && tokens.get(open - 1).kind() == ExpressionTokens.Kind.NAME
                    ? open - 1
                    : open;
        }
        return end;
    }

    /** The last token of the part after an operator of {@code level} that binds tighter than it. */
    private static int widenAfter(List<Token> tokens, int start, int level) {
        int end = primaryEnd(tokens, start);
        while (end + 2 < tokens.size() && precedence(tokens.get(end + 1).text()) > level
                && tokens.get(end + 1).kind() == ExpressionTokens.Kind.SYMBOL) {
            end = primaryEnd(tokens, end + 2);
        }
        return end;
    }

    /** The first token of the part before an operator of {@code level} that binds tighter than it. */
    private static int widenBefore(List<Token> tokens, int end, int level) {
        int start = primaryStart(tokens, end);
        while (start - 2 >= 0 && precedence(tokens.get(start - 1).text()) > level
                && tokens.get(start - 1).kind() == ExpressionTokens.Kind.SYMBOL) {
            start = primaryStart(tokens, start - 2);
        }
        return start;
    }

    /**
     * The operand quoted as the tokens {@code from..to} when they are more than
     * its own primary; its kind is the primary's, which the tighter operators
     * keep (a tighter operator on text is reported at that operator).
     */
    private static Operand widened(Operand operand, List<Token> tokens, int from, int to) {
        if (operand.kind() != Kind.NUMBER && operand.kind() != Kind.BOOL) {
            return operand;
        }
        if (from >= to || primaryStart(tokens, to) == from || primaryEnd(tokens, from) == to) {
            return operand;
        }
        StringBuilder text = new StringBuilder();
        for (int i = from; i <= to; i++) {
            Token t = tokens.get(i);
            boolean binary = t.kind() == ExpressionTokens.Kind.SYMBOL && precedence(t.text()) > 0 && i > from
                    && ExpressionTokens.endsValue(tokens.get(i - 1));
            if (binary) {
                text.append(' ').append(t.text()).append(' ');
            } else {
                text.append(t.text());
                if (t.is(",")) {
                    text.append(' ');
                }
            }
        }
        return new Operand(operand.kind(), text.toString(), operand.text());
    }

    private static String orderMessage(Operand left, Operand right) {
        boolean leftText = left.kind() == Kind.TEXT;
        boolean rightText = right.kind() == Kind.TEXT;
        boolean leftScalar = left.kind() == Kind.NUMBER || left.kind() == Kind.BOOL;
        boolean rightScalar = right.kind() == Kind.NUMBER || right.kind() == Kind.BOOL;
        if ((leftText && rightScalar) || (leftScalar && rightText)) {
            return String.format(ORDER, leftText ? "string" : "number", rightText ? "string" : "number");
        }
        return null;
    }

    /** {@code textOperandError} of {@code parser_expression.cpp}. */
    private static String arithmeticMessage(String op, Operand left, Operand right) {
        if (left.kind() == Kind.DEC2FRAC || right.kind() == Kind.DEC2FRAC) {
            Operand call = left.kind() == Kind.DEC2FRAC ? left : right;
            Operand other = call == left ? right : left;
            return other.kind() == Kind.NUMBER || other.kind() == Kind.BOOL || other.kind() == Kind.MATRIX
                    ? String.format(DEC2FRAC, op, call.source())
                    : null;
        }
        boolean leftText = left.kind() == Kind.TEXT;
        boolean rightText = right.kind() == Kind.TEXT;
        if (!leftText && !rightText) {
            return null;
        }
        String a = left.source();
        String b = right.source();
        if (leftText && rightText) {
            return op.equals("+") ? null : String.format(ONLY_PLUS_JOINS, op, a, b);
        }
        if (op.equals("+") && leftText) {
            String message = String.format(TEXT_PLUS, kindText(right), a, b);
            return isNumericText(left) ? message + String.format(TEXT_PLUS_NUMERIC, a, b) : message;
        }
        if (op.equals("+")) {
            String message = String.format(VALUE_PLUS, kindText(left),
                    left.kind() == Kind.BOOL ? "a bool" : "numeric", a, b);
            return left.kind() == Kind.MATRIX ? message : message + String.format(VALUE_PLUS_JOIN, a, b);
        }
        Operand text = leftText ? left : right;
        String converted = leftText ? "float(" + a + ") " + op + " " + b : a + " " + op + " float(" + b + ")";
        return isNumericText(text)
                ? String.format(CONVERT_FIRST, op, converted)
                : String.format(NOT_A_NUMBER, op, text.source());
    }

    private static String kindText(Operand operand) {
        return switch (operand.kind()) {
            case TEXT -> "text";
            case MATRIX -> "a matrix";
            case BOOL -> "a bool";
            default -> "a number";
        };
    }

    private static boolean isNumericText(Operand operand) {
        return operand.text() != null && NUMERIC_TEXT.matcher(operand.text()).matches();
    }

    // =====================================================================
    // Operands
    // =====================================================================

    /** The operand that ends at token {@code k}, or null when it is not known. */
    private static Operand operandBefore(List<Token> tokens, int k, Map<String, Operand> literals) {
        if (k < 0) {
            return null;
        }
        Token token = tokens.get(k);
        if (token.kind() == ExpressionTokens.Kind.SYMBOL && (token.text().equals(")") || token.text().equals("]"))) {
            int open = ExpressionTokens.matchingOpen(tokens, k);
            if (open < 0) {
                return null;
            }
            boolean called = open > 0 && tokens.get(open - 1).kind() == ExpressionTokens.Kind.NAME;
            if (token.text().equals(")")) {
                return called && tokens.get(open - 1).text().equals("dec2frac") && !isMember(tokens, open - 1)
                        ? dec2frac(tokens, open - 1, k)
                        : null;
            }
            return open > 0 && ExpressionTokens.endsValue(tokens.get(open - 1)) ? null : matrix(tokens, open, k);
        }
        if (isMember(tokens, k)) {
            return null;
        }
        return single(token, literals);
    }

    /** The operand that starts at token {@code k}, or null when it is not known. */
    private static Operand operandAfter(List<Token> tokens, int k, Map<String, Operand> literals) {
        if (k >= tokens.size()) {
            return null;
        }
        Token token = tokens.get(k);
        if (token.kind() == ExpressionTokens.Kind.SYMBOL && (token.text().equals("-") || token.text().equals("+"))) {
            Operand signed = operandAfter(tokens, k + 1, literals);
            return signed != null && signed.kind() == Kind.NUMBER
                    ? new Operand(Kind.NUMBER, token.text().equals("-") ? "-" + signed.source() : signed.source(), null)
                    : null;
        }
        if (token.kind() == ExpressionTokens.Kind.SYMBOL && token.text().equals("[")) {
            int close = ExpressionTokens.matchingClose(tokens, k);
            return close < 0 || followedByIndexOrField(tokens, close) ? null : matrix(tokens, k, close);
        }
        if (token.kind() == ExpressionTokens.Kind.NAME && token.text().equals("dec2frac")
                && k + 1 < tokens.size() && tokens.get(k + 1).text().equals("(")) {
            int close = ExpressionTokens.matchingClose(tokens, k + 1);
            return close < 0 || followedByIndexOrField(tokens, close) ? null : dec2frac(tokens, k, close);
        }
        if (followedByIndexOrField(tokens, k)) {
            return null; // "abc"[0], x.f, f(x): not the plain value
        }
        return single(token, literals);
    }

    private static Operand single(Token token, Map<String, Operand> literals) {
        switch (token.kind()) {
            case STRING -> {
                String body = token.text().substring(1, token.text().length() - 1);
                return new Operand(Kind.TEXT, "\"" + body + "\"", body);
            }
            case NUMBER -> {
                return token.text().endsWith("i") ? null : new Operand(Kind.NUMBER, token.text(), null);
            }
            case NAME -> {
                if (token.text().equals("true") || token.text().equals("false")) {
                    return new Operand(Kind.BOOL, token.text(), null);
                }
                return literals.get(token.text());
            }
            default -> {
                return null;
            }
        }
    }

    /** A matrix literal between {@code open} and {@code close}: numbers only, no text. */
    private static Operand matrix(List<Token> tokens, int open, int close) {
        if (close - open < 2) {
            return null;
        }
        for (int i = open + 1; i < close; i++) {
            Token inner = tokens.get(i);
            if (inner.kind() == ExpressionTokens.Kind.STRING || inner.kind() == ExpressionTokens.Kind.NAME) {
                return null;
            }
        }
        return new Operand(Kind.MATRIX, "A", null);
    }

    private static Operand dec2frac(List<Token> tokens, int name, int close) {
        StringBuilder source = new StringBuilder("dec2frac(");
        for (int i = name + 2; i < close; i++) {
            Token inner = tokens.get(i);
            if (i > name + 2 && inner.kind() != ExpressionTokens.Kind.SYMBOL && tokens.get(i - 1).kind() != ExpressionTokens.Kind.SYMBOL) {
                source.append(' ');
            }
            source.append(inner.text());
            if (inner.text().equals(",")) {
                source.append(' ');
            }
        }
        return new Operand(Kind.DEC2FRAC, source.append(')').toString(), null);
    }

    /** True when token {@code k} is the field of {@code x.k}. */
    private static boolean isMember(List<Token> tokens, int k) {
        return k > 0 && tokens.get(k - 1).text().equals(".");
    }

    private static boolean followedByIndexOrField(List<Token> tokens, int k) {
        if (k + 1 >= tokens.size()) {
            return false;
        }
        String next = tokens.get(k + 1).text();
        return next.equals("[") || next.equals(".") || next.equals("(");
    }

    // =====================================================================
    // Names given only literals
    // =====================================================================

    /**
     * Every plain name the file gives a value only with {@code name = literal}
     * (one kind of literal, every time). A name also defined any other way -
     * by an expression, a header, a list of variables, {@code ,=} - is left
     * out, so it is never reported.
     */
    private static Map<String, Operand> literalVariables(SourceModel model) {
        Map<String, Operand> known = new HashMap<>();
        Set<String> unknown = new java.util.HashSet<>();
        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed() || line.isBlank() || line.hasUnterminatedString()) {
                continue;
            }
            String masked = line.masked();
            String code = line.code();
            if (code.length() != masked.length()) {
                continue;
            }
            boolean header = BlockHeaderGrammar.parse(masked.trim()) != null;
            if (header || !line.extendOperators().isEmpty()) {
                // Inputs, outputs, loop variables, extended names: never a fixed literal.
                for (Token t : ExpressionTokens.of(masked, code)) {
                    if (t.kind() == ExpressionTokens.Kind.NAME) {
                        unknown.add(t.text());
                    }
                }
                if (header) {
                    continue;
                }
            }
            int start = 0;
            for (String statement : Lexis.splitStatements(masked)) {
                int end = start + statement.length();
                recordStatement(masked.substring(start, end), code.substring(start, end), known, unknown);
                start = end + 1;
            }
        }
        unknown.forEach(known::remove);
        return known;
    }

    private static void recordStatement(String masked, String code, Map<String, Operand> known, Set<String> unknown) {
        int equals = Lexis.assignmentIndex(masked);
        if (equals < 0) {
            return;
        }
        String target = masked.substring(0, equals).trim();
        if (TargetList.startsStatement(masked.trim()) || !NAME.matcher(target).matches()) {
            for (Token t : ExpressionTokens.of(masked.substring(0, equals), code.substring(0, equals))) {
                if (t.kind() == ExpressionTokens.Kind.NAME) {
                    unknown.add(t.text());
                }
            }
            return;
        }
        String value = code.substring(equals + 1).trim();
        Operand literal = literalOperand(value);
        Operand before = known.get(target);
        if (literal == null || (before != null && !before.source().equals(literal.source()))) {
            // Not a literal, or two different values: a message could not quote it.
            unknown.add(target);
        } else {
            known.put(target, literal);
        }
    }

    /** {@code "5"}, {@code 2.5}, {@code true}: one literal on its own, through {@link LiteralTypeInference}. */
    private static Operand literalOperand(String value) {
        String masked = maskOneLiteral(value);
        if (masked == null) {
            return null;
        }
        List<Token> parts = ExpressionTokens.of(masked, value);
        if (parts.size() != 1 && !(parts.size() == 2 && parts.get(0).text().equals("-"))) {
            return null;
        }
        SuggestionKind kind = LiteralTypeInference.infer(value);
        return switch (kind) {
            case VARIABLE_STRING -> {
                String body = value.substring(1, value.length() - 1);
                yield new Operand(Kind.TEXT, "\"" + body + "\"", body);
            }
            case VARIABLE_INT, VARIABLE_FLOAT -> new Operand(Kind.NUMBER, value, null);
            case VARIABLE_BOOLEAN -> new Operand(Kind.BOOL, value, null);
            default -> null;
        };
    }

    /** Blanks the body of a value that is one quoted literal; other values come back unchanged. */
    private static String maskOneLiteral(String value) {
        if (value.length() >= 2 && (value.charAt(0) == '"' || value.charAt(0) == '\'')) {
            char quote = value.charAt(0);
            int close = value.indexOf(quote, 1);
            if (close != value.length() - 1) {
                return null;
            }
            return quote + " ".repeat(value.length() - 2) + quote;
        }
        return value;
    }
}
