package language.syntax.syntax_checker.expression;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import language.syntax.syntax_checker.core.Lexis;

/**
 * A line split into strings, numbers, names and symbols, for the checks that
 * read the values on each side of an operator ({@link TextOperandAnalyzer},
 * {@link TimeValueAnalyzer}).
 *
 * <p>
 * Read from the masked line (string bodies blanked, quotes kept), so nothing
 * inside a string is code; a string token carries its text from the
 * unmasked line at the same offsets.
 */
final class ExpressionTokens {

    private ExpressionTokens() {
    }

    enum Kind { STRING, NUMBER, NAME, SYMBOL }

    /** One token; {@code text} of a string includes its quotes. */
    record Token(Kind kind, String text, int start, int end) {

        boolean is(String symbol) {
            return kind == Kind.SYMBOL && text.equals(symbol);
        }

        /** @return the text between the quotes of a string token */
        String body() {
            return text.substring(1, text.length() - 1);
        }
    }

    /** Longest first. */
    private static final String[] SYMBOLS = {
            "==", "!=", "<=", ">=", "&&", "||", "!&", "!|", "//", "*.", "/.", "^.",
            "+", "-", "*", "/", "%", "^", "!", "<", ">", "=", ",", ";", ":", "(", ")", "[", "]", "{", "}",
            ".", "@", "~", "&", "|", "?", "'"
    };

    private static final Pattern NUMBER = Pattern.compile(
            "(?:\\d+(?:\\.\\d*)?|\\.\\d+)(?:[eE][+-]?\\d+)?i?");

    /**
     * @param masked the masked line: string bodies blanked, quotes kept
     * @param code   the same line with its literals intact, offset for offset
     */
    static List<Token> of(String masked, String code) {
        List<Token> tokens = new ArrayList<>();
        Matcher number = NUMBER.matcher(masked);
        int i = 0;
        int n = masked.length();
        while (i < n) {
            char c = masked.charAt(i);
            if (Character.isWhitespace(c)) {
                i++;
                continue;
            }
            if (c == '"' || c == '\'') {
                int close = masked.indexOf(c, i + 1);
                if (close > i) {
                    tokens.add(new Token(Kind.STRING, code.substring(i, close + 1), i, close + 1));
                    i = close + 1;
                    continue;
                }
            }
            if (Lexis.isIdentStart(c)) {
                int end = Lexis.scanIdent(masked, i);
                tokens.add(new Token(Kind.NAME, masked.substring(i, end), i, end));
                i = end;
                continue;
            }
            if (Character.isDigit(c) || (c == '.' && i + 1 < n && Character.isDigit(masked.charAt(i + 1)))) {
                if (number.find(i) && number.start() == i) {
                    int end = number.end();
                    // `5Hz`, `2x`: a number with a unit or a name is not a plain number here.
                    if (end < n && Lexis.isIdentPart(masked.charAt(end))) {
                        end = Lexis.scanIdent(masked, end);
                        tokens.add(new Token(Kind.NAME, masked.substring(i, end), i, end));
                    } else {
                        tokens.add(new Token(Kind.NUMBER, masked.substring(i, end), i, end));
                    }
                    i = end;
                    continue;
                }
            }
            String symbol = String.valueOf(c);
            for (String s : SYMBOLS) {
                if (masked.startsWith(s, i)) {
                    // `2*.5` is 2 * 0.5, not the element-wise `*.`.
                    boolean elementwise = s.length() == 2 && s.charAt(1) == '.';
                    if (elementwise && i + 2 < n && Character.isDigit(masked.charAt(i + 2))) {
                        continue;
                    }
                    symbol = s;
                    break;
                }
            }
            tokens.add(new Token(Kind.SYMBOL, symbol, i, i + symbol.length()));
            i += symbol.length();
        }
        return tokens;
    }

    /** True when the token can end a value, so an operator after it is binary. */
    static boolean endsValue(Token token) {
        return switch (token.kind()) {
            case STRING, NUMBER -> true;
            case NAME -> !Lexis.KEYWORDS.contains(token.text());
            case SYMBOL -> token.is(")") || token.is("]") || token.is("}") || token.is("!") || token.is("'");
        };
    }

    /** @return the index of the bracket that opens the one closing at {@code close}, or -1 */
    static int matchingOpen(List<Token> tokens, int close) {
        int depth = 0;
        for (int i = close; i >= 0; i--) {
            Token t = tokens.get(i);
            if (t.is(")") || t.is("]") || t.is("}")) {
                depth++;
            } else if (t.is("(") || t.is("[") || t.is("{")) {
                depth--;
                if (depth == 0) {
                    return i;
                }
            }
        }
        return -1;
    }

    /** @return the index of the bracket that closes the one opening at {@code open}, or -1 */
    static int matchingClose(List<Token> tokens, int open) {
        int depth = 0;
        for (int i = open; i < tokens.size(); i++) {
            Token t = tokens.get(i);
            if (t.is("(") || t.is("[") || t.is("{")) {
                depth++;
            } else if (t.is(")") || t.is("]") || t.is("}")) {
                depth--;
                if (depth == 0) {
                    return i;
                }
            }
        }
        return -1;
    }

    /**
     * The arguments of the call whose {@code (} is at {@code open}: the
     * tokens of each one, split on commas at depth zero.
     *
     * @return the arguments, or null when the bracket never closes
     */
    static List<List<Token>> arguments(List<Token> tokens, int open) {
        int close = matchingClose(tokens, open);
        if (close < 0) {
            return null;
        }
        List<List<Token>> args = new ArrayList<>();
        List<Token> current = new ArrayList<>();
        int depth = 0;
        for (int i = open + 1; i < close; i++) {
            Token t = tokens.get(i);
            if (t.is("(") || t.is("[") || t.is("{")) {
                depth++;
            } else if (t.is(")") || t.is("]") || t.is("}")) {
                depth--;
            } else if (t.is(",") && depth == 0) {
                args.add(current);
                current = new ArrayList<>();
                continue;
            }
            current.add(t);
        }
        if (!current.isEmpty() || !args.isEmpty()) {
            args.add(current);
        }
        return args;
    }
}
