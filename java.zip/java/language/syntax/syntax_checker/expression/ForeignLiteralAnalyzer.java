package language.syntax.syntax_checker.expression;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Set;

import language.syntax.syntax_checker.core.Analyzer;
import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.core.Findings;
import language.syntax.syntax_checker.core.Lexis;
import language.syntax.syntax_checker.core.Rule;
import language.syntax.syntax_checker.core.SourceModel;

/**
 * Python forms that NC does not have, as the data I/O examples write them
 * ({@code docs/IO_Phase1_Frontend_Handover.md} 2.3). {@code nc.exe} refuses
 * each one before the script runs; the messages are its own, without the
 * {@code Syntax Error (line, col):} prefix.
 *
 * <pre>
 *   d = {"S1": T1}                unexpected '{' - a value is required here
 *   scale=(224, 224)  x = (1, 2)  '(' was never closed - expected ')' but found ','
 *   rows=2:500  sum(1:3)          '(' was never closed - expected ')' but found ':'
 *   D.book.@id                    '.' is not an arithmetic operator - for element-wise multiplication write A*.B
 * </pre>
 *
 * What NC writes instead: {@code dict(["S1"], [T1])} or {@code d["S1"] = T1},
 * {@code [224, 224]}, {@code rows=[2:500]}, {@code D.book.attrs["id"]}.
 *
 * <p>
 * Not judged: a call's own brackets ({@code f(a, b)}, {@code @(x, y)}), NC's
 * intervals, whose {@code (} closes with {@code ]} ({@code (0:1]}), braces
 * without a {@code key:} inside ({@code {}}, {@code x^{2}}), and the {@code :}
 * of a {@code dict} call: {@code dict(keys: values)} is {@code nc.exe}'s own
 * form of {@code dict(keys, values)}, in any letter case. The first fault on a
 * line, left to right, is reported, as {@code nc.exe} stops at the first.
 */
public final class ForeignLiteralAnalyzer implements Analyzer {

    static final String BRACE = "unexpected '{' - a value is required here";
    static final String TUPLE = "'(' was never closed - expected ')' but found ','";
    static final String RANGE = "'(' was never closed - expected ')' but found ':'";
    static final String AT_AFTER_DOT = "'.' is not an arithmetic operator - for element-wise multiplication write A*.B";

    /** Words that may stand before a grouping {@code (} without making it a call. */
    private static final Set<String> NOT_CALLS = Set.of(
            "if", "elseif", "elif", "while", "for", "return", "not", "and", "or", "in", "is_in",
            "is_not_in", "else");

    @Override
    public void analyze(SourceModel model, CheckContext context, Findings out) {
        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed() || line.isBlank()) {
                continue;
            }
            String message = firstFault(line.masked());
            if (message != null) {
                out.add(line.index(), Rule.FOREIGN_LITERAL, message);
            }
        }
    }

    /**
     * @param m one masked line (string bodies blank)
     * @return nc.exe's message for the left-most Python form, or null
     */
    static String firstFault(String m) {
        // Per open bracket: { what it is, its first top-level ',', its first
        // top-level ':' }, judged when it closes (an interval closes with ']').
        Deque<int[]> groups = new ArrayDeque<>();
        int best = Integer.MAX_VALUE;
        String message = null;
        for (int i = 0; i < m.length(); i++) {
            char c = m.charAt(i);
            if (c == '{' && valuePosition(m, i) && isDictLiteral(m, i)) {
                if (i < best) {
                    best = i;
                    message = BRACE;
                }
            } else if (c == '.' && Lexis.nextNonSpace(m, i + 1) < m.length()
                    && m.charAt(Lexis.nextNonSpace(m, i + 1)) == '@') {
                if (i < best) {
                    best = i;
                    message = AT_AFTER_DOT;
                }
            }
            if (c == '(' || c == '[' || c == '{') {
                // what: the '(' offset for a grouping bracket, -2 for a call's
                // (',' separates values there, ':' is still wrong), -3 for a
                // dict call's (':' separates values too), -1 otherwise
                int what = c != '(' ? -1 : !isCall(m, i) ? i : isDictCall(m, i) ? -3 : -2;
                groups.push(new int[] { what, -1, -1 });
            } else if ((c == ',' || c == ':') && !groups.isEmpty()) {
                int[] g = groups.peek();
                if (c == ',' && g[1] < 0) {
                    g[1] = i;
                } else if (c == ':' && g[2] < 0) {
                    g[2] = i;
                }
            } else if ((c == ')' || c == ']' || c == '}') && !groups.isEmpty()) {
                int[] g = groups.pop();
                if (c != ')' || g[0] == -1) {
                    continue; // [..], {..}, or an interval (0:1]
                }
                if (g[0] != -3 && g[2] >= 0 && g[2] < best) {
                    best = g[2];
                    message = RANGE;
                }
                if (g[0] >= 0 && g[1] >= 0 && g[1] < best) {
                    best = g[1];
                    message = TUPLE;
                }
            }
        }
        return message;
    }

    /** True when {@code (} at {@code open} is a call's: a name, or {@code @}, stands before it. */
    private static boolean isCall(String m, int open) {
        int p = Lexis.prevNonSpace(m, open - 1);
        if (p < 0) {
            return false;
        }
        char c = m.charAt(p);
        if (c == '@') {
            return true;
        }
        if (!Lexis.isIdentPart(c)) {
            return false;
        }
        int start = p;
        while (start > 0 && Lexis.isIdentPart(m.charAt(start - 1))) {
            start--;
        }
        return !NOT_CALLS.contains(m.substring(start, p + 1));
    }

    /**
     * True when the call's {@code (} at {@code open} is {@code dict}'s, in any
     * letter case. A method of that name ({@code x.dict(a:b)}) is not: nc.exe
     * reads a {@code :} as a separator only in the plain call.
     */
    private static boolean isDictCall(String m, int open) {
        int p = Lexis.prevNonSpace(m, open - 1);
        int start = p;
        while (start > 0 && Lexis.isIdentPart(m.charAt(start - 1))) {
            start--;
        }
        if (!m.substring(start, p + 1).equalsIgnoreCase("dict")) {
            return false;
        }
        int before = Lexis.prevNonSpace(m, start - 1);
        return before < 0 || m.charAt(before) != '.';
    }

    /** True when a value is expected at {@code i}: line start or after an operator / opener / separator. */
    private static boolean valuePosition(String m, int i) {
        int p = Lexis.prevNonSpace(m, i - 1);
        if (p < 0) {
            return true;
        }
        char c = m.charAt(p);
        return "=([{,;:+-*/&|!<>%".indexOf(c) >= 0;
    }

    /**
     * True for {@code {key: value, ...}}: a {@code :} at the top level inside
     * the braces. {@code {}} and the editor's {@code ^{...}} superscript input
     * are left to the checks that already judge them.
     */
    private static boolean isDictLiteral(String m, int open) {
        int close = Lexis.matchingClose(m, open);
        if (close < 0) {
            return false;
        }
        int depth = 0;
        for (int k = open + 1; k < close; k++) {
            char c = m.charAt(k);
            if (Lexis.isOpenBracket(c)) {
                depth++;
            } else if (Lexis.isCloseBracket(c)) {
                depth--;
            } else if (c == ':' && depth == 0) {
                return true;
            }
        }
        return false;
    }
}
