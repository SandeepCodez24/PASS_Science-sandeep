package language.syntax.syntax_checker.expression;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;

import language.syntax.syntax_checker.core.Analyzer;
import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.core.Findings;
import language.syntax.syntax_checker.core.Lexis;
import language.syntax.syntax_checker.core.Rule;
import language.syntax.syntax_checker.core.SourceModel;
import language.syntax.syntax_checker.core.TargetList;

/**
 * Matrix declarations and matrix indexing (slicing).
 *
 * <h3>Declaring a matrix</h3>
 * Elements are separated by {@code ,}; a run of <b>adjacent</b> semicolons
 * separates a higher axis -- {@code ;} rows, {@code ;;} the blocks of a 3-D
 * matrix, {@code ;;;} the blocks of a 4-D one, k semicolons axis -(k+1):
 *
 * <pre>
 *   valid                                 error
 *   A = [a, a, a; b, b, b];               A = [[1,2],[3,4]];   the old nested form
 *   A = [1, 2, 3];                        A = [1 2 3];         spaces are not separators
 *   A = [];                               A = [1, 2; 3];       rows of different length
 *   v = [1:2:100];                        A = [1, 2;];         an empty row
 *   B = [1,2;3,4 ;; 5,6;7,8];   2x2x2     A = [1, 2; ; 3, 4];  an empty row (a space between)
 *   Q = [1;2 ;; 3;4 ;;; 5;6 ;; 7;8];      A = [1, , 2];        an empty element
 *   T = [1,2;3,4;;];            1x2x2     A = [1,2;3,4 ;; 5,6];  blocks of different shape
 *   K = [A ;; B];               joins
 * </pre>
 *
 * A trailing run of two or more semicolons raises the rank
 * ({@code [1,2;3,4;;]} is 1x2x2); a trailing single {@code ;} is an empty
 * row. A literal written over several lines with {@code ~~} reaches this
 * check as the one line it is.
 *
 * <h3>What is counted</h3>
 * Rows of one 2-D page must have the same number of elements, counted as
 * before: one element per {@code ,}-separated entry. A page holding a range
 * ({@code [1:3; 4:6]}) is not counted, because the length of a range is only
 * known when it runs. Blocks of an N-D literal are compared shape against
 * shape only when every element of the literal is a plain value -- a number,
 * a string, {@code true} / {@code false}. A name or a call may itself be a
 * matrix ({@code [A ;; B]} joins two matrices), so its shape is the
 * interpreter's question.
 *
 * <h3>Indexing a matrix</h3>
 * A {@code [} written straight after a name, a {@code )} or a {@code ]} --
 * no space -- is an index, not a declaration:
 *
 * <pre>
 *   A[r, c]        one element               B[m]           the slab m of an N-D B
 *   A[::]          a copy of the whole       B[i, j, k]     one key per axis
 *   A[m], A[m,]    row m                     R[1, 2, :]     a whole last axis
 *   A[:,n], A[,n]  column n                  A[0:2:6, 1]    start:step:end
 *   A[m:,]         rows m onwards            A[-1, :]       negative keys count from the end
 *   A[1:3, 1:3]    rows 1..3, columns 1..3
 * </pre>
 *
 * The rank of a variable is only known at run time, so any number of keys is
 * accepted here (the interpreter reports a wrong count for the matrix it
 * has). Reported: an empty index ({@code A[]}, {@code A[,]}), an empty key
 * among three or more ({@code B[, 1, 2]} -- write {@code :}), {@code ;}
 * inside an index, a slice with more than two {@code :} other than
 * {@code A[::]}, a step of zero, and a slice whose start is not below its end
 * when both are written as numbers of the same sign ({@code A[3:1, 2]}).
 *
 * <h3>Lists of variables</h3>
 * The {@code [ ]} on the left of {@code [a, b] = f(x)} is not a matrix; it
 * is checked by {@code AssignmentAnalyzer} through {@link TargetList}. Index
 * brackets inside it ({@code [A[i], b] = ...}) are still checked here.
 *
 * <p>
 * Runs on the masked text, so brackets, commas and semicolons inside a string
 * literal are invisible. A line whose brackets do not balance is left to
 * {@link BracketAnalyzer}.
 */
public final class MatrixAnalyzer implements Analyzer {

    private static final Pattern INTEGER = Pattern.compile("[+-]?\\d+");

    /**
     * A value whose shape is one element: a number (complex included), a
     * masked string literal, {@code true} or {@code false}.
     */
    private static final Pattern PLAIN_VALUE = Pattern.compile(
            "[+-]?(?:(?:\\d+(?:\\.\\d*)?|\\.\\d+)(?:[eE][+-]?\\d+)?i?)"
                    + "|\"[^\"]*\"|'[^']*'|true|false");

    // ---- messages ----------------------------------------------------------

    static final String EMPTY_ROW = "Empty row in matrix: remove the extra ';' (rows are written [a, b; c, d])";
    static final String EMPTY_BLOCK = "Empty block in matrix: a '%s' has no block on one side "
            + "(blocks are written [1,2;3,4 ;; 5,6;7,8])";
    static final String EMPTY_ELEMENT = "Empty element in matrix row %d: a value is missing next to ','";
    static final String NESTED = "Nested rows like [[1, 2], [3, 4]] are not valid: write the matrix as [1, 2; 3, 4]";
    static final String RAGGED_ROWS = "Every row must have the same number of elements: row 1 has %d, row %d has %d";
    static final String RAGGED_BLOCKS = "Every block of an N-D matrix must have the same shape: block 1 is %s, "
            + "block %d is %s (blocks are separated by '%s')";

    @Override
    public void analyze(SourceModel model, CheckContext context, Findings out) {
        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed() || line.isBlank() || line.hasUnterminatedString()) {
                continue;
            }
            String message = check(line.masked());
            if (message != null) {
                out.add(line.index(), Rule.MATRIX, message);
            }
        }
    }

    /**
     * @param s one masked logical line
     * @return the first fault, or null
     */
    static String check(String s) {
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) != '[') {
                continue;
            }
            int close = Lexis.matchingClose(s, i);
            if (close < 0) {
                return null; // unbalanced: BracketAnalyzer's
            }
            String inner = s.substring(i + 1, close);
            String message;
            if (isIndex(s, i)) {
                message = checkIndex(nameBefore(s, i), inner);
            } else if (TargetList.isListOpen(s, i)) {
                message = null; // a list of variables: AssignmentAnalyzer's
            } else {
                message = checkDeclaration(inner);
            }
            if (message != null) {
                return message;
            }
            // Keep scanning from i + 1: brackets nested inside are checked too.
        }
        return null;
    }

    // ─────────────────────────────────────────────────────────────────────
    // Declarations
    // ─────────────────────────────────────────────────────────────────────

    /**
     * The shape of one block of a literal, or why it is malformed.
     *
     * @param dims  the sizes, outermost axis first; null when unknown
     *              (a range, a name or a call inside)
     * @param error the first fault, or null
     */
    private record Block(List<Integer> dims, String error) {
        static Block fault(String message) {
            return new Block(null, message);
        }
    }

    private static String checkDeclaration(String inner) {
        if (inner.isBlank()) {
            return null; // [] is the empty matrix
        }
        String body = inner;
        // A trailing ';;' (or longer) raises the rank: [1,2;3,4;;] is 1x2x2.
        int last = Lexis.prevNonSpace(body, body.length() - 1);
        if (last >= 0 && body.charAt(last) == ';') {
            int runStart = last;
            while (runStart > 0 && body.charAt(runStart - 1) == ';') {
                runStart--;
            }
            if (last - runStart + 1 >= 2 && !body.substring(0, runStart).isBlank()) {
                body = body.substring(0, runStart);
            }
        }
        return block(body, highestLevel(body)).error();
    }

    /**
     * Reads one block at separator level {@code level}: level 0 is a row of
     * {@code ,}-separated elements, level 1 a 2-D page of rows, level k a
     * block of k+1 axes whose parts are separated by k semicolons.
     */
    private static Block block(String text, int level) {
        if (level == 0) {
            return row(text, 1);
        }
        List<String> parts = splitAtLevel(text, level);
        List<Block> blocks = new ArrayList<>();
        boolean known = true;
        for (int p = 0; p < parts.size(); p++) {
            String part = parts.get(p);
            if (part.isBlank()) {
                return Block.fault(level == 1 ? EMPTY_ROW : String.format(EMPTY_BLOCK, ";".repeat(level)));
            }
            Block inside = level == 1 ? row(part, p + 1) : block(part, level - 1);
            if (inside.error() != null) {
                return inside;
            }
            blocks.add(inside);
            known &= inside.dims() != null;
        }

        if (level == 1) {
            return page(parts, blocks);
        }
        if (!known) {
            return new Block(null, null);
        }
        List<Integer> first = blocks.get(0).dims();
        for (int b = 1; b < blocks.size(); b++) {
            List<Integer> other = blocks.get(b).dims();
            if (!first.equals(other)) {
                return Block.fault(String.format(RAGGED_BLOCKS, shapeText(first), b + 1, shapeText(other),
                        ";".repeat(level)));
            }
        }
        List<Integer> dims = new ArrayList<>();
        dims.add(blocks.size());
        dims.addAll(first);
        return new Block(Collections.unmodifiableList(dims), null);
    }

    /**
     * One row: its elements, counted; plain values give a known width.
     *
     * @param number the row's 1-based number in its page, for messages
     */
    private static Block row(String text, int number) {
        List<String> elements = Lexis.splitTopLevel(text, ',');
        boolean plain = true;
        for (String element : elements) {
            String value = element.trim();
            if (value.isEmpty()) {
                return Block.fault(String.format(EMPTY_ELEMENT, number));
            }
            if (value.charAt(0) == '[') {
                return Block.fault(NESTED);
            }
            plain &= PLAIN_VALUE.matcher(value).matches();
        }
        return new Block(plain ? List.of(1, elements.size()) : null, null);
    }

    /**
     * One 2-D page: every row as wide as the first, as before. The width is
     * counted per entry even when an entry is a name (the old rule); a page
     * holding a range is not counted at all.
     */
    private static Block page(List<String> rows, List<Block> rowBlocks) {
        boolean range = false;
        for (String row : rows) {
            range |= Lexis.splitTopLevel(row, ':').size() > 1;
        }
        if (range) {
            return new Block(null, null);
        }
        int firstWidth = Lexis.splitTopLevel(rows.get(0), ',').size();
        for (int r = 1; r < rows.size(); r++) {
            int width = Lexis.splitTopLevel(rows.get(r), ',').size();
            if (width != firstWidth) {
                return Block.fault(String.format(RAGGED_ROWS, firstWidth, r + 1, width));
            }
        }
        for (Block row : rowBlocks) {
            if (row.dims() == null) {
                return new Block(null, null);
            }
        }
        return new Block(List.of(rows.size(), firstWidth), null);
    }

    /** The longest run of adjacent {@code ;} at the top level of {@code text}. */
    private static int highestLevel(String text) {
        int highest = 0;
        int depth = 0;
        int i = 0;
        while (i < text.length()) {
            char c = text.charAt(i);
            if (Lexis.isOpenBracket(c)) {
                depth++;
            } else if (Lexis.isCloseBracket(c)) {
                depth = Math.max(0, depth - 1);
            } else if (c == ';' && depth == 0) {
                int end = Lexis.semicolonRunEnd(text, i);
                highest = Math.max(highest, end - i);
                i = end;
                continue;
            }
            i++;
        }
        return highest;
    }

    /**
     * Splits on runs of exactly {@code level} adjacent semicolons at the top
     * level. Shorter runs stay inside the parts; {@code level} is always the
     * longest run, so no longer run exists.
     */
    private static List<String> splitAtLevel(String text, int level) {
        List<String> parts = new ArrayList<>();
        int depth = 0;
        int start = 0;
        int i = 0;
        while (i < text.length()) {
            char c = text.charAt(i);
            if (Lexis.isOpenBracket(c)) {
                depth++;
            } else if (Lexis.isCloseBracket(c)) {
                depth = Math.max(0, depth - 1);
            } else if (c == ';' && depth == 0) {
                int end = Lexis.semicolonRunEnd(text, i);
                if (end - i == level) {
                    parts.add(text.substring(start, i));
                    start = end;
                }
                i = end;
                continue;
            }
            i++;
        }
        parts.add(text.substring(start));
        return parts;
    }

    /** {@code [2, 3, 4]} as {@code 2x3x4}. */
    private static String shapeText(List<Integer> dims) {
        StringBuilder text = new StringBuilder();
        for (int d : dims) {
            if (text.length() > 0) {
                text.append('x');
            }
            text.append(d);
        }
        return text.toString();
    }

    // ─────────────────────────────────────────────────────────────────────
    // Indexing
    // ─────────────────────────────────────────────────────────────────────

    private static String checkIndex(String name, String inner) {
        String shown = name.isEmpty() ? "A" : name;
        if (inner.isBlank()) {
            return "Empty index '" + shown + "[]': give a row, a column, or both, e.g. "
                    + shown + "[1, 2], " + shown + "[1,], " + shown + "[,2]";
        }
        if (Lexis.splitTopLevel(inner, ';').size() > 1) {
            return "';' is not allowed inside an index: separate the keys with ',', e.g. "
                    + shown + "[1, 2]";
        }
        List<String> parts = Lexis.splitTopLevel(inner, ',');
        if (parts.stream().allMatch(String::isBlank)) {
            return "'" + shown + "[" + ",".repeat(parts.size() - 1) + "]' selects nothing: "
                    + "give a row, a column, or both";
        }
        if (parts.size() > 2 && parts.stream().anyMatch(String::isBlank)) {
            return "Every key of an N-D index needs a value: write ':' for a whole axis, e.g. "
                    + shown + "[:, 1, 2]";
        }
        boolean single = parts.size() == 1;
        for (String part : parts) {
            String message = checkSlice(shown, part.trim(), single);
            if (message != null) {
                return message;
            }
        }
        return null;
    }

    /**
     * One key of an index: empty, a value, or a slice {@code a:b},
     * {@code a:s:b}, {@code a:}, {@code :b}, {@code :}. {@code ::} is
     * accepted only as the whole index ({@code A[::]}, a copy).
     */
    private static String checkSlice(String name, String part, boolean wholeIndex) {
        List<String> pieces = Lexis.splitTopLevel(part, ':');
        int colons = pieces.size() - 1;
        if (colons == 0) {
            return null;
        }
        if (colons == 2 && wholeIndex && part.replace(" ", "").equals("::")) {
            return null;
        }
        if (colons > 2) {
            return "'" + part + "' is not a valid slice: use start:end (e.g. " + name
                    + "[1:3, 1:3]), start:step:end, start: , :end, or " + name + "[::] for a copy";
        }
        String start = pieces.get(0).trim();
        String end = pieces.get(colons).trim();
        if (colons == 2) {
            String step = pieces.get(1).trim();
            if (INTEGER.matcher(step).matches() && parse(step) == 0) {
                return "Slice '" + part.trim() + "' has a step of 0: the step must not be zero";
            }
            return null; // a step may run backwards, so start and end are not compared
        }
        if (INTEGER.matcher(start).matches() && INTEGER.matcher(end).matches()) {
            long from = parse(start);
            long to = parse(end);
            // A negative key counts from the end, so only keys of one sign compare.
            if ((from < 0) == (to < 0) && from >= to) {
                return "Slice '" + start + ":" + end + "' is empty: its start must be smaller than its end";
            }
        }
        return null;
    }

    private static long parse(String integer) {
        try {
            return Long.parseLong(integer.startsWith("+") ? integer.substring(1) : integer);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // Scanning helpers
    // ─────────────────────────────────────────────────────────────────────

    /**
     * True when the {@code [} at {@code open} indexes what touches it on the
     * left: a name, a {@code )} or a {@code ]}. A space before it, an operator,
     * {@code =}, {@code ,} or the start of the line makes it a declaration.
     */
    private static boolean isIndex(String s, int open) {
        if (open == 0) {
            return false;
        }
        char before = s.charAt(open - 1);
        return Lexis.isIdentPart(before) || before == ')' || before == ']';
    }

    /** The name written straight before an index, for messages; may be empty. */
    private static String nameBefore(String s, int open) {
        int start = open;
        while (start > 0 && Lexis.isIdentPart(s.charAt(start - 1))) {
            start--;
        }
        return Lexis.visible(s.substring(start, open));
    }
}
