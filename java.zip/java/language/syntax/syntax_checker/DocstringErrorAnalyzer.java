package language.syntax.syntax_checker;

import java.util.HashSet;
import java.util.Set;

final class DocstringErrorAnalyzer {

    private DocstringErrorAnalyzer() {
    }

    static int countDocstringErrors(String code) {
        if (code == null || code.isEmpty()) {
            return 0;
        }

        int doubleQuoteCount = countOccurrences(code, "\"\"\"");
        int singleQuoteCount = countOccurrences(code, "'''");
        int errors = 0;

        if (doubleQuoteCount % 2 != 0) {
            errors++;
        }
        if (singleQuoteCount % 2 != 0) {
            errors++;
        }
        return errors;
    }

    static Set<Integer> findDocstringErrorLines(String code) {
        Set<Integer> errorLines = new HashSet<>();
        if (code == null || code.isEmpty()) {
            return errorLines;
        }

        String[] lines = code.split("\\R", -1);
        boolean inDoubleDocstring = false;
        boolean inSingleDocstring = false;
        int doubleDocstringStartLine = -1;
        int singleDocstringStartLine = -1;

        for (int i = 0; i < lines.length; i++) {
            int doubleCount = countOccurrences(lines[i], "\"\"\"");
            if (doubleCount % 2 != 0) {
                if (!inDoubleDocstring) {
                    inDoubleDocstring = true;
                    doubleDocstringStartLine = i;
                } else {
                    inDoubleDocstring = false;
                    doubleDocstringStartLine = -1;
                }
            }

            int singleCount = countOccurrences(lines[i], "'''");
            if (singleCount % 2 != 0) {
                if (!inSingleDocstring) {
                    inSingleDocstring = true;
                    singleDocstringStartLine = i;
                } else {
                    inSingleDocstring = false;
                    singleDocstringStartLine = -1;
                }
            }
        }

        if (inDoubleDocstring && doubleDocstringStartLine >= 0) {
            errorLines.add(doubleDocstringStartLine);
        }
        if (inSingleDocstring && singleDocstringStartLine >= 0) {
            errorLines.add(singleDocstringStartLine);
        }

        return errorLines;
    }

    static Set<Integer> findDocstringBlockLines(String code) {
        Set<Integer> docstringLines = new HashSet<>();
        if (code == null || code.isEmpty()) {
            return docstringLines;
        }

        String[] lines = code.split("\\R", -1);
        boolean inDoubleDocstring = false;
        boolean inSingleDocstring = false;

        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            int doubleCount = countOccurrences(line, "\"\"\"");
            int singleCount = countOccurrences(line, "'''");

            if (inDoubleDocstring || inSingleDocstring || doubleCount > 0 || singleCount > 0) {
                docstringLines.add(i);
            }

            if (doubleCount % 2 != 0) {
                inDoubleDocstring = !inDoubleDocstring;
            }
            if (singleCount % 2 != 0) {
                inSingleDocstring = !inSingleDocstring;
            }
        }

        return docstringLines;
    }

    private static int countOccurrences(String text, String token) {
        int count = 0;
        int index = 0;
        while ((index = text.indexOf(token, index)) != -1) {
            count++;
            index += token.length();
        }
        return count;
    }
}
