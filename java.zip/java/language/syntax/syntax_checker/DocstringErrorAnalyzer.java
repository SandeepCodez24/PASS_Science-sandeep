package language.syntax.syntax_checker;

import java.util.HashSet;
import java.util.Set;

/**
 * Reports string literals that open and never close.
 *
 * <h3>What this class used to do, and why it was wrong</h3>
 * It counted {@code """} and {@code '''} tokens per line and flipped an
 * "inside a docstring" flag on every odd count. Neural Code has no triple-quote
 * docstring: it has ordinary string literals with two interchangeable
 * delimiters. Three consequences followed, all bad.
 *
 * <ol>
 * <li>The flag could get stuck. One stray quote near the top of a file marked
 * every line below it as docstring, and because four other analyzers skipped
 * "docstring lines", the rest of the file was silently never checked. A broken
 * script reported zero errors and ran.</li>
 * <li>It could not see the common case. A literal left open by a missing
 * closing quote on a single line contains no {@code """} at all, so the one
 * error it should have caught went unreported.</li>
 * <li>It fought the nesting rule. {@code publish("say 'hi'")} is legal, and
 * so is {@code publish('say "hi"')}: only the quote that opened a literal
 * closes it. Counting delimiter tokens cannot express that.</li>
 * </ol>
 *
 * <p>
 * A literal now lives on exactly one logical line -- one line after {@code ~~}
 * continuations are folded in, so splitting a long message across lines is
 * still fine. An unterminated quote is reported on its own line and cannot
 * affect any other.
 *
 * <p>
 * The class name and its two methods are unchanged so
 * {@link ErrorChecker}'s public surface, and the UI bound to it, keep working.
 */
final class DocstringErrorAnalyzer {

    private DocstringErrorAnalyzer() {
    }

    /**
     * @param code raw editor text
     * @return how many lines leave a string literal open
     */
    static int countDocstringErrors(String code) {
        return findDocstringErrorLines(code).size();
    }

    /**
     * @param code raw editor text
     * @return zero-based indices of lines leaving a string literal open
     */
    static Set<Integer> findDocstringErrorLines(String code) {
        return findUnterminatedStringLines(SourceModel.of(code));
    }

    /**
     * Same check against an already-built model, so a caller that has one does
     * not pay to clean the document twice.
     *
     * @param model the cleaned document
     * @return zero-based indices of lines leaving a string literal open
     */
    static Set<Integer> findUnterminatedStringLines(SourceModel model) {
        Set<Integer> errorLines = new HashSet<>();
        for (SourceModel.Line line : model.lines()) {
            if (!line.isAbsorbed() && line.hasUnterminatedString()) {
                errorLines.add(line.index());
            }
        }
        return errorLines;
    }
}
