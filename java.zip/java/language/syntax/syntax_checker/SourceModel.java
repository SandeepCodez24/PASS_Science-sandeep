package language.syntax.syntax_checker;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The one shared view of a source file that every analyzer in this package
 * reads from.
 *
 * <h3>Why this class exists</h3>
 * Each analyzer used to do its own text cleaning, and they disagreed: one
 * stripped comments, another did not; one understood {@code ~~} continuations,
 * the rest did not; the subscript/superscript pass read raw lines and so saw
 * the contents of string literals as code. Every one of those disagreements was
 * a bug the user could see. Cleaning now happens exactly once, here, and an
 * analyzer that wants a different view of the text is a bug in this file rather
 * than a new private copy of the same logic.
 *
 * <h3>Order of operations (this order matters)</h3>
 * <ol>
 * <li><b>Continuations first.</b> A physical line whose last token is
 * {@code ~~} is folded into the following line. This happens on raw text,
 * before anything else, because {@code ~~} is legal <i>inside an open string
 * literal</i> -- that is how a long message is split:
 *
 * <pre>
 *   Motto = "Nature includes everything around us like trees, animals, ~~
 *   rivers, and mountains that is not made by people.";
 * </pre>
 *
 * Parsing strings before joining would see two broken halves. Because the rule
 * is purely positional, a {@code ~~} in the middle of a line is ordinary text
 * and is left alone: {@code publish("i like this symbol ~~ in my ")} is a
 * complete statement, not a continuation.</li>
 *
 * <li><b>Strings next.</b> {@code "} and {@code '} are both string delimiters
 * and each may appear freely inside the other, so
 * {@code publish("I love the country 'india' as my good friend")} and
 * {@code publish('I love the country "india" as my good friend')} are both
 * ordinary strings. Whichever quote opens the literal is the only one that can
 * close it.</li>
 *
 * <li><b>Comments last.</b> {@code #} and {@code \\} begin a comment only when
 * they are NOT inside a string literal, so the {@code #} in
 * {@code publish("issue #42")} is text, and the {@code '} in
 * {@code \\ matrix.cpp's own comment} never opens a string, because the comment
 * has already claimed the rest of the line.</li>
 * </ol>
 *
 * <h3>Two views per line</h3>
 * {@link Line#code()} is the line with its comment removed and its string
 * literals intact -- use it when the text of a literal matters.
 * {@link Line#masked()} is the same text with every string <i>body</i> replaced
 * by spaces, <b>character for character</b>, so offsets still line up.
 * Structural checks (brackets, operators, assignment, indentation,
 * subscript/superscript) all run on the masked form, which is what makes a
 * bracket or an {@code =} inside a literal invisible to them.
 *
 * <p>
 * The quote characters themselves are <b>kept</b>. Blanking them too made
 * {@code Motto = "…";} read as {@code Motto = ;}, which the completeness check
 * correctly called a line ending in {@code =}. Leaving the delimiters in place
 * means a literal still looks like a value while its contents stay invisible.
 *
 * <h3>Line numbering</h3>
 * Indices are zero-based and always match CodeArea paragraphs. A folded
 * continuation group is reported on the line that <i>started</i> it; the lines
 * it swallowed are marked {@link Line#isAbsorbed()} and carry empty text, so
 * the array length -- and therefore every error line the editor draws a dot on
 * -- still matches what the user sees.
 *
 * <h3>Strings do not run away</h3>
 * A string literal lives on exactly one logical line. An unterminated quote is
 * reported on its own line and nothing leaks past it. The old docstring scanner
 * toggled a flag on every odd count of {@code """}, so one stray quote silently
 * marked the rest of the file as docstring and every analyzer quietly stopped
 * checking it -- a whole file could pass with zero errors because of one typo
 * near the top.
 */
public final class SourceModel {

    /** The long-line continuation token, valid only as the last token on a line. */
    public static final String CONTINUATION = "~~";

    /** One editor paragraph, cleaned. */
    public static final class Line {

        private final int index;
        private final int endIndex;
        private final int ownerIndex;
        private final String raw;
        private final String code;
        private final String masked;
        private final boolean unterminatedString;

        private Line(int index, int endIndex, int ownerIndex, String raw,
                String code, String masked, boolean unterminatedString) {
            this.index = index;
            this.endIndex = endIndex;
            this.ownerIndex = ownerIndex;
            this.raw = raw;
            this.code = code;
            this.masked = masked;
            this.unterminatedString = unterminatedString;
        }

        /** Zero-based index of this line, matching the CodeArea paragraph. */
        public int index() {
            return index;
        }

        /**
         * Index of the last physical line folded into this one. Equal to
         * {@link #index()} unless the line ended with {@code ~~}.
         */
        public int endIndex() {
            return endIndex;
        }

        /** True when this physical line was folded into an earlier one. */
        public boolean isAbsorbed() {
            return ownerIndex >= 0;
        }

        /** The line that swallowed this one, or -1. */
        public int ownerIndex() {
            return ownerIndex;
        }

        /** True when this line continues onto at least one following line. */
        public boolean isContinued() {
            return endIndex > index;
        }

        /** The untouched first physical line, for indentation checks. */
        public String raw() {
            return raw;
        }

        /** Continuations joined and comment removed; string literals intact. */
        public String code() {
            return code;
        }

        /** As {@link #code()}, with every string body blanked to spaces of equal length. */
        public String masked() {
            return masked;
        }

        /** True when a quote opened on this line and never closed. */
        public boolean hasUnterminatedString() {
            return unterminatedString;
        }

        /** True when nothing but whitespace survives cleaning. */
        public boolean isBlank() {
            return masked.trim().isEmpty();
        }
    }

    private final List<Line> lines;

    private SourceModel(List<Line> lines) {
        this.lines = Collections.unmodifiableList(lines);
    }

    private static final Object CACHE_LOCK = new Object();
    private static String cachedSource;
    private static SourceModel cachedModel;

    /**
     * Cleans a whole document.
     *
     * <p>
     * The result of the most recent call is remembered. The gutter factory asks
     * for six different error sets <i>per rendered line</i>, and the text is the
     * same every time, so without this the document was cleaned hundreds of
     * times per keystroke. The model and its lines are immutable, so handing the
     * same instance to several callers is safe.
     *
     * @param code raw editor text (may be null)
     * @return the cleaned model; never null
     */
    public static SourceModel of(String code) {
        String key = code == null ? "" : code;
        synchronized (CACHE_LOCK) {
            if (cachedModel != null && key.equals(cachedSource)) {
                return cachedModel;
            }
        }

        SourceModel model = build(key);
        synchronized (CACHE_LOCK) {
            cachedSource = key;
            cachedModel = model;
        }
        return model;
    }

    private static SourceModel build(String code) {
        List<Line> built = new ArrayList<>();
        if (code == null || code.isEmpty()) {
            return new SourceModel(built);
        }

        String[] raw = code.split("\\R", -1);
        Line[] result = new Line[raw.length];

        int i = 0;
        while (i < raw.length) {
            int start = i;
            int end = i;
            StringBuilder joined = new StringBuilder();

            // Fold every ~~ continuation into one logical line. A trailing ~~
            // on the very last line of the file has nothing to join to, so it
            // is left as ordinary text rather than silently dropped.
            while (true) {
                String current = raw[end];
                String trimmed = stripTrailingWhitespace(current);
                boolean continues = trimmed.endsWith(CONTINUATION) && end + 1 < raw.length;
                if (!continues) {
                    joined.append(current);
                    break;
                }
                joined.append(trimmed, 0, trimmed.length() - CONTINUATION.length());
                end++;
            }

            Cleaned cleaned = clean(joined.toString());
            result[start] = new Line(start, end, -1, raw[start],
                    cleaned.code, cleaned.masked, cleaned.unterminatedString);
            for (int absorbed = start + 1; absorbed <= end; absorbed++) {
                result[absorbed] = new Line(absorbed, absorbed, start, raw[absorbed], "", "", false);
            }
            i = end + 1;
        }

        Collections.addAll(built, result);
        return new SourceModel(built);
    }

    /** Every line, in order, including absorbed continuation lines. */
    public List<Line> lines() {
        return lines;
    }

    /** Number of physical lines, always equal to the editor's paragraph count. */
    public int size() {
        return lines.size();
    }

    /**
     * @param index zero-based line index
     * @return that line, or null when the index is out of range
     */
    public Line line(int index) {
        return index >= 0 && index < lines.size() ? lines.get(index) : null;
    }

    /**
     * The whole document in masked form, newlines preserved, so a cross-line
     * scan (unbalanced brackets spanning several lines) still reports the right
     * line number while seeing neither comments nor string contents.
     *
     * @return masked document text
     */
    public String maskedDocument() {
        StringBuilder document = new StringBuilder();
        for (int i = 0; i < lines.size(); i++) {
            if (i > 0) {
                document.append('\n');
            }
            document.append(lines.get(i).masked());
        }
        return document.toString();
    }

    // -----------------------------------------------------------------
    // Internals
    // -----------------------------------------------------------------

    private static final class Cleaned {
        final String code;
        final String masked;
        final boolean unterminatedString;

        Cleaned(String code, String masked, boolean unterminatedString) {
            this.code = code;
            this.masked = masked;
            this.unterminatedString = unterminatedString;
        }
    }

    /**
     * One left-to-right pass producing both views at once.
     *
     * <p>
     * The two views are built together rather than by two separate scans so
     * they cannot disagree about where a string starts, which is the class of
     * bug this whole file exists to remove.
     */
    private static Cleaned clean(String text) {
        StringBuilder masked = new StringBuilder(text.length());
        char openQuote = 0;
        int commentAt = -1;

        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);

            if (openQuote != 0) {
                // Inside a literal. Only the quote that opened it can close it,
                // which is what lets "…'india'…" and '…"india"…' both work.
                if (ch == openQuote && !SyntaxTextUtils.isEscaped(text, i)) {
                    openQuote = 0;
                    masked.append(ch);
                } else {
                    masked.append(' ');
                }
                continue;
            }

            if ((ch == '"' || ch == '\'') && !SyntaxTextUtils.isEscaped(text, i)) {
                openQuote = ch;
                masked.append(ch);
                continue;
            }

            // Comment markers, recognised only outside a literal.
            if (ch == '#') {
                commentAt = i;
                break;
            }
            if (ch == '\\' && i + 1 < text.length() && text.charAt(i + 1) == '\\') {
                commentAt = i;
                break;
            }

            masked.append(ch);
        }

        String code = commentAt >= 0 ? text.substring(0, commentAt) : text;
        return new Cleaned(code, masked.toString(), openQuote != 0);
    }

    private static String stripTrailingWhitespace(String text) {
        int end = text.length();
        while (end > 0 && Character.isWhitespace(text.charAt(end - 1))) {
            end--;
        }
        return text.substring(0, end);
    }
}
