package language.syntax.syntax_checker;

/**
 * Small text helpers shared across the syntax checker.
 *
 * <p>
 * Most callers should ask {@link SourceModel} for a cleaned line instead of
 * calling {@link #stripTrailingComment(String)} directly. The method is kept
 * because it is cheap, self-contained and occasionally useful on a single line
 * that has no document around it -- but it does NOT understand {@code ~~}
 * continuations, so it is not a substitute for the model.
 */
final class SyntaxTextUtils {

    private SyntaxTextUtils() {
    }

    /**
     * Removes a trailing {@code #} or {@code \\} comment.
     *
     * <p>
     * Both {@code "} and {@code '} open string literals and each nests freely
     * inside the other, so only the quote that opened a literal can close it.
     * The previous version tracked {@code "} alone, which meant a line such as
     * {@code publish('a # b')} lost half its literal, and an apostrophe in
     * {@code \\ matrix.cpp's own comment} was read as an unclosed quote.
     *
     * @param line one physical line
     * @return the line with any comment removed
     */
    static String stripTrailingComment(String line) {
        if (line == null || line.isEmpty()) {
            return line;
        }

        char openQuote = 0;
        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);

            if (openQuote != 0) {
                if (ch == openQuote && !isEscaped(line, i)) {
                    openQuote = 0;
                }
                continue;
            }

            if ((ch == '"' || ch == '\'') && !isEscaped(line, i)) {
                openQuote = ch;
                continue;
            }

            if (ch == '#') {
                return line.substring(0, i);
            }
            if (ch == '\\' && i + 1 < line.length() && line.charAt(i + 1) == '\\') {
                return line.substring(0, i);
            }
        }

        return line;
    }

    /**
     * @param text  the text to inspect
     * @param index position of the character in question
     * @return true when an odd number of backslashes immediately precede it
     */
    static boolean isEscaped(String text, int index) {
        int backslashCount = 0;
        int i = index - 1;
        while (i >= 0 && text.charAt(i) == '\\') {
            backslashCount++;
            i--;
        }
        return backslashCount % 2 != 0;
    }
}
