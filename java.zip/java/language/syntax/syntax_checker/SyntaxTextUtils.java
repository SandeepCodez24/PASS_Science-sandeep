package language.syntax.syntax_checker;

final class SyntaxTextUtils {

    private SyntaxTextUtils() {
    }

    static String stripTrailingComment(String line) {
        boolean inQuote = false;

        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (ch == '"' && !isEscaped(line, i)) {
                inQuote = !inQuote;
                continue;
            }

            if (!inQuote) {
                if (ch == '#') {
                    return line.substring(0, i);
                }
                if (ch == '\\' && i + 1 < line.length() && line.charAt(i + 1) == '\\') {
                    return line.substring(0, i);
                }
            }
        }

        return line;
    }

    static boolean isEscaped(String text, int index) {
        int backslashCount = 0;
        int i = index - 1;
        while (i >= 0 && text.charAt(i) == '\\') {
            backslashCount++;
            i--;
        }
        return backslashCount % 2 != 0;
    }
}
