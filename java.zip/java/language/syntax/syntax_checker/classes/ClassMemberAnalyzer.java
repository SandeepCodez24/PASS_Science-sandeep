package language.syntax.syntax_checker.classes;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import language.syntax.syntax_checker.core.Analyzer;
import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.core.Findings;
import language.syntax.syntax_checker.core.Lexis;
import language.syntax.syntax_checker.core.Rule;
import language.syntax.syntax_checker.core.SourceModel;
import language.syntax.syntax_checker.core.TargetList;
import language.syntax.syntax_checker.functions.ScriptDefinitions;
import language.syntax.syntax_checker.structure.BlockHeaderGrammar;

/**
 * The two names {@code nc.exe} keeps for itself after a dot.
 *
 * <pre>
 *   Shape.base, obj.base     a dict of the fields (their types, or an object's values)
 *   Shape.info, obj.info     a dict of every function callable on the class
 * </pre>
 *
 * Both are built in, so they may not be redefined or given values:
 *
 * <pre>
 *   class T():
 *      function y = info():        class 'T' cannot have a method named 'info' - T.info is built in ...
 *      base.info = 1;              'info' cannot be a field name - after a dot it is reserved ...
 *   FF.base = 3;                   'base' cannot be a field name - ...
 *   Shape.info(1)                  '.info' takes no values - write Shape.info
 * </pre>
 *
 * A method named {@code base} is the constructor, as always, so it is not an
 * error. {@code X.base()} and {@code X.info()} with empty brackets are the
 * same as without them.
 *
 * <p>
 * {@code X.info(...)} with values is judged only when {@code X} is a class of
 * the file, {@code base}, or a variable made from one of its classes
 * ({@code p = P(1)}). On anything else nc.exe calls the built-in
 * {@code info(X, ...)} instead ({@code D.info("x")} on a loaded MAT file).
 */
public final class ClassMemberAnalyzer implements Analyzer {

    static final String INFO_METHOD = "class '%1$s' cannot have a method named 'info' - %1$s.info is built in "
            + "(it lists the class's functions)";
    static final String RESERVED_FIELD = "'%s' cannot be a field name - after a dot it is reserved "
            + "(obj.base lists the fields, obj.info the functions)";
    static final String TAKES_NO_VALUES = "'.%s' takes no values - write %s.%s";

    /** {@code .base(} / {@code .info(}; group 1 is the word. */
    private static final Pattern RESERVED_CALL = Pattern.compile("\\.\\s*(base|info)\\s*\\(");

    private record Frame(String closer, String className) {
    }

    @Override
    public void analyze(SourceModel model, CheckContext context, Findings out) {
        Set<String> classOwners = classOwners(model);
        Deque<Frame> frames = new ArrayDeque<>();
        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed() || line.isBlank()) {
                continue;
            }
            String masked = line.masked();
            String first = BlockHeaderGrammar.firstWord(masked.trim());
            if (BlockHeaderGrammar.isCloser(first)) {
                pop(frames, first);
                continue;
            }
            BlockHeaderGrammar.Header header = BlockHeaderGrammar.parse(masked);
            if (header != null && header.kind() == BlockHeaderGrammar.Kind.CLASS) {
                frames.push(new Frame("csend", header.name()));
                continue;
            }
            if (header != null && header.kind() == BlockHeaderGrammar.Kind.FUNCTION) {
                Frame top = frames.peek();
                if (top != null && top.className() != null && "info".equals(header.name())) {
                    out.add(line.index(), Rule.RESERVED_MEMBER, String.format(INFO_METHOD, top.className()));
                }
                frames.push(new Frame("fnend", null));
                continue;
            }
            if (header != null && header.kind().opensBlock()) {
                frames.push(new Frame(header.kind().closer(), null));
            }
            String message = checkLine(masked, classOwners);
            if (message != null) {
                out.add(line.index(), Rule.RESERVED_MEMBER, message);
            }
        }
    }

    /**
     * The owners whose {@code .info(...)} / {@code .base(...)} nc.exe judges:
     * {@code base}, the classes of the file and the variables made from them.
     */
    private static Set<String> classOwners(SourceModel model) {
        ScriptDefinitions defs = ScriptDefinitions.of(model);
        Set<String> owners = new HashSet<>();
        owners.add("base");
        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed() || line.isBlank()) {
                continue;
            }
            for (String statement : Lexis.splitStatements(line.masked())) {
                String text = statement.trim();
                int equals = Lexis.assignmentIndex(text);
                if (equals <= 0) {
                    continue;
                }
                String left = text.substring(0, equals).trim();
                String right = text.substring(equals + 1).trim();
                int nameEnd = right.isEmpty() || !Lexis.isIdentStart(right.charAt(0)) ? 0 : Lexis.scanIdent(right, 0);
                int open = Lexis.nextNonSpace(right, nameEnd);
                if (Lexis.isIdentifier(left) && nameEnd > 0 && open < right.length() && right.charAt(open) == '('
                        && defs.classDef(right.substring(0, nameEnd)) != null) {
                    owners.add(left);
                }
            }
            BlockHeaderGrammar.Header header = BlockHeaderGrammar.parse(line.masked());
            if (header != null && header.kind() == BlockHeaderGrammar.Kind.CLASS) {
                owners.add(header.name());
            }
        }
        return owners;
    }

    /**
     * @param owners the names whose {@code .base(...)} / {@code .info(...)} is
     *               nc.exe's own ({@link #classOwners})
     * @return the first reserved-name fault on a statement line, or null
     */
    static String checkLine(String masked, Set<String> owners) {
        for (String statement : Lexis.splitStatements(masked)) {
            String text = statement.trim();
            int equals = Lexis.assignmentIndex(text);
            if (equals > 0) {
                String left = text.substring(0, equals).trim();
                String field = left.startsWith("[") ? reservedTarget(left) : reservedField(left);
                if (field != null) {
                    return String.format(RESERVED_FIELD, field);
                }
            }
        }
        Matcher call = RESERVED_CALL.matcher(masked);
        while (call.find()) {
            int open = call.end() - 1;
            int close = Lexis.matchingClose(masked, open);
            if (close < 0 || masked.substring(open + 1, close).isBlank()) {
                continue;
            }
            String owner = owner(masked, call.start());
            if (!owners.contains(owner)) {
                continue; // not a class of this file: nc.exe calls the built-in
            }
            return String.format(TAKES_NO_VALUES, call.group(1), owner, call.group(1));
        }
        return null;
    }

    /** {@code x.base} / {@code a.b.info} on the left of {@code =}: the reserved word, or null. */
    private static String reservedField(String left) {
        int dot = left.lastIndexOf('.');
        if (dot <= 0) {
            return null;
        }
        String after = left.substring(dot + 1).trim();
        if (!"base".equals(after) && !"info".equals(after)) {
            return null;
        }
        for (String segment : left.substring(0, dot).split("\\.")) {
            if (!Lexis.isIdentifier(segment.trim())) {
                return null; // f(x).base = ...: not a field path
            }
        }
        return after;
    }

    /** A list of variables holding {@code obj.base} or {@code obj.info}. */
    private static String reservedTarget(String left) {
        for (TargetList.Target target : TargetList.parse(left).targets()) {
            if (target.kind() == TargetList.Kind.FIELD) {
                String field = reservedField(target.text());
                if (field != null) {
                    return field;
                }
            }
        }
        return null;
    }

    /** The name written before the dot at {@code dot}, for the message; {@code X} when there is none. */
    private static String owner(String s, int dot) {
        int end = Lexis.prevNonSpace(s, dot - 1) + 1;
        int start = end;
        while (start > 0 && Lexis.isIdentPart(s.charAt(start - 1))) {
            start--;
        }
        return start < end ? Lexis.visible(s.substring(start, end)) : "X";
    }

    private static void pop(Deque<Frame> frames, String closer) {
        for (Frame frame : frames) {
            if (frame.closer().equals(closer)) {
                Frame popped;
                do {
                    popped = frames.pop();
                } while (popped != frame);
                return;
            }
        }
    }
}
