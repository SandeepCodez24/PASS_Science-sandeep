package language.syntax.syntax_checker;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The single definition of what a Neural Code block header looks like.
 *
 * <p>
 * Three places need this answer and must never disagree: the error checker
 * ({@link BlockHeaderAnalyzer}), the editor's autofill
 * ({@code EditorIndentationHandler}) and the suggestion discovery
 * ({@code VariableDiscoveryEngine}). Before this class each kept its own idea of
 * "a header", which is how a header missing its colon came to be silently
 * ignored by one pass and blamed on the wrong lines by another.
 *
 * <h3>Accepted header shapes</h3>
 *
 * <pre>
 *   if &lt;condition&gt;:                 elseif &lt;condition&gt;:        else:
 *   while &lt;condition&gt;:              for &lt;loop range&gt;:
 *
 *   function name(args):
 *   function out = name(args):
 *   function [a, b] = name(args):
 *   function (a, b) = name(args):      &larr; REJECTED: use [a, b]
 *
 *   class Name(args):                  &larr; the only class form
 * </pre>
 *
 * {@code args} is empty or a comma-separated list of identifiers. A function
 * may be prefixed by {@code private}, {@code protected} or {@code abstract} when
 * it is a class method; the modifiers do not change the shape.
 *
 * <h3>Recovery, not rejection</h3>
 * {@link #parse(String)} recognises a header by its first word alone, so a line
 * such as {@code function ASD = f(x)} is still reported as a {@code FUNCTION}
 * header -- with {@link Header#hasColon()} false and an error message. Callers
 * therefore keep opening the block, and one missing colon produces one error on
 * its own line instead of a cascade through the body and the closer.
 *
 * <p>
 * Input is expected to be a single <b>masked</b> logical line (string bodies
 * blanked, comment removed), as produced by {@link SourceModel.Line#masked()}.
 */
public final class BlockHeaderGrammar {

    private BlockHeaderGrammar() {
    }

    /** Every header keyword, with the closer it expects. */
    public enum Kind {
        IF("if", "iend"),
        FOR("for", "fend"),
        WHILE("while", "wend"),
        FUNCTION("function", "fnend"),
        CLASS("class", "csend"),
        /** Branch of an {@code if}; opens no block of its own. */
        ELSE("else", null),
        /** Branch of an {@code if}; opens no block of its own. */
        ELSEIF("elseif", null);

        private final String keyword;
        private final String closer;

        Kind(String keyword, String closer) {
            this.keyword = keyword;
            this.closer = closer;
        }

        /** @return the keyword that introduces the header */
        public String keyword() {
            return keyword;
        }

        /** @return the terminator this header needs, or null for a branch */
        public String closer() {
            return closer;
        }

        /** @return true when the header opens a block that needs a closer */
        public boolean opensBlock() {
            return closer != null;
        }

        /** @return true for {@code else} / {@code elseif} */
        public boolean isBranch() {
            return closer == null;
        }
    }

    /** One recognised header line. Immutable. */
    public static final class Header {
        private final Kind kind;
        private final boolean hasColon;
        private final String error;
        private final String name;
        private final List<String> parameters;
        private final List<String> outputs;

        private Header(Kind kind, boolean hasColon, String error, String name,
                List<String> parameters, List<String> outputs) {
            this.kind = kind;
            this.hasColon = hasColon;
            this.error = error;
            this.name = name;
            this.parameters = Collections.unmodifiableList(parameters);
            this.outputs = Collections.unmodifiableList(outputs);
        }

        /** @return the header kind */
        public Kind kind() {
            return kind;
        }

        /** @return true when the line ends with {@code :} */
        public boolean hasColon() {
            return hasColon;
        }

        /** @return a user-facing description of what is wrong, or null */
        public String error() {
            return error;
        }

        /** @return true when the header is complete and well formed */
        public boolean isValid() {
            return error == null;
        }

        /**
         * @return the function or class name when the shape could be read,
         *         otherwise null (always null for if/for/while/else/elseif)
         */
        public String name() {
            return name;
        }

        /** @return the declared parameters; empty when none or unreadable */
        public List<String> parameters() {
            return parameters;
        }

        /** @return the declared outputs of a function; empty when none */
        public List<String> outputs() {
            return outputs;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Shapes
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * An identifier in any supported script. Combining marks are required for
     * Tamil / Malayalam / Telugu consonant-vowel forms, and the two hidden
     * styling markers (U+200C, U+200D) may sit inside a subscripted or
     * superscripted name.
     */
    public static final String IDENT = "[\\p{L}_\\u200C\\u200D][\\p{L}\\p{M}\\p{N}_\\u200C\\u200D]*";

    private static final String IDENT_LIST = "(?:" + IDENT + "(?:\\s*,\\s*" + IDENT + ")*)";

    private static final Pattern MODIFIERS = Pattern.compile(
            "^(?:(?:private|protected|abstract)\\s+)+", Pattern.CASE_INSENSITIVE);

    private static final Pattern FUNCTION_SHAPE = Pattern.compile(
            "^(?:(?<out>" + IDENT + "|\\[\\s*" + IDENT_LIST + "\\s*\\])\\s*=\\s*)?"
                    + "(?<name>" + IDENT + ")\\s*\\(\\s*(?<params>" + IDENT_LIST + ")?\\s*\\)$");

    /** {@code (a, b) = name(...)}: recognised only to give a precise message. */
    private static final Pattern PAREN_OUTPUTS = Pattern.compile("^\\([^)]*\\)\\s*=.*$");

    private static final Pattern CLASS_SHAPE = Pattern.compile(
            "^(?<name>" + IDENT + ")\\s*\\(\\s*(?<params>" + IDENT_LIST + ")?\\s*\\)$");

    // ─────────────────────────────────────────────────────────────────────────
    // Public API
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Reads one masked logical line.
     *
     * @param maskedLine the line with its comment removed and string bodies blanked
     * @return the header, or null when the line is not a block header
     */
    public static Header parse(String maskedLine) {
        if (maskedLine == null) {
            return null;
        }
        String text = maskedLine.trim();
        if (text.isEmpty()) {
            return null;
        }

        int start = 0;
        Matcher modifiers = MODIFIERS.matcher(text);
        if (modifiers.find()) {
            start = modifiers.end();
        }
        String afterModifiers = text.substring(start);

        String word = firstWord(afterModifiers);
        Kind kind = kindFor(word);
        if (kind == null) {
            return null;
        }
        // `private mean, std;` is a field declaration, not a header. Only a
        // function may carry access modifiers.
        if (start > 0 && kind != Kind.FUNCTION) {
            return null;
        }

        boolean hasColon = afterModifiers.endsWith(":");
        String body = hasColon ? afterModifiers.substring(0, afterModifiers.length() - 1) : afterModifiers;
        // Keywords are ASCII, so the lower-cased word has the source length.
        String rest = body.substring(word.length()).trim();

        List<String> messages = new ArrayList<>();
        String name = null;
        List<String> parameters = new ArrayList<>();
        List<String> outputs = new ArrayList<>();

        switch (kind) {
            case IF, WHILE, ELSEIF -> {
                if (rest.isEmpty()) {
                    messages.add("'" + kind.keyword() + "' needs a condition");
                }
            }
            case ELSE -> {
                if (!rest.isEmpty()) {
                    messages.add("'else' takes no condition; use 'elseif <condition>:'");
                }
            }
            case FOR -> {
                if (rest.isEmpty()) {
                    messages.add("'for' needs a loop range, e.g. 'for i = [1:10]:'");
                }
            }
            case FUNCTION -> {
                Matcher shape = FUNCTION_SHAPE.matcher(rest);
                if (shape.matches()) {
                    name = shape.group("name");
                    splitInto(shape.group("params"), parameters);
                    String out = shape.group("out");
                    if (out != null) {
                        String inner = out.startsWith("[") ? out.substring(1, out.length() - 1) : out;
                        splitInto(inner, outputs);
                    }
                } else if (rest.isEmpty()) {
                    messages.add("Function header needs a name: 'function name(args):'");
                } else if (PAREN_OUTPUTS.matcher(rest).matches()) {
                    messages.add("Several outputs are written in square brackets: "
                            + "'function [a, b] = name(args):'");
                } else {
                    messages.add("Malformed function header; use 'name(args)', "
                            + "'out = name(args)' or '[a, b] = name(args)'");
                }
            }
            case CLASS -> {
                Matcher shape = CLASS_SHAPE.matcher(rest);
                if (shape.matches()) {
                    name = shape.group("name");
                    splitInto(shape.group("params"), parameters);
                } else {
                    messages.add("Class header must be 'class Name(args):'");
                }
            }
            default -> {
                // no further shape rules
            }
        }

        if (!hasColon) {
            messages.add("Block header must end with ':'");
        }

        String error = messages.isEmpty() ? null : String.join("; ", messages);
        return new Header(kind, hasColon, error, name, parameters, outputs);
    }

    /**
     * @param word a lower-cased first word
     * @return the header kind it introduces, or null
     */
    public static Kind kindFor(String word) {
        if (word == null || word.isEmpty()) {
            return null;
        }
        for (Kind kind : Kind.values()) {
            if (kind.keyword().equals(word)) {
                return kind;
            }
        }
        return null;
    }

    /**
     * @param word a lower-cased first word
     * @return true for {@code iend}, {@code fend}, {@code wend}, {@code fnend}, {@code csend}
     */
    public static boolean isCloser(String word) {
        if (word == null || word.isEmpty()) {
            return false;
        }
        for (Kind kind : Kind.values()) {
            if (word.equals(kind.closer())) {
                return true;
            }
        }
        return false;
    }

    /**
     * The leading word of a trimmed line, lower-cased. Letters, digits and
     * underscores all belong to the word, so {@code for2} and {@code if_ok} are
     * never mistaken for keywords.
     *
     * @param line a line with no leading whitespace
     * @return the lower-cased first word; empty when the line starts otherwise
     */
    public static String firstWord(String line) {
        if (line == null) {
            return "";
        }
        int end = 0;
        while (end < line.length()) {
            char ch = line.charAt(end);
            if (!Character.isLetterOrDigit(ch) && ch != '_') {
                break;
            }
            end++;
        }
        return line.substring(0, end).toLowerCase(Locale.ROOT);
    }

    private static void splitInto(String commaSeparated, List<String> target) {
        if (commaSeparated == null || commaSeparated.isBlank()) {
            return;
        }
        for (String part : commaSeparated.split(",")) {
            String trimmed = part.trim();
            if (!trimmed.isEmpty()) {
                target.add(trimmed);
            }
        }
    }
}
