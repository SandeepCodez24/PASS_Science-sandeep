package language.syntax.syntax_checker;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * Sorts every fault the editor's checks find into the four categories the user
 * sees, and words them for the gutter tooltip and the Command Window.
 *
 * <h3>The four categories</h3>
 *
 * <table>
 * <tr><th>Category</th><th>What lands in it</th></tr>
 * <tr><td>Undefined Variable Error</td><td>a name used before anything defines it</td></tr>
 * <tr><td>Syntax Error</td><td>everything about the shape of the code: brackets, operators,
 * powers, separators, sub/superscripts, block headers and closers, block structure (an unclosed
 * {@code if}, an orphaned {@code iend}, an {@code else} outside an {@code if}), unterminated
 * strings and malformed assignments</td></tr>
 * <tr><td>Unassigned Variable Error</td><td>a name given an {@code =} and then no value:
 * {@code DD = ;}</td></tr>
 * <tr><td>Indentation Error</td><td>the leading spaces only: not a multiple of 3, a tab, or not
 * the depth the enclosing blocks require</td></tr>
 * </table>
 *
 * <h3>One issue per line per category</h3>
 * Several analyzers can find something on the same line. All the Syntax
 * findings on a line become one {@link Issue} carrying every message, so the
 * Command Window prints one row per line and category, and
 * {@link ErrorChecker.ErrorReport#getErrorCount()} counts exactly those rows.
 * The number in "Run aborted: 3 error(s)" is always the number of rows above
 * it.
 *
 * <h3>Duplicates removed</h3>
 * <ul>
 * <li>{@code DD = ;} is also "an operator with no value after it" to
 * {@link OperatorSequenceAnalyzer}. When {@link AssignmentAnalyzer} has
 * explained a line's {@code =}, the operator pass's note about that same
 * {@code =} is dropped.</li>
 * <li>An unterminated string is part of the incomplete-line set and also its
 * own set; it is reported once.</li>
 * </ul>
 *
 * <h3>Where it is used</h3>
 * The gutter bar and its tooltip ({@code ErrorStatusManager}), the footer and
 * status counters (through {@link ErrorChecker.ErrorReport}), and every
 * "Run aborted" / "Step aborted" report in the Command Window, whether the run
 * came from the Run button, the step runner, or a script name typed at the
 * {@code >>} prompt. It reads only {@link ErrorChecker#lineIssues(String)}, so
 * adding a check there and a mapping here is the whole job of a new rule.
 *
 * <p>
 * Line numbers inside this class are zero-based, like every analyzer.
 * {@link Issue#displayLine()} gives the one-based number the editor shows.
 */
public final class ErrorClassifier {

    /** The user-facing error categories, in the order they are listed. */
    public enum Category {
        UNDEFINED_VARIABLE("Undefined Variable Error", "Undefined Variable Errors"),
        SYNTAX("Syntax Error", "Syntax Errors"),
        UNASSIGNED_VARIABLE("Unassigned Variable Error", "Unassigned Variable Errors"),
        INDENTATION("Indentation Error", "Indentation Errors");

        private final String title;
        private final String plural;

        Category(String title, String plural) {
            this.title = title;
            this.plural = plural;
        }

        /** @return the heading shown to the user, e.g. "Syntax Error" */
        public String title() {
            return title;
        }

        /** @return the plural form for counters, e.g. "Syntax Errors" */
        public String plural() {
            return plural;
        }
    }

    /** Whether an issue blocks a run. */
    public enum Severity {
        /** Blocks Run and Step; crimson bar. */
        ERROR,
        /** Reported but does not block; amber bar. No check raises one yet. */
        WARNING
    }

    /** One category of fault on one line. Immutable. */
    public static final class Issue {
        private final int line;
        private final Category category;
        private final Severity severity;
        private final List<String> messages;

        private Issue(int line, Category category, Severity severity, List<String> messages) {
            this.line = line;
            this.category = category;
            this.severity = severity;
            this.messages = Collections.unmodifiableList(messages);
        }

        /** @return the zero-based line index */
        public int line() {
            return line;
        }

        /** @return the one-based line number shown in the editor */
        public int displayLine() {
            return line + 1;
        }

        public Category category() {
            return category;
        }

        public Severity severity() {
            return severity;
        }

        public boolean isError() {
            return severity == Severity.ERROR;
        }

        /** @return every message for this line and category, at least one */
        public List<String> messages() {
            return messages;
        }

        /** @return the messages joined into one sentence list */
        public String message() {
            return String.join("; ", messages);
        }
    }

    /** Every issue in one document. Immutable. */
    public static final class Classification {
        private final List<Issue> issues;
        private final Map<Integer, List<Issue>> byLine;
        private final Map<Category, Integer> counts;
        private final int errorCount;
        private final int warningCount;

        private Classification(List<Issue> issues) {
            this.issues = Collections.unmodifiableList(issues);
            Map<Integer, List<Issue>> lines = new TreeMap<>();
            Map<Category, Integer> perCategory = new EnumMap<>(Category.class);
            for (Category category : Category.values()) {
                perCategory.put(category, 0);
            }
            int errors = 0;
            int warnings = 0;
            for (Issue issue : issues) {
                lines.computeIfAbsent(issue.line(), k -> new ArrayList<>()).add(issue);
                perCategory.merge(issue.category(), 1, Integer::sum);
                if (issue.isError()) {
                    errors++;
                } else {
                    warnings++;
                }
            }
            lines.replaceAll((k, v) -> Collections.unmodifiableList(v));
            this.byLine = Collections.unmodifiableMap(lines);
            this.counts = Collections.unmodifiableMap(perCategory);
            this.errorCount = errors;
            this.warningCount = warnings;
        }

        /** @return every issue, by line and then by category order */
        public List<Issue> issues() {
            return issues;
        }

        /**
         * @param line zero-based line index
         * @return that line's issues; empty when it is clean
         */
        public List<Issue> issuesOn(int line) {
            List<Issue> onLine = byLine.get(line);
            return onLine == null ? List.of() : onLine;
        }

        /** True when the line carries at least one blocking issue. */
        public boolean isErrorLine(int line) {
            for (Issue issue : issuesOn(line)) {
                if (issue.isError()) {
                    return true;
                }
            }
            return false;
        }

        /** True when the line carries issues but none of them blocks. */
        public boolean isWarningLine(int line) {
            return !issuesOn(line).isEmpty() && !isErrorLine(line);
        }

        /** @return how many issues fall in {@code category} */
        public int count(Category category) {
            return counts.getOrDefault(category, 0);
        }

        public int errorCount() {
            return errorCount;
        }

        public int warningCount() {
            return warningCount;
        }

        /** True when a run must be refused. */
        public boolean hasErrors() {
            return errorCount > 0;
        }
    }

    /** At most this many rows are printed in the Command Window; the rest are summarised. */
    public static final int CONSOLE_LIMIT = 50;

    /** The mark the backend prints before its own errors, used for ours too. */
    private static final String CROSS = "\u2716 ";

    private static final String UNDEFINED_ONE = "'%s' is used before it is defined";
    private static final String UNDEFINED_MANY = "%s are used before they are defined";
    private static final String UNDEFINED_UNNAMED = "A name on this line is used before it is defined";
    private static final String ASSIGNS_TO_CALL =
            "Cannot assign to a function call; the left of '=' must be a variable name";
    private static final String STYLING = "Invalid subscript/superscript usage";
    private static final String UNTERMINATED = "String literal is never closed: add the matching quote";
    private static final String INDENTATION_FALLBACK =
            "Invalid indentation: use " + IndentationSyntaxAnalyzer.INDENT_SIZE + " spaces per level";

    private static final Object CACHE_LOCK = new Object();
    private static String cachedSource;
    private static Classification cachedClassification;

    private ErrorClassifier() {
    }

    // =====================================================================
    // Classification
    // =====================================================================

    /**
     * Classifies a whole document. The result of the most recent call is
     * cached, because the gutter asks once per rendered line.
     *
     * @param code raw editor text (may be null)
     * @return the classification; never null
     */
    public static Classification classify(String code) {
        String key = code == null ? "" : code;
        synchronized (CACHE_LOCK) {
            if (cachedClassification != null && key.equals(cachedSource)) {
                return cachedClassification;
            }
        }

        Classification result = build(key);
        synchronized (CACHE_LOCK) {
            cachedSource = key;
            cachedClassification = result;
        }
        return result;
    }

    private static Classification build(String code) {
        SourceModel model = SourceModel.of(code);
        ErrorChecker.LineIssues found = ErrorChecker.lineIssues(code);
        List<Issue> issues = new ArrayList<>();

        for (SourceModel.Line line : model.lines()) {
            int i = line.index();
            if (!found.isErrorLine(i) && !found.hasUnterminatedString(i)) {
                continue;
            }

            Set<String> undefined = new LinkedHashSet<>();
            Set<String> syntax = new LinkedHashSet<>();
            Set<String> unassigned = new LinkedHashSet<>();
            Set<String> indentation = new LinkedHashSet<>();

            // ---- Undefined Variable ------------------------------------
            if (found.hasUndefinedVariable(i)) {
                undefined.add(undefinedMessage(found.undefinedNames(i)));
            }

            // ---- Assignment: Syntax or Unassigned -----------------------
            boolean assignmentExplained = found.hasAssignment(i);
            if (assignmentExplained) {
                if (found.isUnassigned(i)) {
                    unassigned.add(found.assignmentMessage(i));
                } else {
                    syntax.add(found.assignmentMessage(i));
                }
            }

            // ---- Syntax: shape of the line ------------------------------
            if (found.hasUnterminatedString(i)) {
                syntax.add(UNTERMINATED);
            } else if (found.hasIncompleteLine(i)) {
                syntax.add(SyntaxLineAnalyzer.incompleteReason(line));
            }
            if (found.hasInvalidExponent(i)) {
                syntax.add(orDefault(found.exponentMessage(i), "Invalid use of the power operator '^'"));
            }
            if (found.hasMissingSeparator(i)) {
                syntax.add(orDefault(found.separatorMessage(i), "Missing ',' or operator between two values"));
            }
            if (found.hasOperatorSequence(i)) {
                String message = found.operatorMessage(i);
                // The assignment pass already explained this '='.
                boolean aboutEquals = message != null && message.contains("'='");
                if (!(assignmentExplained && aboutEquals)) {
                    syntax.add(orDefault(message, "Invalid operator sequence"));
                }
            }
            if (found.hasSubscriptSuperscript(i)) {
                int faults = found.subscriptSuperscriptCount(i);
                if (ErrorChecker.assignsToCall(line.masked())) {
                    syntax.add(ASSIGNS_TO_CALL);
                    faults--;
                }
                if (faults > 0) {
                    syntax.add(STYLING);
                }
            }
            if (found.hasBlockHeader(i)) {
                syntax.add(orDefault(found.blockHeaderMessage(i), "Malformed block header"));
            }

            // ---- Structure vs spacing -----------------------------------
            if (found.hasIndentation(i)) {
                String structure = found.structureMessage(i);
                String spacing = found.indentationMessage(i);
                if (structure != null) {
                    syntax.add(structure);
                }
                if (spacing != null) {
                    indentation.add(spacing);
                } else if (structure == null) {
                    indentation.add(INDENTATION_FALLBACK);
                }
            }

            add(issues, i, Category.UNDEFINED_VARIABLE, undefined);
            add(issues, i, Category.SYNTAX, syntax);
            add(issues, i, Category.UNASSIGNED_VARIABLE, unassigned);
            add(issues, i, Category.INDENTATION, indentation);
        }

        return new Classification(issues);
    }

    private static void add(List<Issue> issues, int line, Category category, Set<String> messages) {
        messages.remove(null);
        if (!messages.isEmpty()) {
            issues.add(new Issue(line, category, Severity.ERROR, new ArrayList<>(messages)));
        }
    }

    private static String undefinedMessage(List<String> names) {
        if (names == null || names.isEmpty()) {
            return UNDEFINED_UNNAMED;
        }
        if (names.size() == 1) {
            return String.format(UNDEFINED_ONE, names.get(0));
        }
        StringBuilder quoted = new StringBuilder();
        for (int k = 0; k < names.size(); k++) {
            if (k > 0) {
                quoted.append(k == names.size() - 1 ? " and " : ", ");
            }
            quoted.append('\'').append(names.get(k)).append('\'');
        }
        return String.format(UNDEFINED_MANY, quoted);
    }

    private static String orDefault(String message, String fallback) {
        return message == null || message.isBlank() ? fallback : message;
    }

    // =====================================================================
    // Command Window report
    // =====================================================================

    /**
     * The block printed in the Command Window when a run is refused:
     *
     * <pre>
     * ✖ Unassigned Variable Error (line 9): 'DD' is declared but never given a value
     * ✖ Syntax Error (line 11): ';' is not allowed inside publish(...)
     * Run aborted: 2 error(s) in t9_isolate3.nc (1 Syntax, 1 Unassigned Variable).
     * </pre>
     *
     * Only blocking issues are listed. Beyond {@link #CONSOLE_LIMIT} rows the
     * rest are summarised in one line so a badly broken file cannot flood the
     * window.
     *
     * @param classification the file's issues
     * @param fileName       the name to show, e.g. {@code t9_isolate3.nc}
     * @param action         what was refused, e.g. {@code "Run"} or {@code "Step"}
     * @return the report, every line ending in a newline; empty when there are no errors
     */
    public static String consoleReport(Classification classification, String fileName, String action) {
        if (classification == null || !classification.hasErrors()) {
            return "";
        }

        StringBuilder out = new StringBuilder();
        int printed = 0;
        for (Issue issue : classification.issues()) {
            if (!issue.isError()) {
                continue;
            }
            if (printed == CONSOLE_LIMIT) {
                int rest = classification.errorCount() - printed;
                out.append("  ... and ").append(rest).append(" more error(s); see the crimson markers in the editor.\n");
                break;
            }
            out.append(CROSS).append(issue.category().title())
                    .append(" (line ").append(issue.displayLine()).append("): ")
                    .append(issue.message()).append('\n');
            printed++;
        }

        out.append(action == null || action.isBlank() ? "Run" : action).append(" aborted: ")
                .append(classification.errorCount()).append(" error(s)");
        if (fileName != null && !fileName.isBlank()) {
            out.append(" in ").append(fileName);
        }
        out.append(" (").append(tally(classification)).append(").\n");
        return out.toString();
    }

    /** "2 Syntax, 1 Undefined Variable" -- the categories that occur, in enum order. */
    private static String tally(Classification classification) {
        StringBuilder text = new StringBuilder();
        for (Category category : Category.values()) {
            int count = classification.count(category);
            if (count == 0) {
                continue;
            }
            if (text.length() > 0) {
                text.append(", ");
            }
            String title = category.title();
            text.append(count).append(' ').append(title, 0, title.length() - " Error".length());
        }
        return text.toString();
    }
}
