package language.syntax.syntax_checker.symbols;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import language.syntax.syntax_checker.core.Analyzer;
import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.core.Findings;
import language.syntax.syntax_checker.core.Lexis;
import language.syntax.syntax_checker.core.Rule;
import language.syntax.syntax_checker.core.SourceModel;
import language.syntax.syntax_checker.core.TargetList;
import language.syntax.syntax_checker.structure.BlockHeaderGrammar;
import language.syntax.syntax_checker.structure.FunctionSignature;
import language.semantic.ScriptedName;
import language.syntax.textcolours.ConstantWords;
import ui.managers.LanguageDesignManager;

/**
 * Reports references to names that no open scope defines.
 *
 * <h3>Scopes</h3>
 * The file is one scope; a {@code function} or {@code class} header opens a
 * nested one that {@code fnend} / {@code csend} closes, so parameters and
 * locals are visible in the body and do not leak out of it. Functions and
 * classes may be used before the line that defines them (the interpreter
 * pre-registers them), so their names are collected first.
 *
 * <h3>Scripts in the same folder</h3>
 * A script beside the file being edited ({@code ABC.nc}) is a known name:
 * {@code ABC;} runs it and {@code ABC.f(x)} calls a function inside it, and
 * neither is an undefined name. Whether a script is <i>used correctly</i>
 * ({@code ABC()} and {@code X = ABC} are not) is
 * {@link ScriptCallAnalyzer}'s question. Without a known folder (an unsaved
 * tab) there are no scripts, and {@code ABC;} is reported here.
 *
 * <h3>Complex literals</h3>
 * The {@code i} of {@code 5i} is part of the number, not a reference to a
 * variable {@code i}; number literals are blanked before names are read.
 *
 * <p>
 * Names are matched on masked text, so the words in
 * {@code publish("total is", t)} are not read as variables. The message names
 * every undefined name on the line, as written in the source.
 *
 * <h3>Subscripted names (changed)</h3>
 * A name may carry a subscript and a superscript written {@code A_$1},
 * {@code μ_$i_@2}; the whole thing is ONE name, so {@code A_$1} and
 * {@code A_$2} are two different variables and neither is {@code A}. Names
 * are found with {@link ScriptedName#NAME_REGEX}, which also takes in
 * combining marks, so a Tamil or Devanagari name with a vowel sign
 * ({@code கா}, {@code कि}) is read whole instead of being cut at the mark.
 * Whether a name is well formed ({@code A_$} with nothing after it, a
 * {@code ₁}, a zero-width joiner) is not this analyzer's question.
 *
 * <h3>Lists of variables (changed)</h3>
 * Every name on the left of {@code [a, b; c, d] = M} is being defined; the
 * list is read by {@link TargetList}, the same reader
 * {@code AssignmentAnalyzer} uses. {@code ~} is never a variable. In
 * {@code A[i]} and {@code obj.f} only the root is defined; the {@code i} is
 * a reference. The right side is read <b>before</b> the names are defined,
 * as the interpreter evaluates it, so {@code [a, b] = [b, a]} needs both
 * names already. The retired {@code (a, b) = f(x)} still defines its names,
 * so its own Syntax Error is not followed by a cascade of undefined ones;
 * {@code (z) = 4} defines {@code z}.
 *
 * <p>
 * Statements are split on {@code ;} at bracket depth zero, so the rows of
 * {@code [m11, m12; m21, m22] = M} stay one statement.
 */
public final class UndefinedVariableAnalyzer implements Analyzer {

    /** One name, subscript and superscript included; no capture groups. */
    private static final String NAME = ScriptedName.NAME_REGEX;

    static final String UNDEFINED_ONE = "'%s' is used before it is defined";
    static final String UNDEFINED_MANY = "%s are used before they are defined";
    static final String UNDEFINED_UNNAMED = "A name on this line is used before it is defined";
    /** The interpreter's words for {@code U ,= 1} with no {@code U}; {@code %1$s} is {@code ,=} or {@code ;=}. */
    static final String EXTEND_UNDEFINED =
            "extend error (%1$s): variable '%2$s' is not defined — initialize it first, e.g. %2$s = []";

    private static final Pattern IDENTIFIER_PATTERN = Pattern.compile("(?U)" + NAME);

    // A `for` header DECLARES its loop variable, which the generic `=`-based
    // heuristic below cannot see: for `for i = [12:23]:` it would take
    // everything left of the `=` and register the compound string "for i" as
    // the variable, leaving the real loop variable `i` unknown and every later
    // `publish(i)` flagged as undefined. Matched before that heuristic so the
    // loop variable is captured on its own. The trailing `:` is optional --
    // both `for i = [lo:hi]:` and the older colon-less `for i = [lo:hi]` are
    // valid -- and `:?` keeps it out of both capture groups.
    // `for x in <expression>:` is read the same way (nc.exe takes any
    // expression after `in` since 2026-10, not only a name).
    private static final Pattern FOR_HEADER_PATTERN = Pattern
            .compile("(?U)^for\\s+(" + NAME + ")\\s*(?:=|\\s+in\\s+)\\s*(.*?)\\s*:?\\s*$");

    // A `class` header declares the class name (later used as a constructor,
    // `r = Reading(23.5)`) and optionally names a parent class. Both are type
    // names, not undefined variables. `abstract`/`reversible` may prefix it.
    // The trailing `(?:@name(...))?` allows a class annotation such as
    // `class Controller() @rate(10Hz)` (Temporal Determinism).
    private static final Pattern CLASS_HEADER_PATTERN = Pattern.compile(
            "(?U)^(?:(?:abstract|reversible)\\s+)*class\\s+(" + NAME + ")"
                    + "\\s*(?:\\(([^)]*)\\))?\\s*(?:@" + NAME + "\\s*\\([^)]*\\)\\s*)?:?\\s*$");

    // A class field declaration: `private mean, std;` / `protected count;`.
    // These declare names with no `=`, so without this they read as bare
    // references to undefined variables.
    private static final Pattern FIELD_DECLARATION_PATTERN = Pattern.compile(
            "(?U)^(?:private|protected)\\s+(" + NAME + "(?:\\s*,\\s*" + NAME + ")*)\\s*$");

    // `function ...` in any of its four header shapes, optionally prefixed by
    // an access modifier when the function is a class method
    // (`private function base(v)`). The remainder after the keyword is parsed
    // procedurally by parseFunctionHeader().
    private static final Pattern FUNCTION_HEADER_PATTERN = Pattern
            .compile("(?U)^(?:(?:private|protected|abstract)\\s+)*function\\b\\s*(.*)$");

    // Names in round brackets on the left: `(z) = 4` (one name, valid) and
    // the retired `(sum1, prod1) = arithmetics(3, 4);`, which
    // AssignmentAnalyzer reports. Both bind their names here; the generic
    // `=` heuristic would register the compound string "(sum1, prod1)" and
    // leave the real names unknown for every later line.
    private static final Pattern ROUND_TARGETS_PATTERN = Pattern.compile(
            "(?U)^\\(\\s*(" + NAME + "(?:\\s*,\\s*" + NAME + ")*)\\s*\\)\\s*=(?!=)\\s*(.*)$");

    private static final Pattern LEADING_IDENTIFIER_PATTERN =
            Pattern.compile("(?U)^(" + NAME + ")");

    // Every reserved word the lexer recognises plus every block terminator the
    // parser accepts. Anything missing here is read as a bare variable
    // reference and reported as undefined -- which is why `function`, `class`,
    // `fnend`, `csend`, `require`, `ensure` and the access modifiers each used
    // to produce an error on their own line. `base` is the reserved instance
    // self-reference inside a class body, not a user variable.
    //
    // `print` stays in the list purely so older scripts do not light up red.
    // `publish` is the statement the language uses now.
    private static final Set<String> KEYWORDS = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(
            "print", "publish", "if", "else", "elseif", "elif", "for", "while", "return", "break", "continue",
            "true", "false", "null", "and", "or", "not", "is_in", "is_not_in", "new", "clear",
            "iend", "wend", "fend", "fnend", "csend", "end", "endif", "endfor", "endwhile",
            "function", "class", "loop", "in", "base",
            "private", "protected", "abstract", "require", "ensure", "reversible")));

    // Names the parser resolves itself, so they are never user variables: the
    // physical unit constants and the built-in math/physics constants table
    // (constants_builtin.cpp). Without these, `d = 5 * m;` reported `m` as
    // undefined and every unit-bearing line was blocked. Matched exactly:
    // nc.exe reads constant names case-sensitively, and since 2026-10 has no
    // one-letter constants g, r, h (an unassigned `r` silently became the gas
    // constant) - gravity, gas_constant and planck remain.
    // The constants themselves are listed once, in ConstantWords (the
    // highlighter's list too); the physical units are added here.
    private static final Set<String> BUILTIN_CONSTANTS;
    static {
        Set<String> known = new HashSet<>(Arrays.asList("m", "s", "kg", "N", "Pa"));
        known.addAll(Arrays.asList(ConstantWords.WORDS));
        BUILTIN_CONSTANTS = Collections.unmodifiableSet(known);
    }

    /** What a `function` header introduces: its name, outputs, inputs, and the defaults' texts. */
    private static final class FunctionHeader {
        final String name;
        final List<String> outputs;
        final List<String> parameters;
        final List<String> defaults;

        FunctionHeader(String name, List<String> outputs, List<String> parameters, List<String> defaults) {
            this.name = name;
            this.outputs = outputs;
            this.parameters = parameters;
            this.defaults = defaults;
        }
    }

    @Override
    public void analyze(SourceModel model, CheckContext context, Findings out) {
        if (model.size() == 0) {
            return;
        }

        // Scope stack. Index 0 is the file-level scope; a `function` or `class`
        // header pushes a scope that `fnend`/`csend` pops, so parameters and
        // body locals are visible inside the body without leaking out of it. A
        // lookup walks every open scope, so a body can still reference
        // file-level variables declared above it.
        Deque<Set<String>> scopes = new ArrayDeque<>();
        scopes.push(new HashSet<>());

        // Stack depth at each open `class` header, so `csend` knows how far to
        // unwind (see the terminator handling below).
        Deque<Integer> classScopeDepths = new ArrayDeque<>();

        // The language allows calling a function or constructing a class that
        // is defined LATER in the file (parser pass 1 pre-registers
        // forward-referenced definitions), so collect every declared name
        // before the line-by-line walk rather than only as it is reached.
        collectDeclaredNames(model, scopes.peek());

        // Scripts beside this file are called by bare name ('ABC;') and their
        // functions through it ('ABC.f(x)').
        scopes.peek().addAll(context.scripts());

        for (SourceModel.Line sourceLine : model.lines()) {
            if (sourceLine.isAbsorbed() || sourceLine.isBlank()) {
                continue;
            }

            int lineErrors = 0;
            List<String> lineNames = new ArrayList<>();
            String normalizedLine = normalizeVariableNames(sourceLine.masked());

            // The inputs of an anonymous function (`f = @(x) x * 2;`) are
            // known inside that statement only. They sit in an extra,
            // outermost scope - so a name the statement assigns still goes to
            // the real one - removed again before the next statement.
            Set<String> anonymousScope = null;
            // The extend operator (,= or ;=) of each statement, or null. The
            // masked view reads `M ,= X` as `M = X`, so it is found by offset.
            List<SourceModel.ExtendOperator> extendOf = extendOperatorPerStatement(sourceLine);
            int statementIndex = -1;
            for (String statement : splitStatements(normalizedLine)) {
                statementIndex++;
                if (anonymousScope != null) {
                    scopes.removeLastOccurrence(anonymousScope);
                    anonymousScope = null;
                }
                SourceModel.ExtendOperator extend = statementIndex < extendOf.size()
                        ? extendOf.get(statementIndex) : null;
                String line = statement.trim();
                if (line.isEmpty()) {
                    continue;
                }
                Set<String> anonymousInputs = anonymousInputs(line);
                if (!anonymousInputs.isEmpty()) {
                    anonymousScope = anonymousInputs;
                    scopes.addLast(anonymousScope);
                }

                // Closing a function/class body ends its scope. `csend` unwinds
                // back to the depth recorded when the class opened, so a method
                // body left unclosed inside it cannot strand a scope and leak
                // its parameters into the rest of the file.
                String lowerLine = line.toLowerCase();
                if (lowerLine.equals("fnend")) {
                    if (scopes.size() > 1) {
                        scopes.pop();
                    }
                    continue;
                }
                if (lowerLine.equals("csend")) {
                    Integer opened = classScopeDepths.pollFirst();
                    int target = opened == null ? 1 : opened;
                    while (scopes.size() > Math.max(target, 1)) {
                        scopes.pop();
                    }
                    continue;
                }

                // `function` header: the output name(s) and every parameter are
                // declared here. Without this the generic `=` heuristic
                // registers the compound string "function B" and the real
                // output `B` plus every parameter stay unknown, so the whole
                // body reports undefined-variable errors.
                Matcher functionHeaderMatcher = FUNCTION_HEADER_PATTERN.matcher(line);
                if (functionHeaderMatcher.matches()) {
                    FunctionHeader header = parseFunctionHeader(line);
                    Set<String> bodyScope = new HashSet<>();
                    if (header != null) {
                        scopes.peek().add(header.name);
                        bodyScope.addAll(header.outputs);
                        bodyScope.addAll(header.parameters);
                    }
                    scopes.push(bodyScope);
                    // A default is evaluated inside the function at each call:
                    // it sees every input (h=w), the object in a method
                    // (scale=base.w) and anything visible where the function
                    // is defined -- the same names as the body.
                    if (header != null) {
                        for (String defaultText : header.defaults) {
                            lineErrors += countUndefinedIdentifiers(defaultText, scopes, lineNames);
                        }
                    }
                    continue;
                }

                // `class` header: the class name is a type (used later as a
                // constructor), and a parent name in parentheses is another
                // type -- neither is an undefined variable. The body scope
                // carries `base`, the reserved instance self-reference.
                Matcher classHeaderMatcher = CLASS_HEADER_PATTERN.matcher(line);
                if (classHeaderMatcher.matches()) {
                    scopes.peek().add(normalizeVariableName(classHeaderMatcher.group(1)));
                    classScopeDepths.push(scopes.size());
                    Set<String> bodyScope = new HashSet<>();
                    bodyScope.add("base");
                    String parent = classHeaderMatcher.group(2);
                    if (parent != null && !parent.trim().isEmpty()) {
                        scopes.peek().add(normalizeVariableName(parent.trim()));
                    }
                    scopes.push(bodyScope);
                    continue;
                }

                // Class field declaration: `private mean, std;` declares names
                // without an `=`, so register them rather than reading them as
                // references to undefined variables.
                Matcher fieldDeclarationMatcher = FIELD_DECLARATION_PATTERN.matcher(line);
                if (fieldDeclarationMatcher.matches()) {
                    for (String fieldName : fieldDeclarationMatcher.group(1).split(",")) {
                        String declared = normalizeVariableName(fieldName.trim());
                        if (!declared.isEmpty()) {
                            scopes.peek().add(declared);
                        }
                    }
                    continue;
                }

                // `for` header: register only the loop variable as known, and
                // check the range expression separately so a genuinely
                // undefined bound (`for i = [1:hi]:`) is still reported.
                Matcher forHeaderMatcher = FOR_HEADER_PATTERN.matcher(line);
                if (forHeaderMatcher.matches()) {
                    String loopVar = normalizeVariableName(forHeaderMatcher.group(1));
                    String rangeExpr = forHeaderMatcher.group(2);
                    if (!loopVar.isEmpty()) {
                        scopes.peek().add(loopVar);
                    }
                    lineErrors += countUndefinedIdentifiers(rangeExpr, scopes, lineNames);
                    continue;
                }

                // List of variables: `[a, b; c, d] = M`, `[u, ~] = v`. The
                // right side first, then every target is defined.
                if (TargetList.startsStatement(line)) {
                    int close = Lexis.matchingClose(line, Lexis.nextNonSpace(line, 0));
                    int equalsIndex = Lexis.nextNonSpace(line, close + 1);
                    lineErrors += countUndefinedIdentifiers(line.substring(equalsIndex + 1), scopes, lineNames);
                    lineErrors += defineTargets(TargetList.parse(line.substring(0, close + 1)), scopes, lineNames);
                    continue;
                }

                // Names in round brackets: `(z) = 4`, and the retired
                // `(sum1, prod1) = arithmetics(3, 4);`.
                Matcher roundTargetsMatcher = ROUND_TARGETS_PATTERN.matcher(line);
                if (roundTargetsMatcher.matches()) {
                    lineErrors += countUndefinedIdentifiers(roundTargetsMatcher.group(2), scopes, lineNames);
                    for (String outputName : roundTargetsMatcher.group(1).split(",")) {
                        String bound = normalizeVariableName(outputName.trim());
                        if (!bound.isEmpty()) {
                            scopes.peek().add(bound);
                        }
                    }
                    continue;
                }

                // The text is already masked, so an `=` inside a literal
                // (`publish("t=0-ran:", r0)`) cannot be mistaken for an
                // assignment.
                int equalsIndex = indexOfAssignment(line);
                if (equalsIndex >= 0) {
                    String leftSide = normalizeVariableName(line.substring(0, equalsIndex).trim());
                    String rightSide = line.substring(equalsIndex + 1).trim();

                    // Register the ROOT name, not the whole left-hand side:
                    // `A["name"] = ...`, `A[3][4] = ...` and `obj.field = ...`
                    // all define/modify `A`/`obj`. Registering the compound
                    // text instead left the real variable unknown, so a later
                    // `publish(A)` was reported as undefined.
                    String root = rootIdentifier(leftSide);
                    // `M ,= X` reads M before writing it: unlike '=', it never
                    // defines a new name.
                    if (extend != null && root != null && !root.isEmpty() && !isKnown(root, scopes)) {
                        out.add(sourceLine.index(), Rule.UNDEFINED_NAME,
                                String.format(EXTEND_UNDEFINED, extend.text(), Lexis.visible(root)));
                        lineErrors += countUndefinedIdentifiers(rightSide, scopes, lineNames);
                        continue;
                    }
                    if (root != null && !root.isEmpty()) {
                        scopes.peek().add(root);
                        // Index expressions on the left are real references:
                        // the `i` in `A[i] = 1` still has to be defined.
                        lineErrors += countUndefinedIdentifiers(leftSide.substring(root.length()), scopes, lineNames);
                    } else if (!leftSide.isEmpty()) {
                        scopes.peek().add(leftSide);
                    }

                    lineErrors += countUndefinedIdentifiers(rightSide, scopes, lineNames);
                } else {
                    lineErrors += countUndefinedIdentifiers(line, scopes, lineNames);
                }
            }
            if (anonymousScope != null) {
                scopes.removeLastOccurrence(anonymousScope);
            }

            if (lineErrors > 0) {
                out.add(sourceLine.index(), Rule.UNDEFINED_NAME,
                        message(displayableNames(lineNames, sourceLine.masked())));
            }
        }
    }

    /**
     * Defines every target of a list of variables in the innermost scope.
     * The index and field parts are references and are checked.
     *
     * @return how many undefined names the index parts hold
     */
    private static int defineTargets(TargetList.Parsed list, Deque<Set<String>> scopes, List<String> sink) {
        int errors = 0;
        for (TargetList.Target target : list.targets()) {
            if (target.kind() == TargetList.Kind.SKIP) {
                continue;
            }
            String root = normalizeVariableName(target.root());
            if (root != null && !root.isEmpty()) {
                scopes.peek().add(root);
            }
            if (target.kind() == TargetList.Kind.INDEXED) {
                errors += countUndefinedIdentifiers(target.suffix(), scopes, sink);
            }
        }
        return errors;
    }

    /** The input list of an anonymous function: the {@code x, y} of {@code @(x, y)}. */
    private static final Pattern ANONYMOUS_INPUTS_PATTERN = Pattern.compile("@\\s*\\(([^)]*)\\)");

    /** Every input name of every anonymous function in one statement. */
    private static Set<String> anonymousInputs(String statement) {
        Set<String> names = new HashSet<>();
        Matcher m = ANONYMOUS_INPUTS_PATTERN.matcher(statement);
        while (m.find()) {
            for (String part : m.group(1).split(",")) {
                String name = normalizeVariableName(part.trim());
                if (!name.isEmpty()) {
                    names.add(name);
                }
            }
        }
        return names;
    }

    /** "'x' is used before it is defined", or the plural form naming each. */
    static String message(List<String> names) {
        if (names == null || names.isEmpty()) {
            return UNDEFINED_UNNAMED;
        }
        if (names.size() == 1) {
            return String.format(UNDEFINED_ONE, names.get(0));
        }
        StringBuilder quoted = new StringBuilder();
        for (int k = 0; k < names.size(); k++) {
            if (k > 0) {
                quoted.append(k == names.size() - 1 ? " and " : ", ");
            }
            quoted.append('\'').append(names.get(k)).append('\'');
        }
        return String.format(UNDEFINED_MANY, quoted);
    }

    /**
     * Pre-pass for forward references: a function or class may be called before
     * the line that defines it, so every declared name is seeded into the
     * file-level scope up front.
     */
    private static void collectDeclaredNames(SourceModel model, Set<String> globalScope) {
        for (SourceModel.Line sourceLine : model.lines()) {
            if (sourceLine.isAbsorbed() || sourceLine.isBlank()) {
                continue;
            }
            String line = normalizeVariableNames(sourceLine.masked()).trim();
            if (line.isEmpty()) {
                continue;
            }

            Matcher classMatcher = CLASS_HEADER_PATTERN.matcher(line);
            if (classMatcher.matches()) {
                globalScope.add(normalizeVariableName(classMatcher.group(1)));
                continue;
            }

            Matcher functionMatcher = FUNCTION_HEADER_PATTERN.matcher(line);
            if (functionMatcher.matches()) {
                FunctionHeader header = parseFunctionHeader(line);
                if (header != null) {
                    globalScope.add(header.name);
                }
            }
        }
    }

    /**
     * Reads a `function` header line with {@link BlockHeaderGrammar}, the one
     * header reader: every shape ({@code [S, P] = name(a, b=1)},
     * {@code B = name(a)}, {@code name(a=1)}, a bare {@code name}, the
     * retired {@code (S, P) = name(a)}), defaults in any position, commas and
     * brackets inside a default. Returns null when not even a name can be
     * read; the caller still pushes an empty body scope then.
     *
     * @param line the whole masked header statement
     */
    private static FunctionHeader parseFunctionHeader(String line) {
        BlockHeaderGrammar.Header header = BlockHeaderGrammar.parse(line);
        if (header == null || header.kind() != BlockHeaderGrammar.Kind.FUNCTION || header.name() == null) {
            return null;
        }
        List<String> outputs = new ArrayList<>();
        List<String> parameters = new ArrayList<>();
        List<String> defaults = new ArrayList<>();
        addNames(header.outputs(), outputs);
        addNames(header.parameters(), parameters);
        if (header.signature() != null) {
            for (FunctionSignature.Input input : header.signature().inputs()) {
                if (input.hasDefault() && !input.defaultText().isBlank()) {
                    defaults.add(input.defaultText());
                }
            }
        }
        return new FunctionHeader(normalizeVariableName(header.name()), outputs, parameters, defaults);
    }

    private static void addNames(List<String> names, List<String> target) {
        for (String part : names) {
            String name = normalizeVariableName(part.trim());
            if (name != null && !name.isEmpty() && isPotentialIdentifier(name)) {
                target.add(name);
            }
        }
    }

    /**
     * The variable a left-hand side actually defines: the leading identifier,
     * with any index or field suffix dropped. {@code A["name"]}, {@code A[3][4]}
     * and {@code obj.field} all resolve to {@code A}/{@code obj}. Returns null
     * when the text does not start with an identifier.
     */
    private static String rootIdentifier(String text) {
        if (text == null || text.isEmpty()) {
            return null;
        }
        Matcher matcher = LEADING_IDENTIFIER_PATTERN.matcher(text);
        return matcher.find() ? matcher.group(1) : null;
    }

    /** True when {@code name} is defined in any open scope. */
    private static boolean isKnown(String name, Deque<Set<String>> scopes) {
        for (Set<String> scope : scopes) {
            if (scope.contains(name)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Keeps the names that appear verbatim in the source line, without
     * duplicates. The lookup ran on text whose styling markers were normalised,
     * and that internal form must never reach the user.
     */
    private static List<String> displayableNames(List<String> found, String maskedLine) {
        List<String> shown = new ArrayList<>();
        for (String name : found) {
            if (name != null && !name.isEmpty() && maskedLine.contains(name) && !shown.contains(name)) {
                shown.add(name);
            }
        }
        return Collections.unmodifiableList(shown);
    }

    private static int countUndefinedIdentifiers(String text, Deque<Set<String>> scopes, List<String> sink) {
        if (text == null || text.isEmpty()) {
            return 0;
        }

        // Number literals are blanked, so the 'i' of a complex literal
        // (D = 1+5i) is never read as the variable i. Names are read from the
        // text as written and a name is skipped only when its first character
        // was part of a number: reading them from the blanked text would cut
        // A_$1 to "A_$" wherever the blanking takes the digit after '$'.
        String plainText = normalizeVariableNames(text);
        String blanked = Lexis.blankNumbers(plainText);
        boolean aligned = blanked.length() == plainText.length();
        String sanitizedText = aligned ? plainText : blanked;
        int errors = 0;
        Matcher matcher = IDENTIFIER_PATTERN.matcher(sanitizedText);
        Set<String> seen = new HashSet<>();
        while (matcher.find()) {
            if (aligned && Character.isWhitespace(blanked.charAt(matcher.start()))
                    && !Character.isWhitespace(plainText.charAt(matcher.start()))) {
                continue; // the 'i' / 'j' / 'e' of a number literal
            }
            if (matcher.start() > 0 && (sanitizedText.charAt(matcher.start() - 1) == '@'
                    || sanitizedText.charAt(matcher.start() - 1) == '$')) {
                // @sin is a function reference, @rate(...) an annotation, and
                // $Sensor1$ / @Actuator1@ are live signals: none is a variable.
                // A '$' / '@' misplaced inside a name is reported, once, by
                // SubscriptSuperscriptAnalyzer.
                continue;
            }
            String identifier = matcher.group();
            // The name of a named value, f(x1 = 10): an input of the function
            // being called, not a variable. Its value is read as usual.
            if (isNamedValueName(sanitizedText, matcher.start(), matcher.end())) {
                continue;
            }
            if (KEYWORDS.contains(identifier) || BUILTIN_CONSTANTS.contains(identifier)
                    || isKnown(identifier, scopes) || seen.contains(identifier)) {
                continue;
            }
            if (isFunctionLike(sanitizedText, matcher.end())) {
                continue;
            }
            // A field name is not a variable: in `base.mean` or `a.value` only
            // the root (`base`, `a`) has to be defined. Without this, every
            // field read reported its field name as undefined.
            if (isFieldAccess(sanitizedText, matcher.start())) {
                continue;
            }

            seen.add(identifier);
            sink.add(identifier);
            errors++;
        }
        return errors;
    }

    /**
     * Splits one masked line into statements on {@code ;} at bracket depth
     * zero: the {@code ;} and {@code ;;} inside a matrix literal or a list of
     * variables separate its rows and blocks, not statements.
     */
    private static List<String> splitStatements(String line) {
        if (line == null || line.isEmpty()) {
            return Collections.singletonList("");
        }
        return Lexis.splitStatements(line);
    }

    /**
     * For each statement of the line ({@link Lexis#splitStatements} on the
     * masked text), its top-level extend operator, or null.
     */
    private static List<SourceModel.ExtendOperator> extendOperatorPerStatement(SourceModel.Line sourceLine) {
        List<SourceModel.ExtendOperator> perStatement = new ArrayList<>();
        if (sourceLine.extendOperators().isEmpty()) {
            return perStatement;
        }
        int start = 0;
        for (String statement : Lexis.splitStatements(sourceLine.masked())) {
            int end = start + statement.length();
            SourceModel.ExtendOperator found = null;
            for (SourceModel.ExtendOperator op : sourceLine.extendOperators()) {
                if (!op.nested() && op.offset() >= start && op.offset() < end) {
                    found = op;
                    break;
                }
            }
            perStatement.add(found);
            start = end + 1;
        }
        return perStatement;
    }

    private static boolean isFunctionLike(String text, int end) {
        int nextIndex = end;
        while (nextIndex < text.length() && Character.isWhitespace(text.charAt(nextIndex))) {
            nextIndex++;
        }
        return nextIndex < text.length() && text.charAt(nextIndex) == '(';
    }

    /**
     * True for the name of a named value: a name at the start of an argument
     * (right after {@code (} or {@code ,}) followed by a single {@code =}.
     * {@code f(x == 1)} is a comparison, not a name.
     */
    private static boolean isNamedValueName(String text, int start, int end) {
        int before = Lexis.prevNonSpace(text, start - 1);
        if (before < 0 || (text.charAt(before) != '(' && text.charAt(before) != ',')) {
            return false;
        }
        int after = Lexis.nextNonSpace(text, end);
        return after < text.length() && text.charAt(after) == '='
                && (after + 1 >= text.length() || text.charAt(after + 1) != '=');
    }

    /** True when the identifier starting at {@code start} is preceded by a `.`, i.e. it is a field name. */
    private static boolean isFieldAccess(String text, int start) {
        int previousIndex = start - 1;
        while (previousIndex >= 0 && Character.isWhitespace(text.charAt(previousIndex))) {
            previousIndex--;
        }
        return previousIndex >= 0 && text.charAt(previousIndex) == '.';
    }

    private static boolean isPotentialIdentifier(String text) {
        return text != null && IDENTIFIER_PATTERN.matcher(text).matches() && !KEYWORDS.contains(text);
    }

    private static String normalizeVariableNames(String text) {
        return LanguageDesignManager.normalizeMarkersForVariables(text);
    }

    private static String normalizeVariableName(String text) {
        if (text == null || text.isEmpty()) {
            return text;
        }
        return normalizeVariableNames(text).trim();
    }

    // The statement's assignment '=': the first one at bracket depth zero
    // that is not part of '==', '<=', '>=' or '!='. Depth matters since named
    // values arrived: in `F(A2=10, 1)` the '=' belongs to the call, and the
    // statement assigns nothing (the old scan read "F(A2" as a left side).
    private static int indexOfAssignment(String line) {
        return Lexis.assignmentIndex(line);
    }
}
