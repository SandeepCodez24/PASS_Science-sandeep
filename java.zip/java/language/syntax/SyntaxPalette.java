package language.syntax;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import language.semantic.ScriptedName;
import language.syntax.textcolours.BinaryOperators;
import language.syntax.textcolours.ConstantWords;
import language.syntax.textcolours.ConversionOperators;
import language.syntax.textcolours.DataIoFunctions;
import language.syntax.textcolours.FunctionClassKeywords;
import language.syntax.textcolours.LogicalOperators;
import language.syntax.textcolours.LoopKeywords;
import language.syntax.textcolours.OtherKeywords;
import language.syntax.textcolours.PrimitiveOperators;
import language.syntax.textcolours.TextCategory;
import language.syntax.textcolours.library.FunctionLibraries;
import ui.ui_functions.FunctionProvider;

/**
 * The main file of the text colour scheme: it reads every word file in
 * {@code language/syntax/textcolours/} and turns them into the patterns
 * {@link UPITokenMaker} uses.
 *
 * <h3>Where things live</h3>
 *
 * <pre>
 *   WHICH words are in a category   language/syntax/textcolours/*.java
 *                                   (one file per category, plain arrays)
 *   WHICH library functions exist   language/syntax/textcolours/library/*.java
 *   WHICH built-in functions exist  ui/ui_functions/suggestions_list/*_list.java
 *                                   (through FunctionProvider)
 *   WHAT colour a category is       src/main/resources/themes/texts/
 *                                       text_light.css   text_dark.css
 *   HOW words become patterns       this file  (normally never edited)
 * </pre>
 *
 * <h3>One word, one colour</h3>
 * <p>
 * A word claimed by a category file is removed from the built-in function
 * set, so {@code sqrt} (registered as a function for the suggestion box) is
 * painted as a primitive and {@code if} as a loop word. Category files
 * therefore always win over the function lists.
 * </p>
 *
 * <h3>Called words</h3>
 * <p>
 * Function names, data conversion words and word primitives are coloured
 * only where they are called, with {@code (} straight after the name. A
 * variable named {@code norm} or {@code string} keeps the variable colour.
 * To also accept a space before the bracket, change {@link #CALL} to
 * {@code "(?=\\s*\\()"}.
 * </p>
 *
 * <p>
 * <b>Package note.</b> This makes {@code language.syntax} depend on
 * {@code ui.ui_functions}, on purpose: touching {@code FunctionProvider}
 * runs its static block first, so the registry is always complete before the
 * first pattern is built.
 * </p>
 */
public final class SyntaxPalette {

    private SyntaxPalette() {
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CSS classes (one per TextCategory; must match themes/texts/*.css)
    // ─────────────────────────────────────────────────────────────────────────

    public static final String STYLE_VARIABLE = TextCategory.VARIABLE.styleClass();
    public static final String STYLE_NUMBER = TextCategory.NUMBER.styleClass();
    public static final String STYLE_STRING = TextCategory.STRING.styleClass();
    public static final String STYLE_PRIMITIVE = TextCategory.PRIMITIVE.styleClass();
    public static final String STYLE_BINARY = TextCategory.BINARY.styleClass();
    public static final String STYLE_LOGICAL = TextCategory.LOGICAL.styleClass();
    public static final String STYLE_CONVERSION = TextCategory.CONVERSION.styleClass();
    public static final String STYLE_LOOP = TextCategory.LOOP.styleClass();
    public static final String STYLE_FUNCTION_CLASS = TextCategory.FUNCTION_CLASS.styleClass();
    public static final String STYLE_OTHER = TextCategory.OTHER.styleClass();
    public static final String STYLE_FUNCTION_CALL = TextCategory.FUNCTION_CALL.styleClass();
    public static final String STYLE_DATA_IO = TextCategory.DATA_IO.styleClass();
    public static final String STYLE_COMMENT = TextCategory.COMMENT.styleClass();

    /** @deprecated use {@link #STYLE_VARIABLE}. */
    @Deprecated
    public static final String STYLE_IDENTIFIER = STYLE_VARIABLE;
    /** @deprecated use {@link #STYLE_LOOP}. */
    @Deprecated
    public static final String STYLE_CONDITIONAL = STYLE_LOOP;
    /** @deprecated use {@link #STYLE_FUNCTION_CALL}. */
    @Deprecated
    public static final String STYLE_BUILTIN = STYLE_FUNCTION_CALL;

    /** "Followed by an opening bracket": the called-word rule. */
    public static final String CALL = "(?=\\()";

    /**
     * Matches nothing. An empty alternation would match the empty string at
     * every word boundary and wreck the highlighting, so an empty list must
     * become this instead.
     */
    private static final String NEVER_MATCHES = "(?!)";

    // ─────────────────────────────────────────────────────────────────────────
    // Patterns, one per tokenizer group
    // ─────────────────────────────────────────────────────────────────────────

    /** {@code if not}, {@code while not}, then {@code if}, {@code for}, ... {@code wend}. */
    public static String loopPattern() {
        List<String> parts = new ArrayList<>();
        for (String phrase : LoopKeywords.PHRASES) {
            parts.add(String.join("\\s+", Arrays.stream(phrase.trim().split("\\s+"))
                    .map(Pattern::quote).toList()));
        }
        // Phrases first, then single words, each group longest first.
        parts.sort(Comparator.comparingInt(String::length).reversed());
        List<String> words = sortedLongestFirst(LoopKeywords.WORDS);
        for (String w : words) {
            parts.add(Pattern.quote(w));
        }
        return parts.isEmpty() ? NEVER_MATCHES : "\\b(?:" + String.join("|", parts) + ")\\b";
    }

    /** {@code function class fnend csend private protected abstract}. */
    public static String functionClassPattern() {
        return wordPattern(concat(FunctionClassKeywords.WORDS, FunctionClassKeywords.MODIFIERS), false);
    }

    /** {@code break continue pass return}. */
    public static String otherPattern() {
        return wordPattern(OtherKeywords.WORDS, false);
    }

    /** {@code in is_in is_not_in is_nan is_empty not}. */
    public static String logicalWordPattern() {
        return wordPattern(LogicalOperators.WORDS, false);
    }

    /** {@code publish clear cls}. */
    public static String binaryWordPattern() {
        return wordPattern(BinaryOperators.WORDS, false);
    }

    /** {@code int( float( string( dec2rad( rad2dec( abs(}. */
    public static String conversionPattern() {
        return wordPattern(ConversionOperators.WORDS, true);
    }

    /** {@code logbX(}: "logb", any base, then {@code (}. */
    public static String logBasePattern() {
        return "\\b" + Pattern.quote(PrimitiveOperators.LOG_BASE_PREFIX) + "[\\p{L}\\p{N}_.]*" + CALL;
    }

    /** {@code e^} as one token. */
    public static String exponentPattern() {
        return "\\b" + Pattern.quote(PrimitiveOperators.EXPONENT_PREFIX);
    }

    /** {@code sqr( sqrt( cube( cbrt( log(}. */
    public static String primitiveWordPattern() {
        return wordPattern(PrimitiveOperators.CALLED_WORDS, true);
    }

    /** {@code true false null}. */
    public static String primitiveValuePattern() {
        return wordPattern(PrimitiveOperators.VALUES, false);
    }

    /**
     * {@code base} and {@code info} straight after a dot ({@code Shape.base},
     * {@code obj.info}): built in, so they take the function-call colour even
     * with no {@code (} after them -- the one exception to the called-word
     * rule. {@code base} on its own (the object inside a class) is a name.
     */
    public static String introspectionPattern() {
        return "(?<=\\.)(?:base|info)(?![\\p{L}\\p{M}\\p{N}_$@])";
    }

    /** {@code read_csv( load_json( save_png( io_preview(} ... ({@link DataIoFunctions}). */
    public static String dataIoPattern() {
        return wordPattern(DataIoFunctions.names().toArray(String[]::new), true);
    }

    /** Every registered or library function name, where called. */
    public static String builtinFunctionPattern() {
        Set<String> names = builtinFunctionNames();
        return names.isEmpty() ? NEVER_MATCHES
                : wordPattern(names.toArray(String[]::new), true);
    }

    /** {@code == != <= >= < >}. */
    public static String binarySymbolPattern() {
        return symbolPattern(BinaryOperators.SYMBOLS);
    }

    /** {@code && || !& !|}. */
    public static String logicalSymbolPattern() {
        return symbolPattern(LogicalOperators.SYMBOLS);
    }

    /** The single absolute-value bar. */
    public static String absoluteBarPattern() {
        return Pattern.quote(PrimitiveOperators.ABSOLUTE_BAR);
    }

    /** {@code // + - * / ^ % !}, and the transpose {@code '} directly after a value. */
    public static String primitiveSymbolPattern() {
        return symbolPattern(PrimitiveOperators.SYMBOLS) + "|(?<=" + AFTER_VALUE + ")'";
    }

    /**
     * Integers, decimals and scientific numbers: {@code 42}, {@code 3.14},
     * {@code .5}, {@code 6.02e23}, {@code 1E-3}, and imaginary numbers with
     * their {@code i}: {@code 5i}, {@code 2.5i}, {@code 1e-3i}. Digits inside a
     * name ({@code p10count}, {@code x2}) are part of the name, not a number,
     * and {@code 5in} / {@code 5i2} are not complex.
     */
    public static String numberPattern() {
        // Not after '$' / '@' either: the 1 of A_$1 belongs to the name.
        return "(?<![\\p{L}\\p{M}\\p{N}_.$@\\u200C\\u200D])"
                + "(?:\\d+(?:\\.\\d*)?|\\.\\d+)(?:[eE][+-]?\\d+)?i?"
                + "(?![\\p{L}\\p{N}_])";
    }

    /**
     * What a transpose {@code '} stands directly after: {@code A'},
     * {@code (A*B)'}, {@code A[0]'}, {@code 5!'}, {@code A''}. The same rule as
     * {@code CodeSegments.isTranspose}, as far as one character can tell.
     */
    private static final String AFTER_VALUE = "[\\p{L}\\p{M}\\p{N}_)\\]}!']";

    /**
     * {@code "..."} (may span lines, as docstrings do) or {@code '...'} (one
     * line). A {@code '} directly after a value is a transpose, so it opens
     * nothing: the two in {@code C' + D'} do not read as a string.
     */
    public static String stringPattern() {
        return "\"(?:[^\"\\\\]|\\\\.)*\"|(?<!" + AFTER_VALUE + ")'(?:[^'\\\\\\n]|\\\\.)*'";
    }

    /** {@code # ...} and {@code \\ ...} to the end of the line. */
    public static String commentPattern() {
        return "#[^\\n]*|\\\\\\\\[^\\n]*";
    }

    /** A name in any supported script. */
    public static String identifierPattern() {
        return "(?<![\\p{L}\\p{M}\\p{N}_])[\\p{L}_][\\p{L}\\p{M}\\p{N}_]*";
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Function names
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Built-in and library function names, minus every word a category file
     * claims.
     *
     * @return the names painted in the function-call colour where called
     */
    public static Set<String> builtinFunctionNames() {
        Set<String> names = new LinkedHashSet<>(FunctionProvider.getDefaultFunctionNames());
        names.addAll(FunctionLibraries.names());
        names.removeAll(claimedWords());
        names.removeIf(n -> n == null || !n.matches("[\\p{L}_][\\p{L}\\p{M}\\p{N}_]*"));
        return names;
    }

    /** @return every word some category file claims */
    public static Set<String> claimedWords() {
        Set<String> words = new LinkedHashSet<>();
        for (String phrase : LoopKeywords.PHRASES) {
            words.addAll(Arrays.asList(phrase.trim().split("\\s+")));
        }
        words.addAll(Arrays.asList(LoopKeywords.WORDS));
        words.addAll(Arrays.asList(FunctionClassKeywords.WORDS));
        words.addAll(Arrays.asList(FunctionClassKeywords.MODIFIERS));
        words.addAll(Arrays.asList(OtherKeywords.WORDS));
        words.addAll(Arrays.asList(LogicalOperators.WORDS));
        words.addAll(Arrays.asList(BinaryOperators.WORDS));
        words.addAll(Arrays.asList(ConversionOperators.WORDS));
        words.addAll(Arrays.asList(PrimitiveOperators.CALLED_WORDS));
        words.addAll(Arrays.asList(PrimitiveOperators.VALUES));
        return words;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // User functions and classes — read from the document, not configured
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * A function header at the start of a line, any shape. Group 1 is the
     * name, which may carry a subscript / superscript ({@code f_$a}).
     */
    private static final Pattern USER_FUNCTION_HEADER = Pattern.compile(
            "(?m)^[ \\t]*(?:(?:private|protected|abstract)\\s+)*function\\s+"
                    + "(?:(?:\\[[^\\]\\n]*\\]|" + ScriptedName.NAME_REGEX + ")\\s*=\\s*)?"
                    + "(" + ScriptedName.NAME_REGEX + ")\\s*\\(");

    /** {@code class Name(args):}. Group 1 is the name. */
    private static final Pattern USER_CLASS_HEADER = Pattern.compile(
            "(?m)^[ \\t]*class\\s+(" + ScriptedName.NAME_REGEX + ")\\s*\\(");

    private static final Object USER_LOCK = new Object();
    private static String cachedSource;
    private static Set<String> cachedNames = Set.of();

    /**
     * Names of the functions and classes defined in {@code text}. Painted in
     * the function-call colour where they are called (and on their own
     * header, which is a call shape too). The result for the latest text is
     * cached.
     *
     * @param text the whole document being highlighted
     * @return the names; never null
     */
    public static Set<String> userFunctionNames(String text) {
        if (text == null || text.isEmpty()
                || (!text.contains("function") && !text.contains("class"))) {
            return Set.of();
        }
        synchronized (USER_LOCK) {
            if (text.equals(cachedSource)) {
                return cachedNames;
            }
        }
        Set<String> names = new LinkedHashSet<>();
        Matcher f = USER_FUNCTION_HEADER.matcher(text);
        while (f.find()) {
            names.add(f.group(1));
        }
        Matcher c = USER_CLASS_HEADER.matcher(text);
        while (c.find()) {
            names.add(c.group(1));
        }
        Set<String> result = Set.copyOf(names);
        synchronized (USER_LOCK) {
            cachedSource = text;
            cachedNames = result;
        }
        return result;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Constants
    // ─────────────────────────────────────────────────────────────────────────

    /** The named constants nc.exe knows ({@link ConstantWords}). */
    public static final Set<String> CONSTANTS = Set.of(ConstantWords.WORDS);

    /** {@code name =} (not {@code ==}): an assignment, or a named value in a call. */
    private static final Pattern ASSIGNED_NAME = Pattern.compile(
            "(?<![\\p{L}\\p{M}\\p{N}_$@.])([\\p{L}_][\\p{L}\\p{M}\\p{N}_]*)\\s*=(?!=)");

    /** {@code for name in ...}. */
    private static final Pattern FOR_IN_NAME = Pattern.compile(
            "\\bfor\\s+([\\p{L}_][\\p{L}\\p{M}\\p{N}_]*)\\s+in\\b");

    /** A function header line (its inputs and outputs are the function's variables). */
    private static final Pattern FUNCTION_HEADER_LINE = Pattern.compile(
            "(?m)^[ \\t]*(?:(?:private|protected|abstract)\\s+)*function\\b[^\\n]*");

    /** {@code [a, b] =}: a list of variables. */
    private static final Pattern TARGET_LIST = Pattern.compile("\\[([^\\]\\n]*)\\]\\s*=(?!=)");

    private static final Pattern NAME_IN_TEXT = Pattern.compile("[\\p{L}_][\\p{L}\\p{M}\\p{N}_]*");

    private static final Object ASSIGNED_LOCK = new Object();
    private static String assignedSource;
    private static Set<String> assignedResult = Set.of();

    /**
     * The constants ({@link #CONSTANTS}) that {@code text} uses as variables:
     * assigned ({@code e = 5}), a loop variable, an input or output of a
     * function, a name in a list of variables. Such a name takes the variable
     * colour in the whole file, not the constant colour. Strings and comments
     * are not told apart here - a constant named in one only loses its colour,
     * never gains a wrong one. The result for the latest text is cached.
     *
     * @param text the whole document being highlighted
     * @return the constant names used as variables; never null
     */
    public static Set<String> assignedConstants(String text) {
        if (text == null || text.isEmpty()) {
            return Set.of();
        }
        synchronized (ASSIGNED_LOCK) {
            if (text.equals(assignedSource)) {
                return assignedResult;
            }
        }
        Set<String> names = new LinkedHashSet<>();
        Matcher m = ASSIGNED_NAME.matcher(text);
        while (m.find()) {
            names.add(m.group(1));
        }
        m = FOR_IN_NAME.matcher(text);
        while (m.find()) {
            names.add(m.group(1));
        }
        for (Pattern whole : new Pattern[] { FUNCTION_HEADER_LINE, TARGET_LIST }) {
            Matcher w = whole.matcher(text);
            while (w.find()) {
                Matcher n = NAME_IN_TEXT.matcher(w.group());
                while (n.find()) {
                    names.add(n.group());
                }
            }
        }
        names.retainAll(CONSTANTS);
        Set<String> result = Set.copyOf(names);
        synchronized (ASSIGNED_LOCK) {
            assignedSource = text;
            assignedResult = result;
        }
        return result;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Kept for older callers
    // ─────────────────────────────────────────────────────────────────────────

    /** @deprecated the words are now split by category; see the textcolours folder. */
    @Deprecated
    public static final String[] CONDITIONAL_KEYWORDS = concat(LoopKeywords.WORDS,
            concat(FunctionClassKeywords.WORDS, OtherKeywords.WORDS));

    /** @deprecated see {@link PrimitiveOperators#CALLED_WORDS}. */
    @Deprecated
    public static final String[] PRIMITIVE_WORDS = PrimitiveOperators.CALLED_WORDS.clone();

    /** @deprecated see {@link PrimitiveOperators#SYMBOLS}. */
    @Deprecated
    public static final String[] PRIMITIVE_SYMBOLS = PrimitiveOperators.SYMBOLS.clone();

    /** @deprecated use {@link #loopPattern()}. */
    @Deprecated
    public static String conditionalPattern() {
        return loopPattern();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Helpers
    // ─────────────────────────────────────────────────────────────────────────

    private static String wordPattern(String[] words, boolean called) {
        List<String> sorted = sortedLongestFirst(words);
        if (sorted.isEmpty()) {
            return NEVER_MATCHES;
        }
        List<String> quoted = sorted.stream().map(Pattern::quote).toList();
        return "\\b(?:" + String.join("|", quoted) + ")\\b" + (called ? CALL : "");
    }

    private static String symbolPattern(String[] symbols) {
        List<String> sorted = sortedLongestFirst(symbols);
        if (sorted.isEmpty()) {
            return NEVER_MATCHES;
        }
        return "(?:" + String.join("|", sorted.stream().map(Pattern::quote).toList()) + ")";
    }

    private static List<String> sortedLongestFirst(String[] items) {
        List<String> out = new ArrayList<>();
        for (String s : items) {
            if (s != null && !s.isBlank() && !out.contains(s.trim())) {
                out.add(s.trim());
            }
        }
        out.sort(Comparator.comparingInt(String::length).reversed());
        return out;
    }

    private static String[] concat(String[] a, String[] b) {
        String[] out = Arrays.copyOf(a, a.length + b.length);
        System.arraycopy(b, 0, out, a.length, b.length);
        return out;
    }
}
