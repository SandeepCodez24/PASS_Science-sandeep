package language.syntax;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import ui.ui_functions.FunctionProvider;

/**
 * Central, single-place configuration for the editor's syntax colour scheme.
 *
 * <p>
 * This file exists so the colour/keyword scheme can be changed later
 * <b>without touching the tokenizer</b> ({@link UPITokenMaker}). To recolour or
 * reclassify the language you only edit two things:
 * <ol>
 * <li><b>Which words belong to which class</b> — the arrays below
 * ({@link #CONDITIONAL_KEYWORDS}, {@link #PRIMITIVE_WORDS},
 * {@link #PRIMITIVE_SYMBOLS}).</li>
 * <li><b>What colour each class paints</b> — the matching CSS style classes in
 * {@code src/main/resources/themes/editorColor/editor_light.css} and its dark
 * twin {@code editor_dark.css}
 * ({@code .conditional}, {@code .primitive}, {@code .identifier},
 * {@code .builtin-function}).</li>
 * </ol>
 *
 * <p>
 * The token → CSS-style-class names are also kept here as constants so both the
 * tokenizer and the stylesheet stay in agreement.
 *
 * <h3>Built-in functions (dark orchid)</h3>
 * There is deliberately <b>no list of built-in function names in this file</b>.
 * They are read live from {@link FunctionProvider}, which is already the one
 * place the ten {@code ui.ui_functions.suggestions_list.*_list.java} files
 * register into. Adding {@code fourier_list.java} (plus its single
 * {@code register()} line in {@code FunctionProvider.initializeFunctions()}) is
 * therefore the whole job — the editor colours the new names with no edit here
 * and none in the CSS.
 *
 * <p>
 * <b>Package note.</b> This makes {@code language.syntax} depend on
 * {@code ui.ui_functions}. That is a deliberate trade: the alternative, a
 * registration hook the UI calls at startup, buys looser coupling at the cost
 * of a lazily-built pattern and an initialisation order that can silently go
 * wrong. A direct call cannot: touching {@code FunctionProvider} runs its
 * static block first, so the registry is always complete before the first
 * pattern is built.
 */
public final class SyntaxPalette {

    private SyntaxPalette() {
        // Config holder – no instances.
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CSS style-class names (must match the selectors in editor_light.css /
    // editor_dark.css)
    // ─────────────────────────────────────────────────────────────────────────
    /** Ordinary letters / identifiers → black (light) / near-white (dark). */
    public static final String STYLE_IDENTIFIER = "identifier";
    /** Declaration / control-flow words (for, fend, if, while …) → dark sky blue. */
    public static final String STYLE_CONDITIONAL = "conditional";
    /** Math primitives (+, -, frac, deci …) → crimson. */
    public static final String STYLE_PRIMITIVE = "primitive";
    /** Registered built-in functions (sqrt, det, transpose …) → dark orchid. */
    public static final String STYLE_BUILTIN = "builtin-function";

    /**
     * A pattern that can never match anything, used in place of an empty
     * alternation.
     *
     * <p>
     * This matters more than it looks. {@code "\\b(" + "" + ")\\b"} is a valid
     * regex that matches the empty string at every word boundary in the file,
     * which would hand a zero-width span to every character in the document and
     * destroy the highlighting. An empty group list must therefore become a
     * pattern that matches nothing at all, not a pattern that matches
     * everything.
     */
    private static final String NEVER_MATCHES = "(?!)";

    // ─────────────────────────────────────────────────────────────────────────
    // CONDITIONAL OPERATORS / DECLARATION KEYWORDS  →  dark sky blue
    // Add or remove words here to change what is highlighted as control flow.
    // NOTE: every loop/block opener AND its closer lives here, so a `for … fend`
    // block colours BOTH `for` and `fend` (this fixes the "only for is coloured"
    // problem).
    // ─────────────────────────────────────────────────────────────────────────
    public static final String[] CONDITIONAL_KEYWORDS = {
            "print", "let",
            "if", "else", "elseif", "elif", "for", "while",
            "return", "break", "continue",
            "true", "false", "null",
            "or", "not", "is_in", "is_not_in",
            "new", "clear",
            "iend", "wend", "fend",
            "function", "class", "fnend", "csend"
    };

    // ─────────────────────────────────────────────────────────────────────────
    // PRIMITIVES  →  crimson
    // Word-form primitives (matched as whole words) …
    //
    // Keep ONLY words that are not registered built-in functions. Anything in
    // this array that FunctionProvider also registers is filtered out at
    // pattern-build time (see primitiveWordPattern) so it paints dark orchid
    // instead of crimson — sqrt, cbrt, sqr, cube and log all fall out that way,
    // automatically, without this array having to be edited when a category
    // file changes.
    // ─────────────────────────────────────────────────────────────────────────
    public static final String[] PRIMITIVE_WORDS = {
            "sqrt", "cbrt", "sqr", "cube",
            "log", "logb_n",
            "frac2", "frac", "deci2", "deci"
    };

    // … and symbol-form primitives (matched literally). Multi-char symbols such
    // as `//` MUST be listed before their single-char prefix `/`.
    public static final String[] PRIMITIVE_SYMBOLS = {
            "//", "+", "-", "*", "/", "^", "!", "%"
    };

    // ─────────────────────────────────────────────────────────────────────────
    // Regex builders (used by UPITokenMaker) — you normally don't edit these.
    // ─────────────────────────────────────────────────────────────────────────

    /** {@code \b(word1|word2|…)\b} for the conditional keyword list. */
    public static String conditionalPattern() {
        return "\\b(" + String.join("|", CONDITIONAL_KEYWORDS) + ")\\b";
    }

    /**
     * Every registered built-in function name, longest first.
     *
     * @return the names {@link FunctionProvider} currently holds
     */
    public static Set<String> builtinFunctionNames() {
        Set<String> names = new LinkedHashSet<>(FunctionProvider.getDefaultFunctionNames());
        return names;
    }

    /**
     * {@code \b(name1|name2|…)\b(?=\()} for the registered built-in functions.
     *
     * <p>
     * The trailing lookahead is the whole point: a name only paints as a
     * built-in where it is actually being <i>called</i>. A variable the user
     * happens to name {@code norm}, or the word {@code rank} inside a comment,
     * keeps its ordinary colour. The lookahead is zero-width, so the opening
     * bracket itself is left for the primitive-symbol rule as before.
     *
     * <p>
     * If a space between the name and the bracket should also count, change
     * {@code "\\b(?=\\()"} below to {@code "\\b(?=\\s*\\()"} — that is the only
     * edit needed.
     */
    public static String builtinFunctionPattern() {
        Set<String> names = builtinFunctionNames();
        if (names.isEmpty()) {
            return NEVER_MATCHES;
        }

        List<String> sorted = new ArrayList<>(names);
        // Longest first, so `pseudo_inverse` is tried before any shorter name
        // that shares its opening. The word boundaries make this belt-and-braces
        // rather than strictly necessary, but alternation is first-match-wins
        // and the cost here is one sort at startup.
        sorted.sort(Comparator.comparingInt(String::length).reversed());

        return "\\b(?:" + String.join("|", sorted) + ")\\b(?=\\()";
    }

    /**
     * {@code \b(word1|word2|…)\b} for word-form primitives, longest first so
     * e.g. {@code frac2} wins over {@code frac}.
     *
     * <p>
     * Any word that {@link FunctionProvider} registers as a function is removed
     * first, so a name can never belong to two colour classes. This is what
     * keeps crimson meaning "language primitive" and dark orchid meaning
     * "built-in function", with the boundary between them redrawn automatically
     * whenever a category file changes.
     */
    public static String primitiveWordPattern() {
        Set<String> builtins = builtinFunctionNames();

        List<String> words = new ArrayList<>();
        for (String word : PRIMITIVE_WORDS) {
            if (!builtins.contains(word)) {
                words.add(word);
            }
        }
        if (words.isEmpty()) {
            return NEVER_MATCHES;
        }

        words.sort(Comparator.comparingInt(String::length).reversed());
        return "\\b(" + String.join("|", words) + ")\\b";
    }

    /**
     * Alternation of the symbol-form primitives, each Regex-escaped and ordered
     * longest first (so {@code //} is tried before {@code /}).
     */
    public static String primitiveSymbolPattern() {
        String[] sorted = PRIMITIVE_SYMBOLS.clone();
        Arrays.sort(sorted, Comparator.comparingInt(String::length).reversed());
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < sorted.length; i++) {
            if (i > 0) {
                sb.append('|');
            }
            sb.append(java.util.regex.Pattern.quote(sorted[i]));
        }
        return "(?:" + sb + ")";
    }
}
