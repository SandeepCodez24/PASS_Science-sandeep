package language.syntax;

import java.util.Arrays;
import java.util.Comparator;

/**
 * Central, single-place configuration for the editor's syntax colour scheme.
 *
 * <p>
 * This file exists so the colour/keyword scheme can be changed later
 * <b>without touching the tokenizer</b> ({@link UPITokenMaker}). To recolour or
 * reclassify the language you only edit two things:
 * <ol>
 * <li><b>Which words belong to which class</b> — the arrays below
 * ({@link #CONDITIONAL_KEYWORDS}, {@link #PRIMITIVE_WORDS},
 * {@link #PRIMITIVE_SYMBOLS}).</li>
 * <li><b>What colour each class paints</b> — the matching CSS style classes in
 * {@code src/main/resources/language_design/syntax.css}
 * ({@code .conditional}, {@code .primitive}, {@code .identifier}).</li>
 * </ol>
 *
 * <p>
 * The token → CSS-style-class names are also kept here as constants so both the
 * tokenizer and the stylesheet stay in agreement.
 */
public final class SyntaxPalette {

    private SyntaxPalette() {
        // Config holder – no instances.
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CSS style-class names (must match the selectors in syntax.css)
    // ─────────────────────────────────────────────────────────────────────────
    /** Ordinary letters / identifiers → black. */
    public static final String STYLE_IDENTIFIER = "identifier";
    /** Declaration / control-flow words (for, fend, if, while …) → dark sky blue. */
    public static final String STYLE_CONDITIONAL = "conditional";
    /** Math primitives (+, -, sqrt, log …) → crimson. */
    public static final String STYLE_PRIMITIVE = "primitive";

    // ─────────────────────────────────────────────────────────────────────────
    // CONDITIONAL OPERATORS / DECLARATION KEYWORDS  →  dark sky blue
    // Add or remove words here to change what is highlighted as control flow.
    // NOTE: every loop/block opener AND its closer lives here, so a `for … fend`
    // block colours BOTH `for` and `fend` (this fixes the "only for is coloured"
    // problem).
    // ─────────────────────────────────────────────────────────────────────────
    public static final String[] CONDITIONAL_KEYWORDS = {
            "print", "let",
            "if", "else", "elseif", "elif", "for", "while",
            "return", "break", "continue",
            "true", "false", "null",
            "or", "not", "is_in", "is_not_in",
            "new", "clear",
            "iend", "wend", "fend",
            "function", "class", "fnend", "csend"
    };

    // ─────────────────────────────────────────────────────────────────────────
    // PRIMITIVES  →  crimson
    // Word-form primitives (matched as whole words) …
    // ─────────────────────────────────────────────────────────────────────────
    public static final String[] PRIMITIVE_WORDS = {
            "sqrt", "cbrt", "sqr", "cube",
            "log", "logb_n",
            "frac2", "frac", "deci2", "deci"
    };

    // … and symbol-form primitives (matched literally). Multi-char symbols such
    // as `//` MUST be listed before their single-char prefix `/`.
    public static final String[] PRIMITIVE_SYMBOLS = {
            "//", "+", "-", "*", "/", "^", "!", "%"
    };

    // ─────────────────────────────────────────────────────────────────────────
    // Regex builders (used by UPITokenMaker) — you normally don't edit these.
    // ─────────────────────────────────────────────────────────────────────────

    /** {@code \b(word1|word2|…)\b} for the conditional keyword list. */
    public static String conditionalPattern() {
        return "\\b(" + String.join("|", CONDITIONAL_KEYWORDS) + ")\\b";
    }

    /**
     * {@code \b(word1|word2|…)\b} for word-form primitives, longest first so
     * e.g. {@code sqrt} wins over {@code sqr} and {@code frac2} over {@code frac}.
     */
    public static String primitiveWordPattern() {
        String[] sorted = PRIMITIVE_WORDS.clone();
        Arrays.sort(sorted, Comparator.comparingInt(String::length).reversed());
        return "\\b(" + String.join("|", sorted) + ")\\b";
    }

    /**
     * Alternation of the symbol-form primitives, each Regex-escaped and ordered
     * longest first (so {@code //} is tried before {@code /}).
     */
    public static String primitiveSymbolPattern() {
        String[] sorted = PRIMITIVE_SYMBOLS.clone();
        Arrays.sort(sorted, Comparator.comparingInt(String::length).reversed());
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < sorted.length; i++) {
            if (i > 0) {
                sb.append('|');
            }
            sb.append(java.util.regex.Pattern.quote(sorted[i]));
        }
        return "(?:" + sb + ")";
    }
}
