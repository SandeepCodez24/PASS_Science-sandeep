package language.syntax;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.fxmisc.richtext.model.StyleSpans;
import org.fxmisc.richtext.model.StyleSpansBuilder;

public class UPITokenMaker {

    // ── Token classes are configured centrally in SyntaxPalette ──────────────
    // Conditional / declaration keywords (for, fend, if, while …) → dark sky blue
    private static final String CONDITIONAL_PATTERN = SyntaxPalette.conditionalPattern();
    // Registered built-in functions (sqrt, det, transpose …) → dark orchid.
    // Built once at class load; touching SyntaxPalette runs FunctionProvider's
    // static initializer first, so every category file has registered before the
    // pattern is assembled.
    private static final String BUILTIN_PATTERN = SyntaxPalette.builtinFunctionPattern();
    // Word-form primitives (frac, deci …) → crimson
    private static final String PRIMITIVE_WORD_PATTERN = SyntaxPalette.primitiveWordPattern();
    // Symbol-form primitives (+, -, *, /, //, ^, !, %) → crimson
    private static final String PRIMITIVE_SYMBOL_PATTERN = SyntaxPalette.primitiveSymbolPattern();

    private static final String COMMENT_PATTERN = "(?:#[^\n]*|\\\\\\\\[^\n]*)";

    private static final String STRING_PATTERN = "\"([^\"\\\\]|\\\\.)*\"";
    private static final String NUMBER_PATTERN = "\\b\\d+\\b";
    private static final String SUBSCRIPT_SINGLE_PATTERN = "\u200D[^\u200D\n]\u200D"; // Single subscript character
                                                                                      // except marker/newline
    private static final String SUBSCRIPT_SINGLE_GREEK_PATTERN = "\u200D[\u0370-\u03FF\u0B80-\u0BFF]\u200D"; // Single
                                                                                                             // Greek/Tamil
                                                                                                             // subscript
                                                                                                             // letter
    private static final String SUBSCRIPT_MULTI_PATTERN = "\u200D\u200D\u200D[^\u200D\n]+\u200D\u200D\u200D"; // Multiple
                                                                                                              // subscript
                                                                                                              // characters
                                                                                                              // except
                                                                                                              // marker/newline
    private static final String SUBSCRIPT_MULTI_GREEK_PATTERN = "\u200D\u200D\u200D(?=[^\u200D]*[\u0370-\u03FF\u0B80-\u0BFF])[a-zA-Z\u0B80-\u0BFF\u2080\u2081\u2082\u2083\u2084\u2085\u2086\u2087\u2088\u2089\u0370-\u03FF]+\u200D\u200D\u200D"; // Multiple
                                                                                                                                                                                                                                                 // subscript
                                                                                                                                                                                                                                                 // letters
                                                                                                                                                                                                                                                 // (contains
                                                                                                                                                                                                                                                 // Greek/Tamil)
    private static final String SUPERSCRIPT_SINGLE_PATTERN = "\u200C[^\u200C\n]\u200C"; // Single superscript character
                                                                                        // except marker/newline
    private static final String SUPERSCRIPT_SINGLE_GREEK_PATTERN = "\u200C[\u0370-\u03FF\u0B80-\u0BFF]\u200C"; // Single
                                                                                                               // Greek/Tamil
                                                                                                               // superscript
                                                                                                               // letter
    private static final String SUPERSCRIPT_MULTI_PATTERN = "\u200C\u200C\u200C[^\u200C\n]+\u200C\u200C\u200C"; // Multiple
                                                                                                                // superscript
                                                                                                                // characters
                                                                                                                // except
                                                                                                                // marker/newline
    private static final String SUPERSCRIPT_MULTI_GREEK_PATTERN = "\u200C\u200C\u200C(?=[^\u200C]*[\u0370-\u03FF\u0B80-\u0BFF])[a-zA-Z\u0B80-\u0BFF\u00B9\u00B2\u00B3\u2074\u2075\u2076\u2077\u2078\u2079\u2070ᵃᵇᶜᵈᵉᶠᶢʰⁱʲᵏˡᵐⁿᵒᵖʳˢᵗᵘᵛʷˣʸᶻᵝᵞᵟᵋᶿᶲᵡᵠ\u0370-\u03FF]+\u200C\u200C\u200C"; // Multiple
                                                                                                                                                                                                                                                                                    // superscript
                                                                                                                                                                                                                                                                                    // letters
                                                                                                                                                                                                                                                                                    // (contains
                                                                                                                                                                                                                                                                                    // Greek/Tamil)
    private static final String IDENTIFIER_PATTERN = "\\b[a-zA-Z_]\\w*\\b";

    private static final Pattern SUB_SUPER_PATTERN = Pattern.compile(
            "(?<SUBSCRIPTMULTIGREEK>" + SUBSCRIPT_MULTI_GREEK_PATTERN + ")"
                    + "|(?<SUBSCRIPTMULTI>" + SUBSCRIPT_MULTI_PATTERN + ")"
                    + "|(?<SUBSCRIPTSINGLEGREEK>" + SUBSCRIPT_SINGLE_GREEK_PATTERN + ")"
                    + "|(?<SUBSCRIPTSINGLE>" + SUBSCRIPT_SINGLE_PATTERN + ")"
                    + "|(?<SUPERSCRIPTMULTIGREEK>" + SUPERSCRIPT_MULTI_GREEK_PATTERN + ")"
                    + "|(?<SUPERSCRIPTMULTI>" + SUPERSCRIPT_MULTI_PATTERN + ")"
                    + "|(?<SUPERSCRIPTSINGLEGREEK>" + SUPERSCRIPT_SINGLE_GREEK_PATTERN + ")"
                    + "|(?<SUPERSCRIPTSINGLE>" + SUPERSCRIPT_SINGLE_PATTERN + ")");

    // Order matters: COMMENT and STRING first; CONDITIONAL, then BUILTIN, then
    // PRIMITIVEWORD, all before IDENTIFIER (so keywords/functions/primitives win
    // over the generic identifier rule); sub/superscript groups before
    // IDENTIFIER; PRIMITIVESYMBOL covers the math operators.
    //
    // Why BUILTIN sits AFTER CONDITIONAL: `if` and `while` are registered as
    // functions too (logical_conditional_list registers them for the suggestion
    // popup). Written as `if(x > 3):` they would otherwise flip to orchid.
    // CONDITIONAL first means a control-flow word is always control-flow blue,
    // whatever punctuation follows it.
    //
    // Why BUILTIN sits BEFORE PRIMITIVEWORD: a registered function outranks the
    // primitive list. In practice the two can no longer collide at all —
    // SyntaxPalette.primitiveWordPattern() strips any registered name out of the
    // primitive alternation — but the ordering keeps the intent readable and
    // survives someone re-adding a word to PRIMITIVE_WORDS by hand.
    private static final Pattern PATTERN = Pattern.compile(
            "(?<COMMENT>" + COMMENT_PATTERN + ")"
                    + "|(?<STRING>" + STRING_PATTERN + ")"
                    + "|(?<CONDITIONAL>" + CONDITIONAL_PATTERN + ")"
                    + "|(?<BUILTIN>" + BUILTIN_PATTERN + ")"
                    + "|(?<PRIMITIVEWORD>" + PRIMITIVE_WORD_PATTERN + ")"
                    + "|(?<NUMBER>" + NUMBER_PATTERN + ")"
                    + "|(?<SUBSCRIPTMULTIGREEK>" + SUBSCRIPT_MULTI_GREEK_PATTERN + ")"
                    + "|(?<SUBSCRIPTMULTI>" + SUBSCRIPT_MULTI_PATTERN + ")"
                    + "|(?<SUBSCRIPTSINGLEGREEK>" + SUBSCRIPT_SINGLE_GREEK_PATTERN + ")"
                    + "|(?<SUBSCRIPTSINGLE>" + SUBSCRIPT_SINGLE_PATTERN + ")"
                    + "|(?<SUPERSCRIPTMULTIGREEK>" + SUPERSCRIPT_MULTI_GREEK_PATTERN + ")"
                    + "|(?<SUPERSCRIPTMULTI>" + SUPERSCRIPT_MULTI_PATTERN + ")"
                    + "|(?<SUPERSCRIPTSINGLEGREEK>" + SUPERSCRIPT_SINGLE_GREEK_PATTERN + ")"
                    + "|(?<SUPERSCRIPTSINGLE>" + SUPERSCRIPT_SINGLE_PATTERN + ")"
                    + "|(?<PRIMITIVESYMBOL>" + PRIMITIVE_SYMBOL_PATTERN + ")"
                    + "|(?<IDENTIFIER>" + IDENTIFIER_PATTERN + ")");

    public static StyleSpans<Collection<String>> computeHighlighting(String text) {
        Matcher matcher = PATTERN.matcher(text);
        int lastEnd = 0;

        StyleSpansBuilder<Collection<String>> spans = new StyleSpansBuilder<>();

        while (matcher.find()) {
            spans.add(Collections.emptyList(), matcher.start() - lastEnd);

            if (matcher.group("COMMENT") != null)
                addCommentSpans(spans, matcher.group("COMMENT"));
            else if (matcher.group("STRING") != null)
                spans.add(Collections.singleton("string"), matcher.end() - matcher.start());
            else if (matcher.group("CONDITIONAL") != null)
                spans.add(Collections.singleton(SyntaxPalette.STYLE_CONDITIONAL), matcher.end() - matcher.start());
            else if (matcher.group("BUILTIN") != null)
                spans.add(Collections.singleton(SyntaxPalette.STYLE_BUILTIN), matcher.end() - matcher.start());
            else if (matcher.group("PRIMITIVEWORD") != null)
                spans.add(Collections.singleton(SyntaxPalette.STYLE_PRIMITIVE), matcher.end() - matcher.start());
            else if (matcher.group("NUMBER") != null)
                spans.add(Collections.singleton("number"), matcher.end() - matcher.start());
            else if (matcher.group("SUBSCRIPTMULTIGREEK") != null)
                spans.add(Collections.singleton("subscript-greek-multi"), matcher.end() - matcher.start());
            else if (matcher.group("SUBSCRIPTMULTI") != null)
                spans.add(Collections.singleton("subscript-multi"), matcher.end() - matcher.start());
            else if (matcher.group("SUBSCRIPTSINGLEGREEK") != null)
                spans.add(Collections.singleton("subscript-greek-single"), matcher.end() - matcher.start());
            else if (matcher.group("SUBSCRIPTSINGLE") != null)
                spans.add(Collections.singleton("subscript-single"), matcher.end() - matcher.start());
            else if (matcher.group("SUPERSCRIPTMULTIGREEK") != null)
                spans.add(Collections.singleton("superscript-greek-multi"), matcher.end() - matcher.start());
            else if (matcher.group("SUPERSCRIPTMULTI") != null)
                spans.add(Collections.singleton("superscript-multi"), matcher.end() - matcher.start());
            else if (matcher.group("SUPERSCRIPTSINGLEGREEK") != null)
                spans.add(Collections.singleton("superscript-greek-single"), matcher.end() - matcher.start());
            else if (matcher.group("SUPERSCRIPTSINGLE") != null)
                spans.add(Collections.singleton("superscript-single"), matcher.end() - matcher.start());
            else if (matcher.group("PRIMITIVESYMBOL") != null)
                spans.add(Collections.singleton(SyntaxPalette.STYLE_PRIMITIVE), matcher.end() - matcher.start());
            else
                spans.add(Collections.singleton(SyntaxPalette.STYLE_IDENTIFIER), matcher.end() - matcher.start());

            lastEnd = matcher.end();
        }

        spans.add(Collections.emptyList(), text.length() - lastEnd);
        return spans.create();
    }

    private static void addCommentSpans(StyleSpansBuilder<Collection<String>> spans, String commentText) {
        Matcher matcher = SUB_SUPER_PATTERN.matcher(commentText);
        int lastEnd = 0;

        while (matcher.find()) {
            if (matcher.start() > lastEnd)
                spans.add(Collections.singleton("comment"), matcher.start() - lastEnd);

            spans.add(Arrays.asList("comment", subSuperClassName(matcher)), matcher.end() - matcher.start());
            lastEnd = matcher.end();
        }

        if (lastEnd < commentText.length())
            spans.add(Collections.singleton("comment"), commentText.length() - lastEnd);
    }

    private static String subSuperClassName(Matcher matcher) {
        if (matcher.group("SUBSCRIPTMULTIGREEK") != null)
            return "subscript-greek-multi";
        if (matcher.group("SUBSCRIPTMULTI") != null)
            return "subscript-multi";
        if (matcher.group("SUBSCRIPTSINGLEGREEK") != null)
            return "subscript-greek-single";
        if (matcher.group("SUBSCRIPTSINGLE") != null)
            return "subscript-single";
        if (matcher.group("SUPERSCRIPTMULTIGREEK") != null)
            return "superscript-greek-multi";
        if (matcher.group("SUPERSCRIPTMULTI") != null)
            return "superscript-multi";
        if (matcher.group("SUPERSCRIPTSINGLEGREEK") != null)
            return "superscript-greek-single";
        return "superscript-single";
    }
}
