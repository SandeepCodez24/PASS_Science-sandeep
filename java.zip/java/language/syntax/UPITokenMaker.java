package language.syntax;

import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.fxmisc.richtext.model.StyleSpans;
import org.fxmisc.richtext.model.StyleSpansBuilder;

import language.semantic.ScriptedName;
import language.syntax.textcolours.TextCategory;

/**
 * Splits Neural Code text into coloured spans.
 *
 * <p>
 * Nothing to configure here. Which words go in which category is in
 * {@code language/syntax/textcolours/}; the patterns are built by
 * {@link SyntaxPalette}; the colours are in
 * {@code themes/texts/text_light.css} and {@code text_dark.css}.
 * </p>
 *
 * <h3>Every character gets a category</h3>
 * <p>
 * Text no pattern claims ({@code =}, {@code ,}, {@code ;}, {@code :},
 * {@code ~~}, brackets, spaces) is given the variable class, so the variable
 * colour is the only "plain text" colour there is and changing it moves all
 * of them together.
 * </p>
 *
 * <h3>Order of the groups</h3>
 * <p>
 * At any position the first group that matches wins, so the order below is
 * the precedence: comments and strings first (nothing inside them is code),
 * then the word categories, then function names, numbers, the hidden
 * sub/superscript runs, and the symbol categories longest-meaning first --
 * {@code !=} (binary) and {@code !&} (logical) before {@code !} (factorial),
 * {@code ||} before {@code |}. A plain name is last.
 * </p>
 *
 * <h3>{@code ||}: OR or a double absolute value?</h3>
 * <p>
 * {@code ||v||} is a double absolute value; {@code a || b} is OR. A
 * {@code ||} with no value before it opens a double absolute value; the next
 * {@code ||} on the same line after a value closes it; any other {@code ||}
 * is OR. Absolute-value bars take the primitive colour.
 * </p>
 *
 * <h3>Functions and classes (new)</h3>
 * <p>
 * {@code base} and {@code info} right after a dot ({@code Shape.base},
 * {@code obj.info}) are built in and take the function-call colour without a
 * {@code (} ({@link SyntaxPalette#introspectionPattern()}). The name of a
 * named value ({@code x1} in {@code Add(x1=10)}) and an input in a header
 * ({@code a} in {@code f(a=1)}) keep the variable colour, like every other
 * name, and their {@code =} is plain text: nothing styles an assignment.
 * </p>
 *
 * <h3>Constants (new)</h3>
 * <p>
 * A plain name that is one of {@code nc.exe}'s named constants
 * ({@code textcolours/ConstantWords.java}: {@code pi}, {@code e},
 * {@code euler_gamma}, {@code gravity} ...) takes the constant colour -- unless
 * the script uses that name as a variable anywhere
 * ({@link SyntaxPalette#assignedConstants}), as {@code nc.exe} then reads the
 * variable. A name after a dot is a field, never a constant.
 * </p>
 *
 * <h3>Subscripts and superscripts (changed)</h3>
 * <p>
 * A name with a subscript or superscript is written {@code A_$1} /
 * {@code A_@2} and the document holds exactly that text -- the file, the
 * run, the search and the clipboard all see the same characters. It is only
 * <em>drawn</em> as A&#8321;: the two marker characters get
 * {@link #MARKER_CLASS} (shrunk to nothing, see
 * {@code ui.editor.ScriptedNameStyles}) and the part after them gets the
 * existing {@code subscript-multi} / {@code superscript-multi} classes. The
 * caret steps over the hidden markers in one press
 * ({@code ui.editor.ScriptedCaret}, which reads {@link #MARKER_CLASS} from
 * the styles on screen).
 * </p>
 * <p>
 * Markers are hidden only when the whole name is valid
 * ({@link ScriptedName#parse}). {@code A_$} with nothing after it, two
 * subscripts, a superscript before the subscript -- all are drawn exactly as
 * typed, so nothing on screen is ever invisible without a meaning. Inside a
 * string literal {@code _$} is ordinary text and is never styled. Comments
 * are styled like code, so a commented-out line looks the same.
 * </p>
 * <p>
 * The zero-width-joiner patterns of the old design are gone.
 * </p>
 */
public class UPITokenMaker {

    /** Style class of the two hidden marker characters ({@code _$} / {@code _@}). */
    public static final String MARKER_CLASS = "nc-script-marker";

    /** Style class of a subscript's text (already styled in the editor CSS). */
    public static final String SUBSCRIPT_CLASS = "subscript-multi";

    /** Style class of a superscript's text (already styled in the editor CSS). */
    public static final String SUPERSCRIPT_CLASS = "superscript-multi";

    /**
     * Style class of the script part that is drawn stacked over (or under)
     * the other one, in a name with both a subscript and a superscript: the
     * shorter part (the superscript on a tie). An area that stacks
     * ({@code ui.editor.ScriptStack}) draws it with no width and paints it
     * again in the other part's column; anywhere else the class does nothing
     * and the two parts stand side by side.
     */
    public static final String STACKED_CLASS = "nc-script-stacked";

    /** A name carrying at least one marker; see {@link ScriptedName}. */
    private static final Pattern SCRIPTED_PATTERN = ScriptedName.SCRIPTED_NAME;

    // ── The one pattern. Built once; touching SyntaxPalette loads every
    //    category file and the FunctionProvider registry first. ────────────
    private static final Pattern PATTERN = Pattern.compile(
            "(?<COMMENT>" + SyntaxPalette.commentPattern() + ")"
                    + "|(?<STRING>" + SyntaxPalette.stringPattern() + ")"
                    + "|(?<SCRIPTED>" + ScriptedName.SCRIPTED_NAME_REGEX + ")"
                    + "|(?<LOOP>" + SyntaxPalette.loopPattern() + ")"
                    + "|(?<FNCLASS>" + SyntaxPalette.functionClassPattern() + ")"
                    + "|(?<OTHER>" + SyntaxPalette.otherPattern() + ")"
                    + "|(?<LOGICALWORD>" + SyntaxPalette.logicalWordPattern() + ")"
                    + "|(?<BINARYWORD>" + SyntaxPalette.binaryWordPattern() + ")"
                    + "|(?<CONVERSION>" + SyntaxPalette.conversionPattern() + ")"
                    + "|(?<LOGBASE>" + SyntaxPalette.logBasePattern() + ")"
                    + "|(?<EXPONENT>" + SyntaxPalette.exponentPattern() + ")"
                    + "|(?<PRIMWORD>" + SyntaxPalette.primitiveWordPattern() + ")"
                    + "|(?<PRIMVALUE>" + SyntaxPalette.primitiveValuePattern() + ")"
                    + "|(?<INTROSPECTION>" + SyntaxPalette.introspectionPattern() + ")"
                    + "|(?<DATAIO>" + SyntaxPalette.dataIoPattern() + ")"
                    + "|(?<BUILTIN>" + SyntaxPalette.builtinFunctionPattern() + ")"
                    + "|(?<NUMBER>" + SyntaxPalette.numberPattern() + ")"
                    + "|(?<BINARYSYM>" + SyntaxPalette.binarySymbolPattern() + ")"
                    + "|(?<LOGICALSYM>" + SyntaxPalette.logicalSymbolPattern() + ")"
                    + "|(?<ABSBAR>" + SyntaxPalette.absoluteBarPattern() + ")"
                    + "|(?<PRIMSYM>" + SyntaxPalette.primitiveSymbolPattern() + ")"
                    + "|(?<IDENTIFIER>" + SyntaxPalette.identifierPattern() + ")");

    /** Group name to category, for the groups that map one to one. */
    private static final Object[][] SIMPLE_GROUPS = {
            { "STRING", TextCategory.STRING },
            { "LOOP", TextCategory.LOOP },
            { "FNCLASS", TextCategory.FUNCTION_CLASS },
            { "OTHER", TextCategory.OTHER },
            { "LOGICALWORD", TextCategory.LOGICAL },
            { "BINARYWORD", TextCategory.BINARY },
            { "CONVERSION", TextCategory.CONVERSION },
            { "LOGBASE", TextCategory.PRIMITIVE },
            { "EXPONENT", TextCategory.PRIMITIVE },
            { "PRIMWORD", TextCategory.PRIMITIVE },
            { "PRIMVALUE", TextCategory.PRIMITIVE },
            { "INTROSPECTION", TextCategory.FUNCTION_CALL },
            { "DATAIO", TextCategory.DATA_IO },
            { "BUILTIN", TextCategory.FUNCTION_CALL },
            { "NUMBER", TextCategory.NUMBER },
            { "BINARYSYM", TextCategory.BINARY },
            { "ABSBAR", TextCategory.PRIMITIVE },
            { "PRIMSYM", TextCategory.PRIMITIVE },
    };

    private static final String DOUBLE_BAR = "||";

    /**
     * Styles the whole document. Works for any RichTextFX area (the editor's
     * {@code CodeArea}, or a {@code StyleClassedTextArea} in the Command
     * Window).
     *
     * @param text the whole document
     * @return the style spans; every span carries a {@code tc-*} class
     */
    public static StyleSpans<Collection<String>> computeHighlighting(String text) {
        StyleSpansBuilder<Collection<String>> spans = new StyleSpansBuilder<>();
        if (text == null || text.isEmpty()) {
            spans.add(classes(TextCategory.VARIABLE), 0);
            return spans.create();
        }

        Matcher matcher = PATTERN.matcher(text);
        Set<String> userFunctions = SyntaxPalette.userFunctionNames(text);
        int lastEnd = 0;
        int openDoubleBars = 0;
        int barLine = -2;

        while (matcher.find()) {
            int start = matcher.start();
            int length = matcher.end() - start;
            if (start > lastEnd) {
                spans.add(classes(TextCategory.VARIABLE), start - lastEnd);
            }

            if (matcher.group("COMMENT") != null) {
                addCommentSpans(spans, matcher.group("COMMENT"));
            } else if (matcher.group("SCRIPTED") != null) {
                boolean called = matcher.end() < text.length() && text.charAt(matcher.end()) == '('
                        && userFunctions.contains(matcher.group("SCRIPTED"));
                addScriptedSpans(spans, matcher.group("SCRIPTED"),
                        called ? TextCategory.FUNCTION_CALL : TextCategory.VARIABLE);
            } else if (matcher.group("LOGICALSYM") != null) {
                // ||: OR, or the opening / closing of a double absolute value.
                TextCategory category = TextCategory.LOGICAL;
                if (DOUBLE_BAR.equals(matcher.group("LOGICALSYM"))) {
                    int line = text.lastIndexOf('\n', start - 1);
                    if (line != barLine) {
                        barLine = line;
                        openDoubleBars = 0;
                    }
                    if (!valueBefore(text, start)) {
                        openDoubleBars++;
                        category = TextCategory.PRIMITIVE;
                    } else if (openDoubleBars > 0) {
                        openDoubleBars--;
                        category = TextCategory.PRIMITIVE;
                    }
                }
                spans.add(classes(category), length);
            } else if (matcher.group("IDENTIFIER") != null) {
                String name = matcher.group("IDENTIFIER");
                boolean called = matcher.end() < text.length() && text.charAt(matcher.end()) == '('
                        && userFunctions.contains(name);
                TextCategory category = called ? TextCategory.FUNCTION_CALL : TextCategory.VARIABLE;
                // A named constant (pi, e, euler_gamma ...), unless the script
                // uses that name as a variable somewhere; not after a dot
                // (obj.e is a field).
                if (!called && SyntaxPalette.CONSTANTS.contains(name) && (start == 0 || text.charAt(start - 1) != '.')
                        && !SyntaxPalette.assignedConstants(text).contains(name)) {
                    category = TextCategory.CONSTANT;
                }
                spans.add(classes(category), length);
            } else {
                spans.add(classes(simpleCategory(matcher)), length);
            }
            lastEnd = matcher.end();
        }

        if (text.length() > lastEnd) {
            spans.add(classes(TextCategory.VARIABLE), text.length() - lastEnd);
        }
        return spans.create();
    }

    /**
     * @param category a category
     * @return the classes a span of it carries: its own and the legacy one
     */
    public static Collection<String> classes(TextCategory category) {
        return List.of(category.styleClass(), category.legacyClass());
    }

    // =====================================================================
    // Internals
    // =====================================================================

    private static TextCategory simpleCategory(Matcher matcher) {
        for (Object[] g : SIMPLE_GROUPS) {
            if (matcher.group((String) g[0]) != null) {
                return (TextCategory) g[1];
            }
        }
        return TextCategory.VARIABLE;
    }

    /**
     * The spans of one name that carries a marker. A valid name is drawn as
     * base, hidden marker, lowered / raised text; an invalid one exactly as
     * typed, in one colour.
     */
    private static void addScriptedSpans(StyleSpansBuilder<Collection<String>> spans, String name,
            TextCategory category) {
        ScriptedName.Parsed parsed = ScriptedName.parse(name);
        if (!parsed.isValid()) {
            spans.add(classes(category), name.length());
            return;
        }
        ScriptedName.Part stacked = stackedPart(parsed);
        for (ScriptedName.Part part : parsed.parts()) {
            if (part.kind() == ScriptedName.Kind.BASE) {
                spans.add(classes(category), part.end());
                continue;
            }
            spans.add(List.of(category.styleClass(), category.legacyClass(), MARKER_CLASS),
                    part.contentStart() - part.markerStart());
            String script = part.kind() == ScriptedName.Kind.SUBSCRIPT ? SUBSCRIPT_CLASS : SUPERSCRIPT_CLASS;
            spans.add(part == stacked
                    ? List.of(category.styleClass(), category.legacyClass(), script, STACKED_CLASS)
                    : List.of(category.styleClass(), category.legacyClass(), script),
                    part.end() - part.contentStart());
        }
    }

    /**
     * The part of a name drawn stacked in the other part's column: in a name
     * with both a subscript and a superscript, the shorter one (the
     * superscript on a tie); null otherwise.
     *
     * @param parsed a valid parsed name
     * @return the stacked part, or null
     */
    public static ScriptedName.Part stackedPart(ScriptedName.Parsed parsed) {
        ScriptedName.Part sub = null;
        ScriptedName.Part sup = null;
        for (ScriptedName.Part part : parsed.parts()) {
            if (part.kind() == ScriptedName.Kind.SUBSCRIPT) {
                sub = part;
            } else if (part.kind() == ScriptedName.Kind.SUPERSCRIPT) {
                sup = part;
            }
        }
        if (sub == null || sup == null) {
            return null;
        }
        int subLength = sub.text().codePointCount(0, sub.text().length());
        int supLength = sup.text().codePointCount(0, sup.text().length());
        return supLength <= subLength ? sup : sub;
    }

    /** True when the last non-space character before {@code index} ends a value. */
    private static boolean valueBefore(String text, int index) {
        int i = index - 1;
        while (i >= 0 && (text.charAt(i) == ' ' || text.charAt(i) == '\t')) {
            i--;
        }
        if (i < 0 || text.charAt(i) == '\n') {
            return false;
        }
        char c = text.charAt(i);
        return Character.isLetterOrDigit(c) || c == '_' || c == ')' || c == ']'
                || c == '"' || c == '\'' || c == '!' || c == '|'
                || Character.getType(c) == Character.NON_SPACING_MARK
                || Character.getType(c) == Character.COMBINING_SPACING_MARK
                || Character.getType(c) == Character.OTHER_NUMBER;
    }

    private static void addCommentSpans(StyleSpansBuilder<Collection<String>> spans, String commentText) {
        Matcher matcher = SCRIPTED_PATTERN.matcher(commentText);
        int lastEnd = 0;
        while (matcher.find()) {
            if (matcher.start() > lastEnd) {
                spans.add(classes(TextCategory.COMMENT), matcher.start() - lastEnd);
            }
            addScriptedSpans(spans, matcher.group(), TextCategory.COMMENT);
            lastEnd = matcher.end();
        }
        if (lastEnd < commentText.length()) {
            spans.add(classes(TextCategory.COMMENT), commentText.length() - lastEnd);
        }
    }
}
