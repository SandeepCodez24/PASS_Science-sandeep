package language.syntax;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.fxmisc.richtext.model.StyleSpans;
import org.fxmisc.richtext.model.StyleSpansBuilder;

public class UPITokenMaker {

    private static final String[] KEYWORDS = {
            "print", "let", "if", "else", "elseif",
            "while", "for", "true", "false", "null"
    };

    private static final String KEYWORD_PATTERN = "\\b(" + String.join("|", KEYWORDS) + ")\\b";

    private static final String COMMENT_PATTERN = "(?:#[^\n]*|\\\\\\\\[^\n]*)";

    private static final String STRING_PATTERN = "\"([^\"\\\\]|\\\\.)*\"";
    private static final String NUMBER_PATTERN = "\\b\\d+\\b";
    private static final String OPERATOR_PATTERN = "[+\\-*/=]";
    private static final String SUBSCRIPT_SINGLE_PATTERN = "\u200D[^\u200D\n]\u200D"; // Single subscript character
                                                                                      // except marker/newline
    private static final String SUBSCRIPT_SINGLE_GREEK_PATTERN = "\u200D[\u0370-\u03FF\u0B80-\u0BFF]\u200D"; // Single
                                                                                                             // Greek/Tamil
                                                                                                             // subscript
                                                                                                             // letter
    private static final String SUBSCRIPT_MULTI_PATTERN = "\u200D\u200D\u200D[^\u200D\n]+\u200D\u200D\u200D"; // Multiple
                                                                                                              // subscript
                                                                                                              // characters
                                                                                                              // except
                                                                                                              // marker/newline
    private static final String SUBSCRIPT_MULTI_GREEK_PATTERN = "\u200D\u200D\u200D(?=[^\u200D]*[\u0370-\u03FF\u0B80-\u0BFF])[a-zA-Z\u0B80-\u0BFF\u2080\u2081\u2082\u2083\u2084\u2085\u2086\u2087\u2088\u2089\u0370-\u03FF]+\u200D\u200D\u200D"; // Multiple
                                                                                                                                                                                                                                                 // subscript
                                                                                                                                                                                                                                                 // letters
                                                                                                                                                                                                                                                 // (contains
                                                                                                                                                                                                                                                 // Greek/Tamil)
    private static final String SUPERSCRIPT_SINGLE_PATTERN = "\u200C[^\u200C\n]\u200C"; // Single superscript character
                                                                                        // except marker/newline
    private static final String SUPERSCRIPT_SINGLE_GREEK_PATTERN = "\u200C[\u0370-\u03FF\u0B80-\u0BFF]\u200C"; // Single
                                                                                                               // Greek/Tamil
                                                                                                               // superscript
                                                                                                               // letter
    private static final String SUPERSCRIPT_MULTI_PATTERN = "\u200C\u200C\u200C[^\u200C\n]+\u200C\u200C\u200C"; // Multiple
                                                                                                                // superscript
                                                                                                                // characters
                                                                                                                // except
                                                                                                                // marker/newline
    private static final String SUPERSCRIPT_MULTI_GREEK_PATTERN = "\u200C\u200C\u200C(?=[^\u200C]*[\u0370-\u03FF\u0B80-\u0BFF])[a-zA-Z\u0B80-\u0BFF\u00B9\u00B2\u00B3\u2074\u2075\u2076\u2077\u2078\u2079\u2070ᵃᵇᶜᵈᵉᶠᶢʰⁱʲᵏˡᵐⁿᵒᵖʳˢᵗᵘᵛʷˣʸᶻᵝᵞᵟᵋᶿᶲᵡᵠ\u0370-\u03FF]+\u200C\u200C\u200C"; // Multiple
                                                                                                                                                                                                                                                                                    // superscript
                                                                                                                                                                                                                                                                                    // letters
                                                                                                                                                                                                                                                                                    // (contains
                                                                                                                                                                                                                                                                                    // Greek/Tamil)
    private static final String IDENTIFIER_PATTERN = "\\b[a-zA-Z_]\\w*\\b";

    private static final Pattern SUB_SUPER_PATTERN = Pattern.compile(
            "(?<SUBSCRIPTMULTIGREEK>" + SUBSCRIPT_MULTI_GREEK_PATTERN + ")"
                    + "|(?<SUBSCRIPTMULTI>" + SUBSCRIPT_MULTI_PATTERN + ")"
                    + "|(?<SUBSCRIPTSINGLEGREEK>" + SUBSCRIPT_SINGLE_GREEK_PATTERN + ")"
                    + "|(?<SUBSCRIPTSINGLE>" + SUBSCRIPT_SINGLE_PATTERN + ")"
                    + "|(?<SUPERSCRIPTMULTIGREEK>" + SUPERSCRIPT_MULTI_GREEK_PATTERN + ")"
                    + "|(?<SUPERSCRIPTMULTI>" + SUPERSCRIPT_MULTI_PATTERN + ")"
                    + "|(?<SUPERSCRIPTSINGLEGREEK>" + SUPERSCRIPT_SINGLE_GREEK_PATTERN + ")"
                    + "|(?<SUPERSCRIPTSINGLE>" + SUPERSCRIPT_SINGLE_PATTERN + ")");

    private static final Pattern PATTERN = Pattern.compile(
            "(?<COMMENT>" + COMMENT_PATTERN + ")"
                    + "|(?<KEYWORD>" + KEYWORD_PATTERN + ")"
                    + "|(?<STRING>" + STRING_PATTERN + ")"
                    + "|(?<NUMBER>" + NUMBER_PATTERN + ")"
                    + "|(?<OPERATOR>" + OPERATOR_PATTERN + ")"
                    + "|(?<SUBSCRIPTMULTIGREEK>" + SUBSCRIPT_MULTI_GREEK_PATTERN + ")"
                    + "|(?<SUBSCRIPTMULTI>" + SUBSCRIPT_MULTI_PATTERN + ")"
                    + "|(?<SUBSCRIPTSINGLEGREEK>" + SUBSCRIPT_SINGLE_GREEK_PATTERN + ")"
                    + "|(?<SUBSCRIPTSINGLE>" + SUBSCRIPT_SINGLE_PATTERN + ")"
                    + "|(?<SUPERSCRIPTMULTIGREEK>" + SUPERSCRIPT_MULTI_GREEK_PATTERN + ")"
                    + "|(?<SUPERSCRIPTMULTI>" + SUPERSCRIPT_MULTI_PATTERN + ")"
                    + "|(?<SUPERSCRIPTSINGLEGREEK>" + SUPERSCRIPT_SINGLE_GREEK_PATTERN + ")"
                    + "|(?<SUPERSCRIPTSINGLE>" + SUPERSCRIPT_SINGLE_PATTERN + ")"
                    + "|(?<IDENTIFIER>" + IDENTIFIER_PATTERN + ")");

    public static StyleSpans<Collection<String>> computeHighlighting(String text) {
        Matcher matcher = PATTERN.matcher(text);
        int lastEnd = 0;

        StyleSpansBuilder<Collection<String>> spans = new StyleSpansBuilder<>();

        while (matcher.find()) {
            spans.add(Collections.emptyList(), matcher.start() - lastEnd);

            if (matcher.group("COMMENT") != null)
                addCommentSpans(spans, matcher.group("COMMENT"));
            else if (matcher.group("KEYWORD") != null)
                spans.add(Collections.singleton("keyword"), matcher.end() - matcher.start());
            else if (matcher.group("STRING") != null)
                spans.add(Collections.singleton("string"), matcher.end() - matcher.start());
            else if (matcher.group("NUMBER") != null)
                spans.add(Collections.singleton("number"), matcher.end() - matcher.start());
            else if (matcher.group("OPERATOR") != null)
                spans.add(Collections.singleton("operator"), matcher.end() - matcher.start());
            else if (matcher.group("SUBSCRIPTMULTIGREEK") != null)
                spans.add(Collections.singleton("subscript-greek-multi"), matcher.end() - matcher.start());
            else if (matcher.group("SUBSCRIPTMULTI") != null)
                spans.add(Collections.singleton("subscript-multi"), matcher.end() - matcher.start());
            else if (matcher.group("SUBSCRIPTSINGLEGREEK") != null)
                spans.add(Collections.singleton("subscript-greek-single"), matcher.end() - matcher.start());
            else if (matcher.group("SUBSCRIPTSINGLE") != null)
                spans.add(Collections.singleton("subscript-single"), matcher.end() - matcher.start());
            else if (matcher.group("SUPERSCRIPTMULTIGREEK") != null)
                spans.add(Collections.singleton("superscript-greek-multi"), matcher.end() - matcher.start());
            else if (matcher.group("SUPERSCRIPTMULTI") != null)
                spans.add(Collections.singleton("superscript-multi"), matcher.end() - matcher.start());
            else if (matcher.group("SUPERSCRIPTSINGLEGREEK") != null)
                spans.add(Collections.singleton("superscript-greek-single"), matcher.end() - matcher.start());
            else if (matcher.group("SUPERSCRIPTSINGLE") != null)
                spans.add(Collections.singleton("superscript-single"), matcher.end() - matcher.start());
            else
                spans.add(Collections.singleton("identifier"), matcher.end() - matcher.start());

            lastEnd = matcher.end();
        }

        spans.add(Collections.emptyList(), text.length() - lastEnd);
        return spans.create();
    }

    private static void addCommentSpans(StyleSpansBuilder<Collection<String>> spans, String commentText) {
        Matcher matcher = SUB_SUPER_PATTERN.matcher(commentText);
        int lastEnd = 0;

        while (matcher.find()) {
            if (matcher.start() > lastEnd)
                spans.add(Collections.singleton("comment"), matcher.start() - lastEnd);

            spans.add(Arrays.asList("comment", subSuperClassName(matcher)), matcher.end() - matcher.start());
            lastEnd = matcher.end();
        }

        if (lastEnd < commentText.length())
            spans.add(Collections.singleton("comment"), commentText.length() - lastEnd);
    }

    private static String subSuperClassName(Matcher matcher) {
        if (matcher.group("SUBSCRIPTMULTIGREEK") != null)
            return "subscript-greek-multi";
        if (matcher.group("SUBSCRIPTMULTI") != null)
            return "subscript-multi";
        if (matcher.group("SUBSCRIPTSINGLEGREEK") != null)
            return "subscript-greek-single";
        if (matcher.group("SUBSCRIPTSINGLE") != null)
            return "subscript-single";
        if (matcher.group("SUPERSCRIPTMULTIGREEK") != null)
            return "superscript-greek-multi";
        if (matcher.group("SUPERSCRIPTMULTI") != null)
            return "superscript-multi";
        if (matcher.group("SUPERSCRIPTSINGLEGREEK") != null)
            return "superscript-greek-single";
        return "superscript-single";
    }
}
