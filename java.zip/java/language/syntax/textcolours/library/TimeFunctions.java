package language.syntax.textcolours.library;

/**
 * Date and time function names: the {@code timestamp} and {@code duration}
 * values of {@code nc.exe}.
 *
 * <p>
 * Same shape as {@link NumpyFunctions}: one {signature, description} line
 * per function, offered by the suggestion box and painted in the
 * function-call colour ({@code .tc-function-call}) where it is called.
 * Names that are ordinary words ({@code days}, {@code today}, {@code tic})
 * are coloured only where called, so a variable named {@code days} stays
 * plain.
 * </p>
 */
public final class TimeFunctions {

    private TimeFunctions() {
    }

    /** {signature, description} */
    public static final String[][] ENTRIES = {
            { "get_timestamp()", "Time: current date and time" },
            { "today([zone])", "Time: start of today" },
            { "timestamp(year, month, day[, hour, minute, second][, zone])", "Time: timestamp from date parts" },
            { "to_timestamp(text[, zone])", "Time: parse ISO date text" },
            { "seconds(n)", "Time: duration of n seconds" },
            { "minutes(n)", "Time: duration of n minutes" },
            { "hours(n)", "Time: duration of n hours" },
            { "days(n)", "Time: duration of n days" },
            { "get_time(t[, zone])", "Time: hour, minute, second of timestamp" },
            { "get_date(t[, zone])", "Time: year, month, day of timestamp" },
            { "set_time(t, hour, minute, second[, zone])", "Time: same date, new time" },
            { "set_date(t, year, month, day[, zone])", "Time: same time, new date" },
            { "format_time(t[, pattern[, zone]])", "Time: timestamp as formatted text" },
            { "in_seconds(d)", "Time: duration in seconds" },
            { "in_minutes(d)", "Time: duration in minutes" },
            { "in_hours(d)", "Time: duration in hours" },
            { "in_days(d)", "Time: duration in days" },
            { "in_hms(d)", "Time: duration as hours, minutes, seconds" },
            { "in_hrs_min_sec(d)", "Time: same as in_hms" },
            { "format_duration(d)", "Time: duration as hh:mm:ss text" },
            { "tic()", "Time: start the stopwatch" },
            { "toc()", "Time: time since last tic" },
            { "date_range(start, stop[, step])", "Time: timestamps at regular steps" },
            { "is_busday(t, weekmask=\"1111100\", zone=\"\"[, holidays])", "Time: is it a business day" },
            { "busday_count(begin, end, weekmask=\"1111100\", zone=\"\"[, holidays])", "Time: business days between dates" },
            { "busday_offset(t, n, roll=\"raise\", weekmask=\"1111100\", zone=\"\"[, holidays])", "Time: move by business days" },
    };
}
