package language.syntax.textcolours.library;

/**
 * NumPy-style function names.
 *
 * <p>
 * One line per function: the signature the suggestion box inserts and the
 * description it shows. Every name here is offered by the suggestion box
 * and painted in the function-call colour ({@code .tc-function-call}) where
 * it is called. Adding a line is the whole job.
 * </p>
 *
 * <p>
 * A name that another list already registers (for example {@code sin} in
 * {@code trigonometric_list}) is shown once; {@code FunctionProvider} skips
 * duplicates.
 * </p>
 */
public final class NumpyFunctions {

    private NumpyFunctions() {
    }

    /** {signature, description} */
    public static final String[][] ENTRIES = {
            { "sin(x)", "NumPy: sine of x (radians)" },
            { "cos(x)", "NumPy: cosine of x (radians)" },
            { "det(A)", "NumPy: determinant of a square matrix" },
            { "transpose(A)", "NumPy: transpose of a matrix" },
            // Adding & removing elements
            { "insert(A, index, values[, axis])", "NumPy: insert values before position" },
            { "repeat(A, repeats[, axis])", "NumPy: repeat each element or slice" },
            { "pad(A, width, mode=\"constant\", value=0)", "NumPy: add a border around matrix" },
            { "trim_zeros(v, trim=\"fb\")", "NumPy: remove leading and trailing zeros" },
            { "unique(A[, axis])", "NumPy: sorted distinct elements" },
            { "put(A, indices, values)", "NumPy: replace values at positions" },
            { "replace_if(A, mask, value)", "NumPy: replace where mask is true" },
            { "fill_diagonal(A, value, wrap=false)", "NumPy: set the main diagonal" },
            { "nan_to_num(A, nan=0[, posinf[, neginf]])", "NumPy: replace NaN and infinity" },
            // Combining & splitting
            { "concat(A1, A2, ..., axis=0)", "NumPy: join along existing axis" },
            { "stack(A1, A2, ..., axis=0)", "NumPy: join along a new axis" },
            { "row_stack(A1, A2, ...)", "NumPy: stack rows like [A; B]" },
            { "vstack(A1, A2, ...)", "NumPy: same as row_stack" },
            { "column_stack(A1, A2, ...)", "NumPy: join columns like [A, B]" },
            { "hstack(A1, A2, ...)", "NumPy: same as column_stack" },
            { "matrix_split(A, sections, axis=0)", "NumPy: cut matrix into pieces" },
            { "vsplit(A, sections)", "NumPy: cut between rows" },
            { "hsplit(A, sections)", "NumPy: cut between columns" },
            // Copying, sorting & reshaping
            { "sort_asc(A[, axis])", "NumPy: sort ascending along axis" },
            { "sort_desc(A[, axis])", "NumPy: sort descending along axis" },
            { "sort_complex(A[, axis])", "NumPy: sort by real, then imaginary" },
            { "flatten(A, order=\"C\")", "NumPy: all elements in one row" },
            { "flip(A[, axis])", "NumPy: reverse along an axis" },
            { "fliplr(A)", "NumPy: reverse the column order" },
            { "flipud(A)", "NumPy: reverse the row order" },
            { "rot90(A, k=1)", "NumPy: rotate 90 degrees counter-clockwise" },
            { "roll(A, shift[, axis])", "NumPy: shift elements around cyclically" },
            // Creating arrays
            { "check_finite(A)", "NumPy: error if NaN or Inf" },
            { "zeros_like(A)", "NumPy: zeros of the same shape" },
            { "ones_like(A)", "NumPy: ones of the same shape" },
            { "vander(x, N=0, increasing=false)", "NumPy: Vandermonde matrix of powers" },
            { "[X, Y] = meshgrid(x, y, indexing=\"xy\")", "NumPy: coordinate grids from vectors" },
            { "[R, C] = indices(dims)", "NumPy: row and column index grids" },
            { "rand_choice(a, size=1, replace=true[, p])", "NumPy: random picks from elements" },
            { "shuffle(A[, axis])", "NumPy: shuffled copy of matrix" },
            { "permutation(x)", "NumPy: random order of elements" },
            { "rand_binomial(n, p, size=1)", "NumPy: binomial random samples" },
            { "rand_poisson(lam, size=1)", "NumPy: Poisson random samples" },
            { "rand_exponential(scale=1, size=1)", "NumPy: exponential random samples" },
            { "rand_beta(a, b, size=1)", "NumPy: beta random samples" },
            { "rand_gamma(shape, scale=1, size=1)", "NumPy: gamma random samples" },
            { "rand_lognormal(mean=0, sigma=1, size=1)", "NumPy: log-normal random samples" },
            { "rand_chisquare(df, size=1)", "NumPy: chi-square random samples" },
            { "rand_triangular(left, mode, right, size=1)", "NumPy: triangular random samples" },
            { "rand_geometric(p, size=1)", "NumPy: trials until first success" },
            { "rand_multinomial(n, pvals, size=1)", "NumPy: multinomial category counts" },
            { "rand_mvnormal(mean, cov, size=1)", "NumPy: multivariate normal random points" },
            // Indexing & slicing
            { "take(A, indices[, axis])", "NumPy: elements at given positions" },
            { "where(cond[, x[, y]])", "NumPy: choose x or y conditionally" },
            { "[r, c] = nonzero(A)", "NumPy: positions of non-zero elements" },
            { "choose(idx, c1, c2, ...)", "NumPy: pick from choices by index" },
            { "compress(cond, A[, axis])", "NumPy: keep elements where true" },
            { "extract(cond, A)", "NumPy: elements where condition holds" },
            { "[r, c] = diag_indices(n, ndim=2)", "NumPy: main diagonal positions" },
            { "[r, c] = tril_indices(n, k=0[, m])", "NumPy: lower triangle positions" },
            { "[r, c] = triu_indices(n, k=0[, m])", "NumPy: upper triangle positions" },
            { "[r, c] = mask_indices(n, mask=\"triu\", k=0)", "NumPy: triangle positions by mask" },
            { "ravel_index(index, dims)", "NumPy: multi-index to flat position" },
            // Inspecting properties
            { "ndim(A)", "NumPy: number of dimensions" },
            { "is_scalar(x)", "NumPy: true for one value" },
            { "is_complex_each(A)", "NumPy: complex check per element" },
            { "is_real_each(A)", "NumPy: real check per element" },
            { "type(x)", "NumPy: element type as text" },
            { "is_type(x, name)", "NumPy: check type or type group" },
            { "can_cast(from, to, casting=\"safe\")", "NumPy: can one type convert" },
            // Statistics
            { "average(A, axis=\"all\", weights=1)", "NumPy: weighted mean along axis" },
            { "prod(A, axis=\"all\")", "NumPy: product along axis" },
            { "argmin(A, axis=\"all\")", "NumPy: position of smallest element" },
            { "argmax(A, axis=\"all\")", "NumPy: position of largest element" },
            { "count_nonzero(A, axis=\"all\")", "NumPy: count non-zero elements" },
            { "all(A, axis=\"all\")", "NumPy: are all elements true" },
            { "any(A, axis=\"all\")", "NumPy: is any element true" },
            { "cumsum(A, axis=\"all\")", "NumPy: running sum along axis" },
            { "cumprod(A, axis=\"all\")", "NumPy: running product along axis" },
            { "cumulative_sum(A, axis=\"all\", include_initial=false)", "NumPy: running sum, optional start" },
            { "cumulative_prod(A, axis=\"all\", include_initial=false)", "NumPy: running product, optional start" },
            { "nan_mean(A, axis=\"all\")", "NumPy: mean ignoring NaN values" },
            { "nan_median(A, axis=\"all\")", "NumPy: median ignoring NaN values" },
            { "nan_sum(A, axis=\"all\")", "NumPy: sum ignoring NaN values" },
            { "nan_prod(A, axis=\"all\")", "NumPy: product ignoring NaN values" },
            { "nan_min(A, axis=\"all\")", "NumPy: minimum ignoring NaN values" },
            { "nan_max(A, axis=\"all\")", "NumPy: maximum ignoring NaN values" },
            { "nan_argmin(A, axis=\"all\")", "NumPy: smallest position ignoring NaN" },
            { "nan_argmax(A, axis=\"all\")", "NumPy: largest position ignoring NaN" },
            { "nan_var(A, axis=\"all\", ddof=0)", "NumPy: variance ignoring NaN values" },
            { "nan_sd(A, axis=\"all\", ddof=0)", "NumPy: standard deviation ignoring NaN" },
            { "nan_percentile(A, q, axis=\"all\")", "NumPy: percentile ignoring NaN values" },
            { "nan_quantile(A, q, axis=\"all\")", "NumPy: quantile ignoring NaN values" },
            { "nan_cumsum(A, axis=\"all\")", "NumPy: running sum, NaN as 0" },
            { "nan_cumprod(A, axis=\"all\")", "NumPy: running product, NaN as 1" },
            { "[counts, edges] = histogram(a, bins=10, density=false[, range])", "NumPy: count values per bin" },
            { "bin_edges(a, bins=10[, range])", "NumPy: histogram bin edge values" },
            { "[H, xedges, yedges] = histogram2d(x, y, bins=10[, range])", "NumPy: two-dimensional histogram counts" },
            { "[H, edges] = histogramdd(sample, bins=10[, range])", "NumPy: N-dimensional histogram counts" },
            { "bincount(x, weights=1, minlength=0)", "NumPy: count each whole number" },
            { "digitize(x, bins, right=false)", "NumPy: bin number of each value" },
            { "correlate(a, v, mode=\"valid\")", "NumPy: cross-correlation of two sequences" },
            { "gradient(f, spacing=1, axis=\"all\")", "NumPy: numerical rate of change" },
            { "trapz(y, dx=1, axis=-1[, x])", "NumPy: area by trapezoid rule" },
            { "interp(x, xp, fp, left=\"end\", right=\"end\")", "NumPy: linear interpolation between points" },
            // Working with data
            { "is_nan_each(A)", "NumPy: NaN check per element" },
            { "is_inf(A)", "NumPy: infinity check per element" },
            { "is_finite(A)", "NumPy: finite check per element" },
            { "is_posinf(A)", "NumPy: plus-infinity check per element" },
            { "is_neginf(A)", "NumPy: minus-infinity check per element" },
            { "[values, indices, inverse, counts] = unique_all(A)", "NumPy: distinct values with counts" },
            { "fill_nan(A, value=0, method=\"value\", axis=-1)", "NumPy: fill missing NaN values" },
            { "str_concat(a, b)", "NumPy: join two texts" },
            { "split_str(s, sep=\"\", maxsplit=-1)", "NumPy: split text into parts" },
            { "join(sep, texts)", "NumPy: join texts with separator" },
            { "strip(T, chars=\"\")", "NumPy: trim characters at both ends" },
            { "find_str(T, sub)", "NumPy: first position of substring" },
            { "count_str(T, sub)", "NumPy: count substring occurrences" },
            { "starts_with(T, prefix)", "NumPy: text starts with prefix" },
            { "ends_with(T, suffix)", "NumPy: text ends with suffix" },
            { "center(T, width, fill=\" \")", "NumPy: center text in width" },
            { "zfill(T, width)", "NumPy: pad with leading zeros" },
            { "is_digit(T)", "NumPy: text is all digits" },
            { "str_len(T)", "NumPy: number of characters" },
    };
}
