package language.syntax.textcolours;

import java.util.LinkedHashSet;
import java.util.Set;

import language.syntax.syntax_checker.functions.BuiltinSignatures;

/**
 * DATA I/O FUNCTIONS -- class {@code tc-data-io}.
 *
 * <p>
 * The {@code read_*}, {@code load_*}, {@code save_*} and {@code io_*}
 * functions of {@code nc.exe}'s {@code importing_data} section
 * ({@code docs/IO_Phase1_Frontend_Handover.md},
 * {@code IO_Phase2_3_Frontend_Handover.md}), plus the two older workspace
 * functions of the same shape. Coloured only where called, {@code read_csv(},
 * so a variable named {@code load_data} keeps the variable colour. Colour: the
 * {@code .tc-data-io} block in {@code themes/texts/text_light.css} and
 * {@code text_dark.css}.
 * </p>
 *
 * <p>
 * The names are not listed here: they are the rows of the usage table
 * ({@code builtin_signatures.tsv}) whose section is {@link #SECTION}, so a new
 * table from {@code nc.exe} brings new formats with no edit. Their pattern
 * stands before the function-call one in {@code UPITokenMaker}, so it wins;
 * they stay in the function-call set, which the checker also reads.
 * </p>
 */
public final class DataIoFunctions {

    private DataIoFunctions() {
    }

    /** The usage table's section of the I/O functions. */
    public static final String SECTION = "importing_data";

    /** Older functions of the same shape that take the same colour. */
    public static final String[] WORKSPACE_WORDS = {
            "load_workspace", "save_workspace"
    };

    /** @return every name painted in the Data I/O colour where called */
    public static Set<String> names() {
        Set<String> names = new LinkedHashSet<>();
        for (BuiltinSignatures.Signature sig : BuiltinSignatures.all()) {
            if (SECTION.equals(sig.section())) {
                names.add(sig.name());
            }
        }
        names.addAll(Set.of(WORKSPACE_WORDS));
        return names;
    }
}
