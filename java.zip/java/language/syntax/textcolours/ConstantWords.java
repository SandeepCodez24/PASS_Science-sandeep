package language.syntax.textcolours;

/**
 * CONSTANTS -- class {@code tc-constant}.
 *
 * <p>
 * The named constants {@code nc.exe} resolves itself
 * ({@code runtime/interpreter/builtins/constants_builtin.cpp}): the long
 * names and their aliases. Names are case-sensitive there, so they are here:
 * {@code pi} is a constant, {@code PI} is not. A script that assigns one of
 * these names ({@code e = 5}, {@code for e in ...}, an input named {@code e})
 * makes it an ordinary variable for the whole file, and it takes the
 * variable colour ({@code SyntaxPalette#assignedNames}). Colour: the
 * {@code .tc-constant} block in {@code themes/texts/text_light.css} and
 * {@code text_dark.css}.
 * </p>
 *
 * <p>
 * The undefined-name check reads this list too
 * ({@code UndefinedVariableAnalyzer}), so a constant added here is known
 * everywhere at once. The physical units ({@code m s kg N Pa}) are not
 * constants of this kind and keep the variable colour.
 * </p>
 */
public final class ConstantWords {

    private ConstantWords() {
    }

    /** Whole words, exactly as nc.exe spells them. */
    public static final String[] WORDS = {
            // mathematics
            "pi", "π", "e", "euler_gamma", "nan", "inf",
            // physics
            "gravity", "gas_constant", "avogadro",
            "planck", "planck_constant",
            "sigma", "σ", "stefan_boltzmann",
            "k_e", "ke", "coulomb_const",
            "m_e", "me", "electron_mass",
            "m_p", "mp", "proton_mass",
            "e_charge", "echarge", "elementary_charge",
            "grav_const", "gravitational_constant",
            // universal constants: what \con(\token) inserts (Uniconstant)
            "uc_pi", "uc_gravity", "uc_gasconst", "uc_avogadro", "uc_planck", "uc_hbar",
            "uc_gravitational", "uc_stefanboltzmann", "uc_coulomb",
            "uc_electronmass", "uc_protonmass", "uc_neutronmass", "uc_molarmass",
            "uc_elementarycharge", "uc_faraday", "uc_speedoflight", "uc_boltzmann",
            "uc_vacuumpermittivity", "uc_vacuumpermeability", "uc_finestructure",
            "uc_rydberg", "uc_bohrradius", "uc_hartreeenergy", "uc_magneticfluxquantum"
    };
}
