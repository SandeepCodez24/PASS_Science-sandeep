package language.language_engine;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import ui.ui_functions.FunctionEvaluator;

public final class VariableFileWriter {

    private static final Pattern RANGE_PATTERN = Pattern.compile(
            "^(?<start>[+-]?\\d+(?:\\.\\d+)?)\\s*:\\s*(?<end>[+-]?\\d+(?:\\.\\d+)?)\\s*:\\s*(?<step>[+-]?\\d+(?:\\.\\d+)?)$");
    private static final Pattern NUMBER_TOKEN = Pattern.compile("[+-]?(?:\\d+\\.\\d+|\\d+)(?:[eE][+-]?\\d+)?");
    private static final Pattern INTEGER_TOKEN = Pattern.compile("[+-]?\\d+");

    private VariableFileWriter() {
    }

    public static void writeVariablesFile(String cleanedCode, Path variableFilePath) throws IOException {
        List<VariableEntry> variables = extractVariables(cleanedCode);
        Files.writeString(
                variableFilePath,
                buildDictionary(variables),
                StandardOpenOption.CREATE,
                StandardOpenOption.TRUNCATE_EXISTING);
    }

    public static void writeJavaDictionaryFile(String cleanedCode, Path javaDictionaryFilePath) throws IOException {
        List<RangeDictionaryEntry> rangeEntries = extractRangeDictionaryEntries(cleanedCode);
        List<MatrixDictionaryEntry> matrixEntries = extractMatrixDictionaryEntries(cleanedCode);

        StringBuilder combined = new StringBuilder();
        combined.append(buildRangeDictionary(rangeEntries)).append(System.lineSeparator());
        combined.append(buildMatrixDictionary(matrixEntries));

        Files.writeString(
                javaDictionaryFilePath,
                combined.toString(),
                StandardOpenOption.CREATE,
                StandardOpenOption.TRUNCATE_EXISTING);
    }

    private static String buildRangeDictionary(List<RangeDictionaryEntry> entries) {
        StringBuilder dictionary = new StringBuilder();
        dictionary.append("list_distionary = {").append(System.lineSeparator());

        for (int i = 0; i < entries.size(); i++) {
            RangeDictionaryEntry entry = entries.get(i);
            dictionary.append("    ")
                    .append(entry.variableName)
                    .append("={")
                    .append(System.lineSeparator());
            dictionary.append("        ")
                    .append(entry.originalExpression)
                    .append(" : ")
                    .append(formatJavaListInitializer(entry.expandedValues))
                    .append(System.lineSeparator());
            dictionary.append("    }");
            if (i < entries.size() - 1) {
                dictionary.append(',');
            }
            dictionary.append(System.lineSeparator());
        }

        dictionary.append('}').append(System.lineSeparator());
        return dictionary.toString();
    }

    private static String formatJavaListInitializer(List<String> values) {
        return "List<" + inferJavaListElementType(values) + "> list = Arrays.asList(" + String.join(", ", values)
                + ");";
    }

    private static String buildDictionary(List<VariableEntry> variables) {
        StringBuilder dictionary = new StringBuilder();
        dictionary.append("Data = {").append(System.lineSeparator());

        for (int i = 0; i < variables.size(); i++) {
            VariableEntry entry = variables.get(i);
            dictionary.append("    ")
                    .append(quote(entry.name))
                    .append(": {")
                    .append(System.lineSeparator());
            dictionary.append("        \"size\": ")
                    .append(quote(entry.shape))
                    .append(",")
                    .append(System.lineSeparator());
            dictionary.append("        \"type\": ")
                    .append(quote(entry.type))
                    .append(",")
                    .append(System.lineSeparator());
            dictionary.append("        \"value\": ")
                    .append(formatLiteral(entry.value))
                    .append(System.lineSeparator());
            dictionary.append("    }");
            if (i < variables.size() - 1) {
                dictionary.append(',');
            }
            dictionary.append(System.lineSeparator());
        }

        dictionary.append('}').append(System.lineSeparator());
        return dictionary.toString();
    }

    private static String buildMatrixDictionary(List<MatrixDictionaryEntry> entries) {
        StringBuilder dictionary = new StringBuilder();
        dictionary.append("matrix_distionary = {").append(System.lineSeparator());

        for (int i = 0; i < entries.size(); i++) {
            MatrixDictionaryEntry entry = entries.get(i);
            dictionary.append("    ")
                    .append(entry.variableName)
                    .append("={")
                    .append(System.lineSeparator());
            dictionary.append("        ")
                    .append(entry.originalExpression)
                    .append(" : ")
                    .append(formatJavaMatrixInitializer(entry.rows))
                    .append(System.lineSeparator());
            dictionary.append("    }");
            if (i < entries.size() - 1) {
                dictionary.append(',');
            }
            dictionary.append(System.lineSeparator());
        }

        dictionary.append('}').append(System.lineSeparator());
        return dictionary.toString();
    }

    private static String formatJavaMatrixInitializer(List<List<String>> rows) {
        return inferJavaMatrixType(rows) + " matrix = " + buildArrayInitializer(rows) + ";";
    }

    private static String inferJavaMatrixType(List<List<String>> rows) {
        if (rows == null || rows.isEmpty()) {
            return "int[][]";
        }
        boolean hasDecimal = false;
        boolean hasNonNumeric = false;
        for (List<String> row : rows) {
            if (row == null) {
                hasNonNumeric = true;
                continue;
            }

            for (String value : row) {
                if (value == null) {
                    hasNonNumeric = true;
                    continue;
                }

                String trimmed = value.trim();
                if (isWrapped(trimmed, '"', '"') || isWrapped(trimmed, '\'', '\'')) {
                    // quoted string -> prefer String[][]
                    return "String[][]";
                }

                if (!trimmed.matches("[+-]?\\d+")) {
                    // not a plain integer; check if decimal/scientific
                    if (trimmed.matches("[+-]?\\d*\\.\\d+([eE][+-]?\\d+)?")
                            || trimmed.matches("[+-]?\\d+[eE][+-]?\\d+")) {
                        hasDecimal = true;
                    } else {
                        hasNonNumeric = true;
                    }
                }
            }
        }

        if (hasNonNumeric) {
            return "String[][]";
        }
        if (hasDecimal) {
            return "double[][]";
        }
        return "int[][]";
    }

    private static String buildArrayInitializer(List<List<String>> rows) {
        StringBuilder builder = new StringBuilder();
        builder.append("{");
        for (List<String> row : rows) {
            builder.append("{")
                    .append(String.join(",", row))
                    .append("},");
        }
        builder.append("}");
        return builder.toString();
    }

    private static String inferJavaListElementType(List<String> values) {
        if (values == null || values.isEmpty()) {
            return "Integer";
        }

        for (String value : values) {
            if (value == null) {
                return "Double";
            }

            String trimmed = value.trim();
            if (!trimmed.matches("[+-]?\\d+")) {
                return "Double";
            }
        }

        return "Integer";
    }

    private static boolean containsQuotedString(String value) {
        return value != null && (value.contains("\"") || value.contains("'"));
    }

    private static boolean containsIntegerNumber(String value) {
        if (value == null)
            return false;
        Matcher matcher = NUMBER_TOKEN.matcher(value);
        while (matcher.find()) {
            String token = matcher.group();
            if (!token.contains(".") && !token.contains("e") && !token.contains("E")) {
                return true;
            }
        }
        return false;
    }

    private static boolean containsDecimalNumber(String value) {
        if (value == null)
            return false;
        Matcher matcher = NUMBER_TOKEN.matcher(value);
        while (matcher.find()) {
            String token = matcher.group();
            if (token.contains(".") || token.contains("e") || token.contains("E")) {
                return true;
            }
        }
        return false;
    }

    private static String quote(String value) {
        return "\"" + escape(value) + "\"";
    }

    private static String escape(String value) {
        if (value == null) {
            return "";
        }

        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private static String formatLiteral(String value) {
        if (value == null) {
            return "null";
        }

        String trimmed = value.trim();
        if (trimmed.isEmpty()) {
            return quote("");
        }

        if (trimmed.equalsIgnoreCase("true") || trimmed.equalsIgnoreCase("false")
                || trimmed.equalsIgnoreCase("null")) {
            return trimmed.toLowerCase();
        }

        if (trimmed.matches("[+-]?\\d+")) {
            return trimmed;
        }

        if (trimmed.matches("[+-]?\\d*\\.\\d+([eE][+-]?\\d+)?")
                || trimmed.matches("[+-]?\\d+[eE][+-]?\\d+")) {
            return trimmed;
        }

        if (isWrapped(trimmed, '[', ']')) {
            return trimmed;
        }

        return quote(trimmed);
    }

    private static List<VariableEntry> extractVariables(String cleanedCode) {
        List<VariableEntry> variables = new ArrayList<>();
        java.util.Map<String, String> variableValues = new java.util.LinkedHashMap<>();

        if (cleanedCode == null || cleanedCode.isEmpty()) {
            return variables;
        }

        String[] lines = cleanedCode.split("\\R", -1);
        for (String rawLine : lines) {
            String line = rawLine.trim();
            if (line.isEmpty()) {
                continue;
            }

            int equalsIndex = indexOfAssignment(line);
            if (equalsIndex < 0) {
                continue;
            }

            String left = line.substring(0, equalsIndex);
            String right = line.substring(equalsIndex + 1);
            if (right.endsWith(";")) {
                right = right.substring(0, right.length() - 1);
            }

            if (!left.isEmpty() && !right.isEmpty()) {
                String originalRight = right.trim();
                // Evaluate function calls to get actual computed values
                // Pass previously defined variables for substitution
                String evaluatedRight = FunctionEvaluator.evaluateFunction(originalRight, variableValues);
                String normalizedRight = normalizeValue(evaluatedRight);
                String type = inferType(normalizedRight, variableValues.keySet());
                // Store the evaluated value (computed result) instead of the function call
                String varName = left.trim();
                variables.add(new VariableEntry(varName, type, inferShape(normalizedRight), evaluatedRight));
                // Store this variable's value for use in subsequent expressions
                variableValues.put(varName, evaluatedRight);
            }
        }

        return variables;
    }

    private static final class VariableEntry {
        private final String name;
        private final String type;
        private final String shape;
        private final String value;

        private VariableEntry(String name, String type, String shape, String value) {
            this.name = name;
            this.type = type;
            this.shape = shape;
            this.value = value;
        }
    }

    private static final class RangeDictionaryEntry {
        private final String variableName;
        private final String originalExpression;
        private final List<String> expandedValues;

        private RangeDictionaryEntry(String variableName, String originalExpression, List<String> expandedValues) {
            this.variableName = variableName;
            this.originalExpression = originalExpression;
            this.expandedValues = expandedValues;
        }
    }

    private static final class MatrixDictionaryEntry {
        private final String variableName;
        private final String originalExpression;
        private final List<List<String>> rows;

        private MatrixDictionaryEntry(String variableName, String originalExpression, List<List<String>> rows) {
            this.variableName = variableName;
            this.originalExpression = originalExpression;
            this.rows = rows;
        }
    }

    private static List<MatrixDictionaryEntry> extractMatrixDictionaryEntries(String cleanedCode) {
        List<MatrixDictionaryEntry> entries = new ArrayList<>();
        if (cleanedCode == null || cleanedCode.isEmpty()) {
            return entries;
        }

        String[] lines = cleanedCode.split("\\R", -1);
        for (String rawLine : lines) {
            String line = rawLine.trim();
            if (line.isEmpty()) {
                continue;
            }

            int equalsIndex = indexOfAssignment(line);
            if (equalsIndex < 0) {
                continue;
            }

            String left = line.substring(0, equalsIndex).trim();
            String right = line.substring(equalsIndex + 1).trim();
            if (right.endsWith(";")) {
                right = right.substring(0, right.length() - 1).trim();
            }

            if (left.isEmpty() || right.isEmpty()) {
                continue;
            }

            List<List<String>> rows = parseMatrixRows(right);
            if (rows == null) {
                continue;
            }

            entries.add(new MatrixDictionaryEntry(left, right, rows));
        }

        return entries;
    }

    private static List<List<String>> parseMatrixRows(String value) {
        if (value == null) {
            return null;
        }

        String trimmed = value.trim();
        if (!isWrapped(trimmed, '[', ']')) {
            return null;
        }

        String inner = trimmed.substring(1, trimmed.length() - 1).trim();
        if (inner.isEmpty() || !inner.contains(";")) {
            return null;
        }

        List<String> rowTokens = splitTopLevelSemicolon(inner);
        List<List<String>> rows = new ArrayList<>();
        for (String rowToken : rowTokens) {
            String row = rowToken.trim();
            if (row.isEmpty()) {
                continue;
            }

            List<String> cells = splitTopLevelComma(row);
            if (cells.isEmpty()) {
                return null;
            }

            List<String> normalized = new ArrayList<>();
            for (String cell : cells) {
                String normalizedCell = cell.trim();
                if (normalizedCell.isEmpty()) {
                    return null;
                }
                normalized.add(normalizedCell);
            }

            rows.add(normalized);
        }

        if (rows.isEmpty()) {
            return null;
        }

        int expectedCols = rows.get(0).size();
        if (expectedCols == 0) {
            return null;
        }

        for (List<String> row : rows) {
            if (row.size() != expectedCols) {
                return null;
            }
        }

        return rows;
    }

    private static List<String> splitTopLevelSemicolon(String content) {
        List<String> parts = new ArrayList<>();
        if (content == null) {
            return parts;
        }

        int depthParen = 0;
        int depthBracket = 0;
        int depthBrace = 0;
        int start = 0;
        for (int i = 0; i < content.length(); i++) {
            char ch = content.charAt(i);
            switch (ch) {
                case '(':
                    depthParen++;
                    break;
                case ')':
                    depthParen = Math.max(0, depthParen - 1);
                    break;
                case '[':
                    depthBracket++;
                    break;
                case ']':
                    depthBracket = Math.max(0, depthBracket - 1);
                    break;
                case '{':
                    depthBrace++;
                    break;
                case '}':
                    depthBrace = Math.max(0, depthBrace - 1);
                    break;
                case ';':
                    if (depthParen == 0 && depthBracket == 0 && depthBrace == 0) {
                        String token = content.substring(start, i).trim();
                        if (!token.isEmpty()) {
                            parts.add(token);
                        }
                        start = i + 1;
                    }
                    break;
                default:
                    break;
            }
        }

        String tail = content.substring(start).trim();
        if (!tail.isEmpty()) {
            parts.add(tail);
        }

        return parts;
    }

    private static List<RangeDictionaryEntry> extractRangeDictionaryEntries(String cleanedCode) {
        List<RangeDictionaryEntry> entries = new ArrayList<>();
        if (cleanedCode == null || cleanedCode.isEmpty()) {
            return entries;
        }

        String[] lines = cleanedCode.split("\\R", -1);
        for (String rawLine : lines) {
            String line = rawLine.trim();
            if (line.isEmpty()) {
                continue;
            }

            int equalsIndex = indexOfAssignment(line);
            if (equalsIndex < 0) {
                continue;
            }

            String left = line.substring(0, equalsIndex).trim();
            String right = line.substring(equalsIndex + 1).trim();
            if (right.endsWith(";")) {
                right = right.substring(0, right.length() - 1).trim();
            }

            if (left.isEmpty() || right.isEmpty()) {
                continue;
            }

            List<String> expanded = expandRange(right);
            if (expanded == null) {
                continue;
            }

            entries.add(new RangeDictionaryEntry(left, right, expanded));
        }

        return entries;
    }

    private static String inferType(String value, Set<String> knownVariables) {
        if (value == null) {
            return "unknown";
        }

        String trimmed = value.trim();
        if (trimmed.isEmpty()) {
            return "unknown";
        }

        // Collections / ranges: determine element type -> prefer string, then float,
        // then int
        if (isRangeExpression(trimmed) || isWrapped(trimmed, '[', ']') || isWrapped(trimmed, '(', ')')
                || isWrapped(trimmed, '{', '}')) {
            if (containsQuotedString(trimmed)) {
                return "string";
            }
            if (containsDecimalNumber(trimmed)) {
                return "float";
            }
            if (containsIntegerNumber(trimmed)) {
                return "int";
            }
            return "list";
        }

        if ((trimmed.startsWith("\"") && trimmed.endsWith("\""))
                || (trimmed.startsWith("'") && trimmed.endsWith("'"))) {
            return "string";
        }

        if (trimmed.equalsIgnoreCase("true") || trimmed.equalsIgnoreCase("false")) {
            return "boolean";
        }

        if (trimmed.matches("[+-]?\\d+")) {
            return "int";
        }

        if (trimmed.matches("[+-]?\\d*\\.\\d+([eE][+-]?\\d+)?")
                || trimmed.matches("[+-]?\\d+[eE][+-]?\\d+")) {
            return "float";
        }

        if (trimmed.matches("[A-Za-z_][A-Za-z0-9_]*") && knownVariables.contains(trimmed)) {
            return "variable";
        }

        return "expression";
    }

    private static String inferShape(String value) {
        if (value == null) {
            return "1x1";
        }

        String trimmed = value.trim();
        if (trimmed.isEmpty()) {
            return "1x1";
        }

        if (isWrapped(trimmed, '[', ']')) {
            String inner = trimmed.substring(1, trimmed.length() - 1).trim();

            // Case 1: bracketed rows like [[1,2,3],[4,5,6]]
            List<String> topLevel = splitTopLevelComma(inner);
            boolean looksLikeBracketedRows = !topLevel.isEmpty()
                    && topLevel.stream().allMatch(p -> isWrapped(p.trim(), '[', ']'));
            if (looksLikeBracketedRows) {
                boolean allRows = true;
                int expectedCols = -1;
                for (String part : topLevel) {
                    String row = part.trim();
                    if (!isWrapped(row, '[', ']')) {
                        allRows = false;
                        break;
                    }

                    List<String> cols = splitTopLevelComma(row.substring(1, row.length() - 1));
                    int colCount = Math.max(1, cols.size());
                    if (expectedCols == -1) {
                        expectedCols = colCount;
                    } else if (expectedCols != colCount) {
                        allRows = false;
                        break;
                    }
                }

                if (allRows) {
                    return topLevel.size() + "x" + (expectedCols <= 0 ? 1 : expectedCols);
                }

                // If top-level comma splitting did not look like bracketed rows, fall through
                // to semicolon-based row detection below.
                // (do not return 1xN here)
            }

            // Case 2: single-dimensional list like [10, 11, 12] or a range expansion
            // normalized into a list form by normalizeValue().
            if (!inner.isEmpty()) {
                List<String> values = splitTopLevelComma(inner);
                if (!values.isEmpty()) {
                    return "1x" + values.size();
                }
            }

            // Case 2: semicolon-separated rows inside single bracket: [1,2;3,4;]
            if (inner.contains(";")) {
                List<String> rowTokens = splitTopLevelSemicolon(inner);
                if (!rowTokens.isEmpty()) {
                    int rows = 0;
                    int cols = -1;
                    boolean valid = true;
                    for (String rt : rowTokens) {
                        String r = rt.trim();
                        if (r.isEmpty()) {
                            continue;
                        }
                        List<String> cells = splitTopLevelComma(r);
                        if (cells.isEmpty()) {
                            valid = false;
                            break;
                        }
                        if (cols == -1) {
                            cols = cells.size();
                        } else if (cols != cells.size()) {
                            valid = false;
                            break;
                        }
                        rows++;
                    }
                    if (valid && rows > 0 && cols > 0) {
                        return rows + "x" + cols;
                    }
                }
            }

            return "1x1";
        }

        if (isWrapped(trimmed, '(', ')') || isWrapped(trimmed, '{', '}')) {
            List<String> values = splitTopLevelComma(trimmed.substring(1, trimmed.length() - 1));
            return "1x" + Math.max(1, values.size());
        }

        return "1x1";
    }

    private static String normalizeValue(String value) {
        if (value == null) {
            return null;
        }

        String trimmed = value.trim();
        List<String> rangeValues = expandRange(trimmed);
        if (rangeValues != null) {
            return "[" + String.join(", ", rangeValues) + "]";
        }

        return trimmed;
    }

    private static boolean isRangeExpression(String value) {
        return expandRange(value) != null;
    }

    private static List<String> expandRange(String value) {
        if (value == null) {
            return null;
        }

        String trimmed = value.trim();
        boolean exclusive = false;
        String inner = trimmed;
        if (isWrapped(trimmed, '(', ')')) {
            exclusive = true;
            inner = trimmed.substring(1, trimmed.length() - 1).trim();
        }

        Matcher matcher = RANGE_PATTERN.matcher(inner);
        if (!matcher.matches()) {
            return null;
        }

        BigDecimal start = new BigDecimal(matcher.group("start"));
        BigDecimal end = new BigDecimal(matcher.group("end"));
        BigDecimal step = new BigDecimal(matcher.group("step"));
        if (step.compareTo(BigDecimal.ZERO) == 0) {
            return null;
        }

        int direction = step.signum();
        if ((direction > 0 && start.compareTo(end) > 0) || (direction < 0 && start.compareTo(end) < 0)) {
            return null;
        }

        List<String> values = new ArrayList<>();
        BigDecimal current = exclusive ? start.add(step) : start;
        while (shouldInclude(current, end, step, exclusive)) {
            values.add(formatNumber(current));
            current = current.add(step);
        }

        return values;
    }

    private static boolean shouldInclude(BigDecimal current, BigDecimal end, BigDecimal step, boolean exclusive) {
        int comparison = current.compareTo(end);
        if (step.signum() > 0) {
            return exclusive ? comparison < 0 : comparison <= 0;
        }

        return exclusive ? comparison > 0 : comparison >= 0;
    }

    private static String formatNumber(BigDecimal value) {
        return value.stripTrailingZeros().toPlainString();
    }

    private static boolean isWrapped(String value, char open, char close) {
        return value != null
                && value.length() >= 2
                && value.charAt(0) == open
                && value.charAt(value.length() - 1) == close;
    }

    private static List<String> splitTopLevelComma(String content) {
        List<String> parts = new ArrayList<>();
        if (content == null) {
            return parts;
        }

        String trimmed = content.trim();
        if (trimmed.isEmpty()) {
            return parts;
        }

        int depthParen = 0;
        int depthBracket = 0;
        int depthBrace = 0;
        int start = 0;
        for (int i = 0; i < content.length(); i++) {
            char ch = content.charAt(i);
            switch (ch) {
                case '(':
                    depthParen++;
                    break;
                case ')':
                    depthParen = Math.max(0, depthParen - 1);
                    break;
                case '[':
                    depthBracket++;
                    break;
                case ']':
                    depthBracket = Math.max(0, depthBracket - 1);
                    break;
                case '{':
                    depthBrace++;
                    break;
                case '}':
                    depthBrace = Math.max(0, depthBrace - 1);
                    break;
                case ',':
                    if (depthParen == 0 && depthBracket == 0 && depthBrace == 0) {
                        String token = content.substring(start, i).trim();
                        if (!token.isEmpty()) {
                            parts.add(token);
                        }
                        start = i + 1;
                    }
                    break;
                default:
                    break;
            }
        }

        String tail = content.substring(start).trim();
        if (!tail.isEmpty()) {
            parts.add(tail);
        }

        return parts;
    }

    private static int indexOfAssignment(String line) {
        int equalsIndex = line.indexOf('=');
        if (equalsIndex < 0) {
            return -1;
        }
        if (equalsIndex + 1 < line.length() && line.charAt(equalsIndex + 1) == '=') {
            return -1;
        }
        if (equalsIndex > 0 && line.charAt(equalsIndex - 1) == '=') {
            return -1;
        }
        return equalsIndex;
    }

}