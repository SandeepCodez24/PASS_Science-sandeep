package language.language_engine;

import java.util.HashMap;
import java.util.Map;

public class UPIEngine {

    public static String execute(String code) {
        StringBuilder output = new StringBuilder();
        Map<String, String> variables = new HashMap<>();

        // Split code into lines
        String[] lines = code.split("\\r?\\n");

        for (String rawLine : lines) {
            String line = rawLine.trim();

            // Ignore empty lines
            if (line.isEmpty()) continue;

            // ---------- PRINT ----------
            if (line.startsWith("publish")) {
                int start = line.indexOf('(');
                int end = line.lastIndexOf(')');

                if (start == -1 || end == -1 || end <= start) {
                    output.append("✖ Syntax error in publish\n");
                    continue;
                }

                String content = line.substring(start + 1, end).trim();
                content = evaluateValue(content, variables);
                output.append(content).append("\n");
            }

            // ---------- XXXX OUTPUT ----------
            else if (line.startsWith("Xxx")) {
                int start = line.indexOf('(');
                int end = line.lastIndexOf(')');

                if (start == -1 || end == -1 || end <= start) {
                    output.append("✖ Syntax error in Xxx\n");
                    continue;
                }

                String content = line.substring(start + 1, end).trim();
                content = evaluateValue(content, variables);
                output.append(content).append("\n");
            }

            // ---------- ASSIGNMENT ----------
            else if (line.contains("=")) {
                String[] parts = line.split("=", 2);
                if (parts.length == 2) {
                    String varName = parts[0].trim();
                    String value = parts[1].trim();
                    // Remove comments and semicolons
                    value = stripTrailingComment(value).trim();
                    value = value.replaceAll(";$", "").trim();
                    variables.put(varName, evaluateValue(value, variables));
                    // Don't output anything for assignments
                } else {
                    output.append("✖ Syntax error in assignment\n");
                }
            }

            // ---------- VARIABLE REFERENCE ----------
            else if (variables.containsKey(line)) {
                output.append(evaluateValue(line, variables)).append("\n");
            }

            // ---------- EXPRESSION ----------
            else {
                String evaluated = evaluateExpression(line, variables);
                if (evaluated != null) {
                    output.append(evaluated).append("\n");
                } else {
                    output.append("✖ Unknown statement: ").append(line).append("\n");
                }
            }
        }

        return output.toString();
    }

    private static String evaluateValue(String value, Map<String, String> variables) {
        if (value == null || value.isEmpty()) {
            return "";
        }

        String trimmed = value.trim();
        String resolvedValue = resolveVariable(trimmed, variables);

        if (resolvedValue != null && !resolvedValue.isEmpty()) {
            trimmed = resolvedValue;
        }

        if (trimmed.startsWith("\"") && trimmed.endsWith("\"") && trimmed.length() >= 2) {
            return trimmed.substring(1, trimmed.length() - 1);
        }
        if (trimmed.startsWith("'") && trimmed.endsWith("'") && trimmed.length() >= 2) {
            return trimmed.substring(1, trimmed.length() - 1);
        }

        String expressionResult = evaluateExpression(trimmed, variables);
        if (expressionResult != null) {
            return expressionResult;
        }

        return trimmed;
    }

    private static String evaluateExpression(String expression, Map<String, String> variables) {
        if (expression == null || expression.trim().isEmpty()) {
            return null;
        }

        ExpressionParser parser = new ExpressionParser(expression.trim(), variables);
        try {
            double result = parser.parseExpression();
            if (Double.isFinite(result)) {
                if (result == Math.rint(result)) {
                    return String.valueOf((long) result);
                }
                return String.valueOf(result);
            }
        } catch (Exception ignored) {
            // Fall through to return null if parsing fails.
        }
        return null;
    }

    private static String resolveVariable(String token, Map<String, String> variables) {
        if (token == null || token.isEmpty()) {
            return token;
        }

        String current = token;
        java.util.Set<String> seen = new java.util.HashSet<>();

        while (variables.containsKey(current) && !seen.contains(current)) {
            seen.add(current);
            current = variables.get(current);
        }

        return current;
    }

    private static String stripWrappingQuotes(String value) {
        if (value == null) {
            return "";
        }

        String trimmed = value.trim();
        if ((trimmed.startsWith("\"") && trimmed.endsWith("\""))
                || (trimmed.startsWith("'") && trimmed.endsWith("'"))) {
            if (trimmed.length() >= 2) {
                return trimmed.substring(1, trimmed.length() - 1);
            }
        }

        return trimmed;
    }

    private static String stripTrailingComment(String line) {
        boolean inQuote = false;

        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (ch == '"' && !isEscaped(line, i)) {
                inQuote = !inQuote;
                continue;
            }

            if (!inQuote) {
                if (ch == '#') {
                    return line.substring(0, i);
                }
                if (ch == '\\' && i + 1 < line.length() && line.charAt(i + 1) == '\\') {
                    return line.substring(0, i);
                }
            }
        }

        return line;
    }

    private static boolean isEscaped(String text, int index) {
        int backslashCount = 0;
        int i = index - 1;
        while (i >= 0 && text.charAt(i) == '\\') {
            backslashCount++;
            i--;
        }
        return backslashCount % 2 != 0;
    }

    private static final class ExpressionParser {
        private final String input;
        private final Map<String, String> variables;
        private int pos;

        ExpressionParser(String input, Map<String, String> variables) {
            this.input = input;
            this.variables = variables;
            this.pos = 0;
        }

        double parseExpression() {
            double value = parseTerm();
            while (true) {
                skipWhitespace();
                if (match('+')) {
                    value += parseTerm();
                } else if (match('-')) {
                    value -= parseTerm();
                } else {
                    break;
                }
            }
            skipWhitespace();
            if (pos < input.length()) {
                throw new IllegalArgumentException("Unexpected character: " + input.charAt(pos));
            }
            return value;
        }

        private double parseTerm() {
            double value = parseFactor();
            while (true) {
                skipWhitespace();
                if (match('*')) {
                    value *= parseFactor();
                } else if (match('/')) {
                    value /= parseFactor();
                } else {
                    break;
                }
            }
            return value;
        }

        private double parseFactor() {
            skipWhitespace();
            if (match('+')) {
                return parseFactor();
            }
            if (match('-')) {
                return -parseFactor();
            }
            if (match('(')) {
                double value = parseExpression();
                if (!match(')')) {
                    throw new IllegalArgumentException("Missing closing parenthesis");
                }
                return value;
            }
            int start = pos;
            if (peek() == '.' || Character.isDigit(peek())) {
                while (peek() == '.' || Character.isDigit(peek())) {
                    pos++;
                }
                String number = input.substring(start, pos);
                return Double.parseDouble(number);
            }
            if (Character.isLetter(peek()) || peek() == '_') {
                while (Character.isLetterOrDigit(peek()) || peek() == '_') {
                    pos++;
                }
                String identifier = input.substring(start, pos);
                String resolved = resolveVariable(identifier, variables);
                if (resolved == null || resolved.isEmpty()) {
                    throw new IllegalArgumentException("Unknown identifier: " + identifier);
                }
                String numeric = stripWrappingQuotes(resolved);
                return Double.parseDouble(numeric);
            }
            throw new IllegalArgumentException("Unexpected token: " + peek());
        }

        private void skipWhitespace() {
            while (pos < input.length() && Character.isWhitespace(input.charAt(pos))) {
                pos++;
            }
        }

        private boolean match(char expected) {
            skipWhitespace();
            if (pos < input.length() && input.charAt(pos) == expected) {
                pos++;
                return true;
            }
            return false;
        }

        private char peek() {
            if (pos >= input.length()) {
                return '\0';
            }
            return input.charAt(pos);
        }
    }
}
