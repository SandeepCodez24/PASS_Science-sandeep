package application;

import javafx.application.Application;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import ui.UI_Main;
import ui.design.Dim;
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
public class Main extends Application {

    private static final String WINDOW_TITLE = "Neural Code";

    // Title-bar / taskbar logo. Loaded from the classpath, so the
    // "src/main/resources" prefix is dropped and the path starts at
    // "/icons/...". Note: the extension is case-sensitive inside a JAR,
    // so this must match the real file name exactly (.PNG here).
    private static final String APP_ICON = "/icons/ic_18_nc.PNG";

    @Override
    public void start(Stage stage) {
        UI_Main mainUi = new UI_Main(stage);

        stage.setTitle(WINDOW_TITLE);
        stage.setScene(mainUi.getScene());

        // The ribbon collapses compartments and hides the search box rather
        // than cutting labels, but the six tabs and the action cluster can
        // only shrink so far. The minimum keeps them on screen.
        stage.setMinWidth(Dim.Window.MIN_WIDTH);
        stage.setMinHeight(Dim.Window.MIN_HEIGHT);

        // Set the Neural Code logo in the title bar (and taskbar).
        applyAppIcon(stage);

        stage.show();
    }

    // Loads the logo from resources and sets it as the window icon.
    // Fails safe: if the image is missing, we log and continue instead
    // of crashing the whole application at startup.
    private void applyAppIcon(Stage stage) {
        try (var in = Main.class.getResourceAsStream(APP_ICON)) {
            if (in == null) {
                System.err.println("App icon not found on classpath: " + APP_ICON);
                return;
            }
            Image logo = new Image(in);
            stage.getIcons().add(logo);
        } catch (Exception ex) {
            System.err.println("Failed to load app icon: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

