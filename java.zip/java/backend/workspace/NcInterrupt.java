package backend.workspace;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * The IDE's half of the interpreter's cooperative Stop.
 *
 * <p>A process on pipes cannot be sent Ctrl+C on Windows. Instead, Stop
 * creates the empty file {@code <session>/interrupt.flag}. The interpreter
 * looks for it before each statement and on every loop iteration. When it
 * finds the file, it deletes it, unwinds to the prompt keeping every variable
 * assigned so far, and prints "Execution interrupted by user."
 * (runtime/execution/Interrupt.h).
 *
 * <p>The flag belongs to the command that is running. {@link #clear()} is
 * called before every new command is sent, so an old request can never
 * interrupt the next command.
 */
public final class NcInterrupt {

    /** File name the interpreter looks for, inside the session folder. */
    public static final String FLAG_FILE = "interrupt.flag";

    private final Path flag;

    NcInterrupt(Path sessionDirectory) {
        this.flag = sessionDirectory.resolve(FLAG_FILE);
    }

    /**
     * Asks the running command to stop.
     *
     * @return true when the request was placed
     */
    public boolean request() {
        try {
            if (!Files.exists(flag)) {
                Files.createFile(flag);
            }
            return true;
        } catch (IOException e) {
            return Files.exists(flag);
        }
    }

    /** @return true while a request has not yet been picked up by the interpreter */
    public boolean isPending() {
        return Files.exists(flag);
    }

    /** Withdraws a request that has not been picked up. */
    public void clear() {
        try {
            Files.deleteIfExists(flag);
        } catch (IOException ignored) {
            // The interpreter also clears the flag before every prompt.
        }
    }
}
