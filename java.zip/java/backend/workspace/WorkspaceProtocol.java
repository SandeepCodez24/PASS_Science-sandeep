package backend.workspace;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * The IDE side of the interpreter's workspace protocol, version 1. The C++
 * side is {@code runtime/data/DataEngine.cpp}; the contract both sides follow
 * is {@code runtime/data/WS_PROTOCOL.md}.
 *
 * <p>Interpreter to IDE: lines that start with the ASCII Record Separator
 * ({@link #RECORD_SEPARATOR}), then a keyword ({@link #WS} or {@link #VAR}),
 * one space, and one line of JSON.
 *
 * <p>IDE to interpreter: the command lines built by {@link #workspaceNowCommand()},
 * {@link #getVariableCommand(String)} and {@link #clearVariableCommand(String)}.
 */
public final class WorkspaceProtocol {

    /** Starts every protocol line. Program output never contains it. */
    public static final char RECORD_SEPARATOR = '\u001E';

    /** Workspace summary: the complete list of variables. */
    public static final String WS = "@WS";

    /** One variable's full value, sent on request. */
    public static final String VAR = "@VAR";

    /** The protocol version this IDE understands. */
    public static final int VERSION = 1;

    private WorkspaceProtocol() {
    }

    // =====================================================================
    // Messages
    // =====================================================================

    /**
     * One row of the workspace summary.
     *
     * @param name    the variable's (cleaned) name
     * @param cls     its class: double, int64, bool, string, complex, cell, dict, a class name, ...
     * @param size    "1x1", "1x5", "3x4"
     * @param unit    physical unit text such as "m/s", or empty
     * @param preview display text, already length-capped by the interpreter
     * @param hash    content fingerprint (16 hex digits); equal values give equal hashes
     */
    public record VariableSummary(String name, String cls, String size, String unit, String preview,
            String hash) {
    }

    /**
     * The full value of one variable, as requested with
     * {@link #getVariableCommand(String)}.
     *
     * @param name  the variable asked for
     * @param found false when the workspace has no such variable
     * @param cls   its class (see {@link VariableSummary#cls()}), or null if not found
     * @param size  its size, or null if not found
     * @param value the value tree ({@code "k"} = num, int, bool, complex, str,
     *              tensor, cell, cellmatrix, dict, object or func - see
     *              WS_PROTOCOL.md), or null if not found
     */
    public record VariableValue(String name, boolean found, String cls, String size, Map<String, Object> value) {
    }

    /** A parsed protocol line. */
    public sealed interface Message permits WorkspaceMessage, VariableMessage {
    }

    /** @param variables the complete workspace, in assignment order */
    public record WorkspaceMessage(List<VariableSummary> variables) implements Message {
    }

    /** @param variable the variable that was asked for */
    public record VariableMessage(VariableValue variable) implements Message {
    }

    // =====================================================================
    // Parsing
    // =====================================================================

    /**
     * Parses one protocol line: the text after the Record Separator, without
     * the line break.
     *
     * @param line for example {@code @WS {"v":1,...}}
     * @return the message, or null for a keyword this IDE does not know (a
     *         newer interpreter may add some), a newer protocol version, or
     *         malformed JSON
     */
    public static Message parseLine(String line) {
        if (line == null) {
            return null;
        }
        int space = line.indexOf(' ');
        if (space <= 0) {
            return null;
        }
        String keyword = line.substring(0, space);
        String json = line.substring(space + 1);
        try {
            Map<String, Object> obj = Json.parseObject(json);
            if (Json.num(obj, "v", -1) != VERSION) {
                return null;
            }
            if (WS.equals(keyword)) {
                return new WorkspaceMessage(parseSummaries(obj));
            }
            if (VAR.equals(keyword)) {
                return new VariableMessage(parseVariable(obj));
            }
            return null;
        } catch (Json.JsonException e) {
            return null;
        }
    }

    private static List<VariableSummary> parseSummaries(Map<String, Object> obj) {
        List<VariableSummary> out = new ArrayList<>();
        for (Object item : Json.arr(obj, "vars")) {
            if (!(item instanceof Map)) {
                continue;
            }
            @SuppressWarnings("unchecked")
            Map<String, Object> v = (Map<String, Object>) item;
            String name = Json.str(v, "name", null);
            if (name == null || name.isEmpty()) {
                continue;
            }
            out.add(new VariableSummary(name,
                    Json.str(v, "class", ""),
                    Json.str(v, "size", ""),
                    Json.str(v, "unit", ""),
                    Json.str(v, "preview", ""),
                    Json.str(v, "hash", "")));
        }
        return Collections.unmodifiableList(out);
    }

    private static VariableValue parseVariable(Map<String, Object> obj) {
        boolean found = Json.bool(obj, "found", false);
        return new VariableValue(Json.str(obj, "name", ""), found,
                found ? Json.str(obj, "class", "") : null,
                found ? Json.str(obj, "size", "") : null,
                found ? Json.obj(obj, "value") : null);
    }

    // =====================================================================
    // Commands
    // =====================================================================

    /** @return the line asking for an {@code @WS} now, changed or not */
    public static String workspaceNowCommand() {
        return "@cmd wsnow";
    }

    /**
     * @param cleanedName the variable's name as the interpreter knows it
     * @return the line asking for that variable's {@code @VAR}
     */
    public static String getVariableCommand(String cleanedName) {
        return "@cmd getvar " + cleanedName;
    }

    /**
     * @param cleanedName the variable's name as the interpreter knows it
     * @return the line removing that one variable from the global workspace
     */
    public static String clearVariableCommand(String cleanedName) {
        return "@cmd clearvar " + cleanedName;
    }
}
