package backend.workspace;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

import backend.workspace.WorkspaceProtocol.Message;
import backend.workspace.WorkspaceProtocol.VariableMessage;
import backend.workspace.WorkspaceProtocol.VariableSummary;
import backend.workspace.WorkspaceProtocol.VariableValue;
import backend.workspace.WorkspaceProtocol.WorkspaceMessage;

/**
 * The IDE's live view of the interpreter's global workspace.
 *
 * <p>Fed protocol lines by the console's reader thread
 * ({@link ProtocolLineSplitter}), it keeps the latest workspace summary and
 * tells listeners on the UI thread whenever a new one arrives. It also
 * answers requests for one variable's full value ({@link #requestVariable}),
 * which a variable viewer, a plot or an import/export tool can use without
 * knowing anything about the pipe.
 *
 * <p>This class has no JavaFX dependency. The owner supplies the UI executor
 * (for JavaFX, {@code Platform::runLater}) and the function that writes an
 * internal command line to the interpreter.
 */
public final class WorkspaceChannel {

    /** Sends one internal command line to the interpreter; false if it could not. */
    @FunctionalInterface
    public interface CommandSender {
        boolean send(String commandLine);
    }

    /** How long a {@link #requestVariable} waits for its answer. */
    private static final long REQUEST_TIMEOUT_SECONDS = 30;

    private final Executor uiExecutor;
    private volatile CommandSender sender;
    private volatile BooleanSupplier canSend = () -> true;

    private final List<Consumer<List<VariableSummary>>> listeners = new CopyOnWriteArrayList<>();
    private volatile List<VariableSummary> latest = List.of();

    /** Requests waiting for their @VAR, oldest first, per variable name. Guarded by itself. */
    private final Map<String, Deque<CompletableFuture<VariableValue>>> pending = new HashMap<>();

    /**
     * @param uiExecutor where listeners run and commands are sent from
     *                   (for JavaFX: {@code Platform::runLater})
     */
    public WorkspaceChannel(Executor uiExecutor) {
        this.uiExecutor = Objects.requireNonNull(uiExecutor);
    }

    /**
     * @param sender writes one internal command line to the interpreter. It is
     *               only ever called on the UI executor.
     */
    public void setCommandSender(CommandSender sender) {
        this.sender = sender;
    }

    /**
     * @param gate answers whether a command may be sent right now (false
     *             while a command runs: the interpreter would only read it
     *             afterwards, and a paused step block must not see it at all).
     *             Called on the UI executor.
     */
    public void setSendGate(BooleanSupplier gate) {
        this.canSend = gate == null ? () -> true : gate;
    }

    /**
     * Registers a listener for workspace updates. It runs on the UI executor
     * with the complete variable list, in assignment order.
     *
     * @param listener the listener
     */
    public void addWorkspaceListener(Consumer<List<VariableSummary>> listener) {
        listeners.add(Objects.requireNonNull(listener));
    }

    /** @param listener a listener added earlier */
    public void removeWorkspaceListener(Consumer<List<VariableSummary>> listener) {
        listeners.remove(listener);
    }

    /** @return the most recent workspace summary (empty before the first one) */
    public List<VariableSummary> latest() {
        return latest;
    }

    // =====================================================================
    // Incoming (reader thread)
    // =====================================================================

    /**
     * Handles one protocol line. Called on the reader thread. A line this IDE
     * cannot use is ignored.
     *
     * @param line the line without its Record Separator and line break
     */
    public void accept(String line) {
        Message message = WorkspaceProtocol.parseLine(line);
        if (message instanceof WorkspaceMessage ws) {
            latest = ws.variables();
            List<VariableSummary> snapshot = ws.variables();
            uiExecutor.execute(() -> {
                for (Consumer<List<VariableSummary>> listener : listeners) {
                    try {
                        listener.accept(snapshot);
                    } catch (RuntimeException e) {
                        e.printStackTrace();
                    }
                }
            });
        } else if (message instanceof VariableMessage var) {
            CompletableFuture<VariableValue> waiting = null;
            synchronized (pending) {
                Deque<CompletableFuture<VariableValue>> queue = pending.get(var.variable().name());
                if (queue != null) {
                    waiting = queue.pollFirst();
                    if (queue.isEmpty()) {
                        pending.remove(var.variable().name());
                    }
                }
            }
            if (waiting != null) {
                waiting.complete(var.variable());
            }
        }
    }

    // =====================================================================
    // Outgoing
    // =====================================================================

    /**
     * Asks for one variable's full value. Safe to call from any thread.
     *
     * <p>The future fails with {@link IllegalStateException} when the
     * interpreter is busy or not running, and times out after 30 seconds.
     * A variable that does not exist completes normally with
     * {@code found() == false}.
     *
     * @param cleanedName the variable's name as the interpreter knows it
     * @return the value, when it arrives
     */
    public CompletableFuture<VariableValue> requestVariable(String cleanedName) {
        CompletableFuture<VariableValue> future = new CompletableFuture<>();
        if (cleanedName == null || cleanedName.isBlank()) {
            future.completeExceptionally(new IllegalArgumentException("no variable name"));
            return future;
        }
        String name = cleanedName.strip();
        uiExecutor.execute(() -> {
            CommandSender s = sender;
            if (s == null || !canSend.getAsBoolean()) {
                future.completeExceptionally(new IllegalStateException(
                        "The interpreter is busy or not running; try again when the command finishes."));
                return;
            }
            synchronized (pending) {
                pending.computeIfAbsent(name, k -> new ArrayDeque<>()).addLast(future);
            }
            if (!s.send(WorkspaceProtocol.getVariableCommand(name))) {
                forget(name, future);
                future.completeExceptionally(new IllegalStateException("The interpreter is not running."));
            }
        });
        future.orTimeout(REQUEST_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                .whenComplete((v, e) -> forget(name, future));
        return future;
    }

    /** Asks for a fresh {@code @WS} even if nothing changed. Safe from any thread. */
    public void requestWorkspaceNow() {
        uiExecutor.execute(() -> {
            CommandSender s = sender;
            if (s != null && canSend.getAsBoolean()) {
                s.send(WorkspaceProtocol.workspaceNowCommand());
            }
        });
    }

    /**
     * The interpreter went away (stopped, restarted, crashed): every request
     * still waiting fails. The last summary is kept until the new
     * interpreter sends its own.
     */
    public void reset() {
        Map<String, Deque<CompletableFuture<VariableValue>>> failed;
        synchronized (pending) {
            failed = new HashMap<>(pending);
            pending.clear();
        }
        IllegalStateException gone = new IllegalStateException("The interpreter was restarted.");
        failed.values().forEach(q -> q.forEach(f -> f.completeExceptionally(gone)));
    }

    private void forget(String name, CompletableFuture<VariableValue> future) {
        synchronized (pending) {
            Deque<CompletableFuture<VariableValue>> queue = pending.get(name);
            if (queue != null) {
                queue.remove(future);
                if (queue.isEmpty()) {
                    pending.remove(name);
                }
            }
        }
    }
}
