package backend.workspace;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Comparator;
import java.util.Map;
import java.util.stream.Stream;

/**
 * This IDE window's private folder for talking to {@code nc.exe}:
 * {@code ~/.neuralcode/session-<pid>}.
 *
 * <p>The interpreter is told about it through {@value #ENV_SESSION_DIR}.
 * That variable also switches on its IDE mode: the JSON workspace channel,
 * the session autosave ({@value #AUTOSAVE_FILE}) and the Stop flag
 * ({@link NcInterrupt}). The folder is per process, so two IDE windows never
 * share an autosave or a Stop flag.
 *
 * <p>On shutdown ({@link #close()}) the autosave is kept as
 * {@code ~/.neuralcode/last_session.ndat}, which a launch with
 * {@code -Dastra.workspace.persist=true} restores, and the folder is
 * removed. Folders left behind by IDE processes that no longer exist are
 * removed the next time a session starts.
 */
public final class NcSession {

    /** Session folder for the interpreter. */
    public static final String ENV_SESSION_DIR = "NC_SESSION_DIR";

    /** "1": load the autosave before the first prompt. */
    public static final String ENV_RESTORE = "NC_RESTORE";

    /** Written by the interpreter whenever the workspace changed by the time a prompt comes back. */
    public static final String AUTOSAVE_FILE = "autosave.ndat";

    private static final String ROOT_FOLDER = ".neuralcode";
    private static final String SESSION_PREFIX = "session-";
    private static final String LAST_SESSION_FILE = "last_session.ndat";

    private static NcSession instance;

    private final Path root;
    private final Path directory;
    private final NcInterrupt interrupt;

    private NcSession(Path root, Path directory) {
        this.root = root;
        this.directory = directory;
        this.interrupt = new NcInterrupt(directory);
    }

    /**
     * @return this IDE process's session, created on first use
     * @throws IllegalStateException if the folder cannot be created
     */
    public static synchronized NcSession get() {
        if (instance == null) {
            Path root = Path.of(System.getProperty("user.home"), ROOT_FOLDER);
            Path dir = root.resolve(SESSION_PREFIX + ProcessHandle.current().pid());
            try {
                Files.createDirectories(dir);
            } catch (IOException e) {
                throw new IllegalStateException("Cannot create the session folder " + dir, e);
            }
            instance = new NcSession(root, dir);
            instance.removeAbandonedSessions();
        }
        return instance;
    }

    /** @return the session if one was created in this process, otherwise null (creates nothing) */
    public static synchronized NcSession current() {
        return instance;
    }

    /** @return the session folder */
    public Path directory() {
        return directory;
    }

    /** @return the interpreter's session autosave */
    public Path autosaveFile() {
        return directory.resolve(AUTOSAVE_FILE);
    }

    /** @return the workspace kept from the previous IDE session */
    public Path lastSessionFile() {
        return root.resolve(LAST_SESSION_FILE);
    }

    /** @return the Stop flag for this session */
    public NcInterrupt interrupt() {
        return interrupt;
    }

    /**
     * Prepares an interpreter launch.
     *
     * @param environment the launch's environment ({@code ProcessBuilder.environment()})
     * @param restore     true to have the interpreter load the autosave first
     */
    public void configure(Map<String, String> environment, boolean restore) {
        environment.put(ENV_SESSION_DIR, directory.toAbsolutePath().toString());
        if (restore && Files.isRegularFile(autosaveFile())) {
            environment.put(ENV_RESTORE, "1");
        } else {
            environment.remove(ENV_RESTORE);
        }
        interrupt.clear();
    }

    /** Forgets the autosave: the next interpreter starts with an empty workspace. */
    public void discardAutosave() {
        try {
            Files.deleteIfExists(autosaveFile());
        } catch (IOException ignored) {
            // Without NC_RESTORE the interpreter never reads it anyway.
        }
    }

    /**
     * Puts the previous IDE session's workspace in place as this session's
     * autosave, so the next launch with restore loads it.
     *
     * @return true when there was one to restore
     */
    public boolean seedFromLastSession() {
        Path last = lastSessionFile();
        if (!Files.isRegularFile(last)) {
            return false;
        }
        try {
            Files.copy(last, autosaveFile(), StandardCopyOption.REPLACE_EXISTING);
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    /**
     * Ends the session: keeps the autosave as the last session's workspace and
     * removes the session folder. Call once, when the IDE closes, after the
     * interpreter has stopped.
     */
    public void close() {
        Path autosave = autosaveFile();
        if (Files.isRegularFile(autosave)) {
            try {
                Files.copy(autosave, lastSessionFile(), StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException ignored) {
                // Only the persist option is affected.
            }
        }
        deleteTree(directory);
    }

    private void removeAbandonedSessions() {
        try (Stream<Path> children = Files.list(root)) {
            children.filter(Files::isDirectory)
                    .filter(p -> p.getFileName().toString().startsWith(SESSION_PREFIX))
                    .filter(p -> !p.equals(directory))
                    .filter(NcSession::ownerIsGone)
                    .forEach(NcSession::deleteTree);
        } catch (IOException | RuntimeException ignored) {
            // Housekeeping only.
        }
    }

    private static boolean ownerIsGone(Path sessionDir) {
        String name = sessionDir.getFileName().toString().substring(SESSION_PREFIX.length());
        try {
            long pid = Long.parseLong(name);
            return ProcessHandle.of(pid).map(h -> !h.isAlive()).orElse(true);
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private static void deleteTree(Path dir) {
        if (!Files.exists(dir)) {
            return;
        }
        try (Stream<Path> walk = Files.walk(dir)) {
            walk.sorted(Comparator.reverseOrder()).forEach(p -> {
                try {
                    Files.deleteIfExists(p);
                } catch (IOException ignored) {
                    // A file still held open is left for the next cleanup.
                }
            });
        } catch (IOException ignored) {
            // Same.
        }
    }
}
