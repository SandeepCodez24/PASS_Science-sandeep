package backend.workspace;

import java.util.function.Consumer;

/**
 * Separates the interpreter's protocol lines from its ordinary output.
 *
 * <p>It is fed the interpreter's stdout exactly as read, in chunks of any size,
 * on the reader thread. A protocol line starts with
 * {@link WorkspaceProtocol#RECORD_SEPARATOR} and ends at the next line break. It
 * is collected whole, even across chunks, and handed to {@code protocolLines}
 * without the separator and line break. Everything else is passed straight
 * through to {@code output}, in order.
 *
 * <p>This must run <i>before</i> any output buffer that may drop text (the
 * console's pump caps what it holds): a workspace line for a large matrix is
 * long, and losing part of it would lose the whole update.
 *
 * <p>Not thread-safe; one reader thread owns one instance.
 */
public final class ProtocolLineSplitter {

    /** Receives ordinary output, in order. */
    @FunctionalInterface
    public interface OutputSink {
        /**
         * @param buffer characters
         * @param offset first character to take
         * @param length how many to take
         */
        void accept(char[] buffer, int offset, int length);
    }

    /**
     * Longest protocol line kept. A longer one (not something the interpreter
     * sends; its own cap is far below this) is dropped rather than allowed to
     * exhaust memory.
     */
    static final int MAX_LINE_CHARS = 64 * 1024 * 1024;

    private final OutputSink output;
    private final Consumer<String> protocolLines;

    private final StringBuilder line = new StringBuilder();
    private boolean inProtocolLine;
    private boolean discarding;

    /**
     * @param output        receives ordinary output
     * @param protocolLines receives each complete protocol line, e.g.
     *                      {@code @WS {"v":1,...}}
     */
    public ProtocolLineSplitter(OutputSink output, Consumer<String> protocolLines) {
        this.output = output;
        this.protocolLines = protocolLines;
    }

    /**
     * Processes one chunk of interpreter output.
     *
     * @param buffer characters read
     * @param length how many of them are valid
     */
    public void feed(char[] buffer, int length) {
        int i = 0;
        while (i < length) {
            if (!inProtocolLine) {
                int start = i;
                while (i < length && buffer[i] != WorkspaceProtocol.RECORD_SEPARATOR) {
                    i++;
                }
                if (i > start) {
                    output.accept(buffer, start, i - start);
                }
                if (i < length) {
                    // At a separator: a protocol line starts after it.
                    inProtocolLine = true;
                    discarding = false;
                    line.setLength(0);
                    i++;
                }
                continue;
            }

            int start = i;
            while (i < length && buffer[i] != '\n') {
                i++;
            }
            if (!discarding) {
                if (line.length() + (i - start) > MAX_LINE_CHARS) {
                    discarding = true;
                    line.setLength(0);
                } else {
                    line.append(buffer, start, i - start);
                }
            }
            if (i < length) {
                // End of the protocol line.
                i++;
                inProtocolLine = false;
                if (!discarding) {
                    int end = line.length();
                    if (end > 0 && line.charAt(end - 1) == '\r') {
                        end--; // Windows text-mode stdout writes \r\n
                    }
                    String complete = line.substring(0, end);
                    line.setLength(0);
                    protocolLines.accept(complete);
                }
                discarding = false;
            }
        }
    }

    /** Forgets a protocol line left incomplete (the process went away). */
    public void reset() {
        inProtocolLine = false;
        discarding = false;
        line.setLength(0);
    }
}
