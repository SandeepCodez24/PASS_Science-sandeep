package ui.cli;

import java.util.ArrayList;
import java.util.List;

import language.language_ui.handler.NcBlockScanner;
import language.language_ui.handler.NcBlockTemplates;
import language.syntax.syntax_checker.structure.BlockHeaderGrammar;

/**
 * Multi-line input at the Command Window prompt: decides whether ENTER ends
 * the command or opens another input line, and how far in that line starts.
 *
 * <h3>When ENTER does not submit</h3>
 * <ul>
 * <li>The input opens a block that is not closed yet: {@code if} /
 * {@code if not}, {@code for}, {@code while} / {@code while not},
 * {@code function}, {@code class}, completed with their {@code :}. ENTER
 * goes on to the next line until the matching closer ({@code iend},
 * {@code fend}, {@code wend}, {@code fnend}, {@code csend}) brings every
 * block back to zero.</li>
 * <li>The last line ends in {@code ~~}: the statement continues on the next
 * line.</li>
 * </ul>
 * A header without its {@code :} does not open a block here, so a mistyped
 * one-liner still goes to the interpreter at once and gets its error.
 *
 * <h3>Indentation (MATLAB-style: spaces only, no continuation marker)</h3>
 * The prompt counts as the first line's indentation, so the {@code for} of
 * {@code >> for i = [1:2:100]:} sits at column 3 and its body at column 6:
 *
 * <pre>
 * &gt;&gt; for i = [1:2:100]:
 *       publish(i);
 *    fend
 * &gt;&gt; while not (a &gt; 1) &amp;&amp; ~~
 *              (b &lt; 2):
 * </pre>
 *
 * The same rules as the editor apply -- they come from the same
 * {@link NcBlockScanner}: a body is one level (3 spaces) in, a closer and an
 * {@code else:} / {@code elseif ...:} are moved back under their opener when
 * ENTER is pressed on them, and a {@code ~~} continuation starts under the
 * value it continues.
 *
 * <h3>What the interpreter receives</h3>
 * {@link #backendLines(String)}: one line per statement, {@code ~~} groups
 * joined into one line, comments and blank lines dropped, indentation kept
 * relative to the first line. The Command Window sends them together, the
 * way the Step runner sends a block.
 */
final class CliBlockInput {

    /** Columns the prompt takes on the first input line. */
    static final int PROMPT_WIDTH = CLI_Main.PROMPT.length();

    /** One indentation level, the editor's. */
    private static final String INDENT = NcBlockTemplates.INDENT;

    private CliBlockInput() {
    }

    /**
     * What ENTER should do with the input as it stands.
     *
     * @param complete   true to submit; false to open another input line
     * @param nextIndent the new line's leading spaces when not complete
     * @param fixedInput the input with its last line re-indented (a closer or
     *                   a branch moved under its opener), or null when it is
     *                   already right
     */
    record Analysis(boolean complete, String nextIndent, String fixedInput) {
    }

    /**
     * @param input everything typed after the prompt, newlines included
     * @return what ENTER should do
     */
    static Analysis analyze(String input) {
        String text = input == null ? "" : input;
        String[] view = toView(text);
        int last = view.length - 1;

        // Re-indent a closer / else / elseif on the last line first, so the
        // depth and the next line's indentation are read from the fixed text.
        String fixedInput = null;
        if (last > 0) {
            int target = settledIndent(view, last);
            int current = NcBlockScanner.leadingSpaces(view[last]).length();
            if (target >= 0 && target != current) {
                view[last] = " ".repeat(target) + view[last].substring(current);
                fixedInput = fromView(view);
            }
        }

        NcBlockScanner.Group group = NcBlockScanner.groupAt(view, last, view[last]);
        if (group.continues()) {
            String anchor = " ".repeat(NcBlockScanner.continuationAnchor(view[group.head()]));
            return new Analysis(false, anchor, fixedInput);
        }

        int depth = openDepth(view);
        if (depth <= 0) {
            return new Analysis(true, "", fixedInput);
        }
        return new Analysis(false, nextIndent(view, last, group), fixedInput);
    }

    /**
     * The statements to send for a complete multi-line input.
     *
     * @param input everything typed after the prompt
     * @return one entry per statement; never null
     */
    static List<String> backendLines(String input) {
        String[] view = toView(input == null ? "" : input);
        List<String> out = new ArrayList<>();
        for (int i = 0; i < view.length; i++) {
            NcBlockScanner.Group group = NcBlockScanner.groupAt(view, i, view[i]);
            if (group.continues()) {
                continue; // the group's last line carries the whole statement
            }
            String code = NcBlockScanner.codeWithoutComment(group.joined()).stripTrailing();
            if (code.isBlank()) {
                continue;
            }
            int indent = NcBlockScanner.leadingSpaces(code).length();
            int relative = Math.max(0, indent - PROMPT_WIDTH);
            out.add(" ".repeat(relative) + code.substring(indent));
        }
        return out;
    }

    // ─────────────────────────────────────────────────────────────────────
    // Internals
    // ─────────────────────────────────────────────────────────────────────

    /** The input as editor-like lines: the prompt becomes the first line's indentation. */
    private static String[] toView(String input) {
        String[] lines = input.split("\n", -1);
        lines[0] = " ".repeat(PROMPT_WIDTH) + lines[0];
        return lines;
    }

    /** Back from {@link #toView}: the first line loses the prompt's columns again. */
    private static String fromView(String[] view) {
        String[] lines = view.clone();
        lines[0] = lines[0].length() >= PROMPT_WIDTH ? lines[0].substring(PROMPT_WIDTH) : lines[0].stripLeading();
        return String.join("\n", lines);
    }

    /**
     * Blocks still open at the end of the input. A header opens a block only
     * when its group ends with {@code :}.
     */
    private static int openDepth(String[] view) {
        int depth = 0;
        for (int i = 0; i < view.length; i++) {
            NcBlockScanner.Group group = NcBlockScanner.groupAt(view, i, view[i]);
            if (group.continues()) {
                continue;
            }
            String headLine = view[group.head()];
            if (group.head() == i && NcBlockScanner.closerOf(headLine) != null) {
                depth--;
                continue;
            }
            String joined = NcBlockScanner.logicalCode(group.joined()).trim();
            if (!joined.endsWith(":")) {
                continue;
            }
            BlockHeaderGrammar.Header header = BlockHeaderGrammar.parse(joined);
            if (header != null && header.kind().opensBlock()) {
                depth++;
            }
        }
        return depth;
    }

    /** The column a closer or a branch on {@code line} belongs at, or -1 when it is neither. */
    private static int settledIndent(String[] view, int line) {
        String document = String.join("\n", view);
        String current = view[line];
        String closer = NcBlockScanner.closerOf(current);
        if (closer != null) {
            return NcBlockScanner.closerTargetIndent(document, line, closer);
        }
        String logical = NcBlockScanner.logicalCode(current).trim();
        if (logical.endsWith(":")) {
            BlockHeaderGrammar.Header header = BlockHeaderGrammar.parse(logical);
            if (header != null && header.kind().isBranch()) {
                return NcBlockScanner.branchTargetIndent(document, line,
                        NcBlockScanner.leadingSpaces(current).length());
            }
        }
        return -1;
    }

    /** Indentation of the line after {@code last}, inside an open block. */
    private static String nextIndent(String[] view, int last, NcBlockScanner.Group group) {
        String headLine = view[group.head()];
        String headIndent = NcBlockScanner.leadingSpaces(headLine);
        if (group.head() == last && NcBlockScanner.closerOf(headLine) != null) {
            return headIndent; // after a closer: same level as the closer
        }
        String joined = NcBlockScanner.logicalCode(group.joined()).trim();
        BlockHeaderGrammar.Header header = joined.endsWith(":") ? BlockHeaderGrammar.parse(joined) : null;
        if (header == null) {
            return headIndent;
        }
        return headIndent + INDENT;
    }
}
