package ui.cli;

import language.semantic.ScriptMarkers;
import language.semantic.SemanticEncoder;
import language.semantic.VariableNameDecoder;
import ui.managers.LanguageDesignManager;

/**
 * The Command Window's translator between the <b>visual</b> form the user types
 * and the <b>cleaned</b> form {@code nc.exe} understands.
 *
 * <h3>The bug this closes</h3>
 * {@code CLI_Main.handleEnter} used to end with a bare {@code sendRaw(line)},
 * so a line like <code>&#956; = 25</code> reached the interpreter with a raw
 * UTF-8 identifier. The editor never does that: Run hands the backend
 * {@code cleaned_Runfile.nc}, in which {@link SemanticEncoder} has already
 * turned &#956; into {@code var_mu}. The interpreter simply did not recognise
 * the line, so it neither assigned anything nor complained — no error, no row
 * in the Explorer, which is exactly the reported symptom.
 *
 * <h3>Why this is a new class and not an edit to the shared pipeline</h3>
 * {@link LanguageDesignManager} and {@link SemanticEncoder} are what the
 * working editor path depends on, so nothing here modifies them. This class
 * only <em>calls</em> them, which means the CLI and the editor can never drift
 * apart on what a symbol encodes to — the same argument
 * {@code ConsoleSymbolInput} already makes about replacement rules.
 *
 * <h3>The safety property that matters</h3>
 * {@link #encodeLine(String)} is the <b>identity function on any line made only
 * of ASCII</b>. Every command that works today — {@code a = 5}, {@code clear},
 * {@code sct_01.nc}, a function call, a matrix literal — is forwarded byte for
 * byte exactly as before, because the encoder is never even entered. Only a
 * line that actually contains a non-ASCII character takes the encoding path.
 *
 * <p>The {@code ^^2} / {@code __2} shorthands keep working through that fast
 * path rather than around it: {@code ConsoleSymbolInput} has already folded
 * them into real Unicode (&#178;, &#8322;) by the time ENTER is pressed, so the
 * line is no longer ASCII and the encoder turns them back into the
 * {@code __t2} / {@code __s2} markers, precisely as the editor does.
 *
 * <h3>String literals</h3>
 * Encoding runs only on the stretches of a line that sit <em>outside</em> a
 * string literal, so <code>&#2965;&#3007; = "&#2970;&#3019;&#2996;
 * &#2984;&#3006;&#2975;&#3009;"</code> stores its text unharmed. This follows
 * the same quote rule {@code LanguageDesignManager} uses (both {@code "} and
 * {@code '} delimit, each nests inside the other, only the opener closes).
 *
 * <p>Note that the whole-file path does <b>not</b> yet do this — blind
 * {@code String.replace} over a file rewrites literal contents too — so a Tamil
 * string in a {@code .nc} script reaches the interpreter mangled. That is a
 * pre-existing editor-side issue and is deliberately left alone here. If you
 * would rather the CLI reproduce it bug-for-bug until the editor is fixed, set
 * {@link #PRESERVE_STRING_LITERALS} to {@code false} and the two behave
 * identically again.
 */
public final class CliSymbolCodec {

    /**
     * When true, text inside a string literal is forwarded verbatim instead of
     * being run through the symbol encoder. See the class note.
     */
    private static final boolean PRESERVE_STRING_LITERALS = true;

    /**
     * Prefixes that mark a token in interpreter output as a cleaned identifier
     * worth decoding. Kept explicit so a token like {@code my_var} is never
     * touched by accident; if a dictionary is ever added whose cleaned names
     * start with something else, add that prefix here.
     */
    private static final String[] CLEANED_PREFIXES = { "var_", "con_" };

    private CliSymbolCodec() {
    }

    // =====================================================================
    // Visual  ->  cleaned  (what goes down the pipe to nc.exe)
    // =====================================================================

    /**
     * Encodes one submitted console line into the form the interpreter reads.
     *
     * @param visualLine the line exactly as the user sees it at the prompt
     * @return the cleaned line; the input unchanged when it is pure ASCII
     */
    public static String encodeLine(String visualLine) {
        if (visualLine == null || visualLine.isEmpty()) {
            return visualLine == null ? "" : visualLine;
        }
        if (isPlainAscii(visualLine)) {
            return visualLine;
        }
        if (!PRESERVE_STRING_LITERALS) {
            return encodeSegment(visualLine);
        }
        return encodeOutsideLiterals(visualLine);
    }

    /**
     * Encodes a single identifier, for {@code clear <name>}.
     *
     * <p>Unlike {@link SemanticEncoder#encodeName(String)} this also applies the
     * symbol replacements first, so {@code clear \var(\mu)} resolves the same
     * way {@code clear &#956;} does.
     *
     * @param visualName the name as the user typed it
     * @return the cleaned workspace key
     */
    public static String encodeName(String visualName) {
        if (visualName == null) {
            return null;
        }
        String trimmed = visualName.trim();
        if (trimmed.isEmpty() || isPlainAscii(trimmed)) {
            return trimmed;
        }
        return encodeSegment(trimmed).trim();
    }

    // =====================================================================
    // Cleaned  ->  visual  (what the user reads back)
    // =====================================================================

    /**
     * Decodes cleaned identifiers appearing in interpreter output back into
     * their visual form, so {@code var_mu = 25} prints as
     * <code>&#956; = 25</code>.
     *
     * <p>Only tokens carrying a recognised cleaned prefix or script marker are
     * considered, and a token is rewritten only when decoding actually changes
     * it. Ordinary names ({@code ans}, {@code G}, {@code my_var}) therefore pass
     * through untouched.
     *
     * <p>A chunk boundary can split an identifier across two reads, in which
     * case neither half matches and the name is printed undecoded rather than
     * corrupted. With the reader's 2 KB buffer that is rare, and printing a raw
     * name is a far better failure than printing a broken one.
     *
     * @param text one chunk of interpreter output
     * @return the same text with cleaned identifiers rendered visually
     */
    public static String decodeOutput(String text) {
        if (text == null || text.isEmpty() || !mayContainCleanedName(text)) {
            return text;
        }
        StringBuilder out = new StringBuilder(text.length());
        int i = 0;
        while (i < text.length()) {
            char c = text.charAt(i);
            if (isIdentifierStart(c)) {
                int end = i;
                while (end < text.length() && isIdentifierPart(text.charAt(end))) {
                    end++;
                }
                out.append(decodeToken(text.substring(i, end)));
                i = end;
            } else {
                out.append(c);
                i++;
            }
        }
        return out.toString();
    }

    // =====================================================================
    // Internals
    // =====================================================================

    /**
     * The one encoding step, so both callers below go through exactly the same
     * two stages the editor's {@code toCleanedCode} uses. {@code preprocess} is
     * deliberately skipped: it strips comments and collapses spacing across a
     * whole file, neither of which a single console line needs, and skipping it
     * keeps the encoder as close to a no-op as possible.
     */
    private static String encodeSegment(String code) {
        if (code == null || code.isEmpty()) {
            return code == null ? "" : code;
        }
        return SemanticEncoder.encode(LanguageDesignManager.applySymbolReplacements(code));
    }

    /**
     * Walks the line, encoding the code stretches and copying literals through
     * verbatim. Mirrors the quote handling in
     * {@code LanguageDesignManager.collapseSpacingOutsideStrings} so the two
     * agree about where code stops and text starts.
     */
    private static String encodeOutsideLiterals(String line) {
        StringBuilder out = new StringBuilder(line.length());
        StringBuilder code = new StringBuilder();
        char openQuote = 0;

        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);

            if (openQuote != 0) {
                out.append(ch);
                if (ch == openQuote && !isEscaped(line, i)) {
                    openQuote = 0;
                }
                continue;
            }

            if ((ch == '"' || ch == '\'') && !isEscaped(line, i)) {
                out.append(encodeSegment(code.toString()));
                code.setLength(0);
                out.append(ch);
                openQuote = ch;
                continue;
            }

            code.append(ch);
        }

        out.append(encodeSegment(code.toString()));
        return out.toString();
    }

    private static boolean isEscaped(String text, int index) {
        int backslashes = 0;
        int i = index - 1;
        while (i >= 0 && text.charAt(i) == '\\') {
            backslashes++;
            i--;
        }
        return backslashes % 2 != 0;
    }

    private static boolean isPlainAscii(String text) {
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) > 0x7F) {
                return false;
            }
        }
        return true;
    }

    private static boolean mayContainCleanedName(String text) {
        for (String prefix : CLEANED_PREFIXES) {
            if (text.contains(prefix)) {
                return true;
            }
        }
        return text.contains(ScriptMarkers.SUBSCRIPT) || text.contains(ScriptMarkers.SUPERSCRIPT);
    }

    private static String decodeToken(String token) {
        if (!isCleanedCandidate(token)) {
            return token;
        }
        String decoded = VariableNameDecoder.decodeToPlainText(token);
        return decoded == null || decoded.isEmpty() ? token : decoded;
    }

    private static boolean isCleanedCandidate(String token) {
        for (String prefix : CLEANED_PREFIXES) {
            if (token.startsWith(prefix)) {
                return true;
            }
        }
        return token.contains(ScriptMarkers.SUBSCRIPT) || token.contains(ScriptMarkers.SUPERSCRIPT);
    }

    private static boolean isIdentifierStart(char c) {
        return Character.isLetter(c) || c == '_';
    }

    private static boolean isIdentifierPart(char c) {
        return Character.isLetterOrDigit(c) || c == '_';
    }
}
