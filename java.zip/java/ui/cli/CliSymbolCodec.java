package ui.cli;

import language.semantic.CodeSegments;
import language.semantic.SemanticEncoder;
import language.semantic.VariableNameDecoder;
import ui.managers.LanguageDesignManager;

/**
 * The Command Window's translator between what the user types and what
 * {@code nc.exe} reads.
 *
 * <h3>Names go through as typed (changed)</h3>
 * Names reach {@code nc.exe} exactly as written -- {@code A_$1},
 * {@code μ_$i_@2}, {@code க_$1} -- and come back the same way
 * ({@code language.semantic.ScriptedName}). Nothing is translated to
 * {@code var_mu} or {@code __s} markers any more.
 *
 * <h3>The safety property that matters</h3>
 * {@link #encodeLine(String)} is the <b>identity function on any line made only
 * of ASCII</b>: {@code a = 5}, {@code clear}, {@code A_$1 = 4},
 * {@code sct_01.nc}, a matrix literal are forwarded byte for byte. A line
 * with a non-ASCII character goes through the same two stages the editor's
 * Run uses ({@link LanguageDesignManager#applySymbolReplacements} and
 * {@link SemanticEncoder#encode}): {@code \var(\mu)} becomes μ, a constant
 * symbol becomes its {@code con_} name, and the text is put in Unicode normal
 * form C -- so the Command Window and the editor can never disagree.
 *
 * <h3>String literals</h3>
 * Encoding runs only on the stretches of a line that sit <em>outside</em> a
 * string literal, so <code>&#2965;&#3007; = "&#2970;&#3019;&#2996;
 * &#2984;&#3006;&#2975;&#3009;"</code> stores its text unharmed. This follows
 * the same quote rule {@code LanguageDesignManager} uses (both {@code "} and
 * {@code '} delimit, each nests inside the other, only the opener closes).
 *
 * <h3>Output</h3>
 * On the way back nothing is decoded except a physical constant's
 * {@code con_} name, which is shown as its symbol ({@link #decodeOutput}).
 */
public final class CliSymbolCodec {

    /**
     * When true, text inside a string literal is forwarded verbatim instead of
     * being run through the symbol encoder. See the class note.
     */
    private static final boolean PRESERVE_STRING_LITERALS = true;

    /**
     * The only names in interpreter output that are shown differently from
     * how they are written: physical constants ({@code con_pi} reads 𝝅).
     */
    private static final String CONSTANT_PREFIX = "con_";

    private CliSymbolCodec() {
    }

    // =====================================================================
    // Visual  ->  cleaned  (what goes down the pipe to nc.exe)
    // =====================================================================

    /**
     * Encodes one submitted console line into the form the interpreter reads.
     *
     * @param visualLine the line exactly as the user sees it at the prompt
     * @return the cleaned line; the input unchanged when it is pure ASCII
     */
    public static String encodeLine(String visualLine) {
        if (visualLine == null || visualLine.isEmpty()) {
            return visualLine == null ? "" : visualLine;
        }
        if (isPlainAscii(visualLine)) {
            return visualLine;
        }
        if (!PRESERVE_STRING_LITERALS) {
            return encodeSegment(visualLine);
        }
        return encodeOutsideLiterals(visualLine);
    }

    /**
     * Encodes a single identifier, for {@code clear <name>}.
     *
     * <p>Unlike {@link SemanticEncoder#encodeName(String)} this also applies the
     * symbol replacements first, so {@code clear \var(\mu)} resolves the same
     * way {@code clear &#956;} does.
     *
     * @param visualName the name as the user typed it
     * @return the cleaned workspace key
     */
    public static String encodeName(String visualName) {
        if (visualName == null) {
            return null;
        }
        String trimmed = visualName.trim();
        if (trimmed.isEmpty() || isPlainAscii(trimmed)) {
            return trimmed;
        }
        return encodeSegment(trimmed).trim();
    }

    // =====================================================================
    // Cleaned  ->  visual  (what the user reads back)
    // =====================================================================

    /**
     * Shows physical constants in interpreter output as their symbols, so
     * {@code con_pi} prints as 𝝅. Every other name -- {@code A_$1},
     * {@code μ}, {@code my_var} -- is printed exactly as the interpreter
     * reports it, which is exactly as the user wrote it.
     *
     * <p>A chunk boundary can split an identifier across two reads, in which
     * case neither half matches and the name is printed undecoded rather than
     * corrupted. Output reaches the console in batches (the reader takes 8 K
     * characters at a time, and a batch holds everything read in about 30 ms),
     * so that is rare, and printing a raw name is a far better failure than
     * printing a broken one.
     *
     * @param text one chunk of interpreter output
     * @return the same text with cleaned identifiers rendered visually
     */
    public static String decodeOutput(String text) {
        if (text == null || text.isEmpty() || !mayContainCleanedName(text)) {
            return text;
        }
        StringBuilder out = new StringBuilder(text.length());
        int i = 0;
        while (i < text.length()) {
            char c = text.charAt(i);
            if (isIdentifierStart(c)) {
                int end = i;
                while (end < text.length() && isIdentifierPart(text.charAt(end))) {
                    end++;
                }
                out.append(decodeToken(text.substring(i, end)));
                i = end;
            } else {
                out.append(c);
                i++;
            }
        }
        return out.toString();
    }

    // =====================================================================
    // Internals
    // =====================================================================

    /**
     * The one encoding step, so both callers below go through exactly the same
     * two stages the editor's {@code toCleanedCode} uses. {@code preprocess} is
     * deliberately skipped: it strips comments and collapses spacing across a
     * whole file, neither of which a single console line needs, and skipping it
     * keeps the encoder as close to a no-op as possible.
     */
    private static String encodeSegment(String code) {
        if (code == null || code.isEmpty()) {
            return code == null ? "" : code;
        }
        return SemanticEncoder.encode(LanguageDesignManager.applySymbolReplacements(code));
    }

    /**
     * Walks the line, encoding the code stretches and copying literals through
     * verbatim. Mirrors the quote handling in
     * {@code LanguageDesignManager.collapseSpacingOutsideStrings} so the two
     * agree about where code stops and text starts.
     */
    private static String encodeOutsideLiterals(String line) {
        StringBuilder out = new StringBuilder(line.length());
        StringBuilder code = new StringBuilder();
        char openQuote = 0;
        int transposeAt = -1;

        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);

            if (openQuote != 0) {
                out.append(ch);
                if (ch == openQuote && !isEscaped(line, i)) {
                    openQuote = 0;
                }
                continue;
            }

            if (ch == '\'' && CodeSegments.isTranspose(line, i, transposeAt)) {
                transposeAt = i;
                code.append(ch);
                continue;
            }

            if ((ch == '"' || ch == '\'') && !isEscaped(line, i)) {
                out.append(encodeSegment(code.toString()));
                code.setLength(0);
                out.append(ch);
                openQuote = ch;
                continue;
            }

            code.append(ch);
        }

        out.append(encodeSegment(code.toString()));
        return out.toString();
    }

    private static boolean isEscaped(String text, int index) {
        int backslashes = 0;
        int i = index - 1;
        while (i >= 0 && text.charAt(i) == '\\') {
            backslashes++;
            i--;
        }
        return backslashes % 2 != 0;
    }

    private static boolean isPlainAscii(String text) {
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) > 0x7F) {
                return false;
            }
        }
        return true;
    }

    private static boolean mayContainCleanedName(String text) {
        return text.contains(CONSTANT_PREFIX);
    }

    private static String decodeToken(String token) {
        String symbol = VariableNameDecoder.constantSymbol(token);
        return symbol == null ? token : symbol;
    }

    private static boolean isIdentifierStart(char c) {
        return Character.isLetter(c) || c == '_';
    }

    private static boolean isIdentifierPart(char c) {
        // '$' and '@' after '_' belong to a scripted name (A_$1), so a token
        // like A_$con_x is never split into a constant by accident.
        return Character.isLetterOrDigit(c) || c == '_' || c == '$' || c == '@'
                || Character.getType(c) == Character.NON_SPACING_MARK
                || Character.getType(c) == Character.COMBINING_SPACING_MARK;
    }
}
