package ui.cli;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * The Command Window's saved command history, kept across IDE restarts.
 *
 * <h3>Sessions</h3>
 * Commands are grouped by the Command Window session they were typed in. A
 * session starts when the IDE launches and again on every three-dot menu
 * <b>New Window</b>; it is named by that start time. A session in which
 * nothing was typed is never written, so the history holds no empty groups.
 *
 * <h3>File</h3>
 * One UTF-8 text file, {@value #FILE_NAME}, in Astra's per-user folder
 * ({@code %APPDATA%\Astra} on Windows, {@code ~/.astra} elsewhere):
 *
 * <pre>
 *   #session 2026-10-19T18:04:12
 *   eCA9IDU7                     one command per line, Base64 of its UTF-8
 *   Zm9yIGkgPSBbMToyOjEwMF06...  text, so a multi-line block is one entry
 * </pre>
 *
 * Commands are appended as they are submitted, so nothing is lost if the IDE
 * is closed abruptly.
 *
 * <h3>Read once, kept in memory (changed)</h3>
 * <p>
 * The file used to be read -- and, past {@link #MAX_COMMANDS}, rewritten --
 * every time {@link #sessions()} was called. The CLI History window calls it
 * on every command submitted and on every keystroke in its filter, so with a
 * long history each of those re-read up to 20,000 lines on the FX thread. Now
 * the file is read once, on first use; {@link #record} appends to the file
 * and to the copy in memory, and the cap is applied in memory with one
 * rewrite when it is passed. A getter no longer writes to disk.
 * </p>
 *
 * <p>
 * Every method is safe to call when the file cannot be read or written:
 * history is a convenience and never stops a command from running. Call on
 * the FX thread.
 */
public final class CliHistory {

    /** File name inside Astra's per-user folder. */
    static final String FILE_NAME = "cli_history.txt";

    /** Oldest sessions are dropped beyond this many commands in total. */
    static final int MAX_COMMANDS = 20_000;

    private static final String SESSION_TAG = "#session ";

    /** Session start times are stored to the second. */
    private static final DateTimeFormatter STAMP = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

    /** One Command Window session: its start time and its commands, oldest first. */
    public record Session(LocalDateTime started, List<String> commands) {
    }

    /** A session as held in memory: its command list grows. */
    private static final class Group {
        final LocalDateTime started;
        final List<String> commands = new ArrayList<>();

        Group(LocalDateTime started) {
            this.started = started;
        }
    }

    private static LocalDateTime currentStart = now();
    private static boolean currentWritten;

    /** The history, oldest session first; null until first read. */
    private static List<Group> cache;

    /** Commands in {@link #cache}. */
    private static int total;

    /** Run on every change (record, new session, reset), e.g. by an open history window. */
    private static final List<Runnable> LISTENERS = new CopyOnWriteArrayList<>();

    private CliHistory() {
    }

    // =====================================================================
    // Sessions
    // =====================================================================

    /** Starts a new session (IDE launch, New Window). Written on its first command. */
    public static void startSession() {
        currentStart = now();
        currentWritten = false;
        fire();
    }

    /** @return when the current session started */
    public static LocalDateTime currentSessionStart() {
        return currentStart;
    }

    // =====================================================================
    // Recording
    // =====================================================================

    /**
     * Saves one submitted command (a single line or a whole block).
     *
     * @param command the command as typed; blank commands are ignored
     */
    public static void record(String command) {
        if (command == null || command.isBlank()) {
            return;
        }
        ensureLoaded();
        String text = command.stripTrailing();

        // Memory first, so the history window shows it even if the disk fails.
        Group last = cache.isEmpty() ? null : cache.get(cache.size() - 1);
        if (last == null || !currentStart.equals(last.started)) {
            last = new Group(currentStart);
            cache.add(last);
        }
        last.commands.add(text);
        total++;

        StringBuilder out = new StringBuilder();
        if (!currentWritten) {
            out.append(SESSION_TAG).append(STAMP.format(currentStart)).append('\n');
        }
        out.append(encode(text)).append('\n');
        try {
            Path file = file();
            Files.createDirectories(file.getParent());
            Files.writeString(file, out, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            currentWritten = true;
        } catch (IOException | RuntimeException e) {
            // History is a convenience; the command itself is unaffected.
        }

        if (total > MAX_COMMANDS) {
            trim();
            rewrite();
        }
        fire();
    }

    // =====================================================================
    // Reading
    // =====================================================================

    /**
     * Every saved session, oldest first. The current session is included once
     * it has a command. Served from memory.
     *
     * @return the sessions; empty when there is no history
     */
    public static List<Session> sessions() {
        ensureLoaded();
        List<Session> sessions = new ArrayList<>(cache.size());
        for (Group group : cache) {
            if (!group.commands.isEmpty()) {
                sessions.add(new Session(group.started, List.copyOf(group.commands)));
            }
        }
        return sessions;
    }

    /**
     * The most recent commands across all sessions, oldest first, for UP/DOWN
     * recall at launch.
     *
     * @param limit how many at most
     * @return the commands
     */
    public static List<String> recentCommands(int limit) {
        ensureLoaded();
        List<String> all = new ArrayList<>();
        for (Group group : cache) {
            all.addAll(group.commands);
        }
        int from = Math.max(0, all.size() - Math.max(0, limit));
        return new ArrayList<>(all.subList(from, all.size()));
    }

    // =====================================================================
    // Reset
    // =====================================================================

    /**
     * Deletes the whole saved history ("Reset CLI History") and starts a new
     * session.
     *
     * @return true when the history is gone
     */
    public static boolean reset() {
        boolean ok = true;
        try {
            Files.deleteIfExists(file());
        } catch (IOException | RuntimeException e) {
            ok = false;
        }
        cache = new ArrayList<>();
        total = 0;
        currentStart = now();
        currentWritten = false;
        fire();
        return ok;
    }

    // =====================================================================
    // Listeners
    // =====================================================================

    /** @param listener run after every change; call {@link #removeListener} when done */
    public static void addListener(Runnable listener) {
        if (listener != null) {
            LISTENERS.add(listener);
        }
    }

    /** @param listener a listener added earlier */
    public static void removeListener(Runnable listener) {
        LISTENERS.remove(listener);
    }

    private static void fire() {
        for (Runnable listener : LISTENERS) {
            try {
                listener.run();
            } catch (RuntimeException e) {
                e.printStackTrace();
            }
        }
    }

    // =====================================================================
    // Internals
    // =====================================================================

    /** @return the history file in Astra's per-user folder */
    static Path file() {
        String appData = System.getenv("APPDATA");
        String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        Path folder = os.contains("win") && appData != null && !appData.isBlank()
                ? Path.of(appData, "Astra")
                : Path.of(System.getProperty("user.home"), ".astra");
        return folder.resolve(FILE_NAME);
    }

    /** Reads the file into memory once. Past the cap, trims and rewrites it once. */
    private static void ensureLoaded() {
        if (cache != null) {
            return;
        }
        cache = new ArrayList<>();
        total = 0;
        Path file = file();
        if (!Files.isRegularFile(file)) {
            return;
        }
        List<String> lines;
        try {
            lines = Files.readAllLines(file, StandardCharsets.UTF_8);
        } catch (IOException | RuntimeException e) {
            return;
        }
        Group group = null;
        for (String line : lines) {
            if (line.startsWith(SESSION_TAG)) {
                group = new Group(parseStamp(line.substring(SESSION_TAG.length()).trim()));
                cache.add(group);
                continue;
            }
            if (line.isBlank()) {
                continue;
            }
            if (group == null) { // commands before any header: an unnamed session
                group = new Group(LocalDateTime.MIN);
                cache.add(group);
            }
            String decoded = decode(line.trim());
            if (decoded != null) {
                group.commands.add(decoded);
                total++;
            }
        }
        cache.removeIf(g -> g.commands.isEmpty());
        if (total > MAX_COMMANDS) {
            trim();
            rewrite();
        }
    }

    /** Drops the oldest sessions until the total is within the cap (the newest always stays). */
    private static void trim() {
        while (total > MAX_COMMANDS && cache.size() > 1) {
            total -= cache.remove(0).commands.size();
        }
    }

    private static void rewrite() {
        StringBuilder out = new StringBuilder();
        for (Group group : cache) {
            LocalDateTime started = group.started == null || LocalDateTime.MIN.equals(group.started)
                    ? now()
                    : group.started;
            out.append(SESSION_TAG).append(STAMP.format(started)).append('\n');
            for (String command : group.commands) {
                out.append(encode(command)).append('\n');
            }
        }
        try {
            Files.createDirectories(file().getParent());
            Files.writeString(file(), out, StandardCharsets.UTF_8);
            // The current session's header may have been dropped with the old ones.
            currentWritten = cache.stream().anyMatch(g -> currentStart.equals(g.started));
        } catch (IOException | RuntimeException e) {
            // keep what is in memory
        }
    }

    private static String encode(String text) {
        return Base64.getEncoder().encodeToString(text.getBytes(StandardCharsets.UTF_8));
    }

    private static String decode(String line) {
        try {
            return new String(Base64.getDecoder().decode(line), StandardCharsets.UTF_8);
        } catch (IllegalArgumentException e) {
            return null; // a damaged line is skipped, not fatal
        }
    }

    private static LocalDateTime parseStamp(String text) {
        try {
            return LocalDateTime.parse(text, STAMP);
        } catch (DateTimeParseException e) {
            return LocalDateTime.MIN;
        }
    }

    private static LocalDateTime now() {
        return LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS);
    }
}
