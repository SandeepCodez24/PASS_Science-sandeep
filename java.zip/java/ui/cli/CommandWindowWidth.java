package ui.cli;

import java.util.function.IntPredicate;

import javafx.animation.PauseTransition;
import javafx.util.Duration;

/**
 * Keeps the interpreter told how many characters fit on one Command Window
 * line, so it can print a wide matrix in MATLAB-style column groups:
 *
 * <pre>
 *   W =
 *
 *     Columns 0 through 15
 *
 *       1    0    0 ...
 *
 *     Columns 16 through 31
 *     ...
 *     Column 39
 * </pre>
 *
 * <h3>The number</h3>
 * {@code n = floor(visible text width / width of one character) - 1}, at
 * least {@link #MIN_COLUMNS}: the console font is fixed-width
 * ({@link ConsoleArea#charactersPerLine()}), and the one character spare
 * keeps a full-width line from touching the edge. A line of {@code n}
 * characters therefore always fits, so the console's soft wrap (kept for
 * long typed commands) never breaks a column group.
 *
 * <h3>When it is sent</h3>
 * <ul>
 * <li>At launch, as the environment variable {@value #ENVIRONMENT}, which
 * the interpreter uses until the first {@code @cmd width}.</li>
 * <li>Once after the interpreter starts ({@code @cmd width n}, handled like
 * {@code @cmd setpwd}: before the multi-line buffer, printing nothing).</li>
 * <li>After the Command Window is resized, once it has been still for
 * {@link #DEBOUNCE_MS} ms -- dragging a divider sends one line, not
 * hundreds.</li>
 * </ul>
 * Only a <b>changed</b> number is sent. While a command runs (or a step
 * block is paused) nothing is written: a script reading input must never
 * receive the line. The new width then goes out just before the next
 * command, which is the first one that can print with it.
 *
 * <p>
 * This class measures and remembers; {@code CLI_Main} owns the pipe and
 * decides when a line may be written. FX thread only.
 */
final class CommandWindowWidth {

    /** Read by {@code nc.exe} at start-up, until the first {@code @cmd width}. */
    static final String ENVIRONMENT = "NC_DISPLAY_WIDTH";

    /** The interpreter's own minimum. */
    static final int MIN_COLUMNS = 20;

    /** Quiet time after the last resize before the width is sent. */
    static final double DEBOUNCE_MS = 200;

    /** Characters kept free at the end of a line. */
    private static final int SPARE = 1;

    private static final String COMMAND = "@cmd width ";

    private final ConsoleArea console;
    private final PauseTransition settle = new PauseTransition(Duration.millis(DEBOUNCE_MS));

    /** The width the running interpreter has; -1 when it has none from us. */
    private int sent = -1;

    /**
     * Watches the console's size and font.
     *
     * @param console   the Command Window's text area
     * @param onSettled run on the FX thread once a resize has settled; it may
     *                  call {@link #sendIfChanged} when a line may be written
     */
    CommandWindowWidth(ConsoleArea console, Runnable onSettled) {
        this.console = console;
        settle.setOnFinished(e -> onSettled.run());
        console.widthProperty().addListener((obs, was, is) -> settle.playFromStart());
        // The font size lives in the inline style (ConsoleController, zoom).
        console.styleProperty().addListener((obs, was, is) -> settle.playFromStart());
    }

    /**
     * @return the width to give the interpreter, or -1 while the console has
     *         not been laid out yet
     */
    int columns() {
        int fit = console.charactersPerLine();
        return fit <= 0 ? -1 : Math.max(MIN_COLUMNS, fit - SPARE);
    }

    /**
     * Sends the current width when it differs from what the interpreter has.
     *
     * @param writer writes one line to the interpreter; true when written
     */
    void sendIfChanged(IntPredicate writer) {
        int columns = columns();
        if (columns > 0 && columns != sent && writer.test(columns)) {
            sent = columns;
        }
    }

    /** A new interpreter knows nothing: the next {@link #sendIfChanged} always sends. */
    void forgetSent() {
        sent = -1;
    }

    /**
     * @param columns a width
     * @return the protocol line that sets it
     */
    static String command(int columns) {
        return COMMAND + columns;
    }
}
