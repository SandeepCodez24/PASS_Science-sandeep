package ui.cli;

import java.util.List;

import javafx.scene.control.TextArea;
import javafx.scene.input.KeyEvent;
import ui.UI_Main;
import ui.ui_functions.FunctionProvider;
import ui.ui_functions.SuggestionPopup;
import ui.ui_functions.SuggestionProvider;

/**
 * Brings the Editor's autocomplete to the Command Window using the <b>same</b>
 * shared suggestion stack — no duplicate dictionaries.
 *
 * <p>It reuses {@link SuggestionProvider} (the common facade over Greek / Tamil /
 * Sanskrit / Telugu / Malayalam / constants / sub-superscript tables) and the
 * shared {@link SuggestionPopup} widget, exactly like
 * {@code EditorSuggestionHandler} does for the editor. Only the popup (not the
 * editor's live symbol-replacement modes) is wired here, which is all the
 * single-line CLI needs.
 *
 * <p>Suggestions are computed only from the <em>current input line</em> (the
 * text after {@code ide.inputStart}), so committed output never pollutes the
 * pattern. A capturing {@code KEY_PRESSED} event filter handles
 * UP/DOWN/ENTER/ESC while the popup is open and consumes them, so ENTER only
 * reaches {@link ConsoleController} (i.e. "submit") when no suggestion is
 * showing.
 */
public final class CLI_SuggestionBridge {

    private UI_Main ide;
    private TextArea console;
    private final SuggestionPopup popup = new SuggestionPopup();

    /** Wires the bridge onto {@code ide.console}. Call once after the console exists. */
    public void attach(UI_Main ideRef) {
        this.ide = ideRef;
        this.console = ide.console;
        popup.setTheme(ide.currentTheme);
        popup.setOnInsertSuggestion(this::insertSelected);

        // Update suggestions as the user types on the current input line.
        console.textProperty().addListener((obs, oldText, newText) -> {
            if (ide.stage == null || ide.stage.getScene() == null) {
                return;
            }
            String line = currentLine();
            int caretInLine = caretWithinLine();
            if (line.isEmpty() || caretInLine <= 0) {
                popup.hide();
                return;
            }
            // Feed the shared engine so \var(...) variable suggestions stay live.
            SuggestionProvider.updateVariablesFromText(line);
            String pattern = extractPattern(line, caretInLine);
            if (pattern != null && !pattern.trim().isEmpty()) {
                popup.setTheme(ide.currentTheme);
                popup.showSuggestions(console, pattern, line, ide.stage);
            } else {
                popup.hide();
            }
        });

        // Capturing filter: intercept navigation/commit keys before the console's
        // own ENTER-submit handler (and before the KEY_TYPED newline filter).
        console.addEventFilter(KeyEvent.KEY_PRESSED, e -> {
            if (!popup.isSuggestionShowing()) {
                return;
            }
            switch (e.getCode()) {
                case UP -> { popup.selectPrevious(); e.consume(); }
                case DOWN -> { popup.selectNext(); e.consume(); }
                case ENTER, TAB -> { insertSelected(); e.consume(); }
                case ESCAPE -> { popup.hide(); e.consume(); }
                default -> { }
            }
        });
    }

    /** @return true while the popup is visible. */
    public boolean isShowing() {
        return popup.isSuggestionShowing();
    }

    // ---------------------------------------------------------------------
    // Insert (compact port of EditorSuggestionHandler's TextArea path)
    // ---------------------------------------------------------------------

    private void insertSelected() {
        SuggestionProvider.Suggestion suggestion = popup.getSelected();
        if (suggestion == null) {
            return;
        }
        int lineStart = ide.inputStart;
        String fullText = console.getText();
        int caret = console.getCaretPosition();
        if (caret < lineStart) {
            caret = fullText.length();
        }
        String line = fullText.substring(lineStart, caret);
        int caretInLine = line.length();
        String pattern = extractPattern(line, caretInLine);
        if (pattern == null) {
            popup.hide();
            return;
        }

        int patternStartInLine = caretInLine - pattern.length();
        String code = suggestion.getCode();
        String closing = "";

        if ("Function".equals(suggestion.getCategory())) {
            String fn = FunctionProvider.extractFunctionName(code);
            if (FunctionProvider.isNotation(fn)) {
                code = fn;
            } else {
                code = fn + "(";
                closing = ")";
            }
        } else if (code.startsWith("\\var(\\") && code.endsWith(")")) {
            code = code.substring(5);
            if (code.endsWith(")")) {
                code = code.substring(0, code.length() - 1);
            }
            int varIdx = line.lastIndexOf("\\var(", patternStartInLine);
            if (varIdx != -1 && (line.indexOf(")", varIdx) == -1 || line.indexOf(")", varIdx) > caretInLine)) {
                closing = ")";
            }
        } else if (code.startsWith("\\con(\\") && code.endsWith(")")) {
            code = code.substring(5);
            if (code.endsWith(")")) {
                code = code.substring(0, code.length() - 1);
            }
            int conIdx = line.lastIndexOf("\\con(", patternStartInLine);
            if (conIdx != -1 && (line.indexOf(")", conIdx) == -1 || line.indexOf(")", conIdx) > caretInLine)) {
                closing = ")";
            }
        }

        int patternStartAbs = lineStart + patternStartInLine;
        if (code.startsWith("\\") && patternStartAbs > 0 && fullText.charAt(patternStartAbs - 1) == '\\') {
            patternStartAbs--;
        }
        String newText = fullText.substring(0, patternStartAbs) + code + closing + fullText.substring(caret);
        console.setText(newText);
        int newCaret = "Function".equals(suggestion.getCategory())
                ? patternStartAbs + code.length()
                : patternStartAbs + code.length() + closing.length();
        console.positionCaret(newCaret);

        SuggestionProvider.addRecentlyUsedSymbol(suggestion.getCode());
        popup.hide();
        console.requestFocus();
    }

    // ---------------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------------

    private String currentLine() {
        String text = console.getText();
        int start = Math.min(ide.inputStart, text.length());
        int caret = Math.min(Math.max(console.getCaretPosition(), start), text.length());
        return text.substring(start, caret);
    }

    private int caretWithinLine() {
        return currentLine().length();
    }

    /**
     * Extracts the token being typed: a {@code \var(} / {@code \con(} fragment, a
     * {@code \word} escape, or a plain identifier. Mirrors the editor's logic but
     * scoped to a single line.
     */
    private static String extractPattern(String line, int caret) {
        if (line == null || line.isEmpty() || caret <= 0) {
            return null;
        }
        int safe = Math.min(caret, line.length());

        int varIdx = line.lastIndexOf("\\var(", safe);
        if (varIdx != -1) {
            int close = line.indexOf(")", varIdx);
            if (close == -1 || close > safe) {
                String frag = line.substring(varIdx + 5, safe);
                if (frag.matches("[a-zA-Z0-9\\\\()_]*")) {
                    return frag;
                }
            }
        }
        int conIdx = line.lastIndexOf("\\con(", safe);
        if (conIdx != -1) {
            int close = line.indexOf(")", conIdx);
            if (close == -1 || close > safe) {
                String frag = line.substring(conIdx + 5, safe);
                if (frag.matches("[a-zA-Z0-9\\\\()_]*")) {
                    return frag;
                }
            }
        }
        int lastBackslash = line.lastIndexOf("\\", safe - 1);
        if (lastBackslash != -1) {
            String token = line.substring(lastBackslash, safe);
            if (token.matches("\\\\[a-zA-Z0-9_]*")) {
                return token;
            }
        }
        int wordStart = safe;
        while (wordStart > 0 && (Character.isLetterOrDigit(line.charAt(wordStart - 1))
                || line.charAt(wordStart - 1) == '_')) {
            wordStart--;
        }
        String word = line.substring(wordStart, safe);
        if (!word.isEmpty() && word.matches("[a-zA-Z_][a-zA-Z0-9_]*")) {
            return word;
        }
        return null;
    }
}
