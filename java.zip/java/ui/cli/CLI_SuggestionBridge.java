package ui.cli;

import javafx.scene.control.TextArea;
import javafx.scene.input.KeyEvent;
import ui.UI_Main;
import ui.ui_functions.FunctionProvider;
import ui.ui_functions.SuggestionPopup;
import ui.ui_functions.SuggestionProvider;

/**
 * Brings the Editor's autocomplete to the Command Window using the <b>same</b>
 * shared suggestion stack — no duplicate dictionaries.
 *
 * <h3>Why autocomplete stopped inserting</h3>
 * The popup was appearing but nothing was ever inserted. The old
 * {@code insertSelected} rebuilt the whole transcript and called
 * {@code console.setText(...)} — a content change starting at offset 0. The
 * console's freeze rejects any change that reaches into committed history, so
 * the insert was silently dropped. It now edits only the span it actually
 * means to replace, which sits inside the editable region and is allowed.
 *
 * <p>That is the freeze doing its job, not fighting it: rewriting the entire
 * console to insert three characters would also have wiped the session's
 * scrollback on every completion.
 *
 * <p>Suggestions are computed only from the current input line (the text after
 * {@code ide.inputStart}), so committed output never pollutes the pattern, and
 * are skipped while the IDE is printing interpreter output.
 */
public final class CLI_SuggestionBridge {

    private UI_Main ide;
    private TextArea console;
    private ConsoleInputGuard guard;
    private final SuggestionPopup popup = new SuggestionPopup();

    /**
     * Wires the bridge onto {@code ide.console}. Call once after the console
     * and its guard exist.
     *
     * @param ideRef   the IDE controller
     * @param guardRef the console's freeze guard
     */
    public void attach(UI_Main ideRef, ConsoleInputGuard guardRef) {
        this.ide = ideRef;
        this.console = ide.console;
        this.guard = guardRef;
        popup.setTheme(ide.currentTheme);
        popup.setOnInsertSuggestion(this::insertSelected);

        console.textProperty().addListener((obs, oldText, newText) -> {
            if (ide.stage == null || ide.stage.getScene() == null) {
                return;
            }
            if (guard != null && guard.isSystemWriting()) {
                return; // interpreter output, not the user typing
            }
            String line = currentLine();
            int caretInLine = line.length();
            if (line.isEmpty() || caretInLine <= 0) {
                popup.hide();
                return;
            }
            SuggestionProvider.updateVariablesFromText(line);
            String pattern = extractPattern(line, caretInLine);
            if (pattern != null && !pattern.trim().isEmpty()) {
                popup.setTheme(ide.currentTheme);
                popup.showSuggestions(console, pattern, line, ide.stage);
            } else {
                popup.hide();
            }
        });

        // Capturing filter: intercept navigation/commit keys. The guard's own
        // filter is registered first and defers to isSuggestionShowing(), so
        // ENTER reaches "submit" only when no suggestion is open.
        console.addEventFilter(KeyEvent.KEY_PRESSED, e -> {
            if (!popup.isSuggestionShowing()) {
                return;
            }
            switch (e.getCode()) {
                case UP -> { popup.selectPrevious(); e.consume(); }
                case DOWN -> { popup.selectNext(); e.consume(); }
                case ENTER, TAB -> { insertSelected(); e.consume(); }
                case ESCAPE -> { popup.hide(); e.consume(); }
                default -> { }
            }
        });
    }

    /**
     * Backwards-compatible entry point.
     *
     * @param ideRef the IDE controller
     */
    public void attach(UI_Main ideRef) {
        attach(ideRef, null);
    }

    /** @return true while the popup is visible. */
    public boolean isShowing() {
        return popup.isSuggestionShowing();
    }

    // ---------------------------------------------------------------------
    // Insert
    // ---------------------------------------------------------------------

    private void insertSelected() {
        SuggestionProvider.Suggestion suggestion = popup.getSelected();
        if (suggestion == null) {
            return;
        }
        int lineStart = Math.max(0, Math.min(ide.inputStart, console.getLength()));
        int caret = console.getCaretPosition();
        if (caret < lineStart) {
            caret = console.getLength();
        }
        String line = console.getText(lineStart, caret);
        int caretInLine = line.length();
        String pattern = extractPattern(line, caretInLine);
        if (pattern == null) {
            popup.hide();
            return;
        }

        int patternStartInLine = caretInLine - pattern.length();
        String code = suggestion.getCode();
        String closing = "";

        if ("Function".equals(suggestion.getCategory())) {
            String fn = FunctionProvider.extractFunctionName(code);
            if (FunctionProvider.isNotation(fn)) {
                code = fn;
            } else {
                code = fn + "(";
                closing = ")";
            }
        } else if (code.startsWith("\\var(\\") && code.endsWith(")")) {
            code = trimWrapper(code);
            int varIdx = line.lastIndexOf("\\var(", patternStartInLine);
            if (varIdx != -1 && (line.indexOf(")", varIdx) == -1 || line.indexOf(")", varIdx) > caretInLine)) {
                closing = ")";
            }
        } else if (code.startsWith("\\con(\\") && code.endsWith(")")) {
            code = trimWrapper(code);
            int conIdx = line.lastIndexOf("\\con(", patternStartInLine);
            if (conIdx != -1 && (line.indexOf(")", conIdx) == -1 || line.indexOf(")", conIdx) > caretInLine)) {
                closing = ")";
            }
        }

        int patternStartAbs = lineStart + patternStartInLine;
        if (code.startsWith("\\") && patternStartAbs > lineStart
                && console.getText(patternStartAbs - 1, patternStartAbs).equals("\\")) {
            patternStartAbs--;
        }

        // Replace ONLY the typed pattern. Never rebuild the whole console: the
        // freeze rejects edits that start before the prompt, and a full rebuild
        // would discard the scrollback.
        String insertion = code + closing;
        console.replaceText(patternStartAbs, caret, insertion);
        console.positionCaret("Function".equals(suggestion.getCategory())
                ? patternStartAbs + code.length()
                : patternStartAbs + insertion.length());

        SuggestionProvider.addRecentlyUsedSymbol(suggestion.getCode());
        popup.hide();
        console.requestFocus();
    }

    private static String trimWrapper(String code) {
        String trimmed = code.substring(5);
        return trimmed.endsWith(")") ? trimmed.substring(0, trimmed.length() - 1) : trimmed;
    }

    // ---------------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------------

    private String currentLine() {
        String text = console.getText();
        int start = Math.max(0, Math.min(ide.inputStart, text.length()));
        int caret = Math.min(Math.max(console.getCaretPosition(), start), text.length());
        return text.substring(start, caret);
    }

    /**
     * Extracts the token being typed: a {@code \var(} / {@code \con(} fragment,
     * a {@code \word} escape, or a plain identifier. Mirrors the editor's logic
     * but scoped to a single line.
     */
    private static String extractPattern(String line, int caret) {
        if (line == null || line.isEmpty() || caret <= 0) {
            return null;
        }
        int safe = Math.min(caret, line.length());

        String wrapped = wrapperFragment(line, safe, "\\var(");
        if (wrapped != null) {
            return wrapped;
        }
        wrapped = wrapperFragment(line, safe, "\\con(");
        if (wrapped != null) {
            return wrapped;
        }

        int lastBackslash = line.lastIndexOf("\\", safe - 1);
        if (lastBackslash != -1) {
            String token = line.substring(lastBackslash, safe);
            if (token.matches("\\\\[a-zA-Z0-9_]*")) {
                return token;
            }
        }
        int wordStart = safe;
        while (wordStart > 0 && (Character.isLetterOrDigit(line.charAt(wordStart - 1))
                || line.charAt(wordStart - 1) == '_')) {
            wordStart--;
        }
        String word = line.substring(wordStart, safe);
        if (!word.isEmpty() && word.matches("[a-zA-Z_][a-zA-Z0-9_]*")) {
            return word;
        }
        return null;
    }

    private static String wrapperFragment(String line, int safe, String opener) {
        int index = line.lastIndexOf(opener, safe);
        if (index == -1) {
            return null;
        }
        int close = line.indexOf(")", index);
        if (close != -1 && close <= safe) {
            return null;
        }
        String fragment = line.substring(index + opener.length(), safe);
        return fragment.matches("[a-zA-Z0-9\\\\()_]*") ? fragment : null;
    }
}
