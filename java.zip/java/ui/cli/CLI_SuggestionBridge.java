package ui.cli;

import javafx.application.Platform;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyEvent;
import ui.UI_Main;
import ui.ui_functions.FunctionProvider;
import ui.ui_functions.SuggestionPopup;
import ui.ui_functions.SuggestionProvider;
import ui.ui_functions.suggestion_functions.NcFileIndex;
import ui.ui_functions.suggestion_functions.SuggestionScope;
import ui.ui_functions.suggestion_functions.SuggestionSettings;

/**
 * Brings the Editor's autocomplete to the Command Window using the <b>same</b>
 * shared suggestion stack — no duplicate dictionaries.
 *
 * <h3>Why "sq" listed SD, sec, sin ...</h3>
 * The listener ran inside the text change, and a JavaFX {@code TextArea}
 * updates its text <i>before</i> it moves the caret. {@code currentLine()}
 * read the old caret, so the popup was always asked about the text one
 * character behind: typing {@code sq} asked for {@code s}, which is why every
 * {@code s} function appeared, sorted by length. The editor's CodeArea does not
 * have this ordering, which is why it was right. The query now runs on the next
 * pulse ({@link Platform#runLater}), after the caret has landed -- the same
 * deferral {@link ConsoleSymbolInput} already uses for the same reason.
 *
 * <h3>Script names</h3>
 * {@code .nc} scripts in the working folder are offered by name (without
 * {@code .nc}), below variables and functions, so {@code sct} completes to
 * {@code sct_01} and ENTER runs it. The Command Window excludes no file.
 *
 * <h3>Why autocomplete stopped inserting</h3>
 * The popup was appearing but nothing was ever inserted. The old
 * {@code insertSelected} rebuilt the whole transcript and called
 * {@code console.setText(...)} — a content change starting at offset 0. The
 * console's freeze rejects any change that reaches into committed history, so
 * the insert was silently dropped. It now edits only the span it actually
 * means to replace, which sits inside the editable region and is allowed.
 *
 * <p>That is the freeze doing its job, not fighting it: rewriting the entire
 * console to insert three characters would also have wiped the session's
 * scrollback on every completion.
 *
 * <p>Suggestions are computed only from the current input line (the text after
 * {@code ide.inputStart}), so committed output never pollutes the pattern, and
 * are skipped while the IDE is printing interpreter output.
 *
 * <p>The same two rules as the editor apply: nothing is suggested inside a
 * string literal or after a {@code #} / {@code \\} comment marker on the
 * input line ({@link SuggestionScope}), and the user's suggestion settings
 * decide which groups appear ({@link SuggestionSettings}).
 */
public final class CLI_SuggestionBridge {

    private UI_Main ide;
    private TextArea console;
    private ConsoleInputGuard guard;
    private final SuggestionPopup popup = new SuggestionPopup();

    /**
     * True while {@link #insertSelected()} writes the accepted row. That edit
     * is not typing: without this flag the deferred refresh would run after
     * the popup closed and re-open it on the word just inserted.
     */
    private boolean inserting;

    /**
     * Wires the bridge onto {@code ide.console}. Call once after the console
     * and its guard exist.
     *
     * @param ideRef   the IDE controller
     * @param guardRef the console's freeze guard
     */
    public void attach(UI_Main ideRef, ConsoleInputGuard guardRef) {
        this.ide = ideRef;
        this.console = ide.console;
        this.guard = guardRef;
        popup.setTheme(ide.currentTheme);
        popup.setOnInsertSuggestion(this::insertSelected);
        // Scripts are listed from the folder nc.exe resolves names against.
        // No file is excluded here: the Command Window is not inside a script.
        NcFileIndex.setWorkingFolderSupplier(ide::getCurrentFolder);
        popup.setExcludedFileSupplier(() -> null);

        console.textProperty().addListener((obs, oldText, newText) -> {
            if (ide.stage == null || ide.stage.getScene() == null) {
                return;
            }
            if (guard != null && guard.isSystemWriting()) {
                return; // interpreter output, not the user typing
            }
            if (inserting) {
                return; // the accepted row being written, not the user typing
            }
            // Deferred: the caret has not moved yet at this point.
            Platform.runLater(this::refreshSuggestions);
        });

        // Capturing filter: intercept navigation/commit keys. The guard's own
        // filter is registered first and defers to isSuggestionShowing(), so
        // ENTER reaches "submit" only when no suggestion is open.
        console.addEventFilter(KeyEvent.KEY_PRESSED, e -> {
            if (!popup.isSuggestionShowing()) {
                return;
            }
            switch (e.getCode()) {
                case UP -> { popup.selectPrevious(); e.consume(); }
                case DOWN -> { popup.selectNext(); e.consume(); }
                case ENTER, TAB -> { insertSelected(); e.consume(); }
                case ESCAPE -> { popup.hide(); e.consume(); }
                default -> { }
            }
        });
    }

    /**
     * Recomputes the popup from the input line as it stands now, caret
     * included. Runs one pulse after the text change.
     */
    private void refreshSuggestions() {
        if (ide.stage == null || ide.stage.getScene() == null) {
            return;
        }
        if (guard != null && guard.isSystemWriting()) {
            return;
        }
        String line = currentLine();
        int caretInLine = line.length();
        if (line.isEmpty() || caretInLine <= 0) {
            popup.hide();
            return;
        }
        SuggestionProvider.updateVariablesFromText(line);
        if (!SuggestionSettings.anyPopupGroupEnabled()
                || SuggestionScope.isSuppressedInLine(line)) {
            popup.hide();
            return;
        }
        String pattern = extractPattern(line, caretInLine);
        if (pattern != null && !pattern.trim().isEmpty()) {
            popup.setTheme(ide.currentTheme);
            popup.showSuggestions(console, pattern, line, ide.stage);
        } else {
            popup.hide();
        }
    }

    /**
     * Backwards-compatible entry point.
     *
     * @param ideRef the IDE controller
     */
    public void attach(UI_Main ideRef) {
        attach(ideRef, null);
    }

    /** @return true while the popup is visible. */
    public boolean isShowing() {
        return popup.isSuggestionShowing();
    }

    // ---------------------------------------------------------------------
    // Insert
    // ---------------------------------------------------------------------

    private void insertSelected() {
        SuggestionProvider.Suggestion suggestion = popup.getSelected();
        if (suggestion == null) {
            return;
        }
        int lineStart = Math.max(0, Math.min(ide.inputStart, console.getLength()));
        int caret = console.getCaretPosition();
        if (caret < lineStart) {
            caret = console.getLength();
        }
        String line = console.getText(lineStart, caret);
        int caretInLine = line.length();
        String pattern = extractPattern(line, caretInLine);
        if (pattern == null) {
            popup.hide();
            return;
        }

        int patternStartInLine = caretInLine - pattern.length();
        int replaceFromInLine = patternStartInLine;
        String category = suggestion.getCategory();
        String code = suggestion.getCode();
        String closing = "";

        if ("Function".equals(category)) {
            String fn = FunctionProvider.extractFunctionName(code);
            if (FunctionProvider.isNotation(fn)) {
                code = fn;
            } else {
                code = fn + "(";
                closing = ")";
            }
        } else if ("Variable".equals(category) || "StyledVariable".equals(category)) {
            // A workspace variable is inserted exactly as the provider gave it,
            // which is what EditorSuggestionHandler does. Unwrapping it here
            // would corrupt a styled name.
            closing = "";
        } else if (isSymbolCode(code)) {
            // The half-typed wrapper is swallowed along with the token. Greek
            // is one level deep (\var(\mu)) but every other script is two
            // (\var(\tamil(\ko))), and completing only the inner escape left
            // the parentheses one short: "\var(\tamil(\ko)" matches no rule in
            // the replacement table, so it was forwarded verbatim and nc.exe
            // answered "Unknown function 'tamil'". Replacing the span outright
            // makes the depth irrelevant.
            int wrapperStart = openWrapperStart(line, patternStartInLine, caretInLine);
            if (wrapperStart >= 0) {
                replaceFromInLine = wrapperStart;
            }
            String glyph = resolveGlyph(suggestion);

            // The character when it can be resolved; otherwise the provider's
            // own canonical code, which is balanced by construction and which
            // ConsoleSymbolInput then folds into the character for us.
            code = glyph != null ? glyph : suggestion.getCode();
            closing = "";
        }

        int patternStartAbs = lineStart + replaceFromInLine;
        if (code.startsWith("\\") && patternStartAbs > lineStart
                && console.getText(patternStartAbs - 1, patternStartAbs).equals("\\")) {
            patternStartAbs--;
        }

        // Replace ONLY the typed pattern. Never rebuild the whole console: the
        // freeze rejects edits that start before the prompt, and a full rebuild
        // would discard the scrollback.
        String insertion = code + closing;
        inserting = true;
        try {
            console.replaceText(patternStartAbs, caret, insertion);
            console.positionCaret("Function".equals(suggestion.getCategory())
                    ? patternStartAbs + code.length()
                    : patternStartAbs + insertion.length());
        } finally {
            inserting = false;
        }

        SuggestionProvider.addRecentlyUsedSymbol(suggestion.getCode());
        popup.hide();
        console.requestFocus();
    }

    private static boolean isSymbolCode(String code) {
        return code != null && (code.startsWith("\\var(") || code.startsWith("\\con("));
    }

    /**
     * Finds where the wrapper the user is typing inside begins, so the whole
     * half-finished span can be replaced at once.
     *
     * @param line         the current input line
     * @param patternStart offset of the token being completed
     * @param caret        offset of the caret within the line
     * @return the offset of the innermost unclosed {@code \var(} / {@code \con(},
     *         or -1 when the token stands on its own
     */
    private static int openWrapperStart(String line, int patternStart, int caret) {
        return Math.max(openerIndex(line, patternStart, caret, "\\var("),
                openerIndex(line, patternStart, caret, "\\con("));
    }

    private static int openerIndex(String line, int patternStart, int caret, String opener) {
        int index = line.lastIndexOf(opener, patternStart);
        if (index == -1) {
            return -1;
        }
        int close = line.indexOf(")", index);
        return close == -1 || close > caret ? index : -1;
    }

    /**
     * Resolves a symbol suggestion to the character it produces.
     *
     * <p>Two sources, in order of trust: the suggestion's own display value,
     * which the provider populates with the character itself, and failing that
     * {@link SuggestionProvider#getSymbolCharacter(String)}. Returning null is
     * always safe — the caller simply falls back to the escape-completion path
     * that was there before.
     *
     * @param suggestion the selected suggestion
     * @return the character, or null when it cannot be resolved confidently
     */
    private static String resolveGlyph(SuggestionProvider.Suggestion suggestion) {
        String display = suggestion.getDisplay();
        if (isGlyph(display)) {
            return display;
        }
        String simple = simpleSymbolName(suggestion.getCode());
        String converted = SuggestionProvider.getSymbolCharacter(simple);
        return isGlyph(converted) && !converted.equals(simple) ? converted : null;
    }

    /**
     * A glyph is short and carries at least one non-ASCII character. The test
     * matters: it is what stops a human-readable description or a plain
     * function name from ever being inserted as if it were a symbol.
     */
    private static boolean isGlyph(String candidate) {
        if (candidate == null || candidate.isEmpty() || candidate.length() > 4) {
            return false;
        }
        for (int i = 0; i < candidate.length(); i++) {
            if (candidate.charAt(i) > 0x7F) {
                return true;
            }
        }
        return false;
    }

    /** {@code \var(\tamil(\i))} to {@code i}; {@code \var(\mu)} to {@code mu}. */
    private static String simpleSymbolName(String code) {
        if (code == null || code.isEmpty()) {
            return "";
        }
        String[] scripted = {
                "\\var(\\tamil(", "\\var(\\sanskrit(", "\\var(\\hindi(",
                "\\var(\\telugu(", "\\var(\\malayalam("
        };
        for (String prefix : scripted) {
            if (code.startsWith(prefix)) {
                return stripTrailing(code.substring(prefix.length()));
            }
        }
        if (code.startsWith("\\var(\\") || code.startsWith("\\con(\\")) {
            return stripTrailing(code.substring(5));
        }
        return code;
    }

    private static String stripTrailing(String text) {
        String trimmed = text;
        while (trimmed.endsWith(")")) {
            trimmed = trimmed.substring(0, trimmed.length() - 1);
        }
        return trimmed.startsWith("\\") ? trimmed.substring(1) : trimmed;
    }

    // ---------------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------------

    private String currentLine() {
        String text = console.getText();
        int start = Math.max(0, Math.min(ide.inputStart, text.length()));
        int caret = Math.min(Math.max(console.getCaretPosition(), start), text.length());
        return text.substring(start, caret);
    }

    /**
     * Extracts the token being typed: a {@code \var(} / {@code \con(} fragment,
     * a {@code \word} escape, or a plain identifier. Mirrors the editor's logic
     * but scoped to a single line.
     */
    private static String extractPattern(String line, int caret) {
        if (line == null || line.isEmpty() || caret <= 0) {
            return null;
        }
        int safe = Math.min(caret, line.length());

        String wrapped = wrapperFragment(line, safe, "\\var(");
        if (wrapped != null) {
            return wrapped;
        }
        wrapped = wrapperFragment(line, safe, "\\con(");
        if (wrapped != null) {
            return wrapped;
        }

        int lastBackslash = line.lastIndexOf("\\", safe - 1);
        if (lastBackslash != -1) {
            String token = line.substring(lastBackslash, safe);
            if (token.matches("\\\\[a-zA-Z0-9_]*")) {
                return token;
            }
        }
        int wordStart = safe;
        while (wordStart > 0 && (Character.isLetterOrDigit(line.charAt(wordStart - 1))
                || line.charAt(wordStart - 1) == '_')) {
            wordStart--;
        }
        String word = line.substring(wordStart, safe);
        if (!word.isEmpty() && word.matches("[a-zA-Z_][a-zA-Z0-9_]*")) {
            return word;
        }
        return null;
    }

    private static String wrapperFragment(String line, int safe, String opener) {
        int index = line.lastIndexOf(opener, safe);
        if (index == -1) {
            return null;
        }
        int close = line.indexOf(")", index);
        if (close != -1 && close <= safe) {
            return null;
        }
        String fragment = line.substring(index + opener.length(), safe);
        return fragment.matches("[a-zA-Z0-9\\\\()_]*") ? fragment : null;
    }
}
