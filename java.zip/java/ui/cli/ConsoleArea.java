package ui.cli;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.function.BiPredicate;

import org.fxmisc.richtext.StyleClassedTextArea;
import org.fxmisc.richtext.model.ReadOnlyStyledDocument;
import org.fxmisc.richtext.model.SegmentOps;
import org.fxmisc.richtext.model.StyledDocument;
import org.fxmisc.richtext.model.TextOps;
import org.fxmisc.richtext.util.UndoUtils;

import javafx.geometry.BoundingBox;
import javafx.geometry.Bounds;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import ui.editor.ScriptStack;

/**
 * The Command Window's text control: a RichTextFX area, so typed commands
 * can be syntax coloured like the editor, with the {@code TextArea} methods
 * the rest of the CLI already calls.
 *
 * <h3>Kept TextArea names</h3>
 * <p>
 * {@link #positionCaret(int)} is added here; {@code getLength},
 * {@code getText(int, int)}, {@code appendText}, {@code deleteText},
 * {@code replaceText}, {@code selectRange}, {@code getSelection},
 * {@code getSelectedText}, {@code getCaretPosition}, {@code getAnchor},
 * {@code clear}, {@code paste} and {@code textProperty} already exist on
 * RichTextFX areas with the same meaning.
 * </p>
 *
 * <h3>The freeze: an edit veto</h3>
 * <p>
 * Every edit -- typing, paste, cut, delete, a programmatic write -- ends in
 * {@link #replace(int, int, StyledDocument)}. Overriding it gives one
 * checkpoint: when the veto says no, the text does not change.
 * {@link ConsoleInputGuard} installs the veto. Undo (a no-op undo manager)
 * and drag-to-move a selection are switched off here.
 * </p>
 *
 * <h3>Styled writes (new)</h3>
 * <p>
 * {@link #writeStyled} inserts text that already carries its style, as one
 * edit. Output used to be appended plain and coloured afterwards by a text
 * listener, one paragraph at a time; now each piece of output is written
 * once, already in its final colour.
 * </p>
 *
 * <h3>Where the user is looking (new)</h3>
 * <p>
 * {@link #isEndInView()} tells the CLI whether the console's last line is on
 * screen, wherever the caret is. {@link ConsoleViewport} uses it to decide
 * whether output may move the view.
 * </p>
 *
 * <h3>Bringing the caret into view (new)</h3>
 * <p>
 * RichTextFX's own "follow the caret" shows the caret's whole paragraph. The
 * last paragraph carries the scroll room under it (see
 * {@link ConsoleViewport}), about one window high, so following the caret put
 * the {@code >>} line at the top of an empty window -- on a click, on a
 * keystroke, on a Run. {@link #requestFollowCaret()} is therefore replaced:
 * it scrolls by exactly as much as the caret line itself needs, and
 * {@link #requestCaretAtBottom()} puts the caret line on the bottom row (a
 * jump to the newest results, MATLAB style). Both are done in
 * {@link #layoutChildren()}, after the text is laid out, and lay the view out
 * again at once, so nothing is drawn in between.
 * </p>
 * <p>
 * Every move is exact: positions are measured from the characters on screen
 * (never from paragraph bounds, which RichTextFX cuts off at the console's
 * edge) and the view is placed by paragraph ({@link #placeParagraphTop}),
 * never by the scroll pane's estimated scroll position, which lags behind
 * the text by up to a second.
 * </p>
 *
 * <h3>Follow-up work after an edit (new)</h3>
 * <p>
 * A change listener must never change the document itself: RichTextFX moves
 * the caret and selection for an edit only after every listener has heard
 * of it, so a second change made from inside a listener leaves the caret
 * pointing past the end of the text ("IndexOutOfBoundsException: 202 not in
 * [0, 194]" from {@code SelectionImpl}). Restyling and the tail paragraph's
 * class are therefore done in {@link #addAfterEdit after-edit actions}: a
 * listener only notes what changed, and the action runs once the edit --
 * including the caret update -- is complete.
 * </p>
 *
 * <p>
 * The area must sit in a {@code VirtualizedScrollPane} to scroll; see
 * {@code EditorCommandWindow}.
 * </p>
 */
public final class ConsoleArea extends StyleClassedTextArea {

    /** Style class the theme and the generated sheets key on. */
    public static final String STYLE_CLASS = "console-area";

    /** Text operations for {@code String} segments with style-class styles. */
    private static final TextOps<String, Collection<String>> TEXT_OPS = SegmentOps.styledTextOps();

    /** Paragraph style of written text; the tail class is managed by {@code ConsoleViewport}. */
    private static final Collection<String> NO_PARAGRAPH_STYLE = Collections.emptyList();

    /** (start, end) of a proposed edit; true refuses it. */
    private BiPredicate<Integer, Integer> editVeto = (start, end) -> false;

    /** Run after each outermost edit has fully completed; see the class notes. */
    private final List<Runnable> afterEdit = new ArrayList<>();

    /** Edits in progress (an after-edit action may itself edit). */
    private int editDepth;

    /** The room under the last line and the view keeping; set by {@link ConsoleViewport#attach}. */
    private ConsoleViewport viewport;

    /** A pending scroll to the caret, done in the next layout. */
    private enum Follow { NONE, MINIMAL, BOTTOM }

    private Follow follow = Follow.NONE;

    /** The layer {@link ScriptStack} draws stacked subscripts / superscripts on. */
    private final Pane scriptLayer = new Pane();

    public ConsoleArea() {
        super(false);
        getStyleClass().add(STYLE_CLASS);
        setUndoManager(UndoUtils.noOpUndoManager());
        setOnSelectionDropped(event -> { });
        setWrapText(true);
        setEditable(true);
        // Over the text, inside this node so the console's sheets style it;
        // ScriptStack is installed by ConsoleController.
        scriptLayer.setMouseTransparent(true);
        scriptLayer.setManaged(false);
        getChildren().add(scriptLayer);
    }

    /** @return the layer {@link ScriptStack} draws stacked subscripts and superscripts on */
    Pane getScriptLayer() {
        return scriptLayer;
    }

    /**
     * @param veto receives the start and end of every proposed edit; returning
     *             true refuses it. Null allows every edit.
     */
    public void setEditVeto(BiPredicate<Integer, Integer> veto) {
        this.editVeto = veto == null ? (start, end) -> false : veto;
    }

    /** @return the console's viewport control, or null before it is attached */
    ConsoleViewport getViewport() {
        return viewport;
    }

    void setViewport(ConsoleViewport viewport) {
        this.viewport = viewport;
    }

    /**
     * Adds an action run after every edit, once RichTextFX has finished it
     * (listeners notified, caret and selection moved). Actions may change
     * styles; they run again only for a text edit, not for a style change.
     *
     * @param action the follow-up work
     */
    public void addAfterEdit(Runnable action) {
        if (action != null) {
            afterEdit.add(action);
        }
    }

    /**
     * The one place every edit passes through; see the class notes.
     *
     * <p>
     * A caret or selection left past the end of the text by an earlier edit
     * (the prompt rewritten shorter while the caret stayed put) used to make
     * the next keystroke throw "[4, 3) is not a valid range within [0, 3)"
     * from RichTextFX, every keystroke again. The range and the selection are
     * pulled back inside the text first, so the keystroke lands at the end.
     * </p>
     */
    @Override
    public void replace(int start, int end,
            StyledDocument<Collection<String>, String, Collection<String>> replacement) {
        int length = getLength();
        if (getAnchor() > length || getCaretPosition() > length) {
            selectRange(Math.min(getAnchor(), length), Math.min(getCaretPosition(), length));
        }
        start = Math.max(0, Math.min(start, length));
        end = Math.max(start, Math.min(end, length));
        if (editVeto.test(start, end)) {
            return;
        }
        editDepth++;
        try {
            super.replace(start, end, replacement);
        } finally {
            editDepth--;
        }
        if (editDepth == 0) {
            for (Runnable action : afterEdit) {
                action.run();
            }
        }
    }

    /**
     * Replaces {@code start..end} with {@code text} in one style, as a single
     * edit. Line breaks in the text become paragraphs.
     *
     * @param start first offset replaced
     * @param end   offset after the last one replaced
     * @param text  the new text (null = empty)
     * @param style the style classes for all of it
     */
    public void writeStyled(int start, int end, String text, Collection<String> style) {
        replace(start, end, ReadOnlyStyledDocument.fromString(
                text == null ? "" : text, NO_PARAGRAPH_STYLE, style, TEXT_OPS));
    }

    /**
     * {@code TextArea.positionCaret}: moves the caret, clears the selection
     * and scrolls the caret into view (as little as needed).
     *
     * @param position the new caret offset; clamped to the text
     */
    public void positionCaret(int position) {
        moveTo(Math.max(0, Math.min(position, getLength())));
        requestFollowCaret();
    }

    // -----------------------------------------------------------------
    // Following the caret (replaces RichTextFX's own)
    // -----------------------------------------------------------------

    /**
     * Scrolls, in the next layout, by exactly as much as needed to show the
     * caret line; nothing when it is already visible. A caret far off screen
     * is brought to the bottom row. Also what RichTextFX's own key handling
     * calls after every keystroke.
     */
    @Override
    public void requestFollowCaret() {
        if (follow != Follow.BOTTOM) {
            follow = Follow.MINIMAL;
        }
        requestLayout();
    }

    /**
     * Puts the caret line on the bottom row in the next layout, the window
     * filled with the lines above it (a transcript shorter than the window
     * stays at the top).
     */
    public void requestCaretAtBottom() {
        follow = Follow.BOTTOM;
        requestLayout();
    }

    /** Drops a pending follow (the user is reading elsewhere; the view stays). */
    void cancelFollow() {
        follow = Follow.NONE;
    }

    @Override
    protected void layoutChildren() {
        super.layoutChildren();
        scriptLayer.resizeRelocate(0, 0, getWidth(), getHeight());
        Follow mode = follow;
        if (mode == Follow.NONE) {
            return;
        }
        follow = Follow.NONE;
        try {
            applyFollow(mode);
        } catch (RuntimeException notLaidOut) {
            // Not on screen yet: nothing to scroll.
        }
    }

    private void applyFollow(Follow mode) {
        // The text is laid out first, so everything measured below is the
        // text as it now stands, not the layout from before the latest edits.
        layoutFlow();
        Bounds view = viewportOnScreen();
        if (view == null || view.getHeight() <= 0) {
            return;
        }
        int paragraph = getCurrentParagraph();
        OptionalDouble top = paragraphTopOnScreen(paragraph);
        Bounds line = caretLineInParagraphMeasured(paragraph);
        boolean onScreen = top.isPresent()
                && top.getAsDouble() + line.getMaxY() > view.getMinY()
                && top.getAsDouble() + line.getMinY() < view.getMaxY();
        if (!onScreen) {
            // The caret line is off screen - after output longer than the
            // window, or when jumping from the history. Its paragraph is not
            // laid out, so where the line sits in it is estimated, the line
            // is put on the bottom row, and the result is measured below.
            placeParagraphTop(paragraph, view.getHeight() - line.getMaxY());
            layoutFlow();
            top = paragraphTopOnScreen(paragraph);
            if (top.isEmpty()) {
                return;
            }
            line = caretLineInParagraphMeasured(paragraph);
            mode = Follow.BOTTOM;
        }
        double lineTop = top.getAsDouble() + line.getMinY();
        double lineBottom = top.getAsDouble() + line.getMaxY();
        if (mode == Follow.BOTTOM || lineBottom > view.getMaxY()) {
            if (Math.abs(lineBottom - view.getMaxY()) >= 0.5) {
                placeParagraphTop(paragraph, view.getHeight() - line.getMaxY());
                layoutFlow();
            }
        } else if (lineTop < view.getMinY()) {
            placeParagraphTop(paragraph, -line.getMinY());
            layoutFlow();
        }
    }

    /**
     * Puts a paragraph's top {@code y} pixels below the top of the view
     * (negative: above it) in the next layout of the text.
     *
     * <p>
     * Exact, wherever the paragraph is: the scroll pane is asked to show a
     * region exactly one view high, starting {@code y} above the paragraph,
     * and it places the paragraph itself. {@code scrollYBy} is not used: it
     * works from the scroll pane's <em>estimates</em> of the scroll position
     * and the total height, which are refreshed only 15 ms (1 s when they
     * shrink) after the text changes. Within the frame of the change they
     * still describe the old text, so a scroll was clamped short or dropped
     * altogether -- the prompt left at the top left of an empty window -- or,
     * past one window, replaced by a jump to a guessed position that the
     * tall last paragraph (the room) throws off.
     * </p>
     *
     * <p>
     * A transcript shorter than the window still stays at the top left: the
     * scroll pane never leaves a gap above the first line.
     * </p>
     *
     * @param paragraph the paragraph
     * @param y         where its top goes, from the top of the view
     */
    void placeParagraphTop(int paragraph, double y) {
        Insets in = getInsets();
        double height = Math.max(1, getHeight() - in.getTop() - in.getBottom());
        showParagraphRegion(paragraph, new BoundingBox(0, -y, 1, height));
    }

    /**
     * Lays the text out now if an edit or a scroll is waiting for the next
     * frame, so it can be measured as it will be drawn.
     */
    void flushLayout() {
        if (getScene() == null) {
            return;
        }
        try {
            applyCss();
            layout();
        } catch (RuntimeException notLaidOut) {
            // Not on screen yet: nothing to lay out.
        }
    }

    /**
     * The top of a paragraph on screen, even when the top is scrolled out of
     * the view; empty when the paragraph is not laid out.
     *
     * <p>
     * RichTextFX's paragraph bounds are cut off at the console's edge (a
     * paragraph scrolled half out of the top reports the console's top as
     * its own), which made every position measured from them wrong by however
     * much the paragraph was scrolled out. When the top is cut off, it is
     * read from the first character's bounds, which are not cut off (less
     * the little a character's bounds reach above its line, measured on a
     * paragraph that is not cut off). An empty paragraph is one line high:
     * its top is read from its bottom.
     * </p>
     *
     * @param paragraph the paragraph
     * @return its top in screen coordinates
     */
    OptionalDouble paragraphTopOnScreen(int paragraph) {
        Optional<Bounds> box;
        try {
            box = getParagraphBoundsOnScreen(paragraph);
        } catch (RuntimeException notLaidOut) {
            return OptionalDouble.empty();
        }
        if (box.isEmpty()) {
            return OptionalDouble.empty();
        }
        Bounds b = box.get();
        Optional<Bounds> first = getParagraph(paragraph).length() > 0
                ? glyphOnScreen(paragraph, 0) : Optional.empty();
        Bounds console = localToScreen(getBoundsInLocal());
        boolean cutOff = console != null && b.getMinY() <= console.getMinY();
        if (!cutOff) {
            if (first.isPresent()) {
                glyphTopInset = first.get().getMinY() - b.getMinY();
            }
            return OptionalDouble.of(b.getMinY());
        }
        if (first.isPresent()) {
            return OptionalDouble.of(first.get().getMinY() - glyphTopInset);
        }
        if (paragraph < getParagraphs().size() - 1) {
            return OptionalDouble.of(b.getMaxY() - lineHeight());
        }
        return OptionalDouble.of(b.getMinY());
    }

    /**
     * How far a character's bounds start above (negative) or below its
     * line's top; RichTextFX draws a character's range a little taller than
     * the line. Measured on every paragraph that is not cut off.
     */
    private double glyphTopInset;

    /** Bounds of one character of a paragraph on screen (its whole line high); empty when not laid out. */
    private Optional<Bounds> glyphOnScreen(int paragraph, int column) {
        try {
            int at = getAbsolutePosition(paragraph, column);
            return getCharacterBoundsOnScreen(at, at + 1);
        } catch (RuntimeException notLaidOut) {
            return Optional.empty();
        }
    }

    /**
     * Where the caret's line sits inside its paragraph: which line it is is
     * measured from the characters on screen when the paragraph is laid out,
     * so a wrapped line is found exactly whatever the script (Greek and Tamil
     * are not as wide as Latin letters); estimated otherwise
     * ({@link #caretLineInParagraph()}). The line is {@link #lineHeight()}
     * high either way: a character's bounds are a little taller than its
     * line, and the current line must be placed the same whether it is the
     * empty line of a running command or the {@code >>} prompt.
     */
    private Bounds caretLineInParagraphMeasured(int paragraph) {
        int length = getParagraph(paragraph).length();
        if (length > 0) {
            // The character at the caret is on the caret's line (the caret
            // at a wrap is drawn at the start of the next line); at the end
            // of the paragraph, the last character is.
            int column = Math.max(0, Math.min(getCaretColumn(), length - 1));
            Optional<Bounds> first = glyphOnScreen(paragraph, 0);
            Optional<Bounds> glyph = glyphOnScreen(paragraph, column);
            if (first.isPresent() && glyph.isPresent()) {
                // Whole lines: a space's bounds sit a pixel off a letter's.
                double line = lineHeight();
                long index = Math.max(0, Math.round((glyph.get().getMinY() - first.get().getMinY()) / line));
                return new BoundingBox(0, index * line, 1, line);
            }
        }
        return caretLineInParagraph();
    }

    /**
     * Where the caret's line sits inside its paragraph, without the paragraph
     * being on screen: the console font is fixed-width, so the caret's column
     * and the width of the text tell which wrapped line it is on.
     */
    private Bounds caretLineInParagraph() {
        double lineHeight = lineHeight();
        int perLine = Math.max(1, charactersPerLine());
        int line = Math.max(0, getCaretColumn()) / perLine;
        return new BoundingBox(0, line * lineHeight, 1, lineHeight);
    }

    /**
     * How many characters of the console's fixed-width font fit on one line
     * of the text area: the width inside the padding divided by the width of
     * one character, rounded down. The interpreter is told this (less one,
     * for safety) to lay out wide matrices in column groups
     * ({@link CommandWindowWidth}).
     *
     * @return characters per line; 0 before the console is laid out
     */
    public int charactersPerLine() {
        Insets in = getInsets();
        double width = getWidth() - in.getLeft() - in.getRight();
        double charWidth = characterWidth();
        return width <= 0 ? 0 : (int) Math.floor(width / charWidth);
    }

    /** Width of one character of the console font (fixed-width), at least 1. */
    private double characterWidth() {
        Text probe = new Text("M");
        probe.setFont(consoleFont());
        return Math.max(1, probe.getLayoutBounds().getWidth());
    }

    /** Last line height measured from a drawn line; -1 until one was seen. */
    private double drawnLineHeight = -1;

    /**
     * The height of one console line -- the ONE measurement both this class
     * (placing the current line on the bottom row) and {@link ConsoleViewport}
     * (the room under the last line, and the after-layout check) use. The two
     * must agree to the pixel, or the check "corrects" a correct view and the
     * console blinks.
     *
     * <p>
     * It is read from a line actually on screen: a visible one-line paragraph
     * other than the last (the last carries the room as bottom padding). That
     * includes everything RichTextFX adds around the glyphs, which the font
     * alone ("Mg") does not -- measured from the font, the line came out a few
     * pixels short and the bottom of the {@code >>} line was cut off by the
     * window edge. Until such a line has been seen (a fresh console), the
     * font measure is used. Lines are uniform in this console, so the value
     * is kept; it changes only if a different height is actually drawn.
     * </p>
     *
     * <p>
     * Only a paragraph wholly on screen is measured, never the first or the
     * last visible one: RichTextFX cuts a paragraph's bounds off at the
     * console's edge, so the line half scrolled out at the top -- where the
     * current line on the bottom row nearly always leaves one -- measured
     * short, and the "line height" changed with the scroll position. Every
     * placement made with it then disagreed with the one before by a few
     * pixels: the text jumped on each command.
     * </p>
     *
     * @return the line height in pixels
     */
    double lineHeight() {
        double drawn = measureDrawnLine();
        if (drawn > 0) {
            drawnLineHeight = drawn;
        }
        if (drawnLineHeight > 0) {
            return drawnLineHeight;
        }
        Text tall = new Text("Mg");
        tall.setFont(consoleFont());
        return Math.max(1, Math.ceil(tall.getLayoutBounds().getHeight()));
    }

    /**
     * Height of a drawn one-line paragraph that is wholly on screen and not
     * the last; -1 if there is none. See {@link #lineHeight()} for why the
     * first and the last visible paragraphs are never measured.
     */
    private double measureDrawnLine() {
        try {
            int visible = getVisibleParagraphs().size();
            int last = getParagraphs().size() - 1;
            for (int i = 1; i < visible - 1; i++) {
                int paragraph = visibleParToAllParIndex(i);
                if (paragraph >= last || getParagraph(paragraph).length() == 0
                        || getParagraphLinesCount(paragraph) != 1) {
                    continue; // empty lines may be drawn shorter; long ones wrap
                }
                Bounds b = getVisibleParagraphBoundsOnScreen(i);
                if (b != null && b.getHeight() > 0) {
                    return b.getHeight();
                }
            }
        } catch (RuntimeException notLaidOut) {
            // fall through
        }
        return -1;
    }

    /** The font the console draws with (Consolas 13 until it is laid out). */
    private Font consoleFont() {
        Node node = lookup(".text");
        if (node instanceof Text text && text.getFont() != null) {
            return text.getFont();
        }
        return Font.font("Consolas", 13);
    }

    /**
     * The caret's line on screen, measured from its paragraph -- not from the
     * caret itself. The caret is a blinking node that is hidden half the time
     * and whenever the console does not have the focus (Run is clicked in
     * the editor), and RichTextFX reports no caret bounds then. Every follow
     * done while it was hidden took the "off screen" path, was placed
     * approximately, and corrected a frame later: the blink on Run.
     *
     * @return the line's bounds, or empty when its paragraph is not on screen
     */
    Optional<Bounds> caretLineOnScreen() {
        int paragraph = getCurrentParagraph();
        Optional<Bounds> box;
        try {
            box = getParagraphBoundsOnScreen(paragraph);
        } catch (RuntimeException notLaidOut) {
            return Optional.empty();
        }
        OptionalDouble top = paragraphTopOnScreen(paragraph);
        if (box.isEmpty() || top.isEmpty()) {
            return Optional.empty();
        }
        Bounds line = caretLineInParagraphMeasured(paragraph);
        return Optional.of(new BoundingBox(box.get().getMinX(), top.getAsDouble() + line.getMinY(),
                box.get().getWidth(), line.getHeight()));
    }

    /** Lays the text out now, so a scroll is applied before anything is drawn. */
    private void layoutFlow() {
        for (Node child : getChildrenUnmodifiable()) {
            if (child instanceof Parent parent) {
                parent.layout();
            }
        }
    }

    /** The part of the console text is drawn in, in screen coordinates. */
    Bounds viewportOnScreen() {
        Bounds b = localToScreen(getLayoutBounds());
        if (b == null) {
            return null;
        }
        Insets in = getInsets();
        return new BoundingBox(b.getMinX() + in.getLeft(), b.getMinY() + in.getTop(),
                Math.max(0, b.getWidth() - in.getLeft() - in.getRight()),
                Math.max(0, b.getHeight() - in.getTop() - in.getBottom()));
    }

    /**
     * True when the last line of the console (the prompt, or the line output
     * is going to) is on screen, wherever the caret is: the user is looking at
     * the live end. Also true while the console is not on screen.
     *
     * @return whether the end is in view
     */
    public boolean isEndInView() {
        if (getScene() == null || getScene().getWindow() == null
                || !getScene().getWindow().isShowing() || getHeight() <= 0 || !isShownInTree()
                || getLength() == 0) {
            return true;
        }
        try {
            int last = getParagraphs().size() - 1;
            int visible = getVisibleParagraphs().size();
            if (visible == 0 || lastVisibleParToAllParIndex() != last) {
                return false;
            }
            OptionalDouble top = paragraphTopOnScreen(last);
            Bounds view = viewportOnScreen();
            if (top.isEmpty() || view == null) {
                return true;
            }
            // The text sits at the top of the last paragraph (the room is
            // below it): the end is in view while any of its first line is.
            double lineTop = top.getAsDouble();
            return lineTop < view.getMaxY() - 2 && lineTop + lineHeight() > view.getMinY() + 2;
        } catch (RuntimeException notLaidOut) {
            return true;
        }
    }

    /** True when this node and all its parents are visible. */
    private boolean isShownInTree() {
        for (Node node = this; node != null; node = node.getParent()) {
            if (!node.isVisible()) {
                return false;
            }
        }
        return true;
    }
}
