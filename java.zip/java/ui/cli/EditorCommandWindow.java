package ui.cli;

import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.CustomMenuItem;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.SplitPane;
import javafx.scene.control.Tooltip;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import org.fxmisc.flowless.VirtualizedScrollPane;

import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import ui.UI_Main;
import ui.design.AstraFrame;
import ui.design.Dim;
import ui.design.MenuStyle;
import ui.design.section_dims.CommandWindow_dim;
import ui.editor.EditorGutterSeam;
import ui.editor.homeTab.StepFileRunner;
import ui.explorer.PanelTitleBar;
import ui.layout.LayoutManager;
import ui.managers.ThemeManager;

/**
 * The Command Window panel: title strip, three-dot options menu, and the
 * console beneath.
 *
 * <p>Moved from {@code ui.editor} into {@code ui.cli} as part of consolidating
 * the Command Window. Behaviour is unchanged — this is purely the panel chrome
 * (title strip + minimise/restore + options menu); all backend wiring lives in
 * {@link CLI_Main}.
 *
 * <h3>The console</h3>
 * The console is a RichTextFX {@link ConsoleArea}, which scrolls only inside
 * a {@code VirtualizedScrollPane}; the panel holds that scroll pane, and
 * minimising hides it.
 *
 * <h3>Title strip lines</h3>
 * While the Command Window is not the selected panel, its grey title strip has
 * a thin mid-grey line along its top and its bottom, as in MATLAB -- the same
 * grey as the panel dividers. Selected, the strip is navy as before.
 *
 * <h3>Copy</h3>
 * The three-dot menu's <b>Copy</b> puts the whole Command Window transcript --
 * every command, every output and the current prompt line -- on the system
 * clipboard. To copy only part of it, drag-select in the console and press
 * Ctrl+C, or use the console's right-click menu.
 *
 * <p>Unlike the explorers this panel has no collapse triangle. It minimises to
 * and restores from its title strip through the three-dot options menu, which
 * stays visible while minimised so the menu is always reachable.
 *
 * <h3>New Window, CLI History, Reset CLI History</h3>
 * <b>New Window</b> gives a fresh Command Window: the screen is cleared and a
 * new history session starts; the interpreter and the workspace are kept
 * (greyed out while a command runs). <b>CLI History</b> opens every saved
 * command, grouped by the session it was typed in (newest first, named by
 * the session's start time) and kept across restarts ({@link CliHistory}).
 * <b>Reset CLI History</b> deletes it after a confirmation.
 *
 * <h3>Stop</h3>
 * The menu's <b>Stop</b> stops the running command or script, exactly like
 * the ribbon's Stop and Ctrl+C in the console (see
 * {@link CLI_Main#stopExecution(UI_Main)}). It is greyed out unless a command
 * is executing, and follows that state live while the menu is open.
 *
 * <h3>Menu look</h3>
 * The three-dot menu is an ordinary application menu ({@link MenuStyle}):
 * the common width, a square box with a hairline outline, the shared
 * colours and the one menu font -- the same box as every other right-click
 * menu and drop-down.
 *
 * <h3>Standalone CLI</h3>
 * <pre>
 *   New Window
 *   Minimize                         (greyed while standalone)
 *   Standalone CLI                   docked
 *   Exit Standalone CLI          (*) standalone; (*) = green dot
 *   ----------------------------
 *   Copy / Stop / CLI History / Reset CLI History
 * </pre>
 * <b>Standalone CLI</b> moves this panel into a window of its own
 * ({@link StandaloneCliWindow}); the layout gives its place to the editor
 * (see {@code LayoutManager}). The entry then reads <b>Exit Standalone
 * CLI</b> with a green dot at its right edge, so the state is always visible
 * where it is changed. It is greyed in a Custom layout where the Command
 * Window is the only panel in the main window, and left out of the menu in a
 * Custom layout without the CLI. While standalone, the panel's own title
 * strip is hidden: the window's strip carries the title and this same menu
 * ({@link #setStandalone}).
 *
 * <h3>Layouts</h3>
 * Minimising shrinks the panel to its title strip, which only reads as a
 * minimise when the panel sits directly under the editor in a vertical split.
 * The Settings &gt; Layout arrangements that put the Command Window anywhere
 * else (a column of its own, or beside the Code Bot) call
 * {@link #setMinimizeAllowed(boolean)} with false: the panel is restored and
 * the menu's Minimize entry is greyed out until an arrangement allows it
 * again. {@link #attachTo(SplitPane)} is called again on every switch.
 */
public final class EditorCommandWindow {

    private static UI_Main ide;
    private static ConsoleArea console;
    /** The console inside its scroll pane; this is what the panel holds. */
    private static VirtualizedScrollPane<ConsoleArea> consoleView;
    private static VBox panel;
    private static PanelTitleBar header;
    private static SplitPane centerSplit;
    private static double savedDivider = Dim.Split.EDITOR_OVER_CONSOLE;
    private static boolean minimized = false;
    private static boolean minimizeAllowed = true;

    /**
     * Style class on the title strip. While the Command Window is not the
     * selected panel, the theme draws a mid-grey line above and below the
     * strip, as MATLAB does; the generated sheet gives it the top border width.
     */
    public static final String TITLE_CLASS = "command-window-title";

    /**
     * The "you are standalone" dot after Exit Standalone CLI. A state colour,
     * the same green family in both themes (a lighter step on the dark
     * menu), read when the menu is built -- it is rebuilt on every click.
     */
    private static final String STANDALONE_DOT_LIGHT = "#2E9E4F";
    private static final String STANDALONE_DOT_DARK = "#4CC26A";

    private static boolean standalone;

    private EditorCommandWindow() {
    }

    /**
     * Builds the panel. Call once, from Main_Window, after the console exists.
     *
     * @param ideRef     the IDE controller
     * @param consoleRef the console
     * @return the panel, ready to drop into the vertical centre SplitPane
     */
    public static VBox build(UI_Main ideRef, ConsoleArea consoleRef) {
        ide = ideRef;
        console = consoleRef;
        consoleView = new VirtualizedScrollPane<>(console);
        consoleView.getStyleClass().add("console-scroll");
        minimized = false;
        header = PanelTitleBar.create("Command Window")
                .withMenu(EditorCommandWindow::buildOptionsMenu);
        header.getNode().getStyleClass().add(TITLE_CLASS);
        panel = new VBox(header.getNode(), consoleView);
        panel.getStyleClass().add("titled-panel");
        panel.setFillWidth(true);
        VBox.setVgrow(consoleView, Priority.ALWAYS);
        return panel;
    }

    /** @return the title strip, for registration with PanelActivation */
    public static PanelTitleBar getHeader() {
        return header;
    }

    /** @return the panel node */
    public static VBox getPanel() {
        return panel;
    }

    /**
     * Tells the panel which vertical SplitPane it sits in, so its divider
     * position can be saved and restored across a minimise.
     *
     * @param split the editor-over-console SplitPane, or null when the panel
     *              is not directly under the editor
     */
    public static void attachTo(SplitPane split) {
        centerSplit = split;
        // Carries the editor's gutter band through this split's divider, so
        // no white notch shows under the line numbers (see EditorGutterSeam).
        EditorGutterSeam.attach(ide, split);
    }

    /**
     * Allows or forbids minimising. Forbidding it restores the panel first.
     *
     * @param allowed true where the panel sits directly under the editor
     */
    public static void setMinimizeAllowed(boolean allowed) {
        if (!allowed && minimized) {
            setMinimized(false);
        }
        minimizeAllowed = allowed;
    }

    /** @return true if the options menu may minimise the panel */
    public static boolean isMinimizeAllowed() {
        return minimizeAllowed;
    }

    /**
     * Standalone on or off, as far as the panel's own look is concerned: in
     * its own window the panel's title strip is hidden, because the window's
     * strip carries the title and the three-dot menu. Called by
     * {@code LayoutManager}; the panel is moved by it, not here.
     *
     * @param on true while the panel is in its own window
     */
    public static void setStandalone(boolean on) {
        standalone = on;
        if (on && minimized) {
            setMinimized(false);
        }
        if (header != null) {
            header.getNode().setVisible(!on);
            header.getNode().setManaged(!on);
        }
    }

    /** @return true while the panel is in its own window */
    public static boolean isStandalone() {
        return standalone;
    }

    /**
     * The three-dot options menu, fresh. For the standalone window's strip,
     * which shows the same menu as the panel's own strip.
     *
     * @return the menu
     */
    public static ContextMenu optionsMenu() {
        return buildOptionsMenu();
    }

    // =====================================================================
    // Options menu
    // =====================================================================

    private static ContextMenu buildOptionsMenu() {
        ContextMenu menu = new ContextMenu();
        MenuItem newWindow = new MenuItem("New Window");
        newWindow.setOnAction(e -> newWindow());
        // A fresh window while a command runs would lose its output.
        newWindow.disableProperty().bind(CLI_Main.busyProperty());
        MenuItem minimize = new MenuItem(minimized ? "Maximize" : "Minimize");
        minimize.setOnAction(e -> setMinimized(!minimized));
        minimize.setDisable(standalone || (!minimizeAllowed && !minimized));
        MenuItem copy = new MenuItem("Copy");
        copy.setDisable(console == null || console.getLength() == 0);
        copy.setOnAction(e -> copy());
        MenuItem stop = new MenuItem("Stop");
        stop.setOnAction(e -> CLI_Main.stopExecution(ide));
        // Live, not a snapshot: a script that finishes while the menu is open
        // greys the entry at once. Property bindings observe weakly, so the
        // menu (rebuilt on every click) is still collected.
        // Enabled during a step run too, like the ribbon's Stop: a block
        // paused inside the interpreter is not "busy", but it must be stoppable.
        stop.disableProperty().bind(
                CLI_Main.busyProperty().or(StepFileRunner.activeProperty()).not());
        MenuItem history = new MenuItem("CLI History");
        history.setOnAction(e -> CLI_Main.showHistory(ide));
        MenuItem resetHistory = new MenuItem("Reset CLI History");
        resetHistory.setOnAction(e -> confirmResetHistory());
        menu.getItems().addAll(newWindow, minimize);
        // Left out where the layout has no Command Window (Custom without CLI).
        if (LayoutManager.isCliStandaloneOffered()) {
            menu.getItems().add(standaloneItem());
        }
        menu.getItems().addAll(new SeparatorMenuItem(), copy, stop,
                new SeparatorMenuItem(), history, resetHistory);
        // 70 % of the common width: its entries are short.
        return MenuStyle.applySlim(menu);
    }

    /**
     * "Standalone CLI", or "Exit Standalone CLI" with a green dot pinned to
     * the right edge while the panel is in its own window.
     *
     * <p>
     * A {@link CustomMenuItem} holding a name / gap / dot row as wide as
     * {@link Dim.Menu#rowWidth(double)} of the slim menu width -- the same
     * build as the console's right-click entries -- so the dot sits in the
     * shortcut column and the name lines up with the plain entries above and
     * below.
     * </p>
     */
    private static CustomMenuItem standaloneItem() {
        boolean on = LayoutManager.isCliDetached();
        Label name = new Label(on ? "Exit Standalone CLI" : "Standalone CLI");
        Region gap = new Region();
        HBox.setHgrow(gap, Priority.ALWAYS);
        HBox row = new HBox(name, gap);
        row.setAlignment(Pos.CENTER_LEFT);
        row.setMinWidth(Dim.Menu.rowWidth(Dim.Menu.SLIM_WIDTH));
        row.setPrefWidth(Dim.Menu.rowWidth(Dim.Menu.SLIM_WIDTH));
        if (on) {
            boolean dark = "dark".equals(ThemeManager.getActiveTheme());
            Circle dot = new Circle(CommandWindow_dim.STANDALONE_DOT_RADIUS,
                    Color.web(dark ? STANDALONE_DOT_DARK : STANDALONE_DOT_LIGHT));
            row.getChildren().add(dot);
        }

        CustomMenuItem item = new CustomMenuItem(row, true);
        row.disableProperty().bind(item.disableProperty());
        boolean allowed = LayoutManager.canToggleCliStandalone();
        item.setDisable(!allowed);
        String tip;
        if (on) {
            tip = "Standalone CLI is on.\nDock the Command Window back into the layout.";
        } else if (allowed) {
            tip = "Open the Command Window in a window of its own.\nThe editor takes its place in the layout.";
        } else {
            tip = "Not available: the Command Window is the only panel\nin this Custom layout.";
        }
        Tooltip.install(row, new Tooltip(tip));
        // After the menu has closed: the panel is about to change windows.
        item.setOnAction(e -> Platform.runLater(() -> LayoutManager.setCliStandalone(!on)));
        return item;
    }

    /**
     * A fresh Command Window: the screen is cleared and a new CLI History
     * session starts, named by this moment. The interpreter and the
     * workspace carry on unchanged (see {@link CLI_Main#newWindow}).
     */
    public static void newWindow() {
        CLI_Main.newWindow(ide);
    }

    /**
     * Asks before deleting the saved command history, then deletes it.
     *
     * <p>
     * An {@link AstraFrame} dialog rather than an {@code Alert}: square, a
     * hairline outline, the title strip in the panels' active title colour
     * (the Custom layout's base colour when one is in force) and the menus'
     * body colour -- the same family as the menu that opened it. Enter
     * confirms, Esc cancels.
     * </p>
     */
    private static void confirmResetHistory() {
        boolean confirmed = AstraFrame.confirm(
                ide == null ? null : ide.stage,
                "Reset CLI History",
                "Delete every saved Command Window command?",
                "The commands of all sessions are removed. This cannot be undone.",
                "Delete",
                "Cancel");
        if (confirmed && !CLI_Main.resetHistory()) {
            CLI_Main.printNotice("CLI History could not be deleted: " + CliHistory.file());
        }
    }

    /**
     * Copies the entire Command Window history to the system clipboard. Nothing
     * is printed to the console, so copying never adds to what it copies.
     */
    public static void copy() {
        ConsoleInputGuard.copyAll(console);
    }

    // =====================================================================
    // Minimise / restore
    // =====================================================================

    /** @return true if only the title strip is showing */
    public static boolean isMinimized() {
        return minimized;
    }

    /** Flips between minimised and maximised. */
    public static void toggleMinimized() {
        setMinimized(!minimized);
    }

    /**
     * @param minimize true to collapse to the title strip, false to restore the
     *                 console to the height it had before
     */
    public static void setMinimized(boolean minimize) {
        if (panel == null || minimize == minimized) {
            return;
        }
        if (minimize && !minimizeAllowed) {
            return;
        }
        minimized = minimize;
        if (minimize) {
            if (centerSplit != null && centerSplit.getDividerPositions().length > 0) {
                savedDivider = centerSplit.getDividerPositions()[0];
            }
            consoleView.setVisible(false);
            consoleView.setManaged(false);
            panel.setMinHeight(PanelTitleBar.HEIGHT);
            panel.setPrefHeight(PanelTitleBar.HEIGHT);
            panel.setMaxHeight(PanelTitleBar.HEIGHT);
        } else {
            consoleView.setVisible(true);
            consoleView.setManaged(true);
            panel.setMinHeight(Region.USE_COMPUTED_SIZE);
            panel.setPrefHeight(Region.USE_COMPUTED_SIZE);
            panel.setMaxHeight(Double.MAX_VALUE);
            // Captured now: a layout switch can re-point centerSplit (or set
            // it to null) before the pulse runs.
            if (centerSplit != null) {
                final double restore = savedDivider;
                final SplitPane owner = centerSplit;
                Platform.runLater(() -> owner.setDividerPositions(restore));
            }
        }
    }
}
