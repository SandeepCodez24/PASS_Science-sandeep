package ui.cli;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Locale;

import javafx.application.Platform;
import javafx.scene.Parent;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TextArea;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import ui.UI_Main;
import ui.design.Dim;
import ui.design.Typography;
import ui.design.section_dims.CommandWindow_dim;
import ui.explorer.PanelTitleBar;
import ui.managers.TerminalManager;
/**
 * The Command Window panel: title strip, three-dot options menu, and the
 * console beneath.
 *
 * <p>Moved from {@code ui.editor} into {@code ui.cli} as part of consolidating
 * the Command Window. Behaviour is unchanged — this is purely the panel chrome
 * (title strip + minimise/restore + options menu); all backend wiring lives in
 * {@link CLI_Main}.
 *
 * <h3>Copy</h3>
 * The three-dot menu's <b>Copy</b> puts the whole Command Window transcript --
 * every command, every output and the current prompt line -- on the system
 * clipboard. To copy only part of it, drag-select in the console and press
 * Ctrl+C, or use the console's right-click menu.
 *
 * <p>Unlike the explorers this panel has no collapse triangle. It minimises to
 * and restores from its title strip through the three-dot options menu, which
 * stays visible while minimised so the menu is always reachable.
 *
 * <h3>Stop</h3>
 * The menu's <b>Stop</b> stops the running command or script, exactly like
 * the ribbon's Stop and Ctrl+C in the console (see
 * {@link CLI_Main#stopExecution(UI_Main)}). It is greyed out unless a command
 * is executing, and follows that state live while the menu is open.
 *
 * <h3>Menu size</h3>
 * The menu is 30% wider than it used to be and its text is the breadcrumb
 * bar's size. The numbers live in {@link CommandWindow_dim}; the font role is
 * {@code Typography.Role.BREADCRUMB_SEGMENT}. Colours still come from the
 * theme CSS. Only this panel's menu changes; the explorers keep theirs.
 *
 * <h3>Layouts</h3>
 * Minimising shrinks the panel to its title strip, which only reads as a
 * minimise when the panel sits directly under the editor in a vertical split.
 * The Settings &gt; Layout arrangements that put the Command Window anywhere
 * else (a column of its own, or beside the Code Bot) call
 * {@link #setMinimizeAllowed(boolean)} with false: the panel is restored and
 * the menu's Minimize entry is greyed out until an arrangement allows it
 * again. {@link #attachTo(SplitPane)} is called again on every switch.
 */
public final class EditorCommandWindow {

    private static UI_Main ide;
    private static TextArea console;
    private static VBox panel;
    private static PanelTitleBar header;
    private static SplitPane centerSplit;
    private static double savedDivider = Dim.Split.EDITOR_OVER_CONSOLE;
    private static boolean minimized = false;
    private static boolean minimizeAllowed = true;

    /** Style class on the options menu; the generated sheet keys on it. */
    private static final String MENU_CLASS = "command-window-options-menu";

    /** Every label the menu can show, so its width never jumps between states. */
    private static final String[] MENU_LABELS = { "New Window", "Minimize", "Maximize", "Copy", "Stop" };

    /** Built on first use, once the font families have been resolved. */
    private static String menuSheet;

    private EditorCommandWindow() {
    }

    /**
     * Builds the panel. Call once, from Main_Window, after the console exists.
     *
     * @param ideRef     the IDE controller
     * @param consoleRef the console text area
     * @return the panel, ready to drop into the vertical centre SplitPane
     */
    public static VBox build(UI_Main ideRef, TextArea consoleRef) {
        ide = ideRef;
        console = consoleRef;
        minimized = false;
        header = PanelTitleBar.create("Command Window")
                .withMenu(EditorCommandWindow::buildOptionsMenu);
        panel = new VBox(header.getNode(), console);
        panel.getStyleClass().add("titled-panel");
        panel.setFillWidth(true);
        VBox.setVgrow(console, Priority.ALWAYS);
        return panel;
    }

    /** @return the title strip, for registration with PanelActivation */
    public static PanelTitleBar getHeader() {
        return header;
    }

    /** @return the panel node */
    public static VBox getPanel() {
        return panel;
    }

    /**
     * Tells the panel which vertical SplitPane it sits in, so its divider
     * position can be saved and restored across a minimise.
     *
     * @param split the editor-over-console SplitPane, or null when the panel
     *              is not directly under the editor
     */
    public static void attachTo(SplitPane split) {
        centerSplit = split;
    }

    /**
     * Allows or forbids minimising. Forbidding it restores the panel first.
     *
     * @param allowed true where the panel sits directly under the editor
     */
    public static void setMinimizeAllowed(boolean allowed) {
        if (!allowed && minimized) {
            setMinimized(false);
        }
        minimizeAllowed = allowed;
    }

    /** @return true if the options menu may minimise the panel */
    public static boolean isMinimizeAllowed() {
        return minimizeAllowed;
    }

    // =====================================================================
    // Options menu
    // =====================================================================

    private static ContextMenu buildOptionsMenu() {
        ContextMenu menu = new ContextMenu();
        MenuItem newWindow = new MenuItem("New Window");
        newWindow.setOnAction(e -> newWindow());
        MenuItem minimize = new MenuItem(minimized ? "Maximize" : "Minimize");
        minimize.setOnAction(e -> setMinimized(!minimized));
        minimize.setDisable(!minimizeAllowed && !minimized);
        MenuItem copy = new MenuItem("Copy");
        copy.setDisable(console == null || console.getLength() == 0);
        copy.setOnAction(e -> copy());
        MenuItem stop = new MenuItem("Stop");
        stop.setOnAction(e -> CLI_Main.stopExecution(ide));
        // Live, not a snapshot: a script that finishes while the menu is open
        // greys the entry at once. Property bindings observe weakly, so the
        // menu (rebuilt on every click) is still collected.
        stop.disableProperty().bind(CLI_Main.busyProperty().not());
        menu.getItems().addAll(newWindow, minimize, new SeparatorMenuItem(), copy, stop);
        styleOptionsMenu(menu);
        return menu;
    }

    // =====================================================================
    // Options menu styling
    // =====================================================================

    /**
     * Tags the menu and attaches the size/font sheet to its root once the
     * skin exists. The class is added before the first show because the skin
     * copies it when it is created.
     */
    private static void styleOptionsMenu(ContextMenu menu) {
        menu.getStyleClass().add(MENU_CLASS);
        String sheet = optionsMenuSheet();
        menu.skinProperty().addListener((obs, oldSkin, newSkin) -> {
            if (newSkin != null && newSkin.getNode() instanceof Parent root
                    && !root.getStylesheets().contains(sheet)) {
                root.getStylesheets().add(sheet);
            }
        });
    }

    private static String optionsMenuSheet() {
        if (menuSheet != null) {
            return menuSheet;
        }
        Typography.Role role = Typography.Role.BREADCRUMB_SEGMENT;
        String family = "-fx-font-family: " + Typography.familyCss(Typography.family(role)) + ";";
        String font = family + " " + Typography.css(role);
        String width = String.format(Locale.ROOT, "%.1f", optionsMenuWidth());

        String css = ""
                + "." + MENU_CLASS + " {"
                + " -fx-min-width: " + width + "px;"
                + " " + font
                + " }\n"
                // Same specificity as a theme's ".context-menu .menu-item .label",
                // and parent sheets are consulted after scene sheets, so this wins.
                + "." + MENU_CLASS + " .menu-item .label {"
                + " " + font
                + " }\n";
        menuSheet = "data:text/css;base64,"
                + Base64.getEncoder().encodeToString(css.getBytes(StandardCharsets.UTF_8));
        return menuSheet;
    }

    /**
     * The menu's old natural width (longest label at the inherited base font,
     * plus Modena's default insets) times
     * {@link CommandWindow_dim#OPTIONS_MENU_WIDTH_SCALE}.
     */
    private static double optionsMenuWidth() {
        Font before = Typography.font(Typography.Role.BASE);
        double widest = 0;
        for (String label : MENU_LABELS) {
            Text probe = new Text(label);
            probe.setFont(before);
            widest = Math.max(widest, probe.getLayoutBounds().getWidth());
        }
        double em = before.getSize();
        double natural = widest
                + 2 * em * CommandWindow_dim.OPTIONS_MENU_BASE_ITEM_PAD_H_EM
                + 2 * em * CommandWindow_dim.OPTIONS_MENU_BASE_PAD_EM
                + 2 * CommandWindow_dim.OPTIONS_MENU_BORDER;
        double scaled = Math.ceil(natural * CommandWindow_dim.OPTIONS_MENU_WIDTH_SCALE);
        return Math.max(scaled, CommandWindow_dim.OPTIONS_MENU_MIN_WIDTH);
    }

    /** Placeholder: will detach the console into its own Stage. */
    public static void newWindow() {
        TerminalManager.println(ide, "new command window is clicked");
    }

    /**
     * Copies the entire Command Window history to the system clipboard. Nothing
     * is printed to the console, so copying never adds to what it copies.
     */
    public static void copy() {
        ConsoleInputGuard.copyAll(console);
    }

    // =====================================================================
    // Minimise / restore
    // =====================================================================

    /** @return true if only the title strip is showing */
    public static boolean isMinimized() {
        return minimized;
    }

    /** Flips between minimised and maximised. */
    public static void toggleMinimized() {
        setMinimized(!minimized);
    }

    /**
     * @param minimize true to collapse to the title strip, false to restore the
     *                 console to the height it had before
     */
    public static void setMinimized(boolean minimize) {
        if (panel == null || minimize == minimized) {
            return;
        }
        if (minimize && !minimizeAllowed) {
            return;
        }
        minimized = minimize;
        if (minimize) {
            if (centerSplit != null && centerSplit.getDividerPositions().length > 0) {
                savedDivider = centerSplit.getDividerPositions()[0];
            }
            console.setVisible(false);
            console.setManaged(false);
            panel.setMinHeight(PanelTitleBar.HEIGHT);
            panel.setPrefHeight(PanelTitleBar.HEIGHT);
            panel.setMaxHeight(PanelTitleBar.HEIGHT);
        } else {
            console.setVisible(true);
            console.setManaged(true);
            panel.setMinHeight(Region.USE_COMPUTED_SIZE);
            panel.setPrefHeight(Region.USE_COMPUTED_SIZE);
            panel.setMaxHeight(Double.MAX_VALUE);
            // Captured now: a layout switch can re-point centerSplit (or set
            // it to null) before the pulse runs.
            if (centerSplit != null) {
                final double restore = savedDivider;
                final SplitPane owner = centerSplit;
                Platform.runLater(() -> owner.setDividerPositions(restore));
            }
        }
    }
}
