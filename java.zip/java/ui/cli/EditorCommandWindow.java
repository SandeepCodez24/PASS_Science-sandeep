package ui.cli;

import javafx.application.Platform;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TextArea;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import ui.UI_Main;
import ui.design.Dim;
import ui.explorer.PanelTitleBar;
import ui.managers.TerminalManager;
/**
 * The Command Window panel: title strip, three-dot options menu, and the
 * console beneath.
 *
 * <p>Moved from {@code ui.editor} into {@code ui.cli} as part of consolidating
 * the Command Window. Behaviour is unchanged — this is purely the panel chrome
 * (title strip + minimise/restore + options menu); all backend wiring lives in
 * {@link CLI_Main}.
 *
 * <h3>Copy</h3>
 * The three-dot menu's <b>Copy</b> puts the whole Command Window transcript --
 * every command, every output and the current prompt line -- on the system
 * clipboard. To copy only part of it, drag-select in the console and press
 * Ctrl+C, or use the console's right-click menu.
 *
 * <p>Unlike the explorers this panel has no collapse triangle. It minimises to
 * and restores from its title strip through the three-dot options menu, which
 * stays visible while minimised so the menu is always reachable.
 */
public final class EditorCommandWindow {

    private static UI_Main ide;
    private static TextArea console;
    private static VBox panel;
    private static PanelTitleBar header;
    private static SplitPane centerSplit;
    private static double savedDivider = Dim.Split.EDITOR_OVER_CONSOLE;
    private static boolean minimized = false;

    private EditorCommandWindow() {
    }

    /**
     * Builds the panel. Call once, from Main_Window, after the console exists.
     *
     * @param ideRef     the IDE controller
     * @param consoleRef the console text area
     * @return the panel, ready to drop into the vertical centre SplitPane
     */
    public static VBox build(UI_Main ideRef, TextArea consoleRef) {
        ide = ideRef;
        console = consoleRef;
        minimized = false;
        header = PanelTitleBar.create("Command Window")
                .withMenu(EditorCommandWindow::buildOptionsMenu);
        panel = new VBox(header.getNode(), console);
        panel.getStyleClass().add("titled-panel");
        panel.setFillWidth(true);
        VBox.setVgrow(console, Priority.ALWAYS);
        return panel;
    }

    /** @return the title strip, for registration with PanelActivation */
    public static PanelTitleBar getHeader() {
        return header;
    }

    /** @return the panel node */
    public static VBox getPanel() {
        return panel;
    }

    /**
     * Tells the panel which vertical SplitPane it sits in, so its divider
     * position can be saved and restored across a minimise.
     *
     * @param split the editor-over-console SplitPane
     */
    public static void attachTo(SplitPane split) {
        centerSplit = split;
    }

    // =====================================================================
    // Options menu
    // =====================================================================

    private static ContextMenu buildOptionsMenu() {
        ContextMenu menu = new ContextMenu();
        MenuItem newWindow = new MenuItem("New Window");
        newWindow.setOnAction(e -> newWindow());
        MenuItem minimize = new MenuItem(minimized ? "Maximize" : "Minimize");
        minimize.setOnAction(e -> setMinimized(!minimized));
        MenuItem copy = new MenuItem("Copy");
        copy.setDisable(console == null || console.getLength() == 0);
        copy.setOnAction(e -> copy());
        menu.getItems().addAll(newWindow, minimize, new SeparatorMenuItem(), copy);
        return menu;
    }

    /** Placeholder: will detach the console into its own Stage. */
    public static void newWindow() {
        TerminalManager.println(ide, "new command window is clicked");
    }

    /**
     * Copies the entire Command Window history to the system clipboard. Nothing
     * is printed to the console, so copying never adds to what it copies.
     */
    public static void copy() {
        ConsoleInputGuard.copyAll(console);
    }

    // =====================================================================
    // Minimise / restore
    // =====================================================================

    /** @return true if only the title strip is showing */
    public static boolean isMinimized() {
        return minimized;
    }

    /** Flips between minimised and maximised. */
    public static void toggleMinimized() {
        setMinimized(!minimized);
    }

    /**
     * @param minimize true to collapse to the title strip, false to restore the
     *                 console to the height it had before
     */
    public static void setMinimized(boolean minimize) {
        if (panel == null || minimize == minimized) {
            return;
        }
        minimized = minimize;
        if (minimize) {
            if (centerSplit != null && centerSplit.getDividerPositions().length > 0) {
                savedDivider = centerSplit.getDividerPositions()[0];
            }
            console.setVisible(false);
            console.setManaged(false);
            panel.setMinHeight(PanelTitleBar.HEIGHT);
            panel.setPrefHeight(PanelTitleBar.HEIGHT);
            panel.setMaxHeight(PanelTitleBar.HEIGHT);
        } else {
            console.setVisible(true);
            console.setManaged(true);
            panel.setMinHeight(Region.USE_COMPUTED_SIZE);
            panel.setPrefHeight(Region.USE_COMPUTED_SIZE);
            panel.setMaxHeight(Double.MAX_VALUE);
            if (centerSplit != null) {
                final double restore = savedDivider;
                Platform.runLater(() -> centerSplit.setDividerPositions(restore));
            }
        }
    }
}
