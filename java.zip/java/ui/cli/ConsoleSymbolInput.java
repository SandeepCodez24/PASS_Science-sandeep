package ui.cli;

import javafx.application.Platform;
import javafx.scene.control.TextArea;
import ui.UI_Main;
import ui.managers.LanguageDesignManager;

/**
 * Gives the Command Window the same live symbol replacement the editor has:
 * type {@code \\var(\\mu)} and it becomes &#956; as soon as the closing bracket
 * lands, exactly as it does in a {@code .nc} tab.
 *
 * <h3>Why it reuses LanguageDesignManager</h3>
 * The replacement rules are <b>not</b> reimplemented here. This class calls
 * {@link LanguageDesignManager#applySymbolReplacements(String)} — the very
 * function the save/run pipeline uses — so the CLI and the editor cannot drift
 * apart. A second, parallel table of rules would be a guaranteed source of
 * "it works in the editor but not the CLI" bugs.
 *
 * <p>Covered today: every Greek, Tamil, Telugu, Malayalam, Sanskrit and
 * constant symbol, plus the numeric script shorthands {@code ^^2} and
 * {@code __2}.
 *
 * <h3>Scope</h3>
 * Only the text after the prompt is ever touched. Committed history is never
 * rewritten, and replacement is skipped entirely while the IDE is writing
 * interpreter output, so a &#956; appearing in a result is left alone.
 */
public final class ConsoleSymbolInput {

    private final UI_Main ide;
    private final TextArea area;
    private final ConsoleInputGuard guard;

    private boolean rewriting;

    private ConsoleSymbolInput(UI_Main ide, ConsoleInputGuard guard) {
        this.ide = ide;
        this.area = ide.console;
        this.guard = guard;
    }

    /**
     * Installs live replacement on the console.
     *
     * @param ide   the IDE controller
     * @param guard the console's freeze guard
     */
    public static void attach(UI_Main ide, ConsoleInputGuard guard) {
        new ConsoleSymbolInput(ide, guard).install();
    }

    private void install() {
        area.textProperty().addListener((observable, oldText, newText) -> {
            if (rewriting || guard.isSystemWriting()) {
                return;
            }
            // Deferred so the control finishes applying the user's keystroke
            // before the line is rewritten underneath it.
            Platform.runLater(this::rewriteInputLine);
        });
    }

    private void rewriteInputLine() {
        if (rewriting || guard.isSystemWriting()) {
            return;
        }
        String line = guard.currentInput();
        if (line.isEmpty()) {
            return;
        }
        String replaced = LanguageDesignManager.applySymbolReplacements(line);
        if (replaced.equals(line)) {
            return;
        }

        int caret = area.getCaretPosition();
        int shrink = line.length() - replaced.length();

        rewriting = true;
        try {
            guard.setInput(replaced);
            int target = Math.max(ide.inputStart, caret - shrink);
            area.positionCaret(Math.min(target, area.getLength()));
        } finally {
            rewriting = false;
        }
    }
}
