package ui.cli;

import javafx.application.Platform;
import ui.UI_Main;
import ui.managers.LanguageDesignManager;

/**
 * Gives the Command Window the same live symbol replacement the editor has:
 * type {@code \\var(\\mu)} and it becomes &#956; as soon as the closing bracket
 * lands, exactly as it does in a {@code .nc} tab.
 *
 * <h3>Why it reuses LanguageDesignManager</h3>
 * The replacement rules are <b>not</b> reimplemented here. This class calls
 * {@link LanguageDesignManager#applySymbolReplacements(String)} -- the very
 * function the save/run pipeline uses -- so the CLI and the editor cannot drift
 * apart.
 *
 * <h3>Scope</h3>
 * Only the input region is ever touched. Committed history is never
 * rewritten, and replacement is skipped entirely while the CLI is writing,
 * so a &#956; appearing in a result is left alone.
 *
 * <h3>Cost (changed)</h3>
 * It listens to the console's plain-text <i>changes</i>, not to its
 * {@code textProperty}: a listener on the latter made RichTextFX build the
 * whole transcript as one string on every keystroke and every output
 * append. Now only the input region is read, and only after a user edit.
 */
public final class ConsoleSymbolInput {

    private final UI_Main ide;
    private final ConsoleArea area;
    private final ConsoleInputGuard guard;

    private boolean rewriting;
    private boolean queued;

    private ConsoleSymbolInput(UI_Main ide, ConsoleInputGuard guard) {
        this.ide = ide;
        this.area = ide.console;
        this.guard = guard;
    }

    /**
     * Installs live replacement on the console.
     *
     * @param ide   the IDE controller
     * @param guard the console's guard
     */
    public static void attach(UI_Main ide, ConsoleInputGuard guard) {
        new ConsoleSymbolInput(ide, guard).install();
    }

    private void install() {
        area.plainTextChanges().subscribe(change -> {
            if (rewriting || guard.isSystemWriting() || queued) {
                return;
            }
            // Deferred so the control finishes applying the keystroke before
            // the input is rewritten underneath it.
            queued = true;
            Platform.runLater(() -> {
                queued = false;
                rewriteInput();
            });
        });
    }

    private void rewriteInput() {
        if (rewriting || guard.isSystemWriting()) {
            return;
        }
        String input = guard.currentInput();
        if (input.isEmpty()) {
            return;
        }
        String replaced = LanguageDesignManager.applySymbolReplacements(input);
        if (replaced.equals(input)) {
            return;
        }

        int caret = area.getCaretPosition();
        int shrink = input.length() - replaced.length();

        rewriting = true;
        try {
            guard.setInput(replaced);
            int target = Math.max(ide.inputStart, caret - shrink);
            area.positionCaret(Math.min(target, area.getLength()));
        } finally {
            rewriting = false;
        }
    }
}
