package ui.cli;

import javafx.geometry.Pos;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.CustomMenuItem;
import javafx.scene.control.Label;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import ui.UI_Main;
import ui.design.Dim;
import ui.design.MenuStyle;
import ui.editor.ScriptedCaret;
import ui.editor.ScriptStack;
import ui.editor.ScriptedNameStyles;

/**
 * Creates and configures the Command Window text area.
 *
 * <p>The console is a {@link ConsoleArea} (RichTextFX). Three helpers are
 * attached to it here, each with one job:
 * <ul>
 *   <li>{@link ConsoleInputGuard} -- the transcript: what is frozen, where
 *       output and the prompt go, keystrokes;</li>
 *   <li>{@link ConsoleHighlighter} -- colours what the user types (system
 *       writes are coloured when written);</li>
 *   <li>{@link ConsoleViewport} -- the room under the last line, so the
 *       prompt line can be scrolled to the top (MATLAB style).</li>
 * </ul>
 *
 * <h3>Right-click menu</h3>
 * <pre>
 *   Copy                    Ctrl+C    the selection, history included
 *   Copy All                          the whole transcript
 *   ---------------------------------
 *   Paste                   Ctrl+V    always into the input
 *   Select All              Ctrl+A    the whole transcript, ready to copy
 * </pre>
 *
 * <p>The shortcut texts are labels only; the keys themselves are handled by
 * the area and {@link ConsoleInputGuard}. The same box as every other menu
 * ({@link MenuStyle}).
 */
public final class ConsoleController {

    private ConsoleController() {
    }

    /**
     * Initializes {@code ide.console} and installs the freeze, the live
     * colouring and the scroll room.
     *
     * @param ide the IDE controller
     * @return the guard owning the console's transcript
     */
    public static ConsoleInputGuard initialize(UI_Main ide) {
        ide.console = new ConsoleArea();
        ide.console.setPrefHeight(140);
        ide.console.setStyle("-fx-font-family: Consolas; -fx-font-size: 13;");
        ide.inputStart = 0;
        ide.console.moveTo(0);

        ConsoleInputGuard guard = new ConsoleInputGuard(ide, ide.console);
        // Only the user's own edits are coloured here; everything the CLI
        // writes carries its colour already.
        ConsoleHighlighter.attach(ide.console, () -> ide.inputStart, () -> !guard.isSystemWriting());
        ConsoleViewport.attach(ide.console).setInputStart(() -> ide.inputStart);
        // Subscripts and superscripts: A_$1 is drawn A₁ (the _$ / _@ marker
        // hidden, the rest lowered / raised), and one arrow press steps over
        // a hidden marker -- as in the editor. Keys only, no caret listener:
        // output moves the console's caret all the time (see ScriptedCaret).
        ScriptedNameStyles.attachConsole(ide.console);
        ScriptedCaret.installKeysOnly(ide.console);
        ScriptStack.install(ide.console, ide.console.getScriptLayer());
        installContextMenu(ide.console, guard);
        return guard;
    }

    /**
     * Read-only right-click menu: copy anything, paste only into the input.
     *
     * @param console the console
     * @param guard   its guard
     */
    private static void installContextMenu(ConsoleArea console, ConsoleInputGuard guard) {
        CustomMenuItem copy = entry("Copy", KeyCode.C);
        copy.setOnAction(e -> guard.copySelection());

        CustomMenuItem copyAll = entry("Copy All", null);
        copyAll.setOnAction(e -> guard.copyAll());

        CustomMenuItem paste = entry("Paste", KeyCode.V);
        paste.setOnAction(e -> {
            // Whatever is selected, a paste belongs to the input.
            console.positionCaret(console.getLength());
            console.paste();
        });

        CustomMenuItem selectAll = entry("Select All", KeyCode.A);
        selectAll.setOnAction(e -> console.selectRange(0, console.getLength()));

        ContextMenu menu = new ContextMenu(copy, copyAll, new SeparatorMenuItem(), paste, selectAll);
        MenuStyle.apply(menu);

        // Copy is only meaningful with a selection; refreshed each time it opens.
        menu.setOnShowing(e -> copy.setDisable(console.getSelection().getLength() == 0));
        console.setContextMenu(menu);
    }

    /**
     * Builds one menu entry: name on the left, shortcut pinned to the right.
     *
     * @param text the entry's name
     * @param key  the Ctrl/Cmd key shown on the right, or null for none
     * @return the entry
     */
    private static CustomMenuItem entry(String text, KeyCode key) {
        Label name = new Label(text);
        Region gap = new Region();
        HBox.setHgrow(gap, Priority.ALWAYS);

        HBox row = new HBox(name, gap);
        row.setAlignment(Pos.CENTER_LEFT);
        row.setMinWidth(Dim.Menu.rowWidth());
        row.setPrefWidth(Dim.Menu.rowWidth());

        if (key != null) {
            String keys = new KeyCodeCombination(key, KeyCombination.SHORTCUT_DOWN).getDisplayText();
            Label shortcut = new Label(keys);
            shortcut.getStyleClass().add("accelerator-text");
            row.getChildren().add(shortcut);
        }

        CustomMenuItem item = new CustomMenuItem(row, true);
        row.disableProperty().bind(item.disableProperty());
        return item;
    }
}
