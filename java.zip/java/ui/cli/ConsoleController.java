package ui.cli;

import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import ui.UI_Main;

/**
 * Creates and configures the Command Window text area.
 *
 * <p>All prompt-boundary and keystroke policy now lives in
 * {@link ConsoleInputGuard}; this class only builds the control and hands it
 * over. Keeping the two apart means {@link CLI_Main} is about commands and the
 * guard is about keystrokes, and neither has to know the other's rules.
 *
 * <h3>Right-click menu</h3>
 * The {@code TextArea}'s default menu offered Undo, Redo, Cut and Delete, all of
 * which either did nothing (the freeze rejected them) or could reach into the
 * history. It is replaced with a menu that only reads the transcript:
 *
 * <pre>
 *   Copy            Ctrl+C    the selection, history included
 *   Copy All                  the whole transcript
 *   -------------------------
 *   Paste           Ctrl+V    always into the prompt line
 *   Select All                the whole transcript, ready to copy
 * </pre>
 */
public final class ConsoleController {

    private ConsoleController() {
    }

    /**
     * Initializes {@code ide.console} and installs the freeze.
     *
     * @param ide the IDE controller
     * @return the guard owning the console's editable region
     */
    public static ConsoleInputGuard initialize(UI_Main ide) {
        ide.console = new TextArea();
        ide.console.getStyleClass().add("console-area");
        ide.console.setWrapText(true);
        ide.console.setPrefHeight(140);
        ide.console.setStyle("-fx-font-family: Consolas; -fx-font-size: 13;");
        ide.console.setEditable(true);
        ide.inputStart = 0;
        ide.console.positionCaret(0);

        ConsoleInputGuard guard = new ConsoleInputGuard(ide, ide.console);
        installContextMenu(ide.console, guard);
        return guard;
    }

    /**
     * Read-only right-click menu: copy anything, paste only into the prompt.
     *
     * @param console the console
     * @param guard   its freeze guard
     */
    private static void installContextMenu(TextArea console, ConsoleInputGuard guard) {
        MenuItem copy = new MenuItem("Copy");
        copy.setAccelerator(new KeyCodeCombination(KeyCode.C, KeyCombination.SHORTCUT_DOWN));
        copy.setOnAction(e -> guard.copySelection());

        MenuItem copyAll = new MenuItem("Copy All");
        copyAll.setOnAction(e -> guard.copyAll());

        MenuItem paste = new MenuItem("Paste");
        paste.setAccelerator(new KeyCodeCombination(KeyCode.V, KeyCombination.SHORTCUT_DOWN));
        paste.setOnAction(e -> {
            // Whatever is selected, a paste belongs to the prompt line.
            console.positionCaret(console.getLength());
            console.paste();
        });

        MenuItem selectAll = new MenuItem("Select All");
        selectAll.setOnAction(e -> console.selectRange(0, console.getLength()));

        ContextMenu menu = new ContextMenu(copy, copyAll, new SeparatorMenuItem(), paste, selectAll);
        // Copy is only meaningful with a selection; refreshed each time it opens.
        menu.setOnShowing(e -> copy.setDisable(console.getSelection().getLength() == 0));
        console.setContextMenu(menu);
    }
}
