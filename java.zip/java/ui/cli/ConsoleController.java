package ui.cli;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.CustomMenuItem;
import javafx.scene.control.Label;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import ui.UI_Main;

/**
 * Creates and configures the Command Window text area.
 *
 * <p>All prompt-boundary and keystroke policy now lives in
 * {@link ConsoleInputGuard}; this class only builds the control and hands it
 * over. Keeping the two apart means {@link CLI_Main} is about commands and the
 * guard is about keystrokes, and neither has to know the other's rules.
 *
 * <h3>Right-click menu</h3>
 * The {@code TextArea}'s default menu offered Undo, Redo, Cut and Delete, all of
 * which either did nothing (the freeze rejected them) or could reach into the
 * history. It is replaced with a menu that only reads the transcript:
 *
 * <pre>
 *   Copy                    Ctrl+C    the selection, history included
 *   Copy All                          the whole transcript
 *   ---------------------------------
 *   Paste                   Ctrl+V    always into the prompt line
 *   Select All              Ctrl+A    the whole transcript, ready to copy
 * </pre>
 *
 * <p>The shortcut texts are labels only; the keys themselves are handled by
 * the TextArea and {@link ConsoleInputGuard}.
 *
 * <h3>Look</h3>
 * Styled to match the editor's right-click menu: rounded corners, Segoe UI at
 * the menu size (not the console's monospace, which it would otherwise
 * inherit), shortcuts right-aligned in grey and a rounded hover highlight.
 * Each entry is a {@link CustomMenuItem} holding a name / gap / shortcut row,
 * because the built-in accelerator column sits just after the longest label
 * rather than at the right edge. Shape, size and font are set here; colours
 * stay in the theme CSS under {@value #MENU_CLASS}.
 */
public final class ConsoleController {

    /** Style class shared with the theme CSS, which supplies the colours. */
    private static final String MENU_CLASS = "console-context-menu";

    // Dimensions (candidates for a future CommandWindow_dim in section_dims).
    private static final int MENU_WIDTH = 234;       // 260 less 10 %
    private static final int MENU_RADIUS = 8;
    private static final int MENU_PADDING = 5;
    private static final int MENU_BORDER = 1;
    private static final int ITEM_RADIUS = 5;
    private static final int ITEM_PAD_V = 6;
    private static final int ITEM_PAD_H = 12;
    private static final int FONT_SIZE = 12;
    private static final String FONT_FAMILY = "\"Segoe UI\", \"Helvetica Neue\", Arial, sans-serif";

    /** Row width that makes the whole menu exactly {@link #MENU_WIDTH} wide. */
    private static final int ROW_WIDTH =
            MENU_WIDTH - 2 * MENU_PADDING - 2 * ITEM_PAD_H - 2 * MENU_BORDER;

    private static final String MENU_SHEET = buildMenuSheet();

    private ConsoleController() {
    }

    /**
     * Initializes {@code ide.console} and installs the freeze.
     *
     * @param ide the IDE controller
     * @return the guard owning the console's editable region
     */
    public static ConsoleInputGuard initialize(UI_Main ide) {
        ide.console = new TextArea();
        ide.console.getStyleClass().add("console-area");
        ide.console.setWrapText(true);
        ide.console.setPrefHeight(140);
        ide.console.setStyle("-fx-font-family: Consolas; -fx-font-size: 13;");
        ide.console.setEditable(true);
        ide.inputStart = 0;
        ide.console.positionCaret(0);

        ConsoleInputGuard guard = new ConsoleInputGuard(ide, ide.console);
        installContextMenu(ide.console, guard);
        return guard;
    }

    /**
     * Read-only right-click menu: copy anything, paste only into the prompt.
     *
     * @param console the console
     * @param guard   its freeze guard
     */
    private static void installContextMenu(TextArea console, ConsoleInputGuard guard) {
        CustomMenuItem copy = entry("Copy", KeyCode.C);
        copy.setOnAction(e -> guard.copySelection());

        CustomMenuItem copyAll = entry("Copy All", null);
        copyAll.setOnAction(e -> guard.copyAll());

        CustomMenuItem paste = entry("Paste", KeyCode.V);
        paste.setOnAction(e -> {
            // Whatever is selected, a paste belongs to the prompt line.
            console.positionCaret(console.getLength());
            console.paste();
        });

        CustomMenuItem selectAll = entry("Select All", KeyCode.A);
        selectAll.setOnAction(e -> console.selectRange(0, console.getLength()));

        ContextMenu menu = new ContextMenu(copy, copyAll, new SeparatorMenuItem(), paste, selectAll);
        styleMenu(menu);

        // Copy is only meaningful with a selection; refreshed each time it opens.
        menu.setOnShowing(e -> copy.setDisable(console.getSelection().getLength() == 0));
        console.setContextMenu(menu);
    }

    /**
     * Builds one menu entry: name on the left, shortcut pinned to the right.
     *
     * @param text the entry's name
     * @param key  the Ctrl/Cmd key shown on the right, or null for none
     * @return the entry
     */
    private static CustomMenuItem entry(String text, KeyCode key) {
        Label name = new Label(text);
        Region gap = new Region();
        HBox.setHgrow(gap, Priority.ALWAYS);

        HBox row = new HBox(name, gap);
        row.setAlignment(Pos.CENTER_LEFT);
        row.setMinWidth(ROW_WIDTH);
        row.setPrefWidth(ROW_WIDTH);

        if (key != null) {
            // "Ctrl+C" on Windows/Linux, the Cmd glyph on macOS.
            String keys = new KeyCodeCombination(key, KeyCombination.SHORTCUT_DOWN).getDisplayText();
            Label shortcut = new Label(keys);
            shortcut.getStyleClass().add("accelerator-text");
            row.getChildren().add(shortcut);
        }

        CustomMenuItem item = new CustomMenuItem(row, true);
        // Greys both labels when the entry is disabled (e.g. Copy with no selection).
        row.disableProperty().bind(item.disableProperty());
        return item;
    }

    // =====================================================================
    // Styling
    // =====================================================================

    /**
     * Tags the menu for the theme colours and attaches the shape/size/font
     * sheet to its root once the skin exists. The skin copies the style class
     * when it is created, so the class must be added before the first show.
     */
    private static void styleMenu(ContextMenu menu) {
        menu.getStyleClass().add(MENU_CLASS);
        menu.skinProperty().addListener((obs, oldSkin, newSkin) -> {
            if (newSkin != null && newSkin.getNode() instanceof Parent root
                    && !root.getStylesheets().contains(MENU_SHEET)) {
                root.getStylesheets().add(MENU_SHEET);
            }
        });
    }

    private static String buildMenuSheet() {
        String css = ""
                + "." + MENU_CLASS + " {"
                + " -fx-min-width: " + MENU_WIDTH + "px;"
                + " -fx-padding: " + MENU_PADDING + "px;"
                + " -fx-background-insets: 0;"
                + " -fx-background-radius: " + MENU_RADIUS + "px;"
                + " -fx-border-width: " + MENU_BORDER + "px;"
                + " -fx-border-radius: " + MENU_RADIUS + "px;"
                + " -fx-font-family: " + FONT_FAMILY + ";"
                + " -fx-font-size: " + FONT_SIZE + "px;"
                + " }\n"
                + "." + MENU_CLASS + " .menu-item {"
                + " -fx-padding: " + ITEM_PAD_V + "px " + ITEM_PAD_H + "px;"
                + " -fx-background-insets: 0;"
                + " -fx-background-radius: " + ITEM_RADIUS + "px;"
                + " }\n"
                + "." + MENU_CLASS + " .label {"
                + " -fx-font-family: " + FONT_FAMILY + ";"
                + " -fx-font-size: " + FONT_SIZE + "px;"
                + " }\n"
                + "." + MENU_CLASS + " .separator {"
                + " -fx-padding: 3px 4px;"
                + " }\n";
        return "data:text/css;base64,"
                + Base64.getEncoder().encodeToString(css.getBytes(StandardCharsets.UTF_8));
    }
}