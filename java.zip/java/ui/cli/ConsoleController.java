package ui.cli;

import javafx.scene.control.TextArea;
import ui.UI_Main;

/**
 * Creates and configures the Command Window text area.
 *
 * <p>All prompt-boundary and keystroke policy now lives in
 * {@link ConsoleInputGuard}; this class only builds the control and hands it
 * over. Keeping the two apart means {@link CLI_Main} is about commands and the
 * guard is about keystrokes, and neither has to know the other's rules.
 */
public final class ConsoleController {

    private ConsoleController() {
    }

    /**
     * Initializes {@code ide.console} and installs the freeze.
     *
     * @param ide the IDE controller
     * @return the guard owning the console's editable region
     */
    public static ConsoleInputGuard initialize(UI_Main ide) {
        ide.console = new TextArea();
        ide.console.getStyleClass().add("console-area");
        ide.console.setWrapText(true);
        ide.console.setPrefHeight(140);
        ide.console.setStyle("-fx-font-family: Consolas; -fx-font-size: 13;");
        ide.console.setEditable(true);
        ide.inputStart = 0;
        ide.console.positionCaret(0);

        return new ConsoleInputGuard(ide, ide.console);
    }
}
