package ui.cli;

import javafx.scene.control.TextArea;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import ui.UI_Main;

/**
 * Creates and configures the Command Window text area.
 *
 * <p>Moved from {@code ui.explorer.console} into the dedicated {@code ui.cli}
 * package as part of consolidating the Command Window. It is intentionally thin:
 * it builds the {@link TextArea}, enforces the prompt boundary (the caret and
 * all edits can never move into already-committed output), and routes ENTER to
 * {@link CLI_Main#handleEnter(UI_Main)}.
 *
 * <h3>Why there is a KEY_TYPED filter</h3>
 * A JavaFX {@code TextArea} inserts the newline for ENTER on the
 * <b>KEY_TYPED</b> event, not KEY_PRESSED. If we only consume KEY_PRESSED, the
 * control still inserts its own {@code "\n"} — and because {@link CLI_Main}
 * appends a {@code "\n"} too, the result is a doubled newline (one blank line
 * per ENTER). The KEY_TYPED filter below swallows the ENTER character (and any
 * character typed inside committed output), so Java has full, exclusive control
 * over newlines. This is the fix for the "extra blank line on Enter" bug.
 */
public final class ConsoleController {

    private ConsoleController() {
    }

    /**
     * Initializes {@code ide.console} and installs prompt/ENTER handling.
     *
     * @param ide the IDE controller
     */
    public static void initialize(UI_Main ide) {
        ide.console = new TextArea();
        ide.console.getStyleClass().add("console-area");
        ide.console.setWrapText(true);
        ide.console.setPrefHeight(140);
        ide.console.setStyle("-fx-font-family: Consolas; -fx-font-size: 13;");
        ide.console.setEditable(true);
        ide.inputStart = ide.console.getLength();
        ide.console.positionCaret(ide.console.getLength());

        // --- KEY_TYPED filter: Java owns every newline; protect committed text ---
        ide.console.addEventFilter(KeyEvent.KEY_TYPED, event -> {
            String ch = event.getCharacter();
            // Swallow the ENTER character so the TextArea never inserts its own
            // newline (we add exactly one in CLI_Main.handleEnter).
            if (ch != null && (ch.equals("\r") || ch.equals("\n"))) {
                event.consume();
                return;
            }
            // Block typing into already-committed output (before the prompt).
            if (ide.console.getCaretPosition() < ide.inputStart) {
                event.consume();
            }
        });

        // --- KEY_PRESSED: caret guard, backspace guard, ENTER submit ---
        ide.console.setOnKeyPressed(event -> {
            // Keep the caret out of committed output.
            if (ide.console.getCaretPosition() < ide.inputStart) {
                ide.console.positionCaret(ide.console.getLength());
            }

            // If the suggestion popup is open, the bridge's KEY_PRESSED filter has
            // already consumed navigation/commit keys; do nothing here.
            if (CLI_Main.isSuggestionShowing()) {
                return;
            }

            KeyCode code = event.getCode();

            // Never let BACKSPACE erase the prompt or committed output: if the
            // caret sits at (or before) the input boundary, block it.
            if (code == KeyCode.BACK_SPACE && ide.console.getCaretPosition() <= ide.inputStart) {
                event.consume();
                return;
            }

            if (code == KeyCode.ENTER) {
                event.consume();
                CLI_Main.handleEnter(ide);
            }
        });
    }
}
