package ui.cli;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import ui.UI_Main;
import ui.design.AstraFrame;
import ui.design.Dim;
import ui.design.section_dims.CommandWindow_dim;

/**
 * The window behind the Command Window's three-dot <b>CLI History</b>: every
 * saved command, grouped by the session it was typed in, newest session first.
 *
 * <pre>
 *   [ Filter commands...                         ]
 *   v Mon 19 Oct 2026, 18:04:12  (this window)  3
 *        for i = [1:2:100]: ...
 *        x = 5;
 *        sct_01
 *   &gt; Mon 19 Oct 2026, 09:12:40                  27
 *   ------------------------------------------------
 *   Paste to Prompt   Run   Copy             Close
 * </pre>
 *
 * <ul>
 * <li><b>Double-click</b> (or Enter) on a command puts it at the prompt,
 * ready to edit; nothing runs until Enter is pressed in the Command
 * Window.</li>
 * <li><b>Run</b> puts it at the prompt and submits it, exactly as if it had
 * been typed. A whole block is run as one command.</li>
 * <li><b>Copy</b> copies the selected command, or every command of a selected
 * session.</li>
 * </ul>
 * The list follows the history live: a command submitted while the window is
 * open appears at once, and Reset CLI History empties it.
 *
 * <h3>Look</h3>
 * <p>
 * An {@link AstraFrame} tool window: square corners, a hairline outline, a
 * title strip in the panels' active title colour (the Custom layout's base
 * colour when one is in force), a white body (the editor's background in the
 * dark theme) and square buttons with a thin outline that shows in both
 * themes. It can be dragged by the strip, resized from any edge, and closed
 * with Esc. Nothing here sets a colour or a size: the strip and its buttons
 * come from {@code Frame_dim} (the panels' title-strip template), the first
 * size from {@code CommandWindow_dim}.
 * </p>
 *
 * <h3>Independent of the IDE window</h3>
 * <p>
 * Like the standalone Command Window, it is not owned by the IDE: it has its
 * own task-bar entry, its own minimise, maximise and close buttons, and can
 * sit behind the IDE or on another monitor. It still opens centred over the
 * IDE, follows its theme, and closes when the IDE closes.
 * </p>
 */
final class CliHistoryWindow {

    private static final DateTimeFormatter LABEL =
            DateTimeFormatter.ofPattern("EEE d MMM yyyy, HH:mm:ss", Locale.ENGLISH);

    /** The one open window, so a second click brings it forward instead of opening another. */
    private static CliHistoryWindow open;

    private final UI_Main ide;
    private final AstraFrame frame;
    private final Stage stage;
    private final TreeView<Entry> tree = new TreeView<>();
    private final TextField filter = new TextField();
    private final Runnable onChange = this::refresh;
    private final EventHandler<WindowEvent> closeWithIde = e -> stageClose();

    /** A tree row: a session heading or one command. */
    private record Entry(String text, LocalDateTime started, int count, boolean current) {
        boolean isSession() {
            return started != null;
        }
    }

    private CliHistoryWindow(UI_Main ide) {
        this.ide = ide;
        // Independent: own task-bar entry and minimise button; still centred
        // over the IDE and given its sheets and icon.
        AstraFrame.Options options = new AstraFrame.Options()
                .owned(false)
                .minimizeButton(true);
        this.frame = new AstraFrame(ide == null ? null : ide.stage, "CLI History", AstraFrame.Kind.WINDOW,
                options);
        this.stage = frame.stage();
        build();
    }

    /**
     * Opens the window, or brings the open one to the front.
     *
     * @param ide the IDE controller
     */
    static void show(UI_Main ide) {
        if (open != null) {
            open.refresh();
            if (open.stage.isIconified()) {
                open.stage.setIconified(false);
            }
            open.stage.toFront();
            open.stage.requestFocus();
            return;
        }
        open = new CliHistoryWindow(ide);
        open.refresh();
        open.stage.show();
    }

    /** Re-reads the history if the window is open (after a reset, say). */
    static void refreshIfOpen() {
        if (open != null) {
            open.refresh();
        }
    }

    // =====================================================================
    // Layout
    // =====================================================================

    private void build() {
        filter.setPromptText("Filter commands");
        filter.textProperty().addListener((obs, was, is) -> refresh());

        tree.setShowRoot(false);
        tree.setCellFactory(view -> new EntryCell());
        tree.setOnMouseClicked(e -> {
            if (e.getButton() == MouseButton.PRIMARY && e.getClickCount() == 2) {
                pasteSelected();
            }
        });
        tree.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.ENTER) {
                pasteSelected();
                e.consume();
            }
        });

        Button paste = AstraFrame.button("Paste to Prompt");
        paste.setOnAction(e -> pasteSelected());
        Button run = AstraFrame.button("Run");
        run.setOnAction(e -> runSelected());
        Button copy = AstraFrame.button("Copy");
        copy.setOnAction(e -> copySelected());
        Button close = AstraFrame.button("Close");
        close.setCancelButton(true);
        close.setOnAction(e -> stage.close());

        // Command actions need a command; Copy also takes a session.
        paste.disableProperty().bind(tree.getSelectionModel().selectedItemProperty().isNull());
        run.disableProperty().bind(tree.getSelectionModel().selectedItemProperty().isNull()
                .or(CLI_Main.busyProperty()));
        copy.disableProperty().bind(tree.getSelectionModel().selectedItemProperty().isNull());

        Region gap = new Region();
        HBox.setHgrow(gap, Priority.ALWAYS);
        HBox footer = new HBox(paste, run, copy, gap, close);
        footer.getStyleClass().addAll(AstraFrame.BUTTONS_CLASS, "cli-history-footer");
        footer.setAlignment(Pos.CENTER_LEFT);

        // The frame's body already pads the content; only the gap between the
        // filter and the list is set here.
        BorderPane content = new BorderPane(tree);
        BorderPane.setMargin(filter, new Insets(0, 0, Dim.Frame.BODY_SPACING, 0));
        content.setTop(filter);
        content.setBottom(footer);
        content.getStyleClass().add("cli-history");

        frame.setContent(content).setSize(CommandWindow_dim.HISTORY_WIDTH, CommandWindow_dim.HISTORY_HEIGHT);
        stage.addEventHandler(WindowEvent.WINDOW_HIDDEN, e -> {
            CliHistory.removeListener(onChange);
            open = null;
        });
        CliHistory.addListener(onChange);
        // Not owned, so it would outlive the IDE window: close with it.
        if (ide != null && ide.stage != null) {
            ide.stage.addEventHandler(WindowEvent.WINDOW_HIDDEN, closeWithIde);
            stage.addEventHandler(WindowEvent.WINDOW_HIDDEN,
                    e -> ide.stage.removeEventHandler(WindowEvent.WINDOW_HIDDEN, closeWithIde));
        }
    }

    private void stageClose() {
        stage.close();
    }

    // =====================================================================
    // Content
    // =====================================================================

    private void refresh() {
        String query = filter.getText() == null ? "" : filter.getText().strip().toLowerCase(Locale.ROOT);
        LocalDateTime current = CliHistory.currentSessionStart();
        List<CliHistory.Session> sessions = CliHistory.sessions();

        TreeItem<Entry> root = new TreeItem<>();
        boolean first = true;
        for (int s = sessions.size() - 1; s >= 0; s--) { // newest session first
            CliHistory.Session session = sessions.get(s);
            TreeItem<Entry> heading = new TreeItem<>();
            int shown = 0;
            for (int c = session.commands().size() - 1; c >= 0; c--) { // newest command first
                String command = session.commands().get(c);
                if (!query.isEmpty() && !command.toLowerCase(Locale.ROOT).contains(query)) {
                    continue;
                }
                heading.getChildren().add(new TreeItem<>(new Entry(command, null, 0, false)));
                shown++;
            }
            if (shown == 0) {
                continue;
            }
            boolean isCurrent = current.equals(session.started());
            heading.setValue(new Entry(sessionLabel(session.started()), session.started(), shown, isCurrent));
            // The newest session is open; with a filter, every match is shown.
            heading.setExpanded(first || !query.isEmpty());
            first = false;
            root.getChildren().add(heading);
        }
        tree.setRoot(root);
    }

    private static String sessionLabel(LocalDateTime started) {
        return started == null || LocalDateTime.MIN.equals(started) ? "Earlier" : LABEL.format(started);
    }

    // =====================================================================
    // Actions
    // =====================================================================

    private Entry selected() {
        TreeItem<Entry> item = tree.getSelectionModel().getSelectedItem();
        return item == null ? null : item.getValue();
    }

    private void pasteSelected() {
        Entry entry = selected();
        if (entry != null && !entry.isSession()) {
            CLI_Main.pasteToPrompt(ide, entry.text());
        }
    }

    private void runSelected() {
        Entry entry = selected();
        if (entry != null && !entry.isSession()) {
            CLI_Main.runFromHistory(ide, entry.text());
        }
    }

    private void copySelected() {
        TreeItem<Entry> item = tree.getSelectionModel().getSelectedItem();
        if (item == null || item.getValue() == null) {
            return;
        }
        StringBuilder text = new StringBuilder();
        if (item.getValue().isSession()) {
            // Oldest first, the order they were typed in.
            for (int i = item.getChildren().size() - 1; i >= 0; i--) {
                text.append(item.getChildren().get(i).getValue().text()).append('\n');
            }
        } else {
            text.append(item.getValue().text());
        }
        ClipboardContent content = new ClipboardContent();
        content.putString(text.toString());
        Clipboard.getSystemClipboard().setContent(content);
    }

    // =====================================================================
    // Cells
    // =====================================================================

    /** A session heading in bold with its count on the right; a command on one line. */
    private static final class EntryCell extends TreeCell<Entry> {
        @Override
        protected void updateItem(Entry entry, boolean empty) {
            super.updateItem(entry, empty);
            setTooltip(null);
            if (empty || entry == null) {
                setText(null);
                setGraphic(null);
                setStyle("");
                return;
            }
            if (entry.isSession()) {
                Label name = new Label(entry.text() + (entry.current() ? "   (this window)" : ""));
                name.setStyle("-fx-font-weight: bold;");
                Region gap = new Region();
                HBox.setHgrow(gap, Priority.ALWAYS);
                Label count = new Label(String.valueOf(entry.count()));
                count.setStyle("-fx-opacity: 0.65;");
                HBox row = new HBox(name, gap, count);
                row.setAlignment(Pos.CENTER_LEFT);
                row.setMaxWidth(Double.MAX_VALUE);
                setText(null);
                setGraphic(row);
                return;
            }
            String text = entry.text();
            int newline = text.indexOf('\n');
            setGraphic(null);
            setText(newline < 0 ? text : text.substring(0, newline) + "  …");
            setStyle("-fx-font-family: Consolas, monospace;");
            if (newline >= 0) {
                setTooltip(new Tooltip(text));
            }
        }
    }
}
