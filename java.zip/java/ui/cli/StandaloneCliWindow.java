package ui.cli;

import java.util.List;

import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.collections.ListChangeListener;
import javafx.event.Event;
import javafx.geometry.Bounds;
import javafx.geometry.Rectangle2D;
import javafx.geometry.Side;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Tooltip;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.stage.WindowEvent;
import ui.UI_Main;
import ui.design.AstraFrame;
import ui.design.Dim;
import ui.design.section_dims.CommandWindow_dim;
import ui.explorer.PanelActivation;
import ui.explorer.TitleBarIcon;
import ui.layout.LayoutManager;
import ui.layout.custom.CustomLayoutTheme;

/**
 * Standalone CLI: the Command Window panel in a window of its own.
 *
 * <pre>
 *   +-- NC  Command Window -------------------------- [_] [ ] [x] --+   strip: title + caption buttons
 *   |                                                       [=|=]  |   tool bar (0.5 cm), Options
 *   | &gt;&gt; x = 5;                                                      |
 *   | x =                                                          |
 *   |      5                                                       |
 *   | &gt;&gt; _                                                           |
 *   +--------------------------------------------------------------+
 * </pre>
 *
 * <h3>What moves</h3>
 * <p>
 * The panel itself -- the same node the layouts place -- so the console, its
 * text, the prompt, the history, a running command and {@code nc.exe} are
 * all untouched by the move. {@code LayoutManager} decides when the panel is
 * here ({@link #show}) and when it goes home ({@link #release}); this class
 * only owns the window.
 * </p>
 *
 * <h3>The window</h3>
 * <ul>
 * <li><b>Strip.</b> An {@link AstraFrame} tool window: the navy strip carries
 * only the title and the minimise / maximise / close buttons, sized from the
 * panels' title-strip template ({@code Frame_dim}). The panel's own strip
 * is hidden while it is here.</li>
 * <li><b>Tool bar.</b> A 0.5 cm bar under the strip, in the menus' colour
 * ({@code surfaces.css}, section 9), with the <b>Options</b> button at its
 * right end: a thin outline, a slightly darker fill under the pointer and
 * while its menu is open, and a light / dark icon pair
 * ({@link TitleBarIcon#OPTIONS}). It opens the Command Window's menu --
 * the same entries as the docked panel's three dots, including "Exit
 * Standalone CLI" with its green dot -- right-aligned under the button.
 * The docked Command Window keeps its three-dot button; Options exists only
 * here.</li>
 * <li><b>Independent</b>, not owned by the IDE: its own task-bar entry, can
 * go behind the IDE or onto another monitor. It still takes the IDE's icon
 * and sheets, follows the theme, the Text Colours and the Custom layout's
 * colours (its holder is registered with {@link CustomLayoutTheme#addHost}),
 * and it closes with the IDE.</li>
 * <li><b>Place.</b> It opens centred over the IDE every time. Its first size
 * is {@link CommandWindow_dim#STANDALONE_WIDTH_SHARE} by
 * {@link CommandWindow_dim#STANDALONE_HEIGHT_SHARE} of the screen; a size the
 * user gives it is remembered and used the next time instead.</li>
 * <li><b>Close</b> (the close mark, Alt+F4) docks the Command Window back
 * into the layout -- it never closes the Command Window. Esc is left to the
 * console.</li>
 * <li><b>Shortcuts.</b> The IDE's scene accelerators are copied onto this
 * window, and function keys / Ctrl or Alt chords the console does not use
 * are passed on to the IDE window, so Run, Stop and the like still work
 * while typing here. Editing chords (Ctrl+Z / Y / X / C / V / A) are never
 * passed on: they belong to the console.</li>
 * </ul>
 *
 * <p>
 * A fresh frame is built each time the window appears and dropped when it
 * goes, because an {@link AstraFrame} lets go of its theme listeners when it
 * is hidden. The tool bar is built once and moves into each new frame, so
 * its theme-following icon is registered only once.
 * </p>
 */
public final class StandaloneCliWindow {

    private static final String TITLE = "Command Window";

    /** The size the user last gave the window (position is not kept: it opens centred). */
    private static final String KEY_W = "cli.standalone.width";
    private static final String KEY_H = "cli.standalone.height";

    /** Style class of the bar under the strip; geometry generated, colours in surfaces.css. */
    private static final String TOOLBAR_CLASS = "cli-toolbar";

    /** Style class of a button on that bar. */
    private static final String TOOLBAR_BUTTON_CLASS = "cli-toolbar-button";

    /** Added to the Options button while its menu is open. */
    private static final String MENU_SHOWING_CLASS = "menu-showing";

    /** Editing chords that belong to the console and are never passed on. */
    private static final List<KeyCode> CONSOLE_CHORDS = List.of(
            KeyCode.Z, KeyCode.Y, KeyCode.X, KeyCode.C, KeyCode.V, KeyCode.A,
            KeyCode.LEFT, KeyCode.RIGHT, KeyCode.UP, KeyCode.DOWN,
            KeyCode.HOME, KeyCode.END, KeyCode.BACK_SPACE, KeyCode.DELETE,
            KeyCode.ENTER, KeyCode.TAB);

    private static UI_Main ide;
    private static Node content;
    private static AstraFrame frame;
    private static StackPane holder;
    private static ContextMenu menu;

    /** The tool bar and its Options button, built once. */
    private static HBox toolbar;
    private static Button optionsButton;

    /** True between show and release: the panel belongs here. */
    private static boolean wanted;

    /** Waiting for the IDE window to appear (Astra started standalone). */
    private static ChangeListener<Boolean> pendingShow;

    private static boolean mainHooked;

    private static final ListChangeListener<String> FOLLOW_SHEETS = change -> {
        if (frame != null) {
            frame.refreshSheets();
        }
    };

    private StandaloneCliWindow() {
    }

    // =====================================================================
    // Called by LayoutManager
    // =====================================================================

    /**
     * Puts the panel in the window and shows it. Safe to call on every layout
     * build: an open window is left where it is.
     *
     * @param ideRef    the IDE controller
     * @param panel     the Command Window panel
     * @param takeFocus true when the user asked for it (menu): the window comes
     *                  forward with the keyboard in the console. False for a
     *                  rebuild or a launch: the keyboard stays in the IDE.
     */
    public static void show(UI_Main ideRef, Node panel, boolean takeFocus) {
        ide = ideRef;
        content = panel;
        wanted = true;
        if (ide == null || ide.stage == null || panel == null) {
            return;
        }
        hookMainWindow();
        if (!ide.stage.isShowing() || ide.scene == null) {
            // Astra started with the CLI standalone: the IDE window is not up
            // yet (no scene, no screen). Show once it is.
            deferUntilMainShows();
            return;
        }
        if (frame != null) {
            if (!holder.getChildren().contains(panel)) {
                holder.getChildren().setAll(panel);
            }
            if (takeFocus) {
                bringForward(true);
            }
            return;
        }
        build();
        place();
        frame.show();
        if (takeFocus) {
            focusConsole();
        } else {
            Platform.runLater(() -> {
                if (ide.stage.isShowing()) {
                    ide.stage.requestFocus();
                }
            });
        }
    }

    /**
     * Gives the panel back (the layout is about to place it) and closes the
     * window. Does nothing if it is not open.
     */
    public static void release() {
        wanted = false;
        if (frame == null) {
            return;
        }
        if (menu != null) {
            menu.hide();
        }
        holder.getChildren().clear();
        frame.stage().hide();
    }

    /** @return true while the window is on screen */
    public static boolean isShowing() {
        return frame != null && frame.stage().isShowing();
    }

    /** @return the window while it is on screen, for dialogs; otherwise null */
    public static Window window() {
        return isShowing() ? frame.stage() : null;
    }

    /**
     * Brings a minimised window back without taking the keyboard: a run has
     * just reported an error.
     */
    public static void revealIfMinimised() {
        if (isShowing() && frame.stage().isIconified()) {
            frame.stage().setIconified(false);
        }
    }

    /**
     * Brings the window to the front, restoring it if minimised.
     *
     * @param focus true to put the keyboard in the console
     */
    public static void bringForward(boolean focus) {
        if (!isShowing()) {
            return;
        }
        Stage stage = frame.stage();
        if (stage.isIconified()) {
            stage.setIconified(false);
        }
        stage.toFront();
        if (focus) {
            focusConsole();
        }
    }

    // =====================================================================
    // Building
    // =====================================================================

    private static void build() {
        AstraFrame.Options options = new AstraFrame.Options()
                .owned(false)
                .closeOnEscape(false)
                .centreOnShow(false)
                .minimizeButton(true);
        frame = new AstraFrame(ide.stage, TITLE, AstraFrame.Kind.WINDOW, options);
        frame.setBodyFlush();

        holder = new StackPane(content);
        holder.getStyleClass().add("standalone-cli");

        VBox body = new VBox(toolbar(), holder);
        body.setFillWidth(true);
        VBox.setVgrow(holder, Priority.ALWAYS);
        frame.setContent(body);

        // Close = dock back. Run after the event, since the panel changes window.
        frame.setOnCloseRequest(() -> Platform.runLater(() -> LayoutManager.setCliStandalone(false)));

        Stage stage = frame.stage();
        stage.setMinWidth(CommandWindow_dim.STANDALONE_MIN_WIDTH);
        stage.setMinHeight(CommandWindow_dim.STANDALONE_MIN_HEIGHT);

        // Custom layout colours for the CLI body, as in the layout.
        CustomLayoutTheme.addHost(holder);
        // Text Colours and other sheet changes that are not a theme switch.
        ide.scene.getStylesheets().addListener(FOLLOW_SHEETS);

        Scene scene = frame.scene();
        scene.getAccelerators().putAll(ide.scene.getAccelerators());
        scene.addEventHandler(KeyEvent.KEY_PRESSED, StandaloneCliWindow::passOn);

        stage.addEventHandler(WindowEvent.WINDOW_HIDDEN, e -> onHidden());
    }

    /**
     * The 0.5 cm bar with Options at its right end. Built once; each new
     * frame takes it over from the last.
     */
    private static HBox toolbar() {
        if (toolbar != null) {
            return toolbar;
        }
        // Never made active: it sits on the menu-coloured bar, so the theme
        // alone picks the dark or the light rendering.
        TitleBarIcon icon = new TitleBarIcon(TitleBarIcon.OPTIONS, CommandWindow_dim.OPTIONS_ICON_SIZE);
        optionsButton = new Button("", icon.getView());
        optionsButton.getStyleClass().add(TOOLBAR_BUTTON_CLASS);
        optionsButton.setFocusTraversable(false);
        optionsButton.setTooltip(new Tooltip("Options"));
        optionsButton.setOnAction(e -> toggleMenu());

        Region grow = new Region();
        HBox.setHgrow(grow, Priority.ALWAYS);
        toolbar = new HBox(grow, optionsButton);
        toolbar.getStyleClass().add(TOOLBAR_CLASS);
        return toolbar;
    }

    /** Opens the Command Window menu right-aligned under Options, or closes it. */
    private static void toggleMenu() {
        if (menu != null && menu.isShowing()) {
            menu.hide();
            return;
        }
        menu = EditorCommandWindow.optionsMenu();
        ContextMenu shown = menu;
        optionsButton.getStyleClass().add(MENU_SHOWING_CLASS);
        shown.addEventHandler(WindowEvent.WINDOW_HIDDEN,
                e -> optionsButton.getStyleClass().remove(MENU_SHOWING_CLASS));
        Bounds b = optionsButton.localToScreen(optionsButton.getBoundsInLocal());
        if (b != null) {
            // The menu is at least the common menu width; its right edge
            // lines up with the button's.
            shown.show(optionsButton, b.getMaxX() - Dim.Menu.WIDTH, b.getMaxY());
        } else {
            shown.show(optionsButton, Side.BOTTOM, 0, 0);
        }
    }

    private static void onHidden() {
        saveSize();
        if (menu != null) {
            menu.hide();
            menu = null;
        }
        CustomLayoutTheme.removeHost(holder);
        if (ide != null && ide.scene != null) {
            ide.scene.getStylesheets().removeListener(FOLLOW_SHEETS);
        }
        frame = null;
        holder = null;
    }

    // =====================================================================
    // Place and size
    // =====================================================================

    /**
     * Centred over the IDE window, at the remembered size or the default
     * share of the screen, and kept inside the screen's working area.
     */
    private static void place() {
        Stage main = ide.stage;
        List<Screen> screens = Screen.getScreensForRectangle(
                main.getX(), main.getY(), Math.max(1, main.getWidth()), Math.max(1, main.getHeight()));
        Screen screen = screens.isEmpty() ? Screen.getPrimary() : screens.get(0);
        Rectangle2D area = screen.getVisualBounds();

        double w = savedSize(KEY_W, CommandWindow_dim.STANDALONE_MIN_WIDTH);
        double h = savedSize(KEY_H, CommandWindow_dim.STANDALONE_MIN_HEIGHT);
        if (w <= 0 || h <= 0) {
            w = Math.round(area.getWidth() * CommandWindow_dim.STANDALONE_WIDTH_SHARE);
            h = Math.round(area.getHeight() * CommandWindow_dim.STANDALONE_HEIGHT_SHARE);
        }
        w = clamp(w, CommandWindow_dim.STANDALONE_MIN_WIDTH, area.getWidth());
        h = clamp(h, CommandWindow_dim.STANDALONE_MIN_HEIGHT, area.getHeight());

        double cx = main.getX() + main.getWidth() / 2;
        double cy = main.getY() + main.getHeight() / 2;
        double x = clamp(Math.round(cx - w / 2), area.getMinX(), area.getMaxX() - w);
        double y = clamp(Math.round(cy - h / 2), area.getMinY(), area.getMaxY() - h);

        Stage stage = frame.stage();
        stage.setX(x);
        stage.setY(y);
        stage.setWidth(w);
        stage.setHeight(h);
    }

    private static double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }

    /** @return the stored size, or -1 when none is stored or it is too small */
    private static double savedSize(String key, double min) {
        if (ide == null || ide.prefs == null) {
            return -1;
        }
        double v = ide.prefs.getDouble(key, -1);
        return v >= min ? v : -1;
    }

    private static void saveSize() {
        if (frame == null || ide == null || ide.prefs == null) {
            return;
        }
        Rectangle2D b = frame.normalBounds();
        if (b.getWidth() <= 0 || b.getHeight() <= 0) {
            return;
        }
        ide.prefs.putDouble(KEY_W, b.getWidth());
        ide.prefs.putDouble(KEY_H, b.getHeight());
    }

    // =====================================================================
    // Focus, shortcuts, the IDE window
    // =====================================================================

    private static void focusConsole() {
        Platform.runLater(() -> {
            if (!isShowing()) {
                return;
            }
            frame.stage().requestFocus();
            PanelActivation.setActive(PanelActivation.Panel.COMMAND_WINDOW);
            if (ide.console != null) {
                ide.console.requestFocus();
                ide.console.requestFollowCaret();
            }
        });
    }

    /**
     * Passes a shortcut the console did not use to the IDE window, so its
     * key handlers (Run, Stop, ...) answer it. Fired at the IDE's root, never
     * at its focused node, so nothing is typed into the editor.
     */
    private static void passOn(KeyEvent e) {
        if (e.isConsumed() || ide == null || ide.scene == null || ide.scene.getRoot() == null) {
            return;
        }
        KeyCode code = e.getCode();
        boolean function = code.isFunctionKey();
        boolean chord = (e.isShortcutDown() || e.isAltDown()) && !CONSOLE_CHORDS.contains(code)
                && !code.isModifierKey();
        if (!function && !chord) {
            return;
        }
        Node root = ide.scene.getRoot();
        Event.fireEvent(root, e.copyFor(root, root));
    }

    /** Once: the window closes with the IDE (the Standalone choice is kept). */
    private static void hookMainWindow() {
        if (mainHooked || ide == null || ide.stage == null) {
            return;
        }
        mainHooked = true;
        ide.stage.addEventHandler(WindowEvent.WINDOW_HIDDEN, e -> {
            if (frame != null) {
                frame.stage().hide();
            }
        });
    }

    private static void deferUntilMainShows() {
        if (pendingShow != null) {
            return;
        }
        pendingShow = (obs, was, showing) -> {
            if (Boolean.TRUE.equals(showing)) {
                ide.stage.showingProperty().removeListener(pendingShow);
                pendingShow = null;
                // A pulse later: the IDE has just been sized and maximised.
                Platform.runLater(() -> {
                    if (wanted && content != null) {
                        show(ide, content, false);
                    }
                });
            }
        };
        ide.stage.showingProperty().addListener(pendingShow);
    }
}
