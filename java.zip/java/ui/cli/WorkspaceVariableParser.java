package ui.cli;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;

import ui.ui_functions.Variable;

/**
 * Reads and writes {@code variables.txt}, the shared workspace file the C++
 * interpreter owns.
 *
 * <h3>Two supported formats</h3>
 * <pre>
 *   legacy (current nc.exe):   NAME TYPE VALUE
 *   extended (after rebuild):  NAME TYPE SIZE VALUE
 * </pre>
 * Which one is in front of us is decided by the <b>header line</b>, not by
 * sniffing each record. Sniffing looks tempting -- a size field always matches
 * {@code RxC} -- but it misreads a legitimate string: {@code D STR 3x4} is a
 * variable holding the text {@code 3x4}, and the heuristic would swallow it as
 * a size and leave the value empty. The header costs nothing and cannot be
 * wrong.
 *
 * <p><b>This build works against your current nc.exe with no recompile</b>, and
 * automatically prefers the interpreter's own sizes once you rebuild.
 *
 * <p>Sizes inferred on the Java side are a fallback only. The interpreter is
 * the one that actually knows the shape of a matrix, which is why the extended
 * format is worth the rebuild.
 *
 * <p>The writer methods exist so the IDE can implement {@code clear} and
 * {@code clear <name>} without needing new interpreter builtins. They preserve
 * whatever header the file already had, so rewriting a file the interpreter
 * wrote in extended format never downgrades it into an unreadable mix.
 */
public final class WorkspaceVariableParser {

    /** Value column preview cap for large collections (keeps the table snappy). */
    private static final int MAX_INLINE_ELEMENTS = 12;

    private static final String LEGACY_HEADER = "NAME TYPE VALUE";
    private static final String RULE_LINE = "------------------------------";

    private WorkspaceVariableParser() {
    }

    /**
     * Parses {@code variables.txt} into Explorer rows.
     *
     * @param variablesTxt path to the shared workspace file (may be null/missing)
     * @return an ordered list of variables (empty if the file is absent/empty)
     */
    public static List<Variable> parse(Path variablesTxt) {
        boolean extended = false;
        boolean headerChecked = false;

        List<Variable> result = new ArrayList<>();
        for (String raw : readLines(variablesTxt)) {
            String line = raw == null ? "" : raw.strip();
            if (line.isEmpty() || isRule(line)) {
                continue;
            }
            if (!headerChecked && line.contains("NAME")) {
                extended = line.contains("SIZE");
                headerChecked = true;
                continue;
            }
            Variable variable = parseLine(line, extended);
            if (variable != null) {
                result.add(variable);
            }
        }
        return result;
    }

    /**
     * Rewrites the workspace file with an empty variable set, keeping whatever
     * header it already had. This is how {@code clear}
     * works without a new interpreter builtin.
     *
     * @param variablesTxt path to the shared workspace file
     * @return true when the file was rewritten
     */
    public static boolean writeEmpty(Path variablesTxt) {
        return writeLines(variablesTxt, headerOf(variablesTxt), List.of());
    }

    /**
     * Rewrites the workspace file with one variable removed. This is how
     * {@code clear <name>} works without a new interpreter builtin.
     *
     * @param variablesTxt path to the shared workspace file
     * @param cleanedName  the cleaned name to drop
     * @return true when a matching record was found and removed
     */
    public static boolean removeVariable(Path variablesTxt, String cleanedName) {
        if (cleanedName == null || cleanedName.isBlank()) {
            return false;
        }
        List<String> kept = new ArrayList<>();
        boolean removed = false;
        boolean headerSeen = false;

        for (String raw : readLines(variablesTxt)) {
            String line = raw == null ? "" : raw.strip();
            if (line.isEmpty() || isRule(line)) {
                continue;
            }
            if (!headerSeen && line.contains("NAME")) {
                headerSeen = true;
                continue;
            }
            int firstSpace = line.indexOf(' ');
            String name = firstSpace <= 0 ? line : line.substring(0, firstSpace);
            if (cleanedName.equals(name)) {
                removed = true;
                continue;
            }
            kept.add(line);
        }
        return writeLines(variablesTxt, headerOf(variablesTxt), kept) && removed;
    }

    // -----------------------------------------------------------------
    // Record parsing
    // -----------------------------------------------------------------

    /**
     * Parses a single {@code <name> <TYPE> [<SIZE>] <value...>} record.
     *
     * @param line     one stripped, non-header line of the workspace file
     * @param extended true when a SIZE column sits between TYPE and VALUE
     * @return the variable, or null for a malformed line
     */
    private static Variable parseLine(String line, boolean extended) {
        int firstSpace = line.indexOf(' ');
        if (firstSpace <= 0) {
            return null;
        }
        String name = line.substring(0, firstSpace);
        String rest = line.substring(firstSpace + 1).strip();

        int secondSpace = rest.indexOf(' ');
        String type;
        String remainder;
        if (secondSpace < 0) {
            type = rest;
            remainder = "";
        } else {
            type = rest.substring(0, secondSpace);
            remainder = rest.substring(secondSpace + 1).strip();
        }

        String declaredSize = null;
        if (extended && !remainder.isEmpty()) {
            int thirdSpace = remainder.indexOf(' ');
            declaredSize = thirdSpace < 0 ? remainder : remainder.substring(0, thirdSpace);
            remainder = thirdSpace < 0 ? "" : remainder.substring(thirdSpace + 1).strip();
        }

        return buildVariable(name, type, declaredSize, remainder);
    }

    private static Variable buildVariable(String name, String type, String declaredSize, String value) {
        switch (type) {
            case "NUM":
                return new Variable(name, value,
                        size(declaredSize, "1x1"), numericType(value));
            case "STR":
                return new Variable(name, value,
                        size(declaredSize, "1x" + value.length()), "string");
            case "ARR":
                return arrayVariable(name, declaredSize, value);
            case "MAT":
                return matrixVariable(name, declaredSize, value);
            case "DICT":
                return dictVariable(name, declaredSize, value);
            default:
                return new Variable(name, value,
                        size(declaredSize, "1x1"), type.toLowerCase());
        }
    }

    private static Variable arrayVariable(String name, String declaredSize, String value) {
        List<String> elements = splitTopLevel(stripOuter(value, '[', ']'), ',');
        int n = elements.size();
        String display = n > MAX_INLINE_ELEMENTS ? "[1x" + n + " array]" : value;
        return new Variable(name, display,
                size(declaredSize, "1x" + n), inferElementType(elements) + "[]");
    }

    private static Variable matrixVariable(String name, String declaredSize, String value) {
        List<String> rows = splitTopLevel(stripOuter(value, '[', ']'), ',');
        int rowCount = 0;
        int colCount = 0;
        for (String row : rows) {
            String r = row.strip();
            if (r.startsWith("[") && r.endsWith("]")) {
                rowCount++;
                // Ragged rows must not silently report the first row's width.
                colCount = Math.max(colCount, splitTopLevel(stripOuter(r, '[', ']'), ',').size());
            }
        }
        String inferred = (rowCount == 0 ? 1 : rowCount) + "x" + (colCount == 0 ? 1 : colCount);
        String finalSize = size(declaredSize, inferred);
        // A full RxC dump would make the cell enormous; the Size column already
        // carries the shape, so preview compactly.
        return new Variable(name, "[" + finalSize + " matrix]", finalSize, "matrix");
    }

    private static Variable dictVariable(String name, String declaredSize, String value) {
        List<String> entries = splitTopLevel(stripOuter(value, '{', '}'), ',');
        int n = entries.size();
        String display = n > MAX_INLINE_ELEMENTS ? "{" + n + " entries}" : value;
        return new Variable(name, display, size(declaredSize, "1x" + n), "dict");
    }

    private static String size(String declared, String inferred) {
        return declared == null || declared.isBlank() ? inferred : declared;
    }

    private static String numericType(String value) {
        return value != null && value.matches("[+-]?\\d+") ? "int" : "double";
    }

    // -----------------------------------------------------------------
    // File IO
    // -----------------------------------------------------------------

    private static List<String> readLines(Path variablesTxt) {
        if (variablesTxt == null || !Files.exists(variablesTxt)) {
            return List.of();
        }
        try {
            return Files.readAllLines(variablesTxt, StandardCharsets.UTF_8);
        } catch (IOException ex) {
            return List.of();
        }
    }

    /** @return the file's existing header line, or the legacy one if absent */
    private static String headerOf(Path variablesTxt) {
        for (String raw : readLines(variablesTxt)) {
            String line = raw == null ? "" : raw.strip();
            if (line.contains("NAME") && line.contains("TYPE")) {
                return line;
            }
        }
        return LEGACY_HEADER;
    }

    private static boolean writeLines(Path variablesTxt, String header, List<String> records) {
        if (variablesTxt == null) {
            return false;
        }
        StringBuilder out = new StringBuilder();
        out.append(header).append('\n').append(RULE_LINE).append('\n');
        for (String record : records) {
            out.append(record).append('\n');
        }
        try {
            Files.writeString(variablesTxt, out.toString(), StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            return true;
        } catch (IOException ex) {
            return false;
        }
    }

    private static boolean isRule(String line) {
        return line.startsWith("---");
    }

    // -----------------------------------------------------------------
    // Small, dependency-free helpers (bracket-aware splitting)
    // -----------------------------------------------------------------

    private static String stripOuter(String s, char open, char close) {
        if (s == null) {
            return "";
        }
        String t = s.strip();
        if (t.length() >= 2 && t.charAt(0) == open && t.charAt(t.length() - 1) == close) {
            return t.substring(1, t.length() - 1);
        }
        return t;
    }

    private static List<String> splitTopLevel(String content, char delimiter) {
        List<String> parts = new ArrayList<>();
        if (content == null || content.isBlank()) {
            return parts;
        }
        int depthBracket = 0;
        int depthBrace = 0;
        int depthParen = 0;
        boolean inQuote = false;
        int start = 0;
        for (int i = 0; i < content.length(); i++) {
            char c = content.charAt(i);
            if (c == '"') {
                inQuote = !inQuote;
            }
            if (inQuote) {
                continue;
            }
            switch (c) {
                case '[': depthBracket++; break;
                case ']': depthBracket = Math.max(0, depthBracket - 1); break;
                case '{': depthBrace++; break;
                case '}': depthBrace = Math.max(0, depthBrace - 1); break;
                case '(': depthParen++; break;
                case ')': depthParen = Math.max(0, depthParen - 1); break;
                default:
                    if (c == delimiter && depthBracket == 0 && depthBrace == 0 && depthParen == 0) {
                        parts.add(content.substring(start, i).strip());
                        start = i + 1;
                    }
            }
        }
        String tail = content.substring(start).strip();
        if (!tail.isEmpty()) {
            parts.add(tail);
        }
        return parts;
    }

    private static String inferElementType(List<String> elements) {
        if (elements.isEmpty()) {
            return "double";
        }
        boolean anyString = false;
        boolean anyFloat = false;
        for (String e : elements) {
            String t = e.strip();
            if (t.startsWith("\"") || t.startsWith("'")) {
                anyString = true;
            } else if (!t.matches("[+-]?\\d+")) {
                anyFloat = true;
            }
        }
        if (anyString) {
            return "string";
        }
        return anyFloat ? "double" : "int";
    }
}
