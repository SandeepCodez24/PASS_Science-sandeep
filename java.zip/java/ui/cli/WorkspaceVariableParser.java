package ui.cli;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import ui.ui_functions.Variable;

/**
 * Reads the C++ interpreter's shared workspace file ({@code variables.txt}) and
 * converts every top-level global into a {@link Variable} row
 * {@code [name, value, size, datatype]} for the Variable Explorer.
 *
 * <p><b>Why this class exists.</b> The C++ runtime ({@code variable_store.cpp})
 * is the single source of truth for the global workspace. After every
 * successful command it rewrites {@code variables.txt} in the compact form:
 *
 * <pre>
 *   NAME TYPE VALUE
 *   ------------------------------
 *   ans  NUM  25
 *   D    STR  india
 *   XX   MAT  [[1,0,...],[0,1,...], ...]
 *   v    ARR  [1,2,3]
 *   cfg  DICT {[k,N,1],[s,S,hi]}
 * </pre>
 *
 * This parser is the ONLY bridge between that file and the Explorer. It fully
 * replaces the old {@code .dict} pipeline (VariableFileWriter / the heuristic
 * console-parsing in IDEVariableService), which produced a different schema and
 * never matched the runtime state.
 *
 * <p>The parser is deliberately defensive: a hand-edited or partially written
 * {@code variables.txt} must never throw. Unknown / malformed lines are skipped.
 */
public final class WorkspaceVariableParser {

    /** Value column preview cap for large collections (keeps the table snappy). */
    private static final int MAX_INLINE_ELEMENTS = 12;

    private WorkspaceVariableParser() {
    }

    /**
     * Parse {@code variables.txt} into Explorer rows.
     *
     * @param variablesTxt path to the shared workspace file (may be null/missing)
     * @return an ordered list of variables (empty if the file is absent/empty)
     */
    public static List<Variable> parse(Path variablesTxt) {
        List<Variable> result = new ArrayList<>();
        if (variablesTxt == null || !Files.exists(variablesTxt)) {
            return result;
        }
        List<String> lines;
        try {
            lines = Files.readAllLines(variablesTxt);
        } catch (IOException ex) {
            return result;
        }
        for (String raw : lines) {
            Variable v = parseLine(raw);
            if (v != null) {
                result.add(v);
            }
        }
        return result;
    }

    /**
     * Parse a single {@code <name> <TYPE> <value...>} record.
     *
     * @return the variable, or {@code null} for headers / blank / malformed lines
     */
    private static Variable parseLine(String rawLine) {
        if (rawLine == null) {
            return null;
        }
        String line = rawLine.strip();
        if (line.isEmpty()) {
            return null;
        }
        // Skip the header line "NAME TYPE VALUE".
        if (line.startsWith("NAME") && line.contains("TYPE")) {
            return null;
        }
        // Tolerate a leading run of dashes (the "------" rule), which some
        // flushes merge onto the first record's line.
        int firstNonDash = 0;
        while (firstNonDash < line.length() && line.charAt(firstNonDash) == '-') {
            firstNonDash++;
        }
        if (firstNonDash > 0) {
            line = line.substring(firstNonDash).strip();
            if (line.isEmpty()) {
                return null;
            }
        }

        // Split into: name, TYPE, remainder(value).
        int firstSpace = line.indexOf(' ');
        if (firstSpace <= 0) {
            return null;
        }
        String name = line.substring(0, firstSpace);
        String rest = line.substring(firstSpace + 1).strip();
        int secondSpace = rest.indexOf(' ');
        String type;
        String value;
        if (secondSpace < 0) {
            type = rest;
            value = "";
        } else {
            type = rest.substring(0, secondSpace);
            value = rest.substring(secondSpace + 1).strip();
        }

        switch (type) {
            case "NUM":
                return numberVariable(name, value);
            case "STR":
                return new Variable(name, value, "1x" + value.length(), "string");
            case "ARR":
                return arrayVariable(name, value);
            case "MAT":
                return matrixVariable(name, value);
            case "DICT":
                return dictVariable(name, value);
            default:
                // Unknown type tag -> keep it visible but mark generically.
                return new Variable(name, value, "1x1", type.toLowerCase());
        }
    }

    private static Variable numberVariable(String name, String value) {
        String datatype = value.matches("[+-]?\\d+") ? "int" : "float";
        return new Variable(name, value, "1x1", datatype);
    }

    private static Variable arrayVariable(String name, String value) {
        List<String> elements = splitTopLevel(stripOuter(value, '[', ']'), ',');
        int n = elements.size();
        String size = "1x" + n;
        String datatype = inferElementType(elements) + "[]";
        String display = n > MAX_INLINE_ELEMENTS ? "[1x" + n + " array]" : value;
        return new Variable(name, display, size, datatype);
    }

    private static Variable matrixVariable(String name, String value) {
        // value looks like: [[a,b,c],[d,e,f], ...]
        String inner = stripOuter(value, '[', ']');
        List<String> rows = splitTopLevel(inner, ',');
        int rowCount = 0;
        int colCount = 0;
        for (String row : rows) {
            String r = row.strip();
            if (r.startsWith("[") && r.endsWith("]")) {
                rowCount++;
                if (colCount == 0) {
                    colCount = splitTopLevel(stripOuter(r, '[', ']'), ',').size();
                }
            }
        }
        String size = (rowCount == 0 ? 1 : rowCount) + "x" + (colCount == 0 ? 1 : colCount);
        // A full R*C dump would make the cell enormous (e.g. 50x50); the Size
        // column already conveys the shape, so preview compactly.
        String display = "[" + size + " matrix]";
        return new Variable(name, display, size, "matrix");
    }

    private static Variable dictVariable(String name, String value) {
        List<String> entries = splitTopLevel(stripOuter(value, '{', '}'), ',');
        int n = entries.size();
        String display = n > MAX_INLINE_ELEMENTS ? "{" + n + " entries}" : value;
        return new Variable(name, display, "1x" + n, "dict");
    }

    // ---------------------------------------------------------------------
    // Small, dependency-free helpers (bracket-aware splitting).
    // ---------------------------------------------------------------------

    private static String stripOuter(String s, char open, char close) {
        if (s == null) {
            return "";
        }
        String t = s.strip();
        if (t.length() >= 2 && t.charAt(0) == open && t.charAt(t.length() - 1) == close) {
            return t.substring(1, t.length() - 1);
        }
        return t;
    }

    private static List<String> splitTopLevel(String content, char delimiter) {
        List<String> parts = new ArrayList<>();
        if (content == null || content.isBlank()) {
            return parts;
        }
        int depthBracket = 0;
        int depthBrace = 0;
        int depthParen = 0;
        boolean inQuote = false;
        int start = 0;
        for (int i = 0; i < content.length(); i++) {
            char c = content.charAt(i);
            if (c == '"') {
                inQuote = !inQuote;
            }
            if (inQuote) {
                continue;
            }
            switch (c) {
                case '[': depthBracket++; break;
                case ']': depthBracket = Math.max(0, depthBracket - 1); break;
                case '{': depthBrace++; break;
                case '}': depthBrace = Math.max(0, depthBrace - 1); break;
                case '(': depthParen++; break;
                case ')': depthParen = Math.max(0, depthParen - 1); break;
                default:
                    if (c == delimiter && depthBracket == 0 && depthBrace == 0 && depthParen == 0) {
                        parts.add(content.substring(start, i).strip());
                        start = i + 1;
                    }
            }
        }
        String tail = content.substring(start).strip();
        if (!tail.isEmpty()) {
            parts.add(tail);
        }
        return parts;
    }

    private static String inferElementType(List<String> elements) {
        if (elements.isEmpty()) {
            return "double";
        }
        boolean anyString = false;
        boolean anyFloat = false;
        for (String e : elements) {
            String t = e.strip();
            if (t.startsWith("\"") || t.startsWith("'")) {
                anyString = true;
            } else if (t.matches("[+-]?\\d+")) {
                // integer
            } else {
                anyFloat = true;
            }
        }
        if (anyString) {
            return "string";
        }
        return anyFloat ? "float" : "int";
    }
}
