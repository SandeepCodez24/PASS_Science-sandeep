package ui.cli;

import java.util.Collection;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.IntSupplier;

import org.fxmisc.richtext.model.StyleSpan;
import org.fxmisc.richtext.model.StyleSpans;
import org.fxmisc.richtext.model.StyleSpansBuilder;

import language.semantic.ScriptedName;
import language.syntax.UPITokenMaker;
import ui.editor.ScriptStack;

/**
 * Colours the Command Window.
 *
 * <pre>
 *   &gt;&gt; x = sqrt(16) + 2;      prompt in .console-prompt, the command in the
 *                              editor's text colours (UPITokenMaker)
 *   x = 6                     interpreter output in .console-output
 * </pre>
 *
 * <h3>Colour at write time (new)</h3>
 * <p>
 * The CLI knows what it writes: a prompt, an echoed command, or output. So
 * every system write now carries its final style when it is written
 * ({@code ConsoleInputGuard}), and this class no longer guesses from the
 * text whether a line is code or output. The guess -- "a line starting with
 * {@code >>} is a command" -- coloured any output that happened to start with
 * {@code >>} as code, and re-coloured every appended paragraph a second time.
 * </p>
 * <p>
 * What is left here: the spans for a piece of code ({@link #codeSpans}), and
 * live colouring of the text the user is typing ({@link #attach}): on each
 * user edit only the input region is restyled, so the cost of a keystroke
 * does not grow with the transcript.
 * </p>
 */
public final class ConsoleHighlighter {

    /** The prompt's mark, without its trailing space. */
    private static final String PROMPT_MARK = ">>";

    public static final String PROMPT_CLASS = "console-prompt";
    public static final String OUTPUT_CLASS = "console-output";

    /** Style of the {@code >> } prompt. */
    public static final Collection<String> PROMPT_STYLE = List.of(PROMPT_CLASS);

    /** Style of interpreter output and IDE messages. */
    public static final Collection<String> OUTPUT_STYLE = List.of(OUTPUT_CLASS);

    private ConsoleHighlighter() {
    }

    /**
     * Without an input start nothing is coloured live; kept for callers that
     * only want the class constants.
     *
     * @param area the console
     */
    public static void attach(ConsoleArea area) {
        attach(area, null, null);
    }

    /**
     * Colours what the user types, as they type it.
     *
     * @param area        the console
     * @param inputStart  where the input region starts ({@code ide.inputStart})
     * @param userEditing true when a change comes from the user rather than
     *                    from the CLI writing (system writes are styled when
     *                    written); may be null
     */
    public static void attach(ConsoleArea area, IntSupplier inputStart, BooleanSupplier userEditing) {
        if (inputStart == null) {
            return;
        }
        // The check happens while the change is reported (so a system write
        // is told apart from typing); the restyle itself runs after the edit
        // is complete - see ConsoleArea's class notes.
        boolean[] pending = new boolean[1];
        area.plainTextChanges().subscribe(change -> {
            if (userEditing == null || userEditing.getAsBoolean()) {
                pending[0] = true;
            }
        });
        area.addAfterEdit(() -> {
            if (pending[0]) {
                pending[0] = false;
                restyleInput(area, inputStart.getAsInt());
            }
        });
    }

    /**
     * Restyles the input region, {@code from} to the end, as code.
     *
     * @param area the console
     * @param from the input start
     */
    public static void restyleInput(ConsoleArea area, int from) {
        int length = area.getLength();
        int start = Math.max(0, Math.min(from, length));
        if (start >= length) {
            return;
        }
        // A name being edited stays side by side (ScriptStack).
        area.setStyleSpans(start, ScriptStack.keepOpen(area, codeSpans(area.getText(start, length)), start));
    }

    /**
     * @param text code, possibly several lines (a block typed at the prompt)
     * @return its spans, as the editor colours it; exactly as long as the text
     */
    public static StyleSpans<Collection<String>> codeSpans(String text) {
        if (text == null || text.isEmpty()) {
            StyleSpansBuilder<Collection<String>> empty = new StyleSpansBuilder<>();
            empty.add(OUTPUT_STYLE, 0);
            return empty.create();
        }
        try {
            StyleSpansBuilder<Collection<String>> spans = new StyleSpansBuilder<>();
            int total = 0;
            for (StyleSpan<Collection<String>> span : UPITokenMaker.computeHighlighting(text)) {
                int length = Math.min(span.getLength(), text.length() - total);
                if (length <= 0) {
                    break;
                }
                spans.add(span.getStyle(), length);
                total += length;
            }
            if (total < text.length()) {
                spans.add(OUTPUT_STYLE, text.length() - total);
            }
            return spans.create();
        } catch (RuntimeException e) {
            // A tokenizer hiccup on half-typed code must never lose a keystroke.
            StyleSpansBuilder<Collection<String>> plain = new StyleSpansBuilder<>();
            plain.add(OUTPUT_STYLE, text.length());
            return plain.create();
        }
    }

    /**
     * Spans for a name in interpreter output: {@code f_$5} drawn as f&#8325;
     * in the output colour -- the marker hidden, the script lowered or
     * raised, as {@code UPITokenMaker} does for code.
     *
     * @param name a name
     * @return its spans, or null when it has no valid subscript or
     *         superscript (it is then shown exactly as written)
     */
    public static StyleSpans<Collection<String>> outputNameSpans(String name) {
        if (!ScriptedName.hasScripts(name)) {
            return null;
        }
        ScriptedName.Parsed parsed = ScriptedName.parse(name);
        if (!parsed.isValid()) {
            return null;
        }
        ScriptedName.Part stacked = UPITokenMaker.stackedPart(parsed);
        StyleSpansBuilder<Collection<String>> spans = new StyleSpansBuilder<>();
        for (ScriptedName.Part part : parsed.parts()) {
            if (part.kind() == ScriptedName.Kind.BASE) {
                spans.add(OUTPUT_STYLE, part.end());
                continue;
            }
            spans.add(List.of(OUTPUT_CLASS, UPITokenMaker.MARKER_CLASS), part.contentStart() - part.markerStart());
            String script = part.kind() == ScriptedName.Kind.SUBSCRIPT
                    ? UPITokenMaker.SUBSCRIPT_CLASS : UPITokenMaker.SUPERSCRIPT_CLASS;
            spans.add(part == stacked
                    ? List.of(OUTPUT_CLASS, script, UPITokenMaker.STACKED_CLASS)
                    : List.of(OUTPUT_CLASS, script),
                    part.end() - part.contentStart());
        }
        return spans.create();
    }

    /**
     * Spans for one whole transcript line, guessed from its text: prompt plus
     * coloured command, or plain output. Kept for callers that restyle a
     * transcript they did not write; the CLI itself no longer needs it.
     *
     * @param line one line of the transcript
     * @return its spans
     */
    public static StyleSpans<Collection<String>> spansFor(String line) {
        StyleSpansBuilder<Collection<String>> spans = new StyleSpansBuilder<>();
        if (!line.startsWith(PROMPT_MARK)) {
            spans.add(OUTPUT_STYLE, line.length());
            return spans.create();
        }
        spans.add(PROMPT_STYLE, PROMPT_MARK.length());
        String command = line.substring(PROMPT_MARK.length());
        if (!command.isEmpty()) {
            for (StyleSpan<Collection<String>> span : codeSpans(command)) {
                spans.add(span);
            }
        }
        return spans.create();
    }

    /**
     * Restyles paragraphs {@code first..last} from their text (see
     * {@link #spansFor}).
     *
     * @param area  the console
     * @param first first paragraph
     * @param last  last paragraph
     */
    public static void restyle(ConsoleArea area, int first, int last) {
        int count = area.getParagraphs().size();
        for (int i = Math.max(0, first); i <= Math.min(last, count - 1); i++) {
            area.setStyleSpans(i, 0, spansFor(area.getParagraph(i).getText()));
        }
    }
}
