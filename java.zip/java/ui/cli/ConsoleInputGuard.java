package ui.cli;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;

import javafx.scene.control.TextArea;
import javafx.scene.control.TextFormatter;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import ui.UI_Main;

/**
 * Makes the Command Window behave like MATLAB's: everything above the current
 * {@code >> } prompt is frozen history, and the prompt itself is a hard stop
 * that BACKSPACE cannot cross.
 *
 * <h3>Why this is its own class</h3>
 * The old approach put a couple of checks in {@code setOnKeyPressed}. That
 * blocks the obvious case and misses every other way a JavaFX
 * {@code TextArea} can be mutated: a selection dragged across the boundary and
 * then overtyped, DELETE, Ctrl+X, a paste over a spanning selection,
 * drag-and-drop text, and Ctrl+Z (undo can wipe the entire transcript in one
 * keystroke). It also fought the control's own behaviour, because
 * {@code setOnKeyPressed} installs a handler, not a filter.
 *
 * <h3>The four layers</h3>
 * <ol>
 *   <li><b>Anchor.</b> {@code ide.inputStart} is the offset just past the
 *       prompt. Everything below it is committed.</li>
 *   <li><b>Content filter.</b> A {@link TextFormatter} rejects <em>any</em>
 *       change whose range starts before the anchor. Every mutation path in
 *       {@code TextInputControl} funnels through here, so this one layer
 *       covers typing, paste, cut, delete and drag-and-drop at once — that is
 *       what makes the freeze airtight rather than merely usually right.</li>
 *   <li><b>Caret and selection clamp.</b> The same filter also sees non-content
 *       changes, so a click or a drag into the history is pulled back to the
 *       anchor.</li>
 *   <li><b>Key filter.</b> Handles what the formatter cannot see: ENTER
 *       submission, HOME / Ctrl+A scoped to the input line, UP/DOWN history
 *       recall, and suppressing undo/redo.</li>
 * </ol>
 *
 * <h3>System writes</h3>
 * Output from {@code nc.exe} is appended by the IDE itself and must bypass the
 * filter, otherwise the console would reject its own output. All such writes go
 * through {@link #systemWrite(Runnable)}, which is the only way to move the
 * anchor forward.
 */
public final class ConsoleInputGuard {

    private static final int HISTORY_LIMIT = 200;

    private final UI_Main ide;
    private final TextArea area;

    private boolean systemWriting;
    private Runnable onSubmit = () -> { };
    private BooleanSupplier suppressEnter = () -> false;

    private final List<String> history = new ArrayList<>();
    private int historyCursor = 0;
    private String draft = "";

    /**
     * @param ide  the IDE controller (owns {@code inputStart})
     * @param area the console text area
     */
    public ConsoleInputGuard(UI_Main ide, TextArea area) {
        this.ide = ide;
        this.area = area;
        installContentFilter();
        installKeyFilter();
        installPointerClamp();
    }

    // -----------------------------------------------------------------
    // Wiring
    // -----------------------------------------------------------------

    /**
     * @param action invoked when ENTER is pressed on an unfrozen line
     */
    public void setOnSubmit(Runnable action) {
        this.onSubmit = action == null ? () -> { } : action;
    }

    /**
     * @param condition when true, ENTER is left alone (the suggestion popup is
     *                  open and wants to consume it)
     */
    public void setSuppressEnter(BooleanSupplier condition) {
        this.suppressEnter = condition == null ? () -> false : condition;
    }

    // -----------------------------------------------------------------
    // System writes
    // -----------------------------------------------------------------

    /**
     * Runs a privileged console mutation (printing output, painting a prompt,
     * clearing the screen) with the freeze temporarily lifted.
     *
     * @param action the mutation to perform
     */
    public void systemWrite(Runnable action) {
        boolean previous = systemWriting;
        systemWriting = true;
        try {
            action.run();
        } finally {
            systemWriting = previous;
        }
    }

    /**
     * Appends text as output and moves the freeze boundary past it.
     *
     * @param text the text to append
     */
    public void append(String text) {
        if (text == null || text.isEmpty()) {
            return;
        }
        systemWrite(() -> {
            area.appendText(text);
            ide.inputStart = area.getLength();
            area.positionCaret(area.getLength());
        });
    }

    /**
     * Appends text without moving the boundary — used for the newline that
     * follows a submitted command, where the boundary is set by the caller.
     *
     * @param text the text to append
     */
    public void appendRaw(String text) {
        if (text == null || text.isEmpty()) {
            return;
        }
        systemWrite(() -> {
            area.appendText(text);
            area.positionCaret(area.getLength());
        });
    }

    /** Wipes the transcript (the {@code cls} command) and resets the anchor. */
    public void clearScreen() {
        systemWrite(() -> {
            area.clear();
            ide.inputStart = 0;
            area.positionCaret(0);
        });
    }

    /** Moves the freeze boundary to the end of the current text. */
    public void lockToEnd() {
        systemWrite(() -> {
            ide.inputStart = area.getLength();
            area.positionCaret(area.getLength());
        });
    }

    /** @return the text the user has typed after the prompt */
    public String currentInput() {
        int end = area.getLength();
        int start = Math.max(0, Math.min(ide.inputStart, end));
        return area.getText(start, end);
    }

    /**
     * @return true while the IDE is writing to the console itself, so
     *         listeners can tell an append of interpreter output apart from
     *         the user typing
     */
    public boolean isSystemWriting() {
        return systemWriting;
    }

    /**
     * Replaces the text after the prompt. Used by history recall and by live
     * symbol replacement, both of which rewrite the input line wholesale.
     *
     * @param replacement the new input line
     */
    public void setInput(String replacement) {
        replaceInput(replacement);
    }

    /** Replaces the current input line (history recall). */
    private void replaceInput(String replacement) {
        int end = area.getLength();
        int start = Math.max(0, Math.min(ide.inputStart, end));
        systemWrite(() -> {
            area.replaceText(start, end, replacement == null ? "" : replacement);
            area.positionCaret(area.getLength());
        });
    }

    /**
     * Records a submitted command for UP/DOWN recall.
     *
     * @param command the submitted line
     */
    public void rememberCommand(String command) {
        if (command == null || command.isBlank()) {
            return;
        }
        if (history.isEmpty() || !history.get(history.size() - 1).equals(command)) {
            history.add(command);
        }
        while (history.size() > HISTORY_LIMIT) {
            history.remove(0);
        }
        historyCursor = history.size();
        draft = "";
    }

    // -----------------------------------------------------------------
    // Layer 2 + 3: content filter and caret clamp
    // -----------------------------------------------------------------

    private void installContentFilter() {
        area.setTextFormatter(new TextFormatter<>(change -> {
            if (systemWriting) {
                return change;
            }
            int anchor = Math.max(0, Math.min(ide.inputStart, area.getLength()));

            if (change.isContentChange() && change.getRangeStart() < anchor) {
                // Layer 2: the edit reaches into committed history. Reject the
                // whole change rather than trimming it, so a spanning paste
                // cannot partially apply.
                return null;
            }

            // Layer 3: pull the caret and the selection anchor forward.
            if (change.getAnchor() < anchor) {
                change.setAnchor(anchor);
            }
            if (change.getCaretPosition() < anchor) {
                change.setCaretPosition(anchor);
            }
            return change;
        }));
    }

    private void installPointerClamp() {
        // A click lands the caret before the formatter sees a selection change
        // in some skins; clamping on release covers that.
        area.addEventFilter(MouseEvent.MOUSE_RELEASED, event -> {
            int anchor = Math.max(0, Math.min(ide.inputStart, area.getLength()));
            if (area.getCaretPosition() < anchor && area.getSelection().getLength() == 0) {
                area.positionCaret(anchor);
            }
        });
    }

    // -----------------------------------------------------------------
    // Layer 4: key filter
    // -----------------------------------------------------------------

    private void installKeyFilter() {
        area.addEventFilter(KeyEvent.KEY_PRESSED, event -> {
            int anchor = Math.max(0, Math.min(ide.inputStart, area.getLength()));
            KeyCode code = event.getCode();

            // Undo/redo would restore text from before the boundary.
            if (event.isShortcutDown() && (code == KeyCode.Z || code == KeyCode.Y)) {
                event.consume();
                return;
            }

            // Select-all is scoped to the editable line, like MATLAB.
            if (event.isShortcutDown() && code == KeyCode.A) {
                area.selectRange(anchor, area.getLength());
                event.consume();
                return;
            }

            if (code == KeyCode.HOME) {
                if (event.isShiftDown()) {
                    area.selectRange(area.getCaretPosition(), anchor);
                } else {
                    area.positionCaret(anchor);
                }
                event.consume();
                return;
            }

            // ">>" is the hard stop: no backspace, no left-arrow past it.
            if ((code == KeyCode.BACK_SPACE || code == KeyCode.LEFT)
                    && area.getSelection().getLength() == 0
                    && area.getCaretPosition() <= anchor) {
                event.consume();
                return;
            }

            if (suppressEnter.getAsBoolean()) {
                // The suggestion popup owns ENTER/UP/DOWN while it is visible.
                return;
            }

            if (code == KeyCode.UP) {
                recallHistory(-1);
                event.consume();
                return;
            }
            if (code == KeyCode.DOWN) {
                recallHistory(1);
                event.consume();
                return;
            }

            if (code == KeyCode.ENTER) {
                // The TextArea would insert its own newline on KEY_TYPED;
                // consuming here plus the KEY_TYPED filter below means Java is
                // the sole author of newlines, so one ENTER advances one line.
                event.consume();
                onSubmit.run();
            }
        });

        area.addEventFilter(KeyEvent.KEY_TYPED, event -> {
            String character = event.getCharacter();
            if (character != null && (character.equals("\r") || character.equals("\n"))) {
                event.consume();
            }
        });
    }

    private void recallHistory(int direction) {
        if (history.isEmpty()) {
            return;
        }
        if (historyCursor == history.size()) {
            draft = currentInput();
        }
        int next = historyCursor + direction;
        if (next < 0) {
            next = 0;
        }
        if (next > history.size()) {
            next = history.size();
        }
        historyCursor = next;
        replaceInput(historyCursor == history.size() ? draft : history.get(historyCursor));
    }
}
