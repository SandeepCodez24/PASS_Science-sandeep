package ui.cli;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;

import javafx.scene.control.TextArea;
import javafx.scene.control.TextFormatter;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import ui.UI_Main;

/**
 * Makes the Command Window behave like MATLAB's: everything above the current
 * {@code >> } prompt is frozen history, and the prompt itself is a hard stop
 * that BACKSPACE cannot cross.
 *
 * <h3>Why this is its own class</h3>
 * The old approach put a couple of checks in {@code setOnKeyPressed}. That
 * blocks the obvious case and misses every other way a JavaFX
 * {@code TextArea} can be mutated: a selection dragged across the boundary and
 * then overtyped, DELETE, Ctrl+X, a paste over a spanning selection,
 * drag-and-drop text, and Ctrl+Z (undo can wipe the entire transcript in one
 * keystroke). It also fought the control's own behaviour, because
 * {@code setOnKeyPressed} installs a handler, not a filter.
 *
 * <h3>The four layers</h3>
 * <ol>
 *   <li><b>Anchor.</b> {@code ide.inputStart} is the offset just past the
 *       prompt. Everything below it is committed.</li>
 *   <li><b>Content filter.</b> A {@link TextFormatter} rejects <em>any</em>
 *       change whose range starts before the anchor. Every mutation path in
 *       {@code TextInputControl} funnels through here, so this one layer
 *       covers typing, paste, cut, delete and drag-and-drop at once — that is
 *       what makes the freeze airtight rather than merely usually right.</li>
 *   <li><b>Caret clamp on edits.</b> A content change keeps its caret and
 *       anchor at or after the prompt. Selection-only changes are left alone
 *       so the history can be selected and copied (see below).</li>
 *   <li><b>Key filter.</b> Handles what the formatter cannot see: ENTER
 *       submission, HOME / Ctrl+A scoped to the input line, UP/DOWN history
 *       recall, and suppressing undo/redo.</li>
 * </ol>
 *
 * <h3>Select and copy the history</h3>
 * The history is frozen against <em>editing</em>, not against
 * <em>selection</em>. Layer 3 used to pull the caret and the selection anchor
 * forward to the prompt on every change, so a mouse drag over earlier commands
 * or output collapsed the instant it started, and nothing could be copied.
 * Now only content changes are clamped; a selection may lie anywhere, and
 * Ctrl+C (or the console's right-click menu) copies it.
 * <ul>
 *   <li>A plain click in the history still returns the caret to the prompt, as
 *       before; a drag or a double-click keeps its selection.</li>
 *   <li>Shift+arrows extend a selection into the history.</li>
 *   <li>Ctrl+X over the history copies instead of cutting.</li>
 *   <li>Typing, Backspace, Delete, paste or a plain arrow while the selection is
 *       in the history first returns the caret to the end of the prompt line,
 *       so the keystroke goes to the input and never to the history.</li>
 * </ul>
 * Layer 2 is untouched, so no change can ever reach committed text.
 *
 * <h3>System writes</h3>
 * Output from {@code nc.exe} is appended by the IDE itself and must bypass the
 * filter, otherwise the console would reject its own output. All such writes go
 * through {@link #systemWrite(Runnable)}, which is the only way to move the
 * anchor forward.
 */
public final class ConsoleInputGuard {

    private static final int HISTORY_LIMIT = 200;

    private final UI_Main ide;
    private final TextArea area;

    private boolean systemWriting;
    private Runnable onSubmit = () -> { };
    private BooleanSupplier suppressEnter = () -> false;

    private final List<String> history = new ArrayList<>();
    private int historyCursor = 0;
    private String draft = "";

    /**
     * @param ide  the IDE controller (owns {@code inputStart})
     * @param area the console text area
     */
    public ConsoleInputGuard(UI_Main ide, TextArea area) {
        this.ide = ide;
        this.area = area;
        installContentFilter();
        installKeyFilter();
        installPointerClamp();
    }

    // -----------------------------------------------------------------
    // Wiring
    // -----------------------------------------------------------------

    /**
     * @param action invoked when ENTER is pressed on an unfrozen line
     */
    public void setOnSubmit(Runnable action) {
        this.onSubmit = action == null ? () -> { } : action;
    }

    /**
     * @param condition when true, ENTER is left alone (the suggestion popup is
     *                  open and wants to consume it)
     */
    public void setSuppressEnter(BooleanSupplier condition) {
        this.suppressEnter = condition == null ? () -> false : condition;
    }

    // -----------------------------------------------------------------
    // System writes
    // -----------------------------------------------------------------

    /**
     * Runs a privileged console mutation (printing output, painting a prompt,
     * clearing the screen) with the freeze temporarily lifted.
     *
     * @param action the mutation to perform
     */
    public void systemWrite(Runnable action) {
        boolean previous = systemWriting;
        systemWriting = true;
        try {
            action.run();
        } finally {
            systemWriting = previous;
        }
    }

    /**
     * Appends text as output and moves the freeze boundary past it.
     *
     * @param text the text to append
     */
    public void append(String text) {
        if (text == null || text.isEmpty()) {
            return;
        }
        systemWrite(() -> {
            area.appendText(text);
            ide.inputStart = area.getLength();
            area.positionCaret(area.getLength());
        });
    }

    /**
     * Appends text without moving the boundary — used for the newline that
     * follows a submitted command, where the boundary is set by the caller.
     *
     * @param text the text to append
     */
    public void appendRaw(String text) {
        if (text == null || text.isEmpty()) {
            return;
        }
        systemWrite(() -> {
            area.appendText(text);
            area.positionCaret(area.getLength());
        });
    }

    /** Wipes the transcript (the {@code cls} command) and resets the anchor. */
    public void clearScreen() {
        systemWrite(() -> {
            area.clear();
            ide.inputStart = 0;
            area.positionCaret(0);
        });
    }

    /** Moves the freeze boundary to the end of the current text. */
    public void lockToEnd() {
        systemWrite(() -> {
            ide.inputStart = area.getLength();
            area.positionCaret(area.getLength());
        });
    }

    /** @return the text the user has typed after the prompt */
    public String currentInput() {
        int end = area.getLength();
        int start = Math.max(0, Math.min(ide.inputStart, end));
        return area.getText(start, end);
    }

    /**
     * @return true while the IDE is writing to the console itself, so
     *         listeners can tell an append of interpreter output apart from
     *         the user typing
     */
    public boolean isSystemWriting() {
        return systemWriting;
    }

    /**
     * Replaces the text after the prompt. Used by history recall and by live
     * symbol replacement, both of which rewrite the input line wholesale.
     *
     * @param replacement the new input line
     */
    public void setInput(String replacement) {
        replaceInput(replacement);
    }

    /** Replaces the current input line (history recall). */
    private void replaceInput(String replacement) {
        int end = area.getLength();
        int start = Math.max(0, Math.min(ide.inputStart, end));
        systemWrite(() -> {
            area.replaceText(start, end, replacement == null ? "" : replacement);
            area.positionCaret(area.getLength());
        });
    }

    /**
     * Records a submitted command for UP/DOWN recall.
     *
     * @param command the submitted line
     */
    public void rememberCommand(String command) {
        if (command == null || command.isBlank()) {
            return;
        }
        if (history.isEmpty() || !history.get(history.size() - 1).equals(command)) {
            history.add(command);
        }
        while (history.size() > HISTORY_LIMIT) {
            history.remove(0);
        }
        historyCursor = history.size();
        draft = "";
    }

    // -----------------------------------------------------------------
    // Copy
    // -----------------------------------------------------------------

    /** Copies the current selection, wherever it lies. Does nothing when empty. */
    public void copySelection() {
        String selected = area.getSelectedText();
        if (selected != null && !selected.isEmpty()) {
            copyToClipboard(selected);
        }
    }

    /** Copies the whole transcript: every command, output and the prompt line. */
    public void copyAll() {
        copyAll(area);
    }

    /**
     * Copies a console's whole transcript. Static so the Command Window's
     * three-dot menu can use it without holding the guard.
     *
     * @param console the console text area
     */
    public static void copyAll(TextArea console) {
        if (console != null) {
            copyToClipboard(console.getText());
        }
    }

    private static void copyToClipboard(String text) {
        ClipboardContent content = new ClipboardContent();
        content.putString(text == null ? "" : text);
        Clipboard.getSystemClipboard().setContent(content);
    }

    /** True when the caret or the selection anchor sits in committed history. */
    private boolean selectionInHistory() {
        int anchor = Math.max(0, Math.min(ide.inputStart, area.getLength()));
        return area.getCaretPosition() < anchor || area.getAnchor() < anchor;
    }

    /** Leaves the history: caret to the end of the prompt line, selection cleared. */
    private void returnToPrompt() {
        area.positionCaret(area.getLength());
    }

    // -----------------------------------------------------------------
    // Layer 2 + 3: content filter and caret clamp
    // -----------------------------------------------------------------

    private void installContentFilter() {
        area.setTextFormatter(new TextFormatter<>(change -> {
            if (systemWriting) {
                return change;
            }
            int anchor = Math.max(0, Math.min(ide.inputStart, area.getLength()));

            if (change.isContentChange() && change.getRangeStart() < anchor) {
                // Layer 2: the edit reaches into committed history. Reject the
                // whole change rather than trimming it, so a spanning paste
                // cannot partially apply.
                return null;
            }

            // Layer 3: only an EDIT is clamped. A selection-only change (a
            // mouse drag, a double-click, Shift+arrows) may lie anywhere, which
            // is what lets the history be selected and copied. Clamping these
            // too was what collapsed every drag the moment it began.
            if (change.isContentChange()) {
                if (change.getAnchor() < anchor) {
                    change.setAnchor(anchor);
                }
                if (change.getCaretPosition() < anchor) {
                    change.setCaretPosition(anchor);
                }
            }
            return change;
        }));
    }

    private void installPointerClamp() {
        // A click lands the caret before the formatter sees a selection change
        // in some skins; clamping on release covers that.
        area.addEventFilter(MouseEvent.MOUSE_RELEASED, event -> {
            int anchor = Math.max(0, Math.min(ide.inputStart, area.getLength()));
            if (area.getCaretPosition() < anchor && area.getSelection().getLength() == 0) {
                area.positionCaret(anchor);
            }
        });
    }

    // -----------------------------------------------------------------
    // Layer 4: key filter
    // -----------------------------------------------------------------

    private void installKeyFilter() {
        area.addEventFilter(KeyEvent.KEY_PRESSED, event -> {
            int anchor = Math.max(0, Math.min(ide.inputStart, area.getLength()));
            KeyCode code = event.getCode();

            // ── Selection in the history: copy is allowed, editing is not ──
            if (selectionInHistory()) {
                if (code.isModifierKey()) {
                    return; // Ctrl / Shift alone: keep the selection
                }
                if (event.isShortcutDown() && (code == KeyCode.C || code == KeyCode.INSERT)) {
                    copySelection();
                    event.consume();
                    return;
                }
                if (event.isShortcutDown() && code == KeyCode.X) {
                    copySelection(); // copy, never cut, from the history
                    event.consume();
                    return;
                }
                if (event.isShiftDown() && isNavigation(code)) {
                    return; // extending the selection
                }
                // Any other key belongs to the prompt line.
                returnToPrompt();
                if (code == KeyCode.BACK_SPACE || code == KeyCode.DELETE
                        || code == KeyCode.LEFT || code == KeyCode.RIGHT
                        || code == KeyCode.HOME || code == KeyCode.END
                        || code == KeyCode.ESCAPE) {
                    event.consume(); // that key only meant "leave the history"
                    return;
                }
                // Letters, ENTER, paste, UP/DOWN recall: fall through and run
                // normally, now at the prompt.
            }

            // Undo/redo would restore text from before the boundary.
            if (event.isShortcutDown() && (code == KeyCode.Z || code == KeyCode.Y)) {
                event.consume();
                return;
            }

            // Select-all is scoped to the editable line, like MATLAB.
            if (event.isShortcutDown() && code == KeyCode.A) {
                area.selectRange(anchor, area.getLength());
                event.consume();
                return;
            }

            if (code == KeyCode.HOME) {
                if (event.isShiftDown()) {
                    area.selectRange(area.getCaretPosition(), anchor);
                } else {
                    area.positionCaret(anchor);
                }
                event.consume();
                return;
            }

            // ">>" is the hard stop: no backspace, no left-arrow past it.
            if ((code == KeyCode.BACK_SPACE || code == KeyCode.LEFT)
                    && area.getSelection().getLength() == 0
                    && area.getCaretPosition() <= anchor) {
                event.consume();
                return;
            }

            if (suppressEnter.getAsBoolean()) {
                // The suggestion popup owns ENTER/UP/DOWN while it is visible.
                return;
            }

            if (code == KeyCode.UP) {
                recallHistory(-1);
                event.consume();
                return;
            }
            if (code == KeyCode.DOWN) {
                recallHistory(1);
                event.consume();
                return;
            }

            if (code == KeyCode.ENTER) {
                // The TextArea would insert its own newline on KEY_TYPED;
                // consuming here plus the KEY_TYPED filter below means Java is
                // the sole author of newlines, so one ENTER advances one line.
                event.consume();
                onSubmit.run();
            }
        });

        area.addEventFilter(KeyEvent.KEY_TYPED, event -> {
            String character = event.getCharacter();
            if (character != null && (character.equals("\r") || character.equals("\n"))) {
                event.consume();
                return;
            }
            // Safety net: a printable character never lands in the history.
            if (character != null && !character.isEmpty() && character.charAt(0) >= 0x20
                    && character.charAt(0) != 0x7F && !event.isShortcutDown() && selectionInHistory()) {
                returnToPrompt();
            }
        });
    }

    private static boolean isNavigation(KeyCode code) {
        return code == KeyCode.LEFT || code == KeyCode.RIGHT || code == KeyCode.UP
                || code == KeyCode.DOWN || code == KeyCode.HOME || code == KeyCode.END
                || code == KeyCode.PAGE_UP || code == KeyCode.PAGE_DOWN;
    }

    private void recallHistory(int direction) {
        if (history.isEmpty()) {
            return;
        }
        if (historyCursor == history.size()) {
            draft = currentInput();
        }
        int next = historyCursor + direction;
        if (next < 0) {
            next = 0;
        }
        if (next > history.size()) {
            next = history.size();
        }
        historyCursor = next;
        replaceInput(historyCursor == history.size() ? draft : history.get(historyCursor));
    }
}
