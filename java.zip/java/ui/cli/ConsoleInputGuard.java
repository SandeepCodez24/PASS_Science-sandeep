package ui.cli;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.fxmisc.richtext.model.StyleSpans;
import org.fxmisc.richtext.model.TwoDimensional.Bias;

import javafx.application.Platform;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import language.semantic.ScriptedName;
import ui.UI_Main;
import ui.editor.ScriptedCaret;

/**
 * Owns the Command Window's transcript: what is frozen, where output goes,
 * where the prompt is, and what the user may edit (MATLAB's rules).
 *
 * <h3>The transcript model</h3>
 *
 * <pre>
 *   ... frozen history ...                      never editable
 *   &gt;&gt; x = 5                                    an echoed command (frozen)
 *   x = 5                                       output (frozen)
 *   &gt;&gt; |typed text|                              prompt + input region
 *   ^  ^
 *   |  ide.inputStart: start of the input region
 *   outputPosition(): where output goes
 * </pre>
 *
 * <ul>
 *   <li><b>The input region</b> runs from {@code ide.inputStart} to the end.
 *       It is the only editable text.</li>
 *   <li><b>The prompt</b> is painted only while the console is idle
 *       ({@link #showPrompt}). While a command runs there is no prompt, and
 *       the input region holds whatever the user types ahead.</li>
 *   <li><b>Output</b> is always inserted at {@link #outputPosition()}: just
 *       before the prompt when idle, just before the typed-ahead text while a
 *       command runs. Output can therefore never land inside, or after, what
 *       the user is typing -- the old console appended it at the end and then
 *       froze the user's keystrokes into the history.</li>
 *   <li><b>A command</b> is echoed as {@code >> command} on a frozen line of
 *       its own ({@link #echoCommand}) when it starts to run.</li>
 * </ul>
 *
 * <h3>Every system write is one styled edit</h3>
 * <p>
 * Each write carries its final style ({@link ConsoleArea#writeStyled}) and
 * keeps the caret and the selection where they were relative to the text.
 * None of them scrolls: whether to follow the caret is decided once per batch
 * by the CLI (see {@code CLI_Main.withFollow}).
 * </p>
 *
 * <h3>The freeze (unchanged in spirit)</h3>
 * <ol>
 *   <li><b>Edit veto.</b> {@link ConsoleArea#setEditVeto} refuses any edit
 *       starting before the input region unless the CLI itself is writing
 *       ({@link #systemWrite}).</li>
 *   <li><b>Key filter.</b> ENTER submission, HOME / Ctrl+A, UP / DOWN recall,
 *       undo/redo suppressed, Ctrl+C stop-or-copy.</li>
 *   <li><b>Selection is free.</b> The history can be selected and copied;
 *       a key that would edit first returns the caret to the input.</li>
 * </ol>
 */
public final class ConsoleInputGuard {

    private static final int HISTORY_LIMIT = 200;

    private static final String PROMPT = CLI_Main.PROMPT;

    private final UI_Main ide;
    private final ConsoleArea area;

    private boolean systemWriting;
    private boolean promptShown;
    private Runnable onSubmit = () -> { };
    private BooleanSupplier suppressEnter = () -> false;
    private BooleanSupplier busy = () -> false;
    private Runnable onInterrupt = () -> { };

    /** The echo of the command that just started, not yet drawn; see {@link #holdEcho}. */
    private Runnable heldEcho;
    private Runnable onKeyWhileEchoHeld = this::flushEcho;

    private final List<String> history = new ArrayList<>();
    private int historyCursor = 0;
    private String draft = "";

    /**
     * @param ide  the IDE controller (owns {@code inputStart})
     * @param area the console
     */
    public ConsoleInputGuard(UI_Main ide, ConsoleArea area) {
        this.ide = ide;
        this.area = area;
        installContentFilter();
        installKeyFilter();
        installPointerClamp();
    }

    // -----------------------------------------------------------------
    // Wiring
    // -----------------------------------------------------------------

    /** @param action invoked when ENTER is pressed in the input region */
    public void setOnSubmit(Runnable action) {
        this.onSubmit = action == null ? () -> { } : action;
    }

    /** @param condition when true, ENTER is left alone (the suggestion popup wants it) */
    public void setSuppressEnter(BooleanSupplier condition) {
        this.suppressEnter = condition == null ? () -> false : condition;
    }

    /** @param condition true while a command is executing; Ctrl+C then stops */
    public void setBusy(BooleanSupplier condition) {
        this.busy = condition == null ? () -> false : condition;
    }

    /** @param action invoked by Ctrl+C while {@link #setBusy busy} */
    public void setOnInterrupt(Runnable action) {
        this.onInterrupt = action == null ? () -> { } : action;
    }

    /**
     * @param action invoked when the user presses a key or edits while an
     *               echo is held; it must draw the echo ({@link #flushEcho})
     */
    public void setOnKeyWhileEchoHeld(Runnable action) {
        this.onKeyWhileEchoHeld = action == null ? this::flushEcho : action;
    }

    // -----------------------------------------------------------------
    // The held echo (MATLAB: a quick command's result appears in one go)
    // -----------------------------------------------------------------

    /**
     * Holds back a starting command's echo: the screen keeps showing the
     * command as typed, and the echo is drawn by the next write to the
     * console -- normally the command's first output, or its end -- so the
     * echo and the result appear in the same frame. Without it a quick
     * command showed one frame of {@code >> k = 5} over an empty line, then
     * the result: a blink. The CLI draws the echo itself
     * ({@link #flushEcho}) when a command takes longer, and any key or edit
     * by the user draws it first.
     *
     * @param takeTyped true when the command is still in the input region
     *                  (typed and run at once); it is taken out when the echo
     *                  is drawn
     * @param echo      draws the echo ({@link #echoCommand}, or
     *                  {@link #hidePrompt} for a command shown without one)
     */
    public void holdEcho(boolean takeTyped, Runnable echo) {
        flushEcho();
        heldEcho = () -> {
            if (takeTyped) {
                takeInput();
            }
            echo.run();
        };
    }

    /** @return true while an echo is held back */
    public boolean isEchoHeld() {
        return heldEcho != null;
    }

    /** Draws the held echo, if any. Every write to the console does this first. */
    public void flushEcho() {
        Runnable echo = heldEcho;
        if (echo != null) {
            heldEcho = null;
            echo.run();
        }
    }

    // -----------------------------------------------------------------
    // Regions
    // -----------------------------------------------------------------

    /** @return true while the {@code >> } prompt is painted (the console is idle) */
    public boolean isPromptShown() {
        return promptShown;
    }

    /** @return where output is inserted: before the prompt, or before typed-ahead text */
    public int outputPosition() {
        int start = inputStart();
        return Math.max(0, promptShown ? start - PROMPT.length() : start);
    }

    private int inputStart() {
        return Math.max(0, Math.min(ide.inputStart, area.getLength()));
    }

    /** @return the text the user has typed in the input region */
    public String currentInput() {
        int end = area.getLength();
        return area.getText(inputStart(), end);
    }

    /** @return true while the CLI itself is writing, so listeners can tell it from typing */
    public boolean isSystemWriting() {
        return systemWriting;
    }

    /**
     * Runs a privileged console mutation with the freeze lifted.
     *
     * @param action the mutation
     */
    public void systemWrite(Runnable action) {
        boolean previous = systemWriting;
        systemWriting = true;
        try {
            action.run();
        } finally {
            systemWriting = previous;
        }
    }

    // -----------------------------------------------------------------
    // Writing (all frozen, all before the input region)
    // -----------------------------------------------------------------

    /**
     * Interpreter output. While a command runs it is inserted exactly as
     * received (a line may arrive in pieces). While idle -- the prompt is
     * showing -- it is a complete note and goes on lines of its own above the
     * prompt.
     *
     * @param text the output
     */
    public void writeOutput(String text) {
        if (text == null || text.isEmpty()) {
            return;
        }
        flushEcho();
        int from = outputPosition();
        if (promptShown) {
            writeNotice(text);
        } else {
            insertFrozen(from, text, ConsoleHighlighter.OUTPUT_STYLE);
        }
        styleDisplayedNames(from, outputPosition());
    }

    /**
     * A variable's display header in interpreter output: its name alone on
     * the line, followed by {@code =} ({@code f_$5 =}, the value below it).
     */
    private static final Pattern DISPLAY_HEADER =
            Pattern.compile("\\s*(" + ScriptedName.NAME_REGEX + ")\\s*=\\s*");

    /**
     * An interpreter error: {@code Error: ...}, or the categorised form
     * {@code ✖ Syntax Error (line 1, col 21): ...} / {@code ✖ Runtime Error ...}
     * that also carries the call-matching messages
     * ({@code function 'G': input 'a' was not given ...}).
     */
    private static final Pattern ERROR_LINE = Pattern.compile("\\s*(?:\u2716\\s*)?(?:\\p{L}+\\s+)*Error\\b.*");

    /**
     * A name quoted in an error. {@code nc.exe} always quotes the name it
     * means ({@code Error: 'f_$6' is not defined}).
     */
    private static final Pattern QUOTED_NAME = Pattern.compile("'(" + ScriptedName.NAME_REGEX + ")'");

    /**
     * Draws subscripted and superscripted names in interpreter output as the
     * editor and the Variable Explorer do, among the lines {@code from..to}
     * touches:
     * <ul>
     *   <li>a variable's display header: {@code f_$5 =} reads f&#8325; =;</li>
     *   <li>a name quoted in an error: {@code Error: 'f_$6' is not defined}
     *       reads {@code Error: 'f₆' is not defined}.</li>
     * </ul>
     * The text keeps {@code f_$5} (copy gives what can be typed back). No other
     * output is styled: it may be the text of a string, where {@code _$} stays
     * as written, as it does in the editor. Lines are looked at whole, so a
     * line that arrived in two pieces is styled once it is complete.
     */
    private void styleDisplayedNames(int from, int to) {
        int length = area.getLength();
        if (to <= from || from >= length) {
            return;
        }
        int first = area.offsetToPosition(Math.max(0, from), Bias.Forward).getMajor();
        int last = area.offsetToPosition(Math.min(to, length), Bias.Backward).getMajor();
        for (int p = first; p <= last; p++) {
            String line = area.getParagraph(p).getText();
            if (!ScriptedName.hasScripts(line)) {
                continue;
            }
            Matcher header = DISPLAY_HEADER.matcher(line);
            if (header.matches()) {
                styleOutputName(p, header.start(1), header.group(1));
            } else if (ERROR_LINE.matcher(line).matches()) {
                Matcher quoted = QUOTED_NAME.matcher(line);
                while (quoted.find()) {
                    styleOutputName(p, quoted.start(1), quoted.group(1));
                }
            }
        }
    }

    /** Styles one name of an output line when it has a valid subscript or superscript. */
    private void styleOutputName(int paragraph, int column, String name) {
        StyleSpans<Collection<String>> spans = ConsoleHighlighter.outputNameSpans(name);
        if (spans != null) {
            systemWrite(() -> area.setStyleSpans(paragraph, column, spans));
        }
    }

    /**
     * A message from the IDE: always on lines of its own, wherever the
     * output currently stands.
     *
     * @param text the message; a line break is added if missing
     */
    public void writeNotice(String text) {
        if (text == null || text.isEmpty()) {
            return;
        }
        flushEcho();
        String body = text.endsWith("\n") ? text : text + "\n";
        int at = outputPosition();
        if (needsLineBreakBefore(at)) {
            body = "\n" + body;
        }
        insertFrozen(at, body, ConsoleHighlighter.OUTPUT_STYLE);
    }

    /** Paints the {@code >> } prompt at the start of a line, before the input region. */
    public void showPrompt() {
        flushEcho();
        if (promptShown) {
            return;
        }
        int at = outputPosition();
        if (needsLineBreakBefore(at)) {
            insertFrozen(at, "\n", ConsoleHighlighter.OUTPUT_STYLE);
            at++;
        }
        insertFrozen(at, PROMPT, ConsoleHighlighter.PROMPT_STYLE);
        promptShown = true;
    }

    /** Takes the prompt away (a command is starting). Typed text stays. */
    public void hidePrompt() {
        flushEcho();
        if (!promptShown) {
            return;
        }
        int at = outputPosition();
        promptShown = false;
        deleteFrozen(at, at + PROMPT.length());
    }

    /**
     * Echoes a command as it starts: {@code >> command} on a frozen line of
     * its own, coloured as code. The prompt, if showing, becomes part of it.
     *
     * @param command the command as typed (a block keeps its lines), or the
     *                name to echo for a Run
     */
    public void echoCommand(String command) {
        hidePrompt();
        int at = outputPosition();
        if (needsLineBreakBefore(at)) {
            insertFrozen(at, "\n", ConsoleHighlighter.OUTPUT_STYLE);
            at++;
        }
        insertFrozen(at, PROMPT, ConsoleHighlighter.PROMPT_STYLE);
        at += PROMPT.length();
        String body = normalizeLineBreaks(command); // colours must match what is inserted
        if (!body.isEmpty()) {
            insertFrozen(at, body, ConsoleHighlighter.OUTPUT_STYLE);
            StyleSpans<Collection<String>> spans = ConsoleHighlighter.codeSpans(body);
            int from = at;
            systemWrite(() -> area.setStyleSpans(from, spans));
            at += body.length();
        }
        insertFrozen(at, "\n", ConsoleHighlighter.OUTPUT_STYLE);
    }

    /**
     * Removes and returns the input region's text (ENTER is submitting it).
     *
     * @return the text that was typed
     */
    public String takeInput() {
        String text = currentInput();
        int start = inputStart();
        int end = area.getLength();
        if (end > start) {
            systemWrite(() -> area.deleteText(start, end));
        }
        area.moveTo(area.getLength());
        return text;
    }

    /** Wipes the transcript (the {@code cls} command). The prompt goes too. */
    public void clearScreen() {
        flushEcho();
        systemWrite(area::clear);
        ide.inputStart = 0;
        promptShown = false;
        area.moveTo(0);
    }

    /**
     * Drops the oldest part of the transcript once it grows past
     * {@code maxChars}, keeping roughly the last {@code keepChars}. The cut
     * is moved forward to a line start and never reaches the prompt or the
     * input. MATLAB caps its Command Window buffer for the same reason: every
     * edit's cost would otherwise grow with the transcript.
     *
     * @param maxChars  trim only above this length
     * @param keepChars approximate length left after a trim
     */
    public void trimHistory(int maxChars, int keepChars) {
        int length = area.getLength();
        if (length <= maxChars || keepChars >= length) {
            return;
        }
        int limit = outputPosition();
        int cut = Math.min(length - Math.max(0, keepChars), limit);
        if (cut <= 0) {
            return;
        }
        String head = area.getText(cut, Math.min(limit, cut + 4096));
        int newline = head.indexOf('\n');
        if (newline >= 0) {
            cut += newline + 1;
        }
        deleteFrozen(0, Math.min(cut, limit));
    }

    /**
     * Replaces the input region (history recall, live symbol replacement)
     * and colours it. The caret goes to the end, scrolled into view only as
     * far as needed.
     *
     * @param replacement the new input
     */
    public void setInput(String replacement) {
        flushEcho();
        int start = inputStart();
        int end = area.getLength();
        String text = normalizeLineBreaks(replacement);
        systemWrite(() -> area.writeStyled(start, end, text, ConsoleHighlighter.OUTPUT_STYLE));
        ConsoleHighlighter.restyleInput(area, start);
        area.positionCaret(area.getLength());
    }

    /**
     * Opens another line in the input region (multi-line block input).
     *
     * @param indent the new line's leading spaces
     */
    public void newInputLine(String indent) {
        flushEcho();
        int end = area.getLength();
        String text = "\n" + (indent == null ? "" : indent);
        systemWrite(() -> area.writeStyled(end, end, text, ConsoleHighlighter.OUTPUT_STYLE));
        ConsoleHighlighter.restyleInput(area, inputStart());
        area.positionCaret(area.getLength());
    }

    // -----------------------------------------------------------------
    // Edits that keep the caret, the selection and the input start
    // -----------------------------------------------------------------

    /** Inserts frozen text at or before the input start; everything after it shifts. */
    private void insertFrozen(int at, String raw, Collection<String> style) {
        String text = normalizeLineBreaks(raw);
        if (text.isEmpty()) {
            return;
        }
        // The document's own count, not text.length(): RichTextFX stores a
        // "\r\n" line break as ONE character, so counting the string made the
        // input start drift one character per Windows line ending - the input
        // region then began inside the recalled command, backspace and typing
        // were refused, and the prompt was cut ("unit_m" / ">> ix(5)").
        int before = area.getLength();
        int inputBefore = inputStart();
        int caret = area.getCaretPosition();
        int anchor = area.getAnchor();
        systemWrite(() -> area.writeStyled(at, at, text, style));
        int length = area.getLength() - before;
        if (length <= 0) {
            return;
        }
        ide.inputStart = inputBefore + length;
        restoreSelection(shiftForInsert(anchor, at, length), shiftForInsert(caret, at, length));
    }

    /** Deletes frozen text that ends at or before the input start. */
    private void deleteFrozen(int start, int end) {
        if (end <= start) {
            return;
        }
        int length = end - start;
        int inputBefore = inputStart();
        int caret = area.getCaretPosition();
        int anchor = area.getAnchor();
        systemWrite(() -> area.deleteText(start, end));
        ide.inputStart = Math.max(0, inputBefore - length);
        restoreSelection(shiftForDelete(anchor, start, end), shiftForDelete(caret, start, end));
    }

    /**
     * Windows output ends its lines with "\r\n" (std::endl in text mode) and a
     * pipe read can split that pair between two reads. The console only ever
     * holds "\n": every '\r' is dropped (the interpreter never uses a bare
     * '\r' to redraw a line).
     */
    private static String normalizeLineBreaks(String text) {
        if (text == null || text.isEmpty()) {
            return "";
        }
        return text.indexOf('\r') < 0 ? text : text.replace("\r", "");
    }

    /** Puts the selection back, never past the end of the text. */
    private void restoreSelection(int anchor, int caret) {
        int length = area.getLength();
        area.selectRange(Math.max(0, Math.min(anchor, length)), Math.max(0, Math.min(caret, length)));
    }

    private static int shiftForInsert(int position, int at, int length) {
        return position >= at ? position + length : position;
    }

    private static int shiftForDelete(int position, int start, int end) {
        if (position >= end) {
            return position - (end - start);
        }
        return Math.min(position, start);
    }

    /** True when {@code at} is not at the start of a line. */
    private boolean needsLineBreakBefore(int at) {
        return at > 0 && area.getText(at - 1, at).charAt(0) != '\n';
    }

    // -----------------------------------------------------------------
    // UP/DOWN recall
    // -----------------------------------------------------------------

    /** @param command a submitted command, for UP/DOWN recall */
    public void rememberCommand(String command) {
        if (command == null || command.isBlank()) {
            return;
        }
        if (history.isEmpty() || !history.get(history.size() - 1).equals(command)) {
            history.add(command);
        }
        while (history.size() > HISTORY_LIMIT) {
            history.remove(0);
        }
        historyCursor = history.size();
        draft = "";
    }

    /** Forgets every command held for UP/DOWN recall ("Reset CLI History"). */
    public void clearCommandHistory() {
        history.clear();
        historyCursor = 0;
        draft = "";
    }

    /**
     * Fills UP/DOWN recall with commands from earlier sessions.
     *
     * @param commands earlier commands, oldest first
     */
    public void seedHistory(List<String> commands) {
        if (commands == null || commands.isEmpty()) {
            return;
        }
        List<String> merged = new ArrayList<>();
        for (String command : commands) {
            if (command != null && !command.isBlank()
                    && (merged.isEmpty() || !merged.get(merged.size() - 1).equals(command))) {
                merged.add(command);
            }
        }
        merged.addAll(history);
        history.clear();
        int from = Math.max(0, merged.size() - HISTORY_LIMIT);
        history.addAll(merged.subList(from, merged.size()));
        historyCursor = history.size();
        draft = "";
    }

    private void recallHistory(int direction) {
        if (history.isEmpty()) {
            return;
        }
        if (historyCursor == history.size()) {
            draft = currentInput();
        }
        int next = Math.max(0, Math.min(history.size(), historyCursor + direction));
        historyCursor = next;
        setInput(historyCursor == history.size() ? draft : history.get(historyCursor));
    }

    // -----------------------------------------------------------------
    // Copy
    // -----------------------------------------------------------------

    /** Copies the current selection, wherever it lies. Does nothing when empty. */
    public void copySelection() {
        String selected = area.getSelectedText();
        if (selected != null && !selected.isEmpty()) {
            copyToClipboard(selected);
        }
    }

    /** Copies the whole transcript. */
    public void copyAll() {
        copyAll(area);
    }

    /**
     * Copies a console's whole transcript. Static so the three-dot menu can
     * use it without holding the guard.
     *
     * @param console the console
     */
    public static void copyAll(ConsoleArea console) {
        if (console != null) {
            copyToClipboard(console.getText());
        }
    }

    private static void copyToClipboard(String text) {
        ClipboardContent content = new ClipboardContent();
        content.putString(text == null ? "" : text);
        Clipboard.getSystemClipboard().setContent(content);
    }

    /** True when the caret or the selection anchor sits in the frozen history. */
    private boolean selectionInHistory() {
        int start = inputStart();
        return area.getCaretPosition() < start || area.getAnchor() < start;
    }

    /** Leaves the history: caret to the end of the input, selection cleared. */
    private void returnToInput() {
        area.positionCaret(area.getLength());
    }

    // -----------------------------------------------------------------
    // Edit veto
    // -----------------------------------------------------------------

    private void installContentFilter() {
        // Refuse the whole edit when it reaches into the frozen history, so a
        // spanning paste cannot partially apply. Selection-only changes never
        // come here, so the history can still be selected and copied.
        area.setEditVeto((start, end) -> {
            if (systemWriting) {
                return false;
            }
            if (heldEcho != null) {
                // An edit not made by a key (a paste from the menu) while the
                // echo is held: the input region still holds the command, so
                // the edit is refused and the echo drawn; nothing is lost but
                // that one paste within a fraction of a second.
                Platform.runLater(onKeyWhileEchoHeld);
                return true;
            }
            return start < inputStart();
        });
    }

    private void installPointerClamp() {
        // Nothing: a click or a selection in the history leaves the caret and
        // the view where they are (MATLAB). The first key that would edit
        // takes the caret back to the input (installKeyFilter).
    }

    // -----------------------------------------------------------------
    // Key filter
    // -----------------------------------------------------------------

    private void installKeyFilter() {
        area.addEventFilter(KeyEvent.KEY_PRESSED, event -> {
            KeyCode code = event.getCode();
            // A key while a starting command's echo is held: the echo is
            // drawn first, so the key acts on the new, empty input line.
            if (heldEcho != null && !code.isModifierKey()) {
                onKeyWhileEchoHeld.run();
            }
            int start = inputStart();

            // ── Ctrl+C while a command runs: stop it (busy always means stop) ──
            if (code == KeyCode.C && event.isShortcutDown()
                    && !event.isAltDown() && !event.isShiftDown()
                    && busy.getAsBoolean()) {
                event.consume();
                onInterrupt.run();
                return;
            }

            // ── Selection in the history: copy is allowed, editing is not ──
            if (selectionInHistory()) {
                if (code.isModifierKey()) {
                    return;
                }
                if (event.isShortcutDown() && (code == KeyCode.C || code == KeyCode.INSERT)) {
                    copySelection();
                    event.consume();
                    return;
                }
                if (event.isShortcutDown() && code == KeyCode.X) {
                    copySelection(); // copy, never cut, from the history
                    event.consume();
                    return;
                }
                if (event.isShortcutDown() && code == KeyCode.A) {
                    area.selectRange(0, area.getLength());
                    event.consume();
                    return;
                }
                if (event.isShiftDown() && isNavigation(code)) {
                    return; // extending the selection
                }
                returnToInput();
                if (code == KeyCode.BACK_SPACE || code == KeyCode.DELETE
                        || code == KeyCode.LEFT || code == KeyCode.RIGHT
                        || code == KeyCode.HOME || code == KeyCode.END
                        || code == KeyCode.ESCAPE) {
                    event.consume(); // that key only meant "leave the history"
                    return;
                }
            }

            // Undo/redo would restore text from before the boundary.
            if (event.isShortcutDown() && (code == KeyCode.Z || code == KeyCode.Y)) {
                event.consume();
                return;
            }

            if (event.isShortcutDown() && code == KeyCode.A) {
                area.selectRange(0, area.getLength());
                event.consume();
                return;
            }

            if (code == KeyCode.HOME) {
                if (event.isShiftDown()) {
                    area.selectRange(area.getCaretPosition(), start);
                } else {
                    area.positionCaret(start);
                }
                event.consume();
                return;
            }

            // The input start is the hard stop: no backspace, no left-arrow past it.
            if ((code == KeyCode.BACK_SPACE || code == KeyCode.LEFT)
                    && area.getSelection().getLength() == 0
                    && area.getCaretPosition() <= start) {
                event.consume();
                return;
            }

            if (suppressEnter.getAsBoolean()) {
                return; // the suggestion popup owns ENTER/UP/DOWN/ESC while visible
            }

            // ESC clears what is typed, a half-typed multi-line block included
            // (MATLAB). UP brings it back as the draft.
            if (code == KeyCode.ESCAPE) {
                if (ScriptedCaret.isEditingScript(area)) {
                    return; // Esc leaves the subscript / superscript first (ScriptedCaret)
                }
                if (!currentInput().isEmpty()) {
                    setInput("");
                }
                historyCursor = history.size();
                event.consume();
                return;
            }

            // In a multi-line input UP / DOWN move between its lines; they
            // recall history only from the first / last input line.
            if (code == KeyCode.UP && !event.isShiftDown() && !caretOnFirstInputLine()) {
                return;
            }
            if (code == KeyCode.DOWN && !event.isShiftDown() && !caretOnLastInputLine()) {
                return;
            }
            if (code == KeyCode.UP && !event.isShiftDown()) {
                recallHistory(-1);
                event.consume();
                return;
            }
            if (code == KeyCode.DOWN && !event.isShiftDown()) {
                recallHistory(1);
                event.consume();
                return;
            }

            if (code == KeyCode.ENTER) {
                // Java is the sole author of line breaks in the console.
                event.consume();
                onSubmit.run();
            }
        });

        area.addEventFilter(KeyEvent.KEY_TYPED, event -> {
            String character = event.getCharacter();
            if (character != null && (character.equals("\r") || character.equals("\n"))) {
                event.consume();
                return;
            }
            // Safety net: a printable character never lands in the history.
            if (character != null && !character.isEmpty() && character.charAt(0) >= 0x20
                    && character.charAt(0) != 0x7F && !event.isShortcutDown() && selectionInHistory()) {
                returnToInput();
            }
        });
    }

    private boolean caretOnFirstInputLine() {
        int start = inputStart();
        int caret = Math.max(start, Math.min(area.getCaretPosition(), area.getLength()));
        return area.getText(start, caret).indexOf('\n') < 0;
    }

    private boolean caretOnLastInputLine() {
        int end = area.getLength();
        int start = inputStart();
        int caret = Math.max(start, Math.min(area.getCaretPosition(), end));
        return area.getText(caret, end).indexOf('\n') < 0;
    }

    private static boolean isNavigation(KeyCode code) {
        return code == KeyCode.LEFT || code == KeyCode.RIGHT || code == KeyCode.UP
                || code == KeyCode.DOWN || code == KeyCode.HOME || code == KeyCode.END
                || code == KeyCode.PAGE_UP || code == KeyCode.PAGE_DOWN;
    }
}
