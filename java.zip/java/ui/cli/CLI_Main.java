package ui.cli;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Locale;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import ui.UI_Main;
import ui.ui_functions.Variable;

/**
 * <h2>CLI_Main — the Command Window controller</h2>
 *
 * Single Java owner of the Command Window (region 10). Consolidates everything
 * that used to be scattered across {@code ConsoleController},
 * {@code EditorCommandWindow}, {@code UI_MainProgramControl},
 * {@code EditorManager.startUPITerminal} and {@code TerminalManager}.
 *
 * <h3>Design contract</h3>
 * <ul>
 *   <li><b>C++ owns evaluation.</b> One persistent {@code nc.exe} process is the
 *       live backend; it stays alive for the whole session so the workspace
 *       persists between commands.</li>
 *   <li><b>Java owns only the prompt.</b> CLI_Main manages the editable input
 *       region ({@code inputStart}), forwards each line to stdin, and streams
 *       stdout/stderr back. It never parses/infers variables itself.</li>
 *   <li><b>{@code variables.txt} is the shared reference point.</b> The Explorer
 *       is reloaded from that file whenever the {@code ">> "} prompt returns.</li>
 *   <li><b>Suggestions are shared</b> via {@link CLI_SuggestionBridge}.</li>
 * </ul>
 *
 * <h3>Newline discipline (fixes the "extra blank line" bug)</h3>
 * The console's {@link ConsoleController} consumes the ENTER character on
 * KEY_TYPED so the TextArea never inserts its own newline. Therefore
 * <b>CLI_Main is the sole author of newlines</b>: it appends exactly one
 * {@code "\n"} after the user's submitted line, and the backend's prompt
 * ({@code ">> "}) arrives with no leading newline. One ENTER -> one line
 * advance, never two.
 */
public final class CLI_Main {

    /** The interactive prompt printed by nc.exe (main.cpp). Java never prints it, except locally on cls. */
    static final String PROMPT = ">> ";

    /** Optional override: -Dupi.nc.exe=C:\\path\\to\\nc.exe */
    private static final String NC_EXE_PROPERTY = "upi.nc.exe";

    /** Candidate locations searched (relative to user.dir) when no override is set. */
    private static final String[] NC_EXE_CANDIDATES = {
            "cpp/nc.exe",
            "src/main/cpp/nc.exe",
            "nc.exe"
    };

    private static UI_Main ide;
    private static Process process;
    private static BufferedWriter processWriter;
    private static Thread readerThread;

    /** Directory nc.exe runs in; also where the shared variables.txt lives. */
    private static Path workingDirectory;
    private static Path variablesTxt;

    private static CLI_SuggestionBridge suggestionBridge;

    private CLI_Main() {
    }

    // =====================================================================
    // 1. Console construction (called from Main_Window.setupConsole)
    // =====================================================================

    /**
     * Builds the console {@link javafx.scene.control.TextArea}, installs the
     * prompt/key handling, and attaches the shared suggestion popup.
     *
     * @param ideRef the IDE controller
     */
    public static void initConsole(UI_Main ideRef) {
        ide = ideRef;
        ConsoleController.initialize(ide);
        suggestionBridge = new CLI_SuggestionBridge();
        suggestionBridge.attach(ide);
    }

    // =====================================================================
    // 2. Backend lifecycle (called from UI_Main.buildUI, after the UI exists)
    // =====================================================================

    /**
     * Locates and launches the persistent {@code nc.exe} backend from its own
     * directory (the process working directory), wires stdin, and starts the
     * background reader that streams output into the console.
     *
     * @param ideRef the IDE controller
     */
    public static void start(UI_Main ideRef) {
        ide = ideRef;
        Path exe = resolveNcExe();
        if (exe == null) {
            appendText("UPI backend not found. Set -D" + NC_EXE_PROPERTY
                    + "=<path to nc.exe> or place nc.exe under one of: "
                    + String.join(", ", NC_EXE_CANDIDATES) + "\n");
            appendLocalPrompt();
            return;
        }
        workingDirectory = exe.toAbsolutePath().getParent();
        variablesTxt = workingDirectory.resolve("variables.txt");

        try {
            ProcessBuilder pb = new ProcessBuilder(exe.toAbsolutePath().toString());
            pb.directory(workingDirectory.toFile());
            pb.redirectErrorStream(true); // fold stderr into stdout for one stream
            process = pb.start();

            ide.runningProcess = process;
            ide.programRunning = true;
            processWriter = new BufferedWriter(
                    new OutputStreamWriter(process.getOutputStream(), StandardCharsets.UTF_8));
            ide.processWriter = processWriter;

            startReader();
            startExitWatcher();

            // Tell the backend which folder to resolve script names against.
            Path project = ide.getCurrentFolder();
            if (project != null) {
                setWorkspaceDirectory(project);
            }
        } catch (IOException ex) {
            appendText("Failed to start UPI terminal: " + ex.getMessage() + "\n");
            appendLocalPrompt();
        }
    }

    /**
     * Sends the IDE's current project folder to the backend so that running a
     * script by name resolves correctly.
     *
     * @param folder the project/workspace directory
     */
    public static void setWorkspaceDirectory(Path folder) {
        if (folder == null) {
            return;
        }
        sendRaw("@cmd setpwd \"" + folder.toAbsolutePath() + "\"");
    }

    // =====================================================================
    // 3. Input handling (Java owns ONLY the prompt line)
    // =====================================================================

    /**
     * Called when ENTER is pressed and the suggestion popup is NOT open. Takes
     * the text typed after the prompt boundary and dispatches it.
     *
     * @param ideRef the IDE controller
     */
    public static void handleEnter(UI_Main ideRef) {
        ide = ideRef;
        int end = ide.console.getLength();
        if (ide.inputStart > end) {
            ide.inputStart = end;
        }
        String line = ide.console.getText().substring(ide.inputStart, end)
                .replace(PROMPT, "")
                .strip();

        // ---- exit / quit ----
        if (isExit(line)) {
            ide.console.appendText("\n");
            shutdown();
            if (ide.stage != null) {
                ide.stage.close();
            }
            Platform.exit();
            return;
        }

        // ---- cls: clear the SCREEN only (workspace/variables preserved) ----
        // Purely Java-side: wipe the console text and paint one fresh prompt.
        // No backend round-trip, so nc.exe's variables stay intact — this is the
        // conventional meaning of "cls" and fixes the "cls not working" bug.
        if (isClearScreen(line)) {
            ide.console.clear();
            ide.console.appendText(PROMPT);
            ide.inputStart = ide.console.getLength();
            ide.console.positionCaret(ide.console.getLength());
            return;
        }

        // ---- clear: reset the WORKSPACE (variables) AND the screen ----
        if (isClearWorkspace(line)) {
            ide.console.clear();
            ide.inputStart = 0;
            if (ide.varTable != null) {
                ide.varTable.getItems().clear();
            }
            // Backend resets variables.txt + its live memory, then reprints ">> "
            // which the reader will append (becoming the new prompt).
            if (process != null && ide.programRunning) {
                sendRaw("clear");
            } else {
                ide.console.appendText(PROMPT);
                ide.inputStart = ide.console.getLength();
            }
            return;
        }

        // ---- everything else: advance one line, forward to backend ----
        ide.console.appendText("\n");
        ide.inputStart = ide.console.getLength();

        if (process == null || !ide.programRunning) {
            appendText("UPI terminal is not running.\n");
            appendLocalPrompt();
            return;
        }

        sendRaw(line);
    }

    /**
     * Runs a script on the <b>same persistent backend</b> by sending its name.
     * The editor's Run for a {@code .nc} file should call this instead of
     * spawning a separate process, so the workspace stays shared.
     *
     * @param ideRef     the IDE controller
     * @param scriptName the script's name or path (extension optional)
     */
    public static void runScriptByName(UI_Main ideRef, String scriptName) {
        ide = ideRef;
        if (scriptName == null || scriptName.isBlank()) {
            return;
        }
        if (process == null || !ide.programRunning) {
            appendText("UPI terminal is not running.\n");
            return;
        }
        Platform.runLater(() -> {
            ide.console.appendText(scriptName + "\n");
            ide.inputStart = ide.console.getLength();
            sendRaw(scriptName);
        });
    }

    /** @return true while the shared suggestion popup is visible. */
    public static boolean isSuggestionShowing() {
        return suggestionBridge != null && suggestionBridge.isShowing();
    }

    // =====================================================================
    // 4. Output streaming + Explorer refresh
    // =====================================================================

    private static void startReader() {
        readerThread = new Thread(() -> {
            try (InputStream in = process.getInputStream()) {
                byte[] buffer = new byte[4096];
                int len;
                while ((len = in.read(buffer)) != -1) {
                    String chunk = new String(buffer, 0, len, StandardCharsets.UTF_8);
                    Platform.runLater(() -> onOutput(chunk));
                }
            } catch (IOException ignored) {
                // Stream closed on shutdown — nothing to do.
            }
        }, "cli-nc-reader");
        readerThread.setDaemon(true);
        readerThread.start();
    }

    private static void startExitWatcher() {
        Thread watcher = new Thread(() -> {
            try {
                process.waitFor();
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
            Platform.runLater(() -> {
                ide.programRunning = false;
                ide.runningProcess = null;
                ide.processWriter = null;
            });
        }, "cli-nc-exit-watcher");
        watcher.setDaemon(true);
        watcher.start();
    }

    /** Appends a chunk of backend output and, when the prompt returns, refreshes. */
    private static void onOutput(String text) {
        if (ide == null || ide.console == null || text == null || text.isEmpty()) {
            return;
        }
        ide.console.appendText(text);
        ide.console.positionCaret(ide.console.getLength());

        // The prompt marks the end of a command's output: the backend has
        // finished and variables.txt is fully written, so this is the correct,
        // race-free moment to reload the global workspace into the Explorer.
        if (endsWithPrompt(ide.console.getText())) {
            ide.inputStart = ide.console.getLength();
            reloadWorkspace();
        }
    }

    /**
     * Reloads {@code variables.txt} (the C++-written shared workspace) and
     * replaces the Explorer contents. Only global workspace variables appear.
     */
    public static void reloadWorkspace() {
        if (ide == null || ide.varTable == null || variablesTxt == null) {
            return;
        }
        if (!Files.exists(variablesTxt)) {
            return;
        }
        List<Variable> globals = WorkspaceVariableParser.parse(variablesTxt);
        Platform.runLater(() ->
                ide.varTable.setItems(FXCollections.observableArrayList(globals)));
    }

    // =====================================================================
    // 5. Low-level plumbing
    // =====================================================================

    private static void sendRaw(String line) {
        if (processWriter == null) {
            appendText("Input error: backend not connected.\n");
            return;
        }
        try {
            processWriter.write(line);
            processWriter.newLine();
            processWriter.flush();
            ide.inputStart = ide.console.getLength();
        } catch (IOException ex) {
            appendText("\nInput error: " + ex.getMessage() + "\n");
        }
    }

    /** Cleanly stops the backend (used on Exit / app close). */
    public static void shutdown() {
        try {
            if (processWriter != null) {
                processWriter.write("exit");
                processWriter.newLine();
                processWriter.flush();
            }
        } catch (IOException ignored) {
            // fall through to destroy
        }
        if (process != null && process.isAlive()) {
            process.destroy();
        }
    }

    private static Path resolveNcExe() {
        String override = System.getProperty(NC_EXE_PROPERTY);
        if (override != null && !override.isBlank()) {
            Path p = Path.of(override);
            if (Files.exists(p)) {
                return p;
            }
        }
        Path base = Path.of(System.getProperty("user.dir"));
        for (String candidate : NC_EXE_CANDIDATES) {
            Path p = base.resolve(candidate);
            if (Files.exists(p)) {
                return p;
            }
        }
        return null;
    }

    /** Paints a local prompt (used only when the backend can't provide one). */
    private static void appendLocalPrompt() {
        if (ide == null || ide.console == null) {
            return;
        }
        Platform.runLater(() -> {
            ide.console.appendText(PROMPT);
            ide.inputStart = ide.console.getLength();
            ide.console.positionCaret(ide.console.getLength());
        });
    }

    private static void appendText(String text) {
        if (ide == null || ide.console == null || text == null) {
            return;
        }
        Platform.runLater(() -> {
            ide.console.appendText(text);
            ide.console.positionCaret(ide.console.getLength());
        });
    }

    private static boolean endsWithPrompt(String text) {
        return text != null && text.endsWith(PROMPT);
    }

    private static boolean isExit(String s) {
        String n = norm(s);
        return n.equals("exit") || n.equals("exit()") || n.equals("quit") || n.equals("quit()");
    }

    /** cls = clear screen only (keep workspace). */
    private static boolean isClearScreen(String s) {
        return norm(s).equals("cls");
    }

    /** clear = reset workspace (variables) and screen. */
    private static boolean isClearWorkspace(String s) {
        return norm(s).equals("clear");
    }

    private static String norm(String s) {
        return s == null ? "" : s.trim().toLowerCase(Locale.ROOT);
    }
}
