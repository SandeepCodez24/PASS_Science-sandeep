package ui.cli;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.function.IntConsumer;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import backend.workspace.NcSession;
import backend.workspace.ProtocolLineSplitter;
import backend.workspace.WorkspaceChannel;
import backend.workspace.WorkspaceProtocol;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.PauseTransition;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.beans.property.ReadOnlyBooleanWrapper;
import javafx.util.Duration;
import language.language_ui.handler.NcBlockScanner;
import language.semantic.ComplexLiteral;
import language.syntax.syntax_checker.ErrorClassifier;
import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.functions.BuiltinSignatures;
import ui.ui_functions.FunctionProvider;
import ui.UI_Main;
import ui.design.section_dims.CommandWindow_dim;
import ui.editor.homeTab.StepFileRunner;
import ui.editor.navigation.FolderPaths;
import ui.editor.navigation.NavigationActions;
import ui.editor.navigation.SearchPath;
import ui.ui_functions.Variable;
import ui.ui_functions.WorkspaceStore;

/**
 * <h2>CLI_Main -- the Command Window controller</h2>
 *
 * <h3>One owner for the prompt (the redesign)</h3>
 * <p>
 * The prompt used to have two owners: Java painted line breaks on ENTER and
 * {@code nc.exe} printed {@code >> } as its "done" signal. Every symptom of
 * the old console came from reconciling the two -- missing prompts and blank
 * gaps on fast ENTERs, {@code >> >> } collapses, a reply counter that a
 * script printing {@code ">> "} could break, a settle timer guessing when a
 * block had finished. Now:
 * </p>
 * <ul>
 *   <li><b>Java owns the prompt.</b> {@code nc.exe} is started with
 *       {@value #ENV_IDE_PROMPT}=1 and never prints {@code >> }. The console
 *       paints its own prompt ({@link ConsoleInputGuard#showPrompt}) when a
 *       command is over.</li>
 *   <li><b>The end of a command is exact.</b> After each command's lines
 *       the IDE sends {@code @cmd ready <id>}; the interpreter answers with
 *       the protocol line {@code @READY <id>}, which can only arrive after
 *       everything before it has run. One command is in flight at a time.</li>
 *   <li><b>{@code @PROMPT}</b> -- a protocol line the interpreter sends each
 *       time it is back at the top of its loop -- tells the Step runner and
 *       Stop that it is idle. Protocol lines never reach the screen, so
 *       nothing a script prints can be mistaken for them.</li>
 * </ul>
 * <p>
 * An {@code nc.exe} built before this protocol still works (compatibility
 * mode, with a one-line note): its {@code >> } prompts are taken out of the
 * output and end the running command.
 * </p>
 *
 * <h3>Type-ahead (MATLAB style)</h3>
 * <p>
 * While a command runs there is no prompt; whatever the user types stays in
 * the input region at the bottom, and output is inserted above it. ENTER
 * queues the line; when the running command ends, the next one is echoed as
 * {@code >> line} and run. Run, Step and other IDE sends queue the same way.
 * Stop empties the queue.
 * </p>
 *
 * <h3>Empty ENTER</h3>
 * <p>
 * An empty or comment-only line never reaches the interpreter: the console
 * echoes {@code >> } and paints the next prompt at once, as MATLAB does.
 * </p>
 *
 * <h3>Smooth output</h3>
 * <ul>
 *   <li>Output reaches the FX thread in batches (at most about 30 a second),
 *       in order with the protocol lines, and each batch is written as a few
 *       styled edits -- no colour pass afterwards, no prompt collapse
 *       afterwards.</li>
 *   <li>The view scrolls at most once per batch, and only when the user is
 *       looking at the live end (the caret was on screen) and the caret would
 *       otherwise leave it. While the prompt line is still on screen nothing
 *       scrolls, so a prompt scrolled to the top of the window stays there and
 *       output fills the room under it line by line ({@link ConsoleViewport}).
 *       Reading earlier results is never interrupted by new output.</li>
 * </ul>
 *
 * <h3>Command Window width (new)</h3>
 * <p>
 * The interpreter prints a matrix wider than the window in column groups
 * ({@code Columns 0 through 15}, ...), so it needs to know how many
 * characters fit on a line. {@link CommandWindowWidth} measures it; it is
 * given at launch as {@code NC_DISPLAY_WIDTH}, sent once the interpreter
 * runs as {@code @cmd width n}, and sent again after a resize has settled
 * -- only while no command runs, otherwise just before the next one.
 * </p>
 *
 * <h3>Command semantics (unchanged)</h3>
 * <table>
 *   <tr><td>{@code cls}</td><td>clear the screen only; workspace untouched</td></tr>
 *   <tr><td>{@code clear}</td><td>reset the workspace only; screen untouched</td></tr>
 *   <tr><td>{@code clear A}</td><td>remove one variable; screen untouched</td></tr>
 * </table>
 *
 * <h3>Kept from before</h3>
 * <ul>
 *   <li>The workspace arrives as {@code @WS} JSON lines on the same pipe
 *       ({@link #workspaceChannel()}).</li>
 *   <li>Visual names are encoded on the way in and decoded on the way out
 *       ({@link CliSymbolCodec}); {@code 5i} is written {@code 5j} for the
 *       interpreter and shown back as {@code 5i} ({@link ComplexLiteral}).</li>
 *   <li>Typed script names are checked by the editor's checks before they
 *       are sent; full paths outside the current folder and the path are
 *       refused; {@code addpath}, {@code rmpath}, {@code path} are handled
 *       here.</li>
 *   <li>Step-into ({@code @cmd stepinto}, {@code @STEPAT n},
 *       {@code @cmd stepnext}); nothing else reaches stdin while a block is
 *       paused.</li>
 *   <li>Stop is cooperative first ({@code interrupt.flag}), then kill and
 *       relaunch on the session autosave after {@link #STOP_GRACE}.</li>
 *   <li>A dead interpreter is relaunched on the saved workspace when a
 *       command needs it.</li>
 * </ul>
 */
public final class CLI_Main {

    private static final Logger LOG = Logger.getLogger(CLI_Main.class.getName());

    /** The prompt the console paints. */
    static final String PROMPT = ">> ";

    /** Tells {@code nc.exe} to use the prompt protocol instead of printing {@code >> }. */
    static final String ENV_IDE_PROMPT = "NC_IDE_PROMPT";

    /** Protocol line: the interpreter is back at the top of its loop. */
    private static final String PROMPT_EVENT = "@PROMPT";

    /** Protocol line answering {@link #READY_COMMAND}: {@code @READY <id>}. */
    private static final String READY_EVENT = "@READY";

    /** Sent after every command's lines; answered with {@code @READY <id>}. */
    private static final String READY_COMMAND = "@cmd ready";

    /** Optional override: -Dupi.nc.exe=C:\\path\\to\\nc.exe */
    private static final String NC_EXE_PROPERTY = "upi.nc.exe";

    private static final String[] NC_EXE_CANDIDATES = {
            "cpp/nc.exe",
            "src/main/cpp/nc.exe",
            "nc.exe"
    };

    /** How the running interpreter marks the end of a command. */
    private enum Protocol {
        /** Not known yet (just launched). */
        UNKNOWN,
        /** {@code @PROMPT} / {@code @READY} protocol lines. */
        MODERN,
        /** An older {@code nc.exe}: plain {@code >> } prompts in the output. */
        LEGACY
    }

    /** What a queued command is. */
    private enum Kind {
        /** Typed at the prompt: goes through cls / clear / path / script checks. */
        TYPED,
        /** Lines for the interpreter, already encoded (Run, Step, IDE sends). */
        BACKEND,
        /** A refused run: printed, nothing sent. */
        REPORT
    }

    /**
     * One command waiting to run, or running.
     *
     * @param kind   what it is
     * @param echo   shown as {@code >> echo} when it starts; null shows nothing
     * @param lines  the interpreter lines (BACKEND)
     * @param report the text to print (REPORT)
     */
    private record Pending(Kind kind, String echo, List<String> lines, String report) {
        static Pending typed(String text) {
            return new Pending(Kind.TYPED, text, List.of(), null);
        }

        static Pending backend(String echo, String line) {
            return new Pending(Kind.BACKEND, echo, List.of(line), null);
        }

        static Pending report(String echo, String report) {
            return new Pending(Kind.REPORT, echo, List.of(), report);
        }
    }

    /** A protocol line kept in order with the output around it. */
    private record ControlLine(String line) {
    }

    private static UI_Main ide;
    private static Process process;
    private static BufferedWriter processWriter;
    private static ConsoleInputGuard guard;

    /** Directory nc.exe runs in. */
    private static Path workingDirectory;

    /** The live workspace, as the interpreter reports it. */
    private static final WorkspaceChannel WORKSPACE = new WorkspaceChannel(Platform::runLater);

    /** True once {@link #WORKSPACE} has its sender and listener. */
    private static boolean workspaceWired;

    private static CLI_SuggestionBridge suggestionBridge;

    /** Last directory sent with {@code @cmd setpwd}; avoids resending it. */
    private static Path lastWorkspaceDirectory;

    /** Characters per Command Window line, as told to the interpreter ({@code @cmd width}). */
    private static CommandWindowWidth displayWidth;

    // ---- the command in flight and the queue ----------------------------

    /** True from the moment a command starts until it is over. */
    private static boolean inFlight;

    /** The {@code @READY} id the command in flight waits for; 0 for none. */
    private static long awaitingReady;

    /** Last id handed out. */
    private static long readySeq;

    /** Commands waiting for the one in flight (type-ahead, Run, Step, IDE sends). */
    private static final Deque<Pending> QUEUE = new ArrayDeque<>();

    /** True when the interpreter has said it is at the top of its loop and nothing was sent since. */
    private static boolean backendIdle;

    private static Protocol protocol = Protocol.UNKNOWN;
    private static boolean legacyNoted;

    private static final String LEGACY_NOTE =
            "Note: this nc.exe predates the IDE prompt protocol (" + ENV_IDE_PROMPT
            + "). Rebuild it from the current main.cpp; until then the Command Window runs in compatibility mode.\n";

    // ---- script names and the path -------------------------------------

    /**
     * A line that names a script and nothing else: an identifier, an optional
     * {@code .nc}, an optional {@code ;}.
     */
    private static final Pattern SCRIPT_CALL = Pattern.compile(
            "^([\\p{L}_][\\p{L}\\p{M}\\p{N}_]*)(\\.nc)?\\s*;?$",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CHARACTER_CLASS);

    /** A line that is a full path to a {@code .nc} file, optionally quoted and ending in {@code ;}. */
    private static final Pattern PATH_CALL = Pattern.compile(
            "^[\"']?((?:[A-Za-z]:[\\\\/]|\\\\\\\\|/)[^\"']*?\\.nc)[\"']?\\s*;?$",
            Pattern.CASE_INSENSITIVE);

    /** {@code addpath X}, {@code addpath "X"}, {@code addpath('X')}, and the same for rmpath. */
    private static final Pattern PATH_COMMAND = Pattern.compile(
            "^(addpath|rmpath)(?:\\s+|\\s*\\(\\s*)(.+?)(?:\\s*\\))?\\s*;?$",
            Pattern.CASE_INSENSITIVE);

    /** {@code addpath} or {@code rmpath} with nothing to act on. */
    private static final Pattern PATH_COMMAND_BARE = Pattern.compile(
            "^(addpath|rmpath)\\s*(?:\\(\\s*\\))?\\s*;?$",
            Pattern.CASE_INSENSITIVE);

    /** How a folder is put on the interpreter's path. */
    private static final String ADDPATH_COMMAND = "addpath \"%s\"";

    /** A path removal that is waiting for the running command to finish. */
    private static boolean pathRebuildPending;

    /** Scripts larger than this are not pre-checked; the backend handles them as before. */
    private static final long SCRIPT_CHECK_MAX_BYTES = 8L * 1024 * 1024;

    /** {@code -Dastra.workspace.persist=true} keeps the previous session's variables. */
    private static final String PERSIST_PROPERTY = "astra.workspace.persist";

    // ---- Stop -----------------------------------------------------------

    /** Printed when a running command had to be stopped by killing the interpreter. */
    private static final String STOP_MESSAGE = "Execution stopped by user.\n";

    /** What the interpreter prints after a cooperative stop. */
    private static final String INTERRUPTED_MESSAGE = "Execution interrupted by user.";

    /** How long a cooperative stop may take before the interpreter is killed. */
    private static final Duration STOP_GRACE = Duration.millis(2500);

    /** How often a stop in progress is checked on. */
    private static final Duration STOP_POLL = Duration.millis(100);

    /** Watches a cooperative stop in progress; null when none is. */
    private static Timeline stopWatch;

    /** True once the interpreter has reported the current stop. */
    private static boolean interruptAcknowledged;

    /** Printed when the interpreter dies on its own. */
    private static final String CRASH_MESSAGE =
            "UPI backend stopped unexpectedly. It restarts with your next command.\n";

    /** Upper bound on waiting for a killed interpreter to exit. */
    private static final long KILL_WAIT_MS = 3000;

    /** Bumped on every launch and kill; output from an older process is dropped. Read by the reader thread. */
    private static volatile int generation;

    /** True once the first interpreter of this session has been launched. */
    private static boolean launchedOnce;

    /** True while the app is closing, so the exit watcher stays quiet. */
    private static boolean shuttingDown;

    private static final ReadOnlyBooleanWrapper BUSY = new ReadOnlyBooleanWrapper(false);

    /** {@link #BUSY} once it has lasted {@link #BUSY_SHOW_DELAY}; see {@link #busyShownProperty()}. */
    private static final ReadOnlyBooleanWrapper BUSY_SHOWN = new ReadOnlyBooleanWrapper(false);

    /** How long a command runs before the busy state is shown (MATLAB: no flash for quick commands). */
    private static final Duration BUSY_SHOW_DELAY = Duration.millis(150);

    /** Turns {@link #BUSY_SHOWN} on; null when not counting. */
    private static PauseTransition busyShowTimer;

    /**
     * Longest a started command's echo is held back waiting for its first
     * output ({@link ConsoleInputGuard#holdEcho}). A quick command answers
     * well within it, so its echo and result are drawn in one frame.
     */
    private static final Duration ECHO_HOLD = Duration.millis(150);

    // ---- output ---------------------------------------------------------

    /** Minimum gap between two output drains on the FX thread (about 30 per second). */
    private static final long DRAIN_INTERVAL_MS = 33;

    /** Most output held between two drains; older text is dropped beyond this. */
    private static final int PENDING_CAP = 256 * 1024;

    /** The console transcript is trimmed from the top once it passes this. */
    private static final int CONSOLE_MAX_CHARS = 200_000;

    /** What a trim leaves behind, so trimming happens in batches. */
    private static final int CONSOLE_KEEP_CHARS = 150_000;

    // ---- step-into protocol ---------------------------------------------

    /** The step-into control lines understood by nc.exe. */
    public static final String STEP_INTO_COMMAND = "@cmd stepinto";
    public static final String STEP_NEXT_COMMAND = "@cmd stepnext";

    /** Start of a pause marker; used for a cheap contains() test. */
    private static final String STEPAT_TAG = "@STEPAT ";

    /** One complete pause marker. Group 2 is null when no line break followed yet. */
    private static final Pattern STEPAT_LINE = Pattern.compile("@STEPAT (\\d+)[ \\t]*(\\r?\\n)?");

    /** Any proper prefix of a marker: "@", "@ST", "@STEPAT ", "@STEPAT 1" ... */
    private static final Pattern STEPAT_PREFIX =
            Pattern.compile("@(?:S(?:T(?:E(?:P(?:A(?:T(?: \\d*)?)?)?)?)?)?)?");

    /** Printed when a command arrives while a step block is paused. */
    private static final String STEP_PAUSED_MESSAGE =
            "A step run is paused inside a block. Press Step to continue, or Stop to end it.\n";

    /** Notified with the 1-based statement number of each "@STEPAT n". */
    private static IntConsumer stepAtListener;

    /** Notified every time the interpreter is back at the top of its loop. */
    private static Runnable stepIdleListener;

    /** The start of a pause marker cut off at the end of a read. */
    private static String stepCarry = "";

    // ---- history --------------------------------------------------------

    /** Saved commands loaded into UP/DOWN recall at launch. */
    private static final int HISTORY_RECALL = 200;

    private CLI_Main() {
    }

    // =====================================================================
    // 1. Console construction (called from Main_Window.setupConsole)
    // =====================================================================

    /**
     * Builds the console, installs the freeze, attaches the shared suggestion
     * popup and paints the first prompt.
     *
     * @param ideRef the IDE controller
     */
    public static void initConsole(UI_Main ideRef) {
        ide = ideRef;
        guard = ConsoleController.initialize(ide);
        displayWidth = new CommandWindowWidth(ide.console, CLI_Main::sendDisplayWidthWhenIdle);
        // Live symbol replacement first, so the suggestion bridge sees text
        // that has already been folded into its visual form.
        ConsoleSymbolInput.attach(ide, guard);
        suggestionBridge = new CLI_SuggestionBridge();
        suggestionBridge.attach(ide, guard);
        guard.setSuppressEnter(CLI_Main::isSuggestionShowing);
        guard.setOnSubmit(() -> handleEnter(ide));
        // Ctrl+C: stop while a command runs or a step block is paused, copy otherwise.
        guard.setBusy(CLI_Main::isExecuting);
        guard.setOnInterrupt(() -> stopExecution(ide));
        // A key while a starting command's echo is held: the echo is drawn
        // (and the view kept) before the key acts.
        guard.setOnKeyWhileEchoHeld(() -> withFollow(true, guard::flushEcho));
        // A Command Window session starts with the IDE; UP/DOWN reach back
        // into the saved history of earlier sessions.
        CliHistory.startSession();
        guard.seedHistory(CliHistory.recentCommands(HISTORY_RECALL));
        padConsole();
        // The console owns its prompt: the first one is painted here, at the
        // top left, before the interpreter has even started.
        guard.showPrompt();
    }

    /**
     * Keeps the console's first line clear of the title strip
     * ({@link CommandWindow_dim#CONSOLE_PAD_TOP}). Written into the inline
     * style, which beats every stylesheet, and put back if other code rewrites
     * the inline style.
     */
    private static void padConsole() {
        if (ide == null || ide.console == null) {
            return;
        }
        javafx.scene.layout.Region area = ide.console;
        String padding = "-fx-padding: "
                + CommandWindow_dim.CONSOLE_PAD_TOP + "px "
                + CommandWindow_dim.CONSOLE_PAD_RIGHT + "px "
                + CommandWindow_dim.CONSOLE_PAD_BOTTOM + "px "
                + CommandWindow_dim.CONSOLE_PAD_LEFT + "px;";
        Runnable apply = () -> {
            String style = area.getStyle() == null ? "" : area.getStyle();
            if (!style.contains(padding)) {
                area.setStyle(style.isBlank() ? padding : style.strip() + " " + padding);
            }
        };
        apply.run();
        area.styleProperty().addListener((obs, was, is) -> apply.run());
    }

    // =====================================================================
    // 2. Backend lifecycle
    // =====================================================================

    /**
     * Locates and launches the persistent {@code nc.exe}. Idempotent. Only the
     * first launch of a session starts from an empty workspace.
     *
     * @param ideRef the IDE controller
     */
    public static void start(UI_Main ideRef) {
        ide = ideRef;
        if (isBackendAlive()) {
            return;
        }
        boolean fresh = !launchedOnce && !Boolean.getBoolean(PERSIST_PROPERTY);
        launch(fresh, launchedOnce);
    }

    /**
     * Starts one interpreter. Its startup needs no prompt handling: the
     * console already shows its own prompt.
     *
     * @param freshWorkspace  start with an empty workspace
     * @param restoreSnapshot have the interpreter reload the session autosave first
     * @return true when an interpreter is now running
     */
    private static boolean launch(boolean freshWorkspace, boolean restoreSnapshot) {
        Path exe = resolveNcExe();
        if (exe == null) {
            notice("UPI backend not found. Set -D" + NC_EXE_PROPERTY
                    + "=<path to nc.exe> or place nc.exe under one of: "
                    + String.join(", ", NC_EXE_CANDIDATES) + "\n");
            return false;
        }
        workingDirectory = exe.toAbsolutePath().getParent();
        wireWorkspaceChannel();

        NcSession session = session();
        boolean restore = restoreSnapshot;
        if (freshWorkspace) {
            if (session != null) {
                session.discardAutosave();
            }
            WorkspaceStore.get().clearAll();
        } else if (!launchedOnce && Boolean.getBoolean(PERSIST_PROPERTY) && session != null) {
            restore = session.seedFromLastSession();
        }

        try {
            ProcessBuilder pb = new ProcessBuilder(exe.toAbsolutePath().toString());
            pb.directory(workingDirectory.toFile());
            pb.redirectErrorStream(true);
            pb.environment().put(ENV_IDE_PROMPT, "1");
            int columns = displayWidth == null ? -1 : displayWidth.columns();
            if (columns > 0) {
                pb.environment().put(CommandWindowWidth.ENVIRONMENT, String.valueOf(columns));
            }
            if (session != null) {
                session.configure(pb.environment(), restore);
            }
            Process started = pb.start();
            WORKSPACE.reset();

            generation++;
            int gen = generation;
            process = started;
            launchedOnce = true;
            shuttingDown = false;
            protocol = Protocol.UNKNOWN;
            backendIdle = false;
            stepCarry = "";

            ide.runningProcess = started;
            ide.programRunning = true;
            processWriter = new BufferedWriter(
                    new OutputStreamWriter(started.getOutputStream(), StandardCharsets.UTF_8));
            ide.processWriter = processWriter;

            startReader(started, gen);
            startExitWatcher(started, gen);

            // Start in the current folder -- the folder the File Explorer shows.
            Path folder = NavigationActions.projectFolder(ide);
            if (folder == null) {
                folder = lastWorkspaceDirectory != null ? lastWorkspaceDirectory : ide.getCurrentFolder();
            }
            lastWorkspaceDirectory = null;
            if (folder != null) {
                setWorkspaceDirectory(folder);
            }
            // A new interpreter knows nothing of the session's path.
            for (Path added : SearchPath.folders()) {
                sendRaw(String.format(ADDPATH_COMMAND, added.toAbsolutePath()));
            }
            pathRebuildPending = false;
            // A new interpreter has only the start-up width (if any).
            if (displayWidth != null) {
                displayWidth.forgetSent();
                sendDisplayWidth();
            }
            return true;
        } catch (IOException ex) {
            notice("Failed to start UPI terminal: " + ex.getMessage() + "\n");
            return false;
        }
    }

    /**
     * Makes sure an interpreter is running, relaunching one on the saved
     * workspace if it is not.
     *
     * @return true when an interpreter is running
     */
    private static boolean ensureBackend() {
        if (isBackendAlive()) {
            return true;
        }
        if (ide == null) {
            return false;
        }
        boolean fresh = !launchedOnce && !Boolean.getBoolean(PERSIST_PROPERTY);
        return launch(fresh, launchedOnce);
    }

    /**
     * Public form of {@link #ensureBackend()} for the Step runner. FX thread.
     *
     * @param ideRef the IDE controller
     * @return true when an interpreter is running
     */
    public static boolean ensureRunning(UI_Main ideRef) {
        if (ideRef != null) {
            ide = ideRef;
        }
        return ensureBackend();
    }

    /** @return true while an interpreter process is alive */
    public static boolean isBackendAlive() {
        return process != null && process.isAlive();
    }

    /**
     * Tells the backend which folder to resolve script names against: the
     * current folder. Before the interpreter is running it is only recorded.
     *
     * @param folder the current folder
     */
    public static void setWorkspaceDirectory(Path folder) {
        if (folder == null) {
            return;
        }
        Path absolute = folder.toAbsolutePath();
        if (absolute.equals(lastWorkspaceDirectory)) {
            return;
        }
        lastWorkspaceDirectory = absolute;
        if (!isBackendAlive() || processWriter == null) {
            return; // launch() sends it
        }
        sendRaw("@cmd setpwd \"" + absolute + "\"");
    }

    /**
     * Writes {@code @cmd width n} when the width has changed since the
     * interpreter last heard it. Call only where a line may be written: at
     * launch, or just before a command's own lines.
     */
    private static void sendDisplayWidth() {
        // An nc.exe in compatibility mode predates '@cmd width' as well.
        if (displayWidth != null && isBackendAlive() && processWriter != null && protocol != Protocol.LEGACY) {
            displayWidth.sendIfChanged(columns -> sendRaw(CommandWindowWidth.command(columns)));
        }
    }

    /**
     * After a resize: sends the new width now if nothing runs. While a
     * command runs or a step block is paused the line could be read as the
     * script's input, so it waits for the next command instead.
     */
    private static void sendDisplayWidthWhenIdle() {
        if (!isExecuting()) {
            sendDisplayWidth();
        }
    }

    /**
     * Puts a folder on the interpreter's path. A no-op while no interpreter
     * runs: every launch sends the whole path.
     *
     * @param folder the folder, already added to {@link SearchPath}
     */
    public static void addSearchPath(Path folder) {
        if (folder == null) {
            return;
        }
        onFx(() -> {
            if (isBackendAlive() && processWriter != null) {
                sendRaw(String.format(ADDPATH_COMMAND, folder.toAbsolutePath()));
            }
        });
    }

    /**
     * Brings the interpreter's path back into line with {@link SearchPath}
     * after a folder was removed: {@code nc.exe} has no {@code rmpath} the IDE
     * can rely on, so the interpreter is restarted quietly on the same
     * workspace. Waits while a command runs or a step block is paused.
     */
    public static void rebuildSearchPath() {
        onFx(() -> {
            if (!isBackendAlive() || guard == null) {
                return;
            }
            if (isExecuting()) {
                pathRebuildPending = true;
                return;
            }
            restartQuietly();
        });
    }

    /** Runs a path rebuild that was waiting for a command or a step block to finish. */
    private static void runPendingRebuild() {
        if (pathRebuildPending && !isExecuting()) {
            pathRebuildPending = false;
            Platform.runLater(() -> {
                if (!isExecuting()) {
                    restartQuietly();
                } else {
                    pathRebuildPending = true;
                }
            });
        }
    }

    // =====================================================================
    // 2b. Step-into protocol (used by StepFileRunner)
    // =====================================================================

    /** @param listener callback receiving the 1-based statement number of "@STEPAT n", or null */
    public static void setStepAtListener(IntConsumer listener) {
        stepAtListener = listener;
    }

    /** @param listener callback run when the interpreter is back at the top of its loop, or null */
    public static void setStepIdleListener(Runnable listener) {
        stepIdleListener = listener;
    }

    /**
     * Sends one step-into control line ({@link #STEP_INTO_COMMAND} or
     * {@link #STEP_NEXT_COMMAND}). Neither is a command of its own.
     *
     * @param ideRef the IDE controller
     * @param line   the control line
     */
    public static void sendStepControl(UI_Main ideRef, String line) {
        if (ideRef != null) {
            ide = ideRef;
        }
        if (line == null) {
            return;
        }
        onFx(() -> {
            if (isBackendAlive()) {
                sendRaw(line);
            }
        });
    }

    /**
     * Sends one source line of a step unit, encoded like a typed line.
     *
     * <p>A line of a block being stepped into goes straight to the
     * interpreter -- the block's lines must follow {@code @cmd stepinto}
     * without anything in between -- and the prompt stays away until the
     * block is over ({@link #stepBlockFinished}). A simple statement is an
     * ordinary command: it waits behind a running one and ends with its
     * {@code @READY}.
     *
     * @param ideRef the IDE controller
     * @param line   the physical source line
     */
    public static void sendStepLine(UI_Main ideRef, String line) {
        if (ideRef != null) {
            ide = ideRef;
        }
        if (line == null) {
            return;
        }
        onFx(() -> {
            if (guard == null) {
                return;
            }
            if (StepFileRunner.isBlockInProgress()) {
                if (!ensureBackend()) {
                    printNotice("UPI terminal is not running.");
                    return;
                }
                withFollow(true, guard::hidePrompt); // a step is a new run: show it
                sendRaw(encodeKeepingIndent(line));
                return;
            }
            enqueue(Pending.backend(null, encodeKeepingIndent(line)));
        });
    }

    /**
     * Called by the Step runner when a block it stepped into is over: the
     * prompt comes back, or the next queued command runs.
     */
    public static void stepBlockFinished() {
        onFx(() -> {
            if (guard != null && !inFlight && !StepFileRunner.isBlockInProgress()) {
                withFollow(() -> {
                    Pending next = QUEUE.pollFirst();
                    if (next != null) {
                        run(next);
                    } else {
                        guard.showPrompt();
                    }
                });
            }
            runPendingRebuild();
        });
    }

    /** @return true when the interpreter is idle at the top of its loop and no command is running */
    public static boolean isAtPrompt() {
        return guard != null && isBackendAlive() && backendIdle && !inFlight;
    }

    private static String encodeKeepingIndent(String line) {
        int i = 0;
        while (i < line.length() && (line.charAt(i) == ' ' || line.charAt(i) == '\t')) {
            i++;
        }
        return line.substring(0, i) + encodeLine(line.substring(i));
    }

    /** Visual names to cleaned ones, then {@code 5i} to {@code 5j}. Never throws. */
    private static String encodeLine(String line) {
        String encoded;
        try {
            encoded = CliSymbolCodec.encodeLine(line);
        } catch (RuntimeException e) {
            encoded = line;
        }
        try {
            return ComplexLiteral.toBackend(encoded == null ? line : encoded);
        } catch (RuntimeException e) {
            return encoded == null ? line : encoded;
        }
    }

    // =====================================================================
    // 3. Input handling
    // =====================================================================

    /**
     * ENTER in the input region (the suggestion popup is not open). Either
     * opens another line of a multi-line input, or submits it.
     *
     * @param ideRef the IDE controller
     */
    public static void handleEnter(UI_Main ideRef) {
        if (ideRef != null) {
            ide = ideRef;
        }
        if (guard == null || ide == null || ide.console == null) {
            return;
        }
        // ENTER is the user's own action: the current line is brought into
        // view whatever was on screen (a submitted command also jumps to the
        // end through run()).
        withFollow(true, () -> {
            String raw = guard.currentInput();

            // An open block, or a line ending in '~~': ENTER opens the next
            // input line, indented like the editor would.
            CliBlockInput.Analysis block = CliBlockInput.analyze(raw);
            if (block.fixedInput() != null) {
                guard.setInput(block.fixedInput()); // closer / else moved under its opener
                raw = block.fixedInput();
            }
            if (!block.complete()) {
                guard.newInputLine(block.nextIndent());
                return;
            }
            submit(raw); // takes the input out of the input region
        });
    }

    /**
     * A complete input, still in the input region: runs it now, or queues it
     * behind the running command.
     *
     * <p>
     * A command that runs now stays in the input region, as typed, until its
     * echo is drawn together with its first output ({@link #run}); every
     * other input leaves the input region at once.
     * </p>
     *
     * @param raw the input as typed (after the prompt)
     */
    private static void submit(String raw) {
        String text = raw == null ? "" : raw.stripTrailing();
        String line = text.strip();
        boolean multiLine = text.indexOf('\n') >= 0;
        boolean exit = !multiLine && isExit(line);
        boolean runsNow = !exit && !StepFileRunner.isBlockInProgress() && !inFlight && QUEUE.isEmpty();
        if (!runsNow) {
            guard.takeInput();
        }

        if (exit) {
            guard.echoCommand(text);
            shutdown();
            if (ide.stage != null) {
                ide.stage.close();
            }
            Platform.exit();
            return;
        }

        if (!line.isEmpty()) {
            guard.rememberCommand(text);
            CliHistory.record(text);
        }

        // A paused step block owns stdin: nothing typed may be sent. cls
        // only touches the screen, so it still works.
        if (StepFileRunner.isBlockInProgress()) {
            if (!multiLine && isClearScreen(line)) {
                guard.clearScreen();
                return;
            }
            guard.echoCommand(text);
            if (!line.isEmpty()) {
                guard.writeNotice(STEP_PAUSED_MESSAGE);
            }
            return;
        }

        Pending pending = Pending.typed(text);
        if (runsNow) {
            run(pending, true);
        } else {
            QUEUE.addLast(pending); // MATLAB type-ahead: runs when the current command ends
        }
    }

    /**
     * Queues a command from another part of the IDE, or runs it now when
     * nothing is running. Refused (with a note) while a step block is paused.
     */
    private static void enqueue(Pending pending) {
        if (guard == null || ide == null || ide.console == null) {
            return;
        }
        withFollow(() -> {
            if (pending.kind() != Kind.REPORT && StepFileRunner.isBlockInProgress()) {
                guard.writeNotice(STEP_PAUSED_MESSAGE);
                return;
            }
            if (inFlight || !QUEUE.isEmpty()) {
                QUEUE.addLast(pending);
            } else {
                run(pending);
            }
        });
    }

    /** Starts one command that is not in the input region (queued, or sent by the IDE). */
    private static void run(Pending pending) {
        run(pending, false);
    }

    /**
     * Starts one command: echo, then local handling or the interpreter.
     *
     * <p>
     * The echo is held back ({@link ConsoleInputGuard#holdEcho}) and drawn by
     * the command's first write: a quick command's echo and result appear in
     * the same frame, as in MATLAB. A command handled here writes at once; a
     * command sent to the interpreter has its echo drawn by its first output,
     * by its end, or after {@link #ECHO_HOLD} -- whichever comes first.
     * </p>
     *
     * @param pending  the command
     * @param inputHeld true when the command is still in the input region
     */
    private static void run(Pending pending, boolean inputHeld) {
        // A new command - typed, Run, a script, a section: from now on the
        // console has its room (MATLAB's scroll bar activates), and the view
        // goes to the end so the new results are seen.
        ConsoleViewport viewport = ide.console == null ? null : ide.console.getViewport();
        if (viewport != null) {
            viewport.activateRoom();
        }
        jumpToEnd = true;
        inFlight = true;
        awaitingReady = 0;
        setBusy(true);
        String echo = pending.echo();
        guard.holdEcho(inputHeld, echo != null ? () -> guard.echoCommand(echo) : guard::hidePrompt);
        try {
            switch (pending.kind()) {
                case TYPED -> runTyped(pending.echo());
                case REPORT -> {
                    guard.writeOutput(pending.report());
                    finishCommand();
                }
                case BACKEND -> {
                    if (!ensureBackend()) {
                        notRunning();
                    } else {
                        sendCommandLines(pending.lines());
                    }
                }
            }
        } catch (RuntimeException e) {
            LOG.log(Level.WARNING, "Command failed to start", e);
            if (inFlight && awaitingReady == 0) {
                finishCommand();
            }
        }
        if (guard.isEchoHeld()) {
            startEchoHold();
        }
    }

    /** Draws a held echo after {@link #ECHO_HOLD}; null when no hold is timed. */
    private static PauseTransition echoHold;

    /**
     * The command went to the interpreter and has printed nothing yet: its
     * echo is drawn after {@link #ECHO_HOLD} if no output comes first, so a
     * long command shows {@code >> command} with the input line under it.
     */
    private static void startEchoHold() {
        if (echoHold != null) {
            echoHold.stop();
        }
        echoHold = new PauseTransition(ECHO_HOLD);
        echoHold.setOnFinished(e -> {
            if (guard != null && guard.isEchoHeld()) {
                withFollow(true, guard::flushEcho);
            }
        });
        echoHold.play();
    }

    /** A typed command, its echo drawn or held. */
    private static void runTyped(String text) {
        String line = text == null ? "" : text.strip();

        // ---- a block or a '~~' split: the statements, sent together ----
        if (text != null && text.indexOf('\n') >= 0) {
            List<String> lines = CliBlockInput.backendLines(text);
            if (lines.isEmpty()) {
                finishCommand();
                return;
            }
            if (!ensureBackend()) {
                notRunning();
                return;
            }
            List<String> encoded = new ArrayList<>(lines.size());
            for (String l : lines) {
                encoded.add(encodeKeepingIndent(l));
            }
            sendCommandLines(encoded);
            return;
        }

        // ---- nothing to run: the next prompt comes at once (no backend trip) ----
        if (line.isEmpty() || isCommentOnly(line)) {
            finishCommand();
            return;
        }

        // ---- cls: screen only ----
        if (isClearScreen(line)) {
            guard.clearScreen();
            finishCommand();
            return;
        }

        // ---- clear / clear <name>: workspace only ----
        String target = clearTarget(line);
        if (target != null) {
            if (target.isEmpty()) {
                clearAll();
            } else {
                clearOne(target);
            }
            return;
        }

        // ---- help <name>: a function's usage, from the usage table ----
        String help = helpText(line);
        if (help != null) {
            guard.writeOutput(help);
            finishCommand();
            return;
        }

        // ---- addpath / rmpath / path: the session path lives in Java ----
        if (handlePathCommand(line)) {
            finishCommand();
            return;
        }

        // ---- a full path to a .nc file outside the current folder ----
        String outside = outsidePathReport(line);
        if (outside != null) {
            guard.writeOutput(outside);
            finishCommand();
            return;
        }

        // ---- a script name: refused here if the editor's checks fail ----
        String blocked = blockedScriptReport(line);
        if (blocked != null) {
            guard.writeOutput(blocked);
            finishCommand();
            return;
        }

        if (!ensureBackend()) {
            notRunning();
            return;
        }
        // The screen keeps the visual line; the interpreter gets the cleaned one.
        recordTypedScript(line);
        sendCommandLines(List.of(encodeLine(line)));
    }

    /**
     * Sends a command's lines and the {@code @cmd ready} that marks its end.
     *
     * @param lines the interpreter lines
     */
    private static void sendCommandLines(List<String> lines) {
        // A Stop request belongs to the command it was meant for.
        NcSession session = NcSession.current();
        if (session != null && stopWatch == null) {
            session.interrupt().clear();
        }
        long id = ++readySeq;
        awaitingReady = id;
        // A resize made while the last command ran: the new width goes first,
        // so this command already prints with it.
        sendDisplayWidth();
        for (String line : lines) {
            if (!sendRaw(line)) {
                finishCommand();
                return;
            }
        }
        if (protocol != Protocol.LEGACY && !sendRaw(READY_COMMAND + " " + id)) {
            finishCommand();
        }
    }

    /**
     * The command in flight is over. The next queued command starts, or the
     * prompt comes back. While a step block is in progress neither happens:
     * {@link #stepBlockFinished} does it when the block ends.
     */
    private static void finishCommand() {
        inFlight = false;
        awaitingReady = 0;
        if (StepFileRunner.isBlockInProgress()) {
            setBusy(false);
            return;
        }
        Pending next = QUEUE.pollFirst();
        if (next != null) {
            run(next);
            return;
        }
        setBusy(false);
        guard.showPrompt();
        runPendingRebuild();
    }

    private static void notRunning() {
        guard.writeOutput("UPI terminal is not running.\n");
        finishCommand();
    }

    // =====================================================================
    // 3b. Command Window menu: New Window, CLI History
    // =====================================================================

    /**
     * The three-dot menu's <b>New Window</b>: the screen is cleared and a new
     * history session starts. The interpreter and the workspace are kept.
     * Refused while a command runs.
     *
     * @param ideRef the IDE controller
     */
    public static void newWindow(UI_Main ideRef) {
        if (ideRef != null) {
            ide = ideRef;
        }
        onFx(() -> {
            if (guard == null || ide == null || ide.console == null) {
                return;
            }
            if (isExecuting()) {
                printNotice("Stop the running command before opening a new Command Window.");
                return;
            }
            guard.clearScreen();
            CliHistory.startSession();
            guard.showPrompt();
            ide.console.requestFocus();
        });
    }

    /**
     * Opens the CLI History window.
     *
     * @param ideRef the IDE controller
     */
    public static void showHistory(UI_Main ideRef) {
        if (ideRef != null) {
            ide = ideRef;
        }
        CliHistoryWindow.show(ide);
    }

    /**
     * Deletes the saved history and empties UP/DOWN recall. The caller has
     * already asked the user to confirm.
     *
     * @return true when the saved history is gone
     */
    public static boolean resetHistory() {
        if (guard != null) {
            guard.clearCommandHistory();
        }
        return CliHistory.reset();
    }

    /**
     * Puts a command in the input region, replacing what was typed, without
     * running it (CLI History: double-click, Paste to Prompt).
     *
     * @param ideRef  the IDE controller
     * @param command the command; a block keeps its lines
     */
    public static void pasteToPrompt(UI_Main ideRef, String command) {
        if (ideRef != null) {
            ide = ideRef;
        }
        if (guard == null || ide == null || command == null) {
            return;
        }
        guard.setInput(command);
        ide.console.requestFocus();
    }

    /**
     * Puts a command in the input region and submits it, as if typed (CLI
     * History: Run). Queued behind a running command.
     *
     * @param ideRef  the IDE controller
     * @param command the command
     */
    public static void runFromHistory(UI_Main ideRef, String command) {
        if (ideRef != null) {
            ide = ideRef;
        }
        if (guard == null || ide == null || command == null) {
            return;
        }
        guard.setInput(command);
        handleEnter(ide);
        ide.console.requestFocus();
    }

    /**
     * Puts the current folder at the top of the breadcrumb's run-folder
     * history when the line about to be sent runs a script. Bookkeeping only.
     *
     * @param typed the line as typed
     */
    private static void recordTypedScript(String typed) {
        try {
            if (typed == null) {
                return;
            }
            String line = typed.strip();
            Path script = null;
            Matcher call = SCRIPT_CALL.matcher(line);
            if (call.matches()) {
                boolean explicitExtension = call.group(2) != null;
                if (!explicitExtension && isWorkspaceVariable(call.group(1))) {
                    return;
                }
                script = findScript(call.group(1) + ".nc");
            } else {
                Matcher path = PATH_CALL.matcher(line);
                if (path.matches()) {
                    Path file = Path.of(path.group(1));
                    script = Files.isRegularFile(file) ? file : null;
                }
            }
            if (script != null) {
                NavigationActions.recordRecentFolder(ide, script.toAbsolutePath().getParent());
            }
        } catch (RuntimeException ignored) {
            // History is a convenience; a failure here must not reach the user.
        }
    }

    /**
     * Runs a script on the shared backend: the console echoes
     * {@code >> displayName}; the interpreter runs {@code fileToRun} (the
     * cleaned file). Queued behind a running command.
     *
     * @param ideRef      the IDE controller
     * @param displayName what to echo at the prompt, e.g. {@code ssss.nc}
     * @param fileToRun   the cleaned file actually handed to the interpreter
     */
    public static void runScript(UI_Main ideRef, String displayName, Path fileToRun) {
        if (ideRef != null) {
            ide = ideRef;
        }
        if (fileToRun == null) {
            return;
        }
        String echo = displayName == null ? fileToRun.getFileName().toString() : displayName;
        String line = "\"" + fileToRun.toAbsolutePath() + "\"";
        onFx(() -> enqueue(Pending.backend(echo, line)));
    }

    /**
     * Kept so existing callers compile. Prefer
     * {@link #runScript(UI_Main, String, Path)}, which runs the cleaned file.
     *
     * @param ideRef     the IDE controller
     * @param scriptName the script's name or path
     */
    public static void runScriptByName(UI_Main ideRef, String scriptName) {
        if (ideRef != null) {
            ide = ideRef;
        }
        if (scriptName == null || scriptName.isBlank()) {
            return;
        }
        String blocked = blockedScriptReport(scriptName);
        if (blocked != null) {
            reportBlockedRun(ideRef, scriptName, blocked);
            return;
        }
        onFx(() -> enqueue(Pending.backend(scriptName, scriptName)));
    }

    /**
     * Prints a refused run: the script name echoed at the prompt, as a real run
     * would show it, then the report, then a fresh prompt. Queued behind a
     * running command.
     *
     * @param ideRef      the IDE controller
     * @param displayName the name to echo, e.g. {@code t9_isolate3.nc}
     * @param report      the lines to print, each ending in a newline
     */
    public static void reportBlockedRun(UI_Main ideRef, String displayName, String report) {
        if (ideRef != null) {
            ide = ideRef;
        }
        String echo = displayName == null || displayName.isBlank() ? null : displayName;
        String text = report == null || report.isEmpty() ? "Run aborted.\n" : report;
        onFx(() -> enqueue(Pending.report(echo, text)));
    }

    /**
     * Decides whether a command is a script call that must be refused: a bare
     * script name whose {@code .nc} file is found and fails the editor's
     * checks. Null -- "forward as usual" -- in every case it cannot decide.
     *
     * @param typed the command as the user typed it
     * @return the report, or null to let the command through
     */
    static String blockedScriptReport(String typed) {
        try {
            if (typed == null) {
                return null;
            }
            Matcher call = SCRIPT_CALL.matcher(typed.strip());
            if (!call.matches()) {
                return null;
            }
            String base = call.group(1);
            boolean explicitExtension = call.group(2) != null;

            // `A` may mean the variable A rather than A.nc; let the backend decide.
            if (!explicitExtension && isWorkspaceVariable(base)) {
                return null;
            }

            Path script = findScript(base + ".nc");
            if (script == null) {
                return explicitExtension
                        ? "'" + base + ".nc' was not found in the current folder or on the path.\n"
                        : null;
            }
            if (Files.size(script) > SCRIPT_CHECK_MAX_BYTES) {
                return null;
            }

            String text = Files.readString(script, StandardCharsets.UTF_8);
            ErrorClassifier.Classification found = ErrorClassifier.classify(text, CheckContext.forFile(script));
            if (!found.hasErrors()) {
                return null;
            }
            return ErrorClassifier.consoleReport(found, script.getFileName().toString(), "Run");
        } catch (IOException | RuntimeException e) {
            return null;
        }
    }

    /** The current folder first, then each added folder. */
    private static Path findScript(String fileName) {
        List<Path> folders = new ArrayList<>();
        Path current = lastWorkspaceDirectory != null ? lastWorkspaceDirectory : workingDirectory;
        if (current != null) {
            folders.add(current);
        }
        folders.addAll(SearchPath.folders());
        for (Path folder : folders) {
            Path candidate = folder.resolve(fileName);
            if (Files.isRegularFile(candidate)) {
                return candidate;
            }
        }
        return null;
    }

    /**
     * Refuses a typed full path to a {@code .nc} file whose folder is neither
     * the current folder nor on the path.
     *
     * @param typed the line as typed
     * @return the message to print, or null to let the line through
     */
    static String outsidePathReport(String typed) {
        try {
            if (typed == null) {
                return null;
            }
            Matcher m = PATH_CALL.matcher(typed.strip());
            if (!m.matches()) {
                return null;
            }
            Path file = Path.of(m.group(1));
            Path folder = file.toAbsolutePath().getParent();
            if (folder == null) {
                return null;
            }
            Path current = lastWorkspaceDirectory;
            if (current != null && FolderPaths.same(folder, current)) {
                return null;
            }
            if (SearchPath.contains(folder)) {
                return null;
            }
            return "'" + file + "' is not in the current folder or on the path.\n"
                    + "Change the current folder to " + folder + ", or add it with: addpath \"" + folder + "\"\n";
        } catch (RuntimeException e) {
            return null;
        }
    }

    /**
     * Handles {@code addpath}, {@code rmpath} and {@code path} typed at the
     * prompt. Messages go through {@code NavigationActions.say}, which writes
     * them as notes; the caller ends the command.
     *
     * @param line the line as typed
     * @return true if the line was one of them and has been answered
     */
    private static boolean handlePathCommand(String line) {
        String trimmed = line == null ? "" : line.strip();
        String lower = trimmed.toLowerCase(Locale.ROOT);

        if ((lower.equals("path") || lower.equals("path;")) && !isWorkspaceVariable("path")) {
            guard.writeOutput(describePath());
            return true;
        }

        if (PATH_COMMAND_BARE.matcher(trimmed).matches()) {
            guard.writeOutput("Usage: " + lower.replaceAll("[^a-z].*$", "") + " \"<folder>\"\n");
            return true;
        }

        Matcher m = PATH_COMMAND.matcher(trimmed);
        if (!m.matches()) {
            return false;
        }
        boolean add = m.group(1).equalsIgnoreCase("addpath");
        String argument = unquote(m.group(2));
        Path base = NavigationActions.projectFolder(ide);
        Path folder = FolderPaths.parseTyped(argument, base != null ? base : lastWorkspaceDirectory);
        if (folder == null || (add && !FolderPaths.isFolder(folder))) {
            guard.writeOutput((add ? "addpath" : "rmpath") + ": folder not found: " + argument + "\n");
            return true;
        }
        if (add) {
            NavigationActions.addToPath(ide, folder);
        } else {
            NavigationActions.removeFromPath(ide, folder);
        }
        return true;
    }

    /** {@code help} or {@code help <name>} (a trailing ';' allowed). */
    private static final Pattern HELP_COMMAND =
            Pattern.compile("(?i)help(?:\\s+([\\p{L}_][\\p{L}\\p{N}_]*))?\\s*;?");

    /**
     * The answer to {@code help <name>}: the usage line and what the function
     * does - the same text as its suggestion row. Answered here, never sent
     * to nc.exe (which has no help command).
     *
     * <pre>
     *   &gt;&gt; help allclose
     *   allclose(A, B, atol=0.1, rtol=0)
     *       true if every element pair is close: |A-B| &lt;= atol + rtol*|B| ...
     *       NumPy: np.allclose
     * </pre>
     *
     * @return the text to show, or null when the line is not a help command
     *         (a variable named {@code help} is shown as itself)
     */
    private static String helpText(String line) {
        Matcher m = HELP_COMMAND.matcher(line == null ? "" : line.strip());
        if (!m.matches()) {
            return null;
        }
        String name = m.group(1);
        if (name == null) {
            return isWorkspaceVariable("help") ? null
                    : "Usage: help <function>   e.g. help allclose\n";
        }
        BuiltinSignatures.Signature sig = BuiltinSignatures.find(name);
        if (sig != null) {
            return sig.usage() + "\n    " + sig.description()
                    + (sig.numpy().isEmpty() ? "" : "\n    NumPy: " + sig.numpy())
                    + (sig.acceptsNames() ? "" : "\n    Its values cannot be named - give them in order.")
                    + "\n";
        }
        if (BuiltinSignatures.isFamilyName(name)) {
            return name.startsWith("exp")
                    ? name + "(x)\n    N^x for every element, N = " + name.substring(3) + "\n"
                    : name + "(A, B)\n    log base N of N^A + N^B, N = " + name.substring(9) + "\n";
        }
        for (String key : FunctionProvider.getAllFunctions()) {
            if (name.equals(FunctionProvider.extractFunctionName(key))) {
                return key + "\n    " + FunctionProvider.getFunctionDescription(key) + "\n";
            }
        }
        return "help: no built-in function named '" + name + "'\n";
    }

    /** The answer to {@code path}: the current folder, then the added folders. */
    private static String describePath() {
        StringBuilder out = new StringBuilder();
        Path current = NavigationActions.projectFolder(ide);
        out.append("Current folder:\n    ")
                .append(current != null ? current : "(none)").append('\n');
        List<Path> added = SearchPath.folders();
        out.append("Added to path (this session):\n");
        if (added.isEmpty()) {
            out.append("    (none)\n");
        } else {
            for (Path folder : added) {
                out.append("    ").append(folder).append('\n');
            }
        }
        return out.toString();
    }

    private static String unquote(String text) {
        String value = text == null ? "" : text.strip();
        while (value.length() >= 2
                && ((value.startsWith("\"") && value.endsWith("\""))
                        || (value.startsWith("'") && value.endsWith("'")))) {
            value = value.substring(1, value.length() - 1).strip();
        }
        return value;
    }

    /** @return true when the workspace holds a variable typed as {@code visualName} */
    private static boolean isWorkspaceVariable(String visualName) {
        try {
            String cleaned = CliSymbolCodec.encodeName(visualName);
            return cleaned != null && !cleaned.isBlank() && WorkspaceStore.get().contains(cleaned);
        } catch (RuntimeException e) {
            return false;
        }
    }

    /** @return true while the shared suggestion popup is visible. */
    public static boolean isSuggestionShowing() {
        return suggestionBridge != null && suggestionBridge.isShowing();
    }

    // =====================================================================
    // 4. clear / clear <name>
    // =====================================================================

    /** Resets the whole workspace; the screen is left alone. */
    private static void clearAll() {
        WorkspaceStore.get().clearAll();
        if (ensureBackend()) {
            sendCommandLines(List.of("clear"));
        } else {
            NcSession session = NcSession.current();
            if (session != null) {
                session.discardAutosave();
            }
            finishCommand();
        }
    }

    /**
     * Removes one variable with {@code @cmd clearvar}.
     *
     * @param visualName the name the user typed, in editor form
     */
    private static void clearOne(String visualName) {
        String cleaned = CliSymbolCodec.encodeName(visualName);
        if (cleaned == null || cleaned.isBlank()) {
            guard.writeOutput("clear: no variable name given.\n");
            finishCommand();
            return;
        }
        if (!WorkspaceStore.get().contains(cleaned)) {
            guard.writeOutput("clear: '" + visualName + "' is not in the workspace.\n");
            finishCommand();
            return;
        }
        WorkspaceStore.get().remove(cleaned);
        if (ensureBackend()) {
            sendCommandLines(List.of(WorkspaceProtocol.clearVariableCommand(cleaned)));
        } else {
            finishCommand();
        }
    }

    // =====================================================================
    // 4b. Stop and busy state
    // =====================================================================

    /**
     * Stops whatever is running and returns the Command Window to a working
     * prompt. The single entry point for Ctrl+C, the ribbon Stop, F6 and the
     * three-dot menu's Stop. Queued type-ahead is dropped.
     *
     * @param ideRef the IDE controller
     */
    public static void stopExecution(UI_Main ideRef) {
        if (ideRef != null) {
            ide = ideRef;
        }
        if (ide == null) {
            return;
        }
        onFx(() -> {
            // A step-into pause leaves the interpreter blocked on stdin even
            // with no command in flight, so it counts as running. Read before
            // reset() clears it.
            boolean paused = StepFileRunner.isBlockInProgress();
            StepFileRunner.reset(ide);
            if (guard == null) {
                return;
            }
            int cancelled = QUEUE.size();
            QUEUE.clear();
            if (cancelled > 0) {
                withFollow(() -> guard.writeNotice(cancelledNote(cancelled)));
            }
            if (!isBackendAlive()) {
                restartBackend(null);
                return;
            }
            if (!inFlight && !paused) {
                withFollow(guard::showPrompt); // nothing is running
                return;
            }
            requestCooperativeStop(paused);
        });
    }

    /**
     * Asks the running command to stop and watches for the interpreter to come
     * back. If it has not come back after {@link #STOP_GRACE}, it is killed
     * and restarted on the session autosave.
     *
     * @param paused true when a step block is paused inside the interpreter
     */
    private static void requestCooperativeStop(boolean paused) {
        NcSession session = NcSession.current();
        if (session == null) {
            restartBackend(STOP_MESSAGE);
            return;
        }
        if (stopWatch != null) {
            return; // a stop is already in progress
        }
        interruptAcknowledged = false;
        session.interrupt().request();
        if (paused) {
            // The paused interpreter is waiting on stdin; let it go on, so it
            // reaches the next check and sees the flag.
            sendRaw(STEP_NEXT_COMMAND);
        }
        final int gen = generation;
        final long started = System.nanoTime();
        stopWatch = new Timeline(new KeyFrame(STOP_POLL, e -> {
            if (gen != generation) {
                cancelStopWatch(); // the process was replaced meanwhile
                return;
            }
            // The command's @READY has come back (in flight cleared), and the
            // interpreter is idle; a paused block owes no @READY, so its own
            // report counts instead.
            boolean done = !inFlight && backendIdle && (interruptAcknowledged || !paused);
            if (done) {
                cancelStopWatch();
                session.interrupt().clear();
                if (!isExecuting()) {
                    withFollow(guard::showPrompt);
                }
                return;
            }
            long elapsedMs = (System.nanoTime() - started) / 1_000_000L;
            if (elapsedMs >= STOP_GRACE.toMillis()) {
                cancelStopWatch();
                session.interrupt().clear();
                restartBackend(STOP_MESSAGE);
            }
        }));
        stopWatch.setCycleCount(Animation.INDEFINITE);
        stopWatch.play();
    }

    private static void cancelStopWatch() {
        if (stopWatch != null) {
            stopWatch.stop();
            stopWatch = null;
        }
    }

    /**
     * Commands typed (or sent by Run / Step) while another one ran were never
     * shown; when Stop or a crash drops them, say so instead of losing them
     * silently.
     */
    private static String cancelledNote(int count) {
        return count == 1
                ? "1 command waiting to run was cancelled.\n"
                : count + " commands waiting to run were cancelled.\n";
    }

    /** Forgets the command in flight and the queue (the interpreter is gone). */
    private static void dropCommandState() {
        inFlight = false;
        awaitingReady = 0;
        QUEUE.clear();
        setBusy(false);
        stepCarry = "";
        backendIdle = true;
    }

    /**
     * Kills the current interpreter and starts a new one on the session
     * autosave (the workspace at the last prompt).
     *
     * @param message printed before the fresh prompt, or null for none
     */
    private static void restartBackend(String message) {
        // Orphan the old process before it dies, so neither its last output
        // nor its exit watcher can touch the new session.
        generation++;
        Process old = process;
        process = null;
        processWriter = null;
        ide.processWriter = null;
        ide.runningProcess = null;
        ide.programRunning = false;
        killQuietly(old);
        WORKSPACE.reset();
        cancelStopWatch();
        dropCommandState();

        withFollow(() -> {
            if (message != null) {
                guard.writeNotice(message);
            }
            if (!isExecuting()) {
                guard.showPrompt();
            }
        });
        launch(false, true);
    }

    /**
     * Restarts the interpreter on the same workspace without a word (the path
     * lost a folder). Call only while idle, on the FX thread.
     */
    private static void restartQuietly() {
        if (ide == null || guard == null) {
            return;
        }
        generation++;
        Process old = process;
        process = null;
        processWriter = null;
        ide.processWriter = null;
        ide.runningProcess = null;
        ide.programRunning = false;
        killQuietly(old);
        stepCarry = "";
        backendIdle = true;
        launch(false, true);
    }

    private static void killQuietly(Process old) {
        if (old == null) {
            return;
        }
        try {
            old.getOutputStream().close();
        } catch (IOException ignored) {
            // the process is being killed anyway
        }
        old.destroyForcibly();
        try {
            old.waitFor(KILL_WAIT_MS, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    /** @return true while a command is running (typed, Run, Step or an IDE send) */
    public static boolean isBusy() {
        return BUSY.get();
    }

    /** @return busy, or a step block in progress inside the interpreter */
    public static boolean isExecuting() {
        return inFlight || StepFileRunner.isBlockInProgress();
    }

    /** @return read-only busy property (changes on the FX thread only) */
    public static ReadOnlyBooleanProperty busyProperty() {
        return BUSY.getReadOnlyProperty();
    }

    /**
     * Busy, for what the user sees: true once a command has run for
     * {@link #BUSY_SHOW_DELAY}, false as soon as it is over. A quick command
     * ({@code k = 5}) never turns it on, so an indicator bound to it -- the
     * ribbon's Stop -- does not flash on every command. Anything that acts on
     * the running state uses {@link #busyProperty()}.
     *
     * @return read-only shown-busy property (changes on the FX thread only)
     */
    public static ReadOnlyBooleanProperty busyShownProperty() {
        return BUSY_SHOWN.getReadOnlyProperty();
    }

    /**
     * Sends a line on behalf of another part of the IDE. It is a command like
     * any other: queued behind a running one, refused while a step block is
     * paused, and it counts towards the busy state.
     *
     * @param ideRef  the IDE controller
     * @param command the line to send
     */
    public static void sendFromIde(UI_Main ideRef, String command) {
        if (ideRef != null) {
            ide = ideRef;
        }
        if (command == null) {
            return;
        }
        onFx(() -> enqueue(Pending.backend(null, command)));
    }

    private static void setBusy(boolean busy) {
        onFx(() -> {
            BUSY.set(busy);
            if (!busy) {
                if (busyShowTimer != null) {
                    busyShowTimer.stop();
                    busyShowTimer = null;
                }
                BUSY_SHOWN.set(false);
            } else if (!BUSY_SHOWN.get() && busyShowTimer == null) {
                busyShowTimer = new PauseTransition(BUSY_SHOW_DELAY);
                busyShowTimer.setOnFinished(e -> {
                    busyShowTimer = null;
                    BUSY_SHOWN.set(BUSY.get());
                });
                busyShowTimer.play();
            }
        });
    }

    // =====================================================================
    // 4c. Workspace channel (what the Variable Explorer shows)
    // =====================================================================

    /**
     * The live workspace channel:
     * <pre>
     * CLI_Main.workspaceChannel().requestVariable("A")
     *         .thenAccept(v -&gt; ...);   // completes off the FX thread
     * </pre>
     *
     * @return the channel (never null)
     */
    public static WorkspaceChannel workspaceChannel() {
        return WORKSPACE;
    }

    private static void wireWorkspaceChannel() {
        if (workspaceWired) {
            return;
        }
        workspaceWired = true;
        WORKSPACE.setCommandSender(line -> {
            if (!isBackendAlive() || processWriter == null) {
                return false;
            }
            return sendRaw(line);
        });
        WORKSPACE.setSendGate(() -> isBackendAlive() && !isExecuting());
        WORKSPACE.addWorkspaceListener(CLI_Main::applyWorkspace);
    }

    private static void applyWorkspace(List<WorkspaceProtocol.VariableSummary> variables) {
        List<Variable> rows = new ArrayList<>(variables.size());
        for (WorkspaceProtocol.VariableSummary summary : variables) {
            rows.add(Variable.fromSummary(summary, null));
        }
        WorkspaceStore.get().sync(rows);
    }

    /** @return this IDE's session folder, or null (with a note) if it cannot be created */
    private static NcSession session() {
        try {
            return NcSession.get();
        } catch (IllegalStateException e) {
            notice("Warning: " + e.getMessage()
                    + " - Stop will restart the interpreter and the workspace cannot be restored.\n");
            return null;
        }
    }

    // =====================================================================
    // 5. Output streaming
    // =====================================================================

    private static void startReader(Process source, int gen) {
        OutputPump pump = new OutputPump(gen);
        // Protocol lines are taken out here, on the reader thread. @WS / @VAR
        // go straight to the workspace channel (a long line must arrive whole,
        // and the pump may drop text). @PROMPT / @READY go through the pump,
        // in order with the output around them, so the prompt is painted
        // after the output of the command it ends.
        ProtocolLineSplitter splitter = new ProtocolLineSplitter(pump::offerText, line -> {
            if (gen != generation) {
                return;
            }
            if (line.startsWith(WorkspaceProtocol.WS + " ") || line.startsWith(WorkspaceProtocol.VAR + " ")) {
                WORKSPACE.accept(line);
            } else {
                pump.offerControl(line);
            }
        });
        Thread readerThread = new Thread(() -> {
            // One decoder across reads, so a multi-byte character split
            // between two reads (Greek, Tamil) is never corrupted.
            try (Reader in = new InputStreamReader(source.getInputStream(), StandardCharsets.UTF_8)) {
                char[] buffer = new char[8192];
                int length;
                while ((length = in.read(buffer)) != -1) {
                    splitter.feed(buffer, length);
                }
            } catch (IOException ignored) {
                // Stream closed on shutdown or kill.
            }
        }, "cli-nc-reader");
        readerThread.setDaemon(true);
        readerThread.start();
    }

    /**
     * Moves interpreter output and protocol lines onto the FX thread in
     * batches, in order.
     *
     * <p>The reader thread only appends to a list. At most one drain is
     * queued at a time and drains are at least {@link #DRAIN_INTERVAL_MS}
     * apart, so a loop printing every iteration cannot flood the FX thread:
     * clicks (Stop, the menus) always get through. If more than
     * {@link #PENDING_CAP} characters of text pile up between drains, the
     * oldest text is dropped -- never a protocol line, never the newest
     * output.
     */
    private static final class OutputPump {
        private final int gen;
        private final ArrayDeque<Object> items = new ArrayDeque<>();
        private int textChars;
        private boolean scheduled;
        private long lastDrainNanos;

        OutputPump(int gen) {
            this.gen = gen;
        }

        /** Reader thread: buffer output text. */
        void offerText(char[] buffer, int offset, int length) {
            if (length <= 0) {
                return;
            }
            boolean schedule;
            synchronized (this) {
                Object last = items.peekLast();
                if (last instanceof StringBuilder text) {
                    text.append(buffer, offset, length);
                } else {
                    items.addLast(new StringBuilder(Math.max(64, length)).append(buffer, offset, length));
                }
                textChars += length;
                capText();
                schedule = !scheduled;
                scheduled = true;
            }
            if (schedule) {
                Platform.runLater(this::scheduleDrain);
            }
        }

        /** Reader thread: buffer one protocol line. */
        void offerControl(String line) {
            boolean schedule;
            synchronized (this) {
                items.addLast(new ControlLine(line));
                schedule = !scheduled;
                scheduled = true;
            }
            if (schedule) {
                Platform.runLater(this::scheduleDrain);
            }
        }

        /** Drops the oldest text beyond the cap. Caller holds the lock. */
        private void capText() {
            int excess = textChars - PENDING_CAP;
            for (Object item : items) {
                if (excess <= 0) {
                    break;
                }
                if (item instanceof StringBuilder text && text.length() > 0) {
                    int cut = Math.min(excess, text.length());
                    if (cut < text.length() && Character.isLowSurrogate(text.charAt(cut))) {
                        cut++; // never split a surrogate pair
                    }
                    text.delete(0, cut);
                    textChars -= cut;
                    excess -= cut;
                }
            }
        }

        /** FX thread: drain now, or after the rest of the minimum interval. */
        private void scheduleDrain() {
            long sinceMs = (System.nanoTime() - lastDrainNanos) / 1_000_000L;
            long waitMs = DRAIN_INTERVAL_MS - sinceMs;
            if (waitMs <= 0) {
                drain();
            } else {
                PauseTransition delay = new PauseTransition(Duration.millis(waitMs));
                delay.setOnFinished(e -> drain());
                delay.play();
            }
        }

        private void drain() {
            List<Object> batch;
            synchronized (this) {
                batch = new ArrayList<>(items);
                items.clear();
                textChars = 0;
                scheduled = false;
            }
            lastDrainNanos = System.nanoTime();
            if (gen == generation && !batch.isEmpty()) {
                onBatch(batch);
            }
        }
    }

    /**
     * One drain: every piece of output and every protocol line, in order,
     * then the transcript cap -- and one scroll decision for all of it.
     */
    private static void onBatch(List<Object> batch) {
        if (guard == null || ide == null || ide.console == null) {
            return;
        }
        withFollow(() -> {
            // Each item on its own: an error while showing one piece of output
            // must never swallow the @READY behind it in the same batch -- the
            // command would never finish and the prompt would never return.
            for (Object item : batch) {
                try {
                    switch (item) {
                        case StringBuilder text when text.length() > 0 -> onOutput(text.toString());
                        case ControlLine control -> onControl(control.line());
                        default -> { }
                    }
                } catch (RuntimeException e) {
                    LOG.log(Level.WARNING, "Interpreter output could not be shown", e);
                }
            }
            try {
                guard.trimHistory(CONSOLE_MAX_CHARS, CONSOLE_KEEP_CHARS);
            } catch (RuntimeException e) {
                LOG.log(Level.WARNING, "Command Window history could not be trimmed", e);
            }
        });
    }

    /** Interpreter output. FX thread. */
    private static void onOutput(String text) {
        String remaining = text;

        // "@STEPAT <n>" is a step-into pause marker, not output. A marker cut
        // off at the end of the previous read was held back; finish it now.
        if (!stepCarry.isEmpty()) {
            remaining = stepCarry + remaining;
            stepCarry = "";
        }
        if (StepFileRunner.isBlockInProgress() || remaining.contains(STEPAT_TAG)) {
            remaining = extractStepMarkers(remaining);
        }

        // An nc.exe without the prompt protocol starts with a plain prompt.
        if (protocol == Protocol.UNKNOWN && remaining.startsWith(PROMPT)) {
            protocol = Protocol.LEGACY;
            if (!legacyNoted) {
                legacyNoted = true;
                guard.writeNotice(LEGACY_NOTE);
            }
        }
        boolean legacyIdle = false;
        if (protocol == Protocol.LEGACY && remaining.contains(PROMPT)) {
            legacyIdle = remaining.endsWith(PROMPT);
            remaining = remaining.replace(PROMPT, "");
        }

        if (stopWatch != null && remaining.contains(INTERRUPTED_MESSAGE)) {
            interruptAcknowledged = true;
        }

        if (!remaining.isEmpty()) {
            // Cleaned names back to their visual form ("var_mu" -> "μ"), and
            // the interpreter's 'j' back to the user's 'i'.
            String shown;
            try {
                shown = ComplexLiteral.toDisplay(CliSymbolCodec.decodeOutput(remaining));
            } catch (RuntimeException e) {
                shown = remaining;
            }
            guard.writeOutput(shown);
            if (inFlight || StepFileRunner.isBlockInProgress()) {
                jumpToEnd = true; // MATLAB pulls the view to a running command's output
            }
        }

        if (legacyIdle) {
            backendIdle = true;
            notifyStepIdle();
            if (inFlight) {
                finishCommand();
            }
        }
    }

    /** A protocol line other than @WS / @VAR. FX thread. */
    private static void onControl(String line) {
        if (line == null) {
            return;
        }
        if (line.equals(PROMPT_EVENT)) {
            protocol = Protocol.MODERN;
            backendIdle = true;
            notifyStepIdle();
            return;
        }
        if (line.equals(READY_EVENT) || line.startsWith(READY_EVENT + " ")) {
            protocol = Protocol.MODERN;
            long id;
            try {
                id = Long.parseLong(line.substring(READY_EVENT.length()).strip());
            } catch (NumberFormatException e) {
                return;
            }
            if (inFlight && id == awaitingReady && id != 0) {
                finishCommand();
            }
        }
        // Unknown keywords (a newer interpreter may add some) are ignored.
    }

    /**
     * Removes every complete pause marker from {@code text}, reporting each to
     * the Step runner, and holds back an incomplete one at the very end (only
     * while a block is in progress).
     */
    private static String extractStepMarkers(String text) {
        boolean live = StepFileRunner.isBlockInProgress();
        StringBuilder kept = new StringBuilder(text.length());
        Matcher m = STEPAT_LINE.matcher(text);
        int last = 0;
        while (m.find()) {
            kept.append(text, last, m.start());
            if (live && m.group(2) == null && m.end() == text.length()) {
                stepCarry = text.substring(m.start());
                return kept.toString();
            }
            last = m.end();
            notifyStepAt(m.group(1));
        }
        String rest = text.substring(last);
        if (live) {
            int at = rest.lastIndexOf('@');
            if (at >= 0 && STEPAT_PREFIX.matcher(rest.substring(at)).matches()) {
                stepCarry = rest.substring(at);
                rest = rest.substring(0, at);
            }
        }
        kept.append(rest);
        return kept.toString();
    }

    private static void notifyStepAt(String digits) {
        if (stepAtListener == null) {
            return;
        }
        try {
            stepAtListener.accept(Integer.parseInt(digits));
        } catch (NumberFormatException ignored) {
            // A marker too large to be a line number is not one of ours.
        } catch (RuntimeException e) {
            LOG.log(Level.WARNING, "Step runner failed on a pause marker", e);
        }
    }

    private static void notifyStepIdle() {
        if (stepIdleListener == null) {
            return;
        }
        try {
            stepIdleListener.run();
        } catch (RuntimeException e) {
            LOG.log(Level.WARNING, "Step runner failed on an idle interpreter", e);
        }
    }

    private static void startExitWatcher(Process watched, int gen) {
        Thread watcher = new Thread(() -> {
            try {
                watched.waitFor();
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
            Platform.runLater(() -> {
                if (gen != generation) {
                    return; // stopped on purpose and already replaced
                }
                process = null;
                processWriter = null;
                ide.programRunning = false;
                ide.runningProcess = null;
                ide.processWriter = null;
                cancelStopWatch();
                int cancelled = QUEUE.size();
                dropCommandState();
                // A block paused in the dead interpreter can never be resumed.
                if (StepFileRunner.isBlockInProgress()) {
                    StepFileRunner.reset(ide);
                }
                if (!shuttingDown && guard != null) {
                    withFollow(() -> {
                        guard.writeNotice(CRASH_MESSAGE);
                        if (cancelled > 0) {
                            guard.writeNotice(cancelledNote(cancelled));
                        }
                        guard.showPrompt();
                    });
                }
            });
        }, "cli-nc-exit-watcher");
        watcher.setDaemon(true);
        watcher.start();
    }

    /**
     * Shows the most recent workspace the interpreter reported again, and asks
     * it for a fresh one when it is idle. FX thread.
     */
    public static void reloadWorkspace() {
        applyWorkspace(WORKSPACE.latest());
        WORKSPACE.requestWorkspaceNow();
    }

    /**
     * {@code variables.txt} no longer exists; see {@link #workspaceChannel()}.
     *
     * @return always null
     * @deprecated use {@link #workspaceChannel()}
     */
    @Deprecated
    public static Path getVariablesFile() {
        return null;
    }

    // =====================================================================
    // 6. Low-level plumbing
    // =====================================================================

    /**
     * Writes one line to the interpreter's stdin.
     *
     * @param line the line
     * @return true when the line was written
     */
    private static boolean sendRaw(String line) {
        if (processWriter == null) {
            if (guard != null) {
                guard.writeNotice("Input error: backend not connected.");
            }
            return false;
        }
        try {
            processWriter.write(line);
            processWriter.newLine();
            processWriter.flush();
            backendIdle = false;
            return true;
        } catch (IOException ex) {
            if (guard != null) {
                guard.writeNotice("Input error: " + ex.getMessage());
            }
            return false;
        }
    }

    /** Cleanly stops the backend (Exit / app close), then ends the session. */
    public static void shutdown() {
        shuttingDown = true;
        cancelStopWatch();
        try {
            if (processWriter != null) {
                processWriter.write("exit");
                processWriter.newLine();
                processWriter.flush();
            }
        } catch (IOException ignored) {
            // fall through to destroy
        }
        if (process != null && process.isAlive()) {
            try {
                process.waitFor(500, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            if (process.isAlive()) {
                process.destroy();
            }
        }
        WORKSPACE.reset();
        NcSession session = NcSession.current();
        if (session != null) {
            session.close();
        }
    }

    /**
     * Prints IDE-generated text on lines of its own: above the prompt when
     * idle, among the output while a command runs. Never on the prompt line,
     * so it can never be sent as a command. Safe from any thread.
     *
     * @param text the text to print
     */
    public static void appendOutput(String text) {
        if (text == null || text.isEmpty()) {
            return;
        }
        notice(text);
    }

    /**
     * Prints a one-off message from the IDE and makes sure a prompt follows
     * it when nothing is running. Safe from any thread.
     *
     * @param message the text; a trailing newline is added if missing
     */
    public static void printNotice(String message) {
        if (message == null || message.isEmpty()) {
            return;
        }
        onFx(() -> {
            if (guard == null) {
                return;
            }
            withFollow(() -> {
                guard.writeNotice(message);
                if (!isExecuting()) {
                    guard.showPrompt();
                }
            });
        });
    }

    /**
     * Makes sure the prompt is showing when nothing is running. While a
     * command runs, the prompt belongs to its end and this does nothing.
     * Safe from any thread.
     */
    public static void appendPrompt() {
        onFx(() -> {
            if (guard != null && !isExecuting()) {
                withFollow(guard::showPrompt);
            }
        });
    }

    /** Writes an IDE note now (FX) or on the FX thread. */
    private static void notice(String text) {
        onFx(() -> {
            if (guard != null) {
                withFollow(() -> guard.writeNotice(text));
            }
        });
    }

    /** True once a command has started inside the current {@link #withFollow} batch. */
    private static boolean jumpToEnd;

    /** Nesting of {@link #withFollow}; only the outermost one keeps the view. */
    private static int followDepth;

    /**
     * Runs a batch of console writes and decides the view once, after all of
     * them ({@link ConsoleViewport#settle}): the view is kept still while the
     * current line is on screen and followed once it reaches the bottom; a
     * user reading earlier results is never pulled away; a new command
     * starting in the batch jumps to the end.
     */
    private static void withFollow(Runnable writes) {
        withFollow(false, writes);
    }

    /**
     * @param force  follow even if the user was not looking at the current
     *               line (ENTER: the user's own action)
     * @param writes the console writes
     */
    private static void withFollow(boolean force, Runnable writes) {
        if (ide == null || ide.console == null || followDepth > 0) {
            writes.run(); // an inner batch: the outermost one keeps the view
            return;
        }
        ConsoleArea console = ide.console;
        ConsoleViewport viewport = console.getViewport();
        ConsoleViewport.View before = viewport == null ? null : viewport.capture();
        jumpToEnd = false;
        followDepth++;
        try {
            writes.run();
        } finally {
            followDepth--;
            // The view is settled even when a write failed, so the capture
            // never stays open and the screen is never left half-placed.
            boolean jump = force || jumpToEnd;
            jumpToEnd = false;
            try {
                if (viewport != null && before != null) {
                    viewport.settle(before, jump);
                } else if (jump || console.isEndInView()) {
                    console.requestFollowCaret();
                }
            } catch (RuntimeException e) {
                LOG.log(Level.WARNING, "Command Window view could not be placed", e);
            }
        }
    }

    private static void onFx(Runnable action) {
        if (Platform.isFxApplicationThread()) {
            action.run();
        } else {
            Platform.runLater(action);
        }
    }

    private static Path resolveNcExe() {
        String override = System.getProperty(NC_EXE_PROPERTY);
        if (override != null && !override.isBlank()) {
            Path p = Path.of(override);
            if (Files.exists(p)) {
                return p;
            }
        }
        Path base = Path.of(System.getProperty("user.dir"));
        for (String candidate : NC_EXE_CANDIDATES) {
            Path p = base.resolve(candidate);
            if (Files.exists(p)) {
                return p;
            }
        }
        return null;
    }

    private static boolean isExit(String s) {
        String n = norm(s);
        return n.equals("exit") || n.equals("exit()") || n.equals("quit") || n.equals("quit()");
    }

    /** cls / clc = clear screen only (keep workspace). */
    private static boolean isClearScreen(String s) {
        String n = norm(s);
        return n.equals("cls") || n.equals("clc");
    }

    /** A line that is only a comment ({@code #}, {@code \\}) or blank. */
    private static boolean isCommentOnly(String line) {
        try {
            return NcBlockScanner.codeWithoutComment(line).isBlank();
        } catch (RuntimeException e) {
            return false;
        }
    }

    /**
     * Recognises {@code clear} and {@code clear <name>}.
     *
     * @return null when this is not a clear command, "" for a full clear, or
     *         the variable name for a targeted clear
     */
    private static String clearTarget(String s) {
        String raw = s == null ? "" : s.strip();
        String lower = raw.toLowerCase(Locale.ROOT);
        if (lower.equals("clear") || lower.equals("clear;")) {
            return "";
        }
        if (lower.startsWith("clear ")) {
            String name = raw.substring(6).strip();
            if (name.endsWith(";")) {
                name = name.substring(0, name.length() - 1).strip();
            }
            return name;
        }
        return null;
    }

    private static String norm(String s) {
        return s == null ? "" : s.trim().toLowerCase(Locale.ROOT);
    }
}
