package ui.cli;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Locale;

import javafx.application.Platform;
import ui.UI_Main;
import ui.ui_functions.Variable;
import ui.ui_functions.WorkspaceStore;

/**
 * <h2>CLI_Main — the Command Window controller</h2>
 *
 * Single Java owner of the Command Window.
 *
 * <h3>Design contract</h3>
 * <ul>
 *   <li><b>C++ owns evaluation.</b> One persistent {@code nc.exe} is the live
 *       backend for the whole session, so the workspace persists between
 *       commands and between script runs.</li>
 *   <li><b>Java owns the prompt.</b> {@link ConsoleInputGuard} owns the
 *       editable region; this class owns command dispatch.</li>
 *   <li><b>{@code variables.txt} is the workspace.</b> {@link WorkspaceStore}
 *       is refreshed from it whenever the {@code >> } prompt returns, which is
 *       the only race-free moment: the interpreter has finished writing.</li>
 * </ul>
 *
 * <h3>Command semantics</h3>
 * <table>
 *   <tr><td>{@code cls}</td><td>clear the screen only; workspace untouched</td></tr>
 *   <tr><td>{@code clear}</td><td>reset the workspace only; screen untouched</td></tr>
 *   <tr><td>{@code clear A}</td><td>remove one variable; screen untouched</td></tr>
 * </table>
 *
 * <p><b>These work against your current nc.exe with no recompile.</b>
 * {@code cls} never reaches the backend. {@code clear} maps onto the existing
 * {@code clear} builtin. {@code clear <name>} is done by rewriting
 * {@code variables.txt} from Java and sending {@code @cmd syncws} — see
 * {@link #clearOne} for the one caveat.
 */
public final class CLI_Main {

    /** The interactive prompt printed by nc.exe. */
    static final String PROMPT = ">> ";

    /** Optional override: -Dupi.nc.exe=C:\\path\\to\\nc.exe */
    private static final String NC_EXE_PROPERTY = "upi.nc.exe";

    private static final String[] NC_EXE_CANDIDATES = {
            "cpp/nc.exe",
            "src/main/cpp/nc.exe",
            "nc.exe"
    };

    private static UI_Main ide;
    private static Process process;
    private static BufferedWriter processWriter;
    private static ConsoleInputGuard guard;

    /** Directory nc.exe runs in; also where the shared variables.txt lives. */
    private static Path workingDirectory;
    private static Path variablesTxt;

    private static CLI_SuggestionBridge suggestionBridge;

    /**
     * Prompts the interpreter will emit for commands the USER never typed.
     * Every {@code @cmd ...} the IDE sends is answered with a ">> " that must
     * not reach the screen, or the console grows a spurious ">> >> ".
     */
    private static int silentPrompts;

    /** Last directory sent with {@code @cmd setpwd}; avoids resending it. */
    private static Path lastWorkspaceDirectory;

    /** {@code -Dastra.workspace.persist=true} keeps the previous session's variables. */
    private static final String PERSIST_PROPERTY = "astra.workspace.persist";

    private CLI_Main() {
    }

    // =====================================================================
    // 1. Console construction (called from Main_Window.setupConsole)
    // =====================================================================

    /**
     * Builds the console, installs the freeze, and attaches the shared
     * suggestion popup.
     *
     * @param ideRef the IDE controller
     */
    public static void initConsole(UI_Main ideRef) {
        ide = ideRef;
        guard = ConsoleController.initialize(ide);
        // Live symbol replacement first, so the suggestion bridge sees text
        // that has already been folded into its visual form.
        ConsoleSymbolInput.attach(ide, guard);
        suggestionBridge = new CLI_SuggestionBridge();
        suggestionBridge.attach(ide, guard);
        guard.setSuppressEnter(CLI_Main::isSuggestionShowing);
        guard.setOnSubmit(() -> handleEnter(ide));
    }

    // =====================================================================
    // 2. Backend lifecycle
    // =====================================================================

    /**
     * Locates and launches the persistent {@code nc.exe} backend. Idempotent:
     * calling it twice never starts a second interpreter.
     *
     * @param ideRef the IDE controller
     */
    public static void start(UI_Main ideRef) {
        ide = ideRef;
        if (process != null && process.isAlive()) {
            return;
        }
        Path exe = resolveNcExe();
        if (exe == null) {
            appendOutput("UPI backend not found. Set -D" + NC_EXE_PROPERTY
                    + "=<path to nc.exe> or place nc.exe under one of: "
                    + String.join(", ", NC_EXE_CANDIDATES) + "\n");
            appendPrompt();
            return;
        }
        workingDirectory = exe.toAbsolutePath().getParent();
        variablesTxt = workingDirectory.resolve("variables.txt");

        // A new window means a new workspace. Parser's constructor calls
        // loadFromFile(), so variables.txt must be emptied BEFORE the process
        // starts — otherwise the interpreter inherits the previous session and
        // the Explorer fills with variables the user never declared here.
        if (!Boolean.getBoolean(PERSIST_PROPERTY)) {
            WorkspaceVariableParser.writeEmpty(variablesTxt);
            WorkspaceStore.get().clearAll();
        }

        try {
            ProcessBuilder pb = new ProcessBuilder(exe.toAbsolutePath().toString());
            pb.directory(workingDirectory.toFile());
            pb.redirectErrorStream(true);
            process = pb.start();

            ide.runningProcess = process;
            ide.programRunning = true;
            processWriter = new BufferedWriter(
                    new OutputStreamWriter(process.getOutputStream(), StandardCharsets.UTF_8));
            ide.processWriter = processWriter;

            startReader();
            startExitWatcher();

            Path project = ide.getCurrentFolder();
            if (project != null) {
                setWorkspaceDirectory(project);
            }
            reloadWorkspace();
        } catch (IOException ex) {
            appendOutput("Failed to start UPI terminal: " + ex.getMessage() + "\n");
            appendPrompt();
        }
    }

    /**
     * Tells the backend which folder to resolve script names against.
     *
     * @param folder the project/workspace directory
     */
    public static void setWorkspaceDirectory(Path folder) {
        if (folder == null) {
            return;
        }
        Path absolute = folder.toAbsolutePath();
        if (absolute.equals(lastWorkspaceDirectory)) {
            return; // already there; resending only costs a spurious prompt
        }
        lastWorkspaceDirectory = absolute;
        sendInternal("@cmd setpwd \"" + absolute + "\"");
    }

    // =====================================================================
    // 3. Input handling
    // =====================================================================

    /**
     * Called by {@link ConsoleInputGuard} when ENTER is pressed on the prompt
     * line and the suggestion popup is not open.
     *
     * @param ideRef the IDE controller
     */
    public static void handleEnter(UI_Main ideRef) {
        ide = ideRef;
        String line = guard == null ? "" : guard.currentInput().strip();

        if (isExit(line)) {
            guard.appendRaw("\n");
            shutdown();
            if (ide.stage != null) {
                ide.stage.close();
            }
            Platform.exit();
            return;
        }

        guard.rememberCommand(line);

        // ---- cls: screen only. Never reaches the backend, so the workspace
        // ---- cannot be touched by it. ------------------------------------
        if (isClearScreen(line)) {
            guard.clearScreen();
            appendPrompt();
            return;
        }

        // ---- clear / clear <name>: workspace only, screen untouched -------
        String target = clearTarget(line);
        if (target != null) {
            guard.appendRaw("\n");
            guard.lockToEnd();
            if (target.isEmpty()) {
                clearAll();
            } else {
                clearOne(target);
            }
            return;
        }

        // ---- everything else: one line advance, forward to backend --------
        guard.appendRaw("\n");
        guard.lockToEnd();

        if (process == null || !ide.programRunning) {
            appendOutput("UPI terminal is not running.\n");
            appendPrompt();
            return;
        }

        // The screen keeps the visual line the user typed; the interpreter is
        // handed the cleaned one, exactly as Run hands it cleaned_Runfile.nc.
        // Sending the raw line was why a Greek/Tamil/Sanskrit declaration made
        // in the Command Window silently did nothing. Pure-ASCII lines are
        // returned unchanged by the codec, so every command that worked before
        // still travels byte for byte.
        sendRaw(CliSymbolCodec.encodeLine(line));
    }

    /**
     * Runs a script on the shared persistent backend.
     *
     * <p>The <b>displayed</b> name and the <b>executed</b> file are deliberately
     * different: the console shows {@code >> ssss.nc} (requirement 3) while the
     * backend is handed the absolute path of {@code cleaned_Runfile.nc}, which
     * is the only file {@code nc.exe} should ever execute (requirement 4).
     *
     * @param ideRef      the IDE controller
     * @param displayName what to echo at the prompt, e.g. {@code ssss.nc}
     * @param fileToRun   the cleaned file actually handed to the interpreter
     */
    public static void runScript(UI_Main ideRef, String displayName, Path fileToRun) {
        ide = ideRef;
        if (fileToRun == null) {
            return;
        }
        if (process == null || !ide.programRunning) {
            appendOutput("UPI terminal is not running.\n");
            return;
        }
        Platform.runLater(() -> {
            guard.appendRaw(displayName == null ? fileToRun.getFileName().toString() : displayName);
            guard.appendRaw("\n");
            guard.lockToEnd();
            sendRaw("\"" + fileToRun.toAbsolutePath() + "\"");
        });
    }

    /**
     * Kept so existing callers compile. Prefer
     * {@link #runScript(UI_Main, String, Path)}, which runs the cleaned file.
     *
     * @param ideRef     the IDE controller
     * @param scriptName the script's name or path
     */
    public static void runScriptByName(UI_Main ideRef, String scriptName) {
        ide = ideRef;
        if (scriptName == null || scriptName.isBlank()) {
            return;
        }
        Platform.runLater(() -> {
            guard.appendRaw(scriptName);
            guard.appendRaw("\n");
            guard.lockToEnd();
            sendRaw(scriptName);
        });
    }

    /** @return true while the shared suggestion popup is visible. */
    public static boolean isSuggestionShowing() {
        return suggestionBridge != null && suggestionBridge.isShowing();
    }

    // =====================================================================
    // 4. clear / clear <name>
    // =====================================================================

    /**
     * Resets the whole workspace. Uses the interpreter's existing {@code clear}
     * builtin, so no rebuild is needed; the screen is left alone because Java
     * never clears it here.
     */
    private static void clearAll() {
        WorkspaceStore.get().clearAll();
        if (variablesTxt != null) {
            WorkspaceVariableParser.writeEmpty(variablesTxt);
        }
        if (process != null && ide.programRunning) {
            sendRaw("clear");
        } else {
            appendPrompt();
        }
    }

    /**
     * Removes one variable from the workspace.
     *
     * <p>The interpreter has no {@code unset} builtin, so this rewrites
     * {@code variables.txt} without that record and asks the REPL to reload it
     * with {@code @cmd syncws}.
     *
     * <p><b>Caveat with the current binary.</b> If your compiled {@code nc.exe}
     * predates the {@code syncws} hook in {@code main.cpp}, the unknown
     * {@code @cmd} is silently ignored: the file and the Explorer are correct,
     * but the REPL's in-memory copy still holds the variable and will write it
     * back on its next save. The rebuild notes in NOTES.md close this gap.
     *
     * @param visualName the name the user typed, in editor form
     */
    private static void clearOne(String visualName) {
        String cleaned = CliSymbolCodec.encodeName(visualName);
        if (cleaned == null || cleaned.isBlank()) {
            appendOutput("clear: no variable name given.\n");
            appendPrompt();
            return;
        }
        boolean known = WorkspaceStore.get().contains(cleaned);
        boolean removed = variablesTxt != null
                && WorkspaceVariableParser.removeVariable(variablesTxt, cleaned);

        if (!known && !removed) {
            appendOutput("clear: '" + visualName + "' is not in the workspace.\n");
            appendPrompt();
            return;
        }

        WorkspaceStore.get().remove(cleaned);
        if (process != null && ide.programRunning) {
            sendInternal("@cmd syncws");
        } else {
            appendPrompt();
        }
    }

    // =====================================================================
    // 5. Output streaming + Explorer refresh
    // =====================================================================

    private static void startReader() {
        Thread readerThread = new Thread(() -> {
            // A Reader keeps one decoder across reads. Constructing a String
            // per raw byte-chunk (the previous approach) corrupts any
            // multi-byte character that straddles a chunk boundary — which is
            // exactly what Greek and Tamil output is made of.
            try (Reader in = new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8)) {
                char[] buffer = new char[2048];
                int length;
                while ((length = in.read(buffer)) != -1) {
                    String chunk = new String(buffer, 0, length);
                    Platform.runLater(() -> onOutput(chunk));
                }
            } catch (IOException ignored) {
                // Stream closed on shutdown — nothing to do.
            }
        }, "cli-nc-reader");
        readerThread.setDaemon(true);
        readerThread.start();
    }

    private static void startExitWatcher() {
        Thread watcher = new Thread(() -> {
            try {
                process.waitFor();
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
            Platform.runLater(() -> {
                ide.programRunning = false;
                ide.runningProcess = null;
                ide.processWriter = null;
            });
        }, "cli-nc-exit-watcher");
        watcher.setDaemon(true);
        watcher.start();
    }

    private static void onOutput(String text) {
        if (ide == null || ide.console == null || text == null || text.isEmpty() || guard == null) {
            return;
        }

        // Prompts owed to IDE-internal commands are consumed here rather than
        // printed. The interpreter answers every line it reads with a prompt,
        // including the "@cmd" lines the user never typed.
        String remaining = text;
        while (silentPrompts > 0 && remaining.startsWith(PROMPT)) {
            remaining = remaining.substring(PROMPT.length());
            silentPrompts--;
        }
        if (!remaining.isEmpty() && !remaining.startsWith(PROMPT)) {
            // Real output arrived, so any prompt we were still waiting to
            // swallow is never coming; drop the debt rather than let it eat a
            // legitimate prompt later.
            silentPrompts = 0;
        }

        if (!remaining.isEmpty()) {
            // nc.exe answers in cleaned names ("var_mu = 25"). The console is
            // the user's side of the boundary, so names are turned back into
            // their visual form here and the echo reads "μ = 25". Ordinary
            // names and all other output are untouched.
            guard.appendRaw(CliSymbolCodec.decodeOutput(remaining));
        }
        collapseTrailingPrompts();

        // The prompt marks the end of a command: the interpreter has finished
        // and variables.txt is fully written, so this is the correct moment to
        // refresh the workspace.
        if (endsWithPrompt()) {
            guard.lockToEnd();
            reloadWorkspace();
        }
    }

    /**
     * Collapses ">> >> " down to a single prompt.
     *
     * <p>Safety net for the suppression above: output can be delivered in
     * chunks that split a prompt across two reads, in which case the
     * {@code startsWith} test misses. Two prompts with nothing between them are
     * always noise, whatever produced them, so they are folded here.
     */
    private static void collapseTrailingPrompts() {
        guard.systemWrite(() -> {
            while (endsWith(PROMPT + PROMPT)) {
                int length = ide.console.getLength();
                ide.console.deleteText(length - PROMPT.length(), length);
            }
            ide.console.positionCaret(ide.console.getLength());
        });
    }

    /**
     * Reloads {@code variables.txt} into the Explorer. Rows are merged in
     * place by {@link WorkspaceStore}, so nothing is duplicated and nothing is
     * dropped that the interpreter still holds.
     */
    public static void reloadWorkspace() {
        if (variablesTxt == null || !Files.exists(variablesTxt)) {
            return;
        }
        List<Variable> globals = WorkspaceVariableParser.parse(variablesTxt);
        WorkspaceStore.get().sync(globals);
    }

    /** @return the shared workspace file, or null before the backend starts */
    public static Path getVariablesFile() {
        return variablesTxt;
    }

    // =====================================================================
    // 6. Low-level plumbing
    // =====================================================================

    /**
     * Sends a command the user did not type, and records that its prompt must
     * be swallowed rather than displayed.
     *
     * @param line the internal command
     */
    private static void sendInternal(String line) {
        silentPrompts++;
        sendRaw(line);
    }

    private static void sendRaw(String line) {
        if (processWriter == null) {
            appendOutput("Input error: backend not connected.\n");
            return;
        }
        try {
            processWriter.write(line);
            processWriter.newLine();
            processWriter.flush();
        } catch (IOException ex) {
            appendOutput("Input error: " + ex.getMessage() + "\n");
        }
    }

    /** Cleanly stops the backend (used on Exit / app close). */
    public static void shutdown() {
        try {
            if (processWriter != null) {
                processWriter.write("exit");
                processWriter.newLine();
                processWriter.flush();
            }
        } catch (IOException ignored) {
            // fall through to destroy
        }
        if (process != null && process.isAlive()) {
            process.destroy();
        }
    }

    /**
     * Appends IDE-generated text to the console, respecting the freeze.
     *
     * @param text the text to append
     */
    public static void appendOutput(String text) {
        if (guard == null) {
            return;
        }
        if (Platform.isFxApplicationThread()) {
            guard.append(text);
        } else {
            Platform.runLater(() -> guard.append(text));
        }
    }

    /** Paints a prompt locally (only when the backend cannot provide one). */
    public static void appendPrompt() {
        if (guard == null) {
            return;
        }
        Runnable paint = () -> {
            if (!endsWithPrompt()) {
                if (ide.console.getLength() > 0 && !endsWith("\n")) {
                    guard.appendRaw("\n");
                }
                guard.append(PROMPT);
            }
        };
        if (Platform.isFxApplicationThread()) {
            paint.run();
        } else {
            Platform.runLater(paint);
        }
    }

    private static Path resolveNcExe() {
        String override = System.getProperty(NC_EXE_PROPERTY);
        if (override != null && !override.isBlank()) {
            Path p = Path.of(override);
            if (Files.exists(p)) {
                return p;
            }
        }
        Path base = Path.of(System.getProperty("user.dir"));
        for (String candidate : NC_EXE_CANDIDATES) {
            Path p = base.resolve(candidate);
            if (Files.exists(p)) {
                return p;
            }
        }
        return null;
    }

    private static boolean endsWithPrompt() {
        return endsWith(PROMPT);
    }

    private static boolean endsWith(String suffix) {
        int length = ide.console.getLength();
        if (length < suffix.length()) {
            return false;
        }
        return suffix.equals(ide.console.getText(length - suffix.length(), length));
    }

    private static boolean isExit(String s) {
        String n = norm(s);
        return n.equals("exit") || n.equals("exit()") || n.equals("quit") || n.equals("quit()");
    }

    /** cls = clear screen only (keep workspace). */
    private static boolean isClearScreen(String s) {
        String n = norm(s);
        return n.equals("cls") || n.equals("clc");
    }

    /**
     * Recognises {@code clear} and {@code clear <name>}.
     *
     * @param s the submitted line
     * @return null when this is not a clear command, "" for a full clear, or
     *         the variable name for a targeted clear
     */
    private static String clearTarget(String s) {
        String raw = s == null ? "" : s.strip();
        String lower = raw.toLowerCase(Locale.ROOT);
        if (lower.equals("clear")) {
            return "";
        }
        if (lower.startsWith("clear ")) {
            return raw.substring(6).strip();
        }
        return null;
    }

    private static String norm(String s) {
        return s == null ? "" : s.trim().toLowerCase(Locale.ROOT);
    }
}
