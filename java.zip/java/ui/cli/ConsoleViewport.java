package ui.cli;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.function.IntSupplier;

import org.fxmisc.richtext.model.TwoDimensional.Bias;

import javafx.application.Platform;
import javafx.geometry.Bounds;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.ScrollEvent;
import ui.design.section_dims.CommandWindow_dim;

/**
 * Where the Command Window looks (MATLAB's rules).
 *
 * <h3>The room under the last line</h3>
 * <pre>
 *   fresh console              after the first command        scrolled to the end
 *   +--------------------+     +--------------------+ ^       +--------------------+
 *   | >> _               |     | >>                 | |       | >> _               |
 *   |                    |     | >>                 | #       |                    |
 *   |                    |     | >> _               | #       |    (room, never    |
 *   |                    |     |                    | |       |     text)          |
 *   +--------------------+     +--------------------+ v       +--------------------+
 *   no scroll bar              scroll bar active              current line on top
 * </pre>
 * <p>
 * A fresh console has no room and no scroll bar. From the first command on
 * ({@link #activateRoom}) the last paragraph carries the style class
 * {@value #TAIL_CLASS}, and a generated sheet gives it a bottom padding of the
 * visible height less {@link CommandWindow_dim#OVERSCROLL_KEEP_LINES} lines.
 * The scroll bar is then always active, and scrolling all the way down leaves
 * the current line at the top left. There is no blank text: copying,
 * selecting, the prompt and the freeze all see exactly the transcript.
 * </p>
 *
 * <h3>Every batch of writes keeps the view explicitly</h3>
 * <p>
 * The room sits on whichever paragraph is last, so it moves on every new
 * line; left alone, the scroll pane re-anchors on that tall paragraph and the
 * view jumps. So the CLI wraps every batch of console writes in
 * {@link #capture} / {@link #settle}: the first visible line and how far it is
 * scrolled are noted before, and put back after. Then:
 * </p>
 * <ul>
 *   <li><b>The rule, for every kind of output</b> (a typed command, a
 *       script, Run, a section, the step runner): when the output fits, it
 *       simply appears under the command; when it does not, the window shows
 *       the newest lines with the current line on the bottom row. A
 *       transcript shorter than the window stays at the top left.</li>
 *   <li><b>The user scrolled the current line up themselves</b> (MATLAB:
 *       scrolling to the end puts it at the top): output fills the window
 *       under it, still, until it no longer fits -- then the rule above.</li>
 *   <li><b>The user is reading the history</b> and a notice arrives while
 *       nothing runs: the view stays exactly where they are. A new command,
 *       or a running command printing, jumps to the end (the rule above).</li>
 *   <li><b>Checked before drawing:</b> after the layout of every batch, the
 *       result is checked against these rules and corrected before anything
 *       is drawn (see {@link #verifyAfterLayout}).</li>
 * </ul>
 * <p>
 * "On screen" means the console's last line, not the caret: a click in the
 * history leaves the caret there without moving anything, and following the
 * end takes the caret back to the input first.
 * </p>
 */
final class ConsoleViewport {

    /** The class on the last paragraph. */
    static final String TAIL_CLASS = "console-tail";

    private static final Collection<String> TAIL = List.of(TAIL_CLASS);
    private static final Collection<String> PLAIN = Collections.emptyList();

    private final ConsoleArea area;
    private String sheet;
    private double room = -1;
    private boolean roomActive;
    private boolean updateQueued;
    /** Lowest offset changed since the tail was last checked; -1 = none. */
    private int tailDirtyFrom = -1;

    /** The open capture's first visible line, kept current across edits; -1 = none. */
    private int trackedOffset = -1;

    /**
     * True when the user scrolled the view themselves (wheel, scroll bar,
     * page keys) since the CLI last placed it. Only then is a current line
     * away from the bottom row left where it is.
     */
    private boolean userPlaced;

    /** A check of the view is waiting for the next layout. */
    private boolean verifyPending;

    /** The scene the waiting check is registered on. */
    private Scene verifyScene;

    /** The scroll pane the console sits in, once known. */
    private Parent scrollPane;

    /** Start of the input region ({@code ide.inputStart}). */
    private IntSupplier inputStart = () -> 0;

    /** What the view looked like before a batch of writes. */
    record View(int topOffset, double scrolledInto, boolean endInView) {
    }

    private ConsoleViewport(ConsoleArea area) {
        this.area = area;
    }

    /**
     * Installs the room and the view keeping on a console.
     *
     * @param area the console
     * @return the controller, also reachable as {@link ConsoleArea#getViewport()}
     */
    static ConsoleViewport attach(ConsoleArea area) {
        ConsoleViewport viewport = new ConsoleViewport(area);
        viewport.install();
        area.setViewport(viewport);
        return viewport;
    }

    /** @param start where the input region starts ({@code ide.inputStart}) */
    void setInputStart(IntSupplier start) {
        this.inputStart = start == null ? () -> 0 : start;
    }

    private void install() {
        // Never restyle from inside the change notification (see ConsoleArea's
        // class notes): note where the text changed, act after the edit.
        area.plainTextChanges().subscribe(change -> {
            int at = change.getPosition();
            tailDirtyFrom = tailDirtyFrom < 0 ? at : Math.min(tailDirtyFrom, at);
            if (trackedOffset >= 0 && at < trackedOffset) {
                int removed = change.getRemoved().length();
                int inserted = change.getInserted().length();
                trackedOffset = at + removed > trackedOffset
                        ? at // the tracked line itself was deleted (a trim, cls)
                        : trackedOffset + inserted - removed;
            }
        });
        area.addAfterEdit(() -> {
            if (tailDirtyFrom >= 0) {
                int from = tailDirtyFrom;
                tailDirtyFrom = -1;
                markTail(from);
            }
        });
        area.heightProperty().addListener((obs, was, is) -> queueRoomUpdate());
        area.styleProperty().addListener((obs, was, is) -> queueRoomUpdate());
        installUserScrollWatch();
        markTail(0);
    }

    /** Notes when the user moves the view: wheel, scroll bar, page keys. */
    private void installUserScrollWatch() {
        area.addEventFilter(ScrollEvent.SCROLL, event -> userPlaced = true);
        area.addEventFilter(KeyEvent.KEY_PRESSED, event -> {
            KeyCode code = event.getCode();
            if (code == KeyCode.PAGE_UP || code == KeyCode.PAGE_DOWN
                    || (event.isShortcutDown() && (code == KeyCode.HOME || code == KeyCode.END))) {
                userPlaced = true;
            }
        });
        // The scroll bars belong to the scroll pane around the console.
        javafx.event.EventHandler<MouseEvent> onBar = event -> {
            if (event.getTarget() instanceof Node node && !isInside(node, area)) {
                userPlaced = true;
            }
        };
        area.parentProperty().addListener((obs, was, is) -> {
            if (scrollPane != null) {
                scrollPane.removeEventFilter(MouseEvent.MOUSE_PRESSED, onBar);
            }
            scrollPane = is;
            if (is != null) {
                is.addEventFilter(MouseEvent.MOUSE_PRESSED, onBar);
            }
        });
        if (area.getParent() != null) {
            scrollPane = area.getParent();
            scrollPane.addEventFilter(MouseEvent.MOUSE_PRESSED, onBar);
        }
    }

    private static boolean isInside(Node node, Node container) {
        for (Node n = node; n != null; n = n.getParent()) {
            if (n == container) {
                return true;
            }
        }
        return false;
    }

    // =====================================================================
    // The room
    // =====================================================================

    /** From the first command on, the room exists (MATLAB: the scroll bar activates). */
    void activateRoom() {
        if (roomActive) {
            return;
        }
        roomActive = true;
        markTail(0);
        updateRoom();
        area.applyCss();
    }

    private void queueRoomUpdate() {
        if (updateQueued || !roomActive) {
            return;
        }
        updateQueued = true;
        Platform.runLater(() -> {
            updateQueued = false;
            updateRoom();
        });
    }

    /** Sets the tail's bottom padding to the visible height less the kept lines. */
    private void updateRoom() {
        if (!roomActive || area.getScene() == null) {
            return;
        }
        Insets insets = area.getInsets();
        double visible = area.getHeight() - insets.getTop() - insets.getBottom();
        if (visible <= 0) {
            return;
        }
        double next = Math.max(0, Math.floor(visible - CommandWindow_dim.OVERSCROLL_KEEP_LINES * lineHeight()));
        if (Math.abs(next - room) < 1) {
            return;
        }
        room = next;
        String css = "." + ConsoleArea.STYLE_CLASS + " ." + TAIL_CLASS
                + " { -fx-padding: 0 0 " + (int) next + "px 0; }\n";
        if (sheet != null) {
            area.getStylesheets().remove(sheet);
        }
        sheet = "data:text/css;base64,"
                + Base64.getEncoder().encodeToString(css.getBytes(StandardCharsets.UTF_8));
        area.getStylesheets().add(sheet);
    }

    /**
     * Height of one console line: the same measurement {@link ConsoleArea}
     * places the current line with (read from a line actually drawn). The two
     * must agree, or the after-layout check corrects a correct view.
     */
    private double lineHeight() {
        return area.lineHeight();
    }

    // =====================================================================
    // Keeping the view across a batch of writes
    // =====================================================================

    /**
     * Notes the view before a batch of writes. Must be followed by
     * {@link #settle}.
     *
     * @return the view
     */
    View capture() {
        // Writes that arrive before the next frame (a fast command answers
        // within a millisecond or two of ENTER) would otherwise be judged
        // against the layout from before the previous batch: the last line
        // not yet on screen, "the user is reading the history", and the
        // view pulled to the bottom row against the rules. Lay out first.
        area.flushLayout();
        boolean endInView = area.isEndInView();
        int topOffset = -1;
        double scrolledInto = 0;
        try {
            if (!area.getVisibleParagraphs().isEmpty()) {
                int top = area.firstVisibleParToAllParIndex();
                topOffset = area.getAbsolutePosition(top, 0);
                // Not the paragraph's bounds: RichTextFX cuts them off at the
                // console's edge, so no more than the padding was ever kept.
                OptionalDouble parTop = area.paragraphTopOnScreen(top);
                Bounds view = area.viewportOnScreen();
                if (parTop.isPresent() && view != null) {
                    scrolledInto = Math.max(0, view.getMinY() - parTop.getAsDouble());
                }
            }
        } catch (RuntimeException notLaidOut) {
            topOffset = -1;
            scrolledInto = 0;
        }
        trackedOffset = topOffset;
        return new View(topOffset, scrolledInto, endInView);
    }

    /**
     * Puts the view back after a batch of writes, then follows the end as the
     * class notes describe.
     *
     * @param before what {@link #capture} returned
     * @param jump   true when a new command started, or a running command
     *               printed, in this batch: the end is shown whatever was on
     *               screen (MATLAB pulls the view to new output)
     */
    void settle(View before, boolean jump) {
        int topOffset = trackedOffset;
        trackedOffset = -1;
        boolean follow = before.endInView() || jump;
        if (!follow) {
            // Reading the history: nothing the writes asked for moves the view.
            area.cancelFollow();
            restoreTop(topOffset, before);
            return;
        }
        caretToInput();
        if (!userPlaced || !before.endInView()) {
            // THE rule, for every kind of output (typed command, script, Run,
            // section, step): the newest lines fill the window and the current
            // line is on the bottom row. A transcript shorter than the window
            // simply stays at the top left (there is nothing above to show).
            userPlaced = false;
            area.requestCaretAtBottom();
            verifyAfterLayout();
            return;
        }
        // The user scrolled the current line up themselves (MATLAB: scrolling
        // to the end leaves it at the top): output fills the window under it,
        // still; once it no longer fits, the rule above takes over.
        restoreTop(topOffset, before);
        area.requestFollowCaret();
        verifyAfterLayout();
    }

    /** Puts the line that was first on screen back at the top. */
    private void restoreTop(int topOffset, View before) {
        if (topOffset < 0) {
            return;
        }
        int paragraph = area.offsetToPosition(
                Math.max(0, Math.min(topOffset, area.getLength())), Bias.Forward).getMajor();
        double into = topOffset == before.topOffset() ? before.scrolledInto() : 0;
        try {
            // One exact placement (see ConsoleArea.placeParagraphTop), not a
            // jump to the top followed by an estimated scroll.
            area.placeParagraphTop(paragraph, -into);
            area.applyCss();
            area.layout();
        } catch (RuntimeException layoutNotReady) {
            // Not on screen yet: nothing to keep.
        }
    }

    // =====================================================================
    // Checking the result before it is drawn
    // =====================================================================

    /**
     * Checks the view once the next layout is done -- after layout, before
     * anything is drawn -- and corrects it if it broke the rule. The scroll
     * pane occasionally re-anchors on the tall last paragraph (the one with
     * the room) and leaves the current line at the top of an empty window;
     * the check catches that whatever caused it, without a visible blink.
     */
    private void verifyAfterLayout() {
        Scene scene = area.getScene();
        // A check registered on another scene (the console moved to the
        // standalone window and back) would never run, and would block every
        // later check: register again on the scene the console is in now.
        if (scene == null || (verifyPending && scene == verifyScene)) {
            return;
        }
        verifyPending = true;
        verifyScene = scene;
        boolean[] done = new boolean[1];
        Runnable[] self = new Runnable[1];
        self[0] = () -> {
            if (done[0]) {
                return;
            }
            done[0] = true;
            verifyPending = false;
            Platform.runLater(() -> scene.removePostLayoutPulseListener(self[0]));
            verifyView();
        };
        scene.addPostLayoutPulseListener(self[0]);
    }

    /**
     * Allowed results: the current line on the bottom row; the transcript
     * still filling a window from the top left; or, after the user scrolled
     * it there, the current line anywhere on screen. Anything else is put
     * right: current line on the bottom row.
     */
    private void verifyView() {
        try {
            Bounds view = area.viewportOnScreen();
            if (view == null || view.getHeight() <= 0) {
                return;
            }
            double line = lineHeight();
            Optional<Bounds> caret = area.caretLineOnScreen();
            boolean visible = caret.isPresent()
                    && caret.get().getMinY() >= view.getMinY() - 1
                    && caret.get().getMaxY() <= view.getMaxY() + 1;
            boolean onBottomRow = visible && caret.get().getMaxY() >= view.getMaxY() - 1.5 * line;
            // Measured, not the scroll pane's estimated scroll position, which
            // still describes the text from before the latest edits.
            boolean fillingFromTop = visible && area.firstVisibleParToAllParIndex() == 0
                    && area.paragraphTopOnScreen(0).orElse(Double.NEGATIVE_INFINITY) >= view.getMinY() - 0.5;
            if (onBottomRow) {
                userPlaced = false;
                return;
            }
            if (visible && (userPlaced || fillingFromTop)) {
                return;
            }
            area.requestCaretAtBottom();
            area.layout();
        } catch (RuntimeException notLaidOut) {
            // Not on screen: nothing to check.
        }
    }

    /**
     * Following the end means following the input line: a caret left in the
     * history (a click there) goes back to the end, as in MATLAB.
     */
    private void caretToInput() {
        int start = inputStart.getAsInt();
        if (area.getCaretPosition() < start || area.getAnchor() < start) {
            area.moveTo(area.getLength());
        }
    }

    // =====================================================================
    // The tail paragraph
    // =====================================================================

    /**
     * Keeps {@value #TAIL_CLASS} on the last paragraph only. A change can
     * only move the last paragraph at or after its own position, so only the
     * paragraphs from just above it are looked at. The class does nothing
     * until the room is active.
     */
    private void markTail(int fromOffset) {
        int count = area.getParagraphs().size();
        if (count == 0) {
            return;
        }
        int last = count - 1;
        int offset = Math.max(0, Math.min(fromOffset, area.getLength()));
        int first = Math.max(0, area.offsetToPosition(offset, Bias.Backward).getMajor() - 1);
        for (int i = first; i <= last; i++) {
            Collection<String> style = area.getParagraph(i).getParagraphStyle();
            boolean has = style != null && style.contains(TAIL_CLASS);
            boolean want = i == last;
            if (has != want) {
                area.setParagraphStyle(i, want ? TAIL : PLAIN);
            }
        }
    }
}
