package ui;
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
import java.io.BufferedWriter;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.prefs.Preferences;

////////////////////////////////////////////////////////////////////
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableView;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.ToolBar;
import javafx.scene.control.TreeView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
//////////////////////////////////////////////////////////////////
/// Importing scripts 
import plot.PlotWindow;
import ui.editor.EditorFileInfo;
import ui.explorer.Main_Window;
import ui.managers.EditorManager;
import ui.managers.LanguageDesignManager;
import ui.ui_functions.IDEVariableService;
import ui.ui_functions.UI_MainProgramControl;
import ui.ui_functions.Variable;
/// 
////////////////////////////////////////////////////////////////// 
public class UI_Main {
    /* ========== CORE ========== */
    public Stage stage;
    public Scene scene;
    public Parent rootNode;
    public Path currentFolder;
    public PlotWindow plotWindow;
    /* ========== UI COMPONENTS ========== */
    public TreeView<Path> projectTree;
    public TabPane editorTabs;
    public javafx.scene.control.TextArea console;

    public Label footerFileLabel;
    public Label footerCursorLabel;
    public Label footerEncodingLabel;
    public Label footerStatusLabel;
    public Button footerErrorButton;
    public Button footerWarningButton;

    public ToggleButton themeToggle;

    public Image sunIcon;
    public Image moonIcon;

    public ImageView themeIconView;

    public String currentTheme;
    public String baseStylesheet;
    /* Track active theme stylesheet */
    public String currentThemeStylesheet;

    public Preferences prefs = Preferences.userNodeForPackage(UI_Main.class);

    public ToolBar homeTB, compileTB, jtagTB, commissionTB, preferencesTB, helpTB;
    public ToggleGroup ribbonGroup = new ToggleGroup();

    ///////* ========== PROGRAM EXECUTION ========== */
    public Process runningProcess;
    public boolean programRunning = false;
    public BufferedWriter processWriter;
    ///////* ===== TERMINAL CONTROL ===== */
    public int inputStart = 0;
    ///////* ===== VARIABLE EXPLORER ===== */
    public TableView<Variable> varTable;
    public final java.util.List<Variable> consoleVariables = new java.util.ArrayList<>(); 
    public UI_Main(Stage stage) {
        this.stage = stage;
        buildUI();
    }
    public Scene getScene() {
        return scene;
    }
    ///////* ================= BUILD UI ================= */

    private void buildUI() {
        Main_Window.buildUI(this);
        EditorManager.startUPITerminal(this);
    }
    ///////* ================= PROGRAM CONTROL ================= */
    public boolean isProgramRunning() {
        return programRunning;
    }

    public void setProgramRunning(boolean running) {
        programRunning = running;
    }

    public void setRunningProcess(Process process) {
        UI_MainProgramControl.setRunningProcess(this, process);
    }

    public void appendProcessOutput(String text) {
        UI_MainProgramControl.appendProcessOutput(this, text);
    }

    public void handleLocalConsoleInput(String input) {
        UI_MainProgramControl.handleLocalConsoleInput(this, input);
    }

    public void onProgramFinished() {
        UI_MainProgramControl.onProgramFinished(this);
    }

    public void stopProgram() {
        UI_MainProgramControl.stopProgram(this);
    }

    public boolean isRunningUpiTerminal() {
        return runningProcess != null && programRunning;
    }

    public void refreshVariablesForOpenTabs() {
        refreshVariablesForOpenTabs(null);
    }

    public void refreshVariablesForOpenTabs(Tab executedTab) {
        if (editorTabs == null || varTable == null)
            return;

        Tab sourceTab = executedTab;
        if (sourceTab == null || !isUpiTab(sourceTab)) {
            Tab selectedTab = editorTabs.getSelectionModel() != null ? editorTabs.getSelectionModel().getSelectedItem()
                    : null;
            if (selectedTab != null && isUpiTab(selectedTab)) {
                sourceTab = selectedTab;
            }
        }

        if (sourceTab == null) {
            varTable.getItems().setAll(consoleVariables);
            return;
        }

        List<Variable> existingVariables = new ArrayList<>(varTable.getItems());
        List<Variable> updatedVariables = IDEVariableService.collectVariablesFromTabsAndConsole(
                java.util.List.of(sourceTab), consoleVariables);
        List<Variable> mergedVariables = IDEVariableService.mergeVariableLists(existingVariables, updatedVariables);
        varTable.getItems().setAll(mergedVariables);
    }

    private boolean isUpiTab(Tab tab) {
        if (tab == null) {
            return false;
        }

        Object ud = tab.getUserData();
        if (ud instanceof EditorFileInfo info) {
            return info.path != null && LanguageDesignManager.isUpiFile(info.path);
        }
        return false;
    }

    public void addConsoleVariables(java.util.List<Variable> variables) {
        if (variables == null || variables.isEmpty())
            return;

        for (Variable variable : variables) {
            if (variable == null || variable.getName() == null || variable.getName().isBlank())
                continue;
            consoleVariables.removeIf(v -> v.getName().equals(variable.getName()));
            consoleVariables.add(variable);
        }

        refreshVariablesForOpenTabs();
    }

    public Path getCurrentFolder() {
        return currentFolder;
    }

    ///////* ================= VARIABLE DATA ================= */

    public List<String> getVariableNames() {
        return IDEVariableService.getVariableNames(varTable);
    }

    public List<Double> getVariableValues(String name) {
        return IDEVariableService.getVariableValues(varTable, name);
    }
    ///////* ================= UI HELPERS ================= */
    public HBox buildFooter() {
        return Main_Window.buildFooter(this);
    }

    public Image loadIcon(String path) {
        return Main_Window.loadIcon(this, path);
    }

}
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////