package ui;

import java.io.BufferedWriter;
import java.nio.file.Path;
import java.util.List;
import java.util.prefs.Preferences;

import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.ToolBar;
import javafx.scene.control.TreeTableView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import plot.PlotWindow;
import ui.cli.CLI_Main;
import ui.explorer.Main_Window;
import ui.ui_functions.IDEVariableService;
import ui.ui_functions.UI_MainProgramControl;
import ui.ui_functions.Variable;

/**
 * The IDE controller: holds the main window's shared UI components and
 * process state, and delegates behaviour to the specialised classes.
 */
public class UI_Main {

    // =====================================================================
    // Core
    // =====================================================================
    public Stage stage;
    public Scene scene;
    public Parent rootNode;
    public Path currentFolder;
    public PlotWindow plotWindow;

    // =====================================================================
    // UI components
    // =====================================================================
    public TreeTableView<Path> projectTree;
    public TabPane editorTabs;
    public TextArea console;

    public Label footerFileLabel;
    public Label footerCursorLabel;
    public Label footerEncodingLabel;
    public Label footerStatusLabel;
    public Button footerErrorButton;
    public Button footerWarningButton;

    public ToggleButton themeToggle;

    public Image sunIcon;
    public Image moonIcon;

    public ImageView themeIconView;

    public String currentTheme;
    public String baseStylesheet;
    /** The active theme stylesheet. */
    public String currentThemeStylesheet;

    public Preferences prefs = Preferences.userNodeForPackage(UI_Main.class);

    public ToolBar homeTB, compileTB, jtagTB, commissionTB, preferencesTB, helpTB;
    public ToggleGroup ribbonGroup = new ToggleGroup();

    // =====================================================================
    // Program execution
    // =====================================================================
    public Process runningProcess;
    public boolean programRunning = false;
    public BufferedWriter processWriter;

    // =====================================================================
    // Terminal control
    // =====================================================================
    /** Offset just past the current ">> " prompt; everything below is frozen. */
    public int inputStart = 0;

    // =====================================================================
    // Variable Explorer
    // =====================================================================
    /**
     * The Explorer table. Its rows are owned by
     * {@code ui.ui_functions.WorkspaceStore} -- do not call {@code setItems} on
     * it anywhere else, or duplicate rows come straight back.
     */
    public TableView<Variable> varTable;

    public UI_Main(Stage stage) {
        this.stage = stage;
        buildUI();
    }

    public Scene getScene() {
        return scene;
    }

    // =====================================================================
    // Build UI
    // =====================================================================

    private void buildUI() {
        Main_Window.buildUI(this);
        CLI_Main.start(this);
    }

    // =====================================================================
    // Program control
    // =====================================================================

    public boolean isProgramRunning() {
        return programRunning;
    }

    public void setProgramRunning(boolean running) {
        programRunning = running;
    }

    public void setRunningProcess(Process process) {
        UI_MainProgramControl.setRunningProcess(this, process);
    }

    public void appendProcessOutput(String text) {
        UI_MainProgramControl.appendProcessOutput(this, text);
    }

    /**
     * Handles a line typed while no interpreter is attached. Variables are
     * never inferred from typed text, so all this does is return the prompt.
     *
     * @param input the typed line (not interpreted)
     */
    public void handleLocalConsoleInput(String input) {
        CLI_Main.appendPrompt();
    }

    public void onProgramFinished() {
        UI_MainProgramControl.onProgramFinished(this);
    }

    public void stopProgram() {
        UI_MainProgramControl.stopProgram(this);
    }

    public boolean isRunningUpiTerminal() {
        return runningProcess != null && programRunning;
    }

    public Path getCurrentFolder() {
        return currentFolder;
    }

    // =====================================================================
    // Variable data
    // =====================================================================

    public List<String> getVariableNames() {
        return IDEVariableService.getVariableNames(varTable);
    }

    public List<Double> getVariableValues(String name) {
        return IDEVariableService.getVariableValues(varTable, name);
    }

    // =====================================================================
    // UI helpers
    // =====================================================================

    public HBox buildFooter() {
        return Main_Window.buildFooter(this);
    }

    public Image loadIcon(String path) {
        return Main_Window.loadIcon(this, path);
    }
}
