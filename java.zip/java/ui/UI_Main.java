package ui;
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
import java.io.BufferedWriter;
import java.nio.file.Path;
import java.util.List;
import java.util.prefs.Preferences;

////////////////////////////////////////////////////////////////////
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableView;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.ToolBar;
import javafx.scene.control.TreeTableView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
//////////////////////////////////////////////////////////////////
/// Importing scripts
import plot.PlotWindow;
import ui.explorer.Main_Window;
import ui.ui_functions.IDEVariableService;
import ui.ui_functions.UI_MainProgramControl;
import ui.ui_functions.Variable;
///
//////////////////////////////////////////////////////////////////
public class UI_Main {
    /* ========== CORE ========== */
    public Stage stage;
    public Scene scene;
    public Parent rootNode;
    public Path currentFolder;
    public PlotWindow plotWindow;
    /* ========== UI COMPONENTS ========== */
    public TreeTableView<Path> projectTree;
    public TabPane editorTabs;
    public javafx.scene.control.TextArea console;

    public Label footerFileLabel;
    public Label footerCursorLabel;
    public Label footerEncodingLabel;
    public Label footerStatusLabel;
    public Button footerErrorButton;
    public Button footerWarningButton;

    public ToggleButton themeToggle;

    public Image sunIcon;
    public Image moonIcon;

    public ImageView themeIconView;

    public String currentTheme;
    public String baseStylesheet;
    /* Track active theme stylesheet */
    public String currentThemeStylesheet;

    public Preferences prefs = Preferences.userNodeForPackage(UI_Main.class);

    public ToolBar homeTB, compileTB, jtagTB, commissionTB, preferencesTB, helpTB;
    public ToggleGroup ribbonGroup = new ToggleGroup();

    ///////* ========== PROGRAM EXECUTION ========== */
    public Process runningProcess;
    public boolean programRunning = false;
    public BufferedWriter processWriter;
    ///////* ===== TERMINAL CONTROL ===== */
    /** Offset just past the current ">> " prompt; everything below is frozen. */
    public int inputStart = 0;
    ///////* ===== VARIABLE EXPLORER ===== */
    /**
     * The Explorer table. Its rows are owned by
     * {@code ui.ui_functions.WorkspaceStore} — do not call {@code setItems} on
     * it anywhere else, or duplicate rows come straight back.
     */
    public TableView<Variable> varTable;

    /**
     * @deprecated The interpreter's workspace is the only variable source now.
     *             Kept as an empty list so older call sites compile.
     */
    @Deprecated
    public final java.util.List<Variable> consoleVariables = new java.util.ArrayList<>();

    public UI_Main(Stage stage) {
        this.stage = stage;
        buildUI();
    }

    public Scene getScene() {
        return scene;
    }
    ///////* ================= BUILD UI ================= */

    private void buildUI() {
        Main_Window.buildUI(this);
        ui.cli.CLI_Main.start(this);
    }
    ///////* ================= PROGRAM CONTROL ================= */

    public boolean isProgramRunning() {
        return programRunning;
    }

    public void setProgramRunning(boolean running) {
        programRunning = running;
    }

    public void setRunningProcess(Process process) {
        UI_MainProgramControl.setRunningProcess(this, process);
    }

    public void appendProcessOutput(String text) {
        UI_MainProgramControl.appendProcessOutput(this, text);
    }

    public void handleLocalConsoleInput(String input) {
        UI_MainProgramControl.handleLocalConsoleInput(this, input);
    }

    public void onProgramFinished() {
        UI_MainProgramControl.onProgramFinished(this);
    }

    public void stopProgram() {
        UI_MainProgramControl.stopProgram(this);
    }

    public boolean isRunningUpiTerminal() {
        return runningProcess != null && programRunning;
    }

    /**
     * @deprecated The Explorer is refreshed from {@code variables.txt} when the
     *             interpreter's prompt returns. Rebuilding rows per open tab is
     *             what caused a variable to appear once per tab.
     */
    @Deprecated
    public void refreshVariablesForOpenTabs() {
        // Intentionally a no-op.
    }

    /**
     * @param executedTab ignored
     * @deprecated See {@link #refreshVariablesForOpenTabs()}.
     */
    @Deprecated
    public void refreshVariablesForOpenTabs(Tab executedTab) {
        // Intentionally a no-op.
    }

    /**
     * @param variables ignored
     * @deprecated Variables are never inferred from console text.
     */
    @Deprecated
    public void addConsoleVariables(java.util.List<Variable> variables) {
        // Intentionally a no-op.
    }

    public Path getCurrentFolder() {
        return currentFolder;
    }

    ///////* ================= VARIABLE DATA ================= */

    public List<String> getVariableNames() {
        return IDEVariableService.getVariableNames(varTable);
    }

    public List<Double> getVariableValues(String name) {
        return IDEVariableService.getVariableValues(varTable, name);
    }
    ///////* ================= UI HELPERS ================= */

    public HBox buildFooter() {
        return Main_Window.buildFooter(this);
    }

    public Image loadIcon(String path) {
        return Main_Window.loadIcon(this, path);
    }
}
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
