package ui.design;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.function.DoubleSupplier;

import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.Skin;
import javafx.scene.layout.Region;
import javafx.stage.WindowEvent;

/**
 * The one way a pop-up menu gets the application's menu look.
 *
 * <p>
 * Every right-click menu, drop-down and submenu is the same plain box: square
 * corners, a hairline outline, one fixed width ({@link Dim.Menu#WIDTH}), a
 * height that follows the number of entries, one neutral grey under the
 * pointer, one font. Build the menu as usual, then pass it through here
 * before it is first shown:
 * </p>
 *
 * <pre>
 *   ContextMenu menu = MenuStyle.apply(new ContextMenu());
 * </pre>
 *
 * <h3>What it does</h3>
 * <ol>
 * <li>Adds {@link #MENU_CLASS}. The colours ({@code surfaces.css}, section 7,
 * from the {@code -astra-menu-*} palette tokens) and the geometry
 * ({@link DesignStylesheet}, MENUS, from {@link Dim.Menu}) key on it, and on
 * {@code .astra-menu .context-menu} for the submenus. This must happen before
 * the first show: {@code ContextMenuSkin} copies the menu's style classes onto
 * its content once, when the skin is created.</li>
 * <li>Gives the pop-up's content the palette, the surfaces sheet and the
 * generated sheet directly ({@link SurfaceSheets#attach}). A sheet on a node
 * outranks every scene sheet, so no feature sheet, Custom layout sheet or
 * leftover {@code .context-menu} rule can repaint a menu, whichever window
 * or panel opened it. The sheets are refreshed on every opening, so a menu
 * kept between openings follows a change of theme or font size.</li>
 * <li>Keeps one menu on screen at a time: opening a menu closes the one
 * still open, so repeated right-clicks never stack menus.</li>
 * <li>Pins shortcuts and submenu chevrons to the right edge. JavaFX puts that
 * column just after the longest name, so a menu widened to the common width
 * would show "Ctrl+X" floating in the middle. When the menu opens, the name
 * column is widened by exactly the room the minimum width added, which moves
 * the shortcut column flush right. Measured afresh on every opening, before
 * the first frame is drawn.</li>
 * </ol>
 *
 * <h3>Width</h3>
 * <p>
 * {@link Dim.Menu#WIDTH} is a floor: entries that need more room widen the
 * menu rather than being cut. {@link #apply(ContextMenu, DoubleSupplier)}
 * asks for more than the floor (the breadcrumb's run-folder list is as wide
 * as the path box).
 * </p>
 *
 * <h3>Icons</h3>
 * <p>
 * Nothing here adds an icon column. A menu has one only when its entries
 * carry graphics, which only the File Explorer's menus (and the folder lists
 * of the breadcrumb) do.
 * </p>
 *
 * <h3>Do not</h3>
 * <ul>
 * <li>give a menu a style class of its own with colours, paddings or radii;</li>
 * <li>{@code setStyle} a font on a menu or its entries -- an inline style beats
 * every sheet and the menu stops matching the others;</li>
 * <li>{@code setMinWidth} / {@code setPrefWidth} on a menu's content -- the
 * generated sheet's minimum overrides it; pass a width supplier instead.</li>
 * </ul>
 */
public final class MenuStyle {

    /** The style class every menu carries. */
    public static final String MENU_CLASS = "astra-menu";

    /**
     * Added by {@link #applyCompact}: the menu is at least
     * {@link Dim.Menu#COMPACT_WIDTH} wide instead of the common width.
     */
    public static final String COMPACT_CLASS = "astra-menu-compact";

    /**
     * Added by {@link #applyNarrow}: the menu is at least
     * {@link Dim.Menu#NARROW_WIDTH} wide (90 % of the common width).
     */
    public static final String NARROW_CLASS = "astra-menu-narrow";

    /**
     * Added by {@link #applyShort}: the menu is at least
     * {@link Dim.Menu#SHORT_WIDTH} wide (80 % of the common width).
     */
    public static final String SHORT_CLASS = "astra-menu-short";

    /**
     * Added by {@link #applySlim}: the menu is at least
     * {@link Dim.Menu#SLIM_WIDTH} wide (70 % of the common width).
     */
    public static final String SLIM_CLASS = "astra-menu-slim";

    /** Menu property: set once the handlers are installed. */
    private static final String INSTALLED_KEY = MenuStyle.class.getName() + ".installed";

    /** Menu property: the optional {@link DoubleSupplier} for a wider menu. */
    private static final String WIDTH_KEY = MenuStyle.class.getName() + ".width";

    /** Style class JavaFX gives the shortcut label of an entry. */
    private static final String ACCELERATOR_CLASS = "accelerator-text";

    /** Style class of one entry's row inside the menu. */
    private static final String ITEM_CLASS = "menu-item";

    /**
     * The menu on screen now, if any. Held weakly, so a closed menu that is
     * thrown away is not kept alive by this field.
     */
    private static WeakReference<ContextMenu> openMenu = new WeakReference<>(null);

    private MenuStyle() {
    }

    /**
     * The menu font as CSS declarations: the UI family (Segoe UI on Windows)
     * at the File Explorer row size and weight. The generated sheet uses it
     * for every menu.
     *
     * @return {@code -fx-font-family}, {@code -fx-font-size}, {@code -fx-font-weight}
     */
    public static String fontCss() {
        return "-fx-font-family: " + Typography.familyCss(Typography.uiFamily()) + "; "
                + Typography.css(Typography.Role.DIRECTORY_ROW);
    }

    /**
     * Gives a menu the application's menu look. Safe to call more than once.
     *
     * @param menu the menu, before it is first shown
     * @return the same menu, for chaining
     */
    public static ContextMenu apply(ContextMenu menu) {
        return apply(menu, null);
    }

    /**
     * Gives a menu the application's menu look at half the common width
     * ({@link Dim.Menu#COMPACT_WIDTH}). The one exception to the common
     * width, for a short list of short entries: the File Explorer's Info
     * drop-down. Everything else about the menu is the same.
     *
     * @param menu the menu, before it is first shown
     * @return the same menu, for chaining
     */
    public static ContextMenu applyCompact(ContextMenu menu) {
        if (menu == null) {
            return null;
        }
        if (!menu.getStyleClass().contains(COMPACT_CLASS)) {
            menu.getStyleClass().add(COMPACT_CLASS);
        }
        return apply(menu, null);
    }

    /**
     * Gives a menu the application's menu look at 90 % of the common width
     * ({@link Dim.Menu#NARROW_WIDTH}): the Home ribbon's New / Open / Save
     * drop-downs. Everything else about the menu is the same.
     *
     * @param menu the menu, before it is first shown
     * @return the same menu, for chaining
     */
    public static ContextMenu applyNarrow(ContextMenu menu) {
        if (menu == null) {
            return null;
        }
        if (!menu.getStyleClass().contains(NARROW_CLASS)) {
            menu.getStyleClass().add(NARROW_CLASS);
        }
        return apply(menu, null);
    }

    /**
     * Gives a menu the application's menu look at 80 % of the common width
     * ({@link Dim.Menu#SHORT_WIDTH}): the editor's right-click menu.
     * Everything else about the menu is the same.
     *
     * @param menu the menu, before it is first shown
     * @return the same menu, for chaining
     */
    public static ContextMenu applyShort(ContextMenu menu) {
        if (menu == null) {
            return null;
        }
        if (!menu.getStyleClass().contains(SHORT_CLASS)) {
            menu.getStyleClass().add(SHORT_CLASS);
        }
        return apply(menu, null);
    }

    /**
     * Gives a menu the application's menu look at 70 % of the common width
     * ({@link Dim.Menu#SLIM_WIDTH}): the Command Window's three-dot menu.
     * Everything else about the menu is the same.
     *
     * @param menu the menu, before it is first shown
     * @return the same menu, for chaining
     */
    public static ContextMenu applySlim(ContextMenu menu) {
        if (menu == null) {
            return null;
        }
        if (!menu.getStyleClass().contains(SLIM_CLASS)) {
            menu.getStyleClass().add(SLIM_CLASS);
        }
        return apply(menu, null);
    }

    /**
     * Gives a menu the application's menu look and asks for a width other
     * than the common one. The larger of the two is used; a later call
     * replaces an earlier supplier.
     *
     * @param menu     the menu, before it is first shown
     * @param minWidth the outer width wanted, read on every opening; may be
     *                 null for the common width
     * @return the same menu, for chaining
     */
    public static ContextMenu apply(ContextMenu menu, DoubleSupplier minWidth) {
        if (menu == null) {
            return null;
        }
        if (!menu.getStyleClass().contains(MENU_CLASS)) {
            menu.getStyleClass().add(MENU_CLASS);
        }
        if (minWidth != null) {
            menu.getProperties().put(WIDTH_KEY, minWidth);
        }
        if (menu.getProperties().containsKey(INSTALLED_KEY)) {
            return menu;
        }
        menu.getProperties().put(INSTALLED_KEY, Boolean.TRUE);

        // A menu already shown once has its skin: give the content the class
        // and the sheets now, as the skin listener below would have.
        Skin<?> existing = menu.getSkin();
        if (existing != null) {
            prepare(existing.getNode());
        }
        menu.skinProperty().addListener((obs, was, skin) -> {
            if (skin != null) {
                prepare(skin.getNode());
            }
        });

        // Added, not set: callers keep their own setOnShowing / setOnShown.
        // Handlers added this way run before the onShown property handler, so
        // a caller that positions the menu on shown (the Info menu lines its
        // right edge up with the column) sees the final width.
        EventHandler<WindowEvent> onShowing = e -> {
            closeOthers(menu);
            refreshSheets(menu);
        };
        EventHandler<WindowEvent> onShown = e -> fitWidth(menu);
        EventHandler<WindowEvent> onHidden = e -> {
            if (openMenu.get() == menu) {
                openMenu = new WeakReference<>(null);
            }
        };
        menu.addEventHandler(WindowEvent.WINDOW_SHOWING, onShowing);
        menu.addEventHandler(WindowEvent.WINDOW_SHOWN, onShown);
        menu.addEventHandler(WindowEvent.WINDOW_HIDDEN, onHidden);
        return menu;
    }

    // =====================================================================
    // One menu at a time
    // =====================================================================

    /**
     * Closes whatever menu is still open before another one opens.
     *
     * <p>
     * Several panels (the Variable Explorer's rows, the Code Bot's messages)
     * build a fresh menu on every right-click and show it. A secondary click
     * does not always auto-hide the menu already on screen, so a second
     * right-click left the first menu standing and stacked another on top.
     * Doing it here covers every menu, whoever builds it. Submenus are not
     * affected: JavaFX opens those itself, not through this class.
     * </p>
     */
    private static void closeOthers(ContextMenu menu) {
        ContextMenu previous = openMenu.get();
        if (previous != null && previous != menu && previous.isShowing()) {
            previous.hide();
        }
        openMenu = new WeakReference<>(menu);
    }

    // =====================================================================
    // Sheets
    // =====================================================================

    private static void prepare(Node content) {
        if (!(content instanceof Parent root)) {
            return;
        }
        if (!root.getStyleClass().contains(MENU_CLASS)) {
            root.getStyleClass().add(MENU_CLASS);
        }
        SurfaceSheets.attach(root);
    }

    /** Re-attaches, so a kept menu follows the current theme and font size. */
    private static void refreshSheets(ContextMenu menu) {
        Skin<?> skin = menu.getSkin();
        if (skin != null && skin.getNode() instanceof Parent root) {
            SurfaceSheets.attach(root);
        }
    }

    // =====================================================================
    // Width
    // =====================================================================

    /**
     * Makes the menu at least the common width with its shortcut column at
     * the right edge.
     *
     * <p>
     * The generated sheet already holds the content at the common minimum;
     * what it cannot do is move the shortcut column, which JavaFX places
     * just after the widest name. So the names' column is given the room the
     * minimum added: every name label is set to the widest name plus that
     * room. The labels are left-aligned, so nothing moves but the column
     * after them. The labels are reset first, so the natural width is read
     * fresh each time and the extra never compounds.
     * </p>
     */
    private static void fitWidth(ContextMenu menu) {
        Skin<?> skin = menu.getSkin();
        if (skin == null || !(skin.getNode() instanceof Region content)) {
            return;
        }

        List<Label> names = nameLabels(content);
        for (Label name : names) {
            name.setPrefWidth(Region.USE_COMPUTED_SIZE);
        }
        content.applyCss();

        double target = baseWidth(menu);
        Object wanted = menu.getProperties().get(WIDTH_KEY);
        if (wanted instanceof DoubleSupplier supplier) {
            double w = supplier.getAsDouble();
            if (w > target) {
                target = w;
            }
        }

        if (!names.isEmpty()) {
            double natural = content.prefWidth(-1);
            double extra = Math.floor(target - natural);
            if (extra >= 1) {
                double widest = 0;
                for (Label name : names) {
                    widest = Math.max(widest, name.prefWidth(-1));
                }
                double grown = Math.ceil(widest + extra);
                for (Label name : names) {
                    name.setPrefWidth(grown);
                }
            }
        }

        // Lay the pop-up out now, so its window takes the width in this pulse
        // rather than the next one (WINDOW_SHOWN fires inside show(), before
        // the first frame is drawn).
        Scene scene = menu.getScene();
        Parent root = (scene != null) ? scene.getRoot() : null;
        if (root != null) {
            root.applyCss();
            root.layout();
        }
    }

    /** The width a menu is fitted to: compact, narrow, short, slim or the common one. */
    private static double baseWidth(ContextMenu menu) {
        if (menu.getStyleClass().contains(COMPACT_CLASS)) {
            return Dim.Menu.COMPACT_WIDTH;
        }
        if (menu.getStyleClass().contains(NARROW_CLASS)) {
            return Dim.Menu.NARROW_WIDTH;
        }
        if (menu.getStyleClass().contains(SHORT_CLASS)) {
            return Dim.Menu.SHORT_WIDTH;
        }
        if (menu.getStyleClass().contains(SLIM_CLASS)) {
            return Dim.Menu.SLIM_WIDTH;
        }
        return Dim.Menu.WIDTH;
    }

    /**
     * The name label of each plain entry: a {@code Label} sitting directly in
     * an entry's row that is not its shortcut. Custom rows (the Command
     * Window's, the suggestion filters) hold their own layout and are left
     * alone; so are separators.
     */
    private static List<Label> nameLabels(Region content) {
        List<Label> out = new ArrayList<>();
        for (Node row : content.lookupAll("." + ITEM_CLASS)) {
            if (!(row instanceof Parent parent)) {
                continue;
            }
            for (Node child : parent.getChildrenUnmodifiable()) {
                if (child instanceof Label label
                        && !label.getStyleClass().contains(ACCELERATOR_CLASS)) {
                    out.add(label);
                }
            }
        }
        return out;
    }
}
