package ui.design.section_dims;

/**
 * The Settings band's compartment shares.
 *
 * <pre>
 *  | Visuals | Plots | Networks |              free               |
 *  |    3    |   1   |    1     |               11                |
 *  |&lt;------------------------ 16 units ------------------------&gt;|
 * </pre>
 *
 * <p>
 * Same 16-unit grid as Home, so one unit is the same width on both tabs and a
 * single-button compartment here lines up with a single-button compartment
 * there. Everything the bands share (row height, icon size, divider, inset)
 * stays in {@link ToolBand_dim}.
 * </p>
 *
 * <p>
 * Three dividers are drawn, one after each compartment including Networks, so
 * the free space is fenced off, exactly as Signals fences off its Set button.
 * </p>
 */
public class SettingsBand_dim {

    /** The band width is divided into this many equal units. */
    public static final double TOTAL_UNITS = 16;

    /** Visuals: Layout, Theme, Syntax. */
    public static final double UNITS_VISUALS = 3;

    /** Plots: Plot Setup. */
    public static final double UNITS_PLOTS = 1;

    /** Networks: Net Setup. */
    public static final double UNITS_NETWORKS = 1;

    /** Units consumed by the three compartments. Computed, not stated. */
    public static final double USED_UNITS = UNITS_VISUALS + UNITS_PLOTS + UNITS_NETWORKS;

    /** Units left free at the trailing edge. */
    public static final double FREE_UNITS = TOTAL_UNITS - USED_UNITS;

    /** Dividers drawn: one after each of the three compartments. */
    public static final int SEPARATOR_COUNT = 3;

    protected SettingsBand_dim() {
    }
}
