package ui.design.section_dims;

import static ui.design.UIScale.px;
import static ui.design.UIScale.pxi;

/**
 * Geometry of the IDE's own windows and dialogs: the frameless, square
 * windows built by {@link ui.design.AstraFrame} (CLI History, Reset CLI
 * History, and any window added later).
 *
 * <h3>Why frameless</h3>
 * <p>
 * Windows 11 rounds the corners of every window it frames, whatever the CSS
 * says. An {@code AstraFrame} draws its own title strip and outline instead,
 * so it is a plain square box with a hairline edge, like the menus
 * ({@link Menu_dim}).
 * </p>
 * <p>
 * Colours are not here: they are tokens in {@code themes/shared/palette_*.css}
 * used by {@code surfaces.css} section 8. The title strip takes the panels'
 * active title colour, including the Custom layout's base colour.
 * </p>
 */
public class Frame_dim {

    // =====================================================================
    // FRAME
    // =====================================================================

    /** The outline round the whole window. Hairline, unscaled. */
    public static final double BORDER = 1;

    /** Corner rounding: none, anywhere in the frame. */
    public static final double RADIUS = 0;

    /**
     * How close to an edge the pointer must be to resize a resizable window.
     * Wider than the 1 px outline, so the edge is easy to catch.
     */
    public static final double RESIZE_MARGIN = px(5);

    /** Smallest size a resizable window can be dragged to. */
    public static final double MIN_WIDTH = px(320);

    /** Smallest size a resizable window can be dragged to. */
    public static final double MIN_HEIGHT = px(220);

    // =====================================================================
    // TITLE STRIP
    // =====================================================================
    //
    // The template is the panels' own title strip (TitleBar_dim): the same
    // height, the same leading padding, glyphs a step under the panel strip's
    // icons. A window's strip and a panel's strip therefore read as one
    // family, and the minimise / maximise / close marks stay small.

    /** Height of the title strip: the panel strip's height. */
    public static final double TITLE_HEIGHT = TitleBar_dim.HEIGHT;

    /** Space before the window icon: the panel strip's leading padding. */
    public static final double TITLE_PAD_LEFT = TitleBar_dim.PAD_LEFT;

    /** Gap between the icon and the title: the panel strip's spacing. */
    public static final double TITLE_SPACING = TitleBar_dim.CONTENT_SPACING;

    /** Edge of the window icon: the panel strip's three-dot glyph size. */
    public static final double TITLE_ICON_SIZE = TitleBar_dim.DOTS_ICON_SIZE;

    /**
     * Width of each title-strip button (minimise, maximise, close); height is
     * the strip's. Wider than tall, as a window's caption buttons are, but
     * scaled to the 26 px panel strip rather than the operating system's.
     */
    public static final double TITLE_BUTTON_WIDTH = pxi(36);

    /**
     * Edge of the drawn minimise dash, maximise box and close cross: a step
     * under the panel strip's collapse triangle ({@link TitleBar_dim#CARET_ICON_SIZE}).
     */
    public static final double TITLE_GLYPH_SIZE = pxi(8);

    /** Stroke of those three marks. Hairline, unscaled. */
    public static final double TITLE_GLYPH_STROKE = 1;

    // =====================================================================
    // BODY
    // =====================================================================

    /** Padding inside the body, all round. */
    public static final double BODY_PAD = px(12);

    /** Gap between stacked parts of the body (heading, message, list). */
    public static final double BODY_SPACING = px(8);

    /** Width of a dialog (Reset CLI History); its height follows the text. */
    public static final double DIALOG_WIDTH = px(440);

    // =====================================================================
    // BUTTONS
    // =====================================================================

    /** Gap between two buttons in a row. */
    public static final double BUTTON_GAP = px(8);

    /** Vertical padding of a button. */
    public static final double BUTTON_PAD_V = px(4);

    /** Horizontal padding of a button. */
    public static final double BUTTON_PAD_H = px(14);

    /** Narrowest a button may be, so OK and Cancel are not tiny. */
    public static final double BUTTON_MIN_WIDTH = px(76);

    /** The button outline. Hairline, unscaled. */
    public static final double BUTTON_BORDER = 1;

    protected Frame_dim() {
    }
}
