package ui.design.section_dims;

import javafx.geometry.Insets;

import static ui.design.UIScale.px;

/**
 * The vertical rail a collapsed panel shows instead of its title strip.
 *
 * <p>
 * The rail's width lives in {@link Explorer_dim} with the panel it belongs to;
 * what is here is the rail's own internal geometry.
 * </p>
 */
public class Rail_dim {

    /** Rail padding, top edge. */
    public static final double PAD_TOP = px(4);

    /** Rail padding, trailing edge. */
    public static final double PAD_RIGHT = px(0);

    /** Rail padding, bottom edge. */
    public static final double PAD_BOTTOM = px(6);

    /** Rail padding, leading edge. */
    public static final double PAD_LEFT = px(0);

    /** Hairline down the rail's trailing edge. Unscaled. */
    public static final double SIDE_BORDER = 1;

    /**
     * @return the rail's padding as an {@link Insets}
     */
    public static Insets padding() {
        return new Insets(PAD_TOP, PAD_RIGHT, PAD_BOTTOM, PAD_LEFT);
    }

    protected Rail_dim() {
    }
}
