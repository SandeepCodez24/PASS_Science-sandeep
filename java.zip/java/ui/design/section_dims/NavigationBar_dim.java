package ui.design.section_dims;

import static ui.design.UIScale.px;
import static ui.design.UIScale.pxi;

/**
 * The Navigation Bar: the six icon buttons at the left of the quick-access row.
 *
 * <pre>
 *  [Home] [&lt;-] [-&gt;] [Up] | [Cloud] [Root|v] | ( breadcrumb ... ) | [^]
 * </pre>
 *
 * <h3>The height reduction</h3>
 * <p>
 * The whole row used to be {@link #BASE_HEIGHT} tall. It is now
 * {@link #HEIGHT_REDUCTION} shorter, and the pixels that frees up are handed to
 * the tool band as {@link #SAVED_HEIGHT}. {@code ToolBand_dim.ITEM_HEIGHT}
 * reads that constant, so the two rows always add back up to the same total and
 * the explorer panels below do not move.
 * </p>
 * <p>
 * This file owns the row height because the navigation buttons are the tallest
 * thing in it. {@link BreadcrumbBar_dim} derives its own box height from the
 * same reduction ratio.
 * </p>
 */
public class NavigationBar_dim {

    // =====================================================================
    // Row height
    // =====================================================================

    /** Row height before the reduction, at scale 1.0. A design reference, not a length in use. */
    public static final double BASE_HEIGHT = 36;

    /** Fraction removed from the row. A ratio, so not scaled. */
    public static final double HEIGHT_REDUCTION = 0.20;

    /** What remains of the row after the reduction. Not scaled; multiply design values by it. */
    public static final double KEEP_RATIO = 1.0 - HEIGHT_REDUCTION;

    /** Height of the whole quick-access row as designed: 36 becomes 29 at scale 1.0. Never less. */
    public static final double BASE_HEIGHT_KEPT = pxi(BASE_HEIGHT * KEEP_RATIO);

    /**
     * Height of the whole quick-access row in force: {@link #BASE_HEIGHT_KEPT},
     * or more when the breadcrumb's path box needs it for a larger UI font
     * size. Recomputed by {@link #recomputeTextHeights()}.
     */
    public static double HEIGHT;

    /**
     * Height given back to the tool band. Derived from the DESIGNED row height,
     * not the live one, so a larger font growing this row never takes height
     * away from the band.
     */
    public static final double SAVED_HEIGHT = pxi(BASE_HEIGHT) - BASE_HEIGHT_KEPT;

    /** Row padding, top and bottom. */
    public static final double PAD_V = px(2);

    /** Row padding, leading and trailing. */
    public static final double PAD_H = px(6);

    /** Gap between items in the row. */
    public static final double ITEM_SPACING = px(2);

    /**
     * The thin line along the bottom of the whole row, separating it from the
     * panels below, MATLAB-style. A quarter point is about a third of a pixel,
     * and nothing thinner than one pixel can be drawn, so this is the thinnest
     * line possible. Hairline, unscaled; its colour is in the theme files.
     * Inside {@link #HEIGHT}, so the row does not grow.
     */
    public static final double BOTTOM_LINE = 1;

    // =====================================================================
    // Buttons
    // =====================================================================

    /** Square hit area of a navigation button. Was 28. */
    public static final double BUTTON_SIZE = pxi(28 * KEEP_RATIO);

    /** Edge length of the glyph inside a navigation button. Was 22. */
    public static final double ICON_SIZE = pxi(22 * KEEP_RATIO);

    /** Padding inside a navigation button. */
    public static final double BUTTON_PADDING = px(2);

    /** Corner rounding of a navigation button's hover fill. */
    public static final double BUTTON_RADIUS = px(3);

    // =====================================================================
    // Root split control: [icon | v]
    // =====================================================================

    /** Width of the drop-down zone to the right of the Root icon. */
    public static final double SPLIT_ARROW_WIDTH = pxi(12);

    /** Edge length of the small chevron in the drop-down zone. */
    public static final double SPLIT_ARROW_ICON_SIZE = pxi(8);

    /** Outline of the split control on hover. Hairline, unscaled. */
    public static final double SPLIT_BORDER = 1;

    /** Edge length of the icons shown inside the Root and Cloud menus. */
    public static final double MENU_ICON_SIZE = pxi(16);

    // =====================================================================
    // Height that follows the UI font size
    // =====================================================================

    static {
        recomputeTextHeights();
    }

    /**
     * Recomputes {@link #HEIGHT}: the designed row, or the breadcrumb's path
     * box plus this row's padding and bottom line, whichever is taller. Call
     * after {@link BreadcrumbBar_dim#recomputeTextHeights()}.
     */
    public static void recomputeTextHeights() {
        double forPath = BreadcrumbBar_dim.BOX_HEIGHT + 2 * PAD_V + BOTTOM_LINE;
        HEIGHT = Math.max(BASE_HEIGHT_KEPT, Math.ceil(forPath));
    }

    protected NavigationBar_dim() {
    }
}
