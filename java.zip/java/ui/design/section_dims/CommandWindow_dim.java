package ui.design.section_dims;

import static ui.design.UIScale.px;
import static ui.design.UIScale.pxi;

/**
 * The Command Window: the three-dot options menu on its title strip
 * (New Window / Minimize / Copy / Stop), and the console's padding below the
 * strip.
 *
 * <pre>
 *   Command Window                                   [:]
 *                                       +---------------------+
 *                                       | New Window          |
 *                                       | Minimize            |
 *                                       | Standalone CLI      |
 *                                       |---------------------|
 *                                       | Copy                |
 *                                       | Stop                |
 *                                       +---------------------+
 * </pre>
 *
 * <h3>Width</h3>
 * <p>
 * The menu used to size itself to its longest entry at the inherited
 * {@code BASE} font with Modena's default insets. It is now
 * {@link #OPTIONS_MENU_WIDTH_SCALE} times that width -- 30% longer than it
 * was -- while its text drops to the breadcrumb bar's size
 * ({@code Typography.Role.BREADCRUMB_SEGMENT}). The baseline is measured from
 * the entry labels at run time, so adding an entry keeps the ratio.
 * </p>
 *
 * <p>
 * Only the Command Window's menu uses these values. The File Explorer and
 * Variable Explorer menus built by {@code PanelTitleBar} keep their defaults.
 * </p>
 *
 * <p>
 * The console's own right-click menu still keeps its numbers in
 * {@code ConsoleController}; they can move here later.
 * </p>
 */
public class CommandWindow_dim {

    // =====================================================================
    // Three-dot options menu
    // =====================================================================

    /** Width of the menu relative to its old natural width. A ratio, unscaled. */
    public static final double OPTIONS_MENU_WIDTH_SCALE = 1.30;

    /**
     * Modena's {@code .context-menu} padding, in em of the old font. Part of
     * the baseline only; the menu's real padding is not changed.
     */
    public static final double OPTIONS_MENU_BASE_PAD_EM = 0.333333;

    /**
     * Modena's horizontal {@code .menu-item} padding, in em of the old font.
     * Part of the baseline only.
     */
    public static final double OPTIONS_MENU_BASE_ITEM_PAD_H_EM = 0.41777;

    /** Outline of the menu frame. Hairline, unscaled. */
    public static final double OPTIONS_MENU_BORDER = 1;

    /** Lower bound on the menu width, so a very short label set still reads as a menu. */
    public static final double OPTIONS_MENU_MIN_WIDTH = px(120);

    // =====================================================================
    // Console text area
    // =====================================================================

    /**
     * Space between the Command Window's title strip and the first line of the
     * console, so the {@code >>} prompt and the caret do not touch the strip.
     *
     * <p>
     * Applied as the console's padding by {@code CLI_Main.initConsole}. The
     * padding sits outside the scrolled text, so the gap stays put while the
     * transcript scrolls under it -- it is a margin, not a blank first line.
     * </p>
     */
    public static final double CONSOLE_PAD_TOP = px(4);

    /** Space between the console text and the panel's left edge. */
    public static final double CONSOLE_PAD_LEFT = px(8);

    /** Space between the console text and the panel's right edge. */
    public static final double CONSOLE_PAD_RIGHT = px(8);

    /** Space below the last console line. */
    public static final double CONSOLE_PAD_BOTTOM = px(4);

    /**
     * Scroll room under the console's last line (MATLAB style): the room is
     * the visible height less this many lines, so scrolling all the way down
     * leaves the active prompt line at the top of the Command Window. A
     * count, not a length, so not scaled. 0 would let the prompt scroll out
     * of sight; 1 is MATLAB's behaviour.
     */
    public static final int OVERSCROLL_KEEP_LINES = 1;

    // =====================================================================
    // Standalone CLI (the Command Window in a window of its own)
    // =====================================================================
    //
    //   +-- NC  Command Window ------------------------ [_] [ ] [x] --+   frame strip (Frame_dim)
    //   |                                                    [=|=]  |   tool bar, 0.5 cm
    //   | >>                                                         |
    //   +------------------------------------------------------------+

    /**
     * First width of the standalone window as a share of the screen's
     * working area. A ratio, unscaled.
     */
    public static final double STANDALONE_WIDTH_SHARE = 0.30;

    /**
     * First height of the standalone window as a share of the screen's
     * working area. A ratio, unscaled. The window opens centred over the IDE
     * every time; only a size the user gives it is remembered.
     */
    public static final double STANDALONE_HEIGHT_SHARE = 0.60;

    /** The standalone window never gets narrower than this. */
    public static final double STANDALONE_MIN_WIDTH = px(360);

    /** The standalone window never gets shorter than this. */
    public static final double STANDALONE_MIN_HEIGHT = px(240);

    /** Radius of the green dot after "Exit Standalone CLI" in the menu. */
    public static final double STANDALONE_DOT_RADIUS = px(3.5);

    // ---- the tool bar under the strip -----------------------------------

    /**
     * Height of the tool bar: 0.5 cm at 96 dpi (0.5 / 2.54 x 96 = 18.9 px).
     * Its colour is the menus' fill (-astra-menu-bg); see surfaces.css,
     * section 9.
     */
    public static final double TOOLBAR_HEIGHT = pxi(19);

    /** Space between the tool bar's buttons and its left / right ends. */
    public static final double TOOLBAR_PAD_H = px(4);

    /** Space above and below the buttons inside the tool bar. */
    public static final double TOOLBAR_PAD_V = px(1);

    /** The line under the tool bar. Hairline, unscaled. */
    public static final double TOOLBAR_BORDER = 1;

    /** Gap between neighbouring tool-bar buttons (room for later ones). */
    public static final double TOOLBAR_SPACING = px(4);

    /** The Options button: height fills the bar inside its padding and line. */
    public static final double OPTIONS_BUTTON_HEIGHT =
            TOOLBAR_HEIGHT - 2 * TOOLBAR_PAD_V - TOOLBAR_BORDER;

    /** Width of the Options button. */
    public static final double OPTIONS_BUTTON_WIDTH = pxi(26);

    /** The Options button's thin outline. Hairline, unscaled. */
    public static final double OPTIONS_BUTTON_BORDER = 1;

    /** Edge of the Options icon inside the button. */
    public static final double OPTIONS_ICON_SIZE = pxi(13);

    // =====================================================================
    // CLI History window
    // =====================================================================

    /** First width of the CLI History window; it can be resized after. */
    public static final double HISTORY_WIDTH = px(560);

    /** First height of the CLI History window. */
    public static final double HISTORY_HEIGHT = px(520);

    protected CommandWindow_dim() {
    }
}
