package ui.design.section_dims;

import static ui.design.UIScale.px;

/**
 * The Editor Tab: the gutter strip down the left of a {@code .nc} editor and
 * the inset around the code.
 *
 * <h3>What the gutter is made of</h3>
 * <p>
 * Reading left to right, one row of the gutter is:
 * </p>
 *
 * <pre>
 *   | PAD_LEFT | error column | spacing | line number slot | spacing | fold column | PAD_RIGHT |  text gap  | code ...
 *   |&lt;------------------------------ coloured band --------------------------------------&gt;|&lt;- blank -&gt;|
 * </pre>
 *
 * <p>
 * Every piece has a fixed width, so the band is the same width on every line
 * and for every file: nothing in it depends on the line count or on whether a
 * line carries an error. That is what stops the code shifting sideways when a
 * file passes 99 or 999 lines.
 * </p>
 *
 * <h3>The two widths that are not here</h3>
 * <p>
 * The <b>line number slot</b> is exactly {@link #LINE_NUMBER_DIGITS} digits
 * wide at the line-number font, and the <b>text gap</b> is exactly
 * {@link #TEXT_GAP_CHARS} characters wide at the code font. Both are measured
 * from the real font by {@code ui.editor.EditorGutter} when the first editor
 * opens, because a digit's width depends on the font and cannot be written down
 * as a constant. This file holds the counts; the measurement turns them into
 * pixels. Font sizes themselves are {@code Typography.Role.EDITOR_LINE_NUMBER}
 * and {@code Typography.Role.EDITOR_CODE}.
 * </p>
 *
 * <h3>No CSS is generated for this region</h3>
 * <p>
 * The gutter is sized entirely from Java (it has to be: the paragraph graphic
 * decides where the code starts), so {@code DesignStylesheet} has nothing to
 * emit for it. Colours stay in {@code themes/editorColor/editor_*.css}.
 * </p>
 */
public class Editor_dim {

    // ---- gutter band ------------------------------------------------------

    /** Space between the editor's left edge and the error column. */
    public static final double GUTTER_PAD_LEFT = px(2);

    /**
     * Width of the error column. Fixed so the dot's presence on an error line
     * cannot push the number, the fold column or the code to the right. It
     * only needs to be at least as wide as the widest indicator.
     */
    public static final double ERROR_COLUMN_WIDTH = px(12);

    /**
     * Gap between neighbouring gutter columns (error | number | fold). The
     * same value {@code ErrorStatusManager} has always used between the dot
     * and the number.
     */
    public static final double GUTTER_COLUMN_SPACING = px(6);

    /**
     * How many digits the line-number slot holds at full size. A count, not a
     * length, so not scaled.
     *
     * <p>
     * Lines 1 to 9999 draw at the full line-number size. From 10000 up the
     * number is drawn smaller, just enough to fit the same slot, so the gutter
     * never grows.
     * </p>
     */
    public static final int LINE_NUMBER_DIGITS = 4;

    /**
     * Smallest size a shrunk line number may reach, as a fraction of the
     * line-number font. A ratio, not a length, so not scaled.
     *
     * <p>
     * 0.5 keeps numbers of up to eight digits whole. Past that the number is
     * clipped on the left, and the full value is always in its tooltip.
     * </p>
     */
    public static final double LINE_NUMBER_MIN_FONT_RATIO = 0.5;

    /** Width of the fold column (+/- marker and block guide). */
    public static final double FOLD_COLUMN_WIDTH = px(14);

    /**
     * Space between the fold column and the band's right edge. The band is
     * rounded up to a whole pixel, and the rounding is added here, so the band
     * edge always lands on a pixel boundary.
     */
    public static final double GUTTER_PAD_RIGHT = px(2);

    // ---- between gutter and code -------------------------------------------

    /**
     * Width of the blank, uncoloured strip between the band and the first
     * character of code, in characters of the code font. A count, not a
     * length, so not scaled (the font it is measured in is).
     *
     * <p>
     * The strip belongs to the line's gutter graphic, not to the text, so it
     * cannot be typed into, and selection and line highlights never paint it.
     * </p>
     */
    public static final int TEXT_GAP_CHARS = 1;

    // ---- code area inset ---------------------------------------------------

    /**
     * Padding on the code area's right edge. The left and top are zero on
     * purpose, so the band reaches the editor's own edge.
     */
    public static final double CODE_PAD_RIGHT = px(8);

    /** Padding below the last line. */
    public static final double CODE_PAD_BOTTOM = px(8);

    protected Editor_dim() {
    }
}
