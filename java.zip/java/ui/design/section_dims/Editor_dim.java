package ui.design.section_dims;

import static ui.design.UIScale.px;

/**
 * The Editor Tab: the gutter strip down the left of a {@code .nc} editor and
 * the inset around the code.
 *
 * <h3>What the gutter is made of</h3>
 * <p>
 * Reading left to right, one row of the gutter is:
 * </p>
 *
 * <pre>
 *   | PAD_LEFT | error column | spacing | line number slot | spacing | fold column | PAD_RIGHT |  text gap  | code ...
 *   |&lt;------------------------------ coloured band --------------------------------------&gt;|&lt;- blank -&gt;|
 * </pre>
 *
 * <p>
 * Every piece has a fixed width, so the band is the same width on every line
 * and for every file: nothing in it depends on the line count or on whether a
 * line carries an error. That is what stops the code shifting sideways when a
 * file passes 99 or 999 lines.
 * </p>
 *
 * <h3>The two widths that are not here</h3>
 * <p>
 * The <b>line number slot</b> is exactly {@link #LINE_NUMBER_DIGITS} digits
 * wide at the line-number font, and the <b>text gap</b> is exactly
 * {@link #TEXT_GAP_CHARS} characters wide at the code font. Both are measured
 * from the real font by {@code ui.editor.EditorGutter} when the first editor
 * opens, because a digit's width depends on the font and cannot be written down
 * as a constant. This file holds the counts; the measurement turns them into
 * pixels. Font sizes themselves are {@code Typography.Role.EDITOR_LINE_NUMBER}
 * and {@code Typography.Role.EDITOR_CODE}.
 * </p>
 *
 * <h3>No CSS is generated for this region</h3>
 * <p>
 * The gutter is sized entirely from Java (it has to be: the paragraph graphic
 * decides where the code starts), so {@code DesignStylesheet} has nothing to
 * emit for it. Colours stay in {@code themes/editorColor/editor_*.css}.
 * </p>
 */
public class Editor_dim {

    // ---- gutter band ------------------------------------------------------

    /** Space between the editor's left edge and the error column. */
    public static final double GUTTER_PAD_LEFT = px(2);

    /**
     * Width of the error column. Fixed so the issue bar's presence on an error
     * line cannot push the number, the fold column or the code to the right. It
     * only needs to be at least as wide as {@link #ISSUE_BAR_WIDTH}. The whole
     * column, not just the bar, answers the pointer with the issue tooltip.
     */
    public static final double ERROR_COLUMN_WIDTH = px(12);

    /**
     * Gap between neighbouring gutter columns (error | number | fold). The
     * same value {@code ErrorStatusManager} has always used between the error
     * marker and the number.
     */
    public static final double GUTTER_COLUMN_SPACING = px(6);

    /**
     * How many digits the line-number slot holds at full size. A count, not a
     * length, so not scaled.
     *
     * <p>
     * Lines 1 to 9999 draw at the full line-number size. From 10000 up the
     * number is drawn smaller, just enough to fit the same slot, so the gutter
     * never grows.
     * </p>
     */
    public static final int LINE_NUMBER_DIGITS = 4;

    /**
     * Smallest size a shrunk line number may reach, as a fraction of the
     * line-number font. A ratio, not a length, so not scaled.
     *
     * <p>
     * 0.5 keeps numbers of up to eight digits whole. Past that the number is
     * clipped on the left, and the full value is always in its tooltip.
     * </p>
     */
    public static final double LINE_NUMBER_MIN_FONT_RATIO = 0.5;

    /**
     * Width of the issue bar drawn in the error column: a short horizontal
     * dash, crimson for an error and amber for a warning. It replaces the old
     * round dot and must stay no wider than {@link #ERROR_COLUMN_WIDTH}.
     */
    public static final double ISSUE_BAR_WIDTH = px(8);

    /** Height (thickness) of the issue bar. Raised from 2 so the mark reads at a glance. */
    public static final double ISSUE_BAR_HEIGHT = px(3);

        /** Width of the fold column (+/- marker and block guide). */
    public static final double FOLD_COLUMN_WIDTH = px(14);

    /**
     * Space between the fold column and the band's right edge. The band is
     * rounded up to a whole pixel, and the rounding is added here, so the band
     * edge always lands on a pixel boundary.
     */
    public static final double GUTTER_PAD_RIGHT = px(2);

    // ---- issue tooltip -----------------------------------------------------

    /**
     * Widest an issue tooltip may grow before a message is broken onto a
     * second line: 1.5 times the first version's 460, so a typical message
     * stays on one line. The card otherwise hugs its text, in both themes.
     * Colours of the tooltip are in {@code themes/editorColor/editor_*.css};
     * its fonts are the {@code EDITOR_ISSUE_*} roles in {@code Typography}.
     */
    public static final double ISSUE_TOOLTIP_MAX_WIDTH = px(690);

    /** Inner padding of the issue tooltip, all four sides. */
    public static final double ISSUE_TOOLTIP_PADDING = px(9);

    /** Vertical gap between the caption and each issue in the tooltip. */
    public static final double ISSUE_TOOLTIP_ROW_GAP = px(7);

    /**
     * Distance between the gutter row and the issue tooltip, which opens below
     * the row (above it near the screen's bottom edge) rather than at the
     * pointer. Must stay larger than the card's shadow reaches upward
     * ({@code editor_*.css}, about 3 px), or the popup could slide under the
     * pointer and make the tooltip blink.
     */
    public static final double ISSUE_TOOLTIP_OFFSET = px(6);

    /** Gap between an issue's heading and its message. */
    public static final double ISSUE_TOOLTIP_TITLE_GAP = px(2);

    /** Width of the coloured stripe to the left of each issue in the tooltip. */
    public static final double ISSUE_ACCENT_WIDTH = px(3);

    /** Gap between that stripe and the issue's text. */
    public static final double ISSUE_ACCENT_GAP = px(8);

    /**
     * How long the pointer rests on the error column or line number before the
     * tooltip opens, in milliseconds. A time, not a length, so not scaled.
     * JavaFX's default of one second felt unresponsive on a 2-pixel mark.
     */
    public static final double ISSUE_TOOLTIP_DELAY_MS = 250;

        // ---- between gutter and code -------------------------------------------

    /**
     * Width of the blank, uncoloured strip between the band and the first
     * character of code, in characters of the code font. A count, not a
     * length, so not scaled (the font it is measured in is).
     *
     * <p>
     * The strip belongs to the line's gutter graphic, not to the text, so it
     * cannot be typed into, and selection and line highlights never paint it.
     * </p>
     */
    public static final int TEXT_GAP_CHARS = 1;

    // ---- code area inset ---------------------------------------------------

    /**
     * Padding on the code area's right edge. The left and top are zero on
     * purpose, so the band reaches the editor's own edge.
     */
    public static final double CODE_PAD_RIGHT = px(8);

    /** Padding below the last line. */
    public static final double CODE_PAD_BOTTOM = px(8);

    // ---- tab strip -----------------------------------------------------------

    /**
     * Style class on the editor's {@code TabPane}. The generated stylesheet
     * sizes the tab labels through it (breadcrumb font size), so a tab pane
     * elsewhere in the window is not affected. A name, not a length.
     */
    public static final String TAB_PANE_CLASS = "editor-tabs";

    protected Editor_dim() {
    }
}
