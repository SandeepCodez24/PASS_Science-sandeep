package ui.design.section_dims;

import static ui.design.UIScale.px;
import static ui.design.UIScale.pxi;

/**
 * The MATLAB-style split button used by the Files compartment: an icon zone
 * stacked over a menu zone, inside one rounded rectangle.
 *
 * <pre>
 *   +---------------+
 *   |     [icon]    |   icon zone  -> runs the default action
 *   +---------------+
 *   |      New      |   menu zone  -> opens the drop-down
 *   |       v       |
 *   +---------------+
 * </pre>
 *
 * <p>
 * The control's overall height comes from {@code ToolBand_dim.ITEM_HEIGHT} --
 * it is a compartment item like any other, and must match its neighbours.
 * </p>
 */
public class SplitButton_dim {

    /** Edge length of the icon shown beside a drop-down entry. */
    public static final double MENU_ICON_SIZE = pxi(16);

    /** Gap between the label and the triangle in the menu zone. */
    public static final double MENU_ZONE_SPACING = px(1);

    /** Corner rounding of the outer rectangle. */
    public static final double OUTER_RADIUS = px(5);

    /** Border around the outer rectangle. Unscaled. */
    public static final double OUTER_BORDER = 1;

    /** Corner rounding of the two inner zones. */
    public static final double ZONE_RADIUS = px(4);

    /** Icon zone padding, top edge. */
    public static final double ICON_ZONE_PAD_TOP = px(4);

    /** Icon zone padding, trailing edge. */
    public static final double ICON_ZONE_PAD_RIGHT = px(3);

    /** Icon zone padding, bottom edge. */
    public static final double ICON_ZONE_PAD_BOTTOM = px(2);

    /** Icon zone padding, leading edge. */
    public static final double ICON_ZONE_PAD_LEFT = px(3);

    /** Menu zone padding, top edge. */
    public static final double MENU_ZONE_PAD_TOP = px(1);

    /** Menu zone padding, trailing edge. */
    public static final double MENU_ZONE_PAD_RIGHT = px(3);

    /** Menu zone padding, bottom edge. */
    public static final double MENU_ZONE_PAD_BOTTOM = px(3);

    /** Menu zone padding, leading edge. */
    public static final double MENU_ZONE_PAD_LEFT = px(3);

    /** Width of the drop-down triangle's box. */
    public static final double ARROW_WIDTH = px(9);

    /** Height of the drop-down triangle's box. */
    public static final double ARROW_HEIGHT = px(6);

    /**
     * Height of the drawn triangle, slightly under the box height so the glyph
     * does not touch the zone's bottom padding.
     *
     * <p>
     * {@code DesignStylesheet} generates the {@code -fx-shape} path from this
     * and {@link #ARROW_WIDTH}, so the glyph tracks the scale factor instead of
     * sitting at its design size inside an enlarged box.
     * </p>
     */
    public static final double ARROW_SHAPE_HEIGHT = px(5.5);

    protected SplitButton_dim() {
    }
}
