package ui.design.section_dims;

/**
 * Dimensions of the Code Bot panel that opens at the bottom of the File
 * Explorer.
 *
 * <p>
 * Colours are in {@code /themes/codebot/codebot_light.css} and
 * {@code codebot_dark.css}; fonts follow the theme's panel font.
 * </p>
 */
public final class CodeBot_dim {

    private CodeBot_dim() {
    }

    // ---------------------------------------------------------------------
    // Placement
    // ---------------------------------------------------------------------

    /**
     * Divider position when the panel is opened from the ribbon: the tree
     * keeps the top 60%, the Code Bot gets the bottom 40%. The divider can be
     * dragged afterwards; every new open starts from this value again.
     */
    public static final double OPEN_DIVIDER_POSITION = 0.60;

    /** The tree never shrinks below this while the bot is open. */
    public static final double TREE_MIN_HEIGHT = 60;

    /** The bot never shrinks below this (title strip plus input row). */
    public static final double PANEL_MIN_HEIGHT = 150;

    // ---------------------------------------------------------------------
    // Title strip
    // ---------------------------------------------------------------------

    /** The bot glyph at the left of the strip. */
    public static final double HEADER_ICON_SIZE = 16;

    /** Close and new-chat glyphs drawn inside the title-strip buttons. */
    public static final double HEADER_GLYPH_SIZE = 10;

    // ---------------------------------------------------------------------
    // Conversation
    // ---------------------------------------------------------------------

    /** Padding around the message list. */
    public static final double LIST_PADDING = 10;

    /** Vertical gap between two messages. */
    public static final double MESSAGE_GAP = 10;

    /** A bubble may use at most this share of the list's width. */
    public static final double BUBBLE_MAX_SHARE = 0.86;

    /** Round avatar next to the bot's messages. */
    public static final double AVATAR_SIZE = 22;

    /** Gap between the avatar and the bubble. */
    public static final double AVATAR_GAP = 6;

    /** Dots of the "thinking" indicator. */
    public static final double TYPING_DOT_RADIUS = 3;
    public static final double TYPING_DOT_GAP = 4;
    public static final double TYPING_CYCLE_MS = 1200;

    // ---------------------------------------------------------------------
    // Input
    // ---------------------------------------------------------------------

    /** The input grows with its text up to this many lines, then scrolls. */
    public static final int INPUT_MAX_LINES = 6;

    /** Padding around the input row. */
    public static final double INPUT_OUTER_PADDING = 8;

    /** Square send button. */
    public static final double SEND_BUTTON_SIZE = 28;

    /** Paper-plane glyph inside the send button. */
    public static final double SEND_GLYPH_SIZE = 16;

    /** Artificial latency of the dummy service, so the typing state is visible. */
    public static final long DUMMY_REPLY_DELAY_MS = 450;
}
