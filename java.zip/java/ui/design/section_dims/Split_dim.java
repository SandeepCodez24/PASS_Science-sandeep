package ui.design.section_dims;

/**
 * Split-pane divider positions.
 *
 * <p>
 * These are fractions between 0 and 1, not lengths, so nothing here is scaled:
 * scaling a fraction would move the dividers off the panels they belong to.
 * </p>
 */
public class Split_dim {

    /** Boundary between the File Explorer and the editor column. */
    public static final double MAIN_LEFT = 0.20;

    /** Boundary between the editor column and the Variable Explorer. */
    public static final double MAIN_RIGHT = 0.58;

    /** Boundary between the editor tabs and the Command Window below them. */
    public static final double EDITOR_OVER_CONSOLE = 0.75;

    protected Split_dim() {
    }
}
