package ui.design.section_dims;

/**
 * The Home band's compartment shares.
 *
 * <pre>
 *  | Files |  Data  | Vis | Mod | Grp | Compute | Analysis | AI |  free  |
 *  |   2   |    2   |  1  |  1  |  1  |    2    |     2    |  1 |    4   |
 *  |&lt;------------------------- 16 units -------------------------&gt;|
 * </pre>
 *
 * <p>
 * Unit counts are ratios, not lengths, so nothing here is scaled. Heights, the
 * icon size and the divider are shared with Signals and live in
 * {@link ToolBand_dim}.
 * </p>
 *
 * <p>
 * Adding a compartment: add its {@code UNITS_} constant, add it to
 * {@link #USED_UNITS}, and raise {@link #SEPARATOR_COUNT} by one.
 * {@link #FREE_UNITS} then falls out on its own -- it is never stated.
 * </p>
 */
public class HomeBand_dim {

    /** The band width is divided into this many equal units. */
    public static final double TOTAL_UNITS = 16;

    /** Files: New / Open / Save split buttons. */
    public static final double UNITS_FILES = 2;

    /** Data: Import / Process / Export. */
    public static final double UNITS_DATA = 2;

    /** Visualisation: Plot. */
    public static final double UNITS_VISUALISATION = 1;

    /** Modelling: Multi Physics. */
    public static final double UNITS_MODELLING = 1;

    /** Graphical: Neural Link. */
    public static final double UNITS_GRAPHICAL = 1;

    /** Compute: Step / Run / Stop. */
    public static final double UNITS_COMPUTE = 2;

    /** Analysis: the two readouts. */
    public static final double UNITS_ANALYSIS = 2;

    /** AI Help: Code Bot. */
    public static final double UNITS_AI_HELP = 1;

    /** Units consumed by the eight compartments. Computed, not stated. */
    public static final double USED_UNITS =
            UNITS_FILES + UNITS_DATA + UNITS_VISUALISATION + UNITS_MODELLING
                    + UNITS_GRAPHICAL + UNITS_COMPUTE + UNITS_ANALYSIS + UNITS_AI_HELP;

    /** Units left free at the trailing edge for future compartments. */
    public static final double FREE_UNITS = TOTAL_UNITS - USED_UNITS;

    /** Dividers drawn: one after each compartment. */
    public static final int SEPARATOR_COUNT = 8;

    // =====================================================================
    // Files drop-down widths
    // =====================================================================
    // Multipliers on each menu's natural width -- the width its entries need
    // at the regular menu font. Ratios, so not scaled: the natural width is
    // already measured from scaled fonts and padding. 1.0 = no extra width;
    // values below 1.0 are ignored so an entry can never be clipped.
    // Applied through RibbonSplitButton.withMenuWidthScale in HomeRibbon.

    /** New drop-down (Script / Function / Class / Plain Text): 50% wider. */
    public static final double MENU_WIDTH_SCALE_NEW = 1.50;

    /** Open drop-down (Open File / Folder / Last Project / Root Folder): 25% wider. */
    public static final double MENU_WIDTH_SCALE_OPEN = 1.25;

    /** Save drop-down (Save / Save As / Save Root / Save In): 50% wider. */
    public static final double MENU_WIDTH_SCALE_SAVE = 1.50;

    protected HomeBand_dim() {
    }
}
