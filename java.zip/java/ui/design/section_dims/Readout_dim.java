package ui.design.section_dims;

import static ui.design.UIScale.px;

/**
 * The Analysis compartment's two stacked readouts: caption on the first line,
 * live value on the second. Display only -- unlike every other ribbon item
 * these are not clickable.
 */
public class Readout_dim {

    /** Gap between the two stacked readouts. */
    public static final double STACK_SPACING = px(4);

    /** Padding around the stack, leading and trailing. */
    public static final double STACK_PAD_H = px(6);

    /** Readout box padding, top and bottom. */
    public static final double PAD_V = px(1);

    /** Readout box padding, leading and trailing. */
    public static final double PAD_H = px(8);

    /** Corner rounding of a readout box. */
    public static final double RADIUS = px(4);

    /** Border around a readout box. Unscaled. */
    public static final double BORDER = 1;

    protected Readout_dim() {
    }
}
