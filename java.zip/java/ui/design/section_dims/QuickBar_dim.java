package ui.design.section_dims;

/**
 * Retired. The quick-access row is now two regions:
 * {@link NavigationBar_dim} (the six icon buttons and the row height) and
 * {@link BreadcrumbBar_dim} (the path box, its editor and the collapse toggle).
 *
 * <p>
 * Every constant below is an alias onto one of those files, so a call site that
 * still says {@code Dim.QuickBar.X} keeps compiling and gets the new, shorter
 * geometry. Nothing in the files touched by the navigation rework reads this
 * class any more. Once a project-wide search for {@code Dim.QuickBar} and
 * {@code QuickBar_dim} comes back empty, delete this file and the
 * {@code QuickBar} nested class in {@code ui.design.Dim}.
 * </p>
 *
 * @deprecated use {@link NavigationBar_dim} or {@link BreadcrumbBar_dim}
 */
@Deprecated
public class QuickBar_dim {

    /** @deprecated use {@link NavigationBar_dim#HEIGHT} */
    @Deprecated
    public static final double HEIGHT = NavigationBar_dim.HEIGHT;

    /** @deprecated use {@link NavigationBar_dim#BUTTON_SIZE} */
    @Deprecated
    public static final double NAV_BUTTON_SIZE = NavigationBar_dim.BUTTON_SIZE;

    /** @deprecated use {@link NavigationBar_dim#BUTTON_PADDING} */
    @Deprecated
    public static final double NAV_BUTTON_PADDING = NavigationBar_dim.BUTTON_PADDING;

    /** @deprecated use {@link NavigationBar_dim#BUTTON_RADIUS} */
    @Deprecated
    public static final double NAV_BUTTON_RADIUS = NavigationBar_dim.BUTTON_RADIUS;

    /** @deprecated use {@link BreadcrumbBar_dim#BOX_HEIGHT} */
    @Deprecated
    public static final double PATH_MIN_HEIGHT = BreadcrumbBar_dim.BOX_HEIGHT;

    /** @deprecated use {@link BreadcrumbBar_dim#ROOT_ICON_SIZE} */
    @Deprecated
    public static final double PATH_ROOT_ICON_SIZE = BreadcrumbBar_dim.ROOT_ICON_SIZE;

    /** @deprecated use {@link BreadcrumbBar_dim#SEGMENT_SPACING} */
    @Deprecated
    public static final double PATH_SEGMENT_SPACING = BreadcrumbBar_dim.SEGMENT_SPACING;

    /** @deprecated use {@link BreadcrumbBar_dim#BOX_SPACING} */
    @Deprecated
    public static final double PATH_BOX_SPACING = BreadcrumbBar_dim.BOX_SPACING;

    /** @deprecated use {@link BreadcrumbBar_dim#CHEVRON_SIZE} */
    @Deprecated
    public static final double CHEVRON_SIZE = BreadcrumbBar_dim.CHEVRON_SIZE;

    /** @deprecated use {@link BreadcrumbBar_dim#TOGGLE_ICON_SIZE} */
    @Deprecated
    public static final double TOGGLE_ICON_SIZE = BreadcrumbBar_dim.TOGGLE_ICON_SIZE;

    /** @deprecated use {@link BreadcrumbBar_dim#TOGGLE_RADIUS} */
    @Deprecated
    public static final double TOGGLE_RADIUS = BreadcrumbBar_dim.TOGGLE_RADIUS;

    protected QuickBar_dim() {
    }
}
