package ui.design.section_dims;

import static ui.design.UIScale.px;
import static ui.design.UIScale.pxi;

/**
 * The Navigation Bar and Breadcrumb Bar, which are one control in practice:
 * back / forward / up / OneDrive on the left, then the breadcrumb path, then
 * the tool-band collapse toggle at the right end.
 *
 * <p>
 * Kept as one file because the two halves share a row and have to agree on its
 * height. Split them if the breadcrumb ever grows its own chrome.
 * </p>
 */
public class QuickBar_dim {

    /** Height of the whole bar. */
    public static final double HEIGHT = px(36);

    /** Square hit area of a navigation arrow button. */
    public static final double NAV_BUTTON_SIZE = pxi(28);

    /** Padding inside a navigation arrow button. */
    public static final double NAV_BUTTON_PADDING = px(2);

    /** Corner rounding of a navigation button's hover fill. */
    public static final double NAV_BUTTON_RADIUS = px(3);

    /** Minimum height of the breadcrumb row. */
    public static final double PATH_MIN_HEIGHT = pxi(28);

    /** Edge length of the leading folder / This-PC glyph. */
    public static final double PATH_ROOT_ICON_SIZE = pxi(16);

    /** Gap between breadcrumb segments. */
    public static final double PATH_SEGMENT_SPACING = px(4);

    /** Gap between the folder button and the segment row. */
    public static final double PATH_BOX_SPACING = px(6);

    /** Edge length of a breadcrumb separator chevron. */
    public static final double CHEVRON_SIZE = pxi(9);

    /** Edge length of the tool-band collapse glyph. */
    public static final double TOGGLE_ICON_SIZE = pxi(14);

    /** Corner rounding of the collapse toggle's hover fill. */
    public static final double TOGGLE_RADIUS = px(3);

    protected QuickBar_dim() {
    }
}
