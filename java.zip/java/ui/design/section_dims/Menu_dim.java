package ui.design.section_dims;

import static ui.design.UIScale.px;

/**
 * Geometry of every pop-up menu in the application: the four right-click menus
 * (Command Window, Editor Tab, File Explorer on a row and on empty space,
 * Variable Explorer), the drop-downs (File Explorer Info, the Command Window
 * and Variable Explorer three-dot menus, the breadcrumb chevrons, This PC,
 * Root, Cloud, the Files split buttons) and every submenu they open.
 *
 * <h3>One look</h3>
 * <p>
 * Every menu is the same plain box: square corners, a one-pixel outline, one
 * fixed width, and a height that simply follows the number of entries. The
 * colours are tokens in {@code themes/shared/palette_*.css}
 * ({@code -astra-menu-*}), used by the MENUS section of
 * {@code themes/shared/surfaces.css}. {@link ui.design.DesignStylesheet}
 * emits the geometry below, and {@link ui.design.MenuStyle} tags a menu so
 * both apply. There is no per-menu styling anywhere else.
 * </p>
 *
 * <h3>Width</h3>
 * <p>
 * {@link #WIDTH} is the outer width of every menu, outline included. It is
 * sized for the widest standard menu -- the File Explorer's, which has an
 * icon column, a check column, "Indicate Files Not on Path" and the
 * shortcut column -- so that every menu comes out the same. Shortcuts and
 * submenu chevrons are pinned to the right edge.
 * </p>
 * <p>
 * It is a floor, not a clamp: a menu whose entries genuinely need more room
 * (a long folder name in a breadcrumb list, "Undo Rename 'a very long
 * name'") grows rather than cutting its text. The run-folder history list
 * asks for the path box's width instead, MATLAB-style.
 * </p>
 */
public class Menu_dim {

    // =====================================================================
    // FRAME
    // =====================================================================

    /** Outer width of every menu and submenu, outline included. */
    public static final double WIDTH = px(260);

    /**
     * Outer width of a compact menu: half of {@link #WIDTH}. For a short list
     * of short entries (the File Explorer's Info drop-down) that would look
     * empty at the common width. Also a floor: longer entries widen it.
     */
    public static final double COMPACT_WIDTH = WIDTH / 2;

    /**
     * Outer width of a narrow menu: 90 % of {@link #WIDTH}. For the Home
     * ribbon's New / Open / Save drop-downs, which hang under narrow buttons.
     * A floor, like the others.
     */
    public static final double NARROW_WIDTH = WIDTH * 0.9;

    /**
     * Outer width of a short menu: 80 % of {@link #WIDTH}. For the editor's
     * right-click menu, whose entries (Cut ... Replace) are all short. A
     * floor, like the others.
     */
    public static final double SHORT_WIDTH = WIDTH * 0.8;

    /**
     * Outer width of a slim menu: 70 % of {@link #WIDTH}. For the Command
     * Window's three-dot menu. A floor, like the others.
     */
    public static final double SLIM_WIDTH = WIDTH * 0.7;

    /** The outline. Hairline, unscaled. */
    public static final double BORDER = 1;

    /** Corner rounding of the frame and of the hover highlight: none. */
    public static final double RADIUS = 0;

    /**
     * Space between the outline and the first / last entry. Left and right
     * are zero, so the hover highlight runs from outline to outline.
     */
    public static final double PAD_V = px(3);

    // =====================================================================
    // ENTRIES
    // =====================================================================

    /** Vertical padding of one entry: sets the row height with the font. */
    public static final double ITEM_PAD_V = px(4);

    /** Horizontal padding of one entry, left and right. */
    public static final double ITEM_PAD_H = px(12);

    /** Gap between the check / radio column and the text. */
    public static final double CHECK_GAP = px(6);

    /** Gap between the longest text and the shortcut or chevron column. */
    public static final double ACCELERATOR_GAP = px(24);

    // =====================================================================
    // SEPARATORS
    // =====================================================================

    /** Space above and below a separator line. */
    public static final double SEPARATOR_PAD_V = px(3);

    /** How far the separator line stops short of the outline, each side. */
    public static final double SEPARATOR_INSET_H = px(8);

    // =====================================================================
    // GLYPHS
    // =====================================================================

    /**
     * Gap between an entry icon and its text. Only the File Explorer's menus
     * carry icons (sized by {@code DirectoryMenu_dim.MENU_ICON_SIZE}); every
     * other menu has no icon column at all.
     */
    public static final double ICON_GAP = px(8);

    /** Half-height of the submenu chevron (it is drawn 5 x 8 at scale 1). */
    public static final double CHEVRON_PAD_V = px(4);

    /** Half-width of the submenu chevron. */
    public static final double CHEVRON_PAD_H = px(2.5);

    /** Radius of the dot that marks the chosen radio entry. */
    public static final double RADIO_DOT = px(3);

    // =====================================================================
    // DERIVED
    // =====================================================================

    /**
     * The width a custom row ({@code CustomMenuItem}) needs so that its menu
     * comes out exactly {@link #WIDTH} wide: the frame less the outline and the
     * entry's own padding on both sides.
     *
     * @return the row width
     */
    public static double rowWidth() {
        return rowWidth(WIDTH);
    }

    /**
     * The width a custom row needs so that its menu comes out exactly
     * {@code menuWidth} wide (for a short or slim menu).
     *
     * @param menuWidth the menu's outer width
     * @return the row width
     */
    public static double rowWidth(double menuWidth) {
        return menuWidth - 2 * BORDER - 2 * ITEM_PAD_H;
    }

    protected Menu_dim() {
    }
}
