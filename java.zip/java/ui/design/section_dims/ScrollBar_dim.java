package ui.design.section_dims;

import static ui.design.UIScale.pxi;

/**
 * Every scroll bar in the application: the seven sub-windows (File Explorer,
 * Code Bot, Editor Tab, Command Window, Variable Explorer, Signal Explorer,
 * suggestion list) and anything else that scrolls.
 *
 * <pre>
 *     vertical                     horizontal
 *   +---------+             +----+---------------------+----+
 *   |   /\    |  button     | &lt;  |  [=======]          | &gt;  |
 *   +---------+             +----+---------------------+----+
 *   | +-----+ |               button      thumb           button
 *   | |     | |  thumb, inset THUMB_INSET from the track's sides
 *   | +-----+ |
 *   |         |  track
 *   +---------+
 *   |   \/    |  button
 *   +---------+
 *   |&lt;-THICK-&gt;|
 * </pre>
 *
 * <h3>Look</h3>
 * <p>
 * MATLAB style: a flat track, a square-cornered thumb standing a little off
 * the track's edges, and solid triangle arrows in square end buttons. The
 * arrows are vector shapes, {@link #ARROW_BASE} x {@link #ARROW_DEPTH}, filled
 * with the {@code -astra-scroll-arrow} ink -- sharp at any display scaling,
 * and recoloured by the theme with no image files.
 * </p>
 *
 * <h3>Width</h3>
 * <p>
 * Modena's bar is about 14 px across at the default 13 px font. This one is
 * 25 % wider: 14 x 1.25 = 17.5, rounded to {@link #THICKNESS} = 18 so the bar,
 * its buttons and the arrow's padding all land on whole pixels.
 * </p>
 *
 * <h3>Where the numbers go</h3>
 * <p>
 * {@code DesignStylesheet.scrollBars} emits every value here as CSS. Colours
 * are tokens in {@code themes/shared/palette_*.css}, used by
 * {@code themes/shared/surfaces.css}.
 * </p>
 */
public class ScrollBar_dim {

    /**
     * Width of a vertical bar and height of a horizontal one: Modena's ~14
     * plus 25 %, on a whole pixel.
     */
    public static final double THICKNESS = pxi(18);

    /**
     * Length of an end button along the bar. Equal to {@link #THICKNESS}, so
     * the buttons are square.
     */
    public static final double BUTTON_LENGTH = THICKNESS;

    /**
     * Gap between the thumb and the track's two long edges. The thumb is
     * {@code THICKNESS - 2 * THUMB_INSET} across: 14 at scale 1.0.
     */
    public static final double THUMB_INSET = pxi(2);

    /**
     * Shortest the thumb may become on a very long document, so it can
     * always be grabbed.
     */
    public static final double THUMB_MIN_LENGTH = pxi(24);

    /**
     * The arrow triangle's base (its width on a vertical bar). Even, so the
     * triangle is symmetric in the button: (18 - 10) / 2 = 4 either side.
     * Raised from 8, which read as a speck on a high-DPI screen.
     */
    public static final double ARROW_BASE = pxi(10);

    /**
     * The arrow triangle's depth, base to tip. Half the base: a flat,
     * MATLAB-like triangle.
     */
    public static final double ARROW_DEPTH = pxi(5);

    protected ScrollBar_dim() {
    }
}
