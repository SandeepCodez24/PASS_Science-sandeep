package ui.design.section_dims;

import ui.design.Typography;

import static ui.design.UIScale.px;
import static ui.design.UIScale.pxi;

/**
 * The Variable Explorer and everything that shows a variable's value: the
 * explorer table, its three-dot menu, the variable tabs (in the editor area,
 * the split pane or the separate window) and the grid inside each tab.
 *
 * <p>
 * Colours are not here: they live in
 * {@code themes/variable_explorer/variable_light.css} and
 * {@code variable_dark.css}. The menu and grid geometry below is emitted as a
 * small generated sheet by {@code ui.explorer.variable.VariableStyles}.
 * </p>
 */
public class VariableExplorer_dim {

    // =====================================================================
    // EXPLORER TABLE
    // =====================================================================

    /** Row height of the explorer table. Was a literal 26 in the builder. */
    public static final double BASE_TABLE_ROW_HEIGHT = pxi(26);

    /** Room a table row keeps above and below its text, together. */
    public static final double TABLE_ROW_TEXT_PAD = px(5);

    /**
     * Table row height in force: {@link #BASE_TABLE_ROW_HEIGHT}, or one line
     * of the row text plus {@link #TABLE_ROW_TEXT_PAD} if a larger UI font
     * size needs more. Recomputed by {@link #recomputeTextHeights()}.
     */
    public static double TABLE_ROW_HEIGHT;

    /** Type icon in the Name column. */
    public static final double TABLE_ICON_SIZE = pxi(16);

    /** Gap between the type icon and the name. */
    public static final double NAME_ICON_GAP = px(6);

    // =====================================================================
    // MENUS (three-dot menu, its sub-menus, the table's right-click menu)
    // =====================================================================

    /** Corner radius of every menu and box this feature opens: square. */
    public static final double MENU_RADIUS = 0;

    /** Padding inside a menu, all round. */
    public static final double MENU_PAD = px(3);

    /** Padding inside a menu entry, top and bottom. */
    public static final double MENU_ITEM_PAD_V = px(4);

    /** Padding inside a menu entry, left and right. */
    public static final double MENU_ITEM_PAD_H = px(14);

    /** Narrowest the three-dot menu may be. */
    public static final double MENU_MIN_WIDTH = px(190);

    // =====================================================================
    // VARIABLE TABS
    // =====================================================================

    /** Type icon on a variable tab. */
    public static final double TAB_ICON_SIZE = pxi(14);

    /**
     * Space kept free at the right end of the script tab strip for every
     * pixel the variable tabs take, plus this margin (Default view only).
     */
    public static final double TAB_STRIP_GAP = px(8);

    // =====================================================================
    // GRID (the MATLAB-style value grid inside a variable tab)
    // =====================================================================

    /** Height of the "5x5 float64" strip above the grid. */
    public static final double HEADER_HEIGHT = pxi(26);

    /** Padding of that strip, left and right. */
    public static final double HEADER_PAD_H = px(8);

    /** Gap between the strip's icon and its text. */
    public static final double HEADER_SPACING = px(6);

    /** Type icon in the strip. */
    public static final double HEADER_ICON_SIZE = pxi(16);

    /** Row height of the grid. */
    public static final double CELL_HEIGHT = pxi(24);

    /** Width of every value column. */
    public static final double COLUMN_WIDTH = px(84);

    /** Width of a Key / Field column (dictionaries and objects). */
    public static final double KEY_COLUMN_WIDTH = px(160);

    /** Width of a text value column (strings, dictionary values). */
    public static final double TEXT_COLUMN_WIDTH = px(320);

    /** Width of the row-number column on the left. */
    public static final double ROW_HEADER_WIDTH = px(48);

    /** Padding inside a grid cell, left and right. */
    public static final double CELL_PAD_H = px(6);

    /**
     * Least number of rows the grid draws, empty ones included, so a small
     * value still shows a sheet the way MATLAB does. A count, not scaled.
     */
    public static final int MIN_ROWS = 30;

    /** Least number of value columns the grid draws. A count, not scaled. */
    public static final int MIN_COLUMNS = 12;

    /**
     * Most value columns the grid builds. A 1 x 2,000,000 vector would
     * otherwise mean two million column objects; past this the grid shows
     * the first columns and says so. A count, not scaled.
     */
    public static final int MAX_COLUMNS = 2000;

    /** Padding around the "does not exist" and loading messages. */
    public static final double MESSAGE_PAD = px(16);

    // =====================================================================
    // ARRANGEMENTS (divider positions and window sizes)
    // =====================================================================

    /** Split Window: share of the editor area kept by the script tabs. */
    public static final double SPLIT_SCRIPT_SHARE = 0.50;

    /** Full Screen: share of the width taken by the explorer table. */
    public static final double FULL_SCREEN_TABLE_SHARE = 0.35;

    /** Separate Window: share of the window taken by the explorer table. */
    public static final double WINDOW_TABLE_SHARE = 0.40;

    /** Separate Window: width at first open. */
    public static final double WINDOW_WIDTH = px(980);

    /** Separate Window: height at first open. */
    public static final double WINDOW_HEIGHT = px(560);

    /** Separate Window: smallest width it can be dragged to. */
    public static final double WINDOW_MIN_WIDTH = px(420);

    /** Separate Window: smallest height it can be dragged to. */
    public static final double WINDOW_MIN_HEIGHT = px(260);

    // =====================================================================
    // CONFIRMATION DIALOG (Reset Explorer)
    // A frameless window with its own title bar: an OS-framed window gets
    // rounded corners from Windows 11 whatever the CSS says.
    // =====================================================================

    /** Dialog width. */
    public static final double DIALOG_WIDTH = px(460);

    /** Height of the dialog's own title bar. */
    public static final double DIALOG_TITLE_BAR_HEIGHT = px(32);

    /** Left padding of the title bar, before the icon. */
    public static final double DIALOG_TITLE_PAD_LEFT = px(10);

    /** Gap between the title bar's icon and its text. */
    public static final double DIALOG_TITLE_SPACING = px(8);

    /** The Neural Code mark on the title bar. */
    public static final double DIALOG_TITLE_ICON_SIZE = px(16);

    /** Width of the title bar's close button. */
    public static final double DIALOG_CLOSE_WIDTH = px(46);

    /** Padding around the heading, the message and the button row. */
    public static final double DIALOG_PAD = px(16);

    /** Gap between the buttons. */
    public static final double DIALOG_BUTTON_GAP = px(8);

    /** Smallest button width. */
    public static final double DIALOG_BUTTON_MIN_WIDTH = px(110);

    /** Button padding, top/bottom. */
    public static final double DIALOG_BUTTON_PAD_V = px(5);

    /** Button padding, left/right. */
    public static final double DIALOG_BUTTON_PAD_H = px(16);

    // =====================================================================
    // Heights that follow the UI font size
    // =====================================================================

    static {
        recomputeTextHeights();
    }

    /** Recomputes {@link #TABLE_ROW_HEIGHT} for the UI font size in force. */
    public static void recomputeTextHeights() {
        double text = Math.max(Typography.lineHeight(Typography.Role.DIRECTORY_ROW),
                Typography.lineHeight(Typography.Role.VARIABLE_NAME));
        TABLE_ROW_HEIGHT = Math.max(BASE_TABLE_ROW_HEIGHT, Math.max(TABLE_ICON_SIZE, text) + TABLE_ROW_TEXT_PAD);
    }

    protected VariableExplorer_dim() {
    }
}
