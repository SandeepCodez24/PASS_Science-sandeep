package ui.design.section_dims;

import static ui.design.UIScale.px;
import static ui.design.UIScale.pxi;

/**
 * The directory explorer's tree table: its header strip, its three columns, the
 * Info drop-down and the glyphs drawn inside the rows.
 *
 * <h3>Column widths</h3>
 * <p>
 * The default split is {@code 7.5 : 1.75 : 0.75} out of ten, stored here as
 * fractions of one. {@code DirectoryTreeBuilder.ColumnFitter} applies it to
 * the table's usable width -- the width inside the table's border, less the
 * vertical scrollbar when one is showing -- every time that width changes.
 * </p>
 * <p>
 * Two dividers can be dragged: Name | Info and Info | R. A dragged width is
 * kept for the session only; at the next launch the ratio applies again.
 * </p>
 * <p>
 * Info and R are whole pixels and Name takes whatever is left, so the three
 * always add up to exactly the usable width. That exactness is what keeps the
 * empty "filler" strip from appearing to the right of R and the horizontal
 * scrollbar from appearing under a tree that fits.
 * </p>
 *
 * <h3>Narrowing: Name keeps its space</h3>
 * <p>
 * When the panel narrows, Info and R give up width before Name does. While
 * Name would be narrower than {@link #NAME_KEEP_WIDTH}, Info shrinks towards
 * {@link #INFO_MIN_WIDTH}, then R towards {@link #REPO_MIN_WIDTH}; only then
 * does Name itself shrink, never below {@link #NAME_MIN_WIDTH}.
 * </p>
 *
 * <h3>Why the minimums are what they are</h3>
 * <p>
 * The three minimums together must stay below the usable width at the panel's
 * floor ({@link Explorer_dim#PANEL_MIN_WIDTH}: 160 less the table border, less
 * a scrollbar, about 144). They add up to 108 at scale 1.0, which leaves Name
 * about 82 pixels on a fully narrowed panel -- the old minimums (68 + 26)
 * left it about 50. Raising any of them past the floor brings back a
 * horizontal scrollbar on a fully narrowed panel.
 * </p>
 * <p>
 * The Info minimum is below the width of the one-word unit names. When the
 * column is narrower than "Functions", the mode row shows the drop-down
 * triangle alone; the header's tooltip still names the unit.
 * </p>
 */
public class Directory_dim {

    // =====================================================================
    // COLUMN RATIO
    // =====================================================================

    /** Name column: 7.5 of 10. */
    public static final double NAME_SHARE = 0.750;

    /** Info column: 1.75 of 10. */
    public static final double INFO_SHARE = 0.175;

    /** R (repository) column: 0.75 of 10. */
    public static final double REPO_SHARE = 0.075;

    /** Width below which the Name column never shrinks. */
    public static final double NAME_MIN_WIDTH = px(46);

    /**
     * Width Name is protected down to while the panel narrows. Info and R give
     * up width to keep Name at least this wide, and only when both are at
     * their minimums does Name go narrower. Also the narrowest a drag on the
     * Name | Info divider can make Name. About 16 characters of a file name at
     * the row font.
     */
    public static final double NAME_KEEP_WIDTH = px(120);

    /**
     * Width below which the Info column never shrinks: room for a four-digit
     * count with the cell's side padding. The unit names in the header fall
     * back to the triangle alone below the width of the one-word name (see the
     * class notes).
     */
    public static final double INFO_MIN_WIDTH = pxi(40);

    /** Width below which the R column never shrinks: the status dot and its padding. */
    public static final double REPO_MIN_WIDTH = pxi(22);

    /**
     * Width assumed for the vertical scrollbar before the table's skin exists.
     * Once the skin is built the real scrollbar is measured instead, and this
     * value stops mattering; it only keeps the first frame from overflowing.
     */
    public static final double SCROLLBAR_ALLOWANCE = pxi(14);

    // =====================================================================
    // HEADER
    // =====================================================================

    /**
     * Thickness of the faint divider at the right of each header cell, the
     * line along the bottom of the strip, and the line between the two rows
     * of the Info header. The first two are background layers and take no
     * layout space; the third is a border on the caption row and does.
     */
    public static final double HEADER_DIVIDER = pxi(1);

    /**
     * Height of the "Info" caption row, above its dividing line. Just tall
     * enough for {@code Typography.Role.DIRECTORY_INFO_HEADER} with no
     * padding: the brief is two rows and no extra space.
     */
    public static final double INFO_CAPTION_ROW = pxi(12);

    /**
     * Height of the mode row ("By Number of Lines  v") below the line. One
     * pixel more than the caption row: the mode names have descenders, and the
     * row sits on the header's bottom edge, where a descender would be cut.
     */
    public static final double INFO_MODE_ROW = pxi(13);

    /**
     * Height of the whole column header strip. Emitted as {@code -fx-size},
     * the property {@code TableColumnHeader} reads for its height.
     *
     * <p>
     * Derived, not chosen: exactly the Info header's two rows and the line
     * between them. The single-line "Name" and "R" captions are centred in the
     * same height. Change the row heights, not this.
     * </p>
     */
    public static final double HEADER_HEIGHT = INFO_CAPTION_ROW + HEADER_DIVIDER + INFO_MODE_ROW;

    /** Inset either side of the "Name" and "R" captions. */
    public static final double HEADER_PAD_H = px(6);

    /** Width of the drop-down triangle in the mode row. */
    public static final double HEADER_ARROW_SIZE = pxi(7);

    /** Height of that triangle, as a share of its width. */
    public static final double HEADER_ARROW_ASPECT = 0.6;

    /** Inset inside the mode row, left and right of its contents. */
    public static final double INFO_MODE_PAD_H = px(3);

    /** Gap between the mode name and the triangle. */
    public static final double INFO_MODE_SPACING = px(3);

    /**
     * How far the mode row's hover highlight stands off the cell edges, left
     * and bottom. On the right the divider's width is added, so the highlight
     * never paints over the line between Info and R. Background insets only:
     * the highlight moves nothing when it appears.
     */
    public static final double INFO_MODE_HIGHLIGHT_INSET = pxi(1);

    /** Corner radius of the mode row's hover highlight. */
    public static final double INFO_MODE_RADIUS = px(3);

    // =====================================================================
    // INFO DROP-DOWN MENU
    // =====================================================================

    /** Padding inside the menu's frame. */
    public static final double MENU_PAD = px(4);

    /** Corner radius of the menu frame and of a highlighted item. */
    public static final double MENU_RADIUS = px(4);

    /** Vertical padding of one menu item. */
    public static final double MENU_ITEM_PAD_V = px(4);

    /** Horizontal padding of one menu item. */
    public static final double MENU_ITEM_PAD_H = px(10);

    /** Gap between the bottom of the header strip and the top of the menu. */
    public static final double MENU_OFFSET_Y = px(1);

    // =====================================================================
    // RIGHT-CLICK MENU
    // =====================================================================

    /**
     * How much wider the right-click menu (Cut / Copy / Paste / Delete /
     * Rename / Undo / Redo) is than its natural width. A ratio, so not scaled:
     * the natural width is measured from the real font when the menu opens, so
     * the result follows the scale factor and the font on its own. 1.5 is the
     * requested +50%.
     */
    public static final double CONTEXT_MENU_WIDTH_FACTOR = 1.5;

    // =====================================================================
    // INLINE RENAME
    // =====================================================================

    /** Text inset inside the rename field, left and right. */
    public static final double RENAME_FIELD_PAD_H = px(3);

    /** Corner rounding of the rename field. */
    public static final double RENAME_FIELD_RADIUS = px(2);

    /**
     * Slow double-click window, in milliseconds. A second click on an
     * already-selected row that lands later than a double-click
     * ({@link #SLOW_CLICK_MIN_MS}) but no later than this starts a rename, as
     * in Windows Explorer. A time, not a length, so not scaled.
     */
    public static final long SLOW_CLICK_MAX_MS = 1500;

    /**
     * The double-click interval: two clicks closer than this are a
     * double-click (open), and the rename waits this long after the second
     * click so a third, fast click can still turn it into a double-click.
     * Windows' default. A time, not a length, so not scaled.
     */
    public static final long SLOW_CLICK_MIN_MS = 500;

    // =====================================================================
    // ROWS
    // =====================================================================

    /** Height of one file or folder row. Was 24 on the old TreeView. */
    public static final double ROW_HEIGHT = pxi(24);

    /** Inset at the left and right edge of every cell. */
    public static final double CELL_PAD_H = px(6);

    /** Inset above and below a cell's contents. */
    public static final double CELL_PAD_V = px(2);

    /** Gap between a row's icon and its file name. */
    public static final double ICON_GAP = px(6);

    /**
     * Rendered size of a file-type icon.
     *
     * <p>
     * The source PNGs ship at 16, 20, 24 and 32 so that this value can be
     * scaled without JavaFX having to invent pixels;
     * {@code DirectoryFileIconResolver} picks whichever source is nearest at or
     * above the scaled size.
     * </p>
     */
    public static final double FILE_ICON_SIZE = pxi(16);

    // =====================================================================
    // REPO COLUMN GLYPHS
    // =====================================================================

    /** Diameter of the repo status dot. */
    public static final double REPO_DOT_SIZE = pxi(9);

    /** Line thickness of the tick and the cross drawn over a dot. */
    public static final double REPO_MARK_STROKE = px(1.5);

    protected Directory_dim() {
    }
}
