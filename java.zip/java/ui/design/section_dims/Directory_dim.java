package ui.design.section_dims;

import static ui.design.UIScale.px;
import static ui.design.UIScale.pxi;

/**
 * The directory explorer's tree table: its header strip, its three columns, the
 * Info drop-down and the glyphs drawn inside the rows.
 *
 * <h3>The column ratio</h3>
 * <p>
 * The split is {@code 7.5 : 1.75 : 0.75} out of ten, stored here as fractions
 * of one. {@code DirectoryTreeBuilder} applies it to the table's usable width
 * -- the width inside the table's border, less the vertical scrollbar when
 * one is showing -- every time that width changes. None of the three columns
 * can be dragged: the ratio is the only thing that sizes them, so there is no
 * way for a manual resize to knock the header out of step with the rows.
 * </p>
 *
 * <p>
 * Info and R are rounded down to whole pixels and Name takes whatever is left,
 * so the three always add up to exactly the usable width. That exactness is
 * what keeps the empty "filler" strip from appearing to the right of R and the
 * horizontal scrollbar from appearing under a tree that fits.
 * </p>
 *
 * <h3>Why the minimums exist</h3>
 * <p>
 * At the panel's 160px floor ({@link Explorer_dim#PANEL_MIN_WIDTH}) a pure
 * ratio would leave R about eleven pixels wide, narrower than its status dot,
 * and Info too narrow to hold a mode name beside its drop-down triangle.
 * Each column therefore carries a minimum. Below roughly 390px of usable
 * width the Info minimum takes over, and Name gives up the difference.
 * </p>
 * <p>
 * The three minimums together must stay below the usable width at the panel's
 * floor (160 less the table border, less a scrollbar: about 144). They add up
 * to 140 at scale 1.0. Raising any of them past that point brings back a
 * horizontal scrollbar on a fully narrowed panel.
 * </p>
 */
public class Directory_dim {

    // =====================================================================
    // COLUMN RATIO
    // =====================================================================

    /** Name column: 7.5 of 10. */
    public static final double NAME_SHARE = 0.750;

    /** Info column: 1.75 of 10. */
    public static final double INFO_SHARE = 0.175;

    /** R (repository) column: 0.75 of 10. */
    public static final double REPO_SHARE = 0.075;

    /** Width below which the Name column stops shrinking. */
    public static final double NAME_MIN_WIDTH = px(46);

    /**
     * Width below which the Info column stops shrinking. Sized so the longest
     * short mode name, "Functions", still fits beside the triangle in the
     * mode row at {@code DIRECTORY_INFO_HEADER} size. The full names ("By
     * Number of Lines") appear whenever the column is wider than they are.
     */
    public static final double INFO_MIN_WIDTH = pxi(68);

    /** Width below which the R column stops shrinking. */
    public static final double REPO_MIN_WIDTH = pxi(26);

    /**
     * Width assumed for the vertical scrollbar before the table's skin exists.
     * Once the skin is built the real scrollbar is measured instead, and this
     * value stops mattering; it only keeps the first frame from overflowing.
     */
    public static final double SCROLLBAR_ALLOWANCE = pxi(14);

    // =====================================================================
    // HEADER
    // =====================================================================

    /**
     * Thickness of the faint divider at the right of each header cell, the
     * line along the bottom of the strip, and the line between the two rows
     * of the Info header. The first two are background layers and take no
     * layout space; the third is a border on the caption row and does.
     */
    public static final double HEADER_DIVIDER = pxi(1);

    /**
     * Height of the "Info" caption row, above its dividing line. Just tall
     * enough for {@code Typography.Role.DIRECTORY_INFO_HEADER} with no
     * padding: the brief is two rows and no extra space.
     */
    public static final double INFO_CAPTION_ROW = pxi(12);

    /**
     * Height of the mode row ("By Number of Lines  v") below the line. One
     * pixel more than the caption row: the mode names have descenders, and the
     * row sits on the header's bottom edge, where a descender would be cut.
     */
    public static final double INFO_MODE_ROW = pxi(13);

    /**
     * Height of the whole column header strip. Emitted as {@code -fx-size},
     * the property {@code TableColumnHeader} reads for its height.
     *
     * <p>
     * Derived, not chosen: exactly the Info header's two rows and the line
     * between them. The single-line "Name" and "R" captions are centred in the
     * same height. Change the row heights, not this.
     * </p>
     */
    public static final double HEADER_HEIGHT = INFO_CAPTION_ROW + HEADER_DIVIDER + INFO_MODE_ROW;

    /** Inset either side of the "Name" and "R" captions. */
    public static final double HEADER_PAD_H = px(6);

    /** Width of the drop-down triangle in the mode row. */
    public static final double HEADER_ARROW_SIZE = pxi(7);

    /** Height of that triangle, as a share of its width. */
    public static final double HEADER_ARROW_ASPECT = 0.6;

    /** Inset inside the mode row, left and right of its contents. */
    public static final double INFO_MODE_PAD_H = px(3);

    /** Gap between the mode name and the triangle. */
    public static final double INFO_MODE_SPACING = px(3);

    /**
     * How far the mode row's hover highlight stands off the cell edges, left
     * and bottom. On the right the divider's width is added, so the highlight
     * never paints over the line between Info and R. Background insets only:
     * the highlight moves nothing when it appears.
     */
    public static final double INFO_MODE_HIGHLIGHT_INSET = pxi(1);

    /** Corner radius of the mode row's hover highlight. */
    public static final double INFO_MODE_RADIUS = px(3);

    // =====================================================================
    // INFO DROP-DOWN MENU
    // =====================================================================

    /** Padding inside the menu's frame. */
    public static final double MENU_PAD = px(4);

    /** Corner radius of the menu frame and of a highlighted item. */
    public static final double MENU_RADIUS = px(4);

    /** Vertical padding of one menu item. */
    public static final double MENU_ITEM_PAD_V = px(4);

    /** Horizontal padding of one menu item. */
    public static final double MENU_ITEM_PAD_H = px(10);

    /** Gap between the bottom of the header strip and the top of the menu. */
    public static final double MENU_OFFSET_Y = px(1);

    // =====================================================================
    // ROWS
    // =====================================================================

    /** Height of one file or folder row. Was 24 on the old TreeView. */
    public static final double ROW_HEIGHT = pxi(24);

    /** Inset at the left and right edge of every cell. */
    public static final double CELL_PAD_H = px(6);

    /** Inset above and below a cell's contents. */
    public static final double CELL_PAD_V = px(2);

    /** Gap between a row's icon and its file name. */
    public static final double ICON_GAP = px(6);

    /**
     * Rendered size of a file-type icon.
     *
     * <p>
     * The source PNGs ship at 16, 20, 24 and 32 so that this value can be
     * scaled without JavaFX having to invent pixels;
     * {@code DirectoryFileIconResolver} picks whichever source is nearest at or
     * above the scaled size.
     * </p>
     */
    public static final double FILE_ICON_SIZE = pxi(16);

    // =====================================================================
    // REPO COLUMN GLYPHS
    // =====================================================================

    /** Diameter of the repo status dot. */
    public static final double REPO_DOT_SIZE = pxi(9);

    /** Line thickness of the tick and the cross drawn over a dot. */
    public static final double REPO_MARK_STROKE = px(1.5);

    protected Directory_dim() {
    }
}
