/**
 * One file per UI region, each holding that region's dimensions and nothing
 * else.
 *
 * <h2>Why the folder exists</h2>
 * <p>
 * These constants used to live in a single {@code Dim} class with a nested
 * class per region. That worked at six regions and stopped working at fifteen:
 * the file passed 800 lines, and finding the footer's padding meant scrolling
 * past the entire ribbon. Splitting by region means the file you open is the
 * region you are working on, and adding a region is adding a file rather than
 * editing a shared one.
 * </p>
 *
 * <h2>The rules</h2>
 * <ol>
 * <li><b>One region per file</b>, named {@code &lt;Region&gt;_dim}. A new region
 * is a new file; nothing else changes.</li>
 * <li><b>Only layout geometry lives here.</b> Colours belong in
 * {@code themes/light.css} and {@code themes/dark.css}. Font sizes and weights
 * belong in {@link ui.design.Typography}. A one-off offset used inside a single
 * custom widget stays in that widget.</li>
 * <li><b>Every length is written at scale 1.0</b> and wrapped in
 * {@link ui.design.UIScale#px} or {@link ui.design.UIScale#pxi}, both static-
 * imported for readability. Values that are <em>not</em> lengths -- divider
 * fractions, layout unit counts, scale ratios -- are never wrapped, and say so
 * in a comment.</li>
 * <li><b>Hairlines stay at 1.</b> A 1px border scaled to 1.15 renders as a grey
 * smear, so border and divider widths are left unscaled on purpose.</li>
 * <li><b>Derive, do not restate.</b> Where one number is the sum of others -- a
 * band height, a toolbar's horizontal inset, a free-unit count -- compute it.
 * That is what stopped {@code ROW_HEIGHT} ending in an unexplained {@code + 10}
 * and what stops the Home band's used-unit count drifting from the
 * compartments that consume them.</li>
 * <li><b>Cross-region references are fine</b> and preferable to copying a
 * number. {@code Explorer_dim.RAIL_WIDTH} reading {@code TitleBar_dim.HEIGHT}
 * states the relationship instead of duplicating the value.</li>
 * </ol>
 *
 *
 * <h2>Why these classes are not final</h2>
 * <p>
 * Each of them is extended by a nested class in {@link ui.design.Dim}, which is
 * the single front door the rest of the application calls through. That is why
 * the classes here are plain {@code public class} with a {@code protected}
 * constructor rather than {@code final} with a private one. There is no other
 * reason to subclass them, and no reason to instantiate them at all.
 * </p>
 * <h2>Where they are used</h2>
 * <p>
 * Java code does not normally import these directly -- it calls
 * {@link ui.design.Dim}, whose nested classes map onto the files here, so a
 * call site says {@code Dim.Footer.PAD_V} and never has to track which file a
 * constant lives in.
 * {@link ui.design.DesignStylesheet} reads all of them and emits the matching
 * CSS at startup, so a dimension is never written twice.
 * </p>
 *
 * <h2>Regions still on literals</h2>
 * <p>
 * Variable Explorer table, File Directory tree, CLI. Each gets its own file
 * here when its turn comes.
 * </p>
 * <p>
 * Editor Tab is part-way: the gutter and the code inset are in
 * {@code Editor_dim}; the paragraph and sub/superscript metrics in
 * {@code themes/editorColor/editor_*.css} are still literals.
 * </p>
 */
package ui.design.section_dims;
