package ui.design.section_dims;

import static ui.design.UIScale.pxi;

/**
 * Default raster icon sizes shared across the icon loaders.
 *
 * <p>
 * Region-specific sizes live with their region -- a ribbon compartment icon is
 * in {@link ToolBand_dim}, a breadcrumb chevron in {@link BreadcrumbBar_dim}. Only
 * genuine fallbacks belong here.
 * </p>
 */
public class Icons_dim {

    /**
     * Size used by {@code ToolbarIcons.icon(path)} when no size is given.
     * Historically 22.
     */
    public static final double TOOLBAR_DEFAULT = pxi(22);

    protected Icons_dim() {
    }
}
