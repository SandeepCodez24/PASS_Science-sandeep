package ui.design.section_dims;

import ui.design.Typography;

import static ui.design.UIScale.px;
import static ui.design.UIScale.pxi;

/**
 * Row 1: the tab strip (Home / Signals / JTAG / Commission / Settings / Help),
 * the search box, and the trailing action cluster.
 *
 * <h3>The tab's two edges -- read this before changing anything below</h3>
 * <p>
 * The selected tab has to do two contradictory things at once: touch the Row-2
 * band at the bottom with no seam, and stay clear of the title bar at the top
 * by a visible margin.
 * </p>
 * <p>
 * Both come from <b>one</b> number and <b>one</b> mechanism. The tab block (the
 * {@code HBox} holding the six tabs) fills the strip's full height, and each
 * tab carries {@link #TAB_INSET_TOP} as an {@code HBox} <i>layout margin</i> on
 * its top edge, set in {@code ToolbarRibbon}. {@code HBox} subtracts a child's
 * margin from the area it lays that child into, and the tab then fills exactly
 * what is left:
 * </p>
 * <pre>
 *   strip content box     0 .......................... 30
 *   tab block padding     |---4---|
 *   tab (fills)                   4 .................. 30
 *                              navy above        flush with band
 * </pre>
 * <p>
 * The bottom edge is flush because the bottom margin is zero and the tab fills
 * to it. The gap above is exactly {@link #TAB_INSET_TOP} because that is the
 * margin the tab is filling inside. Neither edge can drift.
 * </p>
 * <p>
 * <b>Why a margin.</b> {@code -fx-padding} is a styleable property: anything
 * set programmatically is origin {@code USER} and any author rule that matches
 * the node overrides it, so a padding-based gap is only ever as reliable as
 * one's knowledge of the entire resolved cascade -- Modena, both theme files,
 * the ribbon sheets, the generated sheet. Layout margins are not styleable.
 * There is no {@code -fx-margin} in JavaFX CSS; a margin is a constraint the
 * parent stores in the child's property map, and no stylesheet, skin, theme
 * swap or DPI rule can reach it. The gap is the one number in this design the
 * cascade cannot participate in, which is the property it needed.
 * </p>
 *
 * <h3>Four things that were tried first, and why they are not here</h3>
 * <ol>
 * <li><b>Strip padding.</b> Moves the tab's whole box down, which takes the
 * same amount off the bottom -- the edge that has to stay flush.</li>
 * <li><b>Paint insets</b> ({@code -fx-background-insets} on the tab). Right
 * idea, but Modena hands {@code .toggle-button} a four-layer inset of its own
 * and the tab's fill arrives from a different rule than its insets. The tab
 * kept painting from its top edge.</li>
 * <li><b>A pinned tab height, bottom-aligned.</b> The pin did not hold: the tab
 * reverted to its natural content height of about 21, so the gap was
 * {@code HEIGHT - 21} rather than the value set here -- roughly six pixels, and
 * completely deaf to this constant. It also pushed the label below the strip's
 * centre line, which is why it looked like two unrelated bugs. Never put
 * {@code -fx-pref-height} on {@code .ribbon-tab}.</li>
 * <li><b>Padding on the tab block.</b> Correct arithmetic and the right node,
 * but still a styleable property, and raising this constant from 2 to 4 changed
 * nothing on screen -- which is the signature of a value being overridden
 * rather than being wrong. Hence the margin.</li>
 * </ol>
 * <p>
 * All four failed in CSS, which is why the gap is now a margin. But none of
 * them was the whole story, and the real cause is worth stating plainly.
 * </p>
 *
 * <h3>The actual root cause, found by measurement</h3>
 * <p>
 * {@code ToolBarSkin} sizes its internal container to that container's
 * <em>preferred</em> height and centres it in the bar, instead of handing it
 * the bar's content box. The tab strip's content row prefers about 38 -- the
 * height of the right-hand action cluster -- so inside a 30-tall strip it was
 * being centred at {@code y = -4}.
 * </p>
 * <p>
 * Every gap in this design is measured from that row, so four pixels of gap put
 * the tab's top edge at absolute zero and pushed its bottom four pixels into
 * the band, where it was invisible because the tab and the band share a colour
 * by design. The gap was always being created and always being cancelled, which
 * is exactly why changing {@link #TAB_INSET_TOP} from 2 to 4 had no visible
 * effect and looked like a value being ignored.
 * </p>
 * <p>
 * {@code ToolbarRibbon} now pins that row to {@link #HEIGHT}. With the offset
 * at zero the margin means what it says. It also explains the layout that
 * existed before any of this work: the old tab was about 21 tall in the same
 * 38-tall row, so centring put it near 4 and it looked correct by accident.
 * </p>
 *
 * <h3>Why {@link #HEIGHT} is 30 and no longer 28</h3>
 * <p>
 * It was 28 because a JavaFX {@code TextField} at 12px is about 27px tall, so
 * the search box needed at least that; 28 was the floor, not a considered
 * height. The tab design then asked 28 to hold three things at once: a navy gap
 * big enough to see, a label centred on the strip's centre line, and enough
 * room for that label at {@link #TAB_FONT_SCALE} in bold. At 28 the three fit
 * with one pixel to spare, which is another way of saying the label was one
 * font tweak away from clipping. Thirty gives the gap four pixels and the label
 * twenty, and the whole strip is two pixels taller -- a cost worth paying once,
 * rather than trading the gap against the label every time the font moves.
 * </p>
 *
 * <h3>Where the label sits</h3>
 * <p>
 * The tab spans {@link #TAB_INSET_TOP}..{@link #HEIGHT}, so its own centre is
 * half the gap below the strip's centre. {@link #TAB_PAD_BOTTOM} is
 * {@link #TAB_PAD_TOP} plus {@link #TAB_INSET_TOP}, and that difference pulls
 * the label's centre back onto the strip's centre line exactly. Derived, never
 * stated -- change {@link #TAB_INSET_TOP} and the label stays centred.
 * </p>
 * <p>
 * When the band is collapsed there is nothing below to merge into, so the same
 * inset is applied as the block's bottom padding too. The tab is then centred
 * in the strip on its own and the label's padding goes back to symmetric.
 * </p>
 *
 * <h3>Checking it</h3>
 * <p>
 * Launch with {@code -Dastra.ribbon.debug=true}. {@code ToolbarRibbon} prints
 * the Home tab's bounds converted into the <i>strip's</i> coordinates, so
 * {@code gap} is the real distance below the title bar and {@code overhang} is
 * how far the tab runs past the strip's bottom edge. The last line of a healthy
 * run reads:
 * </p>
 * <pre>
 *   [Ribbon] strip h=30.0 | tab in strip y=4.0..30.0 h=26.0
 *            | gap=4.0 (expected 4.0) | overhang=0.0 (expected 0.0)
 * </pre>
 * <p>
 * Reporting in strip coordinates is the point. The earlier version printed
 * parent-relative bounds, where the tab read {@code y=4} while actually sitting
 * at absolute zero, because its parent was offset by -4. Relative to the strip
 * an offset has nowhere to hide.
 * </p>
 */
public class RibbonBar_dim {

    /**
     * Height of the tab strip as designed: 30, and never less.
     *
     * <p>
     * Thirty, not 28 -- see the class notes. The lower bound is still the
     * search box: a {@code TextField} at 12px is roughly 27px tall, so anything
     * below 28 clips its borders.
     * </p>
     */
    public static final double BASE_HEIGHT = pxi(30);

    /**
     * Height of the tab strip in force. min, pref and max are all pinned to it,
     * in {@code ToolbarRibbon} and in the generated stylesheet.
     *
     * <p>
     * {@link #BASE_HEIGHT} at the default UI font size. A larger size grows it
     * by exactly what the tab label or the search box needs, so the label is
     * never clipped; recomputed by {@link #recomputeTextHeights()}.
     * </p>
     */
    public static double HEIGHT;

    /**
     * Strip padding, top edge.
     *
     * <p>
     * Zero on purpose. The gap above the tab is {@link #TAB_INSET_TOP}, applied
     * to the tab block, not here. A value here does not add to the gap; it
     * shortens the strip's content box, which takes the same amount off the
     * bottom edge -- the one that has to stay flush.
     * </p>
     */
    public static final double PAD_TOP = px(0);

    /**
     * Strip padding, bottom edge.
     *
     * <p>
     * Zero on purpose. Any value here is a navy line between the tab and the
     * band, which is the exact defect this design removes.
     * </p>
     */
    public static final double PAD_BOTTOM = px(0);

    /** Strip padding, leading and trailing. */
    public static final double PAD_H = px(8);

    /**
     * Total horizontal padding of the strip.
     *
     * <p>
     * Only used if the strip is ever a stock {@code ToolBar} again; the
     * {@code RibbonBar} strip hands its row the content box directly, so the
     * padding is taken off by the skin.
     * </p>
     */
    public static final double H_INSET = PAD_H * 2;

    /** Gap between the tab block, the search box and the action cluster. */
    public static final double ROOT_SPACING = px(6);

    // =====================================================================
    // Where the search box sits. Fractions, never scaled.
    // =====================================================================
    //
    // The tabs no longer take a share of the strip: each is exactly as wide
    // as its label needs (at least TAB_MIN_WIDTH), so no tab is ever cut to
    // "S..." or "Com...". The two fractions below now only position the
    // search box on a wide window -- it starts at TABS_FRACTION +
    // GAP_FRACTION of the strip, the same place as before. On a narrower
    // window it slides left towards the tabs, then shrinks to
    // SEARCH_MIN_WIDTH, and below that it is hidden. See
    // ToolbarRibbon.StripRow.

    /** First part of the search box's resting start position. */
    public static final double TABS_FRACTION = 0.40;

    /** Second part of the search box's resting start position. */
    public static final double GAP_FRACTION = 0.275;

    /** Search box width as a share of the strip, within the bounds below. */
    public static final double SEARCH_FRACTION = 0.15;

    /** The search box never shrinks below this; under it, it is hidden. */
    public static final double SEARCH_MIN_WIDTH = px(160);

    /** The search box never grows beyond this on a very wide window. */
    public static final double SEARCH_MAX_WIDTH = px(320);

    // =====================================================================
    // One tab
    // =====================================================================

    /**
     * Navy showing above the tab.
     *
     * <p>
     * THE knob, and a literal one: it is each tab's top {@code HBox} margin and
     * the tab fills what is left, so the gap on screen is this number and
     * nothing else. Raising it can only eat into the tab from the top; the
     * bottom edge is the zero bottom margin and is not reachable from here.
     * </p>
     * <p>
     * Four. Two was correct arithmetic and still read as no gap at all, because
     * the tab is now the same colour as the band -- there is no longer a change
     * of tone to imply the edge, so the navy has to carry it alone. Four is
     * also roughly the midpoint of the two states already seen and rejected:
     * about six pixels when the pinned-height version was silently oversizing
     * it, and two when it was honest but too thin.
     * </p>
     */
    public static final double TAB_INSET_TOP = px(4);

    /**
     * Tab padding, top edge.
     *
     * <p>
     * Keeps the label off the tab's top border. Small on purpose: the tab is
     * only {@code HEIGHT - TAB_INSET_TOP} tall and the label needs the room.
     * </p>
     */
    public static final double TAB_PAD_TOP = px(1);

    /**
     * Tab padding, bottom edge, while the band is open.
     *
     * <p>
     * {@link #TAB_PAD_TOP} plus {@link #TAB_INSET_TOP}. The tab starts one gap
     * below the strip's top but ends flush with its bottom, so its own centre
     * is half a gap low; paying the gap back as bottom padding moves the label
     * -- and only the label -- onto the strip's centre line.
     * </p>
     */
    public static final double TAB_PAD_BOTTOM = TAB_PAD_TOP + TAB_INSET_TOP;

    /** Tab padding, leading and trailing. */
    public static final double TAB_PAD_H = px(16);

    /**
     * Narrowest a tab is drawn. A tab is otherwise exactly as wide as its
     * label plus {@link #TAB_PAD_H}; this only pads out the short ones
     * ("Home", "JTAG", "Help") so they do not look cramped beside
     * "Commission". It never cuts a label -- a longer label simply makes a
     * wider tab.
     */
    public static final double TAB_MIN_WIDTH = px(72);

    /**
     * Multiplier on the tab label's font size.
     *
     * <p>
     * 1.0: the tab label is the one UI font size, bold. It used to be 1.05,
     * a step above the rest of the chrome; with a single central size the
     * weight alone sets the tabs apart.
     * </p>
     * <p>
     * The label has {@code HEIGHT - TAB_INSET_TOP - TAB_PAD_TOP -
     * TAB_PAD_BOTTOM} of room. {@link #HEIGHT} grows so that room always holds
     * one line of the label.
     * </p>
     */
    public static final double TAB_FONT_SCALE = 1.0;

    /** Whether the tab label is emboldened along with {@link #TAB_FONT_SCALE}. */
    public static final boolean TAB_FONT_BOLD = true;

    /**
     * Corner rounding of a hovered or selected tab.
     *
     * <p>
     * Applied to the top two corners only while the band is open; all four once
     * it is collapsed.
     * </p>
     */
    public static final double TAB_RADIUS = px(3);

    /**
     * Border drawn around the selected tab. Unscaled.
     *
     * <p>
     * Drawn on the top, left and right edges while the band is open, and on all
     * four once it is collapsed. The resting tab carries the same widths in
     * transparent, so nothing shifts when selection lands on it.
     * </p>
     */
    public static final double TAB_BORDER = 1;

    // =====================================================================
    // Search box
    // =====================================================================

    /** Outer height of the search box as designed; never less. */
    public static final double BASE_SEARCH_BOX_HEIGHT = pxi(22);

    /** Inner height of the text field as designed; never less. */
    public static final double BASE_SEARCH_FIELD_HEIGHT = pxi(20);

    /**
     * Vertical room a search field needs beyond one line of its text: its
     * own top and bottom inset. 3 makes a 12px line fit
     * {@link #BASE_SEARCH_FIELD_HEIGHT} exactly.
     */
    public static final double SEARCH_FIELD_TEXT_PAD = px(3);

    /**
     * The strip keeps at least this much room above and below the search box,
     * together.
     */
    public static final double SEARCH_BOX_CLEARANCE = px(4);

    /** Outer height of the search box in force; stays below {@link #HEIGHT}. */
    public static double SEARCH_BOX_HEIGHT;

    /** Inner height of the text field in force. */
    public static double SEARCH_FIELD_HEIGHT;

    /** Gap between the field and the magnifier glyph. */
    public static final double SEARCH_BOX_SPACING = px(6);

    /** Search box padding, leading edge. */
    public static final double SEARCH_BOX_PAD_LEFT = px(4);

    /** Search box padding, trailing edge. */
    public static final double SEARCH_BOX_PAD_RIGHT = px(8);

    /** Text field padding, leading edge. */
    public static final double SEARCH_FIELD_PAD_LEFT = px(8);

    /** Text field padding, trailing edge. */
    public static final double SEARCH_FIELD_PAD_RIGHT = px(6);

    /** Corner rounding of the search box. */
    public static final double SEARCH_RADIUS = px(3);

    /** Border around the search box. Unscaled. */
    public static final double SEARCH_BORDER = 1;

    /** Edge length of the magnifier glyph. */
    public static final double SEARCH_ICON_SIZE = pxi(16);

    // =====================================================================
    // Trailing action cluster
    // =====================================================================

    /** Edge length of an undo / redo / save / print / bell glyph. */
    public static final double ACTION_ICON_SIZE = pxi(18);

    /** Padding inside an action icon button. */
    public static final double ACTION_BUTTON_PADDING = px(2);

    /** Corner rounding of an action icon button's hover fill. */
    public static final double ACTION_BUTTON_RADIUS = px(3);

    /** Gap between the four tight action icons. */
    public static final double ACTIONS_SPACING = px(2);

    /** Gap between the action block, the bell and the account control. */
    public static final double CLUSTER_SPACING = px(10);

    // =====================================================================
    // Style-class hooks shared between the Java and the generated stylesheet
    // =====================================================================

    /**
     * Style class put on the tab strip while the Row-2 band is hidden.
     *
     * <p>
     * Owned here rather than in {@code RibbonCollapse} so the Java that adds it
     * and the stylesheet that reads it come from one constant.
     * </p>
     */
    public static final String COLLAPSED_CLASS = "band-collapsed";

    /**
     * Style class on the {@code HBox} holding the six tabs.
     *
     * <p>
     * It needs one because that box's <i>padding</i> is the gap above the tab,
     * and the collapsed state adds the same padding at the bottom. Both come
     * from the generated stylesheet.
     * </p>
     */
    public static final String TAB_BOX_CLASS = "ribbon-tab-box";

    // =====================================================================
    // Heights that follow the UI font size
    // =====================================================================

    static {
        recomputeTextHeights();
    }

    /**
     * Recomputes {@link #HEIGHT}, {@link #SEARCH_BOX_HEIGHT} and
     * {@link #SEARCH_FIELD_HEIGHT} for the UI font size in force. Each is its
     * design value, or what its text needs if that is more.
     */
    public static void recomputeTextHeights() {
        double field = Typography.lineHeight(Typography.Role.SEARCH_FIELD) + SEARCH_FIELD_TEXT_PAD;
        SEARCH_FIELD_HEIGHT = Math.max(BASE_SEARCH_FIELD_HEIGHT, Math.ceil(field));
        SEARCH_BOX_HEIGHT = Math.max(BASE_SEARCH_BOX_HEIGHT, SEARCH_FIELD_HEIGHT + 2 * SEARCH_BORDER);

        double tabLabel = Typography.lineHeight(Typography.Role.RIBBON_TAB, TAB_FONT_SCALE);
        double forTab = TAB_INSET_TOP + TAB_PAD_TOP + tabLabel + TAB_PAD_BOTTOM;
        double forSearch = SEARCH_BOX_HEIGHT + SEARCH_BOX_CLEARANCE;
        HEIGHT = Math.max(BASE_HEIGHT, Math.ceil(Math.max(forTab, forSearch)));
    }

    protected RibbonBar_dim() {
    }
}
