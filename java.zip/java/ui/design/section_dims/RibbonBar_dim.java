package ui.design.section_dims;

import static ui.design.UIScale.px;
import static ui.design.UIScale.pxi;

/**
 * Row 1: the tab strip (Home / Signals / JTAG / Commission / Settings / Help),
 * the search box, and the trailing action cluster.
 *
 * <p>
 * {@link #HEIGHT} is 28 for a reason worth preserving. A JavaFX
 * {@code TextField} at 12px is roughly 27px tall, so 24 clipped the search
 * box's top and bottom borders; anything much below 28 will clip it again.
 * </p>
 */
public class RibbonBar_dim {

    /** Height of the tab strip. min, pref and max are all pinned to it. */
    public static final double HEIGHT = pxi(28);

    /** Strip padding, top and bottom. */
    public static final double PAD_V = px(2);

    /** Strip padding, leading and trailing. */
    public static final double PAD_H = px(8);

    /**
     * Total horizontal padding of the strip.
     *
     * <p>
     * The content row's width is bound to the bar's width minus this. It used
     * to be a literal 20 copied from the Row-2 band, which left the content row
     * 4px narrower than the space actually available.
     * </p>
     */
    public static final double H_INSET = PAD_H * 2;

    /** Gap between the tab block, the search box and the action cluster. */
    public static final double ROOT_SPACING = px(6);

    // =====================================================================
    // Proportions across the strip. Fractions, never scaled.
    // =====================================================================

    /** Share of the strip width occupied by the six tabs. */
    public static final double TABS_FRACTION = 0.40;

    /** Fixed gap between the tabs and the search box. */
    public static final double GAP_FRACTION = 0.275;

    /** Share of the strip width occupied by the search box. */
    public static final double SEARCH_FRACTION = 0.15;

    // =====================================================================
    // One tab
    // =====================================================================

    /** Tab padding, top and bottom. */
    public static final double TAB_PAD_V = px(3);

    /** Tab padding, leading and trailing. */
    public static final double TAB_PAD_H = px(16);

    /** Corner rounding of a hovered or selected tab. */
    public static final double TAB_RADIUS = px(3);

    /** Border drawn around the selected tab. Unscaled. */
    public static final double TAB_BORDER = 1;

    // =====================================================================
    // Search box
    // =====================================================================

    /** Outer height of the search box; must stay below {@link #HEIGHT}. */
    public static final double SEARCH_BOX_HEIGHT = pxi(22);

    /** Inner height of the text field itself. */
    public static final double SEARCH_FIELD_HEIGHT = pxi(20);

    /** Gap between the field and the magnifier glyph. */
    public static final double SEARCH_BOX_SPACING = px(6);

    /** Search box padding, leading edge. */
    public static final double SEARCH_BOX_PAD_LEFT = px(4);

    /** Search box padding, trailing edge. */
    public static final double SEARCH_BOX_PAD_RIGHT = px(8);

    /** Text field padding, leading edge. */
    public static final double SEARCH_FIELD_PAD_LEFT = px(8);

    /** Text field padding, trailing edge. */
    public static final double SEARCH_FIELD_PAD_RIGHT = px(6);

    /** Corner rounding of the search box. */
    public static final double SEARCH_RADIUS = px(3);

    /** Border around the search box. Unscaled. */
    public static final double SEARCH_BORDER = 1;

    /** Edge length of the magnifier glyph. */
    public static final double SEARCH_ICON_SIZE = pxi(16);

    // =====================================================================
    // Trailing action cluster
    // =====================================================================

    /** Edge length of an undo / redo / save / print / bell glyph. */
    public static final double ACTION_ICON_SIZE = pxi(18);

    /** Padding inside an action icon button. */
    public static final double ACTION_BUTTON_PADDING = px(2);

    /** Corner rounding of an action icon button's hover fill. */
    public static final double ACTION_BUTTON_RADIUS = px(3);

    /** Gap between the four tight action icons. */
    public static final double ACTIONS_SPACING = px(2);

    /** Gap between the action block, the bell and the account control. */
    public static final double CLUSTER_SPACING = px(10);

    protected RibbonBar_dim() {
    }
}
