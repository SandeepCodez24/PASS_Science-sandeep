package ui.design.section_dims;

import static ui.design.UIScale.px;
import static ui.design.UIScale.pxi;

/**
 * The Signals compare control: two drop-down selectors side by side with an
 * action zone spanning the full width beneath them.
 *
 * <pre>
 *   +-------------------------------+
 *   | Select 1  v  |  Select 2  v   |   two select zones
 *   +-------------------------------+
 *   |           Compare             |   action zone
 *   +-------------------------------+
 * </pre>
 *
 * <p>
 * The control's overall height comes from {@code ToolBand_dim.ITEM_HEIGHT}: it
 * sits in a compartment alongside plain buttons and has to match them.
 * </p>
 */
public class CompareButton_dim {

    /** Gap between the selector row and the action zone. */
    public static final double SPACING = px(3);

    /** Padding inside the outer rectangle. */
    public static final double PADDING = px(3);

    /** Gap between the two selectors. */
    public static final double ZONE_GAP = px(3);

    /** Height of a selector and of the action zone. */
    public static final double ZONE_HEIGHT = pxi(22);

    /** Corner rounding of the outer rectangle. */
    public static final double OUTER_RADIUS = px(5);

    /** Border around the outer rectangle. Unscaled. */
    public static final double OUTER_BORDER = 1;

    /** Corner rounding of a zone. */
    public static final double ZONE_RADIUS = px(3);

    /** Border around the action zone. Unscaled. */
    public static final double ZONE_BORDER = 1;

    /** Selector padding, leading edge. */
    public static final double SELECT_PAD_LEFT = px(6);

    /** Selector padding, trailing edge. */
    public static final double SELECT_PAD_RIGHT = px(5);

    /** Width of a selector's triangle. */
    public static final double ARROW_WIDTH = px(8);

    /** Height of a selector's triangle. Also the drawn shape height. */
    public static final double ARROW_HEIGHT = px(5);

    protected CompareButton_dim() {
    }
}
