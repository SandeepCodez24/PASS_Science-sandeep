package ui.design.section_dims;

import static ui.design.UIScale.px;
import static ui.design.UIScale.pxi;

/** The collapsible side panels: File Explorer and Variable Explorer. */
public class Explorer_dim {

    /** Preferred width of a side panel when expanded. */
    public static final double PANEL_PREF_WIDTH = px(220);

    /** Width below which a side panel refuses to shrink. */
    public static final double PANEL_MIN_WIDTH = px(160);

    /** Width of the vertical rail a collapsed panel shrinks to. */
    public static final double RAIL_WIDTH = pxi(28);

    /** Gap between the expand button and the rotated title on the rail. */
    public static final double RAIL_SPACING = px(4);

    protected Explorer_dim() {
    }
}
