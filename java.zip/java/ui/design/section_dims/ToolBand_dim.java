package ui.design.section_dims;

import ui.design.Typography;

import static ui.design.UIScale.px;
import static ui.design.UIScale.pxi;

/**
 * Row 2: the band shared by every tab.
 *
 * <p>
 * Home and Signals lay compartments across it; JTAG, Commission, Settings and
 * Help still use a flat row of buttons. All six live in one {@code StackPane},
 * so they must agree on {@link #ROW_HEIGHT}.
 * </p>
 *
 * <p>
 * The band is taller than it was by exactly the height the quick-access row
 * gave up; see {@link #ITEM_HEIGHT}.
 * </p>
 *
 * <p>
 * The per-band unit ratios are in {@link HomeBand_dim} and
 * {@link SignalBand_dim}; the three custom controls are in
 * {@link SplitButton_dim}, {@link CompareButton_dim} and {@link Readout_dim}.
 * </p>
 */
public class ToolBand_dim {

    /** Band padding, top and bottom. */
    public static final double PAD_V = px(4);

    /** Band padding, leading and trailing, for the compartment bands. */
    public static final double PAD_H = px(10);

    /**
     * Total horizontal padding of a compartment band.
     *
     * <p>
     * Subtracted before the unit width is computed, so the ratios describe the
     * usable interior rather than the raw control width. This used to be a
     * literal 20 in {@code RibbonLayout} that had to be kept in step with the
     * CSS by hand, warned about in three separate comments.
     * {@code DesignStylesheet} now emits that padding from {@link #PAD_H}, so
     * the two cannot drift.
     * </p>
     */
    public static final double H_INSET = PAD_H * 2;

    /**
     * Height of the icon / readout row as originally drawn, before the
     * quick-access row gave up part of its height.
     */
    public static final double BASE_ITEM_HEIGHT = px(66);

    /**
     * Height of the icon / readout row inside a compartment as designed: the
     * base row plus the pixels the quick-access row gave up when it was made
     * 20% shorter ({@link NavigationBar_dim#SAVED_HEIGHT}). Never less.
     */
    public static final double DESIGN_ITEM_HEIGHT = BASE_ITEM_HEIGHT + NavigationBar_dim.SAVED_HEIGHT;

    /**
     * Height of the icon / readout row inside a compartment, in force.
     *
     * <p>
     * {@link #DESIGN_ITEM_HEIGHT} at the default UI font size. A larger size
     * grows it to whatever the tallest compartment content needs -- in
     * practice the two stacked Analysis readouts, then the three Views rows --
     * so nothing in the band is clipped. {@link #ROW_HEIGHT} follows it, and so
     * does everything sized from it: the item buttons, the Files split buttons
     * (their icon zone absorbs the extra), the compare control, the Views rows
     * and the Layout band's gallery and zoom rows.
     * </p>
     * <p>
     * Recomputed by {@link #recomputeTextHeights()}.
     * </p>
     */
    public static double ITEM_HEIGHT;

    /** Height of the compartment caption strip as designed; never less. */
    public static final double BASE_CAPTION_HEIGHT = px(18);

    /** Room the caption strip keeps around one line of its text. */
    public static final double CAPTION_TEXT_PAD = px(1);

    /**
     * Height of the compartment caption strip along the bottom, in force: the
     * design value, or one line of the caption plus {@link #CAPTION_TEXT_PAD}
     * if that is more.
     */
    public static double CAPTION_HEIGHT;

    /** Gap between the item row and the caption. */
    public static final double GROUP_SPACING = px(2);

    /** Breathing room below the caption so descenders are never clipped. */
    public static final double ROW_SLACK = px(2);

    /**
     * Total height of the band: the item row (which already includes the height
     * handed over by the quick-access row), the gap, the caption, the band's
     * own vertical padding and a little slack.
     *
     * <p>
     * Derived rather than stated, and recomputed with {@link #ITEM_HEIGHT}
     * and {@link #CAPTION_HEIGHT}.
     * </p>
     */
    public static double ROW_HEIGHT;

    /**
     * Enlargement applied to compartment icons, a ratio (not scaled). Raised
     * from 1.0 when the band gained the quick-access row's saved height.
     */
    public static final double ICON_SCALE = 1.07;

    /** Edge length of a compartment icon: 28 at 1.0, 30 at 1.07. */
    public static final double ICON_SIZE = pxi(28 * ICON_SCALE);

    /** Width of one vertical divider between compartments. Unscaled. */
    public static final double SEPARATOR_WIDTH = 1;

    /** Inset of a divider from the top and bottom of the band. */
    public static final double SEPARATOR_MARGIN_V = px(6);

    /** Compartment padding, leading and trailing. */
    public static final double GROUP_PAD_H = px(4);

    /** Gap between items inside a compartment. */
    public static final double ITEM_SPACING = px(2);

    /** Compartment caption padding, leading and trailing. */
    public static final double CAPTION_PAD_H = px(2);

    /** Padding inside a compartment item button. */
    public static final double ITEM_PADDING = px(2);

    /** Corner rounding of a compartment item button's hover fill. */
    public static final double ITEM_RADIUS = px(4);

    /** Gap between an item's icon and its label. */
    public static final double ITEM_GRAPHIC_GAP = px(4);

    // =====================================================================
    // Collapsed compartments (RibbonBand)
    // =====================================================================
    // When a band is too narrow for every compartment at its natural width,
    // compartments collapse right to left into one button each; clicking it
    // opens the full compartment in a drop-down panel.

    /** Gap between a collapsed compartment's icon and its triangle. */
    public static final double COLLAPSED_ARROW_GAP = px(3);

    /** Padding inside a collapsed compartment's drop-down panel. */
    public static final double POPUP_PAD = px(4);

    /** Corner rounding of that panel. */
    public static final double POPUP_RADIUS = px(4);

    /** Border around that panel. Unscaled. */
    public static final double POPUP_BORDER = 1;

    // =====================================================================
    // The four tabs still using a flat button row
    // =====================================================================

    /**
     * Band padding, leading and trailing, for a flat row.
     *
     * <p>
     * Deliberately not {@link #PAD_H}. The compartment bands sit at 10 so their
     * unit ratios line up with {@link #H_INSET}; the flat rows have always sat
     * at 8 and have no unit maths to satisfy.
     * </p>
     */
    public static final double FLAT_PAD_H = px(8);

    /** Width of a flat Row-2 button. */
    public static final double FLAT_BUTTON_WIDTH = px(110);

    /** Height of a flat Row-2 button. */
    public static final double FLAT_BUTTON_HEIGHT = px(58);

    /** Gap between a flat button's icon and its label. */
    public static final double FLAT_GRAPHIC_GAP = px(3);

    // =====================================================================
    // The compact horizontal button used outside the ribbon
    // =====================================================================

    /** Height of the compact action button. */
    public static final double COMPACT_BUTTON_HEIGHT = px(30);

    /** Gap between a compact button's icon and its label. */
    public static final double COMPACT_GRAPHIC_GAP = px(6);

    /** Compact button padding, top and bottom. */
    public static final double COMPACT_PAD_V = px(3);

    /** Compact button padding, leading and trailing. */
    public static final double COMPACT_PAD_H = px(10);

    /** Corner rounding of a compact button. */
    public static final double COMPACT_RADIUS = px(4);

    // =====================================================================
    // Heights that follow the UI font size
    // =====================================================================

    static {
        recomputeTextHeights();
    }

    /**
     * Recomputes {@link #CAPTION_HEIGHT}, {@link #ITEM_HEIGHT} and
     * {@link #ROW_HEIGHT} for the UI font size in force, then hands the new
     * item row to the classes derived from it ({@link HomeViews_dim},
     * {@link Layout_dim}). Call after
     * {@link CompareButton_dim#recomputeTextHeights()}.
     */
    public static void recomputeTextHeights() {
        CAPTION_HEIGHT = Math.max(BASE_CAPTION_HEIGHT,
                Math.ceil(Typography.lineHeight(Typography.Role.GROUP_CAPTION) + CAPTION_TEXT_PAD));

        ITEM_HEIGHT = Math.max(DESIGN_ITEM_HEIGHT, Math.ceil(tallestItemContent()));

        ROW_HEIGHT = ITEM_HEIGHT + GROUP_SPACING + CAPTION_HEIGHT + (PAD_V * 2) + ROW_SLACK;

        HomeViews_dim.deriveFromItemHeight(ITEM_HEIGHT);
        Layout_dim.deriveFromItemHeight(ITEM_HEIGHT);
    }

    /**
     * What the tallest piece of compartment content needs at the current UI
     * font size. Each term is that control's own stack, written out from the
     * same constants the control and the generated stylesheet use.
     */
    private static double tallestItemContent() {
        double item = Typography.textHeight(Typography.Role.RIBBON_ITEM, 1.0);
        double split = Typography.textHeight(Typography.Role.SPLIT_LABEL, 1.0);
        double title = Typography.textHeight(Typography.Role.READOUT_TITLE, 1.0);
        double value = Typography.textHeight(Typography.Role.READOUT_VALUE, 1.0);

        // A plain item: icon on top, label beneath.
        double plain = ICON_SIZE + ITEM_GRAPHIC_GAP + item + 2 * ITEM_PADDING;

        // The Files split button: icon zone over label, triangle, padding.
        double splitButton = SplitButton_dim.ICON_ZONE_PAD_TOP + ICON_SIZE
                + SplitButton_dim.ICON_ZONE_PAD_BOTTOM
                + SplitButton_dim.MENU_ZONE_PAD_TOP + split
                + SplitButton_dim.MENU_ZONE_SPACING + SplitButton_dim.ARROW_HEIGHT
                + SplitButton_dim.MENU_ZONE_PAD_BOTTOM + 2 * SplitButton_dim.OUTER_BORDER;

        // The Signals compare control: two zone rows inside the outline.
        double compare = 2 * CompareButton_dim.ZONE_HEIGHT + CompareButton_dim.SPACING
                + 2 * CompareButton_dim.PADDING + 2 * CompareButton_dim.OUTER_BORDER;

        // The Analysis compartment: two readouts, caption over value.
        double readout = title + value + 2 * Readout_dim.PAD_V + 2 * Readout_dim.BORDER;
        double readouts = 2 * readout + Readout_dim.STACK_SPACING;

        // The Views compartment: three rows, icon or label, whichever is taller.
        double viewsRow = Math.max(HomeViews_dim.ICON_SIZE, item)
                + 2 * HomeViews_dim.PAD_V + 2 * HomeViews_dim.BORDER;
        double views = HomeViews_dim.ROWS * viewsRow + (HomeViews_dim.ROWS - 1) * HomeViews_dim.ROW_SPACING;

        return Math.max(Math.max(plain, splitButton), Math.max(compare, Math.max(readouts, views)));
    }

    protected ToolBand_dim() {
    }
}
