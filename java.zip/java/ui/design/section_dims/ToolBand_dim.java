package ui.design.section_dims;

import static ui.design.UIScale.px;
import static ui.design.UIScale.pxi;

/**
 * Row 2: the band shared by every tab.
 *
 * <p>
 * Home and Signals lay compartments across it; JTAG, Commission, Settings and
 * Help still use a flat row of buttons. All six live in one {@code StackPane},
 * so they must agree on {@link #ROW_HEIGHT}.
 * </p>
 *
 * <p>
 * The per-band unit ratios are in {@link HomeBand_dim} and
 * {@link SignalBand_dim}; the three custom controls are in
 * {@link SplitButton_dim}, {@link CompareButton_dim} and {@link Readout_dim}.
 * </p>
 */
public class ToolBand_dim {

    /** Band padding, top and bottom. */
    public static final double PAD_V = px(4);

    /** Band padding, leading and trailing, for the compartment bands. */
    public static final double PAD_H = px(10);

    /**
     * Total horizontal padding of a compartment band.
     *
     * <p>
     * Subtracted before the unit width is computed, so the ratios describe the
     * usable interior rather than the raw control width. This used to be a
     * literal 20 in {@code RibbonLayout} that had to be kept in step with the
     * CSS by hand, warned about in three separate comments.
     * {@code DesignStylesheet} now emits that padding from {@link #PAD_H}, so
     * the two cannot drift.
     * </p>
     */
    public static final double H_INSET = PAD_H * 2;

    /** Height of the icon / readout row inside a compartment. */
    public static final double ITEM_HEIGHT = px(66);

    /** Height of the compartment caption strip along the bottom. */
    public static final double CAPTION_HEIGHT = px(18);

    /** Gap between the item row and the caption. */
    public static final double GROUP_SPACING = px(2);

    /** Breathing room below the caption so descenders are never clipped. */
    public static final double ROW_SLACK = px(2);

    /**
     * Total height of the band: the item row, the gap, the caption, the band's
     * own vertical padding and a little slack.
     *
     * <p>
     * Derived rather than stated. The old value was
     * {@code ITEM_HEIGHT + GROUP_SPACING + CAPTION_HEIGHT + 10}, where the 10
     * was the vertical padding (4 + 4) plus 2 of slack, unnamed.
     * </p>
     */
    public static final double ROW_HEIGHT =
            ITEM_HEIGHT + GROUP_SPACING + CAPTION_HEIGHT + (PAD_V * 2) + ROW_SLACK;

    /** Edge length of a compartment icon. */
    public static final double ICON_SIZE = pxi(28);

    /** Width of one vertical divider between compartments. Unscaled. */
    public static final double SEPARATOR_WIDTH = 1;

    /** Inset of a divider from the top and bottom of the band. */
    public static final double SEPARATOR_MARGIN_V = px(6);

    /** Compartment padding, leading and trailing. */
    public static final double GROUP_PAD_H = px(4);

    /** Gap between items inside a compartment. */
    public static final double ITEM_SPACING = px(2);

    /** Compartment caption padding, leading and trailing. */
    public static final double CAPTION_PAD_H = px(2);

    /** Padding inside a compartment item button. */
    public static final double ITEM_PADDING = px(2);

    /** Corner rounding of a compartment item button's hover fill. */
    public static final double ITEM_RADIUS = px(4);

    /** Gap between an item's icon and its label. */
    public static final double ITEM_GRAPHIC_GAP = px(4);

    // =====================================================================
    // The four tabs still using a flat button row
    // =====================================================================

    /**
     * Band padding, leading and trailing, for a flat row.
     *
     * <p>
     * Deliberately not {@link #PAD_H}. The compartment bands sit at 10 so their
     * unit ratios line up with {@link #H_INSET}; the flat rows have always sat
     * at 8 and have no unit maths to satisfy.
     * </p>
     */
    public static final double FLAT_PAD_H = px(8);

    /** Width of a flat Row-2 button. */
    public static final double FLAT_BUTTON_WIDTH = px(110);

    /** Height of a flat Row-2 button. */
    public static final double FLAT_BUTTON_HEIGHT = px(58);

    /** Gap between a flat button's icon and its label. */
    public static final double FLAT_GRAPHIC_GAP = px(3);

    // =====================================================================
    // The compact horizontal button used outside the ribbon
    // =====================================================================

    /** Height of the compact action button. */
    public static final double COMPACT_BUTTON_HEIGHT = px(30);

    /** Gap between a compact button's icon and its label. */
    public static final double COMPACT_GRAPHIC_GAP = px(6);

    /** Compact button padding, top and bottom. */
    public static final double COMPACT_PAD_V = px(3);

    /** Compact button padding, leading and trailing. */
    public static final double COMPACT_PAD_H = px(10);

    /** Corner rounding of a compact button. */
    public static final double COMPACT_RADIUS = px(4);

    protected ToolBand_dim() {
    }
}
