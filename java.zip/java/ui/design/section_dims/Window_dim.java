package ui.design.section_dims;

import static ui.design.UIScale.px;

/** The top-level application window. */
public class Window_dim {

    /** Initial scene width at first launch. */
    public static final double SCENE_WIDTH = px(1200);

    /** Initial scene height at first launch. */
    public static final double SCENE_HEIGHT = px(720);

    protected Window_dim() {
    }
}
