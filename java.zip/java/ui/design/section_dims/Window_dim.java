package ui.design.section_dims;

import static ui.design.UIScale.px;

/** The top-level application window. */
public class Window_dim {

    /** Initial scene width at first launch. */
    public static final double SCENE_WIDTH = px(1200);

    /** Initial scene height at first launch. */
    public static final double SCENE_HEIGHT = px(720);

    /**
     * Narrowest the window can be dragged.
     *
     * <p>
     * The ribbon never cuts a label any more: the Row-2 bands collapse whole
     * compartments into drop-down buttons, and the Row-1 strip hides the
     * search box. What neither can give up is the six tabs plus the action
     * cluster, about 760 px at scale 1.0; this leaves a margin above that.
     * </p>
     */
    public static final double MIN_WIDTH = px(960);

    /** Shortest the window can be dragged. */
    public static final double MIN_HEIGHT = px(600);

    /**
     * How much of its configured launch width the Variable Explorer opens
     * with, as a ratio (not scaled).
     *
     * <p>
     * The explorer's launch width is {@code 1 - Split_dim.MAIN_RIGHT} of the
     * main split. At 1.0 it opened as the widest of the three panels, and had
     * to be dragged narrower on every launch; 0.5 opens it at half that, and
     * the editor gets the difference. {@code Main_Window} applies it once, at
     * start-up, so dragging the divider afterwards behaves exactly as before.
     * </p>
     */
    public static final double VARIABLE_EXPLORER_LAUNCH_SCALE = 0.5;

    protected Window_dim() {
    }
}
