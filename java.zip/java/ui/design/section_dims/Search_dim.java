package ui.design.section_dims;

import static ui.design.UIScale.px;

/**
 * The find / replace bar that floats at the top right of the editor area.
 *
 * <pre>
 *   [&gt;] [ find ............ x ] [ 3/15 ] [Find] [&lt;-][-&gt;] [Aa][ab][.*][f{}]  X
 *        [ replace .............]          [Replace]  [ Replace All ]
 *        status line (only when there is something to say)
 * </pre>
 *
 * <p>
 * Colours are in {@code themes/search/search_{light,dark}.css}; the bar takes
 * the chrome font from the generated stylesheet like every other panel.
 * </p>
 */
public class Search_dim {

    // ---- placement --------------------------------------------------------

    /** Gap between the bar and the top of the editor content (below the tabs). */
    public static final double MARGIN_TOP = px(4);

    /**
     * Gap between the bar and the right edge of the editor area. Wide enough
     * to leave the editor's vertical scroll bar uncovered.
     */
    public static final double MARGIN_RIGHT = px(22);

    /** Narrowest the editor area may be before the bar shrinks its fields. */
    public static final double MIN_HOST_WIDTH = px(360);

    // ---- the bar ----------------------------------------------------------

    /** Inner padding of the bar, all sides. */
    public static final double PADDING = px(4);

    /** Horizontal gap between items in a row. */
    public static final double H_GAP = px(4);

    /** Vertical gap between the Find row and the Replace row. */
    public static final double V_GAP = px(4);

    /** Corner radius of the bar (also used in the CSS). */
    public static final double RADIUS = px(4);

    // ---- items ------------------------------------------------------------

    /** Height of every field and button. */
    public static final double ROW_HEIGHT = px(26);

    /** Preferred width of the Find and Replace fields. */
    public static final double FIELD_WIDTH = px(230);

    /** Smallest the fields shrink to in a narrow editor. */
    public static final double FIELD_MIN_WIDTH = px(120);

    /** Width of the expand toggle at the far left. */
    public static final double EXPAND_WIDTH = px(20);

    /** Square size of the icon buttons (arrows, toggles, close). */
    public static final double ICON_BUTTON = px(26);

    /** Drawn size of an icon inside its button. */
    public static final double ICON_SIZE = px(16);

    /** Drawn size of the small clear-text x inside the Find field. */
    public static final double CLEAR_ICON_SIZE = px(12);

    /** Space kept free at the right of the Find field for the clear x. */
    public static final double CLEAR_RESERVE = px(20);

    /** Minimum width of the match counter ("12/345 · 7 files"). */
    public static final double COUNTER_MIN_WIDTH = px(58);

    /** Minimum width of the Find and Replace text buttons. */
    public static final double TEXT_BUTTON_MIN_WIDTH = px(64);

    /** Delay between the last keystroke and a live search in an open file, ms. */
    public static final double LIVE_SEARCH_DELAY_MS = 140;

    /**
     * Most matches painted at once in an editor. The counter still counts
     * all of them; only the painting stops, to keep very large files fluid.
     */
    public static final int MAX_PAINTED_HITS = 1000;

    protected Search_dim() {
    }
}
