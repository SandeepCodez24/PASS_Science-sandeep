package ui.design.section_dims;

import javafx.geometry.Insets;

import static ui.design.UIScale.px;
import static ui.design.UIScale.pxi;

/**
 * The title strip along the top edge of a panel: File Explorer, Variable
 * Explorer, Command Window.
 *
 * <p>
 * {@link #HEIGHT} doubles as the collapsed height of a panel, which is why
 * {@link Rail_dim} and {@code CollapsiblePanel} both read it rather than
 * carrying their own copy.
 * </p>
 */
public class TitleBar_dim {

    /** Height of the strip, and the collapsed height of a panel. */
    public static final double HEIGHT = pxi(26);

    /** Gap between the triangle, the title and the options button. */
    public static final double CONTENT_SPACING = px(6);

    /** Strip padding, top edge. */
    public static final double PAD_TOP = px(0);

    /** Strip padding, trailing edge (tight -- the options button sits here). */
    public static final double PAD_RIGHT = px(4);

    /** Strip padding, bottom edge. */
    public static final double PAD_BOTTOM = px(0);

    /** Strip padding, leading edge. */
    public static final double PAD_LEFT = px(8);

    /** Hairline under the strip. Unscaled -- see the package notes. */
    public static final double BOTTOM_BORDER = 1;

    /** Square hit area of the triangle and three-dot buttons. */
    public static final double GLYPH_BUTTON_SIZE = pxi(20);

    /** Padding inside a glyph button, between its edge and the icon. */
    public static final double GLYPH_BUTTON_PADDING = px(1);

    /** Corner rounding of a glyph button's hover highlight. */
    public static final double GLYPH_BUTTON_RADIUS = px(3);

    /** Edge length of the collapse triangle. */
    public static final double CARET_ICON_SIZE = pxi(10);

    /** Edge length of the three-dot options glyph. */
    public static final double DOTS_ICON_SIZE = pxi(14);

    /** Fallback edge length for a title-bar glyph with no size given. */
    public static final double DEFAULT_ICON_SIZE = pxi(12);

    /**
     * @return the strip's padding as an {@link Insets}
     */
    public static Insets padding() {
        return new Insets(PAD_TOP, PAD_RIGHT, PAD_BOTTOM, PAD_LEFT);
    }

    protected TitleBar_dim() {
    }
}
