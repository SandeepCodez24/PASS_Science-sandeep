package ui.design.section_dims;

/**
 * Dimensions of the File Explorer's right-click menus and of the static edge
 * strip on the explorer's left side.
 *
 * <p>
 * Colours are not here: they live in
 * {@code /themes/explorer/explorer_light.css} and {@code explorer_dark.css}.
 * Everything below is a logical-pixel value (JavaFX scales it for 125% /
 * 150% displays).
 * </p>
 */
public final class DirectoryMenu_dim {

    private DirectoryMenu_dim() {
    }

    // ---------------------------------------------------------------------
    // Menu icons
    // ---------------------------------------------------------------------

    /**
     * Drawn size of every menu icon. The 48x48 masters in
     * {@code /icons/Explorer} and {@code /icons/HomeFiles} are decoded at
     * this size times the screen scale, so they land pixel for pixel.
     */
    public static final double MENU_ICON_SIZE = 16;

    /** Gap between a menu icon and its label. */
    public static final double MENU_ICON_GAP = 10;

    // ---------------------------------------------------------------------
    // Edge strip
    // ---------------------------------------------------------------------

    /**
     * Width of the static line on the explorer's left edge. 3 px is about
     * 0.8 mm at 100% scaling and about 1 mm at 125%, which keeps it a line and
     * not a bar.
     */
    public static final double EDGE_STRIP_WIDTH = 3;

    // ---------------------------------------------------------------------
    // Group rows
    // ---------------------------------------------------------------------

    /** Gap between a group title, its count and the rule after it. */
    public static final double GROUP_HEADER_GAP = 6;

    /** Thickness of the rule that runs to the right of a group title. */
    public static final double GROUP_RULE_HEIGHT = 1;

    // ---------------------------------------------------------------------
    // Fallback Properties window (used only when the operating system's own
    // dialog cannot be opened)
    // ---------------------------------------------------------------------

    public static final double PROPERTIES_WIDTH = 380;
    public static final double PROPERTIES_ICON_SIZE = 32;
    public static final double PROPERTIES_LABEL_COLUMN = 110;
    public static final double PROPERTIES_PADDING = 16;
    public static final double PROPERTIES_ROW_GAP = 8;
}
