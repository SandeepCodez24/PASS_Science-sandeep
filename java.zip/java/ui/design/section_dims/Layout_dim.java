package ui.design.section_dims;

import static ui.design.UIScale.px;
import static ui.design.UIScale.pxi;

/**
 * The Settings &gt; Layout feature: the Layout band that replaces the Settings
 * band while it is open, the window arrangements it switches between, and the
 * editor zoom range.
 *
 * <h3>The band</h3>
 *
 * <pre>
 *  | Visuals | Layouts                         | View | Gutter    | Zoom  |  free  |
 *  | Layout  | Def Bot Ed-CLI Dir Ed-Bot-CLI Cu | Full | Num  Fold | R/+/- |        |
 *  |    1    |               6                  |  1   |     2     |  1.5  |  4.5   |
 *  |&lt;------------------------------ 16 units ---------------------------------&gt;|
 * </pre>
 *
 * <p>
 * Same 16-unit grid as Home and Settings, so one unit is the same width on all
 * three. Row height, icon size, divider and inset stay in {@link ToolBand_dim}.
 * The band is a {@code RibbonBand}, so on a narrow window it collapses whole
 * compartments into drop-downs rather than cutting a label.
 * </p>
 *
 * <h3>The arrangements</h3>
 * <p>
 * Every value under "Arrangements" is a divider position: a fraction between 0
 * and 1, not a length, so none of them is scaled (see {@link Split_dim}). The
 * Default arrangement reads its positions from {@link Split_dim} and
 * {@link Window_dim}, exactly as the window did before layouts existed.
 * </p>
 */
public class Layout_dim {

    // =====================================================================
    // BAND UNITS
    // =====================================================================

    /** The band width is divided into this many equal units. */
    public static final double TOTAL_UNITS = 16;

    /** Visuals: the Layout button that leads back to the Settings band. */
    public static final double UNITS_RETURN = 1;

    /** Layouts: the six arrangement tiles. */
    public static final double UNITS_LAYOUTS = 6;

    /** View: Full Screen. */
    public static final double UNITS_VIEW = 1;

    /** Gutter: Line Numbers, Line Folders. */
    public static final double UNITS_GUTTER = 2;

    /** Zoom: Reset Zoom / Zoom In / Zoom Out, stacked. */
    public static final double UNITS_ZOOM = 1.5;

    /** Units consumed by the five compartments. Computed, not stated. */
    public static final double USED_UNITS =
            UNITS_RETURN + UNITS_LAYOUTS + UNITS_VIEW + UNITS_GUTTER + UNITS_ZOOM;

    /** Units left free at the trailing edge. */
    public static final double FREE_UNITS = TOTAL_UNITS - USED_UNITS;

    // =====================================================================
    // LAYOUTS GALLERY (the white rounded box around the six tiles)
    // =====================================================================

    /** Outline of the gallery box. A hairline, so not scaled. */
    public static final double GALLERY_BORDER = 1;

    /** Corner rounding of the gallery box. */
    public static final double GALLERY_RADIUS = px(4);

    /** Space between the box outline and the tiles, top and bottom. */
    public static final double GALLERY_PAD_V = px(2);

    /** Space between the box outline and the tiles, left and right. */
    public static final double GALLERY_PAD_H = px(4);

    /** Gap between neighbouring tiles inside the box. */
    public static final double GALLERY_TILE_SPACING = px(2);

    /**
     * Extra width given to every tile beyond its label's measured width. A
     * guard, not a look: the measured width and the width the label needs
     * can differ by a fraction of a pixel, and a label a fraction too narrow
     * is cut to "...". Unscaled.
     */
    public static final double GALLERY_TILE_SLACK = 1;

    /**
     * Height of one tile inside the box. Derived: the box (tiles, padding and
     * outline) is exactly the item row every compartment uses, so the gallery
     * lines up with the buttons in View and Gutter and the caption stays put.
     */
    public static final double GALLERY_TILE_HEIGHT =
            ToolBand_dim.ITEM_HEIGHT - 2 * (GALLERY_PAD_V + GALLERY_BORDER);

    // =====================================================================
    // ZOOM COMPARTMENT (three small rows, MATLAB style)
    // =====================================================================

    /** Gap between the three zoom rows. */
    public static final double ZOOM_ROW_SPACING = px(1);

    /**
     * Height of one zoom row. Derived: the three rows and their two gaps fill
     * exactly the item row every other compartment uses.
     */
    public static final double ZOOM_ROW_HEIGHT =
            Math.floor((ToolBand_dim.ITEM_HEIGHT - 2 * ZOOM_ROW_SPACING) / 3);

    /**
     * Magnifier icon in a zoom row. Raised from 16: the row is about 23 px
     * tall, so 20 leaves a pixel above and below.
     */
    public static final double ZOOM_ICON_SIZE = pxi(20);

    /** Gap between that icon and its label. */
    public static final double ZOOM_GRAPHIC_GAP = px(6);

    /** Padding inside a zoom row, leading and trailing. */
    public static final double ZOOM_ROW_PAD_H = px(6);

    /** Padding inside a zoom row, top and bottom. */
    public static final double ZOOM_ROW_PAD_V = px(0);

    // =====================================================================
    // EDITOR ZOOM (ratios, not lengths -- not scaled)
    // =====================================================================

    /** Zoom level at Reset Zoom and at first launch. */
    public static final double ZOOM_DEFAULT = 1.0;

    /** Smallest zoom level: 10%. Zoom Out is disabled once it is reached. */
    public static final double ZOOM_MIN = 0.10;

    /** Largest zoom level: 500%. Zoom In is disabled once it is reached. */
    public static final double ZOOM_MAX = 5.00;

    /**
     * One Zoom In click (and one Ctrl+wheel notch up, one Ctrl + =): 15
     * percentage points, so 100% -&gt; 115% -&gt; 130%. Zoom magnifies the
     * whole editor from its top-left corner.
     */
    public static final double ZOOM_IN_STEP = 0.15;

    /**
     * One Zoom Out click (and one Ctrl+wheel notch down, one Ctrl + -): 10
     * percentage points, so 100% -&gt; 90% -&gt; 80%.
     */
    public static final double ZOOM_OUT_STEP = 0.10;

    // =====================================================================
    // PANEL WIDTHS
    // =====================================================================

    /**
     * Preferred width of the Variable Explorer panel. Was a literal 380 in
     * {@code VariableExplorerBuilder}.
     */
    public static final double VARIABLE_PANEL_PREF_WIDTH = px(380);

    /**
     * Width below which the Variable Explorer refuses to shrink. Was a literal
     * 320 in {@code VariableExplorerBuilder}.
     */
    public static final double VARIABLE_PANEL_MIN_WIDTH = px(320);

    /**
     * Width below which the Code Bot refuses to shrink when it is docked as a
     * column of its own (Bot Centered, Editor-Bot-CLI, beside the CLI). Inside
     * the File Explorer it follows the explorer's own minimum instead.
     */
    public static final double BOT_COLUMN_MIN_WIDTH = px(220);

    // =====================================================================
    // ARRANGEMENTS (divider positions -- not scaled)
    // =====================================================================

    // ---- Bot Centered ----------------------------------------------------

    /**
     * Bot Centered: share of the width taken by the left column (Editor over
     * Variable Explorer). The Code Bot takes the rest, at full height.
     */
    public static final double BOT_CENTERED_WORK_SHARE = 0.70;

    /** Bot Centered: Editor over Variable Explorer, 50 / 50. */
    public static final double BOT_CENTERED_EDITOR_OVER_VARIABLES = 0.50;

    // ---- Editor-CLI ------------------------------------------------------

    /** Editor-CLI: Editor over Command Window, 50 / 50. */
    public static final double EDITOR_CLI_EDITOR_OVER_CONSOLE = 0.50;

    /** Editor-CLI with the bot open: Command Window beside Code Bot, 50 / 50. */
    public static final double EDITOR_CLI_CONSOLE_BESIDE_BOT = 0.50;

    // ---- Directory Centered ---------------------------------------------

    /** Directory Centered: File Explorer's share of the width. */
    public static final double DIRECTORY_SHARE = Split_dim.MAIN_LEFT;

    /** Directory Centered with the bot open: tree over Code Bot, 50 / 50. */
    public static final double DIRECTORY_TREE_OVER_BOT = 0.50;

    // ---- Editor-Bot-CLI ---------------------------------------------------

    /** Editor-Bot-CLI: first divider, three equal columns. */
    public static final double THREE_COLUMN_FIRST = 1.0 / 3.0;

    /** Editor-Bot-CLI: second divider, three equal columns. */
    public static final double THREE_COLUMN_SECOND = 2.0 / 3.0;

    /** Editor-Bot-CLI with the bot closed: Editor beside CLI, 50 / 50. */
    public static final double TWO_COLUMN_SPLIT = 0.50;

    protected Layout_dim() {
    }
}
