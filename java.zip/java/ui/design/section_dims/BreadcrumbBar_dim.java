package ui.design.section_dims;

import ui.design.Typography;

import static ui.design.UIScale.px;
import static ui.design.UIScale.pxi;

/**
 * The Breadcrumb Bar: the path box that fills the quick-access row to the right
 * of the navigation buttons, the text field it turns into when edited, the
 * drop-down menus it opens, the tool-band collapse toggle at its end, and the
 * "no such path" dialog.
 *
 * <pre>
 *  ( |[folder]|v|  |D:|&gt;|  |My Research Works|&gt;|  |MARL|&gt;|   ...click to edit... ) | [^]
 * </pre>
 *
 * <h3>Split pairs</h3>
 * <p>
 * Every folder name and the chevron after it form one pair. On hover the pair
 * shows three vertical lines -- its left edge, a divider, its right edge --
 * inside one outline, and only the half under the pointer fills. The This PC
 * control at the head of the path is built the same way, with the folder glyph
 * in place of a name.
 * </p>
 *
 * <p>
 * The row height belongs to {@link NavigationBar_dim}. The box here is sized
 * with the same {@link NavigationBar_dim#KEEP_RATIO}, so the two halves of the
 * row shrink together.
 * </p>
 */
public class BreadcrumbBar_dim {

    // =====================================================================
    // Path box
    // =====================================================================

    /** Height of the path box as designed (was 28 before the row shrank). Never less. */
    public static final double BASE_BOX_HEIGHT = pxi(28 * NavigationBar_dim.KEEP_RATIO);

    /**
     * Height of the path box in force: {@link #BASE_BOX_HEIGHT}, or what one
     * line of the path text needs inside the box's padding, its outline and a
     * pair's outline, if that is more. Recomputed with everything derived
     * from it by {@link #recomputeTextHeights()}.
     */
    public static double BOX_HEIGHT;

    /** Path box padding, top and bottom. */
    public static final double BOX_PAD_V = px(1);

    /** Path box padding, leading and trailing. */
    public static final double BOX_PAD_H = px(6);

    /** Corner rounding of the path box. */
    public static final double BOX_RADIUS = px(0);

    /** Outline of the path box. Hairline, unscaled. */
    public static final double BOX_BORDER = 1;

    /** Gap between the This PC control and the crumbs. */
    public static final double BOX_SPACING = px(6);

    /**
     * Height left inside the box once its padding and outline are taken off.
     * The split pairs and the path editor both fill exactly this.
     */
    public static double CONTENT_HEIGHT;

    /**
     * Preferred width of the path box before it grows.
     *
     * <p>
     * Deliberately small. The box grows to fill the row through
     * {@code HBox.setHgrow}; if it instead asked for its full content width, a
     * long path would push the row past the window edge and the ToolBar would
     * send it into the overflow popup.
     * </p>
     */
    public static final double BOX_PREF_WIDTH = px(120);

    // =====================================================================
    // Contents
    // =====================================================================

    /** Edge length of the This PC folder glyph. Was 16. */
    public static final double ROOT_ICON_SIZE = pxi(16 * NavigationBar_dim.KEEP_RATIO);

    /** Kept for older call sites; the This PC zones are pinned to {@link #PAIR_ZONE_HEIGHT}. */
    public static final double ROOT_BUTTON_PAD_V = px(1);

    /** Padding either side of the This PC folder glyph. */
    public static final double ROOT_BUTTON_PAD_H = px(3);

    /** Padding either side of the This PC chevron. */
    public static final double ROOTS_ARROW_PAD_H = px(2);

    /** Edge length of the This PC chevron (always pointing down). */
    public static final double ROOTS_ARROW_SIZE = pxi(8);

    /** Gap between two neighbouring split pairs. */
    public static final double SEGMENT_SPACING = px(2);

    /** Kept for older call sites; the name zone is pinned to {@link #PAIR_ZONE_HEIGHT}. */
    public static final double SEGMENT_PAD_V = 0;

    /** Padding either side of a folder name inside its pair. */
    public static final double SEGMENT_PAD_H = px(4);

    /**
     * Corner rounding of the pair outline (the box a folder name shows under
     * the pointer) and of the path editor: none, so they are plain boxes like
     * the path box around them and every menu they open.
     */
    public static final double CONTROL_RADIUS = 0;

    /** Outline of the older hover fills. Hairline, unscaled. */
    public static final double CONTROL_BORDER = 1;

    /** Edge length of a chevron between crumbs. */
    public static final double CHEVRON_SIZE = pxi(9);

    /** Kept for older call sites; the chevron zone is pinned to {@link #PAIR_ZONE_HEIGHT}. */
    public static final double SEPARATOR_PAD_V = px(2);

    /** Padding either side of a chevron inside its pair. */
    public static final double SEPARATOR_PAD_H = px(3);

    // =====================================================================
    // Split pair  |name|>|
    // =====================================================================

    /** Height of a whole pair, outline included. Fills the box. */
    public static double PAIR_HEIGHT;

    /** Outline of a pair: the left and right vertical lines. Hairline, unscaled. */
    public static final double PAIR_BORDER = 1;

    /** The middle vertical line, between the name and the chevron. Hairline, unscaled. */
    public static final double PAIR_DIVIDER = 1;

    /** Height of the name and chevron zones, which sit inside the outline. */
    public static double PAIR_ZONE_HEIGHT;

    /** Corner rounding of a zone's fill, so it follows the outline's curve. */
    public static final double PAIR_ZONE_RADIUS = Math.max(0, CONTROL_RADIUS - PAIR_BORDER);

    // =====================================================================
    // Drop-down menus (chevrons, This PC, right-click)
    // =====================================================================
    // The frame, the entries, the width and the font of these menus are no
    // longer the breadcrumb's: every menu in the application is the one box
    // in Menu_dim (Dim.Menu). Only the icon size is still set here; the four
    // values below are kept only so code not yet moved keeps compiling.

    /** @deprecated menus take their padding from {@link Menu_dim#PAD_V}. */
    @Deprecated
    public static final double MENU_PAD = Directory_dim.MENU_PAD;

    /** @deprecated menus are square: {@link Menu_dim#RADIUS}. */
    @Deprecated
    public static final double MENU_RADIUS = Directory_dim.MENU_RADIUS;

    /** @deprecated see {@link Menu_dim#ITEM_PAD_V}. */
    @Deprecated
    public static final double MENU_ITEM_PAD_V = Directory_dim.MENU_ITEM_PAD_V;

    /** @deprecated see {@link Menu_dim#ITEM_PAD_H}. */
    @Deprecated
    public static final double MENU_ITEM_PAD_H = Directory_dim.MENU_ITEM_PAD_H;

    /** Edge length of the folder / cloud / root icons in the menus. Same as a directory row icon. */
    public static final double MENU_ICON_SIZE = Directory_dim.FILE_ICON_SIZE;

    // =====================================================================
    // Path editor (the text field shown after a click on empty space)
    // =====================================================================

    /** Height of the path text field: whatever the box leaves inside its padding and outline. */
    public static double EDITOR_HEIGHT;

    /** Path text field padding, leading and trailing. */
    public static final double EDITOR_PAD_H = px(4);

    // =====================================================================
    // Run-folder history zone (the triangle at the box's right end)
    // =====================================================================
    // The zone reaches through the box's own padding, so it sits flush
    // against the outline on the top, right and bottom -- as MATLAB's does --
    // and a hairline divider separates it from the path on its left. Square
    // corners: the user asked for a plain box, not a rounded one.

    /** Width of the history zone, divider excluded. */
    public static final double HISTORY_ZONE_WIDTH = pxi(18);

    /** Height of the history zone: the whole box inside its outline. */
    public static double HISTORY_ZONE_HEIGHT;

    /** Edge length of the triangle glyph inside the zone. */
    public static final double HISTORY_ARROW_SIZE = pxi(10);

    /** The vertical line between the path and the zone. Hairline, unscaled. */
    public static final double HISTORY_DIVIDER = 1;

    // =====================================================================
    // Tool-band collapse toggle at the end of the row
    // =====================================================================

    /** Edge length of the collapse glyph. Was 14. */
    public static final double TOGGLE_ICON_SIZE = pxi(12);

    /** Corner rounding of the toggle's hover fill. */
    public static final double TOGGLE_RADIUS = px(3);

    // =====================================================================
    // "There is no such path" dialog
    // =====================================================================

    /** Width of the dialog. */
    public static final double DIALOG_WIDTH = px(430);

    /** Height of the navy title strip. */
    public static final double DIALOG_TITLE_HEIGHT = pxi(30);

    /** Title strip padding, leading and trailing. */
    public static final double DIALOG_TITLE_PAD_H = px(10);

    /** Edge length of the close glyph's hit area in the title strip. */
    public static final double DIALOG_CLOSE_SIZE = pxi(22);

    /** Padding around the message body. */
    public static final double DIALOG_BODY_PAD = px(18);

    /** Gap between the error mark and the message. */
    public static final double DIALOG_BODY_SPACING = px(16);

    /** Edge length of the red error mark. */
    public static final double DIALOG_ICON_SIZE = pxi(36);

    /** Footer padding, top and bottom. */
    public static final double DIALOG_FOOTER_PAD_V = px(8);

    /** Footer padding, leading and trailing. */
    public static final double DIALOG_FOOTER_PAD_H = px(12);

    /** Width of the OK button. */
    public static final double DIALOG_BUTTON_WIDTH = px(84);

    /** Height of the OK button. */
    public static final double DIALOG_BUTTON_HEIGHT = pxi(26);

    /** Corner rounding of the OK button. */
    public static final double DIALOG_BUTTON_RADIUS = px(3);

    /** Outline of the dialog window and its button. Hairline, unscaled. */
    public static final double DIALOG_BORDER = 1;

    // =====================================================================
    // Heights that follow the UI font size
    // =====================================================================

    /** How far one line of path text may overhang a zone, in pixels. */
    private static final double TEXT_OVERHANG = 1;

    static {
        recomputeTextHeights();
    }

    /**
     * Recomputes {@link #BOX_HEIGHT} and the five heights derived from it.
     * Call before {@link NavigationBar_dim#recomputeTextHeights()}, which
     * sizes the row around the box.
     */
    public static void recomputeTextHeights() {
        double text = Math.max(Typography.lineHeight(Typography.Role.BREADCRUMB_PATH),
                Typography.lineHeight(Typography.Role.BREADCRUMB_PATH_EDITOR));
        // A line may overhang its zone by up to TEXT_OVERHANG: the name and
        // chevron labels have a zero minimum height and centre in the zone,
        // and the line box carries a little empty space above the capitals
        // and below the descenders. That keeps the designed box at the
        // default size, where one Segoe UI line is a fraction over the zone.
        double forText = text - TEXT_OVERHANG + (BOX_PAD_V * 2) + (BOX_BORDER * 2) + (PAIR_BORDER * 2);
        BOX_HEIGHT = Math.max(BASE_BOX_HEIGHT, Math.ceil(forText));
        CONTENT_HEIGHT = BOX_HEIGHT - (BOX_PAD_V * 2) - (BOX_BORDER * 2);
        PAIR_HEIGHT = CONTENT_HEIGHT;
        PAIR_ZONE_HEIGHT = PAIR_HEIGHT - (PAIR_BORDER * 2);
        EDITOR_HEIGHT = CONTENT_HEIGHT;
        HISTORY_ZONE_HEIGHT = BOX_HEIGHT - (BOX_BORDER * 2);
    }

    protected BreadcrumbBar_dim() {
    }
}
