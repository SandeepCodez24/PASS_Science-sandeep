package ui.design.section_dims;

import javafx.geometry.Insets;

import static ui.design.UIScale.px;
import static ui.design.UIScale.pxi;

/** The status bar across the bottom of the window. */
public class Footer_dim {

    /** Gap between adjacent footer items. */
    public static final double ITEM_SPACING = px(9);

    /** Footer padding, top and bottom. */
    public static final double PAD_V = px(3.75);

    /** Footer padding, leading and trailing. */
    public static final double PAD_H = px(7.5);

    /** Vertical padding inside the error and warning buttons. */
    public static final double BUTTON_PAD_V = px(3);

    /** Horizontal padding inside the error and warning buttons. */
    public static final double BUTTON_PAD_H = px(6);

    /**
     * The height every indicator in the footer is pinned to.
     *
     * <p>
     * This is the single number that puts the error count, the warning count
     * and the theme toggle on one centre line. Previously the toggle was a
     * 24px circle while the two count buttons were whatever their 8.25px text
     * plus {@link #BUTTON_PAD_V} came to -- roughly 17px. The tallest child of
     * an {@code HBox} sets the row height, so the toggle was deciding it and
     * the two shorter buttons floated above the optical centre. Pin all three
     * to one height and the problem cannot come back.
     * </p>
     *
     * <p>
     * 18 is the design value because it is the natural height of an
     * {@code app-footer-button}: the FOOTER_BUTTON role rounded up, plus
     * {@link #BUTTON_PAD_V} top and bottom. If that role's size or that
     * padding changes, change this with it -- the buttons will otherwise be
     * clipped or padded out.
     * </p>
     */
    public static final double INDICATOR_SIZE = pxi(18);

    /** Corner rounding shared by the count buttons and the theme toggle. */
    public static final double INDICATOR_RADIUS = px(2);

    /** Outline width shared by the count buttons and the theme toggle. */
    public static final double INDICATOR_BORDER = px(1);

    /**
     * Side of the square light/dark theme toggle.
     *
     * <p>
     * Deliberately an alias of {@link #INDICATOR_SIZE} rather than a number of
     * its own: the toggle is square, so its width and height are both the
     * shared indicator height, and there is no way to set one without the
     * other.
     * </p>
     */
    public static final double TOGGLE_SIZE = INDICATOR_SIZE;

    /**
     * Side of the sun/moon glyph inside the toggle, as a real length.
     *
     * <p>
     * This used to be {@code TOGGLE_ICON_SCALE}, a fraction of the icon's
     * native resolution, which meant the rendered glyph depended on how large
     * the PNG happened to be rather than on the box it sits in. A 64px source
     * and a 32px source produced two different toggles. An absolute size ties
     * the glyph to {@link #TOGGLE_SIZE}, so swapping the artwork changes
     * nothing, and leaves roughly 3px of breathing room inside the frame on
     * each side.
     * </p>
     */
    public static final double TOGGLE_GLYPH = pxi(11);

    /**
     * @return the footer's padding as an {@link Insets}
     */
    public static Insets padding() {
        return new Insets(PAD_V, PAD_H, PAD_V, PAD_H);
    }

    protected Footer_dim() {
    }
}
