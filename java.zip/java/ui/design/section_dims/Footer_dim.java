package ui.design.section_dims;

import javafx.geometry.Insets;

import static ui.design.UIScale.px;
import static ui.design.UIScale.pxi;

/** The status bar across the bottom of the window. */
public class Footer_dim {

    /** Gap between adjacent footer items. */
    public static final double ITEM_SPACING = px(9);

    /** Footer padding, top and bottom. */
    public static final double PAD_V = px(3.75);

    /** Footer padding, leading and trailing. */
    public static final double PAD_H = px(7.5);

    /** Vertical padding inside the error and warning buttons. */
    public static final double BUTTON_PAD_V = px(3);

    /** Horizontal padding inside the error and warning buttons. */
    public static final double BUTTON_PAD_H = px(6);

    /** Diameter of the circular light/dark theme toggle. */
    public static final double TOGGLE_SIZE = pxi(24);

    /**
     * Sun/moon glyph size as a fraction of the icon's native resolution.
     *
     * <p>
     * A ratio, not a length, so it is not scaled -- {@link #TOGGLE_SIZE}
     * already carries the scaling.
     * </p>
     */
    public static final double TOGGLE_ICON_SCALE = 0.65;

    /**
     * @return the footer's padding as an {@link Insets}
     */
    public static Insets padding() {
        return new Insets(PAD_V, PAD_H, PAD_V, PAD_H);
    }

    protected Footer_dim() {
    }
}
