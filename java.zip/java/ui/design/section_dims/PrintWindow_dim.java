package ui.design.section_dims;

import static ui.design.UIScale.px;

/**
 * The Print Script window ({@code PrintStudioWindow}): its own title bar and
 * frame.
 *
 * <pre>
 *   +-----------------------------------------------+
 *   | [NC] Print Script                         [X] |  title bar, #264653
 *   |-----------------------------------------------|
 *   | test_02.nc                                    |
 *   | C:\...\test_02.nc                             |
 *   | 22 lines                                      |
 *   |-----------------------------------------------|
 *   | PDF theme (o) Light ( ) Dark                  |
 *   |             [Cancel] [Save as PDF...] [Print...]|
 *   +-----------------------------------------------+
 * </pre>
 *
 * <p>
 * The window draws its own frame rather than taking the operating system's,
 * because the Windows frame can be neither coloured nor squared: Windows 11
 * rounds every decorated window by about 8 px, whatever the application asks.
 * </p>
 */
public class PrintWindow_dim {

    /** Height of the title bar. */
    public static final double TITLE_BAR_HEIGHT = px(32);

    /** Title bar padding, leading edge. */
    public static final double TITLE_BAR_PAD_LEFT = px(10);

    /** Gap between the window icon and the title. */
    public static final double TITLE_BAR_SPACING = px(8);

    /** Edge length of the window icon in the title bar. */
    public static final double TITLE_ICON_SIZE = px(18);

    /** Width of the close button; it fills the bar's height. */
    public static final double CLOSE_BUTTON_WIDTH = px(44);

    /**
     * Corner rounding of the window. Unscaled, and deliberately all but
     * square: 0.1 px reads as a crisp corner at every display scale.
     */
    public static final double CORNER_RADIUS = 0.1;

    /** Outline of the window frame. Hairline, unscaled. */
    public static final double FRAME_BORDER = 1;

    /**
     * Transparent margin around the frame that holds the drop shadow. The
     * window is this much larger than what is drawn on every side.
     */
    public static final double SHADOW_MARGIN = px(10);

    /** Blur radius of the drop shadow. */
    public static final double SHADOW_RADIUS = px(12);

    /** Padding of the window's body, below the title bar. */
    public static final double BODY_PADDING = px(16);

    /** Width of the window's body. */
    public static final double BODY_WIDTH = px(420);

    protected PrintWindow_dim() {
    }
}
