package ui.design.section_dims;

/**
 * The Signals band's compartment shares.
 *
 * <pre>
 *  | Sensors | Series | Domain | Actuators | Env |    free    |
 *  |   3.5   |    2   |    1   |    3.5    |  1  |      3     |
 *  |&lt;--------------------- 14 units ---------------------&gt;|
 * </pre>
 *
 * <p>
 * Separate from {@link HomeBand_dim} because the two bands divide their width
 * differently -- Home into 16 units, Signals into 14. Everything they share
 * (row height, icon size, the divider, the horizontal inset) is in
 * {@link ToolBand_dim}.
 * </p>
 *
 * <p>
 * Five dividers are drawn, one after each compartment including Environment, so
 * the free space is fenced off rather than bleeding into the Set button.
 * </p>
 */
public class SignalBand_dim {

    /** The band width is divided into this many equal units. */
    public static final double TOTAL_UNITS = 14;

    /** Sensors: Feed Artificial, the compare control, Feed Real. */
    public static final double UNITS_SENSORS = 3.5;

    /** Series: Fit, Process, Extract. */
    public static final double UNITS_SERIES = 2;

    /** Domain: Transform. */
    public static final double UNITS_DOMAIN = 1;

    /** Actuators: Deliver Artificial, the compare control, Deliver Real. */
    public static final double UNITS_ACTUATORS = 3.5;

    /** Environment: Set. */
    public static final double UNITS_ENVIRONMENT = 1;

    /** Units consumed by the five compartments. Computed, not stated. */
    public static final double USED_UNITS =
            UNITS_SENSORS + UNITS_SERIES + UNITS_DOMAIN
                    + UNITS_ACTUATORS + UNITS_ENVIRONMENT;

    /** Units left free at the trailing edge. */
    public static final double FREE_UNITS = TOTAL_UNITS - USED_UNITS;

    /** Dividers drawn: one after each of the five compartments. */
    public static final int SEPARATOR_COUNT = 5;

    protected SignalBand_dim() {
    }
}
