package ui.design;

import java.util.Locale;

/**
 * The single multiplier applied to every dimension in {@link Dim} and every
 * font size in {@link Typography}.
 *
 * <h3>Why this exists</h3>
 * <p>
 * Every number in the design layer is written at a scale factor of 1.0, which
 * is the geometry the UI was originally drawn at. Changing {@link #factor()}
 * once resizes the entire application coherently -- useful for a high-DPI
 * machine, for an accessibility setting, or simply for trying a denser layout
 * without touching a hundred literals.
 * </p>
 *
 * <h3>The freeze rule -- read this before calling setFactor</h3>
 * <p>
 * {@link Dim} and {@link Typography} resolve their constants once, when their
 * class is first loaded. Changing the factor after that point would leave the
 * UI half-scaled, which is far worse than not scaling at all. So the first read
 * of {@link #factor()} <b>freezes</b> this class, and any later
 * {@link #setFactor(double)} throws immediately instead of failing quietly at
 * runtime.
 * </p>
 * <p>
 * Practical consequence: if you ever set the factor from code, do it in
 * {@code application.Launcher} or at the very top of {@code application.Main},
 * <em>before</em> the first JavaFX node is constructed.
 * </p>
 *
 * <h3>Overriding without a rebuild</h3>
 * <p>
 * The factor can also be supplied as a JVM system property, which survives into
 * the packaged executable:
 * </p>
 *
 * <pre>
 *   Astra.exe -J-Dastra.ui.scale=1.25
 * </pre>
 *
 * <p>
 * That is deliberately the only runtime override. Individual dimensions stay
 * compile-time constants so that a typo fails the build rather than shipping.
 * </p>
 */
public final class UIScale {

    /** JVM system property that overrides the built-in factor. */
    public static final String SCALE_PROPERTY = "astra.ui.scale";

    /** Factor used when nothing overrides it. */
    public static final double DEFAULT_FACTOR = 1.0;

    /** Smallest accepted factor; below this the UI stops being usable. */
    public static final double MIN_FACTOR = 0.50;

    /** Largest accepted factor. */
    public static final double MAX_FACTOR = 3.00;

    private static double factor = readSystemProperty();
    private static boolean frozen = false;

    private UIScale() {
    }

    /**
     * Sets the global scale factor. Must be called before any UI class loads.
     *
     * @param value the new factor, clamped to [{@value #MIN_FACTOR},
     *              {@value #MAX_FACTOR}]
     * @throws IllegalStateException if the scale has already been read, which
     *                               means part of the UI is already sized
     */
    public static void setFactor(double value) {
        if (frozen) {
            throw new IllegalStateException(
                    "UIScale.setFactor called after the scale was already applied. "
                            + "Move this call into Launcher/Main, before the first UI class is loaded.");
        }
        factor = clamp(value);
    }

    /**
     * Returns the global scale factor and freezes it against further changes.
     *
     * @return the factor in use
     */
    public static double factor() {
        frozen = true;
        return factor;
    }

    /**
     * @return true once the factor has been read and can no longer be changed
     */
    public static boolean isFrozen() {
        return frozen;
    }

    /**
     * Scales a design-time value.
     *
     * @param designValue the value as written at scale 1.0
     * @return the scaled value, rounded to two decimals so generated CSS stays
     *         readable
     */
    public static double px(double designValue) {
        return Math.round(designValue * factor() * 100.0) / 100.0;
    }

    /**
     * Scales a design-time value and rounds it to a whole pixel. Use this for
     * anything that must land on a pixel boundary -- icon edge lengths, hairline
     * borders, control heights -- because a fractional size there shows up as a
     * blurry edge.
     *
     * @param designValue the value as written at scale 1.0
     * @return the scaled value, rounded to the nearest integer
     */
    public static double pxi(double designValue) {
        return Math.round(designValue * factor());
    }

    /**
     * Formats a number for embedding in generated CSS: no trailing {@code .0},
     * no locale-dependent decimal comma.
     *
     * @param value the number
     * @return its shortest faithful text form
     */
    public static String fmt(double value) {
        if (value == Math.rint(value) && !Double.isInfinite(value)) {
            return Long.toString((long) value);
        }
        return String.format(Locale.ROOT, "%.2f", value);
    }

    private static double readSystemProperty() {
        String raw = System.getProperty(SCALE_PROPERTY);
        if (raw == null || raw.isBlank()) {
            return DEFAULT_FACTOR;
        }
        try {
            return clamp(Double.parseDouble(raw.trim()));
        } catch (NumberFormatException ex) {
            System.err.println("Ignoring bad " + SCALE_PROPERTY + " value: " + raw);
            return DEFAULT_FACTOR;
        }
    }

    private static double clamp(double value) {
        if (Double.isNaN(value)) {
            return DEFAULT_FACTOR;
        }
        return Math.max(MIN_FACTOR, Math.min(MAX_FACTOR, value));
    }
}
