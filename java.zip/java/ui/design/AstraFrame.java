package ui.design;

import java.util.List;

import javafx.beans.value.ChangeListener;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.SVGPath;
import javafx.stage.Modality;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.Window;
import javafx.stage.WindowEvent;
import ui.layout.custom.CustomLayoutConfig;
import ui.layout.custom.CustomLayoutTheme;
import ui.managers.ThemeManager;

/**
 * The IDE's own window frame: a frameless, square window with a title strip
 * in the panels' active title colour, a hairline outline, and a body. Every
 * window or dialog the IDE opens should be built on it, the way every menu is
 * built through {@link MenuStyle}.
 *
 * <pre>
 *   +------------------------------------------------------+
 *   | NC  CLI History                          [ ]   [x]  |   title strip
 *   +------------------------------------------------------+
 *   |                                                      |
 *   |   body: whatever the window shows                    |
 *   |                                                      |
 *   +------------------------------------------------------+
 * </pre>
 *
 * <h3>Why not the operating system's frame</h3>
 * <p>
 * Windows 11 rounds the corners of every window it frames, and draws its
 * title bar in its own colours; neither can be changed from CSS. This frame
 * is drawn by the IDE, so its corners are square and its strip matches the
 * panels.
 * </p>
 *
 * <h3>Two kinds</h3>
 * <ul>
 * <li>{@link Kind#WINDOW} -- a tool window (CLI History): not modal,
 * resizable from every edge and corner, maximize button and double-click on
 * the strip, a white "document" body (the editor's background).</li>
 * <li>{@link Kind#DIALOG} -- a question (Reset CLI History): modal, fixed
 * size, the menus' body colour. {@link #confirm} and {@link #choose} build one
 * in a line.</li>
 * </ul>
 * Both drag by the title strip, close with Esc, and centre over their owner.
 *
 * <h3>Colours, soft-coded</h3>
 * <p>
 * No colour is written here. The frame's parts carry style classes coloured
 * from palette tokens ({@code surfaces.css}, section 8): the strip is
 * {@code -astra-title-active}, the outline {@code -astra-menu-border}, the
 * buttons {@code -astra-button-*}. When the Custom layout puts its own base
 * colour in force ({@link CustomLayoutTheme#baseProperty()}), the frame
 * redefines the four {@code -astra-title-active*} tokens on its own root --
 * the strip, its text ink and its hover all follow, live, while the window is
 * open. A theme switch re-copies the owner's sheets, so an open window
 * changes theme with the IDE.
 * </p>
 *
 * <h3>Geometry</h3>
 * <p>
 * From {@link Dim.Frame}, emitted by {@link DesignStylesheet}.
 * </p>
 *
 * <h3>Options (Standalone CLI)</h3>
 * <p>
 * {@link Options} lets a window differ from the defaults without a second
 * frame class: an <b>independent</b> window (not owned by the IDE, so it has
 * its own task-bar entry and can sit behind the IDE or on another monitor --
 * the owner is still the source of its sheets and icon), Esc that does
 * <b>not</b> close it (the Command Window needs Esc), no centring when shown,
 * and a <b>minimise</b> button. {@link #addTitleButton} puts an extra button
 * (the Command Window's three-dot menu) on the strip, {@link #setBodyFlush}
 * lets the content reach the frame's edges, and {@link #setOnCloseRequest}
 * replaces closing with an action of the caller's (the Command Window docks
 * back instead of closing) -- for the close mark, Esc and Alt+F4 alike.
 * </p>
 */
public final class AstraFrame {

    /** What kind of window this is. */
    public enum Kind {
        /** Resizable, maximizable tool window with a document (white) body. */
        WINDOW,
        /** Modal, fixed-size question with the menus' body colour. */
        DIALOG
    }

    /**
     * How a frame differs from the defaults. Every default is the behaviour
     * the frame always had, so {@code new Options()} changes nothing.
     */
    public static final class Options {
        private boolean owned = true;
        private boolean closeOnEscape = true;
        private boolean centreOnShow = true;
        private boolean minimizeButton;

        /**
         * @param value false for an independent window: own task-bar entry,
         *              not kept above the IDE. The owner passed to the frame
         *              still gives it its sheets and icon. WINDOW kind only.
         * @return these options
         */
        public Options owned(boolean value) {
            owned = value;
            return this;
        }

        /** @param value false to leave Esc to the content; @return these options */
        public Options closeOnEscape(boolean value) {
            closeOnEscape = value;
            return this;
        }

        /** @param value false when the caller places the window; @return these options */
        public Options centreOnShow(boolean value) {
            centreOnShow = value;
            return this;
        }

        /** @param value true for a minimise button on the strip; @return these options */
        public Options minimizeButton(boolean value) {
            minimizeButton = value;
            return this;
        }
    }

    // ---- style classes (colours in surfaces.css section 8, geometry generated) --
    public static final String FRAME_CLASS = "astra-frame";
    public static final String WINDOW_CLASS = "astra-frame-window";
    public static final String DIALOG_CLASS = "astra-frame-dialog";
    public static final String TITLE_BAR_CLASS = "astra-frame-title-bar";
    public static final String TITLE_CLASS = "astra-frame-title";
    public static final String TITLE_BUTTON_CLASS = "astra-frame-title-button";
    public static final String CLOSE_CLASS = "astra-frame-close";
    public static final String GLYPH_CLASS = "astra-frame-glyph";
    public static final String BODY_CLASS = "astra-frame-body";
    public static final String HEADING_CLASS = "astra-frame-heading";
    public static final String MESSAGE_CLASS = "astra-frame-message";
    public static final String BUTTONS_CLASS = "astra-frame-buttons";
    public static final String BUTTON_CLASS = "astra-button";

    // ---- resize zones -------------------------------------------------------
    private static final int NORTH = 1;
    private static final int SOUTH = 2;
    private static final int WEST = 4;
    private static final int EAST = 8;

    private final Window owner;
    private final Kind kind;
    private final Options options;
    private final Stage stage;
    private final BorderPane root = new BorderPane();
    private final StackPane body = new StackPane();
    private final HBox titleBar = new HBox();
    private final Region titleGrow = new Region();
    private final SVGPath maximizeGlyph = new SVGPath();
    private final Scene scene;

    /** Run instead of closing, when set ({@link #setOnCloseRequest}). */
    private Runnable closeAction;

    private boolean maximized;
    private Rectangle2D restoreBounds;

    // drag and resize state
    private final double[] grab = new double[2];
    private int resizeZone;
    private double startX;
    private double startY;
    private Rectangle2D startBounds;

    private final ChangeListener<String> onTheme;
    private final ChangeListener<Color> onBase;
    private final Runnable onFontSize;

    /**
     * Builds the frame. Put the content in with {@link #setContent}, then call
     * {@link #show} or {@link #showAndWait}.
     *
     * @param owner the IDE window it belongs to (centred over it, theme taken
     *              from it); may be null
     * @param title the title-strip text, also the taskbar text
     * @param kind  window or dialog
     */
    public AstraFrame(Window owner, String title, Kind kind) {
        this(owner, title, kind, new Options());
    }

    /**
     * Builds the frame with options. See {@link Options}.
     *
     * @param owner   the IDE window (sheets, icon, centring); may be null
     * @param title   the title-strip text, also the taskbar text
     * @param kind    window or dialog
     * @param options how this frame differs from the defaults; may be null
     */
    public AstraFrame(Window owner, String title, Kind kind, Options options) {
        this.owner = owner;
        this.kind = kind;
        this.options = options == null ? new Options() : options;

        stage = new Stage(StageStyle.UNDECORATED);
        stage.setTitle(title);
        // A dialog is always owned: it is modal to the IDE.
        if (owner != null && (this.options.owned || kind == Kind.DIALOG)) {
            stage.initOwner(owner);
        }
        Image icon = ownerIcon(owner);
        if (icon != null) {
            stage.getIcons().add(icon);
        }
        if (kind == Kind.DIALOG) {
            stage.initModality(Modality.WINDOW_MODAL);
            stage.setResizable(false);
        } else {
            stage.setMinWidth(Dim.Frame.MIN_WIDTH);
            stage.setMinHeight(Dim.Frame.MIN_HEIGHT);
        }

        buildTitleBar(title, icon);

        body.getStyleClass().add(BODY_CLASS);
        root.setTop(titleBar);
        root.setCenter(body);
        root.getStyleClass().addAll(FRAME_CLASS, kind == Kind.WINDOW ? WINDOW_CLASS : DIALOG_CLASS);

        scene = new Scene(root);
        copyOwnerSheets();
        // Palette, shared surfaces and generated geometry on the root itself:
        // node sheets outrank the scene's, so nothing in light.css / dark.css
        // (".button", ".text-field") can repaint the frame.
        SurfaceSheets.attach(root);
        stage.setScene(scene);

        if (this.options.closeOnEscape) {
            scene.addEventFilter(KeyEvent.KEY_PRESSED, e -> {
                if (e.getCode() == KeyCode.ESCAPE) {
                    requestClose();
                    e.consume();
                }
            });
        }
        // Alt+F4 and the task bar's Close: the caller's action, when set.
        stage.setOnCloseRequest(e -> {
            if (closeAction != null) {
                e.consume();
                closeAction.run();
            }
        });
        if (kind == Kind.WINDOW) {
            installResize();
        }

        // Follow the theme and the Custom layout's base colour while open.
        onTheme = (obs, was, now) -> {
            copyOwnerSheets();
            SurfaceSheets.attach(root);
        };
        onBase = (obs, was, now) -> applyBase(now);
        // Follow the UI font size too (Custom Layout window, live): fresh
        // sheets, and a dialog re-fits its content.
        onFontSize = () -> {
            refreshSheets();
            if (this.kind == Kind.DIALOG && stage.isShowing()) {
                stage.sizeToScene();
            }
        };
        ThemeManager.themeProperty().addListener(onTheme);
        CustomLayoutTheme.baseProperty().addListener(onBase);
        Typography.addFontSizeListener(onFontSize);
        applyBase(CustomLayoutTheme.activeBase());
        stage.addEventHandler(WindowEvent.WINDOW_HIDDEN, e -> {
            ThemeManager.themeProperty().removeListener(onTheme);
            CustomLayoutTheme.baseProperty().removeListener(onBase);
            Typography.removeFontSizeListener(onFontSize);
        });

        // Centre over the owner once the size is known. Added, not set, so
        // the caller keeps setOnShown for itself.
        if (this.options.centreOnShow) {
            stage.addEventHandler(WindowEvent.WINDOW_SHOWN, e -> centreOverOwner());
        }
    }

    // =====================================================================
    // Public API
    // =====================================================================

    /** @return the window, for listeners and focus */
    public Stage stage() {
        return stage;
    }

    /** @return the window's scene */
    public Scene scene() {
        return scene;
    }

    /**
     * Puts the window's content in the body.
     *
     * @param content the content
     * @return this frame, for chaining
     */
    public AstraFrame setContent(Node content) {
        body.getChildren().setAll(content);
        return this;
    }

    /**
     * Sets the first size of a {@link Kind#WINDOW}; a dialog sizes itself to
     * its content.
     *
     * @param width  outer width
     * @param height outer height
     * @return this frame, for chaining
     */
    public AstraFrame setSize(double width, double height) {
        stage.setWidth(width);
        stage.setHeight(height);
        return this;
    }

    /**
     * Lets the content reach the frame's edges: no body padding. For content
     * that is itself a panel (the standalone Command Window).
     *
     * @return this frame, for chaining
     */
    public AstraFrame setBodyFlush() {
        body.setStyle("-fx-padding: 0;");
        return this;
    }

    /**
     * Replaces closing with an action: the close mark, Esc (when it closes)
     * and Alt+F4 run it, and the window stays open unless the action hides
     * it.
     *
     * @param action the action, or null to close normally again
     * @return this frame, for chaining
     */
    public AstraFrame setOnCloseRequest(Runnable action) {
        closeAction = action;
        return this;
    }

    /**
     * Adds a button to the title strip, just before the minimise / maximise /
     * close buttons, in the same style as they are.
     *
     * @param glyph   what the button shows
     * @param tooltip its tooltip; may be null
     * @return the button, for its action
     */
    public Button addTitleButton(Node glyph, String tooltip) {
        Button button = titleButton(glyph);
        if (tooltip != null && !tooltip.isBlank()) {
            button.setTooltip(new Tooltip(tooltip));
        }
        int at = titleBar.getChildren().indexOf(titleGrow) + 1;
        titleBar.getChildren().add(at, button);
        return button;
    }

    /** @return true while a WINDOW is maximised by its strip button */
    public boolean isMaximized() {
        return maximized;
    }

    /**
     * @return the window's bounds when not maximised: the bounds it will
     *         return to if it is maximised now
     */
    public Rectangle2D normalBounds() {
        if (maximized && restoreBounds != null) {
            return restoreBounds;
        }
        return new Rectangle2D(stage.getX(), stage.getY(), stage.getWidth(), stage.getHeight());
    }

    /**
     * Copies the owner's sheets again and re-attaches the palette, surfaces
     * and generated sheets. For a window whose owner's sheets changed without
     * a theme switch (font size, editor ink).
     */
    public void refreshSheets() {
        copyOwnerSheets();
        SurfaceSheets.attach(root);
    }

    /** Shows the window and returns at once. */
    public void show() {
        stage.show();
    }

    /** Shows the window and waits until it is closed. */
    public void showAndWait() {
        stage.showAndWait();
    }

    /**
     * A button in the frame's style: square, a thin outline that shows in
     * both themes, the dialog font.
     *
     * @param text the button text
     * @return the button
     */
    public static Button button(String text) {
        Button button = new Button(text);
        button.setMnemonicParsing(false);
        button.getStyleClass().add(BUTTON_CLASS);
        return button;
    }

    /**
     * Asks a yes / no question in an Astra dialog and waits for the answer.
     *
     * <pre>
     *   | NC  title                                   [x] |
     *   | heading (bold)                                  |
     *   | message                                         |
     *   |                          [ confirm ]  [ cancel ]|
     * </pre>
     *
     * @param owner       the IDE window; may be null
     * @param title       title-strip text
     * @param heading     the question, in bold; may be null
     * @param message     what will happen; may be null
     * @param confirmText the confirming button (Enter)
     * @param cancelText  the cancelling button (Esc)
     * @return true when the user confirmed
     */
    public static boolean confirm(Window owner, String title, String heading, String message,
            String confirmText, String cancelText) {
        return choose(owner, title, heading, message, 0, confirmText, cancelText) == 0;
    }

    /**
     * Asks a question with any number of answers in an Astra dialog and waits
     * for the answer. {@link #confirm} is this with two buttons.
     *
     * <pre>
     *   | NC  title                                   [x] |
     *   | heading (bold)                                  |
     *   | message                                         |
     *   |              [ first ]  [ second ]  [ cancel ]  |
     * </pre>
     *
     * @param owner         the IDE window; may be null
     * @param title         title-strip text
     * @param heading       the question, in bold; may be null
     * @param message       what each answer does; may be null
     * @param defaultChoice index of the button Enter presses, focused on opening
     * @param choices       the buttons, left to right; the last one cancels (Esc)
     * @return the index of the button pressed; the last one when the dialog was
     *         closed any other way
     */
    public static int choose(Window owner, String title, String heading, String message,
            int defaultChoice, String... choices) {
        int cancel = choices.length - 1;
        int[] answer = { cancel };
        AstraFrame frame = new AstraFrame(owner, title, Kind.DIALOG);

        VBox text = new VBox();
        text.setSpacing(Dim.Frame.BODY_SPACING);
        if (heading != null && !heading.isBlank()) {
            text.getChildren().add(wrapped(heading, HEADING_CLASS));
        }
        if (message != null && !message.isBlank()) {
            text.getChildren().add(wrapped(message, MESSAGE_CLASS));
        }

        HBox buttons = new HBox();
        Button[] pressed = new Button[choices.length];
        for (int i = 0; i < choices.length; i++) {
            int index = i;
            pressed[i] = button(choices[i]);
            pressed[i].setDefaultButton(i == defaultChoice);
            pressed[i].setCancelButton(i == cancel);
            pressed[i].setOnAction(e -> {
                answer[0] = index;
                frame.stage.close();
            });
            buttons.getChildren().add(pressed[i]);
        }
        buttons.getStyleClass().add(BUTTONS_CLASS);
        buttons.setAlignment(Pos.CENTER_RIGHT);

        VBox content = new VBox(text, buttons);
        content.setPrefWidth(Dim.Frame.DIALOG_WIDTH - 2 * Dim.Frame.BODY_PAD - 2 * Dim.Frame.BORDER);
        frame.setContent(content);

        frame.stage.addEventHandler(WindowEvent.WINDOW_SHOWN, e -> pressed[defaultChoice].requestFocus());
        frame.stage.sizeToScene();
        frame.showAndWait();
        return answer[0];
    }

    // =====================================================================
    // Title strip
    // =====================================================================

    private void buildTitleBar(String title, Image icon) {
        titleBar.getStyleClass().add(TITLE_BAR_CLASS);
        titleBar.setAlignment(Pos.CENTER_LEFT);

        if (icon != null) {
            ImageView view = new ImageView(icon);
            view.setFitWidth(Dim.Frame.TITLE_ICON_SIZE);
            view.setFitHeight(Dim.Frame.TITLE_ICON_SIZE);
            view.setPreserveRatio(true);
            view.setSmooth(true);
            titleBar.getChildren().add(view);
        }

        Label label = new Label(title);
        label.getStyleClass().add(TITLE_CLASS);
        label.setMnemonicParsing(false);
        HBox.setHgrow(titleGrow, Priority.ALWAYS);
        titleBar.getChildren().addAll(label, titleGrow);

        double g = Dim.Frame.TITLE_GLYPH_SIZE;
        if (options.minimizeButton) {
            SVGPath dash = new SVGPath();
            dash.setContent("M0," + g + " H" + g);
            dash.getStyleClass().add(GLYPH_CLASS);
            Button min = titleButton(dash);
            min.setOnAction(e -> stage.setIconified(true));
            titleBar.getChildren().add(min);
        }
        if (kind == Kind.WINDOW) {
            maximizeGlyph.getStyleClass().add(GLYPH_CLASS);
            setMaximizeGlyph();
            Button max = titleButton(maximizeGlyph);
            max.setOnAction(e -> toggleMaximized());
            titleBar.getChildren().add(max);
        }

        SVGPath cross = new SVGPath();
        cross.setContent("M0,0 L" + g + "," + g + " M" + g + ",0 L0," + g);
        cross.getStyleClass().add(GLYPH_CLASS);
        Button close = titleButton(cross);
        close.getStyleClass().add(CLOSE_CLASS);
        close.setOnAction(e -> requestClose());
        titleBar.getChildren().add(close);

        titleBar.setOnMousePressed(e -> {
            grab[0] = stage.getX() - e.getScreenX();
            grab[1] = stage.getY() - e.getScreenY();
        });
        titleBar.setOnMouseDragged(e -> {
            if (!maximized && resizeZone == 0) {
                stage.setX(e.getScreenX() + grab[0]);
                stage.setY(e.getScreenY() + grab[1]);
            }
        });
        titleBar.setOnMouseClicked(e -> {
            if (kind == Kind.WINDOW && e.getButton() == MouseButton.PRIMARY && e.getClickCount() == 2) {
                toggleMaximized();
            }
        });
    }

    /** The close mark and Esc: the caller's action if set, else close. */
    private void requestClose() {
        if (closeAction != null) {
            closeAction.run();
        } else {
            stage.close();
        }
    }

    private static Button titleButton(Node glyph) {
        Button button = new Button();
        button.setGraphic(glyph);
        button.getStyleClass().add(TITLE_BUTTON_CLASS);
        button.setFocusTraversable(false);
        return button;
    }

    private void setMaximizeGlyph() {
        double g = Dim.Frame.TITLE_GLYPH_SIZE;
        if (maximized) {
            // Two overlapping boxes: "restore".
            double s = g * 0.8;
            double o = g - s;
            maximizeGlyph.setContent("M0," + o + " h" + s + " v" + s + " h-" + s + " Z"
                    + " M" + o + "," + o + " V0 H" + g + " V" + s + " H" + s);
        } else {
            maximizeGlyph.setContent("M0,0 H" + g + " V" + g + " H0 Z");
        }
    }

    // =====================================================================
    // Maximize
    // =====================================================================

    private void toggleMaximized() {
        if (maximized) {
            if (restoreBounds != null) {
                stage.setX(restoreBounds.getMinX());
                stage.setY(restoreBounds.getMinY());
                stage.setWidth(restoreBounds.getWidth());
                stage.setHeight(restoreBounds.getHeight());
            }
            maximized = false;
        } else {
            restoreBounds = new Rectangle2D(stage.getX(), stage.getY(), stage.getWidth(), stage.getHeight());
            // The screen's working area, so the taskbar stays visible (an
            // undecorated stage's own setMaximized would cover it).
            List<Screen> screens = Screen.getScreensForRectangle(restoreBounds);
            Screen screen = screens.isEmpty() ? Screen.getPrimary() : screens.get(0);
            Rectangle2D area = screen.getVisualBounds();
            stage.setX(area.getMinX());
            stage.setY(area.getMinY());
            stage.setWidth(area.getWidth());
            stage.setHeight(area.getHeight());
            maximized = true;
        }
        setMaximizeGlyph();
    }

    // =====================================================================
    // Resize from the edges (WINDOW only)
    // =====================================================================

    private void installResize() {
        scene.addEventFilter(MouseEvent.MOUSE_MOVED, e -> {
            int zone = maximized ? 0 : zoneAt(e.getSceneX(), e.getSceneY());
            scene.setCursor(cursorFor(zone));
        });
        scene.addEventFilter(MouseEvent.MOUSE_EXITED_TARGET, e -> {
            if (resizeZone == 0) {
                scene.setCursor(null);
            }
        });
        scene.addEventFilter(MouseEvent.MOUSE_PRESSED, e -> {
            if (maximized || e.getButton() != MouseButton.PRIMARY) {
                return;
            }
            int zone = zoneAt(e.getSceneX(), e.getSceneY());
            if (zone == 0) {
                return;
            }
            resizeZone = zone;
            startX = e.getScreenX();
            startY = e.getScreenY();
            startBounds = new Rectangle2D(stage.getX(), stage.getY(), stage.getWidth(), stage.getHeight());
            e.consume();
        });
        scene.addEventFilter(MouseEvent.MOUSE_DRAGGED, e -> {
            if (resizeZone == 0) {
                return;
            }
            resizeTo(e.getScreenX() - startX, e.getScreenY() - startY);
            e.consume();
        });
        scene.addEventFilter(MouseEvent.MOUSE_RELEASED, e -> {
            if (resizeZone != 0) {
                resizeZone = 0;
                e.consume();
            }
        });
    }

    private void resizeTo(double dx, double dy) {
        double minW = Math.max(stage.getMinWidth(), Dim.Frame.MIN_WIDTH);
        double minH = Math.max(stage.getMinHeight(), Dim.Frame.MIN_HEIGHT);
        double x = startBounds.getMinX();
        double y = startBounds.getMinY();
        double w = startBounds.getWidth();
        double h = startBounds.getHeight();

        if ((resizeZone & EAST) != 0) {
            w = Math.max(minW, startBounds.getWidth() + dx);
        }
        if ((resizeZone & WEST) != 0) {
            w = Math.max(minW, startBounds.getWidth() - dx);
            x = startBounds.getMaxX() - w;
        }
        if ((resizeZone & SOUTH) != 0) {
            h = Math.max(minH, startBounds.getHeight() + dy);
        }
        if ((resizeZone & NORTH) != 0) {
            h = Math.max(minH, startBounds.getHeight() - dy);
            y = startBounds.getMaxY() - h;
        }
        stage.setX(x);
        stage.setY(y);
        stage.setWidth(w);
        stage.setHeight(h);
    }

    private int zoneAt(double x, double y) {
        double m = Dim.Frame.RESIZE_MARGIN;
        double w = scene.getWidth();
        double h = scene.getHeight();
        int zone = 0;
        if (y < m) {
            zone |= NORTH;
        } else if (y > h - m) {
            zone |= SOUTH;
        }
        if (x < m) {
            zone |= WEST;
        } else if (x > w - m) {
            zone |= EAST;
        }
        return zone;
    }

    /** null outside the edges, so the nodes' own cursors (a text field's I-beam) show. */
    private static Cursor cursorFor(int zone) {
        return switch (zone) {
            case NORTH -> Cursor.N_RESIZE;
            case SOUTH -> Cursor.S_RESIZE;
            case WEST -> Cursor.W_RESIZE;
            case EAST -> Cursor.E_RESIZE;
            case NORTH | WEST -> Cursor.NW_RESIZE;
            case NORTH | EAST -> Cursor.NE_RESIZE;
            case SOUTH | WEST -> Cursor.SW_RESIZE;
            case SOUTH | EAST -> Cursor.SE_RESIZE;
            default -> null;
        };
    }

    // =====================================================================
    // Theme and base colour
    // =====================================================================

    /** The owner's sheets (theme, ribbon, editor ...), so the frame matches the IDE. */
    private void copyOwnerSheets() {
        if (owner != null && owner.getScene() != null) {
            scene.getStylesheets().setAll(owner.getScene().getStylesheets());
        }
    }

    /**
     * Redefines the active-title tokens on this frame's root while the Custom
     * layout's base colour is in force, with the same ink, edge and hover the
     * panel strips get from it ({@code CustomLayoutTheme}); clears them
     * otherwise, so the palette's own values show.
     */
    private void applyBase(Color base) {
        if (base == null) {
            root.setStyle("");
            return;
        }
        String fill = CustomLayoutConfig.hex(base);
        String ink = CustomLayoutConfig.hex(CustomLayoutConfig.ink(base));
        String edge = CustomLayoutConfig.hex(CustomLayoutConfig.mix(base, Color.BLACK, 0.25));
        String hover = CustomLayoutConfig.isLight(base) ? "rgba(0, 0, 0, 0.12)" : "rgba(255, 255, 255, 0.20)";
        root.setStyle("-astra-title-active: " + fill + ";"
                + " -astra-title-active-text: " + ink + ";"
                + " -astra-title-active-line: " + edge + ";"
                + " -astra-title-active-button-hover: " + hover + ";");
    }

    // =====================================================================
    // Helpers
    // =====================================================================

    private void centreOverOwner() {
        if (owner == null) {
            return;
        }
        stage.setX(owner.getX() + (owner.getWidth() - stage.getWidth()) / 2);
        stage.setY(owner.getY() + (owner.getHeight() - stage.getHeight()) / 3);
    }

    private static Label wrapped(String text, String styleClass) {
        Label label = new Label(text);
        label.getStyleClass().add(styleClass);
        label.setWrapText(true);
        label.setMnemonicParsing(false);
        label.setMaxWidth(Double.MAX_VALUE);
        label.setMinHeight(Region.USE_PREF_SIZE);
        return label;
    }

    private static Image ownerIcon(Window owner) {
        if (owner instanceof Stage s && !s.getIcons().isEmpty()) {
            return s.getIcons().get(0);
        }
        return null;
    }
}
