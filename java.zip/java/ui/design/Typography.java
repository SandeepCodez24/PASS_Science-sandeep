package ui.design;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

/**
 * Every font in the application, expressed as a small set of named roles.
 *
 * <h3>Why roles instead of sizes</h3>
 * <p>
 * Code should never ask for "12px bold" -- it should ask for
 * {@link Role#PANEL_TITLE}. That way "make all panel titles one point larger"
 * is a single edit here, and it lands identically on the Java side
 * ({@link #font}) and the CSS side ({@link #css}) because both read the same
 * enum.
 * </p>
 *
 * <h3>Why this matters more than it looks</h3>
 * <p>
 * Several controls in the ribbon have fixed heights holding text at fixed
 * sizes -- a 22px search box around a 12px field, a 22px compare zone around a
 * 10.5px label, a 73px item around an 11.5px label. If a scale factor moved the
 * boxes but not the text, or the reverse, that text would overflow or float.
 * Routing both through the design layer keeps them locked together.
 * </p>
 *
 * <h3>Two faces: UI and code</h3>
 * <p>
 * Like MATLAB, Astra draws its chrome (ribbon, menus, panels, dialogs, footer)
 * in the operating system's UI font and its source text (editor, CLI) in a
 * monospaced font. Each role names its {@link Face}. {@link Face#UI} roles
 * carry no family of their own and inherit {@link #uiFamily()} from
 * {@code .root}; {@link Face#CODE} roles emit {@link #codeFamily()} explicitly,
 * so an inline style on the editor keeps the monospaced face as well.
 * </p>
 *
 * <h3>Which font, on which system</h3>
 * <p>
 * Families are resolved once, at first use, against the fonts actually
 * installed. The first installed candidate for the current {@link Os} wins:
 * </p>
 * <ul>
 * <li>Windows -- UI: Segoe UI; code: Consolas, then Cascadia Mono.</li>
 * <li>macOS -- UI: JavaFX's logical {@code System} font, which JavaFX maps to
 * the macOS system face; code: Menlo, then Monaco.</li>
 * <li>Linux -- UI: Noto Sans, Ubuntu, Cantarell, DejaVu Sans, Liberation Sans;
 * code: DejaVu Sans Mono, Noto Sans Mono, Ubuntu Mono, Liberation Mono.</li>
 * </ul>
 * <p>
 * Every list ends in a JavaFX logical font ({@code System} or
 * {@code Monospaced}), which always resolves. No font file is bundled: Segoe
 * UI is licensed with Windows and must not be redistributed, so it is only
 * ever referred to by name.
 * </p>
 * <p>
 * Resolution needs the JavaFX toolkit to be running ({@link Font#getFamilies}
 * requires it). {@code DesignStylesheet.install} runs inside
 * {@code Application.start}, so that is already the case. If a family is
 * asked for earlier, the first candidate is used unchecked; JavaFX then falls
 * back on its own if that font is missing.
 * </p>
 * <p>
 * To preview another platform's look on the development machine, launch with
 * {@code -Dastra.font.ui="DejaVu Sans"} and/or
 * {@code -Dastra.font.code="DejaVu Sans Mono"}. An override is used as given,
 * without an installation check.
 * </p>
 *
 * <h3>The base size</h3>
 * <p>
 * {@link #BASE_SIZE} is emitted onto {@code .root} by {@link DesignStylesheet}.
 * Anything that does not name a role inherits it, so raising the base size
 * enlarges the whole UI's text in one move. It is set to 13, which is what the
 * Modena default resolves to, so introducing it changes nothing visually.
 * </p>
 *
 * <h3>Adding a role</h3>
 * <p>
 * Add the enum constant, then use it. If the role needs to reach CSS, add one
 * line to {@link DesignStylesheet}. Roles are named after what the text
 * <em>is</em>, never after how it looks -- {@code FOOTER_BUTTON}, not
 * {@code TINY_TEXT}.
 * </p>
 */
public final class Typography {

    // =====================================================================
    // Platform and faces
    // =====================================================================

    /** The operating system Astra is running on, as far as fonts care. */
    public enum Os {
        WINDOWS, MAC, LINUX;

        static Os detect() {
            String name = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
            if (name.contains("win")) {
                return WINDOWS;
            }
            if (name.contains("mac") || name.contains("darwin")) {
                return MAC;
            }
            return LINUX;
        }
    }

    /** Which family a role is drawn in. */
    public enum Face {
        /** The operating system's UI font -- toolstrips, menus, panels. */
        UI,
        /** A monospaced font -- editor and CLI source text. */
        CODE
    }

    /** The platform detected at startup. */
    public static final Os OS = Os.detect();

    /** System property that forces the UI family. */
    public static final String UI_FONT_PROPERTY = "astra.font.ui";

    /** System property that forces the code family. */
    public static final String CODE_FONT_PROPERTY = "astra.font.code";

    /**
     * Style class that gives any node the code family through the generated
     * stylesheet. The editor's {@code .code-area} is covered already; add this
     * class to the CLI (and anything else that must stay monospaced) with
     * {@code node.getStyleClass().add(Typography.CODE_FONT_CLASS)}.
     */
    public static final String CODE_FONT_CLASS = "astra-code-font";

    /**
     * Whether the generated stylesheet asks for LCD (ClearType-style) text
     * smoothing. Windows only: macOS no longer uses subpixel smoothing and
     * Linux desktops vary. JavaFX quietly falls back to greyscale where LCD
     * cannot be used (non-opaque backgrounds, effects, transforms). Set to
     * {@code false} if colour fringes ever appear.
     */
    public static final boolean LCD_TEXT = OS == Os.WINDOWS;

    /** JavaFX logical families: always available, never listed as installed. */
    private static final Set<String> LOGICAL =
            Set.of("System", "SansSerif", "Serif", "Monospaced");

    private static final List<String> UI_WINDOWS =
            List.of("Segoe UI", "Tahoma", "System");
    private static final List<String> UI_SEMIBOLD_WINDOWS =
            List.of("Segoe UI Semibold", "Segoe UI", "System");
    private static final List<String> UI_MAC =
            List.of("System");
    private static final List<String> UI_LINUX =
            List.of("Noto Sans", "Ubuntu", "Cantarell", "DejaVu Sans",
                    "Liberation Sans", "System");

    private static final List<String> CODE_WINDOWS =
            List.of("Consolas", "Cascadia Mono", "Courier New", "Monospaced");
    private static final List<String> CODE_MAC =
            List.of("Menlo", "Monaco", "Courier New", "Monospaced");
    private static final List<String> CODE_LINUX =
            List.of("DejaVu Sans Mono", "Noto Sans Mono", "Ubuntu Mono",
                    "Liberation Mono", "Monospaced");

    // =====================================================================
    // Sizes
    // =====================================================================

    /** Size everything inherits unless it names a role. Unscaled design value. */
    public static final double BASE_SIZE = 13;

    /**
     * Enlargement applied to the Row-2 tool band's text roles, a ratio (not a
     * length, so not scaled by {@link UIScale}).
     *
     * <p>
     * Raised from 1.0 to 1.07 when the tool band gained the height the
     * quick-access row gave up. It multiplies exactly six roles:
     * {@code GROUP_CAPTION}, {@code RIBBON_ITEM}, {@code SPLIT_LABEL},
     * {@code COMPARE_LABEL}, {@code READOUT_TITLE} and {@code READOUT_VALUE}.
     * Row 1 (tabs, search), {@code COMPACT_BUTTON} and everything outside the
     * band are unaffected. The matching icon enlargement is
     * {@code ToolBand_dim.ICON_SCALE}; the two are separate so the text can be
     * pulled back (to 1.05, say) without shrinking the icons.
     * </p>
     */
    public static final double TOOL_BAND_TEXT_SCALE = 1.07;

    /** A named text style. Sizes are design values at scale 1.0. */
    public enum Role {

        /** Default UI text: anything that does not name a more specific role. */
        BASE(BASE_SIZE, FontWeight.NORMAL),

        // ---- panels -------------------------------------------------------

        /** Panel title strip: "File Explorer", "Variable Explorer". */
        PANEL_TITLE(12, FontWeight.BOLD),

        /** Rotated label on a collapsed panel's vertical rail. */
        PANEL_RAIL(11, FontWeight.BOLD),

        // ---- directory explorer --------------------------------------------

        /**
         * A file or folder name, an Info count, and an entry in the Info
         * drop-down menu.
         */
        DIRECTORY_ROW(BASE_SIZE, FontWeight.NORMAL),

        /**
         * The "Name", "Info" and "R" captions in the directory header strip.
         * Deliberately the same size as {@link #DIRECTORY_ROW} and not bold:
         * Modena draws table headers bold at 1.08em, which made the header
         * read larger than the rows beneath it. Kept as its own role so the
         * header can be tuned without moving the rows.
         */
        DIRECTORY_HEADER(BASE_SIZE, FontWeight.NORMAL),

        /**
         * Both rows of the Info header: the "Info" caption and the mode name
         * beneath it. Smaller than {@link #DIRECTORY_HEADER} so the two rows
         * fit a header strip only slightly taller than a single caption.
         */
        DIRECTORY_INFO_HEADER(10, FontWeight.NORMAL),

        // ---- Row 1: the ribbon tab strip -----------------------------------

        /** Home / Signals / JTAG / Commission / Settings / Help. */
        RIBBON_TAB(12, FontWeight.BOLD),

        /** Text typed into the ribbon search box. */
        SEARCH_FIELD(12, FontWeight.NORMAL),

        // ---- Row 2: the tool band ------------------------------------------

        /** Compartment name along the bottom edge of a group. */
        GROUP_CAPTION(11 * TOOL_BAND_TEXT_SCALE, FontWeight.NORMAL),

        /** Label beneath a compartment item's icon. */
        RIBBON_ITEM(11.5 * TOOL_BAND_TEXT_SCALE, FontWeight.NORMAL),

        /** Label in a Files split button's drop-down zone. */
        SPLIT_LABEL(11.5 * TOOL_BAND_TEXT_SCALE, FontWeight.NORMAL),

        /** Label inside a Signals compare selector. */
        COMPARE_LABEL(10.5 * TOOL_BAND_TEXT_SCALE, FontWeight.NORMAL),

        /** Caption line of an Analysis readout. */
        READOUT_TITLE(9.5 * TOOL_BAND_TEXT_SCALE, FontWeight.NORMAL),

        /** Value line of an Analysis readout. */
        READOUT_VALUE(13 * TOOL_BAND_TEXT_SCALE, FontWeight.BOLD),

        /**
         * Compact horizontal action button used outside the ribbon.
         * Deliberately NOT multiplied by {@link #TOOL_BAND_TEXT_SCALE}: this
         * button does not sit in the tool band, so it keeps its original size.
         * {@code DesignStylesheet} still reads this role -- do not remove it.
         */
        COMPACT_BUTTON(11, FontWeight.NORMAL),

        // ---- navigation and breadcrumb bar ----------------------------------

        /** A folder name in the breadcrumb path. */
        BREADCRUMB_SEGMENT(11, FontWeight.NORMAL),

        /** The path typed into the breadcrumb once it is switched to editing. */
        BREADCRUMB_EDITOR(11.5, FontWeight.NORMAL),

        // ---- Astra dialogs ---------------------------------------------------

        /** Text on the navy title strip of an Astra dialog. */
        DIALOG_TITLE(12, FontWeight.BOLD),

        /** Message body of an Astra dialog. */
        DIALOG_MESSAGE(12.5, FontWeight.NORMAL),

        /** Buttons in an Astra dialog's footer. */
        DIALOG_BUTTON(11.5, FontWeight.NORMAL),

        // ---- editor ---------------------------------------------------------

        /**
         * Source text in an editor tab, .nc and plain text alike. Applied as an
         * inline style on the editor, because the editor's own stylesheet rule
         * is a smaller fallback size. Monospaced, so the inline style carries
         * the code family too.
         */
        EDITOR_CODE(16, FontWeight.NORMAL, Face.CODE),

        /**
         * Line numbers in the editor gutter. Lines of 10000 and above are drawn
         * smaller than this to fit the same slot; see {@code Editor_dim}.
         * Monospaced so every digit takes the same width in the 4-digit slot.
         */
        EDITOR_LINE_NUMBER(13, FontWeight.NORMAL, Face.CODE),

        // ---- footer ---------------------------------------------------------

        /** Footer status text: file name, cursor position, encoding, state. */
        FOOTER_LABEL(BASE_SIZE, FontWeight.NORMAL),

        /** Footer error and warning count buttons. */
        FOOTER_BUTTON(8.25, FontWeight.NORMAL);

        private final double designSize;
        private final FontWeight weight;
        private final Face face;

        Role(double designSize, FontWeight weight) {
            this(designSize, weight, Face.UI);
        }

        Role(double designSize, FontWeight weight, Face face) {
            this.designSize = designSize;
            this.weight = weight;
            this.face = face;
        }

        /**
         * @return the size before scaling, as written above
         */
        public double designSize() {
            return designSize;
        }

        /**
         * @return the weight of this role
         */
        public FontWeight weight() {
            return weight;
        }

        /**
         * @return the face this role is drawn in
         */
        public Face face() {
            return face;
        }
    }

    private Typography() {
    }

    // =====================================================================
    // Families
    // =====================================================================

    /** Resolved lazily, on first use, so the JavaFX toolkit is already up. */
    private static final class Resolved {
        static final Set<String> INSTALLED = installedFamilies();

        static final String UI = pick(System.getProperty(UI_FONT_PROPERTY),
                uiCandidates(), INSTALLED);

        static final String UI_SEMIBOLD = OS == Os.WINDOWS
                && System.getProperty(UI_FONT_PROPERTY) == null
                        ? pick(null, UI_SEMIBOLD_WINDOWS, INSTALLED)
                        : UI;

        static final String CODE = pick(System.getProperty(CODE_FONT_PROPERTY),
                codeCandidates(), INSTALLED);
    }

    /**
     * @return the UI family: Segoe UI on Windows, the platform equivalent
     *         elsewhere
     */
    public static String uiFamily() {
        return Resolved.UI;
    }

    /**
     * The family used for {@link FontWeight#SEMI_BOLD} UI roles. On Windows
     * this is the separate "Segoe UI Semibold" family, because JavaFX treats
     * any weight below bold as regular when it picks a font file. Elsewhere it
     * is {@link #uiFamily()}, and semibold renders as regular.
     *
     * @return the semibold UI family
     */
    public static String uiSemiboldFamily() {
        return Resolved.UI_SEMIBOLD;
    }

    /**
     * @return the monospaced family for editor and CLI text
     */
    public static String codeFamily() {
        return Resolved.CODE;
    }

    /**
     * The family a role is drawn in.
     *
     * @param role the text role
     * @return the resolved family name
     */
    public static String family(Role role) {
        if (role.face() == Face.CODE) {
            return codeFamily();
        }
        if (role.weight() == FontWeight.SEMI_BOLD) {
            return uiSemiboldFamily();
        }
        return uiFamily();
    }

    /**
     * A family name as a quoted CSS value.
     *
     * @param family the family name
     * @return e.g. {@code "Segoe UI"}, quotes included
     */
    public static String familyCss(String family) {
        return "\"" + family.replace("\"", "") + "\"";
    }

    /**
     * One-line summary of the resolved fonts, for the generated stylesheet's
     * header and for logging.
     *
     * @return e.g. {@code WINDOWS -- UI "Segoe UI", code "Consolas"}
     */
    public static String describe() {
        return OS + " -- UI " + familyCss(uiFamily())
                + ", code " + familyCss(codeFamily());
    }

    // =====================================================================
    // Sizes and declarations
    // =====================================================================

    /**
     * The scaled point size of a role.
     *
     * @param role the text role
     * @return the size to render at
     */
    public static double size(Role role) {
        return UIScale.px(role.designSize());
    }

    /**
     * A ready-to-use {@link Font} for a role, for the rare node that has to be
     * styled from Java rather than CSS.
     *
     * @param role the text role
     * @return the font
     */
    public static Font font(Role role) {
        return Font.font(family(role), role.weight(), FontPosture.REGULAR, size(role));
    }

    /**
     * The CSS declarations for a role, ready to drop inside a rule body.
     *
     * <p>
     * A family is emitted only when the role's family differs from the one
     * {@code .root} provides (code roles, and semibold on Windows); plain UI
     * roles inherit it.
     * </p>
     *
     * @param role the text role
     * @return e.g. {@code -fx-font-size: 12px; -fx-font-weight: bold;}
     */
    public static String css(Role role) {
        StringBuilder out = new StringBuilder(96);
        String family = family(role);
        if (!family.equals(uiFamily())) {
            out.append("-fx-font-family: ").append(familyCss(family)).append("; ");
        }
        out.append("-fx-font-size: ").append(UIScale.fmt(size(role))).append("px;")
                .append(" -fx-font-weight: ").append(weightCss(role.weight())).append(";");
        return out.toString();
    }

    /**
     * The CSS declarations for a role, as an inline {@code setStyle} fragment.
     * Prefer {@link #css} inside a stylesheet; inline styles beat stylesheets
     * and make a control impossible to re-theme.
     *
     * @param role the text role
     * @return the same text as {@link #css}
     */
    public static String inline(Role role) {
        return css(role);
    }

    // =====================================================================
    // Internals
    // =====================================================================

    private static List<String> uiCandidates() {
        switch (OS) {
            case WINDOWS:
                return UI_WINDOWS;
            case MAC:
                return UI_MAC;
            default:
                return UI_LINUX;
        }
    }

    private static List<String> codeCandidates() {
        switch (OS) {
            case WINDOWS:
                return CODE_WINDOWS;
            case MAC:
                return CODE_MAC;
            default:
                return CODE_LINUX;
        }
    }

    /**
     * First installed candidate, or the override if one is given. With no
     * installed-font list (toolkit not started) the first candidate is
     * returned unchecked.
     */
    private static String pick(String override, List<String> candidates, Set<String> installed) {
        if (override != null && !override.isBlank()) {
            return override.trim();
        }
        if (installed.isEmpty()) {
            return candidates.get(0);
        }
        for (String family : candidates) {
            if (LOGICAL.contains(family) || installed.contains(family)) {
                return family;
            }
        }
        return candidates.get(candidates.size() - 1);
    }

    private static Set<String> installedFamilies() {
        try {
            return new HashSet<>(Font.getFamilies());
        } catch (RuntimeException ex) {
            return Set.of();
        }
    }

    private static String weightCss(FontWeight weight) {
        if (weight == null) {
            return "normal";
        }
        switch (weight) {
            case BOLD:
            case EXTRA_BOLD:
            case BLACK:
                return "bold";
            case LIGHT:
            case EXTRA_LIGHT:
            case THIN:
                return "light";
            case SEMI_BOLD:
                return "600";
            default:
                return "normal";
        }
    }
}
