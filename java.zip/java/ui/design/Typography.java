package ui.design;

import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

/**
 * Every font in the application, expressed as a small set of named roles.
 *
 * <h3>Why roles instead of sizes</h3>
 * <p>
 * Code should never ask for "12px bold" -- it should ask for
 * {@link Role#PANEL_TITLE}. That way "make all panel titles one point larger"
 * is a single edit here, and it lands identically on the Java side
 * ({@link #font}) and the CSS side ({@link #css}) because both read the same
 * enum.
 * </p>
 *
 * <h3>Why this matters more than it looks</h3>
 * <p>
 * Several controls in the ribbon have fixed heights holding text at fixed
 * sizes -- a 22px search box around a 12px field, a 22px compare zone around a
 * 10.5px label, a 66px item around an 11.5px label. If a scale factor moved the
 * boxes but not the text, or the reverse, that text would overflow or float.
 * Routing both through the design layer keeps them locked together.
 * </p>
 *
 * <h3>The base size</h3>
 * <p>
 * {@link #BASE_SIZE} is emitted onto {@code .root} by {@link DesignStylesheet}.
 * Anything that does not name a role inherits it, so raising the base size
 * enlarges the whole UI's text in one move. It is set to 13, which is what the
 * Modena default resolves to, so introducing it changes nothing visually.
 * </p>
 *
 * <h3>Adding a role</h3>
 * <p>
 * Add the enum constant, then use it. If the role needs to reach CSS, add one
 * line to {@link DesignStylesheet}. Roles are named after what the text
 * <em>is</em>, never after how it looks -- {@code FOOTER_BUTTON}, not
 * {@code TINY_TEXT}.
 * </p>
 */
public final class Typography {

    /**
     * The UI font stack, in CSS form. Kept identical to the {@code .root} rule
     * that used to live in the theme files.
     */
    public static final String FAMILY_CSS = "\"Consolas\", \"Segoe UI\", monospace";

    /** First family of {@link #FAMILY_CSS}, for the Java-side {@link Font} API. */
    public static final String FAMILY = "Consolas";

    /** Size everything inherits unless it names a role. Unscaled design value. */
    public static final double BASE_SIZE = 13;

    /** A named text style. Sizes are design values at scale 1.0. */
    public enum Role {

        /** Default UI text: anything that does not name a more specific role. */
        BASE(BASE_SIZE, FontWeight.NORMAL),

        // ---- panels -------------------------------------------------------

        /** Panel title strip: "File Explorer", "Variable Explorer". */
        PANEL_TITLE(12, FontWeight.BOLD),

        /** Rotated label on a collapsed panel's vertical rail. */
        PANEL_RAIL(11, FontWeight.BOLD),

        // ---- Row 1: the ribbon tab strip -----------------------------------

        /** Home / Signals / JTAG / Commission / Settings / Help. */
        RIBBON_TAB(12, FontWeight.BOLD),

        /** Text typed into the ribbon search box. */
        SEARCH_FIELD(12, FontWeight.NORMAL),

        // ---- Row 2: the tool band ------------------------------------------

        /** Compartment name along the bottom edge of a group. */
        GROUP_CAPTION(11, FontWeight.NORMAL),

        /** Label beneath a compartment item's icon. */
        RIBBON_ITEM(11.5, FontWeight.NORMAL),

        /** Label in a Files split button's drop-down zone. */
        SPLIT_LABEL(11.5, FontWeight.NORMAL),

        /** Label inside a Signals compare selector. */
        COMPARE_LABEL(10.5, FontWeight.NORMAL),

        /** Caption line of an Analysis readout. */
        READOUT_TITLE(9.5, FontWeight.NORMAL),

        /** Value line of an Analysis readout. */
        READOUT_VALUE(13, FontWeight.BOLD),

        /** Compact horizontal action button used outside the ribbon. */
        COMPACT_BUTTON(11, FontWeight.NORMAL),

        // ---- footer ---------------------------------------------------------

        /** Footer status text: file name, cursor position, encoding, state. */
        FOOTER_LABEL(BASE_SIZE, FontWeight.NORMAL),

        /** Footer error and warning count buttons. */
        FOOTER_BUTTON(8.25, FontWeight.NORMAL);

        private final double designSize;
        private final FontWeight weight;

        Role(double designSize, FontWeight weight) {
            this.designSize = designSize;
            this.weight = weight;
        }

        /**
         * @return the size before scaling, as written above
         */
        public double designSize() {
            return designSize;
        }

        /**
         * @return the weight of this role
         */
        public FontWeight weight() {
            return weight;
        }
    }

    private Typography() {
    }

    /**
     * The scaled point size of a role.
     *
     * @param role the text role
     * @return the size to render at
     */
    public static double size(Role role) {
        return UIScale.px(role.designSize());
    }

    /**
     * A ready-to-use {@link Font} for a role, for the rare node that has to be
     * styled from Java rather than CSS.
     *
     * @param role the text role
     * @return the font
     */
    public static Font font(Role role) {
        return Font.font(FAMILY, role.weight(), FontPosture.REGULAR, size(role));
    }

    /**
     * The CSS declarations for a role, ready to drop inside a rule body.
     *
     * @param role the text role
     * @return e.g. {@code -fx-font-size: 12px; -fx-font-weight: bold;}
     */
    public static String css(Role role) {
        return "-fx-font-size: " + UIScale.fmt(size(role)) + "px;"
                + " -fx-font-weight: " + weightCss(role.weight()) + ";";
    }

    /**
     * The CSS declarations for a role, as an inline {@code setStyle} fragment.
     * Prefer {@link #css} inside a stylesheet; inline styles beat stylesheets
     * and make a control impossible to re-theme.
     *
     * @param role the text role
     * @return the same text as {@link #css}
     */
    public static String inline(Role role) {
        return css(role);
    }

    private static String weightCss(FontWeight weight) {
        if (weight == null) {
            return "normal";
        }
        switch (weight) {
            case BOLD:
            case EXTRA_BOLD:
            case BLACK:
                return "bold";
            case LIGHT:
            case EXTRA_LIGHT:
            case THIN:
                return "light";
            case SEMI_BOLD:
                return "600";
            default:
                return "normal";
        }
    }
}
