package ui.design;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.prefs.Preferences;

import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

/**
 * Every font in the application, expressed as a small set of named roles.
 *
 * <h3>Why roles instead of sizes</h3>
 * <p>
 * Code should never ask for "12px bold" -- it should ask for
 * {@link Role#PANEL_TITLE}. That way "make all panel titles one point larger"
 * is a single edit here, and it lands identically on the Java side
 * ({@link #font}) and the CSS side ({@link #css}) because both read the same
 * enum.
 * </p>
 *
 * <h3>Why this matters more than it looks</h3>
 * <p>
 * Several controls in the ribbon have fixed heights holding text at fixed
 * sizes -- a 22px search box around a 12px field, a 22px compare zone around a
 * 10.5px label, a 73px item around an 11.5px label. If a scale factor moved the
 * boxes but not the text, or the reverse, that text would overflow or float.
 * Routing both through the design layer keeps them locked together.
 * </p>
 *
 * <h3>Three faces: UI, path and code</h3>
 * <p>
 * Like MATLAB, Astra draws its chrome (ribbon, menus, panels, dialogs, footer)
 * in the operating system's UI font and its source text (editor, CLI) in a
 * monospaced font. Each role names its {@link Face}. {@link Face#UI} roles
 * carry no family of their own and inherit {@link #uiFamily()} from
 * {@code .root}; {@link Face#CODE} roles emit {@link #codeFamily()} explicitly,
 * so an inline style on the editor keeps the monospaced face as well.
 * </p>
 * <p>
 * {@link Face#PATH} was the breadcrumb's face: Tahoma on Windows. The
 * breadcrumb now uses the UI face ({@link #BREADCRUMB_FACE} explains why); the
 * notes below record why Tahoma was chosen at the old fixed size of 11. Segoe UI at
 * 11-12px puts most vertical stems on a single pixel and reads thin next to
 * MATLAB. Arial (tried first) was heavier but uneven: it is lightly hinted,
 * so with JavaFX's fractional glyph positions one stem landed on a single
 * dark pixel and the next was smeared grey across two, and every folder name
 * came out a different weight. Tahoma is a screen face with strong TrueType
 * hinting: its stems are drawn to whole pixels at UI sizes, so they come out
 * the same width and darkness everywhere, with the firm look of MATLAB's path
 * bar. Like {@link Face#CODE}, path roles emit their family explicitly.
 * </p>
 * <p>
 * The other half of that fix is {@link #configureTextRendering()}, which turns
 * off sub-pixel glyph positioning before the toolkit starts. It has to be
 * called from {@code Launcher.main}, ahead of {@code Application.launch}.
 * </p>
 *
 * <h3>Which font, on which system</h3>
 * <p>
 * Families are resolved once, at first use, against the fonts actually
 * installed. The first installed candidate for the current {@link Os} wins:
 * </p>
 * <ul>
 * <li>Windows -- UI: Segoe UI; code: Consolas, then Cascadia Mono.</li>
 * <li>macOS -- UI: JavaFX's logical {@code System} font, which JavaFX maps to
 * the macOS system face; code: Menlo, then Monaco.</li>
 * <li>Linux -- UI: Noto Sans, Ubuntu, Cantarell, DejaVu Sans, Liberation Sans;
 * code: DejaVu Sans Mono, Noto Sans Mono, Ubuntu Mono, Liberation Mono.</li>
 * <li>Path (breadcrumb) -- Windows: Tahoma, then Arial; macOS: Tahoma (shipped
 * with macOS), then Verdana; Linux: DejaVu Sans (a Verdana derivative, the
 * nearest freely installed relative of Tahoma), then Liberation Sans. Each
 * list ends in the logical {@code System} font.</li>
 * </ul>
 * <p>
 * Every list ends in a JavaFX logical font ({@code System} or
 * {@code Monospaced}), which always resolves. No font file is bundled: Segoe
 * UI is licensed with Windows and must not be redistributed, so it is only
 * ever referred to by name.
 * </p>
 * <p>
 * Resolution needs the JavaFX toolkit to be running ({@link Font#getFamilies}
 * requires it). {@code DesignStylesheet.install} runs inside
 * {@code Application.start}, so that is already the case. If a family is
 * asked for earlier, the first candidate is used unchecked; JavaFX then falls
 * back on its own if that font is missing.
 * </p>
 * <p>
 * To preview another platform's look on the development machine, launch with
 * {@code -Dastra.font.ui="DejaVu Sans"} and/or
 * {@code -Dastra.font.code="DejaVu Sans Mono"}, and the breadcrumb face with
 * {@code -Dastra.font.path="DejaVu Sans"}. An override is used as given,
 * without an installation check.
 * </p>
 *
 * <h3>One size for the whole chrome</h3>
 * <p>
 * {@link #DEFAULT_UI_FONT_SIZE} (12) is the one number: every UI role --
 * panels, explorers, ribbon, breadcrumb, footer, menus, dialogs -- is that
 * size, bold where it is a title, tab or header. Secondary text (captions,
 * counters, time stamps) is {@link #SECONDARY_RATIO} of it. Only the editor's
 * source text and line numbers ({@link Track#FIXED}) keep a size of their own.
 * </p>
 * <p>
 * The user can change it at run time from the Custom Layout window, between
 * {@link #UI_FONT_SIZE_MIN} and {@link #UI_FONT_SIZE_MAX};
 * {@link #setUiFontSize(double)} applies it at once, with no restart. Boxes
 * that hold text ({@link Dim#recomputeTextHeights()}) grow with it, but never
 * below the height they were designed at, so the default layout is exactly the
 * designed one.
 * </p>
 * <p>
 * {@code .root} carries the UI size ({@link Role#BASE}), so anything that
 * does not name a role inherits it too.
 * </p>
 *
 * <h3>Adding a role</h3>
 * <p>
 * Add the enum constant, then use it. If the role needs to reach CSS, add one
 * line to {@link DesignStylesheet}. Roles are named after what the text
 * <em>is</em>, never after how it looks -- {@code FOOTER_BUTTON}, not
 * {@code TINY_TEXT}.
 * </p>
 */
public final class Typography {

    // =====================================================================
    // Platform and faces
    // =====================================================================

    /** The operating system Astra is running on, as far as fonts care. */
    public enum Os {
        WINDOWS, MAC, LINUX;

        static Os detect() {
            String name = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
            if (name.contains("win")) {
                return WINDOWS;
            }
            if (name.contains("mac") || name.contains("darwin")) {
                return MAC;
            }
            return LINUX;
        }
    }

    /** Which family a role is drawn in. */
    public enum Face {
        /** The operating system's UI font -- toolstrips, menus, panels. */
        UI,
        /** A monospaced font -- editor and CLI source text. */
        CODE,
        /**
         * The breadcrumb path face -- Tahoma on Windows: strongly hinted, so
         * every stem renders at the same width and darkness.
         */
        PATH
    }

    /**
     * The face the breadcrumb path is drawn in: {@link Face#UI}, the same face
     * as every panel.
     *
     * <p>
     * It used to be {@link Face#PATH} (Tahoma on Windows), chosen when the
     * breadcrumb had one fixed size, 11. With the Font Size setting the path
     * is drawn at every size from 10 to 16, and Tahoma does not render
     * evenly across that range: at 12 its text lost ClearType (LCD)
     * smoothing and came out grey and smeared, while 10 and 14 were sharp.
     * The likely cause is Tahoma's own per-size rendering table ("gasp"),
     * which asks for different smoothing at different pixel sizes; Segoe UI,
     * which every panel uses, renders cleanly at all of them. One face for
     * the whole chrome also suits the single-size design.
     * </p>
     * <p>
     * To bring Tahoma back for a test, set this to {@link Face#PATH}; the
     * {@code -Dastra.font.path} override then chooses the family as before.
     * </p>
     */
    public static final Face BREADCRUMB_FACE = Face.UI;

    /** The platform detected at startup. */
    public static final Os OS = Os.detect();

    /** System property that forces the UI family. */
    public static final String UI_FONT_PROPERTY = "astra.font.ui";

    /** System property that forces the code family. */
    public static final String CODE_FONT_PROPERTY = "astra.font.code";

    /** System property that forces the breadcrumb path family. */
    public static final String PATH_FONT_PROPERTY = "astra.font.path";

    /**
     * Style class that gives any node the code family through the generated
     * stylesheet. The editor's {@code .code-area} is covered already; add this
     * class to the CLI (and anything else that must stay monospaced) with
     * {@code node.getStyleClass().add(Typography.CODE_FONT_CLASS)}.
     */
    public static final String CODE_FONT_CLASS = "astra-code-font";

    /**
     * Whether the generated stylesheet asks for LCD (ClearType-style) text
     * smoothing. Windows only: macOS no longer uses subpixel smoothing and
     * Linux desktops vary. JavaFX quietly falls back to greyscale where LCD
     * cannot be used (non-opaque backgrounds, effects, transforms). Set to
     * {@code false} if colour fringes ever appear.
     */
    public static final boolean LCD_TEXT = OS == Os.WINDOWS;

    /** JavaFX logical families: always available, never listed as installed. */
    private static final Set<String> LOGICAL =
            Set.of("System", "SansSerif", "Serif", "Monospaced");

    private static final List<String> UI_WINDOWS =
            List.of("Segoe UI", "Tahoma", "System");
    private static final List<String> UI_SEMIBOLD_WINDOWS =
            List.of("Segoe UI Semibold", "Segoe UI", "System");
    private static final List<String> UI_MAC =
            List.of("System");
    private static final List<String> UI_LINUX =
            List.of("Noto Sans", "Ubuntu", "Cantarell", "DejaVu Sans",
                    "Liberation Sans", "System");

    private static final List<String> PATH_WINDOWS =
            List.of("Tahoma", "Arial", "Segoe UI", "System");
    private static final List<String> PATH_MAC =
            List.of("Tahoma", "Verdana", "Helvetica Neue", "System");
    private static final List<String> PATH_LINUX =
            List.of("DejaVu Sans", "Liberation Sans", "Noto Sans", "System");

    private static final List<String> CODE_WINDOWS =
            List.of("Consolas", "Cascadia Mono", "Courier New", "Monospaced");
    private static final List<String> CODE_MAC =
            List.of("Menlo", "Monaco", "Courier New", "Monospaced");
    private static final List<String> CODE_LINUX =
            List.of("DejaVu Sans Mono", "Noto Sans Mono", "Ubuntu Mono",
                    "Liberation Mono", "Monospaced");

    // =====================================================================
    // Sizes -- THE ONE NUMBER
    // =====================================================================

    /**
     * The UI font size: the one number every panel, the ribbon, the footer,
     * the menus and the dialogs take their text size from. Design value at
     * scale 1.0, in pixels. <b>This is the only place the default lives</b>;
     * change it here and the whole chrome follows.
     *
     * <p>
     * The user can override it from the Custom Layout window (Font Size,
     * {@link #UI_FONT_SIZE_MIN} to {@link #UI_FONT_SIZE_MAX}); that choice is
     * stored under {@link #FONT_SIZE_PREF_KEY} and read back at launch.
     * Editor source text and the Command Window are not affected: their roles
     * are {@link Track#FIXED} and keep their own code size.
     * </p>
     */
    public static final double DEFAULT_UI_FONT_SIZE = 12;

    /** Smallest UI font size the user can choose. */
    public static final double UI_FONT_SIZE_MIN = 10;

    /** Largest UI font size the user can choose. */
    public static final double UI_FONT_SIZE_MAX = 16;

    /**
     * Secondary text -- the Info / Lines header, readout captions, footer
     * counters, time stamps, tooltip captions -- is this share of the UI font
     * size, so it moves with the setting and stays in proportion.
     */
    public static final double SECONDARY_RATIO = 0.85;

    /**
     * Preferences node of the stored size: the same node as
     * {@code UI_Main.prefs} ({@code Preferences.userNodeForPackage(UI_Main.class)},
     * package {@code ui}).
     */
    public static final String FONT_SIZE_PREF_NODE = "ui";

    /** Preferences key of the stored size; written by {@code CustomLayoutConfig}. */
    public static final String FONT_SIZE_PREF_KEY = "layout.custom.fontSize";

    /**
     * Height of one line of text as a share of the font size, used only when a
     * line cannot be measured (the toolkit is not running yet). Segoe UI is
     * 1.33; Tahoma and Consolas are a little less.
     */
    public static final double LINE_HEIGHT_FALLBACK = 1.33;

    /**
     * Kept so older code that names it still compiles. It no longer feeds any
     * role: every ribbon role now uses the one UI size, because ribbon text a
     * step larger than the panels is exactly the mismatch the central size
     * removes.
     *
     * @deprecated the tool band text is the UI font size; see {@link #uiFontSize()}
     */
    @Deprecated
    public static final double TOOL_BAND_TEXT_SCALE = 1.07;

    /**
     * Kept so older code that names it still compiles.
     *
     * @deprecated use {@link #DEFAULT_UI_FONT_SIZE} or {@link #uiFontSize()}
     */
    @Deprecated
    public static final double BASE_SIZE = DEFAULT_UI_FONT_SIZE;

    /** How a role's size is found. */
    public enum Track {
        /** The UI font size times the role's value (1.0 for every UI role today). */
        UI,
        /** The UI font size times {@link #SECONDARY_RATIO}. */
        SECONDARY,
        /** The role's own value, whatever the UI font size: editor code text. */
        FIXED
    }

    /** The size in force; starts from the stored choice, else the default. */
    private static double uiFontSize = clampFontSize(readStoredFontSize());

    /** Run, in order, after the size changes. */
    private static final List<Runnable> FONT_SIZE_LISTENERS = new CopyOnWriteArrayList<>();

    /** Measured line heights, keyed by family / weight / size. */
    private static final Map<String, Double> LINE_CACHE = new HashMap<>();

    /**
     * A named text style. Every UI role follows the one UI font size; the only
     * thing that sets one apart from another is its weight (titles, tabs and
     * headers are bold), its face, or being secondary text.
     */
    public enum Role {

        /** Default UI text: anything that does not name a more specific role. */
        BASE(Track.UI, 1.0, FontWeight.NORMAL),

        // ---- panels -------------------------------------------------------

        /** Panel title strip: "File Explorer", "Variable Explorer". */
        PANEL_TITLE(Track.UI, 1.0, FontWeight.BOLD),

        /** Rotated label on a collapsed panel's vertical rail. */
        PANEL_RAIL(Track.UI, 1.0, FontWeight.BOLD),

        // ---- directory explorer --------------------------------------------

        /**
         * A file or folder name, an Info count, an entry in the explorers'
         * menus, a Variable Explorer cell.
         */
        DIRECTORY_ROW(Track.UI, 1.0, FontWeight.NORMAL),

        /** The "Name", "Info" and "R" captions in the directory header strip. */
        DIRECTORY_HEADER(Track.UI, 1.0, FontWeight.NORMAL),

        /**
         * Both rows of the Info header: the "Info" caption and the mode name
         * beneath it. Secondary, so the two rows fit a header strip only
         * slightly taller than a single caption.
         */
        DIRECTORY_INFO_HEADER(Track.SECONDARY, 1.0, FontWeight.NORMAL),

        /**
         * A variable's name in the Variable Explorer. The UI size, but the
         * code face, so subscripts and Greek letters keep their code look.
         */
        VARIABLE_NAME(Track.UI, 1.0, FontWeight.NORMAL, Face.CODE),

        // ---- Row 1: the ribbon tab strip -----------------------------------

        /** Home / Signals / JTAG / Commission / Settings / Help. */
        RIBBON_TAB(Track.UI, 1.0, FontWeight.BOLD),

        /** Text typed into the ribbon search box. */
        SEARCH_FIELD(Track.UI, 1.0, FontWeight.NORMAL),

        // ---- Row 2: the tool band ------------------------------------------

        /** Compartment name along the bottom edge of a group. */
        GROUP_CAPTION(Track.UI, 1.0, FontWeight.NORMAL),

        /** Label beneath a compartment item's icon. */
        RIBBON_ITEM(Track.UI, 1.0, FontWeight.NORMAL),

        /** Label in a Files split button's drop-down zone. */
        SPLIT_LABEL(Track.UI, 1.0, FontWeight.NORMAL),

        /** Label inside a Signals compare selector and its action zone. */
        COMPARE_LABEL(Track.UI, 1.0, FontWeight.NORMAL),

        /** Caption line of an Analysis readout. Secondary. */
        READOUT_TITLE(Track.SECONDARY, 1.0, FontWeight.NORMAL),

        /** Value line of an Analysis readout. */
        READOUT_VALUE(Track.UI, 1.0, FontWeight.BOLD),

        /** Compact horizontal action button used outside the ribbon. */
        COMPACT_BUTTON(Track.UI, 1.0, FontWeight.NORMAL),

        // ---- navigation and breadcrumb bar ----------------------------------

        /**
         * The UI-face path size. The editor tab labels and the panels' menus
         * are sized from it.
         */
        BREADCRUMB_SEGMENT(Track.UI, 1.0, FontWeight.NORMAL),

        /** Retired; kept because older code may still name it. */
        BREADCRUMB_EDITOR(Track.UI, 1.0, FontWeight.NORMAL),

        /**
         * A folder name in the breadcrumb path, and the "click to edit" hint.
         * The UI face, like every other panel -- see
         * {@link Typography#BREADCRUMB_FACE} for why it is no longer Tahoma.
         */
        BREADCRUMB_PATH(Track.UI, 1.0, FontWeight.NORMAL, BREADCRUMB_FACE),

        /**
         * The path typed into the breadcrumb once it is switched to editing.
         * The same face and size as {@link #BREADCRUMB_PATH}, so the text does
         * not jump when the box turns into a text field.
         */
        BREADCRUMB_PATH_EDITOR(Track.UI, 1.0, FontWeight.NORMAL, BREADCRUMB_FACE),

        // ---- Astra dialogs ---------------------------------------------------

        /** Text on the title strip of an Astra dialog. */
        DIALOG_TITLE(Track.UI, 1.0, FontWeight.BOLD),

        /** Message body of an Astra dialog. */
        DIALOG_MESSAGE(Track.UI, 1.0, FontWeight.NORMAL),

        /** Buttons in an Astra dialog's footer. */
        DIALOG_BUTTON(Track.UI, 1.0, FontWeight.NORMAL),

        // ---- editor ---------------------------------------------------------

        /**
         * Source text in an editor tab, .nc and plain text alike. FIXED: the
         * editor keeps its own code size whatever the UI font size is.
         */
        EDITOR_CODE(Track.FIXED, 16, FontWeight.NORMAL, Face.CODE),

        /**
         * Line numbers in the editor gutter. FIXED, with the code text. Lines
         * of 10000 and above are drawn smaller to fit the same slot; see
         * {@code Editor_dim}.
         */
        EDITOR_LINE_NUMBER(Track.FIXED, 13, FontWeight.NORMAL, Face.CODE),

        /** Heading of an error tooltip in the editor gutter ("Syntax Error"). */
        EDITOR_ISSUE_TITLE(Track.UI, 1.0, FontWeight.BOLD),

        /** The explanation under an error tooltip's heading. */
        EDITOR_ISSUE_TEXT(Track.UI, 1.0, FontWeight.NORMAL),

        /** The "Line 9" caption at the top of an error tooltip. Secondary. */
        EDITOR_ISSUE_CAPTION(Track.SECONDARY, 1.0, FontWeight.NORMAL),

        // ---- footer ---------------------------------------------------------

        /** Footer status text: file name, cursor position, encoding, state. */
        FOOTER_LABEL(Track.UI, 1.0, FontWeight.NORMAL),

        /** Footer error and warning count buttons. Secondary. */
        FOOTER_BUTTON(Track.SECONDARY, 1.0, FontWeight.NORMAL);

        private final Track track;
        private final double value;
        private final FontWeight weight;
        private final Face face;

        Role(Track track, double value, FontWeight weight) {
            this(track, value, weight, Face.UI);
        }

        Role(Track track, double value, FontWeight weight, Face face) {
            this.track = track;
            this.value = value;
            this.weight = weight;
            this.face = face;
        }

        /**
         * @return the size before {@link UIScale} scaling: for UI roles, the
         *         current UI font size (times the secondary ratio for
         *         secondary text); for fixed roles, their own value
         */
        public double designSize() {
            switch (track) {
                case FIXED:
                    return value;
                case SECONDARY:
                    return uiFontSize * SECONDARY_RATIO * value;
                default:
                    return uiFontSize * value;
            }
        }

        /** @return how this role's size is found */
        public Track track() {
            return track;
        }

        /** @return true if this role moves with the UI font size */
        public boolean followsUiFontSize() {
            return track != Track.FIXED;
        }

        /**
         * @return the weight of this role
         */
        public FontWeight weight() {
            return weight;
        }

        /**
         * @return the face this role is drawn in
         */
        public Face face() {
            return face;
        }
    }

    // =====================================================================
    // The UI font size at run time
    // =====================================================================

    /**
     * @return the UI font size in force, a whole number between
     *         {@link #UI_FONT_SIZE_MIN} and {@link #UI_FONT_SIZE_MAX}
     */
    public static double uiFontSize() {
        return uiFontSize;
    }

    /**
     * @return the size stored by the last Apply, or the default when nothing
     *         was stored
     */
    public static double storedUiFontSize() {
        return clampFontSize(readStoredFontSize());
    }

    /**
     * Changes the UI font size for the whole window, at once, without a
     * restart. Nothing is stored here; {@code CustomLayoutConfig.save} does
     * that on Apply.
     *
     * <p>
     * What happens, in order: the text-holding heights in {@link Dim} are
     * recomputed for the new size ({@link Dim#recomputeTextHeights()}), the
     * directory row measurement is dropped, then every listener runs --
     * the generated stylesheet is rebuilt, pinned heights are re-pinned, the
     * explorers re-measure their rows and the Code Bot redraws its text.
     * </p>
     *
     * <p>
     * FX application thread only. A value outside the allowed range is
     * clamped; a fractional one is rounded to a whole pixel.
     * </p>
     *
     * @param size the new size
     * @return true if the size changed
     */
    public static boolean setUiFontSize(double size) {
        double next = clampFontSize(size);
        if (next == uiFontSize) {
            return false;
        }
        uiFontSize = next;
        LINE_CACHE.clear();
        Dim.recomputeTextHeights();
        DirectoryRowMetrics.invalidate();
        for (Runnable listener : FONT_SIZE_LISTENERS) {
            try {
                listener.run();
            } catch (RuntimeException ex) {
                System.err.println("Font size listener failed: " + ex);
            }
        }
        return true;
    }

    /**
     * Registers something to run after the UI font size changes. Listeners run
     * in the order they were added, after {@link Dim} has been recomputed, so
     * every {@code Dim} value they read is already the new one.
     *
     * @param listener the action; kept for the life of the application
     */
    public static void addFontSizeListener(Runnable listener) {
        if (listener != null) {
            FONT_SIZE_LISTENERS.add(listener);
        }
    }

    /**
     * Removes a listener added with {@link #addFontSizeListener}.
     *
     * @param listener the action
     */
    public static void removeFontSizeListener(Runnable listener) {
        FONT_SIZE_LISTENERS.remove(listener);
    }

    /**
     * Clamps to the allowed range and rounds to a whole pixel.
     *
     * @param size any size
     * @return a size the UI accepts
     */
    public static double clampFontSize(double size) {
        if (Double.isNaN(size)) {
            return DEFAULT_UI_FONT_SIZE;
        }
        return Math.max(UI_FONT_SIZE_MIN, Math.min(UI_FONT_SIZE_MAX, Math.round(size)));
    }

    private static double readStoredFontSize() {
        try {
            return Preferences.userRoot().node(FONT_SIZE_PREF_NODE)
                    .getDouble(FONT_SIZE_PREF_KEY, DEFAULT_UI_FONT_SIZE);
        } catch (RuntimeException ex) {
            return DEFAULT_UI_FONT_SIZE;
        }
    }

    private Typography() {
    }

    // =====================================================================
    // Toolkit-level text rendering
    // =====================================================================

    /** System property that keeps JavaFX's sub-pixel glyph positioning on. */
    public static final String SUBPIXEL_PROPERTY = "astra.text.subpixel";

    /**
     * Sets the JavaFX text-rendering switches that must be in place before the
     * toolkit starts. Call it first thing in {@code Launcher.main}, before
     * {@code Application.launch}; called later it does nothing.
     *
     * <p>
     * On Windows it sets {@code prism.subpixeltext=false}. By default JavaFX
     * places each glyph at a fractional pixel position, so the same letter can
     * render crisp in one word and smeared across two pixels in the next --
     * the uneven weights that showed up in the breadcrumb. With the switch off
     * every glyph starts on a whole pixel and identical letters render
     * identically. The cost is spacing rounded to whole pixels, which at UI
     * sizes is not visible. LCD smoothing ({@link #LCD_TEXT}) is unaffected.
     * </p>
     * <p>
     * A value already given on the command line wins. To compare against the
     * JavaFX default, launch with {@code -Dastra.text.subpixel=true}.
     * </p>
     */
    public static void configureTextRendering() {
        if (OS != Os.WINDOWS) {
            return;
        }
        if (Boolean.getBoolean(SUBPIXEL_PROPERTY)) {
            return;
        }
        if (System.getProperty("prism.subpixeltext") == null) {
            System.setProperty("prism.subpixeltext", "false");
        }
    }

    // =====================================================================
    // Families
    // =====================================================================

    /** Resolved lazily, on first use, so the JavaFX toolkit is already up. */
    private static final class Resolved {
        static final Set<String> INSTALLED = installedFamilies();

        static final String UI = pick(System.getProperty(UI_FONT_PROPERTY),
                uiCandidates(), INSTALLED);

        static final String UI_SEMIBOLD = OS == Os.WINDOWS
                && System.getProperty(UI_FONT_PROPERTY) == null
                        ? pick(null, UI_SEMIBOLD_WINDOWS, INSTALLED)
                        : UI;

        static final String CODE = pick(System.getProperty(CODE_FONT_PROPERTY),
                codeCandidates(), INSTALLED);

        static final String PATH = pick(System.getProperty(PATH_FONT_PROPERTY),
                pathCandidates(), INSTALLED);
    }

    /**
     * @return the UI family: Segoe UI on Windows, the platform equivalent
     *         elsewhere
     */
    public static String uiFamily() {
        return Resolved.UI;
    }

    /**
     * The family used for {@link FontWeight#SEMI_BOLD} UI roles. On Windows
     * this is the separate "Segoe UI Semibold" family, because JavaFX treats
     * any weight below bold as regular when it picks a font file. Elsewhere it
     * is {@link #uiFamily()}, and semibold renders as regular.
     *
     * @return the semibold UI family
     */
    public static String uiSemiboldFamily() {
        return Resolved.UI_SEMIBOLD;
    }

    /**
     * @return the monospaced family for editor and CLI text
     */
    public static String codeFamily() {
        return Resolved.CODE;
    }

    /**
     * @return the breadcrumb path family: Tahoma on Windows and macOS, its
     *         nearest installed relative on Linux
     */
    public static String pathFamily() {
        return Resolved.PATH;
    }

    /**
     * The family a role is drawn in.
     *
     * @param role the text role
     * @return the resolved family name
     */
    public static String family(Role role) {
        if (role.face() == Face.CODE) {
            return codeFamily();
        }
        if (role.face() == Face.PATH) {
            return pathFamily();
        }
        if (role.weight() == FontWeight.SEMI_BOLD) {
            return uiSemiboldFamily();
        }
        return uiFamily();
    }

    /**
     * A family name as a quoted CSS value.
     *
     * @param family the family name
     * @return e.g. {@code "Segoe UI"}, quotes included
     */
    public static String familyCss(String family) {
        return "\"" + family.replace("\"", "") + "\"";
    }

    /**
     * One-line summary of the resolved fonts, for the generated stylesheet's
     * header and for logging.
     *
     * @return e.g. {@code WINDOWS -- UI "Segoe UI", path "Tahoma", code "Consolas"}
     */
    public static String describe() {
        return OS + " -- UI " + familyCss(uiFamily())
                + ", path " + familyCss(pathFamily())
                + ", code " + familyCss(codeFamily());
    }

    // =====================================================================
    // Sizes and declarations
    // =====================================================================

    /**
     * The scaled point size of a role.
     *
     * @param role the text role
     * @return the size to render at
     */
    public static double size(Role role) {
        return UIScale.px(role.designSize());
    }

    /**
     * A ready-to-use {@link Font} for a role, for the rare node that has to be
     * styled from Java rather than CSS.
     *
     * @param role the text role
     * @return the font
     */
    public static Font font(Role role) {
        return Font.font(family(role), role.weight(), FontPosture.REGULAR, size(role));
    }

    /**
     * The CSS declarations for a role, ready to drop inside a rule body.
     *
     * <p>
     * A family is emitted only when the role's family differs from the one
     * {@code .root} provides (code and path roles, and semibold on Windows); plain UI
     * roles inherit it.
     * </p>
     *
     * @param role the text role
     * @return e.g. {@code -fx-font-size: 12px; -fx-font-weight: bold;}
     */
    public static String css(Role role) {
        StringBuilder out = new StringBuilder(96);
        String family = family(role);
        if (!family.equals(uiFamily())) {
            out.append("-fx-font-family: ").append(familyCss(family)).append("; ");
        }
        out.append("-fx-font-size: ").append(UIScale.fmt(size(role))).append("px;")
                .append(" -fx-font-weight: ").append(weightCss(role.weight())).append(";");
        return out.toString();
    }

    /**
     * The CSS declarations for a role, as an inline {@code setStyle} fragment.
     * Prefer {@link #css} inside a stylesheet; inline styles beat stylesheets
     * and make a control impossible to re-theme.
     *
     * @param role the text role
     * @return the same text as {@link #css}
     */
    public static String inline(Role role) {
        return css(role);
    }

    /**
     * Height of one line of a role's text, rounded up to a whole pixel. What
     * the single-line text boxes in {@link Dim} are built from.
     *
     * @param role the text role
     * @return the line height in pixels
     */
    public static double lineHeight(Role role) {
        return Math.ceil(textHeight(role, 1.0));
    }

    /**
     * {@link #lineHeight(Role)} for a role drawn at {@code scale} times its
     * size (the ribbon tab's label, for one).
     *
     * @param role  the text role
     * @param scale a multiplier on the role's size
     * @return the line height in pixels, rounded up
     */
    public static double lineHeight(Role role, double scale) {
        return Math.ceil(textHeight(role, scale));
    }

    /**
     * Height of one line of a role's text, unrounded. Boxes that stack several
     * lines add these and round once, the way a laid-out {@code VBox} would.
     *
     * @param role  the text role
     * @param scale a multiplier on the role's size
     * @return the line height in pixels
     */
    public static double textHeight(Role role, double scale) {
        double size = size(role) * scale;
        String family = family(role);
        FontWeight weight = role.weight();
        String key = family + "|" + weight + "|" + size;
        Double cached = LINE_CACHE.get(key);
        if (cached != null) {
            return cached;
        }
        double measured = measureLine(family, weight, size);
        if (measured <= 0) {
            // Toolkit not running yet: estimate, and do not cache the estimate.
            return size * LINE_HEIGHT_FALLBACK;
        }
        LINE_CACHE.put(key, measured);
        return measured;
    }

    private static double measureLine(String family, FontWeight weight, double size) {
        try {
            Text probe = new Text("\u00c1gjpqy|");
            probe.setFont(Font.font(family, weight, FontPosture.REGULAR, size));
            double h = probe.getLayoutBounds().getHeight();
            if (h > 0) {
                return h;
            }
        } catch (RuntimeException | Error ex) {
            // Toolkit not running yet: the caller estimates.
        }
        return -1;
    }

    // =====================================================================
    // Internals
    // =====================================================================

    private static List<String> uiCandidates() {
        switch (OS) {
            case WINDOWS:
                return UI_WINDOWS;
            case MAC:
                return UI_MAC;
            default:
                return UI_LINUX;
        }
    }

    private static List<String> pathCandidates() {
        switch (OS) {
            case WINDOWS:
                return PATH_WINDOWS;
            case MAC:
                return PATH_MAC;
            default:
                return PATH_LINUX;
        }
    }

    private static List<String> codeCandidates() {
        switch (OS) {
            case WINDOWS:
                return CODE_WINDOWS;
            case MAC:
                return CODE_MAC;
            default:
                return CODE_LINUX;
        }
    }

    /**
     * First installed candidate, or the override if one is given. With no
     * installed-font list (toolkit not started) the first candidate is
     * returned unchecked.
     */
    private static String pick(String override, List<String> candidates, Set<String> installed) {
        if (override != null && !override.isBlank()) {
            return override.trim();
        }
        if (installed.isEmpty()) {
            return candidates.get(0);
        }
        for (String family : candidates) {
            if (LOGICAL.contains(family) || installed.contains(family)) {
                return family;
            }
        }
        return candidates.get(candidates.size() - 1);
    }

    private static Set<String> installedFamilies() {
        try {
            return new HashSet<>(Font.getFamilies());
        } catch (RuntimeException ex) {
            return Set.of();
        }
    }

    private static String weightCss(FontWeight weight) {
        if (weight == null) {
            return "normal";
        }
        switch (weight) {
            case BOLD:
            case EXTRA_BOLD:
            case BLACK:
                return "bold";
            case LIGHT:
            case EXTRA_LIGHT:
            case THIN:
                return "light";
            case SEMI_BOLD:
                return "600";
            default:
                return "normal";
        }
    }
}
