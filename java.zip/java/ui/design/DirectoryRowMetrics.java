package ui.design;

import javafx.scene.text.Font;
import javafx.scene.text.Text;

/**
 * Font and row height of the directory explorer, in one place.
 *
 * <h3>Font</h3>
 * <p>
 * The tree's rows, its column captions and the Info unit menu use
 * {@link Typography.Role#DIRECTORY_ROW}: the one UI font size, like the
 * breadcrumb, the Variable Explorer and every other panel. There is no
 * separate directory size to drift out of step.
 * </p>
 *
 * <h3>Row height</h3>
 * <p>
 * The row height is not a fixed number. It is measured from the font actually
 * in use: the height of a line that contains both ascenders and descenders
 * ({@code Á}, {@code g}, {@code j}, {@code y}), or the file icon, or the repo
 * dot, whichever is tallest, plus {@link #ROW_PAD_V} above and below. That is
 * the smallest height at which nothing in a row can touch the row next to it,
 * and it stays correct if the font role or the icon size is changed later.
 * </p>
 * <p>
 * Both {@link DesignStylesheet} ({@code -fx-cell-size}) and the tree builder
 * ({@code setFixedCellSize}) read {@link #rowHeight()}, so CSS and Java always
 * agree. The cells themselves carry no vertical padding; the whole gap is this
 * one value.
 * </p>
 *
 * <p>
 * Measurement needs the JavaFX toolkit, which is running by the time either
 * caller asks. The result is cached, and dropped by
 * {@link Typography#setUiFontSize} when the Font Size setting changes.
 * </p>
 */
public final class DirectoryRowMetrics {

    /** The font role of the rows: the one UI font size. */
    public static final Typography.Role FONT_ROLE = Typography.Role.DIRECTORY_ROW;

    /**
     * Space above and below the tallest item in a row, in pixels. 2 gives a
     * compact list with a clear separation between rows; 1 is the tightest
     * that still keeps the selection highlight off the text.
     */
    public static final double ROW_PAD_V = 2;

    /** Sample with the tallest ascender and the deepest descenders. */
    private static final String PROBE_TEXT = "ÁÇgjpqy|";

    private static double cachedTextHeight = -1;
    private static double cachedRowHeight = -1;

    private DirectoryRowMetrics() {
    }

    /**
     * @return the CSS declarations for the directory font (the breadcrumb role)
     */
    public static String fontCss() {
        return Typography.css(FONT_ROLE);
    }

    /**
     * @return the directory font as a {@link Font}, for measuring
     */
    public static Font font() {
        return Font.font(Typography.uiFamily(), Typography.size(FONT_ROLE));
    }

    /**
     * @return the height of one line of directory text, rounded up to a whole
     *         pixel
     */
    public static synchronized double textHeight() {
        if (cachedTextHeight < 0) {
            Text probe = new Text(PROBE_TEXT);
            probe.setFont(font());
            cachedTextHeight = Math.ceil(probe.getLayoutBounds().getHeight());
        }
        return cachedTextHeight;
    }

    /**
     * @return the smallest row height at which no row content can overlap a
     *         neighbouring row
     */
    public static synchronized double rowHeight() {
        if (cachedRowHeight < 0) {
            double content = Math.max(textHeight(),
                    Math.max(Dim.Directory.FILE_ICON_SIZE, Dim.Directory.REPO_DOT_SIZE));
            cachedRowHeight = Math.ceil(content + 2 * ROW_PAD_V);
        }
        return cachedRowHeight;
    }

    /**
     * Forgets the cached measurements. {@link Typography#setUiFontSize} calls
     * it before the stylesheet is rebuilt.
     */
    public static synchronized void invalidate() {
        cachedTextHeight = -1;
        cachedRowHeight = -1;
    }
}
