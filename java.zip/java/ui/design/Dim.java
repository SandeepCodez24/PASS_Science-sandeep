package ui.design;

import ui.design.section_dims.CompareButton_dim;
import ui.design.section_dims.Explorer_dim;
import ui.design.section_dims.Footer_dim;
import ui.design.section_dims.HomeBand_dim;
import ui.design.section_dims.Icons_dim;
import ui.design.section_dims.QuickBar_dim;
import ui.design.section_dims.Rail_dim;
import ui.design.section_dims.Readout_dim;
import ui.design.section_dims.RibbonBar_dim;
import ui.design.section_dims.SignalBand_dim;
import ui.design.section_dims.SplitButton_dim;
import ui.design.section_dims.Split_dim;
import ui.design.section_dims.TitleBar_dim;
import ui.design.section_dims.ToolBand_dim;
import ui.design.section_dims.Window_dim;

/**
 * The single entry point to every dimension in the application.
 *
 * <h3>What this class is</h3>
 * <p>
 * A map, not a store. Every constant physically lives in
 * {@code ui.design.section_dims}, one file per region, so that adding a region
 * means adding a file rather than growing an 800-line class. This class gives
 * all of them one front door, so calling code writes
 * {@code Dim.ToolBand.ITEM_HEIGHT} and never has to know or care which file it
 * came from.
 * </p>
 *
 * <h3>How it works</h3>
 * <p>
 * Each nested class extends its region file, so it inherits that file's public
 * constants and helper methods. {@code Dim.Footer.PAD_V} resolves to
 * {@code Footer_dim.PAD_V}, {@code Dim.TitleBar.padding()} to
 * {@code TitleBar_dim.padding()}, and so on. Nothing is copied, so there is no
 * second place for a value to drift out of step -- which is the whole point of
 * the design layer.
 * </p>
 * <p>
 * The alternative was to restate every constant here as
 * {@code public static final double PAD_V = Footer_dim.PAD_V;}. That is roughly
 * two hundred lines whose only job is to name each value a second time, and a
 * line that can be forgotten when a region file gains a constant. Inheritance
 * has neither problem.
 * </p>
 *
 * <h3>Two consequences worth knowing</h3>
 * <ol>
 * <li>The region files are no longer {@code final} and their constructors are
 * {@code protected} rather than {@code private}, because a final class cannot
 * be extended. They are still not instantiable from outside the package in any
 * meaningful way, and there is no reason to subclass them other than this.</li>
 * <li>Some IDE inspections flag static access through a subclass name
 * ("static member accessed via inheritance"). That warning is about accidental
 * inheritance; here it is the mechanism, so switch it off for this class if it
 * gets noisy.</li>
 * </ol>
 *
 * <h3>Adding a region</h3>
 * <ol>
 * <li>Create {@code section_dims/NewThing_dim.java} following the rules in that
 * package's {@code package-info}.</li>
 * <li>Add one nested class here: {@code public static final class NewThing
 * extends NewThing_dim { }}.</li>
 * <li>Emit its CSS from {@link DesignStylesheet} if any of it needs to reach a
 * stylesheet.</li>
 * </ol>
 *
 * <h3>Where the rest of the design layer lives</h3>
 * <ul>
 * <li>{@link Typography} -- font families, sizes and weights, by role.</li>
 * <li>{@link UIScale} -- the one global multiplier applied to everything
 * here.</li>
 * <li>{@link DesignStylesheet} -- turns both into the generated stylesheet.</li>
 * <li>{@code themes/light.css}, {@code themes/dark.css} -- colours, and only
 * colours.</li>
 * </ul>
 */
public final class Dim {

    private Dim() {
    }

    // =====================================================================
    // WINDOW AND LAYOUT
    // =====================================================================

    /** The top-level application window. See {@link Window_dim}. */
    public static final class Window extends Window_dim {
        private Window() {
        }
    }

    /** Split-pane divider positions. See {@link Split_dim}. */
    public static final class Split extends Split_dim {
        private Split() {
        }
    }

    /** Fallback raster icon sizes. See {@link Icons_dim}. */
    public static final class Icons extends Icons_dim {
        private Icons() {
        }
    }

    // =====================================================================
    // PANELS
    // =====================================================================

    /** File Explorer and Variable Explorer panels. See {@link Explorer_dim}. */
    public static final class Explorer extends Explorer_dim {
        private Explorer() {
        }
    }

    /** Panel title strips. See {@link TitleBar_dim}. */
    public static final class TitleBar extends TitleBar_dim {
        private TitleBar() {
        }
    }

    /** The rail a collapsed panel shows. See {@link Rail_dim}. */
    public static final class Rail extends Rail_dim {
        private Rail() {
        }
    }

    // =====================================================================
    // RIBBON -- Row 1
    // =====================================================================

    /** The tab strip, search box and action cluster. See {@link RibbonBar_dim}. */
    public static final class RibbonBar extends RibbonBar_dim {
        private RibbonBar() {
        }
    }

    // =====================================================================
    // RIBBON -- Row 2
    // =====================================================================

    /**
     * The compartment band shared by every tab. See {@link ToolBand_dim}.
     *
     * <p>
     * The per-band ratios and the three custom controls hang off this class as
     * nested classes of their own, so {@code Dim.ToolBand.Home.UNITS_FILES} and
     * {@code Dim.ToolBand.Compare.ZONE_HEIGHT} keep working exactly as before.
     * </p>
     */
    public static final class ToolBand extends ToolBand_dim {

        private ToolBand() {
        }

        /** Home band unit ratios. See {@link HomeBand_dim}. */
        public static final class Home extends HomeBand_dim {
            private Home() {
            }
        }

        /** Signals band unit ratios. See {@link SignalBand_dim}. */
        public static final class Signals extends SignalBand_dim {
            private Signals() {
            }
        }

        /** The Files split button. See {@link SplitButton_dim}. */
        public static final class SplitButton extends SplitButton_dim {
            private SplitButton() {
            }
        }

        /** The Signals compare control. See {@link CompareButton_dim}. */
        public static final class Compare extends CompareButton_dim {
            private Compare() {
            }
        }

        /** The Analysis readouts. See {@link Readout_dim}. */
        public static final class Readout extends Readout_dim {
            private Readout() {
            }
        }
    }

    // =====================================================================
    // NAVIGATION AND FOOTER
    // =====================================================================

    /** Navigation arrows and the breadcrumb path. See {@link QuickBar_dim}. */
    public static final class QuickBar extends QuickBar_dim {
        private QuickBar() {
        }
    }

    /** The status bar. See {@link Footer_dim}. */
    public static final class Footer extends Footer_dim {
        private Footer() {
        }
    }
}
