package ui.design;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.DoubleSupplier;

import javafx.scene.layout.Region;

/**
 * Pins a node's height to a {@link Dim} value that follows the UI font size,
 * and keeps it pinned when the size changes.
 *
 * <h3>Why this exists</h3>
 * <p>
 * Code that used to write
 * </p>
 *
 * <pre>
 *   button.setMinHeight(Dim.ToolBand.ITEM_HEIGHT);
 *   button.setPrefHeight(Dim.ToolBand.ITEM_HEIGHT);
 *   button.setMaxHeight(Dim.ToolBand.ITEM_HEIGHT);
 * </pre>
 *
 * <p>
 * copied the height once, when the node was built. Now that the Font Size
 * setting can change {@code ITEM_HEIGHT} while the IDE is running, the copy
 * would go stale. Writing
 * </p>
 *
 * <pre>
 *   LiveHeight.pin(button, () -&gt; Dim.ToolBand.ITEM_HEIGHT);
 * </pre>
 *
 * <p>
 * pins the node now and again after every change, reading the value afresh
 * each time.
 * </p>
 *
 * <h3>Cost</h3>
 * <p>
 * Nothing while the size stays put: no listener, no binding, nothing runs. On
 * a change, one pass over the registered nodes -- a few dozen -- setting three
 * numbers each. Nodes are held weakly, so a pinned node that leaves the scene
 * and is collected drops out on its own.
 * </p>
 */
public final class LiveHeight {

    /** How much of the height is pinned. */
    private enum Mode {
        /** min, pref and max. */
        EXACT,
        /** min and pref; the node may still grow. */
        AT_LEAST,
        /** pref only. */
        PREF
    }

    private static final class Entry {
        final WeakReference<Region> region;
        final DoubleSupplier height;
        final Mode mode;

        Entry(Region region, DoubleSupplier height, Mode mode) {
            this.region = new WeakReference<>(region);
            this.height = height;
            this.mode = mode;
        }
    }

    private static final List<Entry> ENTRIES = new ArrayList<>();

    static {
        Typography.addFontSizeListener(LiveHeight::repinAll);
    }

    private LiveHeight() {
    }

    /**
     * Sets min, pref and max height to the value, now and after every change
     * of the UI font size.
     *
     * @param region the node
     * @param height reads the current value, e.g. {@code () -> Dim.ToolBand.ITEM_HEIGHT}
     */
    public static void pin(Region region, DoubleSupplier height) {
        register(region, height, Mode.EXACT);
    }

    /**
     * Sets min and pref height to the value, now and after every change. The
     * maximum is left alone.
     *
     * @param region the node
     * @param height reads the current value
     */
    public static void pinAtLeast(Region region, DoubleSupplier height) {
        register(region, height, Mode.AT_LEAST);
    }

    /**
     * Sets pref height to the value, now and after every change.
     *
     * @param region the node
     * @param height reads the current value
     */
    public static void pinPref(Region region, DoubleSupplier height) {
        register(region, height, Mode.PREF);
    }

    private static void register(Region region, DoubleSupplier height, Mode mode) {
        if (region == null || height == null) {
            return;
        }
        Entry entry = new Entry(region, height, mode);
        apply(region, entry);
        ENTRIES.add(entry);
    }

    private static void repinAll() {
        Iterator<Entry> it = ENTRIES.iterator();
        while (it.hasNext()) {
            Entry entry = it.next();
            Region region = entry.region.get();
            if (region == null) {
                it.remove();
            } else {
                apply(region, entry);
            }
        }
    }

    private static void apply(Region region, Entry entry) {
        double h = entry.height.getAsDouble();
        switch (entry.mode) {
            case EXACT:
                region.setMinHeight(h);
                region.setPrefHeight(h);
                region.setMaxHeight(h);
                break;
            case AT_LEAST:
                region.setMinHeight(h);
                region.setPrefHeight(h);
                break;
            default:
                region.setPrefHeight(h);
                break;
        }
    }
}
