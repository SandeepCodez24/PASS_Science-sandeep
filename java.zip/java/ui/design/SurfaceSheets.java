package ui.design;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.WeakChangeListener;
import javafx.collections.ListChangeListener;
import javafx.scene.Parent;
import javafx.scene.Scene;
import ui.managers.ThemeManager;

/**
 * Keeps the shared palette and the shared surfaces sheet on a scene, directly
 * after the base theme sheet:
 *
 * <pre>
 *   ... light.css | palette_light.css | surfaces.css | (everything else) ...
 *   ... dark.css  | palette_dark.css  | surfaces.css | (everything else) ...
 * </pre>
 *
 * <h3>What the two sheets are</h3>
 * <ul>
 * <li>{@code themes/shared/palette_light.css} / {@code palette_dark.css} --
 * every colour the sub-windows share, once, as a named token on
 * {@code .root} ({@code -astra-panel-bg}, {@code -astra-title-inactive},
 * {@code -astra-scroll-thumb}, ...). Plus the scroll-bar arrow images, which
 * cannot be tokens.</li>
 * <li>{@code themes/shared/surfaces.css} -- one file for both themes: the
 * rules that make the seven sub-windows one family (title strips, panel
 * bodies, column sub-headers, scroll bars, dividers, guarding bars, footer).
 * It names tokens only, so it follows the theme by itself.</li>
 * </ul>
 *
 * <h3>Why directly after the base theme</h3>
 * <p>
 * Later sheets win ties in JavaFX. Sitting right after {@code light.css} /
 * {@code dark.css}, the surfaces sheet beats the base theme, while the editor
 * sheet, the text-colour sheet, the feature sheets and the Custom layout's
 * sheet -- all added after the base theme -- still beat it. That keeps the
 * Custom layout able to recolour the panels. {@link DesignStylesheet} stays
 * last, as before; it carries geometry only, so the two never collide.
 * </p>
 * <p>
 * {@code ThemeManager} swaps the base sheet by removing it and appending the
 * new one, which moves it to the end of the list. The listener here then puts
 * the block back directly after it. It acts only when the block is out of
 * place, so it settles after one round and never fights {@link RibbonTheme},
 * {@link ThemedSheetPair} or {@link DesignStylesheet}, none of which care
 * where in front of them the block sits.
 * </p>
 *
 * <h3>Secondary windows</h3>
 * <p>
 * A window with a scene of its own (the separate Variable Explorer window, a
 * dialog) has no {@code light.css} / {@code dark.css} to sit behind. Calling
 * {@link #install(Scene)} on it still works: the block goes to the front of
 * that scene's list, and the theme is read from {@link ThemeManager} and
 * followed through {@link ThemeManager#themeProperty()}.
 * </p>
 * <p>
 * The separate Variable Explorer window copies the main scene's list, so it
 * needs nothing extra.
 * </p>
 *
 * <h3>Popups</h3>
 * <p>
 * A {@code javafx.stage.Popup} (the suggestion list) is a window whose
 * content is not under a node matching {@code .root}, so the palette's
 * tokens would not resolve in it. {@link #attach(Parent)} puts the palette,
 * the surfaces sheet and the generated geometry sheet on the popup's content
 * node itself, adds {@link #PALETTE_CLASS} (the palette declares its tokens
 * on that class as well as on {@code .root}), and swaps the palette when the
 * theme changes.
 * </p>
 */
public final class SurfaceSheets {

    /** Classpath location of the light palette. */
    public static final String PALETTE_LIGHT = "/themes/shared/palette_light.css";

    /** Classpath location of the dark palette. */
    public static final String PALETTE_DARK = "/themes/shared/palette_dark.css";

    /** Classpath location of the theme-independent surfaces sheet. */
    public static final String SURFACES = "/themes/shared/surfaces.css";

    /**
     * Style class the palettes declare their tokens on, besides {@code .root}.
     * Given to a popup's content by {@link #attach(Parent)}.
     */
    public static final String PALETTE_CLASS = "astra-palette";

    private static final String LIGHT_BASE = "light.css";
    private static final String DARK_BASE = "dark.css";

    /** Scene property key: one install per scene. */
    private static final String KEY = SurfaceSheets.class.getName();

    /** Scene property key holding the theme listener, so it lives as long as the scene. */
    private static final String THEME_LISTENER_KEY = KEY + ".themeListener";

    private static String lightUri;
    private static String darkUri;
    private static String surfacesUri;
    private static boolean resolved;
    private static boolean syncing;

    private SurfaceSheets() {
    }

    /**
     * Attaches the palette and surfaces sheets and keeps them in place for the
     * life of the scene. Safe to call more than once.
     *
     * @param scene the scene
     */
    public static void install(Scene scene) {
        if (scene == null) {
            return;
        }
        resolve();
        if (lightUri == null && darkUri == null && surfacesUri == null) {
            return;
        }
        if (scene.getProperties().containsKey(KEY)) {
            sync(scene);
            return;
        }
        scene.getProperties().put(KEY, Boolean.TRUE);

        sync(scene);

        scene.getStylesheets().addListener((ListChangeListener<String>) change -> {
            if (syncing) {
                return;
            }
            Platform.runLater(() -> sync(scene));
        });

        // Only matters for a scene with no base theme sheet, which cannot
        // tell the theme from its own list. The listener is held by the
        // scene and registered weakly, so a closed window is not kept alive.
        ChangeListener<String> onTheme = (obs, was, now) -> Platform.runLater(() -> sync(scene));
        scene.getProperties().put(THEME_LISTENER_KEY, onTheme);
        ThemeManager.themeProperty().addListener(new WeakChangeListener<>(onTheme));
    }

    /**
     * Puts the palette, the surfaces sheet and the generated geometry sheet
     * on one node, for content that lives in a window without the main
     * scene's sheets -- a {@code Popup}. Keeps the palette in step with the
     * theme for as long as the node lives. Safe to call more than once.
     *
     * @param node the popup's content root
     */
    public static void attach(Parent node) {
        if (node == null) {
            return;
        }
        resolve();
        if (!node.getStyleClass().contains(PALETTE_CLASS)) {
            node.getStyleClass().add(PALETTE_CLASS);
        }
        applyTo(node);
        if (node.getProperties().containsKey(THEME_LISTENER_KEY)) {
            return;
        }
        ChangeListener<String> onTheme = (obs, was, now) -> applyTo(node);
        node.getProperties().put(THEME_LISTENER_KEY, onTheme);
        ThemeManager.themeProperty().addListener(new WeakChangeListener<>(onTheme));
    }

    /** Palette for the active theme, then surfaces, then geometry, at the front. */
    private static void applyTo(Parent node) {
        List<String> sheets = node.getStylesheets();
        boolean dark = "dark".equals(ThemeManager.getActiveTheme());
        String palette = dark ? darkUri : lightUri;
        String other = dark ? lightUri : darkUri;

        List<String> block = new ArrayList<>(3);
        if (palette != null) {
            block.add(palette);
        }
        if (surfacesUri != null) {
            block.add(surfacesUri);
        }
        String geometry = DesignStylesheet.sheetUri();
        if (geometry != null) {
            block.add(geometry);
        }

        if (inPlace(sheets, 0, block) && (other == null || !sheets.contains(other))) {
            return;
        }
        if (other != null) {
            sheets.removeIf(other::equals);
        }
        sheets.removeAll(block);
        sheets.addAll(0, block);
    }

    // =====================================================================
    // Internals
    // =====================================================================

    private static synchronized void resolve() {
        if (resolved) {
            return;
        }
        resolved = true;
        lightUri = toUri(PALETTE_LIGHT);
        darkUri = toUri(PALETTE_DARK);
        surfacesUri = toUri(SURFACES);
    }

    private static String toUri(String resource) {
        URL url = SurfaceSheets.class.getResource(resource);
        if (url == null) {
            System.err.println("Shared stylesheet not on the classpath: " + resource
                    + " -- expected at src/main/resources" + resource);
            return null;
        }
        return url.toExternalForm();
    }

    /**
     * Puts the block (palette, then surfaces) directly after the base theme,
     * or at the front when there is no base theme. Does nothing if it is
     * already there and the other palette is absent.
     */
    private static void sync(Scene scene) {
        List<String> sheets = scene.getStylesheets();

        int base = baseIndex(sheets);
        boolean dark = base >= 0
                ? DARK_BASE.equalsIgnoreCase(fileName(sheets.get(base)))
                : "dark".equals(ThemeManager.getActiveTheme());

        String palette = dark ? darkUri : lightUri;
        String other = dark ? lightUri : darkUri;

        List<String> block = new ArrayList<>(2);
        if (palette != null) {
            block.add(palette);
        }
        if (surfacesUri != null) {
            block.add(surfacesUri);
        }
        if (block.isEmpty()) {
            return;
        }

        if (inPlace(sheets, base + 1, block) && (other == null || !sheets.contains(other))) {
            return;
        }

        syncing = true;
        try {
            if (other != null) {
                sheets.removeIf(other::equals);
            }
            sheets.removeAll(block);
            int at = baseIndex(sheets) + 1;
            sheets.addAll(at, block);
        } finally {
            syncing = false;
        }
    }

    /** True if {@code block} sits at {@code start} and nowhere else. */
    private static boolean inPlace(List<String> sheets, int start, List<String> block) {
        if (start + block.size() > sheets.size()) {
            return false;
        }
        for (int i = 0; i < block.size(); i++) {
            String uri = block.get(i);
            if (!uri.equals(sheets.get(start + i))) {
                return false;
            }
            if (sheets.indexOf(uri) != sheets.lastIndexOf(uri)) {
                return false;
            }
        }
        return true;
    }

    private static int baseIndex(List<String> sheets) {
        for (int i = 0; i < sheets.size(); i++) {
            String name = fileName(sheets.get(i));
            if (LIGHT_BASE.equalsIgnoreCase(name) || DARK_BASE.equalsIgnoreCase(name)) {
                return i;
            }
        }
        return -1;
    }

    /**
     * The last path segment, matched whole, so {@code editor_dark.css},
     * {@code ribbon_dark.css} and {@code palette_dark.css} are never mistaken
     * for the base theme.
     */
    private static String fileName(String uri) {
        if (uri == null) {
            return "";
        }
        int slash = uri.lastIndexOf('/');
        return (slash >= 0) ? uri.substring(slash + 1) : uri;
    }
}
