package ui.design;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;

import javafx.application.Platform;
import javafx.collections.ListChangeListener;
import javafx.scene.Scene;

/**
 * Turns {@link Dim} and {@link Typography} into a real stylesheet and keeps it
 * attached to the scene as the last sheet in the list.
 *
 * <h3>Why generate CSS at all</h3>
 * <p>
 * JavaFX CSS has no numeric variables -- looked-up values work for colours
 * only. Without this class every padding and font size would have to be written
 * twice: once in {@link Dim} for the Java side and once by hand in
 * {@code light.css} and {@code dark.css}. The ribbon showed exactly what that
 * costs: {@code RibbonLayout.TOOLBAR_H_INSET = 20} had to match
 * {@code -fx-padding: 4 10 4 10} in two stylesheets, and three comments warned
 * about keeping them in step. Now one constant produces both.
 * </p>
 *
 * <h3>Why it must be last</h3>
 * <p>
 * {@code ThemeManager} swaps {@code light.css} for {@code dark.css} at runtime
 * and then appends an editor stylesheet. Later sheets win ties in JavaFX, so
 * this class watches the list and moves itself back to the end whenever it
 * changes. That also makes the migration safe to do gradually: a dimension left
 * behind in a theme file is simply overridden until it is deleted.
 * </p>
 *
 * <h3>The ribbon colour sheets</h3>
 * <p>
 * {@link #install} also installs {@link RibbonTheme}, which keeps
 * {@code themes/ribbon/ribbon_light.css} or {@code ribbon_dark.css} attached
 * alongside whichever base theme is active. The ribbon's colours were split out
 * of {@code light.css} / {@code dark.css} because both files had grown past the
 * point where the ribbon block could be found in them. Installing it from here
 * means no other file has to know the ribbon sheets exist.
 * </p>
 *
 * <h3>Reading the generated CSS</h3>
 * <p>
 * Launch with {@code -Dastra.design.dumpCss=true} and the exact stylesheet in
 * use is written to {@code astra-design.css} in the working directory, with a
 * comment header per region.
 * </p>
 */
public final class DesignStylesheet {

    /** Set to {@code true} to write the generated sheet to disk on startup. */
    public static final String DUMP_PROPERTY = "astra.design.dumpCss";

    private static String cachedUri;
    private static boolean reordering = false;

    private DesignStylesheet() {
    }

    /**
     * Attaches the generated sheet to a scene and keeps it at the end of the
     * stylesheet list for the life of the scene. Also installs the ribbon
     * colour sheets.
     *
     * @param scene the application scene
     */
    public static void install(Scene scene) {
        if (scene == null) {
            return;
        }

        // Before the generated sheet, so the ribbon colours sit under the
        // generated geometry rather than over it.
        RibbonTheme.install(scene);

        String uri = uri();
        if (uri == null) {
            return;
        }
        if (!scene.getStylesheets().contains(uri)) {
            scene.getStylesheets().add(uri);
        }
        scene.getStylesheets().addListener((ListChangeListener<String>) change -> {
            if (reordering) {
                return;
            }
            Platform.runLater(() -> moveToEnd(scene));
        });
    }

    /**
     * Rebuilds the sheet and re-attaches it. Only needed if a design value is
     * ever changed at runtime; the normal path is {@link #install}.
     *
     * @param scene the application scene
     */
    public static void refresh(Scene scene) {
        if (scene == null) {
            return;
        }
        String old = cachedUri;
        cachedUri = null;
        if (old != null) {
            scene.getStylesheets().remove(old);
        }
        install(scene);
    }

    /**
     * The generated stylesheet as text. Exposed for debugging and tests.
     *
     * @return the CSS source
     */
    public static String css() {
        StringBuilder out = new StringBuilder(8192);

        out.append("/* =====================================================================\n")
                .append("   GENERATED -- do not edit\n")
                .append("   Produced by ui.design.DesignStylesheet from Dim and Typography.\n")
                .append("   Scale factor in use: ").append(UIScale.fmt(UIScale.factor())).append("\n")
                .append("   Colours are NOT here: they stay in themes/light.css, dark.css and\n")
                .append("   themes/ribbon/ribbon_light.css, ribbon_dark.css.\n")
                .append("   ===================================================================== */\n\n");

        root(out);
        titleBar(out);
        rail(out);
        ribbonBar(out);
        toolBand(out);
        splitButton(out);
        compareButton(out);
        readout(out);
        quickBar(out);
        footer(out);

        return out.toString();
    }

    // =====================================================================
    // Region emitters
    // =====================================================================

    private static void root(StringBuilder out) {
        header(out, "ROOT -- the size everything else inherits");
        out.append(".root {\n")
                .append("    -fx-font-family: ").append(Typography.FAMILY_CSS).append(";\n")
                .append(decl("-fx-font-size", Typography.size(Typography.Role.BASE), "px"))
                .append("}\n\n");
    }

    private static void titleBar(StringBuilder out) {
        header(out, "TITLE BAR -- panel title strips");
        out.append(".panel-title-bar {\n")
                .append(pad(Dim.TitleBar.PAD_TOP, Dim.TitleBar.PAD_RIGHT,
                        Dim.TitleBar.PAD_BOTTOM, Dim.TitleBar.PAD_LEFT))
                .append(decl("-fx-spacing", Dim.TitleBar.CONTENT_SPACING))
                .append("    -fx-border-width: 0 0 ")
                .append(UIScale.fmt(Dim.TitleBar.BOTTOM_BORDER)).append(" 0;\n")
                .append("}\n\n");

        out.append(".panel-title-label {\n    ")
                .append(Typography.css(Typography.Role.PANEL_TITLE)).append("\n}\n\n");

        out.append(".panel-title-button {\n")
                .append(decl("-fx-padding", Dim.TitleBar.GLYPH_BUTTON_PADDING))
                .append(decl("-fx-background-radius", Dim.TitleBar.GLYPH_BUTTON_RADIUS))
                .append(box(Dim.TitleBar.GLYPH_BUTTON_SIZE))
                .append("}\n\n");
    }

    private static void rail(StringBuilder out) {
        header(out, "RAIL -- collapsed panel strip");
        out.append(".panel-rail {\n")
                .append(pad(Dim.Rail.PAD_TOP, Dim.Rail.PAD_RIGHT,
                        Dim.Rail.PAD_BOTTOM, Dim.Rail.PAD_LEFT))
                .append(decl("-fx-spacing", Dim.Explorer.RAIL_SPACING))
                .append("    -fx-border-width: 0 ")
                .append(UIScale.fmt(Dim.Rail.SIDE_BORDER)).append(" 0 0;\n")
                .append("}\n\n");

        out.append(".panel-rail-label {\n    ")
                .append(Typography.css(Typography.Role.PANEL_RAIL)).append("\n}\n\n");
    }

    /**
     * Row 1.
     *
     * <p>
     * Note what this block does <b>not</b> do: it does not produce the gap
     * above the tab. That is an {@code HBox} margin set in
     * {@code ToolbarRibbon}, because margins are not styleable and therefore
     * cannot be overridden by Modena, by a theme file, or by anything else in
     * the cascade. Three CSS-based attempts at that gap failed for three
     * different reasons; the notes in {@code RibbonBar_dim} list them.
     * </p>
     * <p>
     * What this block does do is keep out of the way: {@code .ribbon-tab-box}
     * gets an explicit zero padding, and {@code .ribbon-tab} gets no height
     * property of any kind so the tab is free to fill whatever its margin
     * leaves. If you add {@code -fx-pref-height} to {@code .ribbon-tab} or a
     * padding to the block, you are reintroducing a failure that has already
     * cost several rounds.
     * </p>
     * <p>
     * The tab's padding is asymmetric to finish the job: the tab starts one gap
     * below the strip's top but ends flush with its bottom, so its own centre
     * is half a gap low. {@code TAB_PAD_BOTTOM} pays that gap back and puts the
     * label -- and only the label -- on the strip's centre line.
     * </p>
     * <p>
     * The zero insets are not vestigial: they cancel Modena's
     * {@code 0 0 -1 0, 0, 1, 2} on {@code .toggle-button}, which would
     * otherwise inset the fill a pixel or two on three sides and stop the
     * bottom edge meeting the band cleanly.
     * </p>
     * <p>
     * The label's font is emitted twice on purpose: {@code Typography.css} for
     * the role, then {@code TAB_FONT_SCALE} and the weight after it, overriding
     * within the same rule.
     * </p>
     * <p>
     * Collapsed: the block takes the same padding at the bottom, so the tab is
     * centred in the strip with navy all round, the label's padding goes back
     * to symmetric, and the border and radius close up on all four sides.
     * </p>
     */
    private static void ribbonBar(StringBuilder out) {
        header(out, "RIBBON BAR -- Row 1: tabs, search box, action cluster");

        final String radius = UIScale.fmt(Dim.RibbonBar.TAB_RADIUS);
        final String border = UIScale.fmt(Dim.RibbonBar.TAB_BORDER);
        // Qualified with the strip's own class so the collapsed rules always
        // out-specify the open ones, whatever JavaFX makes of a bare descendant
        // selector against a pseudo-class.
        final String collapsed = ".ribbon-tab-bar." + Dim.RibbonBar.COLLAPSED_CLASS;
        final String tabBox = "." + Dim.RibbonBar.TAB_BOX_CLASS;

        // Height pinned here as well as in ToolbarRibbon. The strip must not
        // grow: every vertical number below is measured from it.
        out.append(".ribbon-tab-bar {\n")
                .append(hBox(Dim.RibbonBar.HEIGHT))
                .append(pad(Dim.RibbonBar.PAD_TOP, Dim.RibbonBar.PAD_H,
                        Dim.RibbonBar.PAD_BOTTOM, Dim.RibbonBar.PAD_H))
                .append("}\n\n");

        // Zero padding, stated rather than assumed. The gap above the tab is an
        // HBox MARGIN set in ToolbarRibbon -- margins are not styleable, so
        // nothing in the cascade can reach them, which is the whole reason the
        // gap moved out of CSS. A padding here would be a second, styleable
        // gap on top of it.
        out.append(tabBox).append(" {\n")
                .append("    -fx-padding: 0;\n")
                .append("    -fx-fill-height: true;\n")
                .append("    -fx-alignment: CENTER_LEFT;\n")
                .append("}\n\n");

        // Deliberately no height of any kind: the tab must be free to fill.
        // The asymmetric padding is what centres the label on the strip's
        // centre line -- see the note above.
        out.append(".ribbon-tab {\n")
                .append(pad(Dim.RibbonBar.TAB_PAD_TOP, Dim.RibbonBar.TAB_PAD_H,
                        Dim.RibbonBar.TAB_PAD_BOTTOM, Dim.RibbonBar.TAB_PAD_H))
                .append("    -fx-background-insets: 0;\n")
                .append("    -fx-border-insets: 0;\n")
                .append("    -fx-border-width: ").append(border).append(" ")
                .append(border).append(" 0 ").append(border).append(";\n")
                .append("    ").append(Typography.css(Typography.Role.RIBBON_TAB)).append("\n")
                .append(tabFont())
                .append("}\n\n");

        // Open band: top two corners rounded, bottom two square.
        out.append(".ribbon-tab:hover,\n.ribbon-tab:selected {\n")
                .append("    -fx-background-radius: ").append(radius).append(" ")
                .append(radius).append(" 0 0;\n")
                .append("}\n\n");

        // Open band: outline on the top, right and left; nothing at the bottom.
        out.append(".ribbon-tab:selected {\n")
                .append("    -fx-border-radius: ").append(radius).append(" ")
                .append(radius).append(" 0 0;\n")
                .append("    -fx-border-width: ").append(border).append(" ")
                .append(border).append(" 0 ").append(border).append(";\n")
                .append("}\n\n");

        // Collapsed band: the block is padded on both edges, so the tab is
        // already centred; the label just needs its padding symmetric again.
        out.append(collapsed).append(" .ribbon-tab {\n")
                .append(padVH(Dim.RibbonBar.TAB_PAD_TOP, Dim.RibbonBar.TAB_PAD_H))
                .append(decl("-fx-border-width", Dim.RibbonBar.TAB_BORDER))
                .append("}\n\n");

        out.append(collapsed).append(" .ribbon-tab:hover,\n")
                .append(collapsed).append(" .ribbon-tab:selected {\n")
                .append(decl("-fx-background-radius", Dim.RibbonBar.TAB_RADIUS))
                .append("}\n\n");

        out.append(collapsed).append(" .ribbon-tab:selected {\n")
                .append(decl("-fx-border-radius", Dim.RibbonBar.TAB_RADIUS))
                .append(decl("-fx-border-width", Dim.RibbonBar.TAB_BORDER))
                .append("}\n\n");

        out.append(".ribbon-search-box {\n")
                .append(hBox(Dim.RibbonBar.SEARCH_BOX_HEIGHT))
                .append(decl("-fx-spacing", Dim.RibbonBar.SEARCH_BOX_SPACING))
                .append(pad(0, Dim.RibbonBar.SEARCH_BOX_PAD_RIGHT, 0,
                        Dim.RibbonBar.SEARCH_BOX_PAD_LEFT))
                .append(decl("-fx-background-radius", Dim.RibbonBar.SEARCH_RADIUS))
                .append(decl("-fx-border-radius", Dim.RibbonBar.SEARCH_RADIUS))
                .append(decl("-fx-border-width", Dim.RibbonBar.SEARCH_BORDER))
                .append("}\n\n");

        out.append(".ribbon-search-field {\n")
                .append(hBox(Dim.RibbonBar.SEARCH_FIELD_HEIGHT))
                .append(pad(0, Dim.RibbonBar.SEARCH_FIELD_PAD_RIGHT, 0,
                        Dim.RibbonBar.SEARCH_FIELD_PAD_LEFT))
                .append("    -fx-background-insets: 0;\n")
                .append("    ").append(Typography.css(Typography.Role.SEARCH_FIELD)).append("\n")
                .append("}\n\n");

        out.append(".ribbon-icon-button {\n")
                .append(decl("-fx-padding", Dim.RibbonBar.ACTION_BUTTON_PADDING))
                .append(decl("-fx-background-radius", Dim.RibbonBar.ACTION_BUTTON_RADIUS))
                .append("}\n\n");

        out.append(".ribbon-actions {\n")
                .append(decl("-fx-spacing", Dim.RibbonBar.ACTIONS_SPACING))
                .append("}\n\n");
    }

    private static void toolBand(StringBuilder out) {
        header(out, "TOOL BAND -- Row 2: compartments shared by every tab");

        // Order matters. The Home and Signals bars carry BOTH .menu-toolbar and
        // their own band class, and the two rules have equal specificity, so
        // the band rule has to come second to win.
        out.append(".menu-toolbar {\n")
                .append(padVH(Dim.ToolBand.PAD_V, Dim.ToolBand.FLAT_PAD_H))
                .append("    -fx-spacing: 0;\n")
                .append("    -fx-border-width: 0;\n")
                .append("}\n\n");

        out.append(".home-ribbon-toolbar,\n.signal-ribbon-toolbar {\n")
                .append(padVH(Dim.ToolBand.PAD_V, Dim.ToolBand.PAD_H))
                .append("    -fx-spacing: 0;\n")
                .append("    -fx-border-width: 0;\n")
                .append("}\n\n");

        out.append("/* Home and Signals both assume that padding when they divide the band\n")
                .append("   into units -- see Dim.ToolBand.H_INSET. The flat rows have no unit\n")
                .append("   maths and keep their own, narrower padding.\n")
                .append("   The zero border width is not cosmetic: Modena gives .tool-bar a\n")
                .append("   bottom hairline, and on the Row-2 band that hairline is the very\n")
                .append("   line the merged tab design removes. */\n\n");

        out.append(".ribbon-group {\n")
                .append(pad(0, Dim.ToolBand.GROUP_PAD_H, 0, Dim.ToolBand.GROUP_PAD_H))
                .append(decl("-fx-spacing", Dim.ToolBand.GROUP_SPACING))
                .append("}\n\n");

        out.append(".ribbon-group-items {\n")
                .append(decl("-fx-spacing", Dim.ToolBand.ITEM_SPACING))
                .append("}\n\n");

        out.append(".ribbon-group-caption {\n")
                .append(pad(0, Dim.ToolBand.CAPTION_PAD_H, 0, Dim.ToolBand.CAPTION_PAD_H))
                .append("    ").append(Typography.css(Typography.Role.GROUP_CAPTION)).append("\n")
                .append("}\n\n");

        out.append(".ribbon-group-separator {\n")
                .append(width(Dim.ToolBand.SEPARATOR_WIDTH))
                .append("}\n\n");

        out.append(".ribbon-item-button {\n")
                .append(decl("-fx-padding", Dim.ToolBand.ITEM_PADDING))
                .append(decl("-fx-background-radius", Dim.ToolBand.ITEM_RADIUS))
                .append("    ").append(Typography.css(Typography.Role.RIBBON_ITEM)).append("\n")
                .append("}\n\n");

        out.append(".compact-action-button {\n")
                .append(padVH(Dim.ToolBand.COMPACT_PAD_V, Dim.ToolBand.COMPACT_PAD_H))
                .append(decl("-fx-background-radius", Dim.ToolBand.COMPACT_RADIUS))
                .append(decl("-fx-border-radius", Dim.ToolBand.COMPACT_RADIUS))
                .append("    ").append(Typography.css(Typography.Role.COMPACT_BUTTON)).append("\n")
                .append("}\n\n");
    }

    private static void splitButton(StringBuilder out) {
        header(out, "SPLIT BUTTON -- the Files control");

        out.append(".ribbon-split-button {\n")
                .append(decl("-fx-background-radius", Dim.ToolBand.SplitButton.OUTER_RADIUS))
                .append(decl("-fx-border-radius", Dim.ToolBand.SplitButton.OUTER_RADIUS))
                .append(decl("-fx-border-width", Dim.ToolBand.SplitButton.OUTER_BORDER))
                .append("    -fx-padding: 0;\n")
                .append("}\n\n");

        String zoneRadius = UIScale.fmt(Dim.ToolBand.SplitButton.ZONE_RADIUS);

        out.append(".ribbon-split-icon-zone {\n")
                .append("    -fx-background-radius: ").append(zoneRadius).append(" ")
                .append(zoneRadius).append(" 0 0;\n")
                .append(pad(Dim.ToolBand.SplitButton.ICON_ZONE_PAD_TOP,
                        Dim.ToolBand.SplitButton.ICON_ZONE_PAD_RIGHT,
                        Dim.ToolBand.SplitButton.ICON_ZONE_PAD_BOTTOM,
                        Dim.ToolBand.SplitButton.ICON_ZONE_PAD_LEFT))
                .append("}\n\n");

        out.append(".ribbon-split-menu-zone {\n")
                .append("    -fx-background-radius: 0 0 ").append(zoneRadius).append(" ")
                .append(zoneRadius).append(";\n")
                .append(pad(Dim.ToolBand.SplitButton.MENU_ZONE_PAD_TOP,
                        Dim.ToolBand.SplitButton.MENU_ZONE_PAD_RIGHT,
                        Dim.ToolBand.SplitButton.MENU_ZONE_PAD_BOTTOM,
                        Dim.ToolBand.SplitButton.MENU_ZONE_PAD_LEFT))
                .append(decl("-fx-spacing", Dim.ToolBand.SplitButton.MENU_ZONE_SPACING))
                .append("}\n\n");

        // The triangle is a vector shape, so its path is generated too. Emitting
        // only the box would leave the glyph at its design size while the box
        // around it grew.
        out.append(".ribbon-split-arrow {\n")
                .append(triangle(Dim.ToolBand.SplitButton.ARROW_WIDTH,
                        Dim.ToolBand.SplitButton.ARROW_SHAPE_HEIGHT))
                .append(hBox(Dim.ToolBand.SplitButton.ARROW_HEIGHT))
                .append(width(Dim.ToolBand.SplitButton.ARROW_WIDTH))
                .append("}\n\n");

        out.append(".ribbon-split-label {\n    ")
                .append(Typography.css(Typography.Role.SPLIT_LABEL)).append("\n}\n\n");
    }

    private static void compareButton(StringBuilder out) {
        header(out, "COMPARE BUTTON -- the Signals three-zone control");

        out.append(".ribbon-compare-button {\n")
                .append(decl("-fx-background-radius", Dim.ToolBand.Compare.OUTER_RADIUS))
                .append(decl("-fx-border-radius", Dim.ToolBand.Compare.OUTER_RADIUS))
                .append(decl("-fx-border-width", Dim.ToolBand.Compare.OUTER_BORDER))
                .append(decl("-fx-padding", Dim.ToolBand.Compare.PADDING))
                .append(decl("-fx-spacing", Dim.ToolBand.Compare.SPACING))
                .append("}\n\n");

        out.append(".ribbon-compare-select-zone {\n")
                .append(decl("-fx-background-radius", Dim.ToolBand.Compare.ZONE_RADIUS))
                .append(pad(0, Dim.ToolBand.Compare.SELECT_PAD_RIGHT, 0,
                        Dim.ToolBand.Compare.SELECT_PAD_LEFT))
                .append(decl("-fx-spacing", Dim.ToolBand.Compare.SPACING))
                .append(hBox(Dim.ToolBand.Compare.ZONE_HEIGHT))
                .append("}\n\n");

        out.append(".ribbon-compare-action-zone {\n")
                .append(decl("-fx-background-radius", Dim.ToolBand.Compare.ZONE_RADIUS))
                .append(decl("-fx-border-radius", Dim.ToolBand.Compare.ZONE_RADIUS))
                .append(decl("-fx-border-width", Dim.ToolBand.Compare.ZONE_BORDER))
                .append(hBox(Dim.ToolBand.Compare.ZONE_HEIGHT))
                .append("}\n\n");

        out.append(".ribbon-compare-arrow {\n")
                .append(triangle(Dim.ToolBand.Compare.ARROW_WIDTH,
                        Dim.ToolBand.Compare.ARROW_HEIGHT))
                .append(hBox(Dim.ToolBand.Compare.ARROW_HEIGHT))
                .append(width(Dim.ToolBand.Compare.ARROW_WIDTH))
                .append("}\n\n");

        out.append(".ribbon-compare-label {\n    ")
                .append(Typography.css(Typography.Role.COMPARE_LABEL)).append("\n}\n\n");
    }

    private static void readout(StringBuilder out) {
        header(out, "READOUT -- the Analysis compartment");

        out.append(".ribbon-readout-stack {\n")
                .append(pad(0, Dim.ToolBand.Readout.STACK_PAD_H, 0,
                        Dim.ToolBand.Readout.STACK_PAD_H))
                .append(decl("-fx-spacing", Dim.ToolBand.Readout.STACK_SPACING))
                .append("}\n\n");

        out.append(".ribbon-readout {\n")
                .append(padVH(Dim.ToolBand.Readout.PAD_V, Dim.ToolBand.Readout.PAD_H))
                .append(decl("-fx-background-radius", Dim.ToolBand.Readout.RADIUS))
                .append(decl("-fx-border-radius", Dim.ToolBand.Readout.RADIUS))
                .append(decl("-fx-border-width", Dim.ToolBand.Readout.BORDER))
                .append("}\n\n");

        out.append(".ribbon-readout-title {\n    ")
                .append(Typography.css(Typography.Role.READOUT_TITLE)).append("\n}\n\n");

        out.append(".ribbon-readout-value {\n    ")
                .append(Typography.css(Typography.Role.READOUT_VALUE)).append("\n}\n\n");
    }

    private static void quickBar(StringBuilder out) {
        header(out, "QUICK BAR -- navigation arrows and breadcrumb path");

        out.append(".quick-access-bar {\n")
                .append(hBox(Dim.QuickBar.HEIGHT))
                .append("}\n\n");

        out.append(".quick-path-box {\n")
                .append(decl("-fx-spacing", Dim.QuickBar.PATH_BOX_SPACING))
                .append(decl("-fx-min-height", Dim.QuickBar.PATH_MIN_HEIGHT))
                .append("}\n\n");

        out.append(".quick-path-segments {\n")
                .append(decl("-fx-spacing", Dim.QuickBar.PATH_SEGMENT_SPACING))
                .append("}\n\n");

        out.append(".quick-bar-toggle {\n")
                .append(decl("-fx-background-radius", Dim.QuickBar.TOGGLE_RADIUS))
                .append("}\n\n");
    }

    private static void footer(StringBuilder out) {
        header(out, "FOOTER -- status bar");

        // CENTER_LEFT is doing real work here. An HBox defaults to TOP_LEFT,
        // so every child shorter than the tallest one hangs from the top edge
        // instead of sitting on the row's centre line. That was half of the
        // footer's alignment problem; pinning the three indicators to one
        // height (below) is the other half.
        out.append(".app-footer {\n")
                .append(padVH(Dim.Footer.PAD_V, Dim.Footer.PAD_H))
                .append(decl("-fx-spacing", Dim.Footer.ITEM_SPACING))
                .append("    -fx-alignment: CENTER_LEFT;\n")
                .append("}\n\n");

        out.append(".app-footer-label {\n    ")
                .append(Typography.css(Typography.Role.FOOTER_LABEL)).append("\n}\n\n");

        // Height only, never width: the label reads "\u2716 0" and has to be
        // free to grow when the count reaches double figures.
        out.append(".app-footer-button {\n")
                .append(padVH(Dim.Footer.BUTTON_PAD_V, Dim.Footer.BUTTON_PAD_H))
                .append(hBox(Dim.Footer.INDICATOR_SIZE))
                .append(decl("-fx-background-radius", Dim.Footer.INDICATOR_RADIUS))
                .append(decl("-fx-border-radius", Dim.Footer.INDICATOR_RADIUS))
                .append(decl("-fx-border-width", Dim.Footer.INDICATOR_BORDER))
                .append("    ").append(Typography.css(Typography.Role.FOOTER_BUTTON)).append("\n")
                .append("}\n\n");

        // Square, not circular, and the same box on both axes as the two count
        // buttons are tall -- so the three of them read as one set of
        // indicators. The radius, border width and the zero padding all match
        // .app-footer-button; only -fx-shape's old 50em rounding is gone.
        out.append(".footer-theme-toggle {\n")
                .append(box(Dim.Footer.TOGGLE_SIZE))
                .append(decl("-fx-background-radius", Dim.Footer.INDICATOR_RADIUS))
                .append(decl("-fx-border-radius", Dim.Footer.INDICATOR_RADIUS))
                .append(decl("-fx-border-width", Dim.Footer.INDICATOR_BORDER))
                .append("    -fx-padding: 0;\n")
                .append("    -fx-alignment: CENTER;\n")
                .append("    -fx-content-display: GRAPHIC_ONLY;\n")
                .append("}\n");
    }

    // =====================================================================
    // Emitter helpers
    // =====================================================================

    /**
     * The tab label's size and weight, emitted immediately after
     * {@code Typography.css(Role.RIBBON_TAB)} so it overrides the role's own
     * font declarations inside the same rule.
     *
     * <p>
     * Scaling the role's size rather than stating a number keeps the tabs in
     * proportion if the base typography ever changes, and keeps the one place
     * that knows the tabs are 20% up next to the pinned heights that have to
     * contain them.
     * </p>
     *
     * @return the declarations, ready to append
     */
    private static String tabFont() {
        StringBuilder out = new StringBuilder(64);
        out.append(decl("-fx-font-size",
                Typography.size(Typography.Role.RIBBON_TAB) * Dim.RibbonBar.TAB_FONT_SCALE,
                "px"));
        if (Dim.RibbonBar.TAB_FONT_BOLD) {
            out.append("    -fx-font-weight: bold;\n");
        }
        return out.toString();
    }

    private static void header(StringBuilder out, String text) {
        out.append("/* ===== ").append(text).append(" ===== */\n");
    }

    private static String decl(String property, double value) {
        return "    " + property + ": " + UIScale.fmt(value) + ";\n";
    }

    private static String decl(String property, double value, String unit) {
        return "    " + property + ": " + UIScale.fmt(value) + unit + ";\n";
    }

    private static String pad(double top, double right, double bottom, double left) {
        return "    -fx-padding: " + UIScale.fmt(top) + " " + UIScale.fmt(right) + " "
                + UIScale.fmt(bottom) + " " + UIScale.fmt(left) + ";\n";
    }

    private static String padVH(double vertical, double horizontal) {
        return "    -fx-padding: " + UIScale.fmt(vertical) + " " + UIScale.fmt(horizontal)
                + " " + UIScale.fmt(vertical) + " " + UIScale.fmt(horizontal) + ";\n";
    }

    /** min, pref and max height pinned to one value. */
    private static String hBox(double height) {
        String h = UIScale.fmt(height);
        return "    -fx-min-height: " + h + ";\n"
                + "    -fx-pref-height: " + h + ";\n"
                + "    -fx-max-height: " + h + ";\n";
    }

    /** min, pref and max width pinned to one value. */
    private static String width(double value) {
        String w = UIScale.fmt(value);
        return "    -fx-min-width: " + w + ";\n"
                + "    -fx-pref-width: " + w + ";\n"
                + "    -fx-max-width: " + w + ";\n";
    }

    /** A square box: min, pref and max on both axes. */
    private static String box(double size) {
        return width(size) + hBox(size);
    }

    /**
     * A downward-pointing triangle as an {@code -fx-shape} path, generated at
     * the requested size so the glyph tracks the scale factor. {@code
     * -fx-scale-shape} stays false: the path is already the right size, and
     * letting JavaFX stretch it would round differently.
     */
    private static String triangle(double width, double height) {
        return "    -fx-shape: \"M 0 0 L " + UIScale.fmt(width) + " 0 L "
                + UIScale.fmt(width / 2.0) + " " + UIScale.fmt(height) + " Z\";\n"
                + "    -fx-scale-shape: false;\n";
    }

    // =====================================================================
    // Attachment
    // =====================================================================

    private static synchronized String uri() {
        if (cachedUri != null) {
            return cachedUri;
        }
        String css = css();
        maybeDump(css);
        cachedUri = "data:text/css;base64,"
                + Base64.getEncoder().encodeToString(css.getBytes(StandardCharsets.UTF_8));
        return cachedUri;
    }

    private static void moveToEnd(Scene scene) {
        String uri = cachedUri;
        if (uri == null) {
            return;
        }
        int last = scene.getStylesheets().size() - 1;
        int at = scene.getStylesheets().indexOf(uri);
        if (at == last) {
            return;
        }
        reordering = true;
        try {
            if (at >= 0) {
                scene.getStylesheets().remove(at);
            }
            scene.getStylesheets().add(uri);
        } finally {
            reordering = false;
        }
    }

    private static void maybeDump(String css) {
        if (!Boolean.getBoolean(DUMP_PROPERTY)) {
            return;
        }
        try {
            Path target = Path.of("astra-design.css");
            Files.writeString(target, css, StandardCharsets.UTF_8);
            System.out.println("Design stylesheet written to " + target.toAbsolutePath());
        } catch (IOException ex) {
            System.err.println("Could not write the design stylesheet: " + ex.getMessage());
        }
    }
}
