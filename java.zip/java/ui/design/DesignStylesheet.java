package ui.design;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;

import javafx.application.Platform;
import javafx.collections.ListChangeListener;
import javafx.scene.Scene;

/**
 * Turns {@link Dim} and {@link Typography} into a real stylesheet and keeps it
 * attached to the scene as the last sheet in the list.
 *
 * <h3>Why generate CSS at all</h3>
 * <p>
 * JavaFX CSS has no numeric variables -- looked-up values work for colours
 * only. Without this class every padding and font size would have to be written
 * twice: once in {@link Dim} for the Java side and once by hand in
 * {@code light.css} and {@code dark.css}. The ribbon showed exactly what that
 * costs: {@code RibbonLayout.TOOLBAR_H_INSET = 20} had to match
 * {@code -fx-padding: 4 10 4 10} in two stylesheets, and three comments warned
 * about keeping them in step. Now one constant produces both.
 * </p>
 *
 * <h3>Why it must be last</h3>
 * <p>
 * {@code ThemeManager} swaps {@code light.css} for {@code dark.css} at runtime
 * and then appends an editor stylesheet. Later sheets win ties in JavaFX, so
 * this class watches the list and moves itself back to the end whenever it
 * changes. That also makes the migration safe to do gradually: a dimension left
 * behind in a theme file is simply overridden until it is deleted.
 * </p>
 *
 * <h3>The ribbon colour sheets</h3>
 * <p>
 * {@link #install} also installs {@link RibbonTheme}, which keeps
 * {@code themes/ribbon/ribbon_light.css} or {@code ribbon_dark.css} attached
 * alongside whichever base theme is active. The ribbon's colours were split out
 * of {@code light.css} / {@code dark.css} because both files had grown past the
 * point where the ribbon block could be found in them. Installing it from here
 * means no other file has to know the ribbon sheets exist.
 * </p>
 *
 * <h3>Fonts</h3>
 * <p>
 * {@code .root} carries the platform UI family ({@link Typography#uiFamily()},
 * Segoe UI on Windows) and the base size; everything in the chrome inherits
 * both. The editor ({@code .code-area}) and any node carrying
 * {@link Typography#CODE_FONT_CLASS} get the monospaced
 * {@link Typography#codeFamily()} instead. Families are resolved when the sheet
 * is first built, which is after the JavaFX toolkit has started.
 * </p>
 *
 * <h3>Reading the generated CSS</h3>
 * <p>
 * Launch with {@code -Dastra.design.dumpCss=true} and the exact stylesheet in
 * use is written to {@code astra-design.css} in the working directory, with a
 * comment header per region.
 * </p>
 */
public final class DesignStylesheet {

    /** Set to {@code true} to write the generated sheet to disk on startup. */
    public static final String DUMP_PROPERTY = "astra.design.dumpCss";

    private static String cachedUri;
    private static boolean reordering = false;

    private DesignStylesheet() {
    }

    /**
     * Attaches the generated sheet to a scene and keeps it at the end of the
     * stylesheet list for the life of the scene. Also installs the ribbon
     * colour sheets.
     *
     * @param scene the application scene
     */
    public static void install(Scene scene) {
        if (scene == null) {
            return;
        }

        // Before the generated sheet, so the ribbon colours sit under the
        // generated geometry rather than over it.
        RibbonTheme.install(scene);

        String uri = uri();
        if (uri == null) {
            return;
        }
        if (!scene.getStylesheets().contains(uri)) {
            scene.getStylesheets().add(uri);
        }
        scene.getStylesheets().addListener((ListChangeListener<String>) change -> {
            if (reordering) {
                return;
            }
            Platform.runLater(() -> moveToEnd(scene));
        });
    }

    /**
     * Rebuilds the sheet and re-attaches it. Only needed if a design value is
     * ever changed at runtime; the normal path is {@link #install}.
     *
     * @param scene the application scene
     */
    public static void refresh(Scene scene) {
        if (scene == null) {
            return;
        }
        String old = cachedUri;
        cachedUri = null;
        if (old != null) {
            scene.getStylesheets().remove(old);
        }
        install(scene);
    }

    /**
     * The generated stylesheet as text. Exposed for debugging and tests.
     *
     * @return the CSS source
     */
    public static String css() {
        StringBuilder out = new StringBuilder(8192);

        out.append("/* =====================================================================\n")
                .append("   GENERATED -- do not edit\n")
                .append("   Produced by ui.design.DesignStylesheet from Dim and Typography.\n")
                .append("   Scale factor in use: ").append(UIScale.fmt(UIScale.factor())).append("\n")
                .append("   Fonts in use: ").append(Typography.describe()).append("\n")
                .append("   Colours are NOT here: they stay in themes/light.css, dark.css and\n")
                .append("   themes/ribbon/ribbon_light.css, ribbon_dark.css.\n")
                .append("   ===================================================================== */\n\n");

        root(out);
        codeText(out);
        textRendering(out);
        titleBar(out);
        rail(out);
        directoryTree(out);
        ribbonBar(out);
        toolBand(out);
        splitButton(out);
        compareButton(out);
        readout(out);
        navigationBar(out);
        breadcrumbBar(out);
        pathErrorDialog(out);
        footer(out);

        return out.toString();
    }

    // =====================================================================
    // Region emitters
    // =====================================================================

    private static void root(StringBuilder out) {
        header(out, "ROOT -- the family and size everything else inherits");
        out.append(".root {\n")
                .append("    -fx-font-family: ")
                .append(Typography.familyCss(Typography.uiFamily())).append(";\n")
                .append(decl("-fx-font-size", Typography.size(Typography.Role.BASE), "px"))
                .append("}\n\n");
    }

    /**
     * The monospaced face for source text.
     *
     * <p>
     * {@code .code-area} is the style class RichTextFX gives every
     * {@code CodeArea}, so the editor is covered without touching its code.
     * The CLI, or anything else that must stay monospaced, opts in by adding
     * {@link Typography#CODE_FONT_CLASS}. Only the family is set here: the
     * editor's size still comes from its inline {@code EDITOR_CODE} style,
     * which now names the same family.
     * </p>
     * <p>
     * This sheet is attached after {@code editor_light.css} /
     * {@code editor_dark.css}, so at equal specificity this rule wins. A more
     * specific family rule in those files (for example on
     * {@code .code-area .text}) would still beat it and should be removed.
     * </p>
     */
    private static void codeText(StringBuilder out) {
        header(out, "CODE TEXT -- editor and CLI keep a monospaced face");
        out.append(".code-area,\n.").append(Typography.CODE_FONT_CLASS).append(" {\n")
                .append("    -fx-font-family: ")
                .append(Typography.familyCss(Typography.codeFamily())).append(";\n")
                .append("}\n\n");
    }

    /**
     * LCD (ClearType-style) smoothing on every text node, Windows only; see
     * {@link Typography#LCD_TEXT}.
     */
    private static void textRendering(StringBuilder out) {
        if (!Typography.LCD_TEXT) {
            return;
        }
        header(out, "TEXT RENDERING -- ClearType-style smoothing (Windows)");
        out.append(".text {\n")
                .append("    -fx-font-smoothing-type: lcd;\n")
                .append("}\n\n");
    }

    private static void titleBar(StringBuilder out) {
        header(out, "TITLE BAR -- panel title strips");
        out.append(".panel-title-bar {\n")
                .append(pad(Dim.TitleBar.PAD_TOP, Dim.TitleBar.PAD_RIGHT,
                        Dim.TitleBar.PAD_BOTTOM, Dim.TitleBar.PAD_LEFT))
                .append(decl("-fx-spacing", Dim.TitleBar.CONTENT_SPACING))
                .append("    -fx-border-width: 0 0 ")
                .append(UIScale.fmt(Dim.TitleBar.BOTTOM_BORDER)).append(" 0;\n")
                .append("}\n\n");

        out.append(".panel-title-label {\n    ")
                .append(Typography.css(Typography.Role.PANEL_TITLE)).append("\n}\n\n");

        out.append(".panel-title-button {\n")
                .append(decl("-fx-padding", Dim.TitleBar.GLYPH_BUTTON_PADDING))
                .append(decl("-fx-background-radius", Dim.TitleBar.GLYPH_BUTTON_RADIUS))
                .append(box(Dim.TitleBar.GLYPH_BUTTON_SIZE))
                .append("}\n\n");
    }

    private static void rail(StringBuilder out) {
        header(out, "RAIL -- collapsed panel strip");
        out.append(".panel-rail {\n")
                .append(pad(Dim.Rail.PAD_TOP, Dim.Rail.PAD_RIGHT,
                        Dim.Rail.PAD_BOTTOM, Dim.Rail.PAD_LEFT))
                .append(decl("-fx-spacing", Dim.Explorer.RAIL_SPACING))
                .append("    -fx-border-width: 0 ")
                .append(UIScale.fmt(Dim.Rail.SIDE_BORDER)).append(" 0 0;\n")
                .append("}\n\n");

        out.append(".panel-rail-label {\n    ")
                .append(Typography.css(Typography.Role.PANEL_RAIL)).append("\n}\n\n");
    }

    /**
     * The directory explorer's tree table.
     *
     * <p>
     * Everything here is scoped under {@code .directory-tree} so the Variable
     * Explorer's table keeps Modena's look. The colours that pair with these
     * rules -- the header fill, the faint dividers, the mode-row hover -- are in
     * the "DIRECTORY EXPLORER" block of {@code light.css} and {@code dark.css}.
     * </p>
     *
     * <h4>Header</h4>
     * <p>
     * Modena gives {@code .column-header} a 2em height, a 2px padding and bold
     * text at 1.08em. All three are replaced: the height by
     * {@code HEADER_HEIGHT} (through {@code -fx-size}, which is what
     * {@code TableColumnHeader} reads), the padding by zero, and the font by
     * the breadcrumb bar's font ({@link DirectoryRowMetrics#FONT_ROLE}) in
     * pixels, so the captions come out exactly the size of the rows rather
     * than an em step above them.
     * </p>
     * <p>
     * The divider is the first of two background layers, showing through a
     * one-pixel inset on the right and bottom of the fill. Modena uses three
     * layers there (border, inner highlight, gradient); the themes supply two
     * colours to match the two insets emitted here. The filler after the last
     * column keeps only the bottom line, so no divider hangs over the
     * scrollbar.
     * </p>
     *
     * <h4>Rows</h4>
     * <p>
     * Modena draws the vertical grid as a one-pixel right border on every
     * cell, empty rows included, which is why the lines ran to the bottom of
     * the panel. The border width goes to zero here; the themes also make its
     * colour transparent, so neither half can bring the line back alone.
     * </p>
     * <p>
     * Row text uses the breadcrumb font, and the row height is
     * {@link DirectoryRowMetrics#rowHeight()}: the measured text line or the
     * icon, whichever is taller, plus a small pad. Modena's
     * {@code -fx-cell-size: 2em} is what made rows grow with the font; it is
     * replaced by that measured height, and the cells and the disclosure
     * triangle lose their vertical padding so the pad is the only gap between
     * rows. The same value is given to {@code setFixedCellSize} in
     * {@code DirectoryTreeBuilder}.
     * </p>
     */
    private static void directoryTree(StringBuilder out) {
        header(out, "DIRECTORY EXPLORER -- tree table");

        final String t = ".directory-tree";
        final String d = UIScale.fmt(Dim.Directory.HEADER_DIVIDER);
        final String rowFont = DirectoryRowMetrics.fontCss();
        final String headerFont = rowFont;

        // ---- header strip -----------------------------------------------
        out.append(t).append(" .column-header {\n")
                .append(decl("-fx-size", Dim.Directory.HEADER_HEIGHT))
                .append("    -fx-padding: 0;\n")
                .append("    -fx-background-insets: 0, 0 ").append(d).append(" ").append(d).append(" 0;\n")
                .append("    ").append(headerFont).append("\n")
                .append("}\n\n");

        out.append(t).append(" .filler {\n")
                .append("    -fx-padding: 0;\n")
                .append("    -fx-background-insets: 0, 0 0 ").append(d).append(" 0;\n")
                .append("}\n\n");

        out.append(t).append(" > .column-header-background {\n")
                .append("    -fx-background-insets: 0;\n")
                .append("}\n\n");

        // Every caption: row-sized, regular weight, a little air either side.
        out.append(t).append(" .column-header .label {\n")
                .append("    ").append(headerFont).append("\n")
                .append(padVH(0, Dim.Directory.HEADER_PAD_H))
                .append("}\n\n");

        out.append(t).append(" .column-header.directory-name-column > .label {\n")
                .append("    -fx-alignment: CENTER_LEFT;\n")
                .append("}\n\n");

        out.append(t).append(" .column-header.directory-repo-column > .label {\n")
                .append("    -fx-alignment: CENTER;\n")
                .append("}\n\n");

        // Info: the header label carries no text, only a graphic that JavaFX
        // stretches to the label's full size, so the label itself must have
        // no padding or the graphic would not reach the cell's edges.
        out.append(t).append(" .column-header.directory-info-column > .label {\n")
                .append("    -fx-alignment: CENTER;\n")
                .append("    -fx-padding: 0;\n")
                .append("}\n\n");

        // ---- Info header: two rows ---------------------------------------
        //   | Info                  |   caption row, line underneath
        //   | By Number of Lines  v |   mode row, the drop-down
        final String infoFont = Typography.css(Typography.Role.DIRECTORY_INFO_HEADER);
        final double inset = Dim.Directory.INFO_MODE_HIGHLIGHT_INSET;
        final double rightInset = inset + Dim.Directory.HEADER_DIVIDER;
        final double radius = Dim.Directory.INFO_MODE_RADIUS;

        out.append(t).append(" .directory-info-header {\n")
                .append("    -fx-padding: 0;\n")
                .append("    -fx-spacing: 0;\n")
                .append("}\n\n");

        out.append(t).append(" .column-header .label.directory-info-caption {\n")
                .append("    ").append(infoFont).append("\n")
                .append("    -fx-padding: 0;\n")
                .append("    -fx-alignment: CENTER;\n")
                .append(hBox(Dim.Directory.INFO_CAPTION_ROW + Dim.Directory.HEADER_DIVIDER))
                .append("    -fx-border-width: 0 0 ").append(d).append(" 0;\n")
                .append("}\n\n");

        // Two background layers when highlighted (outline, fill), so both
        // insets are emitted; at rest the theme gives a single transparent
        // layer and only the first inset is used. Right padding clears the
        // divider as well as the highlight.
        out.append(t).append(" .directory-info-mode {\n")
                .append(hBox(Dim.Directory.INFO_MODE_ROW))
                .append(pad(0, Dim.Directory.INFO_MODE_PAD_H + rightInset,
                        0, Dim.Directory.INFO_MODE_PAD_H))
                .append(decl("-fx-spacing", Dim.Directory.INFO_MODE_SPACING))
                .append("    -fx-background-insets: ")
                .append(insets(0, rightInset, inset, inset)).append(", ")
                .append(insets(1, rightInset + 1, inset + 1, inset + 1)).append(";\n")
                .append("    -fx-background-radius: ").append(UIScale.fmt(radius)).append(", ")
                .append(UIScale.fmt(Math.max(0, radius - 1))).append(";\n")
                .append("}\n\n");

        out.append(t).append(" .column-header .label.directory-info-mode-label {\n")
                .append("    ").append(infoFont).append("\n")
                .append("    -fx-padding: 0;\n")
                .append("}\n\n");

        // ---- rows ---------------------------------------------------------
        // Measured height replaces Modena's 2em, which scaled with the font.
        out.append(t).append(" .tree-table-row-cell {\n")
                .append(decl("-fx-cell-size", DirectoryRowMetrics.rowHeight()))
                .append("    -fx-padding: 0;\n")
                .append("}\n\n");

        // No vertical padding: the row height already holds the gap.
        out.append(t).append(" .tree-table-row-cell > .tree-table-cell {\n")
                .append(padVH(0, Dim.Directory.CELL_PAD_H))
                .append("    -fx-border-width: 0;\n")
                .append("    ").append(rowFont).append("\n")
                .append("}\n\n");

        // Modena pads the triangle 4px top and bottom; keep only its sides.
        out.append(t).append(" .tree-table-row-cell > .tree-disclosure-node {\n")
                .append(pad(0, 6, 0, 8))
                .append("}\n\n");

        // ---- Info drop-down menu ------------------------------------------
        // The menu lives in its own popup window, so it is matched by its own
        // class rather than under .directory-tree.
        out.append(".context-menu.directory-info-menu {\n")
                .append(decl("-fx-padding", Dim.Directory.MENU_PAD))
                .append(decl("-fx-background-radius", Dim.Directory.MENU_RADIUS))
                .append(decl("-fx-border-radius", Dim.Directory.MENU_RADIUS))
                .append("    -fx-border-width: 1;\n")
                .append("}\n\n");

        out.append(".directory-info-menu .menu-item {\n")
                .append(padVH(Dim.Directory.MENU_ITEM_PAD_V, Dim.Directory.MENU_ITEM_PAD_H))
                .append(decl("-fx-background-radius", Math.max(0, Dim.Directory.MENU_RADIUS - 1)))
                .append("}\n\n");

        out.append(".directory-info-menu .menu-item .label {\n    ")
                .append(rowFont).append("\n}\n\n");
    }

    /**
     * Row 1.
     *
     * <p>
     * Note what this block does <b>not</b> do: it does not produce the gap
     * above the tab. That is an {@code HBox} margin set in
     * {@code ToolbarRibbon}, because margins are not styleable and therefore
     * cannot be overridden by Modena, by a theme file, or by anything else in
     * the cascade. Three CSS-based attempts at that gap failed for three
     * different reasons; the notes in {@code RibbonBar_dim} list them.
     * </p>
     * <p>
     * What this block does do is keep out of the way: {@code .ribbon-tab-box}
     * gets an explicit zero padding, and {@code .ribbon-tab} gets no height
     * property of any kind so the tab is free to fill whatever its margin
     * leaves. If you add {@code -fx-pref-height} to {@code .ribbon-tab} or a
     * padding to the block, you are reintroducing a failure that has already
     * cost several rounds.
     * </p>
     * <p>
     * The tab's padding is asymmetric to finish the job: the tab starts one gap
     * below the strip's top but ends flush with its bottom, so its own centre
     * is half a gap low. {@code TAB_PAD_BOTTOM} pays that gap back and puts the
     * label -- and only the label -- on the strip's centre line.
     * </p>
     * <p>
     * The zero insets are not vestigial: they cancel Modena's
     * {@code 0 0 -1 0, 0, 1, 2} on {@code .toggle-button}, which would
     * otherwise inset the fill a pixel or two on three sides and stop the
     * bottom edge meeting the band cleanly.
     * </p>
     * <p>
     * The label's font is emitted twice on purpose: {@code Typography.css} for
     * the role, then {@code TAB_FONT_SCALE} and the weight after it, overriding
     * within the same rule.
     * </p>
     * <p>
     * Collapsed: the block takes the same padding at the bottom, so the tab is
     * centred in the strip with navy all round, the label's padding goes back
     * to symmetric, and the border and radius close up on all four sides.
     * </p>
     */
    private static void ribbonBar(StringBuilder out) {
        header(out, "RIBBON BAR -- Row 1: tabs, search box, action cluster");

        final String radius = UIScale.fmt(Dim.RibbonBar.TAB_RADIUS);
        final String border = UIScale.fmt(Dim.RibbonBar.TAB_BORDER);
        // Qualified with the strip's own class so the collapsed rules always
        // out-specify the open ones, whatever JavaFX makes of a bare descendant
        // selector against a pseudo-class.
        final String collapsed = ".ribbon-tab-bar." + Dim.RibbonBar.COLLAPSED_CLASS;
        final String tabBox = "." + Dim.RibbonBar.TAB_BOX_CLASS;

        // Height pinned here as well as in ToolbarRibbon. The strip must not
        // grow: every vertical number below is measured from it.
        out.append(".ribbon-tab-bar {\n")
                .append(hBox(Dim.RibbonBar.HEIGHT))
                .append(pad(Dim.RibbonBar.PAD_TOP, Dim.RibbonBar.PAD_H,
                        Dim.RibbonBar.PAD_BOTTOM, Dim.RibbonBar.PAD_H))
                .append("}\n\n");

        // Zero padding, stated rather than assumed. The gap above the tab is an
        // HBox MARGIN set in ToolbarRibbon -- margins are not styleable, so
        // nothing in the cascade can reach them, which is the whole reason the
        // gap moved out of CSS. A padding here would be a second, styleable
        // gap on top of it.
        out.append(tabBox).append(" {\n")
                .append("    -fx-padding: 0;\n")
                .append("    -fx-fill-height: true;\n")
                .append("    -fx-alignment: CENTER_LEFT;\n")
                .append("}\n\n");

        // Deliberately no height of any kind: the tab must be free to fill.
        // The asymmetric padding is what centres the label on the strip's
        // centre line -- see the note above.
        out.append(".ribbon-tab {\n")
                .append(pad(Dim.RibbonBar.TAB_PAD_TOP, Dim.RibbonBar.TAB_PAD_H,
                        Dim.RibbonBar.TAB_PAD_BOTTOM, Dim.RibbonBar.TAB_PAD_H))
                .append("    -fx-background-insets: 0;\n")
                .append("    -fx-border-insets: 0;\n")
                .append("    -fx-border-width: ").append(border).append(" ")
                .append(border).append(" 0 ").append(border).append(";\n")
                .append("    ").append(Typography.css(Typography.Role.RIBBON_TAB)).append("\n")
                .append(tabFont())
                .append("}\n\n");

        // Open band: top two corners rounded, bottom two square.
        out.append(".ribbon-tab:hover,\n.ribbon-tab:selected {\n")
                .append("    -fx-background-radius: ").append(radius).append(" ")
                .append(radius).append(" 0 0;\n")
                .append("}\n\n");

        // Open band: outline on the top, right and left; nothing at the bottom.
        out.append(".ribbon-tab:selected {\n")
                .append("    -fx-border-radius: ").append(radius).append(" ")
                .append(radius).append(" 0 0;\n")
                .append("    -fx-border-width: ").append(border).append(" ")
                .append(border).append(" 0 ").append(border).append(";\n")
                .append("}\n\n");

        // Collapsed band: the block is padded on both edges, so the tab is
        // already centred; the label just needs its padding symmetric again.
        out.append(collapsed).append(" .ribbon-tab {\n")
                .append(padVH(Dim.RibbonBar.TAB_PAD_TOP, Dim.RibbonBar.TAB_PAD_H))
                .append(decl("-fx-border-width", Dim.RibbonBar.TAB_BORDER))
                .append("}\n\n");

        out.append(collapsed).append(" .ribbon-tab:hover,\n")
                .append(collapsed).append(" .ribbon-tab:selected {\n")
                .append(decl("-fx-background-radius", Dim.RibbonBar.TAB_RADIUS))
                .append("}\n\n");

        out.append(collapsed).append(" .ribbon-tab:selected {\n")
                .append(decl("-fx-border-radius", Dim.RibbonBar.TAB_RADIUS))
                .append(decl("-fx-border-width", Dim.RibbonBar.TAB_BORDER))
                .append("}\n\n");

        out.append(".ribbon-search-box {\n")
                .append(hBox(Dim.RibbonBar.SEARCH_BOX_HEIGHT))
                .append(decl("-fx-spacing", Dim.RibbonBar.SEARCH_BOX_SPACING))
                .append(pad(0, Dim.RibbonBar.SEARCH_BOX_PAD_RIGHT, 0,
                        Dim.RibbonBar.SEARCH_BOX_PAD_LEFT))
                .append(decl("-fx-background-radius", Dim.RibbonBar.SEARCH_RADIUS))
                .append(decl("-fx-border-radius", Dim.RibbonBar.SEARCH_RADIUS))
                .append(decl("-fx-border-width", Dim.RibbonBar.SEARCH_BORDER))
                .append("}\n\n");

        out.append(".ribbon-search-field {\n")
                .append(hBox(Dim.RibbonBar.SEARCH_FIELD_HEIGHT))
                .append(pad(0, Dim.RibbonBar.SEARCH_FIELD_PAD_RIGHT, 0,
                        Dim.RibbonBar.SEARCH_FIELD_PAD_LEFT))
                .append("    -fx-background-insets: 0;\n")
                .append("    ").append(Typography.css(Typography.Role.SEARCH_FIELD)).append("\n")
                .append("}\n\n");

        out.append(".ribbon-icon-button {\n")
                .append(decl("-fx-padding", Dim.RibbonBar.ACTION_BUTTON_PADDING))
                .append(decl("-fx-background-radius", Dim.RibbonBar.ACTION_BUTTON_RADIUS))
                .append("}\n\n");

        out.append(".ribbon-actions {\n")
                .append(decl("-fx-spacing", Dim.RibbonBar.ACTIONS_SPACING))
                .append("}\n\n");
    }

    private static void toolBand(StringBuilder out) {
        header(out, "TOOL BAND -- Row 2: compartments shared by every tab");

        // Order matters. The Home and Signals bars carry BOTH .menu-toolbar and
        // their own band class, and the two rules have equal specificity, so
        // the band rule has to come second to win.
        out.append(".menu-toolbar {\n")
                .append(padVH(Dim.ToolBand.PAD_V, Dim.ToolBand.FLAT_PAD_H))
                .append("    -fx-spacing: 0;\n")
                .append("    -fx-border-width: 0;\n")
                .append("}\n\n");

        out.append(".home-ribbon-toolbar,\n.signal-ribbon-toolbar {\n")
                .append(padVH(Dim.ToolBand.PAD_V, Dim.ToolBand.PAD_H))
                .append("    -fx-spacing: 0;\n")
                .append("    -fx-border-width: 0;\n")
                .append("}\n\n");

        out.append("/* Home and Signals both assume that padding when they divide the band\n")
                .append("   into units -- see Dim.ToolBand.H_INSET. The flat rows have no unit\n")
                .append("   maths and keep their own, narrower padding.\n")
                .append("   The zero border width is not cosmetic: Modena gives .tool-bar a\n")
                .append("   bottom hairline, and on the Row-2 band that hairline is the very\n")
                .append("   line the merged tab design removes. */\n\n");

        out.append(".ribbon-group {\n")
                .append(pad(0, Dim.ToolBand.GROUP_PAD_H, 0, Dim.ToolBand.GROUP_PAD_H))
                .append(decl("-fx-spacing", Dim.ToolBand.GROUP_SPACING))
                .append("}\n\n");

        out.append(".ribbon-group-items {\n")
                .append(decl("-fx-spacing", Dim.ToolBand.ITEM_SPACING))
                .append("}\n\n");

        out.append(".ribbon-group-caption {\n")
                .append(pad(0, Dim.ToolBand.CAPTION_PAD_H, 0, Dim.ToolBand.CAPTION_PAD_H))
                .append("    ").append(Typography.css(Typography.Role.GROUP_CAPTION)).append("\n")
                .append("}\n\n");

        out.append(".ribbon-group-separator {\n")
                .append(width(Dim.ToolBand.SEPARATOR_WIDTH))
                .append("}\n\n");

        out.append(".ribbon-item-button {\n")
                .append(decl("-fx-padding", Dim.ToolBand.ITEM_PADDING))
                .append(decl("-fx-background-radius", Dim.ToolBand.ITEM_RADIUS))
                .append("    ").append(Typography.css(Typography.Role.RIBBON_ITEM)).append("\n")
                .append("}\n\n");

        out.append(".compact-action-button {\n")
                .append(padVH(Dim.ToolBand.COMPACT_PAD_V, Dim.ToolBand.COMPACT_PAD_H))
                .append(decl("-fx-background-radius", Dim.ToolBand.COMPACT_RADIUS))
                .append(decl("-fx-border-radius", Dim.ToolBand.COMPACT_RADIUS))
                .append("    ").append(Typography.css(Typography.Role.COMPACT_BUTTON)).append("\n")
                .append("}\n\n");
    }

    private static void splitButton(StringBuilder out) {
        header(out, "SPLIT BUTTON -- the Files control");

        out.append(".ribbon-split-button {\n")
                .append(decl("-fx-background-radius", Dim.ToolBand.SplitButton.OUTER_RADIUS))
                .append(decl("-fx-border-radius", Dim.ToolBand.SplitButton.OUTER_RADIUS))
                .append(decl("-fx-border-width", Dim.ToolBand.SplitButton.OUTER_BORDER))
                .append("    -fx-padding: 0;\n")
                .append("}\n\n");

        String zoneRadius = UIScale.fmt(Dim.ToolBand.SplitButton.ZONE_RADIUS);

        out.append(".ribbon-split-icon-zone {\n")
                .append("    -fx-background-radius: ").append(zoneRadius).append(" ")
                .append(zoneRadius).append(" 0 0;\n")
                .append(pad(Dim.ToolBand.SplitButton.ICON_ZONE_PAD_TOP,
                        Dim.ToolBand.SplitButton.ICON_ZONE_PAD_RIGHT,
                        Dim.ToolBand.SplitButton.ICON_ZONE_PAD_BOTTOM,
                        Dim.ToolBand.SplitButton.ICON_ZONE_PAD_LEFT))
                .append("}\n\n");

        out.append(".ribbon-split-menu-zone {\n")
                .append("    -fx-background-radius: 0 0 ").append(zoneRadius).append(" ")
                .append(zoneRadius).append(";\n")
                .append(pad(Dim.ToolBand.SplitButton.MENU_ZONE_PAD_TOP,
                        Dim.ToolBand.SplitButton.MENU_ZONE_PAD_RIGHT,
                        Dim.ToolBand.SplitButton.MENU_ZONE_PAD_BOTTOM,
                        Dim.ToolBand.SplitButton.MENU_ZONE_PAD_LEFT))
                .append(decl("-fx-spacing", Dim.ToolBand.SplitButton.MENU_ZONE_SPACING))
                .append("}\n\n");

        // The triangle is a vector shape, so its path is generated too. Emitting
        // only the box would leave the glyph at its design size while the box
        // around it grew.
        out.append(".ribbon-split-arrow {\n")
                .append(triangle(Dim.ToolBand.SplitButton.ARROW_WIDTH,
                        Dim.ToolBand.SplitButton.ARROW_SHAPE_HEIGHT))
                .append(hBox(Dim.ToolBand.SplitButton.ARROW_HEIGHT))
                .append(width(Dim.ToolBand.SplitButton.ARROW_WIDTH))
                .append("}\n\n");

        out.append(".ribbon-split-label {\n    ")
                .append(Typography.css(Typography.Role.SPLIT_LABEL)).append("\n}\n\n");
    }

    private static void compareButton(StringBuilder out) {
        header(out, "COMPARE BUTTON -- the Signals three-zone control");

        out.append(".ribbon-compare-button {\n")
                .append(decl("-fx-background-radius", Dim.ToolBand.Compare.OUTER_RADIUS))
                .append(decl("-fx-border-radius", Dim.ToolBand.Compare.OUTER_RADIUS))
                .append(decl("-fx-border-width", Dim.ToolBand.Compare.OUTER_BORDER))
                .append(decl("-fx-padding", Dim.ToolBand.Compare.PADDING))
                .append(decl("-fx-spacing", Dim.ToolBand.Compare.SPACING))
                .append("}\n\n");

        out.append(".ribbon-compare-select-zone {\n")
                .append(decl("-fx-background-radius", Dim.ToolBand.Compare.ZONE_RADIUS))
                .append(pad(0, Dim.ToolBand.Compare.SELECT_PAD_RIGHT, 0,
                        Dim.ToolBand.Compare.SELECT_PAD_LEFT))
                .append(decl("-fx-spacing", Dim.ToolBand.Compare.SPACING))
                .append(hBox(Dim.ToolBand.Compare.ZONE_HEIGHT))
                .append("}\n\n");

        out.append(".ribbon-compare-action-zone {\n")
                .append(decl("-fx-background-radius", Dim.ToolBand.Compare.ZONE_RADIUS))
                .append(decl("-fx-border-radius", Dim.ToolBand.Compare.ZONE_RADIUS))
                .append(decl("-fx-border-width", Dim.ToolBand.Compare.ZONE_BORDER))
                .append(hBox(Dim.ToolBand.Compare.ZONE_HEIGHT))
                .append("}\n\n");

        out.append(".ribbon-compare-arrow {\n")
                .append(triangle(Dim.ToolBand.Compare.ARROW_WIDTH,
                        Dim.ToolBand.Compare.ARROW_HEIGHT))
                .append(hBox(Dim.ToolBand.Compare.ARROW_HEIGHT))
                .append(width(Dim.ToolBand.Compare.ARROW_WIDTH))
                .append("}\n\n");

        out.append(".ribbon-compare-label {\n    ")
                .append(Typography.css(Typography.Role.COMPARE_LABEL)).append("\n}\n\n");
    }

    private static void readout(StringBuilder out) {
        header(out, "READOUT -- the Analysis compartment");

        out.append(".ribbon-readout-stack {\n")
                .append(pad(0, Dim.ToolBand.Readout.STACK_PAD_H, 0,
                        Dim.ToolBand.Readout.STACK_PAD_H))
                .append(decl("-fx-spacing", Dim.ToolBand.Readout.STACK_SPACING))
                .append("}\n\n");

        out.append(".ribbon-readout {\n")
                .append(padVH(Dim.ToolBand.Readout.PAD_V, Dim.ToolBand.Readout.PAD_H))
                .append(decl("-fx-background-radius", Dim.ToolBand.Readout.RADIUS))
                .append(decl("-fx-border-radius", Dim.ToolBand.Readout.RADIUS))
                .append(decl("-fx-border-width", Dim.ToolBand.Readout.BORDER))
                .append("}\n\n");

        out.append(".ribbon-readout-title {\n    ")
                .append(Typography.css(Typography.Role.READOUT_TITLE)).append("\n}\n\n");

        out.append(".ribbon-readout-value {\n    ")
                .append(Typography.css(Typography.Role.READOUT_VALUE)).append("\n}\n\n");
    }

    /**
     * The quick-access row and the six navigation buttons.
     *
     * <p>
     * The row selector is doubled with {@code :horizontal} on purpose. Modena
     * pads {@code .tool-bar:horizontal}, and although an author sheet already
     * outranks the user-agent sheet, naming the same pseudo-class here means
     * the padding cannot come back through specificity either. Without an
     * explicit padding the 29px row would be squeezed by Modena's ~5px per
     * side and clip the 22px buttons.
     * </p>
     */
    private static void navigationBar(StringBuilder out) {
        header(out, "NAVIGATION BAR -- Home, Back, Forward, Up, Cloud, Root");

        out.append(".quick-access-bar,\n.quick-access-bar:horizontal {\n")
                .append(hBox(Dim.NavigationBar.HEIGHT))
                .append(padVH(Dim.NavigationBar.PAD_V, Dim.NavigationBar.PAD_H))
                .append(decl("-fx-spacing", Dim.NavigationBar.ITEM_SPACING))
                .append("    -fx-alignment: CENTER_LEFT;\n")
                .append("}\n\n");

        out.append(".quick-nav-button {\n")
                .append(box(Dim.NavigationBar.BUTTON_SIZE))
                .append(decl("-fx-padding", Dim.NavigationBar.BUTTON_PADDING))
                .append(decl("-fx-background-radius", Dim.NavigationBar.BUTTON_RADIUS))
                .append(decl("-fx-border-radius", Dim.NavigationBar.BUTTON_RADIUS))
                .append("}\n\n");

        String r = UIScale.fmt(Dim.NavigationBar.BUTTON_RADIUS);

        // The Root control: one outlined box on hover, two live zones inside.
        out.append(".quick-nav-split {\n")
                .append(hBox(Dim.NavigationBar.BUTTON_SIZE))
                .append(decl("-fx-background-radius", Dim.NavigationBar.BUTTON_RADIUS))
                .append(decl("-fx-border-radius", Dim.NavigationBar.BUTTON_RADIUS))
                .append(decl("-fx-border-width", Dim.NavigationBar.SPLIT_BORDER))
                .append("    -fx-padding: 0;\n")
                .append("    -fx-spacing: 0;\n")
                .append("    -fx-alignment: CENTER_LEFT;\n")
                .append("}\n\n");

        // The zones sit inside the 1px outline, so they are 2px shorter than
        // the control and their outer corners follow its radius.
        double zoneHeight = Dim.NavigationBar.BUTTON_SIZE - (Dim.NavigationBar.SPLIT_BORDER * 2);

        out.append(".quick-nav-split-icon {\n")
                .append(hBox(zoneHeight))
                .append(width(zoneHeight))
                .append(decl("-fx-padding", Dim.NavigationBar.BUTTON_PADDING))
                .append("    -fx-background-radius: ").append(r).append(" 0 0 ").append(r).append(";\n")
                .append("}\n\n");

        out.append(".quick-nav-split-arrow {\n")
                .append(hBox(zoneHeight))
                .append(width(Dim.NavigationBar.SPLIT_ARROW_WIDTH))
                .append("    -fx-padding: 0;\n")
                .append("    -fx-background-radius: 0 ").append(r).append(" ").append(r).append(" 0;\n")
                .append("}\n\n");
    }

    /**
     * The path box, the split pairs inside it, the text field it turns into,
     * its drop-down menus, and the collapse toggle at the end of the row.
     *
     * <h4>Split pairs</h4>
     * <p>
     * A pair is an {@code HBox} with a hairline outline (its left and right
     * vertical lines) holding a name zone and a chevron zone. The chevron zone
     * carries a hairline left border, which is the middle vertical line, and
     * its fill is inset by the same amount so it never paints over that line.
     * All three lines are present at rest in a transparent colour, so hovering
     * moves nothing. The zones sit inside the outline, so they are two pixels
     * shorter than the pair and their corners follow its curve.
     * </p>
     *
     * <h4>Menus</h4>
     * <p>
     * Every drop-down of the quick-access row (breadcrumb chevrons, This PC,
     * right-click, and the navigation bar's Root and Cloud menus) carries
     * {@code .quick-path-menu} and takes the
     * directory explorer's font ({@link DirectoryRowMetrics#fontCss()}) and the
     * Info menu's padding, so the two menus are the same size. Without this the
     * menus inherited the 13px root size and read larger than the tree.
     * </p>
     */
    private static void breadcrumbBar(StringBuilder out) {
        header(out, "BREADCRUMB BAR -- path box, split pairs, path editor, menus, collapse toggle");

        out.append(".quick-path-box {\n")
                .append(hBox(Dim.BreadcrumbBar.BOX_HEIGHT))
                .append(padVH(Dim.BreadcrumbBar.BOX_PAD_V, Dim.BreadcrumbBar.BOX_PAD_H))
                .append(decl("-fx-spacing", Dim.BreadcrumbBar.BOX_SPACING))
                .append(decl("-fx-background-radius", Dim.BreadcrumbBar.BOX_RADIUS))
                .append(decl("-fx-border-radius", Dim.BreadcrumbBar.BOX_RADIUS))
                .append(decl("-fx-border-width", Dim.BreadcrumbBar.BOX_BORDER))
                .append("    -fx-alignment: CENTER_LEFT;\n")
                .append("}\n\n");

        out.append(".quick-path-segments {\n")
                .append(decl("-fx-spacing", Dim.BreadcrumbBar.SEGMENT_SPACING))
                .append("    -fx-alignment: CENTER_LEFT;\n")
                .append("}\n\n");

        // ---- split pair |name|>| -------------------------------------------
        final String zr = UIScale.fmt(Dim.BreadcrumbBar.PAIR_ZONE_RADIUS);
        final String divider = UIScale.fmt(Dim.BreadcrumbBar.PAIR_DIVIDER);

        out.append(".quick-path-pair {\n")
                .append(hBox(Dim.BreadcrumbBar.PAIR_HEIGHT))
                .append("    -fx-padding: 0;\n")
                .append("    -fx-spacing: 0;\n")
                .append("    -fx-alignment: CENTER_LEFT;\n")
                .append(decl("-fx-background-radius", Dim.BreadcrumbBar.CONTROL_RADIUS))
                .append(decl("-fx-border-radius", Dim.BreadcrumbBar.CONTROL_RADIUS))
                .append(decl("-fx-border-width", Dim.BreadcrumbBar.PAIR_BORDER))
                .append("}\n\n");

        out.append(".quick-path-pair-name {\n")
                .append(hBox(Dim.BreadcrumbBar.PAIR_ZONE_HEIGHT))
                .append(padVH(0, Dim.BreadcrumbBar.SEGMENT_PAD_H))
                .append("    -fx-background-insets: 0;\n")
                .append("    -fx-background-radius: ").append(zr).append(" 0 0 ").append(zr).append(";\n")
                .append("    -fx-border-width: 0;\n")
                .append("    -fx-alignment: CENTER;\n")
                .append("    ").append(Typography.css(Typography.Role.BREADCRUMB_SEGMENT)).append("\n")
                .append("}\n\n");

        out.append(".quick-path-pair-arrow {\n")
                .append(hBox(Dim.BreadcrumbBar.PAIR_ZONE_HEIGHT))
                .append(padVH(0, Dim.BreadcrumbBar.SEPARATOR_PAD_H))
                .append("    -fx-background-insets: 0 0 0 ").append(divider).append(";\n")
                .append("    -fx-background-radius: 0 ").append(zr).append(" ").append(zr).append(" 0;\n")
                .append("    -fx-border-width: 0 0 0 ").append(divider).append(";\n")
                .append("    -fx-border-radius: 0;\n")
                .append("    -fx-alignment: CENTER;\n")
                .append("}\n\n");

        // The This PC pair holds a glyph instead of a name.
        out.append(".quick-path-roots > .quick-path-pair-name {\n")
                .append(padVH(0, Dim.BreadcrumbBar.ROOT_BUTTON_PAD_H))
                .append("}\n\n");

        out.append(".quick-path-roots > .quick-path-pair-arrow {\n")
                .append(padVH(0, Dim.BreadcrumbBar.ROOTS_ARROW_PAD_H))
                .append("}\n\n");

        out.append(".quick-path-empty {\n    ")
                .append(Typography.css(Typography.Role.BREADCRUMB_SEGMENT)).append("\n}\n\n");

        out.append(".quick-path-editor {\n")
                .append(hBox(Dim.BreadcrumbBar.EDITOR_HEIGHT))
                .append(pad(0, Dim.BreadcrumbBar.EDITOR_PAD_H, 0, Dim.BreadcrumbBar.EDITOR_PAD_H))
                .append(decl("-fx-background-radius", Dim.BreadcrumbBar.CONTROL_RADIUS))
                .append(decl("-fx-border-radius", Dim.BreadcrumbBar.CONTROL_RADIUS))
                .append(decl("-fx-border-width", Dim.BreadcrumbBar.CONTROL_BORDER))
                .append("    -fx-background-insets: 0;\n")
                .append("    ").append(Typography.css(Typography.Role.BREADCRUMB_EDITOR)).append("\n")
                .append("}\n\n");

        // ---- drop-down menus: the directory explorer's size -------------
        // A menu lives in its own popup window, so it is matched by its own
        // class rather than under .quick-path-box.
        //
        // The Files split buttons' drop-downs (.ribbon-split-dropdown) share
        // these rules, so their entries use this regular menu font rather
        // than the enlarged tool-band size (Typography.TOOL_BAND_TEXT_SCALE
        // is for the label under the icon only). One rule for both keeps the
        // two families of menu from drifting apart. Their widths are set in
        // RibbonSplitButton, not here.
        final String menuFont = DirectoryRowMetrics.fontCss();

        out.append(".context-menu.quick-path-menu,\n.context-menu.ribbon-split-dropdown {\n")
                .append(decl("-fx-padding", Dim.BreadcrumbBar.MENU_PAD))
                .append(decl("-fx-background-radius", Dim.BreadcrumbBar.MENU_RADIUS))
                .append(decl("-fx-border-radius", Dim.BreadcrumbBar.MENU_RADIUS))
                .append("    -fx-border-width: 1;\n")
                .append("}\n\n");

        out.append(".quick-path-menu .menu-item,\n.ribbon-split-dropdown .menu-item {\n")
                .append(padVH(Dim.BreadcrumbBar.MENU_ITEM_PAD_V, Dim.BreadcrumbBar.MENU_ITEM_PAD_H))
                .append(decl("-fx-background-radius", Math.max(0, Dim.BreadcrumbBar.MENU_RADIUS - 1)))
                .append("}\n\n");

        out.append(".quick-path-menu .menu-item .label,\n.ribbon-split-dropdown .menu-item .label {\n    ")
                .append(menuFont).append("\n}\n\n");

        // The subfolder on the current path, or the current drive.
        out.append(".quick-path-menu .menu-item.quick-path-menu-current .label {\n")
                .append("    -fx-font-weight: bold;\n")
                .append("}\n\n");

        out.append(".quick-bar-toggle {\n")
                .append(decl("-fx-background-radius", Dim.BreadcrumbBar.TOGGLE_RADIUS))
                .append("}\n\n");
    }

    /**
     * The Astra-style "There is no such path" dialog: navy title strip, message
     * body with a red error mark, light grey footer with an OK button.
     */
    private static void pathErrorDialog(StringBuilder out) {
        header(out, "PATH ERROR DIALOG -- shown for a path that does not exist");

        out.append(".path-error-dialog {\n")
                .append(width(Dim.BreadcrumbBar.DIALOG_WIDTH))
                .append(decl("-fx-border-width", Dim.BreadcrumbBar.DIALOG_BORDER))
                .append("}\n\n");

        out.append(".path-error-title-bar {\n")
                .append(hBox(Dim.BreadcrumbBar.DIALOG_TITLE_HEIGHT))
                .append(pad(0, Dim.BreadcrumbBar.DIALOG_TITLE_PAD_H / 2, 0,
                        Dim.BreadcrumbBar.DIALOG_TITLE_PAD_H))
                .append("    -fx-alignment: CENTER_LEFT;\n")
                .append("}\n\n");

        out.append(".path-error-title {\n    ")
                .append(Typography.css(Typography.Role.DIALOG_TITLE)).append("\n}\n\n");

        out.append(".path-error-close {\n")
                .append(box(Dim.BreadcrumbBar.DIALOG_CLOSE_SIZE))
                .append("    -fx-padding: 0;\n")
                .append(decl("-fx-background-radius", Dim.BreadcrumbBar.DIALOG_BUTTON_RADIUS))
                .append("    ").append(Typography.css(Typography.Role.DIALOG_TITLE)).append("\n")
                .append("}\n\n");

        out.append(".path-error-body {\n")
                .append(decl("-fx-padding", Dim.BreadcrumbBar.DIALOG_BODY_PAD))
                .append(decl("-fx-spacing", Dim.BreadcrumbBar.DIALOG_BODY_SPACING))
                .append("    -fx-alignment: CENTER_LEFT;\n")
                .append("}\n\n");

        out.append(".path-error-message {\n    ")
                .append(Typography.css(Typography.Role.DIALOG_MESSAGE)).append("\n}\n\n");

        out.append(".path-error-footer {\n")
                .append(padVH(Dim.BreadcrumbBar.DIALOG_FOOTER_PAD_V, Dim.BreadcrumbBar.DIALOG_FOOTER_PAD_H))
                .append("    -fx-border-width: ").append(UIScale.fmt(Dim.BreadcrumbBar.DIALOG_BORDER))
                .append(" 0 0 0;\n")
                .append("    -fx-alignment: CENTER_RIGHT;\n")
                .append("}\n\n");

        out.append(".path-error-ok {\n")
                .append(width(Dim.BreadcrumbBar.DIALOG_BUTTON_WIDTH))
                .append(hBox(Dim.BreadcrumbBar.DIALOG_BUTTON_HEIGHT))
                .append(decl("-fx-background-radius", Dim.BreadcrumbBar.DIALOG_BUTTON_RADIUS))
                .append(decl("-fx-border-radius", Dim.BreadcrumbBar.DIALOG_BUTTON_RADIUS))
                .append(decl("-fx-border-width", Dim.BreadcrumbBar.DIALOG_BORDER))
                .append("    ").append(Typography.css(Typography.Role.DIALOG_BUTTON)).append("\n")
                .append("}\n\n");
    }

    private static void footer(StringBuilder out) {
        header(out, "FOOTER -- status bar");

        // CENTER_LEFT is doing real work here. An HBox defaults to TOP_LEFT,
        // so every child shorter than the tallest one hangs from the top edge
        // instead of sitting on the row's centre line. That was half of the
        // footer's alignment problem; pinning the three indicators to one
        // height (below) is the other half.
        out.append(".app-footer {\n")
                .append(padVH(Dim.Footer.PAD_V, Dim.Footer.PAD_H))
                .append(decl("-fx-spacing", Dim.Footer.ITEM_SPACING))
                .append("    -fx-alignment: CENTER_LEFT;\n")
                .append("}\n\n");

        out.append(".app-footer-label {\n    ")
                .append(Typography.css(Typography.Role.FOOTER_LABEL)).append("\n}\n\n");

        // Height only, never width: the label reads "\u2716 0" and has to be
        // free to grow when the count reaches double figures.
        out.append(".app-footer-button {\n")
                .append(padVH(Dim.Footer.BUTTON_PAD_V, Dim.Footer.BUTTON_PAD_H))
                .append(hBox(Dim.Footer.INDICATOR_SIZE))
                .append(decl("-fx-background-radius", Dim.Footer.INDICATOR_RADIUS))
                .append(decl("-fx-border-radius", Dim.Footer.INDICATOR_RADIUS))
                .append(decl("-fx-border-width", Dim.Footer.INDICATOR_BORDER))
                .append("    ").append(Typography.css(Typography.Role.FOOTER_BUTTON)).append("\n")
                .append("}\n\n");

        // Square, not circular, and the same box on both axes as the two count
        // buttons are tall -- so the three of them read as one set of
        // indicators. The radius, border width and the zero padding all match
        // .app-footer-button; only -fx-shape's old 50em rounding is gone.
        out.append(".footer-theme-toggle {\n")
                .append(box(Dim.Footer.TOGGLE_SIZE))
                .append(decl("-fx-background-radius", Dim.Footer.INDICATOR_RADIUS))
                .append(decl("-fx-border-radius", Dim.Footer.INDICATOR_RADIUS))
                .append(decl("-fx-border-width", Dim.Footer.INDICATOR_BORDER))
                .append("    -fx-padding: 0;\n")
                .append("    -fx-alignment: CENTER;\n")
                .append("    -fx-content-display: GRAPHIC_ONLY;\n")
                .append("}\n");
    }

    // =====================================================================
    // Emitter helpers
    // =====================================================================

    /**
     * The tab label's size and weight, emitted immediately after
     * {@code Typography.css(Role.RIBBON_TAB)} so it overrides the role's own
     * font declarations inside the same rule.
     *
     * <p>
     * Scaling the role's size rather than stating a number keeps the tabs in
     * proportion if the base typography ever changes, and keeps the one place
     * that knows the tabs are 20% up next to the pinned heights that have to
     * contain them.
     * </p>
     *
     * @return the declarations, ready to append
     */
    private static String tabFont() {
        StringBuilder out = new StringBuilder(64);
        out.append(decl("-fx-font-size",
                Typography.size(Typography.Role.RIBBON_TAB) * Dim.RibbonBar.TAB_FONT_SCALE,
                "px"));
        if (Dim.RibbonBar.TAB_FONT_BOLD) {
            out.append("    -fx-font-weight: bold;\n");
        }
        return out.toString();
    }

    private static void header(StringBuilder out, String text) {
        out.append("/* ===== ").append(text).append(" ===== */\n");
    }

    private static String decl(String property, double value) {
        return "    " + property + ": " + UIScale.fmt(value) + ";\n";
    }

    private static String decl(String property, double value, String unit) {
        return "    " + property + ": " + UIScale.fmt(value) + unit + ";\n";
    }

    private static String pad(double top, double right, double bottom, double left) {
        return "    -fx-padding: " + UIScale.fmt(top) + " " + UIScale.fmt(right) + " "
                + UIScale.fmt(bottom) + " " + UIScale.fmt(left) + ";\n";
    }

    /** Four values in CSS order, for insets lists. */
    private static String insets(double top, double right, double bottom, double left) {
        return UIScale.fmt(top) + " " + UIScale.fmt(right) + " "
                + UIScale.fmt(bottom) + " " + UIScale.fmt(left);
    }

    private static String padVH(double vertical, double horizontal) {
        return "    -fx-padding: " + UIScale.fmt(vertical) + " " + UIScale.fmt(horizontal)
                + " " + UIScale.fmt(vertical) + " " + UIScale.fmt(horizontal) + ";\n";
    }

    /** min, pref and max height pinned to one value. */
    private static String hBox(double height) {
        String h = UIScale.fmt(height);
        return "    -fx-min-height: " + h + ";\n"
                + "    -fx-pref-height: " + h + ";\n"
                + "    -fx-max-height: " + h + ";\n";
    }

    /** min, pref and max width pinned to one value. */
    private static String width(double value) {
        String w = UIScale.fmt(value);
        return "    -fx-min-width: " + w + ";\n"
                + "    -fx-pref-width: " + w + ";\n"
                + "    -fx-max-width: " + w + ";\n";
    }

    /** A square box: min, pref and max on both axes. */
    private static String box(double size) {
        return width(size) + hBox(size);
    }

    /**
     * A downward-pointing triangle as an {@code -fx-shape} path, generated at
     * the requested size so the glyph tracks the scale factor. {@code
     * -fx-scale-shape} stays false: the path is already the right size, and
     * letting JavaFX stretch it would round differently.
     */
    private static String triangle(double width, double height) {
        return "    -fx-shape: \"M 0 0 L " + UIScale.fmt(width) + " 0 L "
                + UIScale.fmt(width / 2.0) + " " + UIScale.fmt(height) + " Z\";\n"
                + "    -fx-scale-shape: false;\n";
    }

    // =====================================================================
    // Attachment
    // =====================================================================

    private static synchronized String uri() {
        if (cachedUri != null) {
            return cachedUri;
        }
        String css = css();
        maybeDump(css);
        cachedUri = "data:text/css;base64,"
                + Base64.getEncoder().encodeToString(css.getBytes(StandardCharsets.UTF_8));
        return cachedUri;
    }

    private static void moveToEnd(Scene scene) {
        String uri = cachedUri;
        if (uri == null) {
            return;
        }
        int last = scene.getStylesheets().size() - 1;
        int at = scene.getStylesheets().indexOf(uri);
        if (at == last) {
            return;
        }
        reordering = true;
        try {
            if (at >= 0) {
                scene.getStylesheets().remove(at);
            }
            scene.getStylesheets().add(uri);
        } finally {
            reordering = false;
        }
    }

    private static void maybeDump(String css) {
        if (!Boolean.getBoolean(DUMP_PROPERTY)) {
            return;
        }
        try {
            Path target = Path.of("astra-design.css");
            Files.writeString(target, css, StandardCharsets.UTF_8);
            System.out.println("Design stylesheet written to " + target.toAbsolutePath());
        } catch (IOException ex) {
            System.err.println("Could not write the design stylesheet: " + ex.getMessage());
        }
    }
}
