package ui.design;

import java.net.URL;
import java.util.List;

import javafx.application.Platform;
import javafx.collections.ListChangeListener;
import javafx.scene.Scene;

/**
 * Keeps the ribbon's colour sheet attached to the scene and in step with the
 * active theme.
 *
 * <h3>Why the ribbon has its own stylesheet</h3>
 * <p>
 * {@code light.css} and {@code dark.css} had grown past the point where the
 * ribbon block could be found in them, let alone edited with any confidence --
 * the same problem that moved the editor tokens to {@code themes/editorColor}
 * and the fold colours to {@code themes/folding}. Every colour belonging to the
 * Row-1 tab strip, the Row-2 band and the controls inside it now lives in
 * {@code themes/ribbon/ribbon_light.css} and {@code ribbon_dark.css}, and the
 * two base theme files keep everything else.
 * </p>
 *
 * <h3>How the right one gets loaded</h3>
 * <p>
 * This class does not need to be told which theme is active and
 * {@code ThemeManager} does not need to know these files exist. It watches the
 * scene's stylesheet list: whenever {@code dark.css} is in it, the dark ribbon
 * sheet is attached and the light one removed, and the other way round. The
 * base theme file is matched on its exact file name, so
 * {@code editor_dark.css} and {@code fold_dark.css} are correctly ignored.
 * </p>
 *
 * <h3>Order</h3>
 * <p>
 * The ribbon sheet is appended after the base theme so its rules win ties, and
 * left alone once it is there. It deliberately does not fight
 * {@link DesignStylesheet} for the last slot -- that sheet carries geometry
 * only and this one carries colours only, so they never collide, and two
 * listeners both insisting on being last would ping-pong forever.
 * </p>
 *
 * <p>
 * Installed from {@link DesignStylesheet#install(Scene)}, so no call site has
 * to change.
 * </p>
 */
public final class RibbonTheme {

    /** Classpath location of the light ribbon colours. */
    public static final String LIGHT_RESOURCE = "/themes/ribbon/ribbon_light.css";

    /** Classpath location of the dark ribbon colours. */
    public static final String DARK_RESOURCE = "/themes/ribbon/ribbon_dark.css";

    /** File name of the light base theme, matched exactly. */
    private static final String LIGHT_BASE = "light.css";

    /** File name of the dark base theme, matched exactly. */
    private static final String DARK_BASE = "dark.css";

    private static String lightUri;
    private static String darkUri;
    private static boolean resolved;
    private static boolean syncing;

    private RibbonTheme() {
    }

    /**
     * Attaches the correct ribbon sheet and keeps it correct for the life of
     * the scene.
     *
     * @param scene the application scene
     */
    public static void install(Scene scene) {
        if (scene == null) {
            return;
        }
        resolve();
        if (lightUri == null && darkUri == null) {
            return;
        }

        sync(scene);

        scene.getStylesheets().addListener((ListChangeListener<String>) change -> {
            if (syncing) {
                return;
            }
            Platform.runLater(() -> sync(scene));
        });
    }

    /**
     * @return the URI of the sheet currently wanted for this scene, or
     *         {@code null} if neither could be resolved
     */
    public static String activeUri(Scene scene) {
        resolve();
        return isDark(scene) ? darkUri : lightUri;
    }

    // =====================================================================
    // Internals
    // =====================================================================

    private static synchronized void resolve() {
        if (resolved) {
            return;
        }
        resolved = true;
        lightUri = toUri(LIGHT_RESOURCE);
        darkUri = toUri(DARK_RESOURCE);
    }

    private static String toUri(String resource) {
        URL url = RibbonTheme.class.getResource(resource);
        if (url == null) {
            System.err.println("Ribbon stylesheet not on the classpath: " + resource
                    + " -- expected at src/main/resources" + resource);
            return null;
        }
        return url.toExternalForm();
    }

    /**
     * Ensures exactly one ribbon sheet is present and that it sits after the
     * base theme. Does nothing if that is already true, which is what keeps
     * this listener from looping against {@link DesignStylesheet}'s.
     */
    private static void sync(Scene scene) {
        List<String> sheets = scene.getStylesheets();

        boolean dark = isDark(scene);
        String wanted = dark ? darkUri : lightUri;
        String unwanted = dark ? lightUri : darkUri;

        if (wanted == null) {
            return;
        }

        int baseAt = baseIndex(sheets);
        int wantedAt = sheets.indexOf(wanted);
        boolean unwantedPresent = unwanted != null && sheets.contains(unwanted);
        boolean ordered = wantedAt >= 0 && (baseAt < 0 || wantedAt > baseAt);

        if (ordered && !unwantedPresent) {
            return;
        }

        syncing = true;
        try {
            if (unwantedPresent) {
                sheets.remove(unwanted);
            }
            if (wantedAt >= 0) {
                sheets.remove(wanted);
            }
            sheets.add(wanted);
        } finally {
            syncing = false;
        }
    }

    private static boolean isDark(Scene scene) {
        for (String sheet : scene.getStylesheets()) {
            if (DARK_BASE.equalsIgnoreCase(fileName(sheet))) {
                return true;
            }
        }
        return false;
    }

    private static int baseIndex(List<String> sheets) {
        for (int i = 0; i < sheets.size(); i++) {
            String name = fileName(sheets.get(i));
            if (LIGHT_BASE.equalsIgnoreCase(name) || DARK_BASE.equalsIgnoreCase(name)) {
                return i;
            }
        }
        return -1;
    }

    /**
     * The last path segment of a stylesheet URI. Comparing whole names rather
     * than testing {@code endsWith("dark.css")} is what stops
     * {@code editor_dark.css} and {@code fold_dark.css} from being mistaken
     * for the base theme.
     */
    private static String fileName(String uri) {
        if (uri == null) {
            return "";
        }
        int slash = uri.lastIndexOf('/');
        return (slash >= 0) ? uri.substring(slash + 1) : uri;
    }
}
