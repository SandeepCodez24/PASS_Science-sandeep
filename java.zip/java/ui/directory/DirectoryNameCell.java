package ui.directory;

import java.nio.file.Files;
import java.nio.file.Path;
import javafx.application.Platform;
import javafx.beans.InvalidationListener;
import javafx.beans.WeakInvalidationListener;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.css.PseudoClass;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeTableCell;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.stage.Window;
import ui.design.Dim;
import ui.design.section_dims.DirectoryMenu_dim;
import ui.editor.navigation.NavigationActions;

/**
 * The Name column: the disclosure triangle, the file-type icon and the name.
 *
 * <p>
 * The JavaFX tree column draws the triangle and the indent itself, so this cell
 * is responsible only for the icon and the text. The triangle remaining the
 * column's own is what lets it keep working as the sole way to expand a folder
 * now that a double-click means something else.
 * </p>
 *
 * <h3>In-place rename</h3>
 * <p>
 * Renaming used to open a {@code TextInputDialog}. It now happens in the row,
 * as in Windows Explorer and every IDE: the name turns into a text field beside
 * the icon, with the part before the extension selected (the whole name for a
 * folder).
 * </p>
 * <ul>
 * <li><b>Enter</b> or <b>Tab</b> commits; <b>Esc</b> cancels.</li>
 * <li><b>Clicking away</b> commits. If the name is not valid at that moment,
 * the rename is dropped and the old name stays.</li>
 * <li>An invalid name on Enter -- a duplicate, a forbidden character, a
 * reserved word -- shows a red note under the field and keeps it open.</li>
 * </ul>
 *
 * <h3>Neural Code names</h3>
 * <p>
 * A file whose name ends in {@code .nc} follows the naming rule in
 * {@link NcFileNames}: a letter first, then letters, digits and underscores.
 * As in MATLAB's Current Folder, the rule is checked while the name is typed:
 * </p>
 * <ul>
 * <li>As soon as the name breaks the rule, an amber note appears under the
 * field saying why ({@link DirectoryRenameHint}). It follows every key stroke
 * and goes away once the name is valid. It also appears when the field opens
 * on an existing file whose name already breaks the rule.</li>
 * <li><b>Spaces</b> are corrected on commit: each run of spaces becomes one
 * underscore ({@code test 01.nc} is saved as {@code test_01.nc}), and the
 * Command Window says so. This happens on Enter and on clicking away.</li>
 * <li>Any other break -- a leading digit, a hyphen -- is refused on Enter
 * with a red note, and the field stays open. Clicking away drops the rename,
 * as for any invalid name.</li>
 * <li>Pressing Enter on an unchanged name never changes anything, except
 * that a name whose only fault is spaces is corrected -- the note said it
 * would be. A legacy name with any other fault is left as it is.</li>
 * </ul>
 * <p>
 * Folders and non-.nc files are not affected.
 * </p>
 *
 * <h3>Not JavaFX's editing machinery</h3>
 * <p>
 * The cell does not use JavaFX's own table-editing machinery. That machinery
 * also starts an edit on a plain click of a selected row and on a double-click,
 * both of which would fight the double-click-to-open behaviour. Instead,
 * {@link DirectoryTreeBuilder} publishes the path being renamed, and the one
 * cell showing that path turns its field on. If that cell is recycled for a
 * different row (the tree scrolled), the rename is cancelled.
 * </p>
 *
 * <h3>Group title rows</h3>
 * <p>
 * While <b>Group by</b> is on, some rows are {@link DirectoryGroupItem}s with
 * no path. This cell draws them as a title, a count and a thin rule running
 * to the right edge, as Windows Explorer does; the row itself carries the
 * {@code :group} pseudo-class (set by the tree's row factory).
 * </p>
 *
 * <h3>Context menu</h3>
 * <p>
 * The cell no longer owns a context menu. The tree opens one of its two menus
 * itself ({@code DirectoryTreeBuilder}), because an empty-space click has no
 * cell, and because a menu attached to a cell registers its shortcuts with the
 * whole window.
 * </p>
 *
 * <h3>Cut</h3>
 * <p>
 * The item waiting to be pasted after a Cut is drawn dimmed (the {@code :cut}
 * pseudo-class), until it is pasted or the clipboard changes.
 * </p>
 *
 * <h3>Icon sharpness</h3>
 * <p>
 * The icon view is sized in logical pixels ({@link Dim.Directory#FILE_ICON_SIZE}),
 * while the image in it is decoded at the physical size of the window this
 * cell is in -- 16 px at 100%, 20 px at 125%, 24 px at 150% -- so it reaches
 * the screen without any further scaling. When the window moves to a monitor
 * with a different scale, the cell notices and decodes again.
 * </p>
 */
public final class DirectoryNameCell extends TreeTableCell<Path, Path> {

    /** Style class of the rename field; sized in the generated sheet, coloured in the theme. */
    static final String RENAME_FIELD_CLASS = "directory-rename-field";

    /**
     * Style class of the note under the field, warning and error alike. The
     * generated sheet sizes it; the theme colours it red, and amber with
     * {@link DirectoryRenameHint#WARNING_CLASS}.
     */
    static final String RENAME_ERROR_CLASS = "directory-rename-error";

    /** Style classes of a group title row's parts. */
    static final String GROUP_TITLE_CLASS = "directory-group-title";
    static final String GROUP_COUNT_CLASS = "directory-group-count";
    static final String GROUP_RULE_CLASS = "directory-group-rule";

    private static final PseudoClass CUT = PseudoClass.getPseudoClass("cut");

    private final ImageView iconView = new ImageView();

    // ---- group title --------------------------------------------------------
    private final Label groupTitle = new Label();
    private final Label groupCount = new Label();
    private final Region groupRule = new Region();
    private final HBox groupBox;

    /** The window this cell is shown in, tracked through its scene. */
    private final ObservableValue<Window> window = sceneProperty().flatMap(Scene::windowProperty);

    /**
     * Held strongly here and registered weakly on the window, so a discarded
     * cell never stays reachable through the window's scale properties.
     */
    private final InvalidationListener scaleListener = observable -> refreshIcon();
    private final WeakInvalidationListener weakScaleListener = new WeakInvalidationListener(scaleListener);

    /** Same pattern for the "which path is being renamed" property. */
    private final InvalidationListener renameListener = observable -> syncRename();

    /** Scale and theme the current image was decoded for; avoids redundant work. */
    private double iconScale = -1;
    private boolean iconDark;
    private Path iconPath;

    // ---- rename state ---------------------------------------------------
    private boolean renaming;
    private boolean finishing;
    private Path renamingPath;
    /** True when the item being renamed is a folder: the .nc rule does not apply. */
    private boolean renamingFolder;
    private TextField field;
    private HBox editBox;
    /** Created on the first note; most cells never need one. */
    private DirectoryRenameHint hint;
    private ChangeListener<Boolean> focusListener;

    public DirectoryNameCell() {
        iconView.setFitWidth(Dim.Directory.FILE_ICON_SIZE);
        iconView.setFitHeight(Dim.Directory.FILE_ICON_SIZE);
        iconView.setPreserveRatio(true);
        iconView.setSmooth(true);
        setGraphicTextGap(Dim.Directory.ICON_GAP);
        getStyleClass().add("directory-name-cell");

        groupTitle.getStyleClass().add(GROUP_TITLE_CLASS);
        groupCount.getStyleClass().add(GROUP_COUNT_CLASS);
        groupRule.getStyleClass().add(GROUP_RULE_CLASS);
        groupRule.setMinHeight(DirectoryMenu_dim.GROUP_RULE_HEIGHT);
        groupRule.setPrefHeight(DirectoryMenu_dim.GROUP_RULE_HEIGHT);
        groupRule.setMaxHeight(DirectoryMenu_dim.GROUP_RULE_HEIGHT);
        groupRule.setMinWidth(0);
        HBox.setHgrow(groupRule, Priority.ALWAYS);
        groupBox = new HBox(DirectoryMenu_dim.GROUP_HEADER_GAP, groupTitle, groupCount, groupRule);
        groupBox.setAlignment(Pos.CENTER_LEFT);
        groupBox.setMinWidth(0);

        window.addListener((observable, oldWindow, newWindow) -> watchWindow(oldWindow, newWindow));
        watchWindow(null, window.getValue());

        DirectoryTreeBuilder.renameTargetProperty().addListener(new WeakInvalidationListener(renameListener));
    }

    @Override
    protected void updateItem(Path item, boolean empty) {
        super.updateItem(item, empty);

        // Recycled for another row while its field was open: the tree
        // scrolled. Drop the rename rather than carry the field elsewhere.
        if (renaming && (empty || item == null || !item.equals(renamingPath))) {
            stopRename();
            Platform.runLater(DirectoryTreeBuilder::cancelRename);
        }

        pseudoClassStateChanged(CUT, false);

        TreeItem<Path> treeItem = getTableRow() == null ? null : getTableRow().getTreeItem();
        if (!empty && treeItem instanceof DirectoryGroupItem group) {
            showGroup(group);
            return;
        }

        if (empty || item == null) {
            setText(null);
            setGraphic(null);
            setContentDisplay(ContentDisplay.LEFT);
            iconPath = null;
            return;
        }

        setContentDisplay(renaming ? ContentDisplay.GRAPHIC_ONLY : ContentDisplay.LEFT);
        pseudoClassStateChanged(CUT, item.equals(DirectoryTreeBuilder.cutTarget()));

        if (!renaming) {
            setText(DirectoryRename.nameOf(item));
        }

        // A reused cell may be showing a different file of the same scale, so
        // always re-resolve here; the resolver's cache makes this cheap.
        iconPath = null;
        refreshIcon();

        if (!renaming && item.equals(DirectoryTreeBuilder.renameTargetProperty().get())) {
            Platform.runLater(this::syncRename);
        }
    }

    // =====================================================================
    // Icon
    // =====================================================================

    /**
     * Decodes the icon for the current item at the current window scale, if
     * the item, the scale or the theme has changed since the last decode.
     */
    private void refreshIcon() {
        Path item = getItem();
        if (isEmpty() || item == null
                || (getTableRow() != null && getTableRow().getTreeItem() instanceof DirectoryGroupItem)) {
            return;
        }

        double scale = DirectoryFileIconResolver.outputScaleOf(this);
        boolean dark = DirectoryFileIconResolver.isDarkTheme();
        if (item.equals(iconPath) && scale == iconScale && dark == iconDark) {
            return;
        }

        Image icon = DirectoryFileIconResolver.resolve(item, Dim.Directory.FILE_ICON_SIZE, scale);
        iconView.setImage(icon);
        if (!renaming) {
            // While renaming, the icon sits inside the edit box and stays there.
            setGraphic(icon == null ? null : iconView);
        }
        iconPath = item;
        iconScale = scale;
        iconDark = dark;
    }

    /**
     * Moves the scale listener from the old window to the new one, and
     * re-decodes, since the new window may be on a different monitor.
     */
    private void watchWindow(Window oldWindow, Window newWindow) {
        if (oldWindow != null) {
            oldWindow.outputScaleXProperty().removeListener(weakScaleListener);
            oldWindow.outputScaleYProperty().removeListener(weakScaleListener);
        }
        if (newWindow != null) {
            newWindow.outputScaleXProperty().addListener(weakScaleListener);
            newWindow.outputScaleYProperty().addListener(weakScaleListener);
        }
        refreshIcon();
    }

    // =====================================================================
    // Group title
    // =====================================================================

    private void showGroup(DirectoryGroupItem group) {
        iconPath = null;
        groupTitle.setText(group.title());
        groupCount.setText("(" + group.count() + ")");
        setText(null);
        setGraphic(groupBox);
        setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
    }

    // =====================================================================
    // In-place rename
    // =====================================================================

    /** Turns the field on or off to match the path the builder is renaming. */
    private void syncRename() {
        Path target = DirectoryTreeBuilder.renameTargetProperty().get();
        Path item = getItem();
        boolean should = target != null && !isEmpty() && target.equals(item);
        if (should && !renaming) {
            startRename();
        } else if (!should && renaming) {
            stopRename();
        }
    }

    private void startRename() {
        Path item = getItem();
        if (item == null) {
            return;
        }
        renaming = true;
        renamingPath = item;
        renamingFolder = Files.isDirectory(item);

        String name = DirectoryRename.nameOf(item);
        field = new TextField(name);
        field.getStyleClass().add(RENAME_FIELD_CLASS);
        field.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(field, Priority.ALWAYS);

        editBox = new HBox(Dim.Directory.ICON_GAP, iconView, field);
        editBox.setAlignment(Pos.CENTER_LEFT);
        editBox.setFillHeight(false);

        setText(null);
        setGraphic(editBox);
        setContentDisplay(ContentDisplay.GRAPHIC_ONLY);

        field.addEventFilter(KeyEvent.KEY_PRESSED, event -> {
            switch (event.getCode()) {
                case ENTER, TAB -> {
                    commit(false);
                    event.consume();
                }
                case ESCAPE -> {
                    cancelFromUser();
                    event.consume();
                }
                // Keep the arrow keys in the field; otherwise the table would
                // move its selection out from under the open rename.
                case UP, DOWN, PAGE_UP, PAGE_DOWN -> event.consume();
                default -> {
                }
            }
        });
        // Every key stroke re-checks the name: a red note from a refused
        // Enter gives way to the live warning, or to nothing.
        field.textProperty().addListener((observable, was, isNow) -> updateHint());
        focusListener = (observable, was, isNow) -> {
            if (!isNow && renaming && !finishing) {
                commit(true);
            }
        };
        field.focusedProperty().addListener(focusListener);

        int selectEnd = DirectoryRename.selectionEnd(item, name);
        Platform.runLater(() -> {
            if (field != null && renaming) {
                field.requestFocus();
                field.selectRange(0, selectEnd);
                // One more pulse, so the field has its place on screen before
                // a note for an already-invalid name is positioned under it.
                Platform.runLater(this::updateHint);
            }
        });
    }

    /** Puts the plain name back. Safe to call more than once. */
    private void stopRename() {
        if (!renaming) {
            return;
        }
        renaming = false;
        renamingPath = null;
        renamingFolder = false;
        hideHint();
        if (field != null && focusListener != null) {
            field.focusedProperty().removeListener(focusListener);
        }
        field = null;
        focusListener = null;
        if (editBox != null) {
            editBox.getChildren().clear(); // releases the icon view
        }
        editBox = null;

        setContentDisplay(ContentDisplay.LEFT);
        Path item = getItem();
        if (isEmpty() || item == null) {
            setText(null);
            setGraphic(null);
            return;
        }
        setText(DirectoryRename.nameOf(item));
        setGraphic(iconView.getImage() == null ? null : iconView);
    }

    /**
     * @param focusLoss true when the field lost focus (a click elsewhere):
     *                  an invalid name then abandons the rename instead of
     *                  keeping the field open
     */
    private void commit(boolean focusLoss) {
        if (!renaming || finishing || field == null) {
            return;
        }
        String typed = typedName();
        String original = DirectoryRename.nameOf(renamingPath);
        boolean unchanged = typed.equals(original);

        // Clicking away from an untouched field changes nothing, even when
        // the name breaks the rule: only a deliberate Enter corrects it.
        if (unchanged && focusLoss) {
            finish(false);
            return;
        }

        String toCommit = typed;
        boolean corrected = false;
        if (!renamingFolder) {
            NcFileNames.Check check = NcFileNames.check(typed);
            if (check.isFixable()) {
                toCommit = check.name();
                corrected = true;
            } else if (check.isInvalid()) {
                if (unchanged || focusLoss) {
                    // An old name left as it was, or a click away from a bad
                    // one: close and keep the name the file already has.
                    finish(!focusLoss);
                    return;
                }
                showHint(DirectoryRenameHint.Level.ERROR, check.message());
                field.requestFocus();
                return;
            }
        }

        String error = DirectoryTreeBuilder.commitRename(
                getTableRow() == null ? null : getTableRow().getTreeItem(), toCommit);
        if (error == null) {
            if (corrected && !toCommit.equals(original)) {
                NavigationActions.say("Renamed to " + toCommit
                        + ". Spaces are not allowed in .nc file names, so they were replaced with underscores.");
            }
            finish(!focusLoss);
            return;
        }
        if (focusLoss) {
            finish(false);
            return;
        }
        showHint(DirectoryRenameHint.Level.ERROR, error);
        field.requestFocus();
    }

    private void cancelFromUser() {
        finish(true);
    }

    private void finish(boolean returnFocusToTree) {
        finishing = true;
        try {
            DirectoryTreeBuilder.cancelRename(); // clears the target; syncRename stops the field
            stopRename();
            if (returnFocusToTree && getTreeTableView() != null) {
                getTreeTableView().requestFocus();
            }
        } finally {
            finishing = false;
        }
    }

    // =====================================================================
    // The note under the field
    // =====================================================================

    /**
     * The live check: an amber note while a .nc name breaks the rule, nothing
     * otherwise. Folders and other files never get one.
     */
    private void updateHint() {
        if (!renaming || field == null) {
            return;
        }
        if (renamingFolder) {
            hideHint();
            return;
        }
        NcFileNames.Check check = NcFileNames.check(typedName());
        if (check.isValid()) {
            hideHint();
        } else {
            showHint(DirectoryRenameHint.Level.WARNING, check.message());
        }
    }

    private void showHint(DirectoryRenameHint.Level level, String message) {
        if (field == null) {
            return;
        }
        if (hint == null) {
            hint = new DirectoryRenameHint();
        }
        hint.show(field, level, message);
    }

    private void hideHint() {
        if (hint != null) {
            hint.hide();
        }
    }

    /** What is in the field, with white space at either end removed. */
    private String typedName() {
        String text = field == null ? null : field.getText();
        return text == null ? "" : text.strip();
    }
}
