package ui.directory;

import java.nio.file.Path;
import java.util.function.Function;
import javafx.beans.InvalidationListener;
import javafx.beans.WeakInvalidationListener;
import javafx.beans.value.ObservableValue;
import javafx.scene.Scene;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.TreeTableCell;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Window;
import ui.design.Dim;

/**
 * The Name column: the disclosure triangle, the file-type icon and the name.
 *
 * <p>
 * The JavaFX tree column draws the triangle and the indent itself, so this cell
 * is responsible only for the icon and the text. The triangle remaining the
 * column's own is what lets it keep working as the sole way to expand a folder
 * now that a double-click means something else.
 * </p>
 *
 * <h3>Icon sharpness</h3>
 * <p>
 * The icon view is sized in logical pixels ({@link Dim.Directory#FILE_ICON_SIZE}),
 * while the image in it is decoded at the physical size of the window this
 * cell is in -- 16 px at 100%, 20 px at 125%, 24 px at 150% -- so it reaches
 * the screen without any further scaling. When the window moves to a monitor
 * with a different scale, the cell notices and decodes again.
 * </p>
 */
public final class DirectoryNameCell extends TreeTableCell<Path, Path> {

    private final Function<Path, ContextMenu> contextMenuFactory;
    private final ImageView iconView = new ImageView();

    /** The window this cell is shown in, tracked through its scene. */
    private final ObservableValue<Window> window = sceneProperty().flatMap(Scene::windowProperty);

    /**
     * Held strongly here and registered weakly on the window, so a discarded
     * cell never stays reachable through the window's scale properties.
     */
    private final InvalidationListener scaleListener = observable -> refreshIcon();
    private final WeakInvalidationListener weakScaleListener = new WeakInvalidationListener(scaleListener);

    /** Scale and theme the current image was decoded for; avoids redundant work. */
    private double iconScale = -1;
    private boolean iconDark;
    private Path iconPath;

    /**
     * @param contextMenuFactory builds the right-click menu for a path; may be
     *                           null for no menu
     */
    public DirectoryNameCell(Function<Path, ContextMenu> contextMenuFactory) {
        this.contextMenuFactory = contextMenuFactory;
        iconView.setFitWidth(Dim.Directory.FILE_ICON_SIZE);
        iconView.setFitHeight(Dim.Directory.FILE_ICON_SIZE);
        iconView.setPreserveRatio(true);
        iconView.setSmooth(true);
        setGraphicTextGap(Dim.Directory.ICON_GAP);
        getStyleClass().add("directory-name-cell");
        setOnContextMenuRequested(event -> refreshContextMenu());

        window.addListener((observable, oldWindow, newWindow) -> watchWindow(oldWindow, newWindow));
        watchWindow(null, window.getValue());
    }

    @Override
    protected void updateItem(Path item, boolean empty) {
        super.updateItem(item, empty);

        if (empty || item == null) {
            setText(null);
            setGraphic(null);
            setContextMenu(null);
            iconPath = null;
            return;
        }

        Path fileName = item.getFileName();
        setText(fileName == null ? item.toString() : fileName.toString());

        // A reused cell may be showing a different file of the same scale, so
        // always re-resolve here; the resolver's cache makes this cheap.
        iconPath = null;
        refreshIcon();
        setContextMenu(null);
    }

    // =====================================================================
    // Icon
    // =====================================================================

    /**
     * Decodes the icon for the current item at the current window scale, if
     * the item, the scale or the theme has changed since the last decode.
     */
    private void refreshIcon() {
        Path item = getItem();
        if (isEmpty() || item == null) {
            return;
        }

        double scale = DirectoryFileIconResolver.outputScaleOf(this);
        boolean dark = DirectoryFileIconResolver.isDarkTheme();
        if (item.equals(iconPath) && scale == iconScale && dark == iconDark) {
            return;
        }

        Image icon = DirectoryFileIconResolver.resolve(item, Dim.Directory.FILE_ICON_SIZE, scale);
        if (icon == null) {
            iconView.setImage(null);
            setGraphic(null);
        } else {
            iconView.setImage(icon);
            setGraphic(iconView);
        }
        iconPath = item;
        iconScale = scale;
        iconDark = dark;
    }

    /**
     * Moves the scale listener from the old window to the new one, and
     * re-decodes, since the new window may be on a different monitor.
     */
    private void watchWindow(Window oldWindow, Window newWindow) {
        if (oldWindow != null) {
            oldWindow.outputScaleXProperty().removeListener(weakScaleListener);
            oldWindow.outputScaleYProperty().removeListener(weakScaleListener);
        }
        if (newWindow != null) {
            newWindow.outputScaleXProperty().addListener(weakScaleListener);
            newWindow.outputScaleYProperty().addListener(weakScaleListener);
        }
        refreshIcon();
    }

    // =====================================================================
    // Context menu
    // =====================================================================

    /**
     * Builds the menu on demand rather than on every {@code updateItem}, since
     * the menu's enabled/disabled state is a snapshot of the clipboard and the
     * undo stack at the moment of the click.
     */
    private void refreshContextMenu() {
        Path item = getItem();
        if (isEmpty() || item == null || contextMenuFactory == null) {
            setContextMenu(null);
            return;
        }
        if (getTreeTableView() != null && getTableRow() != null && getTableRow().getIndex() >= 0) {
            getTreeTableView().getSelectionModel().select(getTableRow().getIndex());
        }
        setContextMenu(contextMenuFactory.apply(item));
    }
}
