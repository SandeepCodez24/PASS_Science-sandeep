package ui.directory;

import java.nio.file.Path;
import java.util.function.Function;
import javafx.application.Platform;
import javafx.beans.InvalidationListener;
import javafx.beans.WeakInvalidationListener;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Bounds;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.control.TreeTableCell;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.stage.Window;
import ui.design.Dim;

/**
 * The Name column: the disclosure triangle, the file-type icon and the name.
 *
 * <p>
 * The JavaFX tree column draws the triangle and the indent itself, so this cell
 * is responsible only for the icon and the text. The triangle remaining the
 * column's own is what lets it keep working as the sole way to expand a folder
 * now that a double-click means something else.
 * </p>
 *
 * <h3>In-place rename</h3>
 * <p>
 * Renaming used to open a {@code TextInputDialog}. It now happens in the row,
 * as in Windows Explorer and every IDE: the name turns into a text field beside
 * the icon, with the part before the extension selected (the whole name for a
 * folder).
 * </p>
 * <ul>
 * <li><b>Enter</b> or <b>Tab</b> commits; <b>Esc</b> cancels.</li>
 * <li><b>Clicking away</b> commits. If the name is not valid at that moment,
 * the rename is dropped and the old name stays.</li>
 * <li>An invalid name on Enter -- a duplicate, a forbidden character, a
 * reserved word -- shows a red note under the field and keeps it open. The note
 * goes as soon as the text changes.</li>
 * </ul>
 * <p>
 * The cell does not use JavaFX's own table-editing machinery. That machinery
 * also starts an edit on a plain click of a selected row and on a double-click,
 * both of which would fight the double-click-to-open behaviour. Instead,
 * {@link DirectoryTreeBuilder} publishes the path being renamed, and the one
 * cell showing that path turns its field on. If that cell is recycled for a
 * different row (the tree scrolled), the rename is cancelled.
 * </p>
 *
 * <h3>Icon sharpness</h3>
 * <p>
 * The icon view is sized in logical pixels ({@link Dim.Directory#FILE_ICON_SIZE}),
 * while the image in it is decoded at the physical size of the window this
 * cell is in -- 16 px at 100%, 20 px at 125%, 24 px at 150% -- so it reaches
 * the screen without any further scaling. When the window moves to a monitor
 * with a different scale, the cell notices and decodes again.
 * </p>
 */
public final class DirectoryNameCell extends TreeTableCell<Path, Path> {

    /** Style class of the rename field; sized in the generated sheet, coloured in the theme. */
    static final String RENAME_FIELD_CLASS = "directory-rename-field";

    /** Style class of the red note under the field. */
    static final String RENAME_ERROR_CLASS = "directory-rename-error";

    private final Function<Path, ContextMenu> contextMenuFactory;
    private final ImageView iconView = new ImageView();

    /** The window this cell is shown in, tracked through its scene. */
    private final ObservableValue<Window> window = sceneProperty().flatMap(Scene::windowProperty);

    /**
     * Held strongly here and registered weakly on the window, so a discarded
     * cell never stays reachable through the window's scale properties.
     */
    private final InvalidationListener scaleListener = observable -> refreshIcon();
    private final WeakInvalidationListener weakScaleListener = new WeakInvalidationListener(scaleListener);

    /** Same pattern for the "which path is being renamed" property. */
    private final InvalidationListener renameListener = observable -> syncRename();

    /** Scale and theme the current image was decoded for; avoids redundant work. */
    private double iconScale = -1;
    private boolean iconDark;
    private Path iconPath;

    // ---- rename state ---------------------------------------------------
    private boolean renaming;
    private boolean finishing;
    private Path renamingPath;
    private TextField field;
    private HBox editBox;
    private Tooltip errorTip;
    private ChangeListener<Boolean> focusListener;

    /**
     * @param contextMenuFactory builds the right-click menu for a path; may be
     *                           null for no menu
     */
    public DirectoryNameCell(Function<Path, ContextMenu> contextMenuFactory) {
        this.contextMenuFactory = contextMenuFactory;
        iconView.setFitWidth(Dim.Directory.FILE_ICON_SIZE);
        iconView.setFitHeight(Dim.Directory.FILE_ICON_SIZE);
        iconView.setPreserveRatio(true);
        iconView.setSmooth(true);
        setGraphicTextGap(Dim.Directory.ICON_GAP);
        getStyleClass().add("directory-name-cell");
        setOnContextMenuRequested(event -> refreshContextMenu());

        window.addListener((observable, oldWindow, newWindow) -> watchWindow(oldWindow, newWindow));
        watchWindow(null, window.getValue());

        DirectoryTreeBuilder.renameTargetProperty().addListener(new WeakInvalidationListener(renameListener));
    }

    @Override
    protected void updateItem(Path item, boolean empty) {
        super.updateItem(item, empty);

        // Recycled for another row while its field was open: the tree
        // scrolled. Drop the rename rather than carry the field elsewhere.
        if (renaming && (empty || item == null || !item.equals(renamingPath))) {
            stopRename();
            Platform.runLater(DirectoryTreeBuilder::cancelRename);
        }

        if (empty || item == null) {
            setText(null);
            setGraphic(null);
            setContextMenu(null);
            iconPath = null;
            return;
        }

        if (!renaming) {
            setText(DirectoryRename.nameOf(item));
        }

        // A reused cell may be showing a different file of the same scale, so
        // always re-resolve here; the resolver's cache makes this cheap.
        iconPath = null;
        refreshIcon();
        setContextMenu(null);

        if (!renaming && item.equals(DirectoryTreeBuilder.renameTargetProperty().get())) {
            Platform.runLater(this::syncRename);
        }
    }

    // =====================================================================
    // Icon
    // =====================================================================

    /**
     * Decodes the icon for the current item at the current window scale, if
     * the item, the scale or the theme has changed since the last decode.
     */
    private void refreshIcon() {
        Path item = getItem();
        if (isEmpty() || item == null) {
            return;
        }

        double scale = DirectoryFileIconResolver.outputScaleOf(this);
        boolean dark = DirectoryFileIconResolver.isDarkTheme();
        if (item.equals(iconPath) && scale == iconScale && dark == iconDark) {
            return;
        }

        Image icon = DirectoryFileIconResolver.resolve(item, Dim.Directory.FILE_ICON_SIZE, scale);
        iconView.setImage(icon);
        if (!renaming) {
            // While renaming, the icon sits inside the edit box and stays there.
            setGraphic(icon == null ? null : iconView);
        }
        iconPath = item;
        iconScale = scale;
        iconDark = dark;
    }

    /**
     * Moves the scale listener from the old window to the new one, and
     * re-decodes, since the new window may be on a different monitor.
     */
    private void watchWindow(Window oldWindow, Window newWindow) {
        if (oldWindow != null) {
            oldWindow.outputScaleXProperty().removeListener(weakScaleListener);
            oldWindow.outputScaleYProperty().removeListener(weakScaleListener);
        }
        if (newWindow != null) {
            newWindow.outputScaleXProperty().addListener(weakScaleListener);
            newWindow.outputScaleYProperty().addListener(weakScaleListener);
        }
        refreshIcon();
    }

    // =====================================================================
    // Context menu
    // =====================================================================

    /**
     * Builds the menu on demand rather than on every {@code updateItem}, since
     * the menu's enabled/disabled state is a snapshot of the clipboard and the
     * undo stack at the moment of the click.
     */
    private void refreshContextMenu() {
        Path item = getItem();
        if (isEmpty() || item == null || contextMenuFactory == null || renaming) {
            setContextMenu(null);
            return;
        }
        if (getTreeTableView() != null && getTableRow() != null && getTableRow().getIndex() >= 0) {
            getTreeTableView().getSelectionModel().select(getTableRow().getIndex());
        }
        setContextMenu(contextMenuFactory.apply(item));
    }

    // =====================================================================
    // In-place rename
    // =====================================================================

    /** Turns the field on or off to match the path the builder is renaming. */
    private void syncRename() {
        Path target = DirectoryTreeBuilder.renameTargetProperty().get();
        Path item = getItem();
        boolean should = target != null && !isEmpty() && target.equals(item);
        if (should && !renaming) {
            startRename();
        } else if (!should && renaming) {
            stopRename();
        }
    }

    private void startRename() {
        Path item = getItem();
        if (item == null) {
            return;
        }
        renaming = true;
        renamingPath = item;
        setContextMenu(null);

        String name = DirectoryRename.nameOf(item);
        field = new TextField(name);
        field.getStyleClass().add(RENAME_FIELD_CLASS);
        field.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(field, Priority.ALWAYS);

        editBox = new HBox(Dim.Directory.ICON_GAP, iconView, field);
        editBox.setAlignment(Pos.CENTER_LEFT);
        editBox.setFillHeight(false);

        setText(null);
        setGraphic(editBox);
        setContentDisplay(ContentDisplay.GRAPHIC_ONLY);

        field.addEventFilter(KeyEvent.KEY_PRESSED, event -> {
            switch (event.getCode()) {
                case ENTER, TAB -> {
                    commit(false);
                    event.consume();
                }
                case ESCAPE -> {
                    cancelFromUser();
                    event.consume();
                }
                // Keep the arrow keys in the field; otherwise the table would
                // move its selection out from under the open rename.
                case UP, DOWN, PAGE_UP, PAGE_DOWN -> event.consume();
                default -> {
                }
            }
        });
        field.textProperty().addListener((observable, was, isNow) -> hideError());
        focusListener = (observable, was, isNow) -> {
            if (!isNow && renaming && !finishing) {
                commit(true);
            }
        };
        field.focusedProperty().addListener(focusListener);

        int selectEnd = DirectoryRename.selectionEnd(item, name);
        Platform.runLater(() -> {
            if (field != null && renaming) {
                field.requestFocus();
                field.selectRange(0, selectEnd);
            }
        });
    }

    /** Puts the plain name back. Safe to call more than once. */
    private void stopRename() {
        if (!renaming) {
            return;
        }
        renaming = false;
        renamingPath = null;
        hideError();
        if (field != null && focusListener != null) {
            field.focusedProperty().removeListener(focusListener);
        }
        field = null;
        focusListener = null;
        if (editBox != null) {
            editBox.getChildren().clear(); // releases the icon view
        }
        editBox = null;

        setContentDisplay(ContentDisplay.LEFT);
        Path item = getItem();
        if (isEmpty() || item == null) {
            setText(null);
            setGraphic(null);
            return;
        }
        setText(DirectoryRename.nameOf(item));
        setGraphic(iconView.getImage() == null ? null : iconView);
    }

    /**
     * @param focusLoss true when the field lost focus (a click elsewhere):
     *                  an invalid name then abandons the rename instead of
     *                  keeping the field open
     */
    private void commit(boolean focusLoss) {
        if (!renaming || finishing || field == null) {
            return;
        }
        String error = DirectoryTreeBuilder.commitRename(
                getTableRow() == null ? null : getTableRow().getTreeItem(), field.getText());
        if (error == null || focusLoss) {
            finish(!focusLoss);
            return;
        }
        showError(error);
        field.requestFocus();
    }

    private void cancelFromUser() {
        finish(true);
    }

    private void finish(boolean returnFocusToTree) {
        finishing = true;
        try {
            DirectoryTreeBuilder.cancelRename(); // clears the target; syncRename stops the field
            stopRename();
            if (returnFocusToTree && getTreeTableView() != null) {
                getTreeTableView().requestFocus();
            }
        } finally {
            finishing = false;
        }
    }

    private void showError(String message) {
        if (field == null) {
            return;
        }
        if (errorTip == null) {
            errorTip = new Tooltip();
            errorTip.getStyleClass().add(RENAME_ERROR_CLASS);
            errorTip.setWrapText(true);
            errorTip.setMaxWidth(360);
            errorTip.setAutoHide(true);
        }
        errorTip.setText(message);
        Bounds bounds = field.localToScreen(field.getBoundsInLocal());
        if (bounds == null) {
            return;
        }
        errorTip.show(field, bounds.getMinX(), bounds.getMaxY() + 2);
    }

    private void hideError() {
        if (errorTip != null && errorTip.isShowing()) {
            errorTip.hide();
        }
    }
}
