package ui.directory;

import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import javafx.beans.InvalidationListener;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelFormat;
import javafx.scene.image.PixelReader;
import javafx.scene.image.WritableImage;
import javafx.scene.image.WritablePixelFormat;
import javafx.stage.Screen;
import javafx.stage.Window;
import ui.design.Dim;

/**
 * Picks the icon for a row of the directory tree.
 *
 * <h3>One master per icon, per theme</h3>
 * <p>
 * Every icon under {@code /icons/other_files} exists exactly once per theme,
 * as a 96x96 RGBA PNG:
 * </p>
 * <pre>
 * /icons/other_files/light/&lt;name&gt;.png
 * /icons/other_files/dark/&lt;name&gt;.png
 * </pre>
 * <p>
 * There are no per-size files. The previous resolver chose between 16, 20, 24
 * and 32 px files by the <i>logical</i> draw size and ignored the screen's
 * output scale, so on a 125% or 150% Windows display a 16 px bitmap was
 * stretched by the GPU and every icon looked soft.
 * </p>
 *
 * <h3>How an icon is made crisp</h3>
 * <p>
 * The master is reduced once to exactly the number of <i>physical</i> pixels
 * the row will occupy -- draw size times the window's output scale -- with a
 * premultiplied area-average filter ({@link #downscale}). JavaFX's own
 * load-time scaler was measured against it and is visibly softer at 16-24 px,
 * which is why it is not used. The {@link ImageView} is then given the
 * <i>logical</i> draw size as its fit size, so the bitmap lands on the screen
 * one pixel to one pixel with no further resampling. {@link #apply} does both
 * halves; a cell that sets the image itself must also set
 * {@code fitWidth}/{@code fitHeight} to the draw size, or the icon will be
 * shown at its pixel size.
 * </p>
 * <p>
 * The filter works on premultiplied colour, so transparent pixels never
 * darken an edge. (The masters also store their outline colour under every
 * transparent pixel, which protects them in any other image tool.)
 * </p>
 *
 * <h3>Light and dark</h3>
 * <p>
 * The dark variants are drawn, not inverted: the sheet is dark slate and the
 * label colours are lifted slightly so they stay distinct against it. After a
 * theme switch call {@link #setDarkTheme} and then redraw the tree
 * ({@code DirectoryTreeBuilder.refreshIcons(ide)}).
 * </p>
 *
 * <h3>Neural Code files</h3>
 * <p>
 * {@code .nc} files keep the project's own icon at {@link #NC_ICON}; it is not
 * part of the themed set and is loaded through the same crisp path.
 * </p>
 */
public final class DirectoryFileIconResolver {

    /** Neural Code source files: the project's own icon, both themes. */
    private static final String NC_ICON = "/icons/ic_19_file.png";

    /** Root of the themed set. */
    private static final String OTHER_ROOT = "/icons/other_files/";

    /** Folder rows (themed, part of the set). */
    private static final String FOLDER = "folder";

    /** Anything without an icon of its own. */
    private static final String GENERIC = "generic";

    /** Pixel size of every master in the themed set. */
    public static final int MASTER_SIZE = 96;

    /** Every file-type icon shipped in the set, by file name. */
    private static final Set<String> SHIPPED = Set.of(
            // Office
            "docx", "doc", "xlsx", "xls", "csv", "pptx", "ppt", "pdf",
            // Text, data, configuration
            "txt", "md", "json", "xml", "yaml", "ini", "log",
            // Source
            "c", "cpp", "h", "hpp", "java", "js", "ts", "py", "cs",
            "html", "css", "sh", "bat",
            // Archives
            "zip", "rar", "7z",
            // Media
            "mp3", "wav", "mp4", "avi", "png", "jpg", "svg", "gif",
            // Binaries
            "exe", "dll");

    /**
     * Reduced images, keyed by resource path and pixel size. The theme is part
     * of the resource path, so switching theme needs no invalidation.
     */
    private static final Map<String, Image> CACHE = new ConcurrentHashMap<>();

    /** Masters at their native size, keyed by resource path. */
    private static final Map<String, Image> MASTERS = new ConcurrentHashMap<>();

    /** Resources that were looked up and not found, so they are not retried. */
    private static final Set<String> MISSING = ConcurrentHashMap.newKeySet();

    private static volatile boolean darkTheme;

    private DirectoryFileIconResolver() {
    }

    // =====================================================================
    // Theme
    // =====================================================================

    /**
     * Tells the resolver which variant to load.
     *
     * <p>
     * Call this from wherever the application swaps {@code themes/light.css}
     * for {@code themes/dark.css}, then redraw the tree so rows drawn before
     * the switch pick up the new variant.
     * </p>
     *
     * @param dark true for the dark variants
     */
    public static void setDarkTheme(boolean dark) {
        darkTheme = dark;
    }

    /**
     * @return true if the dark variants are in use
     */
    public static boolean isDarkTheme() {
        return darkTheme;
    }

    // =====================================================================
    // Applying to a view (preferred entry point for cells)
    // =====================================================================

    /**
     * Creates a view showing the icon for {@code path} at the row icon size.
     *
     * @param path the file or folder; may be null
     * @return a new view; its image is null if nothing could be loaded
     */
    public static ImageView createView(Path path) {
        return createView(path, Dim.Directory.FILE_ICON_SIZE);
    }

    /**
     * Creates a view showing the icon for {@code path}.
     *
     * @param path   the file or folder; may be null
     * @param drawAt the logical size to draw at
     * @return a new view; its image is null if nothing could be loaded
     */
    public static ImageView createView(Path path, double drawAt) {
        ImageView view = new ImageView();
        view.setPreserveRatio(true);
        apply(view, path, drawAt);
        return view;
    }

    /**
     * Shows the icon for {@code path} in an existing view at the row icon size.
     *
     * @param view the view to update; ignored if null
     * @param path the file or folder; may be null
     */
    public static void apply(ImageView view, Path path) {
        apply(view, path, Dim.Directory.FILE_ICON_SIZE);
    }

    /**
     * Shows the icon for {@code path} in an existing view.
     *
     * <p>
     * Sets the view's fit size to the logical draw size and its image to one
     * decoded at the physical size of the window the view is in (or, if the
     * view is not in a window yet, the highest scale of any connected screen).
     * </p>
     *
     * @param view   the view to update; ignored if null
     * @param path   the file or folder; may be null
     * @param drawAt the logical size to draw at
     */
    public static void apply(ImageView view, Path path, double drawAt) {
        if (view == null) {
            return;
        }
        double size = drawAt > 0 ? drawAt : Dim.Directory.FILE_ICON_SIZE;
        view.setFitWidth(size);
        view.setFitHeight(size);
        view.setSmooth(true);
        view.setImage(resolve(path, size, outputScaleOf(view)));
    }

    // =====================================================================
    // Resolution
    // =====================================================================

    /**
     * @param path the file or folder; may be null
     * @return the icon decoded for the row icon size on the sharpest connected
     *         screen, or null if nothing could be loaded
     */
    public static Image resolve(Path path) {
        return resolve(path, Dim.Directory.FILE_ICON_SIZE, defaultOutputScale());
    }

    /**
     * @param path   the file or folder; may be null
     * @param drawAt the logical size the icon will be drawn at
     * @return the icon decoded for the sharpest connected screen, or null if
     *         nothing could be loaded
     */
    public static Image resolve(Path path, double drawAt) {
        return resolve(path, drawAt, defaultOutputScale());
    }

    /**
     * @param path        the file or folder; may be null
     * @param drawAt      the logical size the icon will be drawn at
     * @param outputScale the render scale of the target window (1.0, 1.25,
     *                    1.5, 2.0 ...)
     * @return the icon, decoded at {@code ceil(drawAt * outputScale)} pixels,
     *         or null if nothing could be loaded
     */
    public static Image resolve(Path path, double drawAt, double outputScale) {
        if (path == null) {
            return null;
        }
        int pixels = pixelSize(drawAt, outputScale);

        if (Files.isDirectory(path)) {
            return loadThemed(FOLDER, pixels);
        }
        if (NcMetrics.isNeuralCode(path)) {
            return load(NC_ICON, pixels);
        }

        String name = iconName(extensionOf(path));
        Image icon = loadThemed(name, pixels);
        if (icon == null && !GENERIC.equals(name)) {
            icon = loadThemed(GENERIC, pixels);
        }
        return icon;
    }

    // =====================================================================
    // Output scale
    // =====================================================================

    /**
     * @param node any node; may be null or not yet in a window
     * @return the render scale of the node's window, or
     *         {@link #defaultOutputScale()} if it has none yet
     */
    public static double outputScaleOf(Node node) {
        if (node != null) {
            Scene scene = node.getScene();
            Window window = scene == null ? null : scene.getWindow();
            if (window != null) {
                double scale = Math.max(window.getOutputScaleX(), window.getOutputScaleY());
                if (scale > 0) {
                    return scale;
                }
            }
        }
        return defaultOutputScale();
    }

    /**
     * The highest render scale of any connected screen. Used when the target
     * window is not known, so an icon is never decoded smaller than some
     * screen will need.
     *
     * @return at least 1.0
     */
    public static double defaultOutputScale() {
        double max = 1.0;
        for (Screen screen : Screen.getScreens()) {
            max = Math.max(max, Math.max(screen.getOutputScaleX(), screen.getOutputScaleY()));
        }
        return max;
    }

    /**
     * Runs {@code refresh} whenever the window's render scale changes -- for
     * example when it is dragged from a 100% monitor to a 150% one -- so the
     * tree can redraw its icons at the new pixel size.
     *
     * @param window  the window holding the tree; ignored if null
     * @param refresh what to run, typically
     *                {@code () -> DirectoryTreeBuilder.refreshIcons(ide)}
     */
    public static void refreshOnScaleChange(Window window, Runnable refresh) {
        if (window == null || refresh == null) {
            return;
        }
        InvalidationListener listener = observable -> refresh.run();
        window.outputScaleXProperty().addListener(listener);
        window.outputScaleYProperty().addListener(listener);
    }

    /** Drops every decoded image; the next lookup decodes again. */
    public static void clearCache() {
        CACHE.clear();
        MASTERS.clear();
        MISSING.clear();
    }

    // =====================================================================
    // Loading
    // =====================================================================

    private static Image loadThemed(String name, int pixels) {
        return load(OTHER_ROOT + (darkTheme ? "dark/" : "light/") + name + ".png", pixels);
    }

    /**
     * Returns a classpath image reduced to fit a square of {@code pixels},
     * caching both the master and the result.
     */
    private static Image load(String resource, int pixels) {
        String key = resource + "@" + pixels;
        Image cached = CACHE.get(key);
        if (cached != null) {
            return cached;
        }
        Image master = master(resource);
        if (master == null) {
            return null;
        }
        Image scaled = downscale(master, pixels);
        Image previous = CACHE.putIfAbsent(key, scaled);
        return previous != null ? previous : scaled;
    }

    private static Image master(String resource) {
        Image cached = MASTERS.get(resource);
        if (cached != null) {
            return cached;
        }
        if (MISSING.contains(resource)) {
            return null;
        }
        URL url = DirectoryFileIconResolver.class.getResource(resource);
        if (url == null) {
            MISSING.add(resource);
            return null;
        }
        // Native size, synchronous: the reduction below needs the pixels now.
        Image image = new Image(url.toExternalForm(), false);
        if (image.isError() || image.getPixelReader() == null
                || image.getWidth() < 1 || image.getHeight() < 1) {
            MISSING.add(resource);
            return null;
        }
        Image previous = MASTERS.putIfAbsent(resource, image);
        return previous != null ? previous : image;
    }

    // =====================================================================
    // Area-average reduction
    // =====================================================================

    /**
     * Reduces {@code source} so its longer side is {@code target} pixels,
     * keeping the aspect ratio.
     *
     * <p>
     * Each output pixel is the exact area-weighted mean of the source pixels it
     * covers (a box filter with fractional edge coverage), applied separably
     * and in premultiplied colour. For an integer ratio such as 96 to 24 or 16
     * this is a plain block average; for 96 to 20 the partial edge pixels are
     * weighted by how much of them falls inside. It does not sharpen, so it
     * adds no halos around the label text.
     * </p>
     *
     * <p>
     * An image that is already at or below the target is returned as is; the
     * view scales it up.
     * </p>
     */
    private static Image downscale(Image source, int target) {
        int sw = (int) source.getWidth();
        int sh = (int) source.getHeight();
        if (target >= sw && target >= sh) {
            return source;
        }
        double ratio = (double) target / Math.max(sw, sh);
        int tw = Math.max(1, (int) Math.round(sw * ratio));
        int th = Math.max(1, (int) Math.round(sh * ratio));

        int[] argb = new int[sw * sh];
        WritablePixelFormat<java.nio.IntBuffer> format = PixelFormat.getIntArgbInstance();
        PixelReader reader = source.getPixelReader();
        reader.getPixels(0, 0, sw, sh, format, argb, 0, sw);

        // Premultiplied channels, 0..1: a, r*a, g*a, b*a.
        float[] src = new float[sw * sh * 4];
        for (int i = 0; i < argb.length; i++) {
            int p = argb[i];
            float a = ((p >>> 24) & 0xFF) / 255f;
            int o = i * 4;
            src[o] = a;
            src[o + 1] = ((p >>> 16) & 0xFF) / 255f * a;
            src[o + 2] = ((p >>> 8) & 0xFF) / 255f * a;
            src[o + 3] = (p & 0xFF) / 255f * a;
        }

        Span[] cols = spans(sw, tw);
        Span[] rows = spans(sh, th);

        // Horizontal pass: sw x sh -> tw x sh
        float[] mid = new float[tw * sh * 4];
        for (int y = 0; y < sh; y++) {
            int srcRow = y * sw;
            int midRow = y * tw;
            for (int x = 0; x < tw; x++) {
                Span span = cols[x];
                int o = (midRow + x) * 4;
                for (int k = 0; k < span.weights.length; k++) {
                    int s = (srcRow + span.first + k) * 4;
                    float w = span.weights[k];
                    mid[o] += src[s] * w;
                    mid[o + 1] += src[s + 1] * w;
                    mid[o + 2] += src[s + 2] * w;
                    mid[o + 3] += src[s + 3] * w;
                }
            }
        }

        // Vertical pass: tw x sh -> tw x th, then un-premultiply.
        int[] out = new int[tw * th];
        for (int y = 0; y < th; y++) {
            Span span = rows[y];
            for (int x = 0; x < tw; x++) {
                float a = 0, r = 0, g = 0, b = 0;
                for (int k = 0; k < span.weights.length; k++) {
                    int s = ((span.first + k) * tw + x) * 4;
                    float w = span.weights[k];
                    a += mid[s] * w;
                    r += mid[s + 1] * w;
                    g += mid[s + 2] * w;
                    b += mid[s + 3] * w;
                }
                int ai = channel(a);
                int value = 0;
                if (ai > 0) {
                    value = (ai << 24)
                            | (channel(r / a) << 16)
                            | (channel(g / a) << 8)
                            | channel(b / a);
                }
                out[y * tw + x] = value;
            }
        }

        WritableImage result = new WritableImage(tw, th);
        result.getPixelWriter().setPixels(0, 0, tw, th, format, out, 0, tw);
        return result;
    }

    private static int channel(float value) {
        int v = Math.round(value * 255f);
        return v < 0 ? 0 : (v > 255 ? 255 : v);
    }

    /** The source pixels one output pixel covers, with their weights. */
    private record Span(int first, float[] weights) {
    }

    private static Span[] spans(int sourceLength, int targetLength) {
        double scale = (double) sourceLength / targetLength;
        Span[] spans = new Span[targetLength];
        for (int i = 0; i < targetLength; i++) {
            double start = i * scale;
            double end = Math.min(sourceLength, (i + 1) * scale);
            int first = (int) Math.floor(start);
            int last = Math.min(sourceLength - 1, (int) Math.ceil(end) - 1);
            float[] weights = new float[last - first + 1];
            double total = 0;
            for (int j = first; j <= last; j++) {
                double cover = Math.min(end, j + 1) - Math.max(start, j);
                weights[j - first] = (float) Math.max(0, cover);
                total += weights[j - first];
            }
            for (int k = 0; k < weights.length; k++) {
                weights[k] /= (float) total;
            }
            spans[i] = new Span(first, weights);
        }
        return spans;
    }

    /**
     * @return the physical pixel size for a logical size at a render scale,
     *         between 1 and {@link #MASTER_SIZE}
     */
    private static int pixelSize(double drawAt, double outputScale) {
        double size = drawAt > 0 ? drawAt : Dim.Directory.FILE_ICON_SIZE;
        double scale = outputScale > 0 ? outputScale : 1.0;
        // The small epsilon keeps 16 * 1.25 = 20.000000000000004 at 20.
        int pixels = (int) Math.ceil(size * scale - 1e-6);
        return Math.max(1, Math.min(MASTER_SIZE, pixels));
    }

    // =====================================================================
    // Names
    // =====================================================================

    private static String extensionOf(Path path) {
        Path name = path.getFileName();
        if (name == null) {
            return "";
        }
        String text = name.toString().toLowerCase(Locale.ROOT);
        int dot = text.lastIndexOf('.');
        // A leading dot is a name, not an extension: ".gitignore" is not a file
        // of type "gitignore".
        return (dot > 0 && dot < text.length() - 1) ? text.substring(dot + 1) : "";
    }

    /**
     * Maps an extension to an icon name in the set. Close variants of a
     * shipped type borrow its icon; anything else is {@link #GENERIC}.
     */
    private static String iconName(String extension) {
        if (extension.isEmpty()) {
            return GENERIC;
        }
        String name = switch (extension) {
            // Office variants (macro-enabled, templates, shows)
            case "docm", "dotx", "dotm" -> "docx";
            case "dot" -> "doc";
            case "xlsm", "xlsb", "xltx", "xltm" -> "xlsx";
            case "xlt" -> "xls";
            case "pptm", "potx", "potm", "ppsx", "ppsm" -> "pptx";
            case "pps", "pot" -> "ppt";
            // Text and data
            case "text" -> "txt";
            case "markdown", "mdown", "mkd" -> "md";
            case "jsonc" -> "json";
            case "yml" -> "yaml";
            // Source
            case "cc", "cxx", "c++" -> "cpp";
            case "hh", "hxx", "h++" -> "hpp";
            case "mjs", "cjs", "jsx" -> "js";
            case "mts", "cts", "tsx" -> "ts";
            case "pyw", "pyi" -> "py";
            case "htm", "xhtml", "shtml" -> "html";
            case "bash", "zsh" -> "sh";
            case "cmd" -> "bat";
            // Media
            case "jpeg", "jpe", "jfif" -> "jpg";
            case "svgz" -> "svg";
            case "m4v" -> "mp4";
            default -> extension;
        };
        return SHIPPED.contains(name) ? name : GENERIC;
    }
}
