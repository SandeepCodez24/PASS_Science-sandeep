package ui.directory;

import java.nio.file.Path;
import java.util.function.Supplier;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Pos;
import javafx.scene.control.TreeTableCell;

/**
 * The Info column: one number per row, in whatever unit the header is set to.
 *
 * <p>
 * The cell binds to the observable {@link NcMetrics} hands back rather than
 * asking for a value, because the count usually is not known yet when the row
 * is first drawn. Binding means the number appears the moment the background
 * parse finishes, with no redraw of the tree; unbinding on recycle means a row
 * scrolled out of view stops listening to a file it no longer shows.
 * </p>
 *
 * <p>
 * Right-aligned. Numbers in a column are read by comparing their lengths, and
 * that only works if they share an edge.
 * </p>
 */
public final class DirectoryInfoCell extends TreeTableCell<Path, Path> {

    private final Supplier<InfoMode> mode;
    private ObservableValue<String> bound;

    /**
     * @param mode reads the column's current mode at draw time, so a change of
     *             mode needs only a table refresh
     */
    public DirectoryInfoCell(Supplier<InfoMode> mode) {
        this.mode = mode;
        setAlignment(Pos.CENTER_RIGHT);
        getStyleClass().add("directory-info-cell");
    }

    @Override
    protected void updateItem(Path item, boolean empty) {
        super.updateItem(item, empty);

        release();

        if (empty || item == null) {
            setText(null);
            return;
        }

        bound = NcMetrics.text(item, mode.get());
        textProperty().bind(bound);
    }

    private void release() {
        if (bound != null) {
            textProperty().unbind();
            bound = null;
        }
        setText(null);
    }
}
