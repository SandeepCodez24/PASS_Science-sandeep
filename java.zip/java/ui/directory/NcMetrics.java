package ui.directory;

import java.io.IOException;
import java.nio.charset.MalformedInputException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import ui.editor.folding.FoldParser;
import ui.editor.folding.FoldRegion;

/**
 * The numbers behind the Info column.
 *
 * <h3>Where the counts come from</h3>
 * <p>
 * Functions and classes are not counted with a regular expression of their own.
 * {@link FoldParser} already reads exactly the grammar this needs --
 * {@code function} closed by {@code fnend}, {@code class} closed by
 * {@code csend}, both tracked on a stack, with keywords inside comment runs
 * ignored -- and it is the parser the editor's fold markers already agree with.
 * Writing a second parser here would mean two definitions of "a function" that
 * could drift apart, and the first symptom would be a fold marker and a count
 * disagreeing on screen. So this class parses once and classifies the regions.
 * </p>
 *
 * <h3>Functions inside a class are methods</h3>
 * <p>
 * A {@code function} whose start line falls within a {@code class} region is
 * that class's method, and is not added to the function count. On the two
 * sample files this gives 8 functions / 0 classes for the first and 0 functions
 * / 2 classes for the second, which is what the file names promise. Change
 * {@link #isNested} if the other convention is ever wanted -- it is the only
 * place the rule is expressed.
 * </p>
 *
 * <h3>Why this is not computed on the FX thread</h3>
 * <p>
 * The Info column asks for a value once per visible row, and every miss is a
 * file read plus a parse. Doing that inline would stall the scroll for as long
 * as the disk takes. Instead each cell is handed a
 * {@link javafx.beans.property.StringProperty} that starts empty and fills in
 * when a background thread has the answer; the cell is bound to it, so the text
 * appears without anyone re-rendering the tree.
 * </p>
 *
 * <p>
 * Results are cached against the file's last-modified time, so an edit
 * invalidates its own entry and nothing else. Call {@link #invalidate} after a
 * save if the timestamp granularity ever proves too coarse.
 * </p>
 */
public final class NcMetrics {

    /** The extension whose contents are worth parsing. */
    public static final String NC_EXTENSION = ".nc";

    /**
     * Files above this size are reported as an em dash rather than parsed. A
     * directory listing must never be the thing that reads a 200MB file.
     */
    private static final long PARSE_CEILING_BYTES = 5L * 1024 * 1024;

    /** Shown while a background count is still running. */
    private static final String PENDING = "";

    /** Shown for a file too large to parse, or one that could not be read. */
    private static final String UNAVAILABLE = "\u2014";

    private static final ExecutorService WORKERS = Executors.newFixedThreadPool(
            Math.max(2, Math.min(4, Runtime.getRuntime().availableProcessors() / 2)),
            runnable -> {
                Thread thread = new Thread(runnable, "directory-metrics");
                thread.setDaemon(true);
                return thread;
            });

    private static final Map<String, SimpleStringProperty> CACHE = new ConcurrentHashMap<>();

    private NcMetrics() {
    }

    // =====================================================================
    // Public API
    // =====================================================================

    /**
     * The Info text for one row.
     *
     * @param path the file or folder; may be null
     * @param mode the current Info column mode
     * @return an observable that is empty now and carries the value once it is
     *         known; never null
     */
    public static ObservableValue<String> text(Path path, InfoMode mode) {
        SimpleStringProperty value = new SimpleStringProperty(PENDING);
        if (path == null || mode == null) {
            return value;
        }

        // Folders stay blank: a folder has no line count, and summing its
        // children would mean walking the whole subtree on every redraw.
        if (Files.isDirectory(path)) {
            return value;
        }

        // A non-.nc file has no functions, classes or meaningful line count, so
        // only Size is shown for it. Everything else stays blank, as specified.
        if (!isNeuralCode(path) && !mode.appliesToAllFiles()) {
            return value;
        }

        long stamp;
        long size;
        try {
            stamp = Files.getLastModifiedTime(path).toMillis();
            size = Files.size(path);
        } catch (IOException | RuntimeException e) {
            value.set(UNAVAILABLE);
            return value;
        }

        // Size needs no parse and no cache -- it is already in hand.
        if (mode == InfoMode.SIZE) {
            value.set(formatSize(size));
            return value;
        }

        if (size > PARSE_CEILING_BYTES) {
            value.set(UNAVAILABLE);
            return value;
        }

        String key = path.toString().toLowerCase(Locale.ROOT) + "|" + stamp + "|" + mode.name();
        SimpleStringProperty cached = CACHE.get(key);
        if (cached != null) {
            return cached;
        }

        CACHE.put(key, value);
        WORKERS.submit(() -> {
            String computed = compute(path, mode);
            Platform.runLater(() -> value.set(computed));
        });
        return value;
    }

    /**
     * Drops every cached count for a file, so the next redraw recounts it.
     *
     * @param path the file; ignored if null
     */
    public static void invalidate(Path path) {
        if (path == null) {
            return;
        }
        String prefix = path.toString().toLowerCase(Locale.ROOT) + "|";
        CACHE.keySet().removeIf(key -> key.startsWith(prefix));
    }

    /** Drops every cached count. */
    public static void invalidateAll() {
        CACHE.clear();
    }

    /**
     * @param path any path; may be null
     * @return true if it names a Neural Code source file
     */
    public static boolean isNeuralCode(Path path) {
        if (path == null) {
            return false;
        }
        Path name = path.getFileName();
        return name != null && name.toString().toLowerCase(Locale.ROOT).endsWith(NC_EXTENSION);
    }

    // =====================================================================
    // Counting
    // =====================================================================

    private static String compute(Path path, InfoMode mode) {
        String text = read(path);
        if (text == null) {
            return UNAVAILABLE;
        }

        if (mode == InfoMode.LINES) {
            return String.valueOf(countLines(text));
        }

        List<FoldRegion> regions = FoldParser.parse(text);

        if (mode == InfoMode.CLASSES) {
            long classes = regions.stream()
                    .filter(region -> region.getKind() == FoldRegion.Kind.CLASS)
                    .count();
            return classes == 0 ? "" : String.valueOf(classes);
        }

        long functions = regions.stream()
                .filter(region -> region.getKind() == FoldRegion.Kind.FUNCTION)
                .filter(region -> !isNested(region, regions))
                .count();
        return functions == 0 ? "" : String.valueOf(functions);
    }

    /**
     * @return true if this region starts inside a {@code class} block, which
     *         makes it a method rather than a free function
     */
    private static boolean isNested(FoldRegion region, List<FoldRegion> all) {
        for (FoldRegion other : all) {
            if (other.getKind() != FoldRegion.Kind.CLASS) {
                continue;
            }
            if (region.getStartLine() > other.getStartLine()
                    && region.getEndLine() <= other.getEndLine()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Physical lines, counted the way an editor's gutter counts them: a file of
     * three lines with no trailing newline is three, and so is the same file
     * with one.
     */
    private static int countLines(String text) {
        if (text.isEmpty()) {
            return 0;
        }
        int lines = 1;
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == '\n') {
                lines++;
            }
        }
        // A trailing newline closes the last line rather than opening a new one.
        return text.charAt(text.length() - 1) == '\n' ? lines - 1 : lines;
    }

    private static String read(Path path) {
        try {
            return Files.readString(path, StandardCharsets.UTF_8);
        } catch (MalformedInputException e) {
            // A file saved in a legacy code page still has countable lines.
            try {
                return new String(Files.readAllBytes(path), StandardCharsets.ISO_8859_1);
            } catch (IOException | RuntimeException inner) {
                return null;
            }
        } catch (IOException | RuntimeException e) {
            return null;
        }
    }

    // =====================================================================
    // Formatting
    // =====================================================================

    /**
     * Binary units, one decimal above a kilobyte, none below -- "840 B",
     * "12.4 KB", "3.1 MB". The column is narrow, so nothing here is padded.
     *
     * @param bytes the size
     * @return the display text
     */
    public static String formatSize(long bytes) {
        if (bytes < 1024) {
            return bytes + " B";
        }
        double value = bytes / 1024.0;
        String[] units = {"KB", "MB", "GB", "TB"};
        int unit = 0;
        while (value >= 1024 && unit < units.length - 1) {
            value /= 1024.0;
            unit++;
        }
        return String.format(Locale.ROOT, value >= 100 ? "%.0f %s" : "%.1f %s", value, units[unit]);
    }
}
