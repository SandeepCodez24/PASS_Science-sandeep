package ui.directory;

import java.nio.file.Path;
import java.util.function.Consumer;

import javafx.animation.PauseTransition;
import javafx.event.EventTarget;
import javafx.scene.Node;
import javafx.scene.control.TextInputControl;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeTableView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.ScrollEvent;
import javafx.util.Duration;
import ui.design.Dim;

/**
 * Windows Explorer's "slow double-click": click a file, pause, click its name
 * again, and the name opens for editing.
 *
 * <h3>The rule</h3>
 * <p>
 * A rename starts when all of these hold for a primary click with no modifier
 * keys:
 * </p>
 * <ul>
 * <li>it lands on the <b>name</b> of a row (not the disclosure triangle, not
 * the Info or R column);</li>
 * <li>that row was <b>already the only selected row</b> before the click;</li>
 * <li>the previous click was on the <b>same row</b>, between
 * {@link Dim.Directory#SLOW_CLICK_MIN_MS} and
 * {@link Dim.Directory#SLOW_CLICK_MAX_MS} ago -- slower than a double-click,
 * but still one deliberate gesture;</li>
 * <li>the pointer did not drag between press and release.</li>
 * </ul>
 * <p>
 * The rename then waits one double-click interval. A third, quick click in that
 * time turns the gesture into an ordinary double-click (open the file or
 * re-root at the folder) and the rename is dropped. So does a key press, a
 * scroll, a change of selection, or the tree losing focus.
 * </p>
 *
 * <p>
 * A fast double-click is untouched: {@code DirectoryTreeBuilder} still opens a
 * file or re-roots at a folder on it.
 * </p>
 */
final class DirectorySlowClick {

    /** Pointer travel, in pixels, beyond which a press-release is a drag. */
    private static final double DRAG_SLOP = 4;

    private final TreeTableView<Path> tree;
    private final Consumer<Path> startRename;
    private final PauseTransition timer = new PauseTransition(Duration.millis(Dim.Directory.SLOW_CLICK_MIN_MS));

    private Path lastClickPath;
    private long lastClickTime;

    private Path pressPath;
    private boolean pressEligible;
    private double pressX;
    private double pressY;

    private Path pending;

    /**
     * @param tree        the directory tree table
     * @param startRename opens the rename field on a path
     */
    DirectorySlowClick(TreeTableView<Path> tree, Consumer<Path> startRename) {
        this.tree = tree;
        this.startRename = startRename;
    }

    void install() {
        timer.setOnFinished(event -> fire());

        tree.addEventFilter(MouseEvent.MOUSE_PRESSED, this::onPressed);
        tree.addEventFilter(MouseEvent.MOUSE_RELEASED, this::onReleased);
        tree.addEventFilter(MouseEvent.MOUSE_DRAGGED, event -> {
            if (Math.abs(event.getScreenX() - pressX) > DRAG_SLOP
                    || Math.abs(event.getScreenY() - pressY) > DRAG_SLOP) {
                pressEligible = false;
                cancel();
            }
        });
        tree.addEventFilter(KeyEvent.KEY_PRESSED, event -> cancel());
        tree.addEventFilter(ScrollEvent.SCROLL, event -> cancel());
        tree.focusedProperty().addListener((observable, was, isNow) -> {
            if (!isNow) {
                cancel();
            }
        });
        tree.getSelectionModel().selectedItemProperty().addListener((observable, was, isNow) -> {
            if (pending != null && (isNow == null || !pending.equals(isNow.getValue()))) {
                cancel();
            }
        });
    }

    /** Drops a rename that is waiting to start. */
    void cancel() {
        timer.stop();
        pending = null;
    }

    private void onPressed(MouseEvent event) {
        if (event.getButton() != MouseButton.PRIMARY
                || event.isShiftDown() || event.isControlDown() || event.isAltDown() || event.isMetaDown()) {
            cancel();
            pressEligible = false;
            lastClickPath = null;
            return;
        }
        if (isInsideTextInput(event.getTarget())) {
            // A click inside an open rename field is text editing.
            pressEligible = false;
            return;
        }
        if (event.getClickCount() >= 2) {
            // Part of a fast double-click: that opens, it never renames.
            cancel();
            pressEligible = false;
            lastClickPath = null;
            return;
        }

        long now = System.currentTimeMillis();
        Path rowPath = DirectoryTreeBuilder.rowPathUnder(event.getTarget());
        Path namePath = nameCellPathUnder(event.getTarget());
        Path selected = singleSelection();
        long gap = now - lastClickTime;

        pressEligible = namePath != null
                && namePath.equals(selected)
                && namePath.equals(lastClickPath)
                && gap >= Dim.Directory.SLOW_CLICK_MIN_MS
                && gap <= Dim.Directory.SLOW_CLICK_MAX_MS
                && !DirectoryTreeBuilder.isRenaming();
        pressPath = namePath;
        pressX = event.getScreenX();
        pressY = event.getScreenY();

        lastClickPath = rowPath;
        lastClickTime = now;

        if (!pressEligible) {
            cancel();
        }
    }

    private void onReleased(MouseEvent event) {
        if (!pressEligible || pressPath == null) {
            return;
        }
        pressEligible = false;
        if (!pressPath.equals(nameCellPathUnder(event.getTarget()))) {
            return;
        }
        pending = pressPath;
        timer.playFromStart();
    }

    private void fire() {
        Path path = pending;
        pending = null;
        if (path != null && path.equals(singleSelection())) {
            // A rename that opens now must not count as the first half of a
            // later slow click.
            lastClickPath = null;
            startRename.accept(path);
        }
    }

    private Path singleSelection() {
        if (tree.getSelectionModel().getSelectedIndices().size() != 1) {
            return null;
        }
        TreeItem<Path> item = tree.getSelectionModel().getSelectedItem();
        return item == null ? null : item.getValue();
    }

    private static Path nameCellPathUnder(EventTarget target) {
        Node node = (target instanceof Node n) ? n : null;
        while (node != null) {
            if (node instanceof DirectoryNameCell cell) {
                return cell.isEmpty() ? null : cell.getItem();
            }
            node = node.getParent();
        }
        return null;
    }

    static boolean isInsideTextInput(EventTarget target) {
        Node node = (target instanceof Node n) ? n : null;
        while (node != null) {
            if (node instanceof TextInputControl) {
                return true;
            }
            node = node.getParent();
        }
        return false;
    }
}
