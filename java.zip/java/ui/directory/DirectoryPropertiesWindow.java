package ui.directory;

import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.text.DecimalFormat;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.concurrent.atomic.AtomicLong;
import javafx.application.Platform;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.image.ImageView;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.Window;
import ui.design.section_dims.DirectoryMenu_dim;

/**
 * Astra's own Properties window, laid out like the <i>General</i> page of the
 * Windows sheet.
 *
 * <p>
 * It is the fallback only: {@link DirectoryShell#showProperties} opens the
 * operating system's real dialog whenever it can, and comes here when it
 * cannot (a Linux desktop without the FileManager1 service, native access
 * disabled, and so on). It is modeless, like the real one.
 * </p>
 *
 * <p>
 * A folder's size and contents are counted on a background thread, and the
 * two rows fill in when the walk finishes, as Windows does.
 * </p>
 */
final class DirectoryPropertiesWindow {

    private static final String ROOT_CLASS = "directory-properties";
    private static final String KEY_CLASS = "directory-properties-key";
    private static final String VALUE_CLASS = "directory-properties-value";
    private static final String NAME_CLASS = "directory-properties-name";

    private static final DateTimeFormatter DATE = DateTimeFormatter
            .ofLocalizedDateTime(FormatStyle.FULL, FormatStyle.MEDIUM)
            .withZone(ZoneId.systemDefault());

    private DirectoryPropertiesWindow() {
    }

    static void show(Path path, Window owner) {
        BasicFileAttributes attrs;
        try {
            attrs = Files.readAttributes(path, BasicFileAttributes.class);
        } catch (IOException ex) {
            return;
        }
        boolean folder = attrs.isDirectory();
        String name = DirectoryRename.nameOf(path);

        // --- name row -------------------------------------------------------
        ImageView icon = DirectoryFileIconResolver.createView(path, DirectoryMenu_dim.PROPERTIES_ICON_SIZE);
        Label nameLabel = new Label(name);
        nameLabel.getStyleClass().add(NAME_CLASS);
        HBox nameRow = new HBox(DirectoryMenu_dim.PROPERTIES_PADDING, icon, nameLabel);
        nameRow.setAlignment(Pos.CENTER_LEFT);

        // --- details --------------------------------------------------------
        GridPane grid = new GridPane();
        grid.setHgap(DirectoryMenu_dim.PROPERTIES_PADDING);
        grid.setVgap(DirectoryMenu_dim.PROPERTIES_ROW_GAP);
        ColumnConstraints keys = new ColumnConstraints(DirectoryMenu_dim.PROPERTIES_LABEL_COLUMN);
        keys.setHalignment(HPos.LEFT);
        ColumnConstraints values = new ColumnConstraints();
        values.setHgrow(Priority.ALWAYS);
        grid.getColumnConstraints().addAll(keys, values);

        int row = 0;
        addRow(grid, row++, "Type of file:", folder ? "File folder" : typeOf(path));
        addRow(grid, row++, "Location:", path.getParent() == null ? "" : path.getParent().toString());
        Label size = addRow(grid, row++, "Size:", folder ? "Calculating\u2026" : sizeText(attrs.size()));
        Label contains = folder ? addRow(grid, row++, "Contains:", "Calculating\u2026") : null;

        GridPane dates = new GridPane();
        dates.setHgap(DirectoryMenu_dim.PROPERTIES_PADDING);
        dates.setVgap(DirectoryMenu_dim.PROPERTIES_ROW_GAP);
        dates.getColumnConstraints().addAll(keys, values);
        addRow(dates, 0, "Created:", date(attrs.creationTime()));
        addRow(dates, 1, "Modified:", date(attrs.lastModifiedTime()));
        addRow(dates, 2, "Accessed:", date(attrs.lastAccessTime()));

        CheckBox readOnly = new CheckBox("Read-only");
        readOnly.setSelected(!Files.isWritable(path));
        readOnly.setDisable(true);
        CheckBox hidden = new CheckBox("Hidden");
        boolean isHidden;
        try {
            isHidden = Files.isHidden(path);
        } catch (IOException ex) {
            isHidden = false;
        }
        hidden.setSelected(isHidden);
        hidden.setDisable(true);
        GridPane attrsGrid = new GridPane();
        attrsGrid.setHgap(DirectoryMenu_dim.PROPERTIES_PADDING);
        attrsGrid.getColumnConstraints().addAll(keys, values);
        Label attrKey = new Label("Attributes:");
        attrKey.getStyleClass().add(KEY_CLASS);
        attrsGrid.add(attrKey, 0, 0);
        attrsGrid.add(new HBox(DirectoryMenu_dim.PROPERTIES_PADDING, readOnly, hidden), 1, 0);

        // --- buttons --------------------------------------------------------
        Stage stage = new Stage();
        Button ok = new Button("OK");
        ok.setDefaultButton(true);
        ok.setCancelButton(true);
        ok.setOnAction(e -> stage.close());
        HBox buttons = new HBox(ok);
        buttons.setAlignment(Pos.CENTER_RIGHT);

        VBox root = new VBox(DirectoryMenu_dim.PROPERTIES_PADDING,
                nameRow, new Separator(), grid, new Separator(), dates, new Separator(), attrsGrid, buttons);
        root.setPadding(new Insets(DirectoryMenu_dim.PROPERTIES_PADDING));
        root.getStyleClass().add(ROOT_CLASS);
        root.setPrefWidth(DirectoryMenu_dim.PROPERTIES_WIDTH);

        Scene scene = new Scene(root);
        if (owner != null && owner.getScene() != null) {
            scene.getStylesheets().setAll(owner.getScene().getStylesheets());
        }
        stage.setScene(scene);
        stage.setTitle(name + " Properties");
        stage.setResizable(false);
        stage.initModality(Modality.NONE);
        if (owner != null) {
            stage.initOwner(owner);
        }
        stage.show();

        if (folder) {
            DirectoryShell.background(() -> {
                AtomicLong bytes = new AtomicLong();
                AtomicLong files = new AtomicLong();
                AtomicLong folders = new AtomicLong();
                try {
                    Files.walkFileTree(path, new SimpleFileVisitor<>() {
                        @Override
                        public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes a) {
                            if (!dir.equals(path)) {
                                folders.incrementAndGet();
                            }
                            return stage.isShowing() ? FileVisitResult.CONTINUE : FileVisitResult.TERMINATE;
                        }

                        @Override
                        public FileVisitResult visitFile(Path file, BasicFileAttributes a) {
                            files.incrementAndGet();
                            bytes.addAndGet(a.size());
                            return FileVisitResult.CONTINUE;
                        }

                        @Override
                        public FileVisitResult visitFileFailed(Path file, IOException exc) {
                            return FileVisitResult.CONTINUE;
                        }
                    });
                } catch (IOException ignored) {
                    // Whatever was counted is still shown.
                }
                Platform.runLater(() -> {
                    size.setText(sizeText(bytes.get()));
                    if (contains != null) {
                        contains.setText(files.get() + " Files, " + folders.get() + " Folders");
                    }
                });
            });
        }
    }

    private static Label addRow(GridPane grid, int row, String key, String value) {
        Label k = new Label(key);
        k.getStyleClass().add(KEY_CLASS);
        Label v = new Label(value);
        v.getStyleClass().add(VALUE_CLASS);
        v.setWrapText(true);
        grid.add(k, 0, row);
        grid.add(v, 1, row);
        return v;
    }

    private static String typeOf(Path path) {
        String ext = DirectoryViewSettings.extensionOf(path);
        if (ext.equals("nc")) {
            return "Neural Code file (.nc)";
        }
        return ext.isEmpty() ? "File" : ext.toUpperCase() + " File (." + ext + ")";
    }

    private static String date(FileTime time) {
        return time == null ? "" : DATE.format(time.toInstant());
    }

    /** "1.25 MB (1,310,720 bytes)", as Windows writes it. */
    static String sizeText(long bytes) {
        DecimalFormat grouped = new DecimalFormat("#,##0");
        DecimalFormat oneDecimal = new DecimalFormat("#,##0.##");
        String human;
        if (bytes < 1024) {
            human = bytes + " bytes";
            return human;
        } else if (bytes < 1024L * 1024) {
            human = oneDecimal.format(bytes / 1024.0) + " KB";
        } else if (bytes < 1024L * 1024 * 1024) {
            human = oneDecimal.format(bytes / (1024.0 * 1024)) + " MB";
        } else {
            human = oneDecimal.format(bytes / (1024.0 * 1024 * 1024)) + " GB";
        }
        return human + " (" + grouped.format(bytes) + " bytes)";
    }
}
