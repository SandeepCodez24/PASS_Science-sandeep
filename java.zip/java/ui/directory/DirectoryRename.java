package ui.directory;

import java.io.IOException;
import java.nio.file.AccessDeniedException;
import java.nio.file.FileSystemException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Set;

/**
 * The rules and the file-system step behind the File Explorer's in-place
 * rename. The editing itself lives in {@link DirectoryNameCell}; the gestures
 * that start it (menu, F2, slow double-click) in {@link DirectoryTreeBuilder}
 * and {@link DirectorySlowClick}.
 *
 * <h3>Validation</h3>
 * <p>
 * A rejected name is reported under the field and the field stays open, as in
 * Windows Explorer, so {@link #validate(Path, String)} returns a sentence for
 * the user rather than throwing. The rules are Windows' own, applied on
 * Windows only; elsewhere only {@code /} and control characters are refused.
 * </p>
 *
 * <h3>Changing only the case</h3>
 * <p>
 * On Windows, {@code Files.move("notes.nc", "Notes.nc")} does nothing: the
 * two names are the same file, so Java returns without renaming.
 * {@link #move(Path, Path)} goes through a temporary name in that one case, so
 * a case-only rename takes effect.
 * </p>
 */
public final class DirectoryRename {

    /**
     * Performs a rename and everything that must go with it (undo history,
     * open editor tabs). Supplied by the file-operation layer.
     */
    @FunctionalInterface
    public interface Mover {

        /**
         * @param source the existing file or folder
         * @param target the new path, a sibling of {@code source}
         * @return the path the item now has
         * @throws IOException if the file system refused
         */
        Path move(Path source, Path target) throws IOException;
    }

    private static final boolean WINDOWS = System.getProperty("os.name", "")
            .toLowerCase(Locale.ROOT).startsWith("windows");

    private static final String WINDOWS_FORBIDDEN = "\\/:*?\"<>|";

    private static final Set<String> WINDOWS_RESERVED = Set.of(
            "CON", "PRN", "AUX", "NUL",
            "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9",
            "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9");

    private static final int MAX_NAME_LENGTH = 255;

    private DirectoryRename() {
    }

    /**
     * @param source the item being renamed
     * @param name   the new name, already trimmed
     * @return why the name cannot be used, or null when it can
     */
    public static String validate(Path source, String name) {
        if (name == null || name.isEmpty()) {
            return "A name is required.";
        }
        if (name.equals(".") || name.equals("..")) {
            return "'" + name + "' is not a valid name.";
        }
        if (name.length() > MAX_NAME_LENGTH) {
            return "The name is too long (at most " + MAX_NAME_LENGTH + " characters).";
        }
        for (int i = 0; i < name.length(); i++) {
            char c = name.charAt(i);
            if (c < 32 || c == '/' || (WINDOWS && WINDOWS_FORBIDDEN.indexOf(c) >= 0)) {
                return WINDOWS
                        ? "A name can't contain any of these characters:  \\ / : * ? \" < > |"
                        : "A name can't contain '/'.";
            }
        }
        if (WINDOWS) {
            char last = name.charAt(name.length() - 1);
            if (last == '.' || last == ' ') {
                return "A name can't end with a space or a period.";
            }
            int dot = name.indexOf('.');
            String stem = (dot < 0 ? name : name.substring(0, dot)).trim().toUpperCase(Locale.ROOT);
            if (WINDOWS_RESERVED.contains(stem)) {
                return "'" + stem + "' is a reserved name in Windows.";
            }
        }

        Path parent = source.getParent();
        if (parent == null) {
            return "A drive cannot be renamed here.";
        }
        Path target = parent.resolve(name);
        if (Files.exists(target) && !sameFile(source, target)) {
            return "'" + name + "' already exists in this folder.";
        }
        return null;
    }

    /**
     * Renames {@code source} to {@code target}, handling a case-only change.
     *
     * @param source the existing item
     * @param target its new path
     * @return {@code target}
     * @throws IOException if the file system refused
     */
    public static Path move(Path source, Path target) throws IOException {
        if (Files.exists(target) && sameFile(source, target)) {
            if (source.getFileName() != null && target.getFileName() != null
                    && source.getFileName().toString().equals(target.getFileName().toString())) {
                return target; // truly nothing to do
            }
            // Same file, different case: step through a temporary name.
            Path temp = source.resolveSibling(".astra-rename-" + System.nanoTime());
            Files.move(source, temp);
            try {
                Files.move(temp, target);
            } catch (IOException ex) {
                Files.move(temp, source); // put it back
                throw ex;
            }
            return target;
        }
        Files.move(source, target);
        return target;
    }

    /**
     * A user-facing sentence for a failed move.
     *
     * @param ex the failure
     * @return the message to show under the field
     */
    public static String describe(Exception ex) {
        if (ex instanceof AccessDeniedException) {
            return "Access denied. The item may be open in another program.";
        }
        if (ex instanceof NoSuchFileException) {
            return "The item no longer exists.";
        }
        if (ex instanceof FileSystemException fse && fse.getReason() != null) {
            return "Could not rename: " + fse.getReason();
        }
        String message = ex.getMessage();
        return "Could not rename" + (message == null || message.isBlank() ? "." : ": " + message);
    }

    /**
     * How much of the name to select when editing opens: the part before the
     * extension for a file, the whole name for a folder or a dot-file, as
     * Windows Explorer does.
     *
     * @param path the item
     * @param name its current name
     * @return the end offset of the initial selection
     */
    public static int selectionEnd(Path path, String name) {
        if (name == null) {
            return 0;
        }
        if (path != null && Files.isDirectory(path)) {
            return name.length();
        }
        int dot = name.lastIndexOf('.');
        return dot > 0 ? dot : name.length();
    }

    /**
     * @param path an item
     * @return its display name
     */
    public static String nameOf(Path path) {
        if (path == null) {
            return "";
        }
        Path file = path.getFileName();
        return file == null ? path.toString() : file.toString();
    }

    private static boolean sameFile(Path a, Path b) {
        try {
            return Files.isSameFile(a, b);
        } catch (IOException ex) {
            return false;
        }
    }
}
