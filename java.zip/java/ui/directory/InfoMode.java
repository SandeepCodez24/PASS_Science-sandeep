package ui.directory;

import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;

/**
 * What the Info column is currently measuring.
 *
 * <p>
 * One choice applies to the whole tree, the way a sort order does -- the column
 * has a single header, so it can only carry a single unit. The choice survives
 * restarts, because a user who works in lines does not want to reselect lines
 * every morning.
 * </p>
 *
 * <p>
 * {@link #LINES} is the default, as specified.
 * </p>
 */
public enum InfoMode {

    /** File size on disk. The only mode that applies to every file. */
    SIZE("By Size", "Size"),

    /** Physical line count. The default. */
    LINES("By Number of Lines", "Lines"),

    /** Top-level {@code function} blocks in a {@code .nc} file. */
    FUNCTIONS("By Functions", "Functions"),

    /** {@code class} blocks in a {@code .nc} file. */
    CLASSES("By Classes", "Classes");

    private static final Preferences PREFS = Preferences.userRoot().node("astra/directory");
    private static final String KEY = "infoMode";

    private final String label;
    private final String shortLabel;

    InfoMode(String label, String shortLabel) {
        this.label = label;
        this.shortLabel = shortLabel;
    }

    /**
     * @return the full name, shown in the drop-down menu, in the header's
     *         tooltip, and in the header itself when the Info column is wide
     *         enough to hold it
     */
    public String label() {
        return label;
    }

    /**
     * @return the one-word name the Info header falls back to when the column
     *         is too narrow for {@link #label()}
     */
    public String shortLabel() {
        return shortLabel;
    }

    /**
     * @return true if this mode means anything for a file that is not
     *         {@code .nc}; only {@link #SIZE} does
     */
    public boolean appliesToAllFiles() {
        return this == SIZE;
    }

    /**
     * @return the remembered mode, or {@link #LINES} if none was stored or the
     *         stored name is no longer a mode
     */
    public static InfoMode stored() {
        String raw = PREFS.get(KEY, LINES.name());
        try {
            return valueOf(raw);
        } catch (IllegalArgumentException e) {
            return LINES;
        }
    }

    /**
     * Remembers a mode for the next session.
     *
     * @param mode the mode; ignored if null
     */
    public static void store(InfoMode mode) {
        if (mode == null) {
            return;
        }
        PREFS.put(KEY, mode.name());
        try {
            PREFS.flush();
        } catch (BackingStoreException ignored) {
            // The choice still holds for this session.
        }
    }
}
