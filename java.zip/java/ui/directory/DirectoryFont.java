package ui.directory;

import java.util.Locale;
import javafx.scene.text.Font;

/**
 * The font the File Explorer's rows are drawn in -- the breadcrumb bar's
 * font -- so that the explorer's right-click menus and the Code Bot use the
 * same family and size instead of the larger default menu font.
 *
 * <p>
 * The font is not hard-coded here. It is read from a live row of the tree
 * ({@link DirectoryTreeBuilder#rowFont()}), which gets it from the generated
 * design stylesheet, so a change of the breadcrumb font in one place carries
 * to the menus and the bot as well. It is applied as an inline style, the one
 * kind of rule that a theme sheet's own {@code .label} or {@code .menu-item}
 * font cannot override.
 * </p>
 *
 * @param family the font family, e.g. "Segoe UI"
 * @param size   the size in logical pixels
 */
public record DirectoryFont(String family, double size) {

    /**
     * @return the font of the explorer's rows right now, or JavaFX's default
     *         font before the tree has drawn any row
     */
    public static DirectoryFont current() {
        Font font = DirectoryTreeBuilder.rowFont();
        if (font == null) {
            font = Font.getDefault();
        }
        return new DirectoryFont(font.getFamily(), font.getSize());
    }

    /** @return {@code -fx-font-family} and {@code -fx-font-size} at full size */
    public String css() {
        return css(1.0);
    }

    /**
     * @param scale a multiplier for secondary text (time stamps, hints)
     * @return {@code -fx-font-family} and {@code -fx-font-size}
     */
    public String css(double scale) {
        return "-fx-font-family: \"" + family.replace("\"", "") + "\"; " + sizeCss(scale);
    }

    /**
     * Size only, for text that keeps its own family (code blocks).
     *
     * @param scale a multiplier
     * @return {@code -fx-font-size}
     */
    public String sizeCss(double scale) {
        return String.format(Locale.ROOT, "-fx-font-size: %.2fpx;", size * scale);
    }
}
