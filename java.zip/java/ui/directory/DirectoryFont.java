package ui.directory;

import java.util.Locale;

import ui.design.DirectoryRowMetrics;
import ui.design.Typography;

/**
 * The font the File Explorer's rows are drawn in -- the one UI font size --
 * so that the explorer's right-click menus and the Code Bot use the same
 * family and size instead of the larger default menu font.
 *
 * <p>
 * The font comes straight from {@link Typography}
 * ({@link DirectoryRowMetrics#FONT_ROLE}), the same place the generated
 * stylesheet takes the rows' font from, so it is right at once after the Font
 * Size setting changes -- it no longer waits for a live row to be restyled.
 * It is applied as an inline style, the one kind of rule that a theme sheet's
 * own {@code .label} or {@code .menu-item} font cannot override.
 * </p>
 *
 * @param family the font family, e.g. "Segoe UI"
 * @param size   the size in logical pixels
 */
public record DirectoryFont(String family, double size) {

    /**
     * @return the font of the explorer's rows at the UI font size in force
     */
    public static DirectoryFont current() {
        return new DirectoryFont(Typography.family(DirectoryRowMetrics.FONT_ROLE),
                Typography.size(DirectoryRowMetrics.FONT_ROLE));
    }

    /** @return {@code -fx-font-family} and {@code -fx-font-size} at full size */
    public String css() {
        return css(1.0);
    }

    /**
     * @param scale a multiplier for secondary text (time stamps, hints)
     * @return {@code -fx-font-family} and {@code -fx-font-size}
     */
    public String css(double scale) {
        return "-fx-font-family: \"" + family.replace("\"", "") + "\"; " + sizeCss(scale);
    }

    /**
     * Size only, for text that keeps its own family (code blocks).
     *
     * @param scale a multiplier
     * @return {@code -fx-font-size}
     */
    public String sizeCss(double scale) {
        return String.format(Locale.ROOT, "-fx-font-size: %.2fpx;", size * scale);
    }
}
