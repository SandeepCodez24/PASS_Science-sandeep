package ui.directory;

import javafx.beans.InvalidationListener;
import javafx.geometry.Bounds;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.StrokeLineCap;
import javafx.scene.shape.StrokeLineJoin;
import javafx.stage.Window;
import ui.design.Typography;
import ui.design.section_dims.DirectoryMenu_dim;

/**
 * The note shown under the File Explorer's rename field, as MATLAB's Current
 * Folder does: an icon and one sentence, directly below the name being typed.
 *
 * <pre>
 *   [tes t _01.nc        ]
 *   +-------------------------------------------------------------------+
 *   | /!\  Spaces are not allowed in .nc file names. They will be ...   |
 *   +-------------------------------------------------------------------+
 * </pre>
 *
 * <h3>Two levels</h3>
 * <ul>
 * <li><b>Warning</b> (amber triangle) -- shown live, while the name is being
 * typed, for a .nc name that breaks the naming rule ({@link NcFileNames}). It
 * follows every key stroke and disappears as soon as the name is valid.</li>
 * <li><b>Error</b> (red circle) -- shown when Enter is pressed and the name
 * is refused: a duplicate, a forbidden character, a reserved word, a .nc name
 * that cannot be corrected. The field stays open.</li>
 * </ul>
 *
 * <h3>Why two tooltips rather than one with a changing style class</h3>
 * <p>
 * A {@link Tooltip}'s skin copies the tooltip's style classes onto its label
 * once, when the skin is created, and does not follow later changes. A class
 * added or removed after the first show would never reach the screen. So each
 * level has its own tooltip, classed before it is first shown, and only one of
 * them is ever showing.
 * </p>
 *
 * <h3>Look</h3>
 * <p>
 * Both carry {@link DirectoryNameCell#RENAME_ERROR_CLASS}, the class the
 * generated sheet sizes (row font, padding); the warning adds
 * {@link #WARNING_CLASS}, which only recolours it. The colours, and those of
 * the two marks, are in {@code light.css} / {@code dark.css}. The marks are
 * drawn as shapes, like the Repo column's dots, so they stay sharp at any
 * scale and take their colours from the theme.
 * </p>
 *
 * <h3>Staying with the field</h3>
 * <p>
 * The note is shown, not installed, and does not hide itself; the cell hides
 * it when the rename ends. If the window moves while it is showing, it hides
 * rather than float where the field used to be.
 * </p>
 */
final class DirectoryRenameHint {

    /** Which note to show. */
    enum Level {
        WARNING, ERROR
    }

    /** Added to the warning note; recolours it amber. */
    static final String WARNING_CLASS = "directory-rename-warning";

    /** The two marks and their glyphs; coloured in the theme files. */
    static final String MARK_WARNING_CLASS = "directory-rename-mark-warning";
    static final String MARK_ERROR_CLASS = "directory-rename-mark-error";
    static final String GLYPH_STROKE_CLASS = "directory-rename-glyph-stroke";
    static final String GLYPH_DOT_CLASS = "directory-rename-glyph-dot";

    private Tooltip warning;
    private Tooltip error;
    private Tooltip showing;

    /** The size the current marks were drawn at, so a font change redraws them. */
    private double markSize = -1;

    private Window watched;
    private final InvalidationListener windowMoved = observable -> hide();

    /**
     * Shows a note under a field, or updates the one already there.
     *
     * @param field   the rename field
     * @param level   warning or error
     * @param message the sentence; a blank one hides the note
     */
    void show(TextField field, Level level, String message) {
        if (field == null || message == null || message.isBlank()) {
            hide();
            return;
        }
        Tooltip tip = level == Level.ERROR ? error() : warning();
        if (showing != null && showing != tip) {
            showing.hide();
        }
        refreshMarks();
        if (!message.equals(tip.getText())) {
            tip.setText(message);
        }

        Bounds bounds = field.localToScreen(field.getBoundsInLocal());
        if (bounds == null) {
            return;
        }
        double x = bounds.getMinX();
        double y = bounds.getMaxY() + DirectoryMenu_dim.RENAME_HINT_OFFSET_Y;
        if (tip.isShowing()) {
            tip.setAnchorX(x);
            tip.setAnchorY(y);
        } else {
            tip.show(field, x, y);
        }
        showing = tip;

        Scene scene = field.getScene();
        watch(scene == null ? null : scene.getWindow());
    }

    /** Hides whichever note is showing. Safe to call at any time. */
    void hide() {
        if (warning != null && warning.isShowing()) {
            warning.hide();
        }
        if (error != null && error.isShowing()) {
            error.hide();
        }
        showing = null;
        watch(null);
    }

    // =====================================================================
    // Tooltips
    // =====================================================================

    private Tooltip warning() {
        if (warning == null) {
            warning = create(true);
        }
        return warning;
    }

    private Tooltip error() {
        if (error == null) {
            error = create(false);
        }
        return error;
    }

    private static Tooltip create(boolean isWarning) {
        Tooltip tip = new Tooltip();
        // Classes first: the skin copies them once, on first show.
        tip.getStyleClass().add(DirectoryNameCell.RENAME_ERROR_CLASS);
        if (isWarning) {
            tip.getStyleClass().add(WARNING_CLASS);
        }
        tip.setWrapText(true);
        tip.setMaxWidth(DirectoryMenu_dim.RENAME_HINT_MAX_WIDTH);
        tip.setAutoHide(false);
        tip.setContentDisplay(ContentDisplay.LEFT);
        tip.setGraphicTextGap(DirectoryMenu_dim.RENAME_HINT_ICON_GAP);
        return tip;
    }

    /** Redraws the marks if the UI font size changed since they were drawn. */
    private void refreshMarks() {
        double size = Math.max(DirectoryMenu_dim.RENAME_HINT_ICON_MIN,
                Math.round(Typography.size(Typography.Role.DIRECTORY_ROW)
                        * DirectoryMenu_dim.RENAME_HINT_ICON_RATIO));
        if (size == markSize) {
            return;
        }
        markSize = size;
        warning().setGraphic(warningMark(size));
        error().setGraphic(errorMark(size));
    }

    private void watch(Window window) {
        if (watched == window) {
            return;
        }
        if (watched != null) {
            watched.xProperty().removeListener(windowMoved);
            watched.yProperty().removeListener(windowMoved);
        }
        watched = window;
        if (watched != null) {
            watched.xProperty().addListener(windowMoved);
            watched.yProperty().addListener(windowMoved);
        }
    }

    // =====================================================================
    // Marks
    // =====================================================================

    /** An amber triangle with an exclamation mark, as MATLAB's warning. */
    private static Node warningMark(double s) {
        double h = s * 0.9;
        double top = (s - h) / 2.0;
        Polygon triangle = new Polygon(
                s / 2.0, top,
                s, top + h,
                0.0, top + h);
        triangle.setStrokeWidth(1);
        triangle.setStrokeLineJoin(StrokeLineJoin.ROUND);
        triangle.getStyleClass().add(MARK_WARNING_CLASS);

        Line bar = new Line(s / 2.0, top + h * 0.36, s / 2.0, top + h * 0.62);
        bar.setStrokeWidth(Math.max(1.2, s * 0.12));
        bar.setStrokeLineCap(StrokeLineCap.ROUND);
        bar.getStyleClass().add(GLYPH_STROKE_CLASS);

        Circle dot = new Circle(s / 2.0, top + h * 0.80, Math.max(0.8, s * 0.07));
        dot.getStyleClass().add(GLYPH_DOT_CLASS);

        return new Group(triangle, bar, dot);
    }

    /** A red disc with a cross, matching the "no such path" dialog's mark. */
    private static Node errorMark(double s) {
        double r = s / 2.0 - 0.5;
        Circle disc = new Circle(s / 2.0, s / 2.0, r);
        disc.setStrokeWidth(1);
        disc.getStyleClass().add(MARK_ERROR_CLASS);

        double arm = r * 0.42;
        double c = s / 2.0;
        double width = Math.max(1.2, s * 0.11);
        Line first = new Line(c - arm, c - arm, c + arm, c + arm);
        Line second = new Line(c - arm, c + arm, c + arm, c - arm);
        for (Line line : new Line[] {first, second}) {
            line.setStrokeWidth(width);
            line.setStrokeLineCap(StrokeLineCap.ROUND);
            line.getStyleClass().add(GLYPH_STROKE_CLASS);
        }
        return new Group(disc, first, second);
    }
}
