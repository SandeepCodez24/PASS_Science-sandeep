package ui.directory;

import java.util.Locale;

/**
 * The naming rule for Neural Code ({@code .nc}) files, in one place, so the
 * File Explorer's rename, its paste naming and the Home ribbon's Save As all
 * agree on what a valid name is.
 *
 * <h3>The rule</h3>
 * <p>
 * The part before {@code .nc} must be an identifier, as in MATLAB: it starts
 * with a letter ({@code A-Z}, {@code a-z}) and goes on with letters, digits
 * ({@code 0-9}) and underscores only. A function or class file is called by
 * its name, so a name that is not an identifier could never be called.
 * </p>
 * <p>
 * Only ASCII letters count, as in MATLAB: a file name has to survive every
 * file system, archive tool and command line the project may meet. Other
 * files ({@code .txt}, folders, ...) are not touched by this rule.
 * </p>
 *
 * <h3>Spaces are corrected, everything else is refused</h3>
 * <p>
 * Spaces are the common slip, and their intent is clear, so they are fixed
 * rather than refused: each run of white space becomes one underscore, and
 * white space at either end of the name is dropped ({@code "test 01.nc"} becomes
 * {@code "test_01.nc"}). Anything else -- a leading digit, a hyphen, a dot --
 * is refused with a sentence saying why, because there is no single obvious
 * correction for it.
 * </p>
 *
 * <pre>
 *   test_01.nc     VALID
 *   test 01.nc     FIXABLE   -&gt; test_01.nc
 *   1test.nc       INVALID   must start with a letter
 *   my-file 2.nc   INVALID   '-' cannot be used (the space alone would be fixed)
 * </pre>
 */
public final class NcFileNames {

    /** The extension the rule applies to, with its dot. */
    public static final String EXTENSION = NcMetrics.NC_EXTENSION;

    /** The rule in one sentence, for places that cannot be more specific. */
    public static final String RULE =
            "A .nc file name must start with a letter and can only contain letters, digits and underscores.";

    /** What {@link #check(String)} found. */
    public enum Status {
        /** Not a .nc name, or a valid one. */
        VALID,
        /** Contains spaces; valid once they become underscores. */
        FIXABLE,
        /** Breaks the rule in a way that is not corrected automatically. */
        INVALID
    }

    /**
     * The result of checking one name.
     *
     * @param status  what was found
     * @param name    the name to use: as given for VALID and INVALID, the
     *                corrected name for FIXABLE
     * @param message a sentence for the user; null for VALID
     */
    public record Check(Status status, String name, String message) {

        /** @return true if the name can be used as it is */
        public boolean isValid() {
            return status == Status.VALID;
        }

        /** @return true if the name is usable once its spaces are replaced */
        public boolean isFixable() {
            return status == Status.FIXABLE;
        }

        /** @return true if the name cannot be used */
        public boolean isInvalid() {
            return status == Status.INVALID;
        }
    }

    private NcFileNames() {
    }

    // =====================================================================
    // Public API
    // =====================================================================

    /**
     * @param name a file name (not a path); may be null
     * @return true if it ends in {@code .nc}, in any case
     */
    public static boolean isNc(String name) {
        return name != null && name.toLowerCase(Locale.ROOT).endsWith(EXTENSION);
    }

    /**
     * @param name a file name
     * @return true if it is not a .nc name, or is a valid one
     */
    public static boolean isValid(String name) {
        return check(name).isValid();
    }

    /**
     * Checks a file name against the rule.
     *
     * @param name a file name, already stripped of white space at either end;
     *             may be null
     * @return the result; never null
     */
    public static Check check(String name) {
        if (!isNc(name)) {
            return new Check(Status.VALID, name, null);
        }
        String ext = extensionOf(name);
        String stem = name.substring(0, name.length() - ext.length());

        String problem = problem(stem);
        if (problem == null) {
            return new Check(Status.VALID, name, null);
        }
        if (!hasWhitespace(stem)) {
            return new Check(Status.INVALID, name, problem);
        }

        String fixedStem = replaceWhitespace(stem);
        String remaining = problem(fixedStem);
        if (remaining != null) {
            // The spaces would be fixed, but something else would still be
            // wrong: report that, since it is what the user has to change.
            return new Check(Status.INVALID, name, remaining);
        }
        String fixed = fixedStem + ext;
        return new Check(Status.FIXABLE, fixed,
                "Spaces are not allowed in .nc file names. They will be replaced with underscores: "
                        + fixed);
    }

    /**
     * A valid name as close as possible to {@code name}, in the way MATLAB's
     * {@code matlab.lang.makeValidName} works: white space and any other
     * character that is not allowed become underscores, and a name that does
     * not start with a letter gets an {@code x} in front. Used to pre-fill a
     * Save dialog after a name was refused.
     *
     * @param name a file name; may be null
     * @return a valid name; a non-.nc name is returned unchanged
     */
    public static String suggest(String name) {
        Check check = check(name);
        if (check.isValid() || check.isFixable()) {
            return check.name();
        }
        String ext = extensionOf(name);
        String stem = replaceWhitespace(name.substring(0, name.length() - ext.length()));

        StringBuilder out = new StringBuilder(stem.length() + 1);
        for (int i = 0; i < stem.length(); i++) {
            char c = stem.charAt(i);
            out.append(isIdentifierPart(c) ? c : '_');
        }
        if (out.length() == 0) {
            return "Untitled" + ext;
        }
        if (!isAsciiLetter(out.charAt(0))) {
            out.insert(0, 'x');
        }
        return out + ext;
    }

    // =====================================================================
    // Internals
    // =====================================================================

    /** The user's own spelling of the extension (".nc", ".NC", ...). */
    private static String extensionOf(String name) {
        return name.substring(name.length() - EXTENSION.length());
    }

    /** @return why a stem is not an identifier, or null if it is one */
    private static String problem(String stem) {
        if (stem.isEmpty()) {
            return "Type a name before \".nc\".";
        }
        char first = stem.charAt(0);
        if (!isAsciiLetter(first)) {
            if (isWhitespace(first)) {
                return "A .nc file name can't contain spaces.";
            }
            if (first >= '0' && first <= '9') {
                return "A .nc file name must start with a letter, not a digit.";
            }
            if (first == '_') {
                return "A .nc file name must start with a letter, not an underscore.";
            }
            return "A .nc file name must start with a letter.";
        }
        for (int i = 1; i < stem.length(); i++) {
            char c = stem.charAt(i);
            if (isIdentifierPart(c)) {
                continue;
            }
            if (isWhitespace(c)) {
                return "A .nc file name can't contain spaces.";
            }
            return "'" + c + "' can't be used in a .nc file name. Use letters, digits and underscores only.";
        }
        return null;
    }

    /** Ends trimmed, each inner run of white space made one underscore. */
    private static String replaceWhitespace(String stem) {
        StringBuilder out = new StringBuilder(stem.length());
        boolean inRun = false;
        for (int i = 0; i < stem.length(); i++) {
            char c = stem.charAt(i);
            if (isWhitespace(c)) {
                inRun = true;
                continue;
            }
            if (inRun && out.length() > 0) {
                out.append('_');
            }
            inRun = false;
            out.append(c);
        }
        return out.toString();
    }

    private static boolean hasWhitespace(String text) {
        for (int i = 0; i < text.length(); i++) {
            if (isWhitespace(text.charAt(i))) {
                return true;
            }
        }
        return false;
    }

    /** Ordinary white space plus the non-breaking space a paste can bring in. */
    private static boolean isWhitespace(char c) {
        return Character.isWhitespace(c) || c == ' ' || c == ' ' || c == ' ';
    }

    private static boolean isAsciiLetter(char c) {
        return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z');
    }

    private static boolean isIdentifierPart(char c) {
        return isAsciiLetter(c) || (c >= '0' && c <= '9') || c == '_';
    }
}
