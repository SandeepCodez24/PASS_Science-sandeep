package ui.directory;

import java.io.File;
import java.io.IOException;
import java.lang.foreign.Arena;
import java.lang.foreign.FunctionDescriptor;
import java.lang.foreign.Linker;
import java.lang.foreign.MemorySegment;
import java.lang.foreign.SymbolLookup;
import java.lang.foreign.ValueLayout;
import java.lang.invoke.MethodHandle;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import javafx.application.Platform;
import javafx.stage.Window;

/**
 * The operating-system side of the File Explorer's menu: the native
 * <b>Properties</b> dialog, <b>Open in Explorer</b>, and moving a file to the
 * Recycle Bin / Trash.
 *
 * <h3>Properties, per platform</h3>
 * <dl>
 * <dt>Windows</dt>
 * <dd>The real Windows Properties sheet, opened with
 * {@code ShellExecuteExW(verb "properties", SEE_MASK_INVOKEIDLIST)} -- the
 * same call Explorer makes. It is reached through the JDK's own Foreign
 * Function API (final since JDK 22), so no library is added to the pom. The
 * call runs on one long-lived background thread with COM initialised
 * (single-threaded apartment), which the shell requires; the sheet itself is
 * modeless and lives on after the call returns, exactly as in Explorer.</dd>
 * <dt>macOS</dt>
 * <dd>Finder's own <i>Get Info</i> window, through {@code osascript}.</dd>
 * <dt>Linux</dt>
 * <dd>The desktop file manager's own properties dialog, through the
 * freedesktop {@code org.freedesktop.FileManager1.ShowItemProperties} D-Bus
 * call, which Nautilus, Dolphin, Nemo, Caja and Thunar answer.</dd>
 * </dl>
 * <p>
 * If the native route fails -- an unusual Linux desktop, a sandbox, native
 * access switched off -- {@link DirectoryPropertiesWindow} opens instead, so
 * the menu entry always does something.
 * </p>
 *
 * <h3>Native access</h3>
 * <p>
 * The Windows call is a "restricted" method. JDK 25 runs it, but prints a
 * one-line warning unless the JVM is started with
 * {@code --enable-native-access=ALL-UNNAMED} (or the module name, if Astra is
 * ever made modular). Add that flag next to the JavaFX one in the pom's
 * javafx-maven-plugin options and in the launcher of the shipped .exe.
 * </p>
 */
public final class DirectoryShell {

    /** The host platform, decided once. */
    public enum Os {
        WINDOWS, MAC, LINUX;

        static Os detect() {
            String name = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
            if (name.startsWith("windows")) {
                return WINDOWS;
            }
            if (name.contains("mac") || name.contains("darwin")) {
                return MAC;
            }
            return LINUX;
        }
    }

    public static final Os OS = Os.detect();

    /** Background work: process launches, trash moves, the Windows shell call. */
    private static final ExecutorService WORKER = Executors.newSingleThreadExecutor(runnable -> {
        Thread thread = new Thread(runnable, "astra-explorer-shell");
        thread.setDaemon(true);
        return thread;
    });

    private DirectoryShell() {
    }

    // =====================================================================
    // Labels
    // =====================================================================

    /**
     * @return the platform's name for "show this folder in the file manager"
     */
    public static String openInFileManagerLabel() {
        return switch (OS) {
            case WINDOWS -> "Open in Explorer";
            case MAC -> "Open in Finder";
            case LINUX -> "Open in File Manager";
        };
    }

    /**
     * @return the platform's name for the bin
     */
    public static String trashName() {
        return OS == Os.WINDOWS ? "Recycle Bin" : "Trash";
    }

    // =====================================================================
    // Open in Explorer
    // =====================================================================

    /**
     * Opens the platform file manager on a folder.
     *
     * @param folder  the folder to show
     * @param onError receives a message if nothing could be opened (FX thread)
     */
    public static void openInFileManager(Path folder, Consumer<String> onError) {
        if (folder == null || !Files.isDirectory(folder)) {
            report(onError, "The folder no longer exists.");
            return;
        }
        String target = folder.toAbsolutePath().toString();
        List<String> command = switch (OS) {
            case WINDOWS -> List.of("explorer.exe", target);
            case MAC -> List.of("open", target);
            case LINUX -> List.of("xdg-open", target);
        };
        WORKER.execute(() -> {
            try {
                Process process = new ProcessBuilder(command).redirectErrorStream(true).start();
                // explorer.exe reports exit code 1 even on success, so only
                // the other platforms' exit codes are meaningful.
                if (OS != Os.WINDOWS && process.waitFor(5, TimeUnit.SECONDS) && process.exitValue() != 0) {
                    report(onError, "The file manager could not be opened.");
                }
            } catch (IOException ex) {
                report(onError, "The file manager could not be opened: " + ex.getMessage());
            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
            }
        });
    }

    // =====================================================================
    // Properties
    // =====================================================================

    /**
     * Shows the operating system's Properties dialog for a file or folder,
     * falling back to Astra's own window if that is not possible.
     *
     * @param path  the item
     * @param owner owner for the fallback window, may be null
     */
    public static void showProperties(Path path, Window owner) {
        if (path == null || !Files.exists(path)) {
            return;
        }
        Path absolute = path.toAbsolutePath();
        WORKER.execute(() -> {
            boolean shown;
            try {
                shown = switch (OS) {
                    case WINDOWS -> WindowsShell.properties(absolute);
                    case MAC -> run(List.of("osascript",
                            "-e", "tell application \"Finder\" to open information window of ("
                                    + "POSIX file \"" + escapeAppleScript(absolute.toString()) + "\" as alias)",
                            "-e", "tell application \"Finder\" to activate"));
                    case LINUX -> run(List.of("dbus-send", "--session", "--print-reply",
                            "--dest=org.freedesktop.FileManager1",
                            "--type=method_call",
                            "/org/freedesktop/FileManager1",
                            "org.freedesktop.FileManager1.ShowItemProperties",
                            "array:string:" + absolute.toUri(),
                            "string:"));
                };
            } catch (Throwable ex) {
                // UnsatisfiedLinkError, IllegalCallerException (native access
                // denied), a missing osascript/dbus-send: all mean "fall back".
                shown = false;
            }
            if (!shown) {
                Platform.runLater(() -> DirectoryPropertiesWindow.show(absolute, owner));
            }
        });
    }

    private static String escapeAppleScript(String text) {
        return text.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    // =====================================================================
    // Trash
    // =====================================================================

    /**
     * Moves an item to the Recycle Bin / Trash. Blocking; call from a
     * background thread.
     *
     * @param path the item
     * @return true if the item is now in the bin
     */
    public static boolean moveToTrash(Path path) {
        String absolute = path.toAbsolutePath().toString();
        try {
            // macOS: Finder's own "Move to Trash" (keeps "Put Back" working)
            // and never wakes AWT inside a JavaFX process.
            if (OS == Os.MAC) {
                return run(List.of("osascript", "-e",
                        "tell application \"Finder\" to delete (POSIX file \""
                                + escapeAppleScript(absolute) + "\" as alias)"));
            }
            // Linux: GLib's trash, which every mainstream desktop shares.
            if (OS == Os.LINUX && run(List.of("gio", "trash", absolute))) {
                return true;
            }
        } catch (IOException ex) {
            // fall through to AWT
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            return false;
        }
        // Windows (and Linux without gio): the JDK's own Recycle Bin call.
        File file = path.toFile();
        try {
            if (java.awt.Desktop.isDesktopSupported()) {
                java.awt.Desktop desktop = java.awt.Desktop.getDesktop();
                if (desktop.isSupported(java.awt.Desktop.Action.MOVE_TO_TRASH)) {
                    return desktop.moveToTrash(file);
                }
            }
        } catch (RuntimeException | Error ex) {
            // Headless or unsupported.
        }
        return false;
    }

    /**
     * Runs a blocking task on the shell worker.
     *
     * @param task the work
     */
    static void background(Runnable task) {
        WORKER.execute(task);
    }

    // =====================================================================
    // Helpers
    // =====================================================================

    private static boolean run(List<String> command) throws IOException, InterruptedException {
        Process process = new ProcessBuilder(command).redirectErrorStream(true).start();
        process.getInputStream().transferTo(java.io.OutputStream.nullOutputStream());
        if (!process.waitFor(10, TimeUnit.SECONDS)) {
            process.destroy();
            return false;
        }
        return process.exitValue() == 0;
    }

    private static void report(Consumer<String> onError, String message) {
        if (onError != null) {
            Platform.runLater(() -> onError.accept(message));
        }
    }

    // =====================================================================
    // Windows: ShellExecuteExW through the Foreign Function API
    // =====================================================================

    /**
     * {@code ShellExecuteExW} with the "properties" verb.
     *
     * <p>
     * Layout of {@code SHELLEXECUTEINFOW} on 64-bit Windows (x64 and ARM64
     * alike), 112 bytes:
     * </p>
     * <pre>
     *   0  DWORD   cbSize          4  ULONG  fMask
     *   8  HWND    hwnd           16  LPCWSTR lpVerb
     *  24  LPCWSTR lpFile         32  LPCWSTR lpParameters
     *  40  LPCWSTR lpDirectory    48  int    nShow (+4 pad)
     *  56  HINSTANCE hInstApp     64  void*  lpIDList
     *  72  LPCWSTR lpClass        80  HKEY   hkeyClass
     *  88  DWORD   dwHotKey (+4)  96  HANDLE hIcon / hMonitor
     * 104  HANDLE  hProcess
     * </pre>
     */
    private static final class WindowsShell {

        private static final int STRUCT_SIZE = 112;
        private static final int SEE_MASK_INVOKEIDLIST = 0x0000000C;
        private static final int SEE_MASK_FLAG_NO_UI = 0x00000400;
        private static final int SW_SHOW = 5;
        private static final int COINIT_APARTMENTTHREADED = 0x2;

        private static MethodHandle shellExecuteEx;
        private static boolean comReady;

        private WindowsShell() {
        }

        /** Runs on the shell worker thread only. */
        static boolean properties(Path path) throws Throwable {
            if (shellExecuteEx == null) {
                Linker linker = Linker.nativeLinker();
                Arena global = Arena.global();
                SymbolLookup shell32 = SymbolLookup.libraryLookup("shell32", global);
                SymbolLookup ole32 = SymbolLookup.libraryLookup("ole32", global);

                MethodHandle coInitializeEx = linker.downcallHandle(
                        ole32.find("CoInitializeEx").orElseThrow(),
                        FunctionDescriptor.of(ValueLayout.JAVA_INT, ValueLayout.ADDRESS, ValueLayout.JAVA_INT));
                shellExecuteEx = linker.downcallHandle(
                        shell32.find("ShellExecuteExW").orElseThrow(),
                        FunctionDescriptor.of(ValueLayout.JAVA_INT, ValueLayout.ADDRESS));

                if (!comReady) {
                    // S_OK or S_FALSE (already initialised) are both fine.
                    int hr = (int) coInitializeEx.invokeExact(MemorySegment.NULL, COINIT_APARTMENTTHREADED);
                    comReady = hr >= 0;
                }
            }

            // Auto arena: the strings stay alive until the GC is sure nothing
            // refers to them, which comfortably outlives the shell's read.
            Arena arena = Arena.ofAuto();
            MemorySegment info = arena.allocate(STRUCT_SIZE, 8);
            MemorySegment verb = arena.allocateFrom("properties", StandardCharsets.UTF_16LE);
            MemorySegment file = arena.allocateFrom(path.toString(), StandardCharsets.UTF_16LE);

            info.set(ValueLayout.JAVA_INT, 0, STRUCT_SIZE);
            info.set(ValueLayout.JAVA_INT, 4, SEE_MASK_INVOKEIDLIST | SEE_MASK_FLAG_NO_UI);
            info.set(ValueLayout.ADDRESS, 16, verb);
            info.set(ValueLayout.ADDRESS, 24, file);
            info.set(ValueLayout.JAVA_INT, 48, SW_SHOW);

            int ok = (int) shellExecuteEx.invokeExact(info);
            return ok != 0;
        }
    }
}
