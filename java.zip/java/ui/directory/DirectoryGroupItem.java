package ui.directory;

import java.nio.file.Path;
import javafx.scene.control.TreeItem;

/**
 * A group title row ("A - G", "Today", "NC file") under a folder while
 * <b>Group by</b> is on.
 *
 * <p>
 * Its value is {@code null} on purpose. Every file operation in the explorer
 * works on the row's path, and a title row has none: a null value makes Cut,
 * Delete, Rename and double-click-to-open simply find nothing to act on,
 * instead of acting on some stand-in path. The cells recognise a group row by
 * its class and draw the title themselves.
 * </p>
 *
 * <p>
 * Groups start expanded. They are kept and reused by {@link #key()} across a
 * refresh or a re-sort, so a group the user collapsed stays collapsed.
 * </p>
 */
public final class DirectoryGroupItem extends TreeItem<Path> {

    private final String key;
    private String title;

    DirectoryGroupItem(String key, String title) {
        super(null);
        this.key = key;
        this.title = title;
        setExpanded(true);
    }

    /** @return identity of the group, stable across refreshes */
    public String key() {
        return key;
    }

    /** @return the group's title, e.g. "A \u2013 G" */
    public String title() {
        return title;
    }

    void setTitle(String title) {
        this.title = title;
    }

    /** @return the number of rows directly in the group */
    public int count() {
        return getChildren().size();
    }

    /**
     * @return the folder this group belongs to, or null if detached
     */
    public Path folder() {
        TreeItem<Path> parent = getParent();
        return parent == null ? null : parent.getValue();
    }

    @Override
    public boolean isLeaf() {
        return false;
    }

    /**
     * @param item any tree item
     * @return true if it is a group title row
     */
    public static boolean isGroup(TreeItem<?> item) {
        return item instanceof DirectoryGroupItem;
    }
}
