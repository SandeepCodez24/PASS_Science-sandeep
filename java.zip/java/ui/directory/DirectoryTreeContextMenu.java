package ui.directory;

import java.nio.file.Files;
import java.nio.file.Path;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.RadioMenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;

/**
 * The File Explorer's two right-click menus.
 *
 * <pre>
 *   Right-click on a file or folder        Right-click on empty space
 *   ------------------------------         ------------------------------
 *   Cut                    Ctrl+X          New                        >
 *   Copy                   Ctrl+C          ------------------------------
 *   ------------------------------         Paste                  Ctrl+V
 *   Delete                 Delete          ------------------------------
 *   Rename                     F2          Sort by                    >
 *   ------------------------------         Group by                   >
 *   Undo ...               Ctrl+Z          Refresh                    F5
 *   Redo ...               Ctrl+Y          ------------------------------
 *   ------------------------------         Undo ...               Ctrl+Z
 *   Properties          Alt+Enter          Redo ...               Ctrl+Y
 *                                          ------------------------------
 *                                          Open in Explorer
 *                                          Properties          Alt+Enter
 *
 *   New      >  New Folder | New Script, New Function, New Class, New Text
 *   Sort by  >  Name, Type, Date modified, Size | Ascending, Descending
 *   Group by >  Name, Type, Date modified, Size, None | Ascending, Descending
 * </pre>
 *
 * <h3>Shortcuts</h3>
 * <p>
 * Each shortcut is shown at the right end of its row through the item's
 * accelerator. The menus are always opened with {@code ContextMenu.show}, never
 * attached with {@code setContextMenu}: an attached menu registers its
 * accelerators with the whole scene, which would make Ctrl+C in the editor
 * copy a file. The keys themselves are handled by the tree only while it has
 * focus (see {@code DirectoryTreeBuilder}), using the same combinations as
 * below. On macOS the combinations show and work with Command.
 * </p>
 *
 * <h3>Size and font</h3>
 * <p>
 * The menus take their natural width -- no extra widening -- and use the
 * explorer rows' own font ({@link DirectoryFont}), the same family and size as
 * the breadcrumb bar and the file names, rather than the larger default menu
 * font. The font is applied inline to every row, submenu rows included,
 * because a submenu opens in its own popup and would not inherit it.
 * </p>
 *
 * <h3>Files and folders</h3>
 * <p>
 * A folder currently gets the file menu ({@link #forFolder} delegates to
 * {@link #forFile}). Folder-only entries belong in {@link #forFolder} when they
 * come; nothing else needs to change.
 * </p>
 */
public final class DirectoryTreeContextMenu {

    /** Style class of both menus (and their submenus). */
    public static final String MENU_CLASS = "directory-tree-menu";

    /** Style class of the three submenu rows, for the chevron styling. */
    public static final String SUBMENU_CLASS = "directory-tree-submenu";

    private static final boolean MAC = DirectoryShell.OS == DirectoryShell.Os.MAC;

    // ---- shortcuts, shared with the tree's key handler --------------------
    public static final KeyCombination CUT = new KeyCodeCombination(KeyCode.X, KeyCombination.SHORTCUT_DOWN);
    public static final KeyCombination COPY = new KeyCodeCombination(KeyCode.C, KeyCombination.SHORTCUT_DOWN);
    public static final KeyCombination PASTE = new KeyCodeCombination(KeyCode.V, KeyCombination.SHORTCUT_DOWN);
    public static final KeyCombination DELETE = new KeyCodeCombination(KeyCode.DELETE);
    public static final KeyCombination RENAME = new KeyCodeCombination(KeyCode.F2);
    public static final KeyCombination UNDO = new KeyCodeCombination(KeyCode.Z, KeyCombination.SHORTCUT_DOWN);
    public static final KeyCombination REDO = MAC
            ? new KeyCodeCombination(KeyCode.Z, KeyCombination.SHORTCUT_DOWN, KeyCombination.SHIFT_DOWN)
            : new KeyCodeCombination(KeyCode.Y, KeyCombination.SHORTCUT_DOWN);
    public static final KeyCombination REFRESH = new KeyCodeCombination(KeyCode.F5);
    public static final KeyCombination PROPERTIES = MAC
            ? new KeyCodeCombination(KeyCode.I, KeyCombination.SHORTCUT_DOWN)
            : new KeyCodeCombination(KeyCode.ENTER, KeyCombination.ALT_DOWN);

    private DirectoryTreeContextMenu() {
    }

    // =====================================================================
    // Menus
    // =====================================================================

    /**
     * The menu for a row: {@link #forFolder} or {@link #forFile}.
     *
     * @param path    the row's path
     * @param actions what the entries do
     * @return the menu, or null if there is nothing to show
     */
    public static ContextMenu forItem(Path path, Actions actions) {
        if (path == null || actions == null) {
            return null;
        }
        return Files.isDirectory(path) ? forFolder(path, actions) : forFile(path, actions);
    }

    /**
     * The menu for a folder row. Same as a file's for now; folder-only
     * entries (Open, New inside, Paste into) will be added here.
     */
    public static ContextMenu forFolder(Path folder, Actions actions) {
        return forFile(folder, actions);
    }

    /** The menu for a file row. */
    public static ContextMenu forFile(Path path, Actions actions) {
        boolean modifiable = actions.canModify(path);

        MenuItem cut = item("Cut", "cut", CUT, () -> actions.cut(path));
        cut.setDisable(!modifiable);
        MenuItem copy = item("Copy", "copy", COPY, () -> actions.copy(path));
        copy.setDisable(!Files.exists(path));

        MenuItem delete = item("Delete", "delete", DELETE, () -> actions.delete(path));
        delete.setDisable(!modifiable);
        MenuItem rename = item("Rename", "rename", RENAME, () -> actions.rename(path));
        rename.setDisable(!Files.exists(path));

        MenuItem properties = item("Properties", "properties", PROPERTIES, () -> actions.properties(path));

        ContextMenu menu = menu();
        menu.getItems().addAll(
                cut,
                copy,
                new SeparatorMenuItem(),
                delete,
                rename,
                new SeparatorMenuItem(),
                undoItem(actions),
                redoItem(actions),
                new SeparatorMenuItem(),
                properties);
        return applyFont(menu);
    }

    /**
     * The menu for empty space: acts on the folder the tree is showing (or,
     * for a group title row, the folder the group belongs to).
     *
     * @param folder  the folder
     * @param actions what the entries do
     * @return the menu
     */
    public static ContextMenu forEmptySpace(Path folder, Actions actions) {
        if (folder == null || actions == null) {
            return null;
        }

        MenuItem paste = item("Paste", "paste", PASTE, () -> actions.paste(folder));
        paste.setDisable(!actions.canPaste());

        MenuItem refresh = item("Refresh", "refresh", REFRESH, actions::refresh);

        MenuItem open = item(DirectoryShell.openInFileManagerLabel(), "open_in_explorer", null,
                () -> actions.openInFileManager(folder));

        MenuItem properties = item("Properties", "properties", PROPERTIES, () -> actions.properties(folder));

        ContextMenu menu = menu();
        menu.getItems().addAll(
                newMenu(folder, actions),
                new SeparatorMenuItem(),
                paste,
                new SeparatorMenuItem(),
                sortMenu(actions),
                groupMenu(actions),
                refresh,
                new SeparatorMenuItem(),
                undoItem(actions),
                redoItem(actions),
                new SeparatorMenuItem(),
                open,
                properties);
        return applyFont(menu);
    }

    // =====================================================================
    // Submenus
    // =====================================================================

    private static Menu newMenu(Path folder, Actions actions) {
        Menu menu = submenu("New", DirectoryMenuIcons.homeFiles("new"));
        for (NewItemKind kind : NewItemKind.values()) {
            MenuItem entry = new MenuItem(kind.label(),
                    DirectoryMenuIcons.view(kind.iconFolder(), kind.iconName()));
            entry.setOnAction(event -> actions.create(folder, kind));
            menu.getItems().add(entry);
            if (kind == NewItemKind.FOLDER) {
                menu.getItems().add(new SeparatorMenuItem());
            }
        }
        return menu;
    }

    private static Menu sortMenu(Actions actions) {
        Menu menu = submenu("Sort by", DirectoryMenuIcons.explorer("sort_by"));

        ToggleGroup keys = new ToggleGroup();
        for (DirectoryViewSettings.SortKey key : DirectoryViewSettings.SortKey.values()) {
            RadioMenuItem entry = new RadioMenuItem(key.label());
            entry.setToggleGroup(keys);
            entry.setSelected(key == DirectoryViewSettings.sortKey());
            entry.setOnAction(event -> {
                if (DirectoryViewSettings.setSortKey(key)) {
                    actions.viewChanged();
                }
            });
            menu.getItems().add(entry);
        }
        menu.getItems().add(new SeparatorMenuItem());
        addDirection(menu, DirectoryViewSettings.sortAscending(), false, ascending -> {
            if (DirectoryViewSettings.setSortAscending(ascending)) {
                actions.viewChanged();
            }
        });
        return menu;
    }

    private static Menu groupMenu(Actions actions) {
        Menu menu = submenu("Group by", DirectoryMenuIcons.explorer("group_by"));

        ToggleGroup keys = new ToggleGroup();
        for (DirectoryViewSettings.GroupKey key : DirectoryViewSettings.GroupKey.values()) {
            RadioMenuItem entry = new RadioMenuItem(key.label());
            entry.setToggleGroup(keys);
            entry.setSelected(key == DirectoryViewSettings.groupKey());
            entry.setOnAction(event -> {
                if (DirectoryViewSettings.setGroupKey(key)) {
                    actions.viewChanged();
                }
            });
            menu.getItems().add(entry);
        }
        menu.getItems().add(new SeparatorMenuItem());
        addDirection(menu, DirectoryViewSettings.groupAscending(), !DirectoryViewSettings.isGrouped(),
                ascending -> {
                    if (DirectoryViewSettings.setGroupAscending(ascending)) {
                        actions.viewChanged();
                    }
                });
        return menu;
    }

    /** Appends the Ascending / Descending pair to a submenu. */
    private static void addDirection(Menu menu, boolean ascending, boolean disabled,
            java.util.function.Consumer<Boolean> apply) {
        ToggleGroup direction = new ToggleGroup();
        RadioMenuItem up = new RadioMenuItem("Ascending");
        RadioMenuItem down = new RadioMenuItem("Descending");
        up.setToggleGroup(direction);
        down.setToggleGroup(direction);
        up.setSelected(ascending);
        down.setSelected(!ascending);
        up.setDisable(disabled);
        down.setDisable(disabled);
        up.setOnAction(event -> apply.accept(true));
        down.setOnAction(event -> apply.accept(false));
        menu.getItems().addAll(up, down);
    }

    // =====================================================================
    // Undo / Redo rows, shared by both menus
    // =====================================================================

    private static MenuItem undoItem(Actions actions) {
        String text = actions.undoText();
        MenuItem undo = item(text == null ? "Undo" : text, "undo", UNDO, actions::undo);
        undo.setDisable(text == null);
        return undo;
    }

    private static MenuItem redoItem(Actions actions) {
        String text = actions.redoText();
        MenuItem redo = item(text == null ? "Redo" : text, "redo", REDO, actions::redo);
        redo.setDisable(text == null);
        return redo;
    }

    // =====================================================================
    // Building blocks
    // =====================================================================

    private static ContextMenu menu() {
        ContextMenu menu = new ContextMenu();
        menu.getStyleClass().add(MENU_CLASS);
        return menu;
    }

    /**
     * Gives the menu and every row in it, down through the submenus, the
     * explorer's row font.
     */
    private static ContextMenu applyFont(ContextMenu menu) {
        String style = DirectoryFont.current().css();
        menu.setStyle(style);
        applyFont(menu.getItems(), style);
        return menu;
    }

    private static void applyFont(java.util.List<MenuItem> items, String style) {
        for (MenuItem item : items) {
            item.setStyle(style);
            if (item instanceof Menu submenu) {
                applyFont(submenu.getItems(), style);
            }
        }
    }

    private static Menu submenu(String label, ImageView icon) {
        Menu menu = new Menu(label, icon);
        menu.getStyleClass().add(SUBMENU_CLASS);
        return menu;
    }

    private static MenuItem item(String label, String icon, KeyCombination shortcut, Runnable action) {
        MenuItem item = new MenuItem(label, DirectoryMenuIcons.explorer(icon));
        if (shortcut != null) {
            // Display only: the menu is shown, never attached, so this does not
            // register a scene-wide accelerator.
            item.setAccelerator(shortcut);
        }
        item.setOnAction(event -> action.run());
        return item;
    }

    // =====================================================================
    // Actions
    // =====================================================================

    /**
     * What the menu entries do. Implemented by {@link DirectoryFileOps}.
     */
    public interface Actions {

        /** @return false for the tree's root folder and for missing items */
        boolean canModify(Path item);

        void cut(Path item);

        void copy(Path item);

        void delete(Path item);

        void rename(Path item);

        void properties(Path item);

        void create(Path folder, NewItemKind kind);

        boolean canPaste();

        void paste(Path folder);

        void refresh();

        void openInFileManager(Path folder);

        /** @return "Undo Rename" and so on, or null when there is nothing to undo */
        String undoText();

        /** @return "Redo Rename" and so on, or null when there is nothing to redo */
        String redoText();

        void undo();

        void redo();

        /** The Sort by / Group by setting changed. */
        void viewChanged();
    }
}
