package ui.directory;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Objects;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;

/**
 * Builds the context menu displayed for directory-tree files and folders.
 *
 * <p>
 * Moved from {@code ui.explorer.project.ProjectTreeContextMenu} unchanged. It
 * never touched the {@code TreeView} type, only paths and callbacks, so the
 * move to a tree table cost it nothing.
 * </p>
 */
public final class DirectoryTreeContextMenu {

    private DirectoryTreeContextMenu() {
    }

    public static ContextMenu create(Path path, Actions actions) {
        if (path == null || actions == null) {
            return null;
        }

        MenuItem cut = item("Cut", () -> actions.cut.accept(path));
        MenuItem copy = item("Copy", () -> actions.copy.accept(path));
        MenuItem paste = item("Paste", () -> actions.paste.accept(path));
        MenuItem delete = item("Delete", () -> actions.delete.accept(path));
        MenuItem rename = item("Rename", () -> actions.rename.accept(path));
        MenuItem undo = item("Undo", actions.undo);
        MenuItem redo = item("Redo", actions.redo);

        paste.setDisable(!actions.canPaste.getAsBoolean()
                || (!Files.isDirectory(path) && path.getParent() == null));
        delete.setDisable(!Files.exists(path) || !actions.canDelete.getAsBoolean());
        rename.setDisable(!Files.exists(path) || !actions.canRename.getAsBoolean());
        undo.setDisable(!actions.canUndo.getAsBoolean());
        redo.setDisable(!actions.canRedo.getAsBoolean());

        ContextMenu menu = new ContextMenu();
        menu.getItems().addAll(
                cut,
                copy,
                paste,
                new SeparatorMenuItem(),
                delete,
                rename,
                new SeparatorMenuItem(),
                undo,
                redo);
        return menu;
    }

    private static MenuItem item(String label, Runnable action) {
        MenuItem item = new MenuItem(label);
        item.setOnAction(event -> action.run());
        return item;
    }

    /** Callbacks and current availability rules supplied by the file-operation layer. */
    public static final class Actions {

        private final Consumer<Path> cut;
        private final Consumer<Path> copy;
        private final Consumer<Path> paste;
        private final Consumer<Path> delete;
        private final Consumer<Path> rename;
        private final Runnable undo;
        private final Runnable redo;
        private final BooleanSupplier canPaste;
        private final BooleanSupplier canDelete;
        private final BooleanSupplier canRename;
        private final BooleanSupplier canUndo;
        private final BooleanSupplier canRedo;

        public Actions(
                Consumer<Path> cut,
                Consumer<Path> copy,
                Consumer<Path> paste,
                Consumer<Path> delete,
                Consumer<Path> rename,
                Runnable undo,
                Runnable redo,
                BooleanSupplier canPaste,
                BooleanSupplier canDelete,
                BooleanSupplier canRename,
                BooleanSupplier canUndo,
                BooleanSupplier canRedo) {
            this.cut = Objects.requireNonNull(cut);
            this.copy = Objects.requireNonNull(copy);
            this.paste = Objects.requireNonNull(paste);
            this.delete = Objects.requireNonNull(delete);
            this.rename = Objects.requireNonNull(rename);
            this.undo = Objects.requireNonNull(undo);
            this.redo = Objects.requireNonNull(redo);
            this.canPaste = Objects.requireNonNull(canPaste);
            this.canDelete = Objects.requireNonNull(canDelete);
            this.canRename = Objects.requireNonNull(canRename);
            this.canUndo = Objects.requireNonNull(canUndo);
            this.canRedo = Objects.requireNonNull(canRedo);
        }
    }
}
