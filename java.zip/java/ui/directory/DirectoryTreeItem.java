package ui.directory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;
import javafx.collections.ObservableList;
import javafx.scene.control.TreeItem;

/**
 * A tree node that reads its folder the first time it is opened.
 *
 * <h3>Why this replaced the recursive build</h3>
 * <p>
 * {@code ProjectManager.buildTree} walked the entire subtree before the tree
 * was shown. That was survivable while a node cost one {@code TreeItem}, but
 * the Info column turns every node into a potential file read, and a
 * double-click that re-roots the tree now happens often enough that the cost is
 * paid again and again. Opening a folder with a deep {@code node_modules} or a
 * build output directory inside it would freeze the window.
 * </p>
 * <p>
 * A node now lists its folder only when it is first expanded, which is also the
 * first moment its children can be seen. Everything the user actually looks at
 * is built; nothing else is.
 * </p>
 *
 * <h3>Renaming in place</h3>
 * <p>
 * {@link #renameTo(Path)} changes a node's path without rebuilding the tree.
 * A renamed folder rewrites the paths of every child it has already loaded, so
 * the folders open underneath it stay open; the parent then re-sorts, so the
 * node moves to its new alphabetical place. The previous rename refreshed the
 * whole tree, which collapsed everything the user had opened.
 * </p>
 *
 * <h3>Sorting</h3>
 * <p>
 * Folders first, then files, each alphabetically and case-insensitively -- the
 * order every file manager uses. The old build inherited whatever order the
 * filesystem returned, which on Windows is roughly alphabetical and on a
 * network share is not.
 * </p>
 */
public final class DirectoryTreeItem extends TreeItem<Path> {

    private static final Comparator<Path> ORDER = Comparator
            .comparing((Path path) -> !Files.isDirectory(path))
            .thenComparing(path -> {
                Path name = path.getFileName();
                return (name == null ? path.toString() : name.toString()).toLowerCase(Locale.ROOT);
            });

    private boolean loaded;
    private Boolean leaf;

    /**
     * @param path the file or folder this node stands for
     */
    public DirectoryTreeItem(Path path) {
        super(path);

        // Reading the folder on expansion, rather than on construction, is the
        // whole point of the class.
        expandedProperty().addListener((observable, was, isNow) -> {
            if (isNow && !loaded) {
                loadChildren();
            }
        });
    }

    @Override
    public ObservableList<TreeItem<Path>> getChildren() {
        // The root is expanded before anyone listens, so a first call for an
        // already-expanded node has to load too.
        if (!loaded && isExpanded()) {
            loadChildren();
        }
        return super.getChildren();
    }

    @Override
    public boolean isLeaf() {
        if (leaf == null) {
            Path value = getValue();
            leaf = value == null || !Files.isDirectory(value);
        }
        return leaf;
    }

    /**
     * Forgets what was read, so the next expansion lists the folder again.
     * Used by the refresh path after files change on disk.
     */
    public void invalidate() {
        loaded = false;
        leaf = null;
        super.getChildren().clear();
    }

    /**
     * Gives this node a new path after a rename on disk, keeping its expanded
     * state and that of everything under it, and moves it to its sorted place
     * among its siblings.
     *
     * @param newPath the path the item now has
     */
    public void renameTo(Path newPath) {
        Path old = getValue();
        setValue(newPath);
        if (old == null || newPath == null || old.equals(newPath)) {
            return;
        }
        rebaseChildren(old, newPath);
        TreeItem<Path> parent = getParent();
        if (parent instanceof DirectoryTreeItem folder) {
            folder.resort();
        }
    }

    /** Rewrites the paths of every loaded descendant from one folder to another. */
    private void rebaseChildren(Path oldRoot, Path newRoot) {
        for (TreeItem<Path> child : super.getChildren()) {
            Path value = child.getValue();
            if (value != null && value.startsWith(oldRoot)) {
                child.setValue(newRoot.resolve(oldRoot.relativize(value)));
            }
            if (child instanceof DirectoryTreeItem folder) {
                folder.rebaseChildren(oldRoot, newRoot);
            }
        }
    }

    /** Puts the loaded children back in folders-first, alphabetical order. */
    private void resort() {
        ObservableList<TreeItem<Path>> current = super.getChildren();
        List<TreeItem<Path>> sorted = new ArrayList<>(current);
        sorted.sort((a, b) -> ORDER.compare(a.getValue(), b.getValue()));
        if (!sorted.equals(current)) {
            current.setAll(sorted);
        }
    }

    /**
     * Builds a node and, if it is a folder, opens it.
     *
     * @param path the folder to root a tree at
     * @return the expanded root node
     */
    public static DirectoryTreeItem rootFor(Path path) {
        DirectoryTreeItem root = new DirectoryTreeItem(path);
        root.setExpanded(true);
        return root;
    }

    private void loadChildren() {
        loaded = true;

        Path folder = getValue();
        if (folder == null || !Files.isDirectory(folder)) {
            return;
        }

        List<Path> entries = new ArrayList<>();
        try (Stream<Path> stream = Files.list(folder)) {
            stream.forEach(entries::add);
        } catch (IOException | RuntimeException e) {
            // An unreadable folder shows as an empty one rather than failing
            // the whole load, which is what the old build did too.
            return;
        }

        entries.sort(ORDER);

        List<TreeItem<Path>> children = new ArrayList<>(entries.size());
        for (Path entry : entries) {
            children.add(new DirectoryTreeItem(entry));
        }
        super.getChildren().setAll(children);
    }
}
