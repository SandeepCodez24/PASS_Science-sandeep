package ui.directory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;
import javafx.collections.ObservableList;
import javafx.scene.control.TreeItem;

/**
 * A tree node that reads its folder the first time it is opened.
 *
 * <h3>Lazy loading</h3>
 * <p>
 * A node lists its folder only when it is first expanded, which is also the
 * first moment its children can be seen. Everything the user actually looks at
 * is built; nothing else is. (This replaced a recursive build that walked the
 * whole subtree up front and froze on a deep {@code node_modules}.)
 * </p>
 *
 * <h3>Entries and children</h3>
 * <p>
 * A folder keeps two lists. {@link #entries} is the flat list of what is on
 * disk, one {@code DirectoryTreeItem} per file or subfolder. The tree's
 * children are built from it by {@link #arrange()}: the entries in the order
 * {@link DirectoryViewSettings} asks for, and -- when <b>Group by</b> is on --
 * wrapped in {@link DirectoryGroupItem} title rows. Sorting and grouping
 * therefore never read the disk again, and never replace an entry, so a
 * subfolder the user opened stays open through any re-sort or regroup.
 * </p>
 *
 * <h3>Refresh</h3>
 * <p>
 * {@link #reload()} re-reads a loaded folder and reconciles: an entry still on
 * disk keeps its node (and so its expanded state), a new one gets a node, a
 * gone one is dropped. Expanded subfolders reload in turn; collapsed ones
 * that were loaded before just forget, and re-read when next opened.
 * </p>
 *
 * <h3>Renaming in place</h3>
 * <p>
 * {@link #renameTo(Path)} changes a node's path without rebuilding the tree.
 * A renamed folder rewrites the paths of every child it has already loaded,
 * and the parent folder re-arranges, so the node moves to its new place (and,
 * when grouped by name, to its new group).
 * </p>
 */
public final class DirectoryTreeItem extends TreeItem<Path> {

    private boolean loaded;
    private Boolean leaf;
    private BasicFileAttributes attributes;
    private boolean attributesRead;

    /** What is on disk in this folder, unordered and ungrouped. */
    private final List<DirectoryTreeItem> entries = new ArrayList<>();

    /** Group rows currently shown, by key, so they are reused across arranges. */
    private final Map<String, DirectoryGroupItem> groups = new HashMap<>();

    /**
     * @param path the file or folder this node stands for
     */
    public DirectoryTreeItem(Path path) {
        super(path);
        expandedProperty().addListener((observable, was, isNow) -> {
            if (isNow && !loaded) {
                loadChildren();
            }
        });
    }

    @Override
    public ObservableList<TreeItem<Path>> getChildren() {
        // The root is expanded before anyone listens, so a first call for an
        // already-expanded node has to load too.
        if (!loaded && isExpanded()) {
            loadChildren();
        }
        return super.getChildren();
    }

    @Override
    public boolean isLeaf() {
        if (leaf == null) {
            Path value = getValue();
            leaf = value == null || !Files.isDirectory(value);
        }
        return leaf;
    }

    /** @return true if this node is a folder */
    public boolean isFolder() {
        return !isLeaf();
    }

    /** @return true once the folder has been read */
    public boolean isLoaded() {
        return loaded;
    }

    /**
     * Size and dates, read once and cached until the next refresh.
     *
     * @return the attributes, or null if the item cannot be read
     */
    public BasicFileAttributes attributes() {
        if (!attributesRead) {
            attributesRead = true;
            Path value = getValue();
            try {
                attributes = value == null ? null : Files.readAttributes(value, BasicFileAttributes.class);
            } catch (IOException | RuntimeException ex) {
                attributes = null;
            }
        }
        return attributes;
    }

    /** @return the entries on disk, in no particular order (read-only view) */
    public List<DirectoryTreeItem> entries() {
        return List.copyOf(entries);
    }

    /**
     * Forgets what was read, so the next expansion lists the folder again.
     */
    public void invalidate() {
        loaded = false;
        leaf = null;
        forgetAttributes();
        entries.clear();
        groups.clear();
        super.getChildren().clear();
    }

    private void forgetAttributes() {
        attributes = null;
        attributesRead = false;
    }

    // =====================================================================
    // Reading
    // =====================================================================

    private void loadChildren() {
        loaded = true;
        entries.clear();
        for (Path path : list(getValue())) {
            entries.add(new DirectoryTreeItem(path));
        }
        arrange();
    }

    /**
     * Re-reads this folder from disk, keeping every node that still exists
     * (and with it, its expanded state), then re-arranges. Recurses into
     * expanded subfolders.
     */
    public void reload() {
        leaf = null;
        forgetAttributes();
        if (!loaded) {
            return;
        }
        Map<Path, DirectoryTreeItem> existing = new LinkedHashMap<>();
        for (DirectoryTreeItem entry : entries) {
            existing.put(entry.getValue(), entry);
        }

        List<DirectoryTreeItem> fresh = new ArrayList<>();
        for (Path path : list(getValue())) {
            DirectoryTreeItem kept = existing.get(path);
            if (kept != null && kept.isFolder() == Files.isDirectory(path)) {
                kept.leaf = null;
                kept.forgetAttributes();
                fresh.add(kept);
            } else {
                fresh.add(new DirectoryTreeItem(path));
            }
        }
        entries.clear();
        entries.addAll(fresh);
        arrange();

        for (DirectoryTreeItem entry : entries) {
            if (!entry.loaded) {
                continue;
            }
            if (entry.isExpanded()) {
                entry.reload();
            } else {
                entry.invalidate();
            }
        }
    }

    private static List<Path> list(Path folder) {
        List<Path> result = new ArrayList<>();
        if (folder == null || !Files.isDirectory(folder)) {
            return result;
        }
        try (Stream<Path> stream = Files.list(folder)) {
            stream.forEach(result::add);
        } catch (IOException | RuntimeException e) {
            // An unreadable folder shows as an empty one rather than failing
            // the whole load.
        }
        return result;
    }

    // =====================================================================
    // Ordering and grouping
    // =====================================================================

    /**
     * Rebuilds the visible children from {@link #entries} under the current
     * {@link DirectoryViewSettings}. Reads nothing from disk except, for a
     * date or size key, the attributes each entry caches.
     */
    public void arrange() {
        List<DirectoryTreeItem> sorted = new ArrayList<>(entries);
        sorted.sort(DirectoryViewSettings.comparator());

        ObservableList<TreeItem<Path>> children = super.getChildren();

        if (!DirectoryViewSettings.isGrouped()) {
            groups.values().forEach(group -> group.getChildren().clear());
            groups.clear();
            if (!children.equals(sorted)) {
                children.clear();
                children.setAll(sorted);
            }
            return;
        }

        DirectoryViewSettings.GroupKey key = DirectoryViewSettings.groupKey();
        Map<String, DirectoryGrouping.Bucket> buckets = new HashMap<>();
        Map<String, List<TreeItem<Path>>> members = new LinkedHashMap<>();
        for (DirectoryTreeItem entry : sorted) {
            DirectoryGrouping.Bucket bucket = DirectoryGrouping.bucketOf(entry, key);
            buckets.putIfAbsent(bucket.key(), bucket);
            members.computeIfAbsent(bucket.key(), k -> new ArrayList<>()).add(entry);
        }

        Comparator<DirectoryGrouping.Bucket> order = Comparator
                .comparingInt(DirectoryGrouping.Bucket::rank)
                .thenComparing(DirectoryGrouping.Bucket::label, String.CASE_INSENSITIVE_ORDER);
        if (!DirectoryViewSettings.groupAscending()) {
            order = order.reversed();
        }
        List<DirectoryGrouping.Bucket> orderedBuckets = new ArrayList<>(buckets.values());
        orderedBuckets.sort(order);

        // Detach everything first so no node is ever in two child lists.
        children.clear();
        groups.values().forEach(group -> group.getChildren().clear());

        Map<String, DirectoryGroupItem> kept = new HashMap<>();
        List<TreeItem<Path>> groupRows = new ArrayList<>();
        for (DirectoryGrouping.Bucket bucket : orderedBuckets) {
            DirectoryGroupItem group = groups.get(bucket.key());
            if (group == null) {
                group = new DirectoryGroupItem(bucket.key(), bucket.label());
            } else {
                group.setTitle(bucket.label());
            }
            group.getChildren().setAll(members.get(bucket.key()));
            kept.put(bucket.key(), group);
            groupRows.add(group);
        }
        groups.clear();
        groups.putAll(kept);
        children.setAll(groupRows);
    }

    /**
     * Re-arranges this folder and every loaded folder below it. Called when
     * the Sort by or Group by setting changes.
     */
    public void arrangeAll() {
        if (!loaded) {
            return;
        }
        arrange();
        for (DirectoryTreeItem entry : entries) {
            entry.arrangeAll();
        }
    }

    // =====================================================================
    // Rename
    // =====================================================================

    /**
     * Gives this node a new path after a rename on disk, keeping its expanded
     * state and that of everything under it, and moves it to its place among
     * its siblings (and, if grouped, into its new group).
     *
     * @param newPath the path the item now has
     */
    public void renameTo(Path newPath) {
        Path old = getValue();
        setValue(newPath);
        forgetAttributes();
        if (old == null || newPath == null || old.equals(newPath)) {
            return;
        }
        rebaseChildren(old, newPath);
        DirectoryTreeItem folder = parentFolder(this);
        if (folder != null) {
            folder.arrange();
        }
    }

    /** Rewrites the paths of every loaded descendant from one folder to another. */
    private void rebaseChildren(Path oldRoot, Path newRoot) {
        for (DirectoryTreeItem child : entries) {
            Path value = child.getValue();
            if (value != null && value.startsWith(oldRoot)) {
                child.setValue(newRoot.resolve(oldRoot.relativize(value)));
            }
            child.rebaseChildren(oldRoot, newRoot);
        }
    }

    /**
     * The folder node an item sits in, skipping any group row between them.
     *
     * @param item a tree item
     * @return its folder node, or null for the root
     */
    public static DirectoryTreeItem parentFolder(TreeItem<Path> item) {
        TreeItem<Path> parent = item == null ? null : item.getParent();
        while (parent != null && !(parent instanceof DirectoryTreeItem)) {
            parent = parent.getParent();
        }
        return (DirectoryTreeItem) parent;
    }

    // =====================================================================
    // Construction
    // =====================================================================

    /**
     * Builds a node and, if it is a folder, opens it.
     *
     * @param path the folder to root a tree at
     * @return the expanded root node
     */
    public static DirectoryTreeItem rootFor(Path path) {
        DirectoryTreeItem root = new DirectoryTreeItem(path);
        root.setExpanded(true);
        return root;
    }
}
