package ui.directory;

import java.nio.file.Path;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.control.TreeTableCell;
import javafx.scene.control.Tooltip;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Polyline;
import javafx.scene.shape.StrokeLineCap;
import ui.design.Dim;
import ui.directory.repo.RepoStatus;
import ui.directory.repo.RepoStatusRegistry;

/**
 * The Repo column: one small mark saying how a file stands against the
 * repository it was cloned from.
 *
 * <pre>
 *   green dot + tick    unchanged
 *   green dot           new file, not in the repository
 *   yellow dot          in the repository, changed locally
 *   red dot + cross     deleted locally, still in the repository
 *   (nothing)           not a working copy, or no answer yet
 * </pre>
 *
 * <h3>Inactive, not absent</h3>
 * <p>
 * Every mark above is implemented and reachable now. What is missing is only
 * the thing that decides which one a file gets: with no provider installed
 * {@link RepoStatusRegistry} reports {@link RepoStatus#UNKNOWN} for everything
 * and the column renders empty. Installing a real provider lights the whole
 * column up without this class changing.
 * </p>
 *
 * <h3>Drawn, not loaded</h3>
 * <p>
 * The marks are shapes rather than PNGs. Four of them, at one size, described
 * entirely by a radius and two strokes -- and being vector, they stay sharp at
 * any {@link ui.design.UIScale} and take their colours from the theme instead
 * of needing a light and a dark copy of each.
 * </p>
 */
public final class DirectoryRepoCell extends TreeTableCell<Path, Path> {

    private static final Color GREEN = Color.web("#2E7D32");
    private static final Color YELLOW = Color.web("#C8A200");
    private static final Color RED = Color.web("#C62828");
    private static final Color MARK = Color.web("#FFFFFF");

    public DirectoryRepoCell() {
        setAlignment(Pos.CENTER);
        getStyleClass().add("directory-repo-cell");
    }

    @Override
    protected void updateItem(Path item, boolean empty) {
        super.updateItem(item, empty);

        setText(null);

        if (empty || item == null) {
            setGraphic(null);
            setTooltip(null);
            return;
        }

        RepoStatus status = RepoStatusRegistry.statusOf(item);
        if (status.isBlank()) {
            setGraphic(null);
            setTooltip(null);
            return;
        }

        setGraphic(glyph(status));
        String described = RepoStatusRegistry.describe(item);
        setTooltip(described == null ? null : new Tooltip(described));
    }

    // =====================================================================
    // Glyphs
    // =====================================================================

    private static Group glyph(RepoStatus status) {
        double radius = Dim.Directory.REPO_DOT_SIZE / 2.0;
        Circle dot = new Circle(radius, colourOf(status));
        Group group = new Group(dot);

        switch (status) {
            case UNCHANGED -> group.getChildren().add(tick(radius));
            case DELETED -> group.getChildren().addAll(cross(radius));
            default -> {
                // ADDED and MODIFIED are the bare dot.
            }
        }
        return group;
    }

    private static Color colourOf(RepoStatus status) {
        return switch (status) {
            case UNCHANGED, ADDED -> GREEN;
            case MODIFIED -> YELLOW;
            case DELETED -> RED;
            default -> Color.TRANSPARENT;
        };
    }

    private static Polyline tick(double radius) {
        Polyline tick = new Polyline(
                -radius * 0.45, 0.0,
                -radius * 0.10, radius * 0.40,
                radius * 0.50, -radius * 0.40);
        tick.setStroke(MARK);
        tick.setStrokeWidth(Dim.Directory.REPO_MARK_STROKE);
        tick.setStrokeLineCap(StrokeLineCap.ROUND);
        return tick;
    }

    private static Line[] cross(double radius) {
        double arm = radius * 0.42;
        Line first = new Line(-arm, -arm, arm, arm);
        Line second = new Line(-arm, arm, arm, -arm);
        for (Line line : new Line[]{first, second}) {
            line.setStroke(MARK);
            line.setStrokeWidth(Dim.Directory.REPO_MARK_STROKE);
            line.setStrokeLineCap(StrokeLineCap.ROUND);
        }
        return new Line[]{first, second};
    }
}
