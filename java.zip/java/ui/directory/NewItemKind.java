package ui.directory;

import java.util.function.Supplier;
import language.language_ui.handler.NcBlockTemplates;

/**
 * The five entries of the explorer's <b>New</b> submenu, in menu order.
 *
 * <p>
 * The Neural Code skeletons are the same ones the Home ribbon's New menu and
 * the editor's autofill use ({@link NcBlockTemplates}), so a function or class
 * created from the explorer is identical to one created anywhere else.
 * </p>
 */
public enum NewItemKind {

    FOLDER("New Folder", DirectoryMenuIcons.EXPLORER, "new_folder", "New Folder", "", () -> ""),
    SCRIPT("New Script", DirectoryMenuIcons.HOME_FILES, "new_script", "Untitled", ".nc", () -> ""),
    FUNCTION("New Function", DirectoryMenuIcons.HOME_FILES, "new_function", "Untitled_Function", ".nc",
            NcBlockTemplates::functionFileTemplate),
    CLASS("New Class", DirectoryMenuIcons.HOME_FILES, "new_class", "Untitled_Class", ".nc",
            NcBlockTemplates::classFileTemplate),
    TEXT("New Text", DirectoryMenuIcons.HOME_FILES, "new_txt", "Untitled", ".txt", () -> "");

    private final String label;
    private final String iconFolder;
    private final String iconName;
    private final String baseName;
    private final String extension;
    private final Supplier<String> template;

    NewItemKind(String label, String iconFolder, String iconName, String baseName, String extension,
            Supplier<String> template) {
        this.label = label;
        this.iconFolder = iconFolder;
        this.iconName = iconName;
        this.baseName = baseName;
        this.extension = extension;
        this.template = template;
    }

    /** @return the menu label */
    public String label() {
        return label;
    }

    String iconFolder() {
        return iconFolder;
    }

    String iconName() {
        return iconName;
    }

    /** @return the first name tried, before numbering ("Untitled") */
    public String baseName() {
        return baseName;
    }

    /** @return the extension with its dot, or empty for a folder */
    public String extension() {
        return extension;
    }

    /** @return true for New Folder */
    public boolean isFolder() {
        return this == FOLDER;
    }

    /** @return the initial file content */
    public String template() {
        String text = template.get();
        return text == null ? "" : text;
    }
}
