package ui.directory.repo;

import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * The one place the Repo column looks, and the one place a backend is plugged
 * in.
 *
 * <p>
 * Today {@link #NONE} is installed: it tracks nothing, so every file reports
 * {@link RepoStatus#UNKNOWN} and the column draws blank, which is the inactive
 * state the brief asked for. When the backend exists the whole of the change is
 * one line at startup:
 * </p>
 *
 * <pre>
 *   RepoStatusRegistry.install(new GitRepoStatusProvider());
 * </pre>
 *
 * <p>
 * Nothing in {@code ui.directory} needs editing for that, because nothing in
 * {@code ui.directory} names a provider.
 * </p>
 */
public final class RepoStatusRegistry {

    /** The do-nothing provider. Tracks no folder and knows no file. */
    public static final RepoStatusProvider NONE = new RepoStatusProvider() {

        @Override
        public boolean tracks(Path root) {
            return false;
        }

        @Override
        public RepoStatus statusOf(Path path) {
            return RepoStatus.UNKNOWN;
        }
    };

    private static final List<Runnable> LISTENERS = new CopyOnWriteArrayList<>();

    private static volatile RepoStatusProvider provider = NONE;
    private static volatile boolean tracking;

    private RepoStatusRegistry() {
    }

    /**
     * Installs the provider the column will consult.
     *
     * @param newProvider the provider, or null to go back to {@link #NONE}
     */
    public static void install(RepoStatusProvider newProvider) {
        provider = (newProvider != null) ? newProvider : NONE;
        refreshed();
    }

    /**
     * @return the installed provider, never null
     */
    public static RepoStatusProvider provider() {
        return provider;
    }

    /**
     * Told by the tree when its root moves. Asks the provider once whether the
     * new root is a working copy and remembers the answer, so the per-row calls
     * that follow never have to.
     *
     * @param root the new tree root; may be null
     */
    public static void rootChanged(Path root) {
        RepoStatusProvider current = provider;
        boolean nowTracking;
        try {
            nowTracking = current.tracks(root);
        } catch (RuntimeException e) {
            nowTracking = false;
        }
        tracking = nowTracking;
        try {
            current.rootChanged(root);
        } catch (RuntimeException ignored) {
            // A provider that cannot prepare simply has no answers.
        }
        refreshed();
    }

    /**
     * @return true if the current root is a working copy and the column should
     *         draw marks at all
     */
    public static boolean isTracking() {
        return tracking;
    }

    /**
     * The status of one file, with the "not a working copy" case already
     * handled so callers do not repeat it.
     *
     * @param path the file; may be null
     * @return the status, never null
     */
    public static RepoStatus statusOf(Path path) {
        if (!tracking || path == null) {
            return RepoStatus.UNKNOWN;
        }
        try {
            RepoStatus status = provider.statusOf(path);
            return (status != null) ? status : RepoStatus.UNKNOWN;
        } catch (RuntimeException e) {
            return RepoStatus.UNKNOWN;
        }
    }

    /**
     * The tooltip text for one file.
     *
     * @param path the file
     * @return the description, or null if there is nothing to say
     */
    public static String describe(Path path) {
        if (!tracking || path == null) {
            return null;
        }
        try {
            String described = provider.describe(path);
            if (described != null) {
                return described;
            }
        } catch (RuntimeException ignored) {
            return null;
        }
        return switch (statusOf(path)) {
            case UNCHANGED -> "Unchanged from the repository";
            case ADDED -> "New file, not in the repository";
            case MODIFIED -> "Changed from the repository copy";
            case DELETED -> "Deleted locally, still in the repository";
            default -> null;
        };
    }

    /**
     * Registers a callback fired whenever the answers may have changed, so the
     * tree can repaint. A provider that fetches in the background calls
     * {@link #refreshed()} to trigger these.
     *
     * @param listener the callback; ignored if null
     */
    public static void addListener(Runnable listener) {
        if (listener != null) {
            LISTENERS.add(listener);
        }
    }

    /** Announces that statuses may have changed. Safe from any thread. */
    public static void refreshed() {
        for (Runnable listener : LISTENERS) {
            try {
                listener.run();
            } catch (RuntimeException e) {
                e.printStackTrace();
            }
        }
    }
}
