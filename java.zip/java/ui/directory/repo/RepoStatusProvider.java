package ui.directory.repo;

import java.nio.file.Path;

/**
 * The seam between the Repo column and whatever tracks the files.
 *
 * <h3>Why the interface is this small</h3>
 * <p>
 * The column needs two answers and no others: "is this folder under your
 * control?" and "what is the state of this file?". Everything a real backend
 * does -- authenticating, fetching, diffing, caching, watching for remote
 * changes -- happens behind those two methods, so Git, Azure Repos, a Jira-
 * linked repository or an internal sync service can each be dropped in without
 * the column changing a line. That was the point of building the foundation
 * before the backend exists.
 * </p>
 *
 * <h3>The contract implementations must keep</h3>
 * <ul>
 * <li>{@link #statusOf} is called once per visible row on every redraw and
 * <b>runs on the JavaFX thread</b>. It must return from memory. A provider that
 * needs to talk to a server does that on its own thread, stores the answer, and
 * calls {@link RepoStatusRegistry#refreshed()} when it lands.</li>
 * <li>Neither method may throw. An unreachable server is {@link
 * RepoStatus#UNKNOWN}, not an exception -- the directory tree must still
 * render.</li>
 * <li>{@link #tracks} is asked once per root change, so it may block briefly
 * (walking up for a {@code .git} directory, reading a config file).</li>
 * </ul>
 */
public interface RepoStatusProvider {

    /**
     * Whether this provider has anything to say about a folder tree.
     *
     * <p>
     * When this returns false for the current root the column is left entirely
     * blank, as specified for a root that did not come from a repository. The
     * column stays visible, so the other two do not change width when the user
     * moves between a working copy and an ordinary folder.
     * </p>
     *
     * @param root the folder now shown as the tree root; may be null
     * @return true if files under this root can be given a status
     */
    boolean tracks(Path root);

    /**
     * The state of one file. Must not block.
     *
     * @param path the file or folder; may be null
     * @return the status, never null; {@link RepoStatus#UNKNOWN} when there is
     *         no answer yet
     */
    RepoStatus statusOf(Path path);

    /**
     * A human-readable explanation for the row's tooltip.
     *
     * @param path the file or folder
     * @return the text, or null to let the registry use the status name
     */
    default String describe(Path path) {
        return null;
    }

    /**
     * Told when the tree root moves, so a provider can discard a cache built
     * for the previous working copy and start populating the new one.
     *
     * @param root the new root; may be null when no project is open
     */
    default void rootChanged(Path root) {
        // Most providers need nothing here.
    }
}
