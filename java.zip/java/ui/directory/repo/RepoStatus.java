package ui.directory.repo;

/**
 * What the Repo column has to say about one file.
 *
 * <p>
 * Deliberately named for what the states <em>mean</em> rather than for any one
 * provider's vocabulary. Git calls an added-but-uncommitted file "staged new",
 * Azure DevOps calls it "pending add", Jira does not track files at all and
 * would be answering for whatever repository a ticket points at. All of them
 * can answer the only question the column asks: is this file the same as the
 * one in the remote, and if not, how does it differ.
 * </p>
 *
 * <p>
 * {@link #UNKNOWN} is the state everything is in today, and the one the column
 * draws as nothing at all.
 * </p>
 */
public enum RepoStatus {

    /**
     * No answer available: no provider is installed, the root is not a working
     * copy, or the provider has not finished looking. Drawn as empty.
     */
    UNKNOWN,

    /** Present in the remote and byte-identical to it. Green tick. */
    UNCHANGED,

    /** Present locally, not in the remote. Green dot. */
    ADDED,

    /** Present in both, and the local copy differs. Yellow dot. */
    MODIFIED,

    /** Present in the remote, gone locally. Red dot with a cross. */
    DELETED,

    /**
     * Deliberately outside the working copy's scope -- the equivalent of a
     * {@code .gitignore} match. Drawn as empty, like {@link #UNKNOWN}, but kept
     * separate so a provider can distinguish "I was not asked to track this"
     * from "I do not know".
     */
    IGNORED;

    /**
     * @return true if this state puts no mark in the column
     */
    public boolean isBlank() {
        return this == UNKNOWN || this == IGNORED;
    }
}
