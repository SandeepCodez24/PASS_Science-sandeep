package ui.directory;

import java.net.URL;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Screen;
import ui.design.section_dims.DirectoryMenu_dim;

/**
 * Icons for the File Explorer's right-click menus.
 *
 * <p>
 * Two sets are used, both 48x48 RGBA masters in a light and a dark variant:
 * </p>
 * <ul>
 * <li>{@code /icons/Explorer/{light,dark}/<name>.png} -- the menu's own
 * icons (cut, copy, paste, delete, rename, undo, redo, new_folder, sort_by,
 * group_by, refresh, open_in_explorer, properties);</li>
 * <li>{@code /icons/HomeFiles/{light,dark}/<name>.png} -- the Home ribbon's
 * New drop-down icons (new, new_script, new_function, new_class, new_txt),
 * reused so the explorer's New submenu and the ribbon's look the same.</li>
 * </ul>
 *
 * <p>
 * A menu is built fresh on every right-click, so the theme is read at that
 * moment ({@link DirectoryFileIconResolver#isDarkTheme()}) and no live
 * registry is needed. Each master is decoded once per theme at the menu icon
 * size times the primary screen's scale, so it is not resampled again on
 * screen.
 * </p>
 */
public final class DirectoryMenuIcons {

    /** The explorer's own set. */
    public static final String EXPLORER = "/icons/Explorer/";

    /** The Home ribbon Files set, shared with the New submenu. */
    public static final String HOME_FILES = "/icons/HomeFiles/";

    private static final Map<String, Image> CACHE = new ConcurrentHashMap<>();

    private DirectoryMenuIcons() {
    }

    /**
     * @param folder {@link #EXPLORER} or {@link #HOME_FILES}
     * @param name   base file name without theme folder or extension
     * @return a view sized for a menu row, or null if the asset is missing
     */
    public static ImageView view(String folder, String name) {
        Image image = image(folder, name);
        if (image == null) {
            return null;
        }
        ImageView view = new ImageView(image);
        view.setFitWidth(DirectoryMenu_dim.MENU_ICON_SIZE);
        view.setFitHeight(DirectoryMenu_dim.MENU_ICON_SIZE);
        view.setPreserveRatio(true);
        view.setSmooth(true);
        return view;
    }

    /** Shorthand for an icon from {@link #EXPLORER}. */
    public static ImageView explorer(String name) {
        return view(EXPLORER, name);
    }

    /** Shorthand for an icon from {@link #HOME_FILES}. */
    public static ImageView homeFiles(String name) {
        return view(HOME_FILES, name);
    }

    private static Image image(String folder, String name) {
        String theme = DirectoryFileIconResolver.isDarkTheme() ? "dark" : "light";
        String resource = folder + theme + "/" + name + ".png";
        double scale = Math.max(1.0, Screen.getPrimary().getOutputScaleX());
        int px = (int) Math.round(DirectoryMenu_dim.MENU_ICON_SIZE * scale);
        String key = resource + "@" + px;
        Image cached = CACHE.get(key);
        if (cached != null) {
            return cached;
        }
        URL url = DirectoryMenuIcons.class.getResource(resource);
        if (url == null) {
            return null;
        }
        Image image = new Image(url.toExternalForm(), px, px, true, true);
        if (image.isError()) {
            return null;
        }
        CACHE.put(key, image);
        return image;
    }
}
