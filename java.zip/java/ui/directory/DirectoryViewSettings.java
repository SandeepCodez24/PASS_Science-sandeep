package ui.directory;

import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Comparator;
import java.util.Locale;
import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;

/**
 * How the File Explorer orders and groups its rows: the state behind the
 * right-click menu's <b>Sort by</b> and <b>Group by</b> submenus.
 *
 * <p>
 * One setting applies to the whole tree, as in Windows Explorer and MATLAB's
 * Current Folder, and it survives restarts the same way {@link InfoMode} does.
 * Defaults: sort by Name, Ascending; group by None.
 * </p>
 *
 * <h3>Folders first</h3>
 * <p>
 * Whatever the key and direction, folders stay above files. Only the order
 * inside each of the two blocks changes. That is what every IDE tree does, and
 * it keeps a folder from being lost in the middle of a long list of files
 * when the list is sorted by size or date.
 * </p>
 */
public final class DirectoryViewSettings {

    /** The four keys of the Sort by submenu, in the menu's order. */
    public enum SortKey {
        NAME("Name"),
        TYPE("Type"),
        DATE_MODIFIED("Date modified"),
        SIZE("Size");

        private final String label;

        SortKey(String label) {
            this.label = label;
        }

        public String label() {
            return label;
        }
    }

    /**
     * The keys of the Group by submenu, in the menu's order. {@link #NONE}
     * comes last, below the four keys, as "(None)" does in Windows.
     */
    public enum GroupKey {
        NAME("Name"),
        TYPE("Type"),
        DATE_MODIFIED("Date modified"),
        SIZE("Size"),
        NONE("None");

        private final String label;

        GroupKey(String label) {
            this.label = label;
        }

        public String label() {
            return label;
        }
    }

    private static final Preferences PREFS = Preferences.userRoot().node("astra/directory");
    private static final String KEY_SORT = "sortKey";
    private static final String KEY_SORT_ASC = "sortAscending";
    private static final String KEY_GROUP = "groupKey";
    private static final String KEY_GROUP_ASC = "groupAscending";

    private static SortKey sortKey = read(KEY_SORT, SortKey.class, SortKey.NAME);
    private static boolean sortAscending = PREFS.getBoolean(KEY_SORT_ASC, true);
    private static GroupKey groupKey = read(KEY_GROUP, GroupKey.class, GroupKey.NONE);
    private static boolean groupAscending = PREFS.getBoolean(KEY_GROUP_ASC, true);

    private DirectoryViewSettings() {
    }

    // =====================================================================
    // Read
    // =====================================================================

    public static SortKey sortKey() {
        return sortKey;
    }

    public static boolean sortAscending() {
        return sortAscending;
    }

    public static GroupKey groupKey() {
        return groupKey;
    }

    public static boolean groupAscending() {
        return groupAscending;
    }

    /** @return true when rows are split into groups */
    public static boolean isGrouped() {
        return groupKey != GroupKey.NONE;
    }

    // =====================================================================
    // Write -- each setter stores at once and reports whether anything changed
    // =====================================================================

    public static boolean setSortKey(SortKey key) {
        if (key == null || key == sortKey) {
            return false;
        }
        sortKey = key;
        PREFS.put(KEY_SORT, key.name());
        flush();
        return true;
    }

    public static boolean setSortAscending(boolean ascending) {
        if (ascending == sortAscending) {
            return false;
        }
        sortAscending = ascending;
        PREFS.putBoolean(KEY_SORT_ASC, ascending);
        flush();
        return true;
    }

    public static boolean setGroupKey(GroupKey key) {
        if (key == null || key == groupKey) {
            return false;
        }
        groupKey = key;
        PREFS.put(KEY_GROUP, key.name());
        flush();
        return true;
    }

    public static boolean setGroupAscending(boolean ascending) {
        if (ascending == groupAscending) {
            return false;
        }
        groupAscending = ascending;
        PREFS.putBoolean(KEY_GROUP_ASC, ascending);
        flush();
        return true;
    }

    // =====================================================================
    // Ordering
    // =====================================================================

    /**
     * The order of the rows inside one folder (or inside one group) under the
     * current settings: folders first, then the chosen key in the chosen
     * direction, then the name ascending to break ties.
     *
     * @return a comparator over tree items
     */
    public static Comparator<DirectoryTreeItem> comparator() {
        Comparator<DirectoryTreeItem> byKey = switch (sortKey) {
            case NAME -> (a, b) -> compareNames(a.getValue(), b.getValue());
            case TYPE -> Comparator.comparing(DirectoryViewSettings::typeKey);
            case DATE_MODIFIED -> Comparator.comparingLong(DirectoryViewSettings::modifiedMillis);
            case SIZE -> Comparator.comparingLong(DirectoryViewSettings::sizeOf);
        };
        if (!sortAscending) {
            byKey = byKey.reversed();
        }
        Comparator<DirectoryTreeItem> byName = (a, b) -> compareNames(a.getValue(), b.getValue());
        return Comparator.comparing((DirectoryTreeItem item) -> !item.isFolder())
                .thenComparing(byKey)
                .thenComparing(byName);
    }

    /**
     * Natural, case-insensitive name order, as Windows Explorer uses:
     * {@code file2.nc} before {@code file10.nc}.
     */
    static int compareNames(Path a, Path b) {
        return naturalCompare(DirectoryRename.nameOf(a), DirectoryRename.nameOf(b));
    }

    static int naturalCompare(String a, String b) {
        String x = a.toLowerCase(Locale.ROOT);
        String y = b.toLowerCase(Locale.ROOT);
        int i = 0;
        int j = 0;
        while (i < x.length() && j < y.length()) {
            char cx = x.charAt(i);
            char cy = y.charAt(j);
            if (Character.isDigit(cx) && Character.isDigit(cy)) {
                int si = i;
                int sj = j;
                while (si < x.length() && x.charAt(si) == '0') {
                    si++;
                }
                while (sj < y.length() && y.charAt(sj) == '0') {
                    sj++;
                }
                int ei = si;
                int ej = sj;
                while (ei < x.length() && Character.isDigit(x.charAt(ei))) {
                    ei++;
                }
                while (ej < y.length() && Character.isDigit(y.charAt(ej))) {
                    ej++;
                }
                int lenDiff = (ei - si) - (ej - sj);
                if (lenDiff != 0) {
                    return lenDiff;
                }
                int cmp = x.substring(si, ei).compareTo(y.substring(sj, ej));
                if (cmp != 0) {
                    return cmp;
                }
                i = ei;
                j = ej;
            } else {
                if (cx != cy) {
                    return Character.compare(cx, cy);
                }
                i++;
                j++;
            }
        }
        int rest = (x.length() - i) - (y.length() - j);
        return rest != 0 ? rest : a.compareTo(b);
    }

    /** Lower-case extension without the dot; empty for folders and bare names. */
    static String typeKey(DirectoryTreeItem item) {
        if (item.isFolder()) {
            return "";
        }
        return extensionOf(item.getValue());
    }

    static String extensionOf(Path path) {
        String name = DirectoryRename.nameOf(path);
        int dot = name.lastIndexOf('.');
        return dot > 0 && dot < name.length() - 1 ? name.substring(dot + 1).toLowerCase(Locale.ROOT) : "";
    }

    static long modifiedMillis(DirectoryTreeItem item) {
        BasicFileAttributes attrs = item.attributes();
        return attrs == null ? 0L : attrs.lastModifiedTime().toMillis();
    }

    static long sizeOf(DirectoryTreeItem item) {
        if (item.isFolder()) {
            return 0L;
        }
        BasicFileAttributes attrs = item.attributes();
        return attrs == null ? 0L : attrs.size();
    }

    // =====================================================================
    // Storage
    // =====================================================================

    private static <E extends Enum<E>> E read(String key, Class<E> type, E fallback) {
        String raw = PREFS.get(key, fallback.name());
        try {
            return Enum.valueOf(type, raw);
        } catch (IllegalArgumentException ex) {
            return fallback;
        }
    }

    private static void flush() {
        try {
            PREFS.flush();
        } catch (BackingStoreException ignored) {
            // The choice still holds for this session.
        }
    }
}
