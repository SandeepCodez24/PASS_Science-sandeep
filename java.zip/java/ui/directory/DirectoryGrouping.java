package ui.directory;

import java.nio.file.attribute.BasicFileAttributes;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.TemporalAdjusters;
import java.time.temporal.WeekFields;
import java.util.Locale;

/**
 * Decides which group a row belongs to under the current
 * {@link DirectoryViewSettings.GroupKey}.
 *
 * <h3>The groups</h3>
 * <dl>
 * <dt>Name</dt>
 * <dd>The alphabet is split into four equal-as-possible ranges, 26 letters as
 * 7 - 7 - 6 - 6: <b>A - G</b>, <b>H - N</b>, <b>O - T</b>, <b>U - Z</b>. Two
 * extra groups catch what no letter range can: <b>0 - 9</b> for names that
 * start with a digit, and <b>Other</b> for anything else (a symbol, an
 * underscore, a Greek or Tamil letter).</dd>
 * <dt>Type</dt>
 * <dd><b>Folders</b>, then one group per extension, e.g. <b>NC file</b>,
 * <b>TXT file</b>; names with no extension go to <b>File</b>.</dd>
 * <dt>Date modified</dt>
 * <dd>Windows' own ranges: Today, Yesterday, Earlier this week, Last week,
 * Earlier this month, Last month, Earlier this year, A long time ago.
 * Ascending runs from oldest to newest, like the Date sort.</dd>
 * <dt>Size</dt>
 * <dd>Windows' own ranges: Folders, Empty (0 KB), Tiny (under 16 KB), Small
 * (under 1 MB), Medium (under 128 MB), Large (under 1 GB), Huge (under 4 GB),
 * Gigantic.</dd>
 * </dl>
 */
final class DirectoryGrouping {

    /**
     * One group.
     *
     * @param rank  order among the groups when ascending
     * @param key   identity, stable across refreshes (so a collapsed group
     *              stays collapsed)
     * @param label the title shown in the tree
     */
    record Bucket(int rank, String key, String label) {
    }

    private static final long KB = 1024L;
    private static final long MB = KB * 1024L;
    private static final long GB = MB * 1024L;

    private DirectoryGrouping() {
    }

    static Bucket bucketOf(DirectoryTreeItem item, DirectoryViewSettings.GroupKey key) {
        return switch (key) {
            case NAME -> byName(item);
            case TYPE -> byType(item);
            case DATE_MODIFIED -> byDate(item);
            case SIZE -> bySize(item);
            case NONE -> new Bucket(0, "none", "");
        };
    }

    // ---------------------------------------------------------------------
    // Name: A-G, H-N, O-T, U-Z (7-7-6-6), plus 0-9 and Other
    // ---------------------------------------------------------------------

    private static Bucket byName(DirectoryTreeItem item) {
        String name = DirectoryRename.nameOf(item.getValue());
        char first = name.isEmpty() ? ' ' : Character.toUpperCase(name.charAt(0));
        if (first >= '0' && first <= '9') {
            return new Bucket(0, "name:digit", "0 \u2013 9");
        }
        if (first >= 'A' && first <= 'G') {
            return new Bucket(1, "name:ag", "A \u2013 G");
        }
        if (first >= 'H' && first <= 'N') {
            return new Bucket(2, "name:hn", "H \u2013 N");
        }
        if (first >= 'O' && first <= 'T') {
            return new Bucket(3, "name:ot", "O \u2013 T");
        }
        if (first >= 'U' && first <= 'Z') {
            return new Bucket(4, "name:uz", "U \u2013 Z");
        }
        return new Bucket(5, "name:other", "Other");
    }

    // ---------------------------------------------------------------------
    // Type
    // ---------------------------------------------------------------------

    private static Bucket byType(DirectoryTreeItem item) {
        if (item.isFolder()) {
            return new Bucket(0, "type:folder", "Folders");
        }
        String ext = DirectoryViewSettings.extensionOf(item.getValue());
        if (ext.isEmpty()) {
            return new Bucket(2, "type:", "File");
        }
        // Rank 1 for every extension; ties are broken by label below, so the
        // extension groups come out alphabetically.
        return new Bucket(1, "type:" + ext, ext.toUpperCase(Locale.ROOT) + " file");
    }

    // ---------------------------------------------------------------------
    // Date modified (rank 0 = oldest)
    // ---------------------------------------------------------------------

    private static Bucket byDate(DirectoryTreeItem item) {
        BasicFileAttributes attrs = item.attributes();
        if (attrs == null) {
            return new Bucket(0, "date:old", "A long time ago");
        }
        ZoneId zone = ZoneId.systemDefault();
        LocalDate day = LocalDate.ofInstant(Instant.ofEpochMilli(attrs.lastModifiedTime().toMillis()), zone);
        LocalDate today = LocalDate.now(zone);

        WeekFields week = WeekFields.of(Locale.getDefault());
        LocalDate weekStart = today.with(TemporalAdjusters.previousOrSame(week.getFirstDayOfWeek()));
        LocalDate lastWeekStart = weekStart.minusWeeks(1);
        LocalDate monthStart = today.withDayOfMonth(1);
        LocalDate lastMonthStart = monthStart.minusMonths(1);
        LocalDate yearStart = today.withDayOfYear(1);

        if (!day.isBefore(today)) {
            return new Bucket(7, "date:today", "Today");
        }
        if (day.equals(today.minusDays(1))) {
            return new Bucket(6, "date:yesterday", "Yesterday");
        }
        if (!day.isBefore(weekStart)) {
            return new Bucket(5, "date:thisweek", "Earlier this week");
        }
        if (!day.isBefore(lastWeekStart)) {
            return new Bucket(4, "date:lastweek", "Last week");
        }
        if (!day.isBefore(monthStart)) {
            return new Bucket(3, "date:thismonth", "Earlier this month");
        }
        if (!day.isBefore(lastMonthStart)) {
            return new Bucket(2, "date:lastmonth", "Last month");
        }
        if (!day.isBefore(yearStart)) {
            return new Bucket(1, "date:thisyear", "Earlier this year");
        }
        return new Bucket(0, "date:old", "A long time ago");
    }

    // ---------------------------------------------------------------------
    // Size
    // ---------------------------------------------------------------------

    private static Bucket bySize(DirectoryTreeItem item) {
        if (item.isFolder()) {
            return new Bucket(0, "size:folder", "Folders");
        }
        long size = DirectoryViewSettings.sizeOf(item);
        if (size == 0) {
            return new Bucket(1, "size:empty", "Empty (0 KB)");
        }
        if (size < 16 * KB) {
            return new Bucket(2, "size:tiny", "Tiny (0 \u2013 16 KB)");
        }
        if (size < MB) {
            return new Bucket(3, "size:small", "Small (16 KB \u2013 1 MB)");
        }
        if (size < 128 * MB) {
            return new Bucket(4, "size:medium", "Medium (1 \u2013 128 MB)");
        }
        if (size < GB) {
            return new Bucket(5, "size:large", "Large (128 MB \u2013 1 GB)");
        }
        if (size < 4 * GB) {
            return new Bucket(6, "size:huge", "Huge (1 \u2013 4 GB)");
        }
        return new Bucket(7, "size:gigantic", "Gigantic (> 4 GB)");
    }
}
