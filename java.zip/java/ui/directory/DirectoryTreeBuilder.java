package ui.directory;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.function.Function;
import javafx.application.Platform;
import javafx.beans.InvalidationListener;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.event.EventTarget;
import javafx.geometry.Bounds;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.geometry.Side;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.OverrunStyle;
import javafx.scene.control.RadioMenuItem;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Tooltip;
import javafx.scene.control.TreeTableColumn;
import javafx.scene.control.TreeTableRow;
import javafx.scene.control.TreeTableView;
import javafx.scene.control.skin.VirtualFlow;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Polygon;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import ui.UI_Main;
import ui.design.Dim;
import ui.design.DirectoryRowMetrics;
import ui.directory.repo.RepoStatusRegistry;
import ui.editor.navigation.FolderPaths;
import ui.editor.navigation.NavigationActions;
import ui.managers.EditorManager;

/**
 * Builds the directory explorer: a three-column tree table with a header strip.
 *
 * <pre>
 *   +----------------------------------------+-------------------+----+
 *   |                                        |       Info        |    |
 *   | Name                                   |-------------------| R  |
 *   |                                        | By Number of Li v |    |
 *   +----------------------------------------+-------------------+----+
 *   | v [] NeuralCode                        |                   |    |
 *   |      [] cleaned_Runfile.nc             |                42 | o  |
 *   |      [] Examaple_indentation.nc        |                17 | o  |
 *   +----------------------------------------+-------------------+----+
 *        7.5                    :             1.75      :  0.75
 * </pre>
 *
 * <h3>Why a TreeTableView</h3>
 * <p>
 * The old explorer was a {@code TreeView}, which has one column by definition.
 * {@code TreeTableView} keeps the disclosure triangles and the indent of a tree
 * and adds a header that stays aligned over the values.
 * </p>
 *
 * <h3>Fixed columns</h3>
 * <p>
 * No column can be dragged. All three are {@code setResizable(false)}, which
 * makes JavaFX hide the invisible drag handles on their dividers altogether,
 * so there is no resize cursor and no way to start a resize.
 * </p>
 * <p>
 * This replaces a mixed arrangement that caused two bugs. Name was resizable
 * while Info and Repo were not. Dragging the Name divider set the column's
 * width directly, bypassing the ratio binding on its preferred width, so the
 * columns no longer filled the table and an empty strip opened at the right.
 * And the Info/Repo divider could not be dragged at all, because that divider
 * belongs to Info.
 * </p>
 * <p>
 * {@link ColumnFitter} now sizes the columns. It measures the width actually
 * available to them -- inside the table's border, less the vertical scrollbar
 * only while that scrollbar is showing -- and splits it by the ratio in
 * {@link ui.design.section_dims.Directory_dim}, with Name taking the rounding
 * remainder. The columns therefore always sum to exactly the viewport width,
 * so no empty strip appears whether or not the tree is long enough to scroll.
 * </p>
 *
 * <h3>The Info header</h3>
 * <p>
 * The Info column's header is two rows in the space of a slightly taller
 * strip: the caption "Info" above a dividing line, and beneath it the current
 * unit with a drop-down triangle. The mode row is the drop-down: it highlights
 * on hover, stays highlighted while the menu is open, and clicking it opens
 * or closes the unit menu.
 * </p>
 * <p>
 * The unit is written out in full ("By Number of Lines") when the column is
 * wide enough, and drops to one word ("Lines") when it is not; the tooltip
 * always carries the full name. Both rows use the smaller
 * {@code DIRECTORY_INFO_HEADER} font so the pair fits without padding.
 * </p>
 * <p>
 * The header has no text of its own, only this graphic. With no text to lay
 * out, JavaFX stretches a header's graphic to the header's full size, which is
 * what lets the two rows span the whole cell.
 * </p>
 *
 * <h3>Rows</h3>
 * <p>
 * Row text uses the breadcrumb bar's font, and every row is
 * {@link DirectoryRowMetrics#rowHeight()} tall -- the text line or the icon,
 * whichever is taller, plus a small pad -- so the list is as compact as it can
 * be without one row's text touching the next.
 * </p>
 *
 * <h3>Double-click</h3>
 * <p>
 * A double-click on a folder makes that folder the base folder -- the tree
 * re-roots there and the breadcrumb follows, because both go through
 * {@link NavigationActions#goTo}. Expansion is left entirely to the disclosure
 * triangle. The handler is an event <em>filter</em> on the table, because
 * {@code TreeTableRow} expands on double-click from inside its own skin and a
 * handler added afterwards cannot stop that.
 * </p>
 */
public final class DirectoryTreeBuilder {

    private static final String TABLE_CLASS = "directory-tree";

    // Column style classes. JavaFX copies a column's style classes onto its
    // header, which is how the generated sheet aligns each caption.
    private static final String NAME_COLUMN_CLASS = "directory-name-column";
    private static final String INFO_COLUMN_CLASS = "directory-info-column";
    private static final String REPO_COLUMN_CLASS = "directory-repo-column";

    private static final String INFO_HEADER_CLASS = "directory-info-header";
    private static final String INFO_CAPTION_CLASS = "directory-info-caption";
    private static final String INFO_MODE_CLASS = "directory-info-mode";
    private static final String INFO_MODE_LABEL_CLASS = "directory-info-mode-label";
    private static final String INFO_ARROW_CLASS = "directory-info-arrow";
    private static final String INFO_MENU_CLASS = "directory-info-menu";
    private static final String MENU_SHOWING_CLASS = "menu-showing";
    private static final String COLUMN_HEADER_CLASS = "column-header";

    private static final String NAME_CAPTION = "Name";
    private static final String INFO_CAPTION = "Info";
    private static final String REPO_CAPTION = "R";

    private static InfoMode infoMode = InfoMode.stored();

    private static TreeTableView<Path> table;
    private static ContextMenu openModeMenu;

    /** The mode row's text, kept so a change of unit can rewrite it. */
    private static Label modeLabel;
    private static Tooltip modeTooltip;

    /** Scratch node for measuring a mode name before choosing it. */
    private static final Text MEASURE = new Text();

    private DirectoryTreeBuilder() {
    }

    // =====================================================================
    // Construction
    // =====================================================================

    /**
     * Creates the tree table and installs it on the IDE controller.
     *
     * @param ide                the IDE controller
     * @param contextMenuFactory builds the right-click menu for a path
     */
    public static void initialize(UI_Main ide, Function<Path, ContextMenu> contextMenuFactory) {
        TreeTableView<Path> tree = new TreeTableView<>();
        tree.getStyleClass().add(TABLE_CLASS);
        tree.setShowRoot(true);
        tree.setPrefWidth(Dim.Explorer.PANEL_PREF_WIDTH);
        tree.setMinWidth(Dim.Explorer.PANEL_MIN_WIDTH);
        // Measured from the breadcrumb font and the icon size: the tightest
        // height at which rows cannot overlap. The generated sheet uses the
        // same value for -fx-cell-size.
        tree.setFixedCellSize(DirectoryRowMetrics.rowHeight());
        // Unconstrained: ColumnFitter alone decides the widths. A constrained
        // policy would run its own distribution on top and fight it.
        tree.setColumnResizePolicy(TreeTableView.UNCONSTRAINED_RESIZE_POLICY);
        tree.setTableMenuButtonVisible(false);
        tree.setPlaceholder(new Label(""));

        TreeTableColumn<Path, Path> name = buildNameColumn(contextMenuFactory);
        TreeTableColumn<Path, Path> info = buildInfoColumn(tree);
        TreeTableColumn<Path, Path> repo = buildRepoColumn();

        tree.getColumns().add(name);
        tree.getColumns().add(info);
        tree.getColumns().add(repo);
        tree.setTreeColumn(name);

        new ColumnFitter(tree, name, info, repo).install();
        installDoubleClick(ide, tree);

        // A provider that learns something in the background repaints the R
        // column without anyone rebuilding the tree.
        RepoStatusRegistry.addListener(() -> {
            if (table != null) {
                table.refresh();
            }
        });

        table = tree;
        ide.projectTree = tree;
    }

    // =====================================================================
    // Columns
    // =====================================================================

    /**
     * The settings every column shares: it shows the row's own path, and it
     * cannot be sorted, reordered or resized.
     *
     * <p>
     * The minimum width is zero because {@link ColumnFitter} applies the
     * design minimums itself; a column-level minimum would let a column grow
     * past its computed share and push the three past the viewport.
     * </p>
     */
    private static TreeTableColumn<Path, Path> fixedColumn(String caption, String styleClass) {
        TreeTableColumn<Path, Path> column = new TreeTableColumn<>(caption);
        column.setCellValueFactory(features ->
                new ReadOnlyObjectWrapper<>(features.getValue().getValue()));
        column.setSortable(false);
        column.setReorderable(false);
        column.setResizable(false);
        column.setMinWidth(0);
        column.setMaxWidth(Double.MAX_VALUE);
        column.getStyleClass().add(styleClass);
        return column;
    }

    private static TreeTableColumn<Path, Path> buildNameColumn(
            Function<Path, ContextMenu> contextMenuFactory) {

        TreeTableColumn<Path, Path> column = fixedColumn(NAME_CAPTION, NAME_COLUMN_CLASS);
        column.setCellFactory(ignored -> new DirectoryNameCell(contextMenuFactory));
        return column;
    }

    /**
     * The Info column, whose header is two rows: the caption, and the unit
     * drop-down beneath it.
     *
     * <p>
     * The header text is left null on purpose. With no text, the header's label
     * resizes its graphic to its own full width and height, so the
     * {@link VBox} below spans the whole cell.
     * </p>
     */
    private static TreeTableColumn<Path, Path> buildInfoColumn(TreeTableView<Path> tree) {
        TreeTableColumn<Path, Path> column = fixedColumn(null, INFO_COLUMN_CLASS);
        column.setCellFactory(ignored -> new DirectoryInfoCell(() -> infoMode));

        // Row 1: the caption. Its bottom border is the line between the rows.
        Label caption = new Label(INFO_CAPTION);
        caption.getStyleClass().add(INFO_CAPTION_CLASS);
        caption.setAlignment(Pos.CENTER);
        // Rows are pinned to the design heights. A zero minimum lets a font
        // with a taller line box than Consolas centre inside the row instead
        // of pushing the header taller.
        caption.setMinSize(0, 0);
        caption.setMaxWidth(Double.MAX_VALUE);

        // Row 2: the current unit and the triangle, as one clickable strip.
        Label mode = new Label();
        mode.getStyleClass().add(INFO_MODE_LABEL_CLASS);
        mode.setAlignment(Pos.CENTER);
        mode.setTextOverrun(OverrunStyle.ELLIPSIS);
        mode.setMinSize(0, 0);
        mode.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(mode, Priority.ALWAYS);

        double arrowWidth = Dim.Directory.HEADER_ARROW_SIZE;
        double arrowHeight = arrowWidth * Dim.Directory.HEADER_ARROW_ASPECT;
        Polygon arrow = new Polygon(
                0.0, 0.0,
                arrowWidth, 0.0,
                arrowWidth / 2.0, arrowHeight);
        arrow.getStyleClass().add(INFO_ARROW_CLASS);

        // Height, padding, spacing and highlight insets come from the generated
        // sheet; the colours, including hover and menu-open, from the theme.
        HBox modeRow = new HBox(mode, arrow);
        modeRow.getStyleClass().add(INFO_MODE_CLASS);
        modeRow.setAlignment(Pos.CENTER);
        modeRow.setMinWidth(0);
        modeRow.setMaxWidth(Double.MAX_VALUE);
        modeRow.setCursor(Cursor.HAND);

        modeTooltip = new Tooltip();
        Tooltip.install(modeRow, modeTooltip);

        VBox header = new VBox(caption, modeRow);
        header.getStyleClass().add(INFO_HEADER_CLASS);
        header.setFillWidth(true);
        header.setMinSize(0, 0);
        header.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);

        modeRow.setOnMouseClicked(event -> {
            if (event.getButton() == MouseButton.PRIMARY) {
                event.consume();
                toggleModeMenu(header, modeRow, tree);
            }
        });

        // The full name or the short one is chosen from the width the label
        // actually has, so it is re-chosen whenever that width or the font
        // changes. Choosing never changes the width -- the label always takes
        // whatever the row leaves it -- so this cannot loop.
        mode.widthProperty().addListener(observable -> fitModeText());
        mode.fontProperty().addListener(observable -> fitModeText());

        modeLabel = mode;
        fitModeText();

        column.setGraphic(header);
        return column;
    }

    /**
     * Writes the current unit into the mode row: the full name if it fits, the
     * one-word name otherwise. Anything narrower still is ellipsized by the
     * label itself.
     */
    private static void fitModeText() {
        Label label = modeLabel;
        if (label == null) {
            return;
        }
        InfoMode mode = infoMode;

        Insets insets = label.getInsets();
        double available = label.getWidth() - insets.getLeft() - insets.getRight();
        String full = mode.label();
        String chosen;
        if (available <= 0 || textWidth(full, label.getFont()) <= available) {
            // Before the first layout the width is unknown; the full name is
            // the right first guess and the width listener corrects it.
            chosen = full;
        } else {
            chosen = mode.shortLabel();
        }

        if (!chosen.equals(label.getText())) {
            label.setText(chosen);
        }
        if (modeTooltip != null) {
            modeTooltip.setText(INFO_CAPTION + ": " + full);
        }
    }

    private static double textWidth(String text, Font font) {
        MEASURE.setFont(font);
        MEASURE.setText(text);
        return Math.ceil(MEASURE.getLayoutBounds().getWidth());
    }

    private static TreeTableColumn<Path, Path> buildRepoColumn() {
        TreeTableColumn<Path, Path> column = fixedColumn(REPO_CAPTION, REPO_COLUMN_CLASS);
        column.setCellFactory(ignored -> new DirectoryRepoCell());
        return column;
    }

    // =====================================================================
    // Column widths
    // =====================================================================

    /**
     * Keeps the three columns at {@code 7.5 : 1.75 : 0.75} of the width that is
     * really available to them.
     *
     * <h4>Why not a plain binding</h4>
     * <p>
     * The width the rows can use depends on whether the vertical scrollbar is
     * showing, and a short tree has none. The old binding always subtracted a
     * fixed scrollbar allowance, so a tree that did not scroll had that many
     * pixels of empty filler to the right of the last column. This class finds
     * the table's real vertical scrollbar once the skin is built and listens
     * to its visibility and width as well as to the table's own size.
     * </p>
     *
     * <h4>Rounding</h4>
     * <p>
     * Info and R are floored to whole pixels and Name receives the exact
     * remainder, so the three sum to the usable width with no fractional
     * overflow that would summon a horizontal scrollbar.
     * </p>
     */
    private static final class ColumnFitter {

        private final TreeTableView<Path> tree;
        private final TreeTableColumn<Path, Path> name;
        private final TreeTableColumn<Path, Path> info;
        private final TreeTableColumn<Path, Path> repo;
        private final InvalidationListener refit = observable -> fit();

        private ScrollBar verticalBar;

        ColumnFitter(TreeTableView<Path> tree,
                TreeTableColumn<Path, Path> name,
                TreeTableColumn<Path, Path> info,
                TreeTableColumn<Path, Path> repo) {
            this.tree = tree;
            this.name = name;
            this.info = info;
            this.repo = repo;
        }

        void install() {
            tree.widthProperty().addListener(refit);
            tree.insetsProperty().addListener(refit);
            // The scrollbar is created with the skin, which is created on the
            // first CSS pass after the table joins a scene.
            tree.skinProperty().addListener(observable -> Platform.runLater(this::attachScrollBar));
            if (tree.getSkin() != null) {
                attachScrollBar();
            }
            fit();
        }

        private void attachScrollBar() {
            if (verticalBar != null) {
                return;
            }
            for (Node node : tree.lookupAll(".scroll-bar")) {
                if (node instanceof ScrollBar bar
                        && bar.getOrientation() == Orientation.VERTICAL
                        && bar.getParent() instanceof VirtualFlow) {
                    verticalBar = bar;
                    bar.visibleProperty().addListener(refit);
                    bar.widthProperty().addListener(refit);
                    break;
                }
            }
            fit();
        }

        private void fit() {
            double usable = Math.floor(usableWidth());
            if (usable <= 0) {
                return;
            }

            double repoWidth = Math.max(Dim.Directory.REPO_MIN_WIDTH,
                    Math.floor(usable * Dim.Directory.REPO_SHARE));
            double infoWidth = Math.max(Dim.Directory.INFO_MIN_WIDTH,
                    Math.floor(usable * Dim.Directory.INFO_SHARE));
            double nameWidth = Math.max(Dim.Directory.NAME_MIN_WIDTH,
                    usable - infoWidth - repoWidth);

            apply(name, nameWidth);
            apply(info, infoWidth);
            apply(repo, repoWidth);
        }

        private double usableWidth() {
            Insets insets = tree.getInsets();
            double inner = tree.getWidth() - insets.getLeft() - insets.getRight();

            double scrollBar;
            if (verticalBar == null) {
                scrollBar = Dim.Directory.SCROLLBAR_ALLOWANCE;
            } else if (verticalBar.isVisible()) {
                scrollBar = verticalBar.getWidth();
            } else {
                scrollBar = 0;
            }
            return inner - scrollBar;
        }

        private static void apply(TreeTableColumn<Path, Path> column, double width) {
            if (Double.compare(column.getPrefWidth(), width) != 0) {
                column.setPrefWidth(width);
            }
        }
    }

    // =====================================================================
    // The Info header menu
    // =====================================================================

    /**
     * Opens the unit menu under the Info header, right-aligned to it, or
     * closes it if it is already open.
     *
     * <p>
     * In practice the click that closes an open menu is usually swallowed by
     * the menu's own auto-hide, which already does the right thing; the check
     * here covers the case where it is not.
     * </p>
     */
    private static void toggleModeMenu(Node header, Node modeRow, TreeTableView<Path> tree) {
        if (openModeMenu != null && openModeMenu.isShowing()) {
            openModeMenu.hide();
            return;
        }

        ContextMenu menu = new ContextMenu();
        menu.getStyleClass().add(INFO_MENU_CLASS);
        ToggleGroup group = new ToggleGroup();

        for (InfoMode mode : InfoMode.values()) {
            RadioMenuItem item = new RadioMenuItem(mode.label());
            item.setToggleGroup(group);
            item.setSelected(mode == infoMode);
            item.setOnAction(event -> applyMode(mode, tree));
            menu.getItems().add(item);
        }

        Node anchor = columnHeaderOf(header);

        menu.setOnShown(event -> {
            if (!modeRow.getStyleClass().contains(MENU_SHOWING_CLASS)) {
                modeRow.getStyleClass().add(MENU_SHOWING_CLASS);
            }
            alignRight(menu, anchor);
        });
        menu.setOnHidden(event -> {
            modeRow.getStyleClass().remove(MENU_SHOWING_CLASS);
            if (openModeMenu == menu) {
                openModeMenu = null;
            }
        });

        openModeMenu = menu;
        menu.show(anchor, Side.BOTTOM, 0, Dim.Directory.MENU_OFFSET_Y);
    }

    /**
     * Moves a shown menu so its right edge lines up with the anchor's. The Info
     * column sits near the panel's right side, and a left-aligned menu would
     * run out past the panel.
     */
    private static void alignRight(ContextMenu menu, Node anchor) {
        // The popup window is wider than the visible frame by its drop shadow,
        // so the frame is measured on screen and the window shifted by the
        // difference, rather than guessing the shadow's size.
        Node frame = menu.getSkin() == null ? null : menu.getSkin().getNode();
        Bounds target = anchor.localToScreen(anchor.getLayoutBounds());
        Bounds actual = frame == null ? null : frame.localToScreen(frame.getLayoutBounds());
        if (target == null || actual == null) {
            return;
        }
        menu.setX(menu.getX() + (target.getMaxX() - actual.getMaxX()));
    }

    /**
     * @return the column header cell containing {@code node}, or {@code node}
     *         itself if it is not inside one
     */
    private static Node columnHeaderOf(Node node) {
        Parent parent = node.getParent();
        while (parent != null) {
            if (parent.getStyleClass().contains(COLUMN_HEADER_CLASS)) {
                return parent;
            }
            parent = parent.getParent();
        }
        return node;
    }

    private static void applyMode(InfoMode mode, TreeTableView<Path> tree) {
        if (mode == null || mode == infoMode) {
            return;
        }
        infoMode = mode;
        InfoMode.store(mode);
        fitModeText();
        tree.refresh();
    }

    /**
     * @return the unit the Info column is currently showing
     */
    public static InfoMode infoMode() {
        return infoMode;
    }

    // =====================================================================
    // Double-click
    // =====================================================================

    /**
     * Makes a double-clicked folder the base folder, and a double-clicked file
     * open in the editor.
     */
    private static void installDoubleClick(UI_Main ide, TreeTableView<Path> tree) {
        tree.addEventFilter(MouseEvent.MOUSE_PRESSED, event -> {
            if (event.getButton() != MouseButton.PRIMARY || event.getClickCount() != 2) {
                return;
            }

            Path path = pathUnder(event.getTarget());
            if (path == null) {
                return;
            }

            // Consumed either way: without this the row's own skin toggles the
            // folder open on the second click, which is exactly the behaviour
            // being replaced.
            event.consume();

            if (Files.isDirectory(path)) {
                setAsBaseFolder(ide, path);
            } else if (Files.isRegularFile(path)) {
                EditorManager.openFileDirectly(ide, path);
            }
        });
    }

    /**
     * Re-roots the tree on a folder, which also moves the breadcrumb.
     *
     * <p>
     * {@code goTo} loads the folder as the project, and loading a project is
     * the single operation that sets the tree root and pushes the path to the
     * breadcrumb, so the two cannot disagree.
     * </p>
     */
    private static void setAsBaseFolder(UI_Main ide, Path folder) {
        Path current = NavigationActions.projectFolder(ide);
        if (FolderPaths.same(current, folder)) {
            // Already the root. Re-loading would collapse everything the user
            // has opened underneath it for no visible gain.
            return;
        }
        NavigationActions.goTo(ide, folder);
    }

    /**
     * Walks up from whatever was clicked to the row that contains it.
     *
     * @param target the event target
     * @return the row's path, or null if the click missed every row
     */
    private static Path pathUnder(EventTarget target) {
        Node node = (target instanceof Node n) ? n : null;
        while (node != null) {
            if (node instanceof TreeTableRow<?> row) {
                Object item = row.getItem();
                return (item instanceof Path path) ? path : null;
            }
            node = node.getParent();
        }
        return null;
    }

    // =====================================================================
    // Refresh
    // =====================================================================

    /**
     * Redraws every visible row. Call after a theme switch, so rows drawn with
     * the previous icon set pick up the new one.
     *
     * @param ide the IDE controller
     */
    public static void refreshIcons(UI_Main ide) {
        if (ide != null && ide.projectTree != null) {
            ide.projectTree.refresh();
        }
    }
}
