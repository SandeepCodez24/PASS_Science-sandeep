package ui.directory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.function.Consumer;
import javafx.application.Platform;
import javafx.beans.InvalidationListener;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.SimpleObjectProperty;
import javafx.css.PseudoClass;
import javafx.event.EventTarget;
import javafx.geometry.Bounds;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.geometry.Side;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.OverrunStyle;
import javafx.scene.control.RadioMenuItem;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Tooltip;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeTableColumn;
import javafx.scene.control.TreeTableRow;
import javafx.scene.control.TreeTableView;
import javafx.scene.control.skin.VirtualFlow;
import javafx.scene.input.ContextMenuEvent;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Polygon;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import ui.UI_Main;
import ui.design.Dim;
import ui.design.DirectoryRowMetrics;
import ui.directory.repo.RepoStatusRegistry;
import ui.editor.navigation.FolderPaths;
import ui.editor.navigation.NavigationActions;
import ui.managers.EditorManager;
import ui.managers.ProjectManager;

/**
 * Builds the directory explorer: a three-column tree table with a header strip.
 *
 * <pre>
 *   +----------------------------------------+-------------------+----+
 *   |                                        |       Info        |    |
 *   | Name                                   |-------------------| R  |
 *   |                                        | By Number of Li v |    |
 *   +----------------------------------------+-------------------+----+
 *   | v [] NeuralCode                        |                   |    |
 *   |      [] cleaned_Runfile.nc             |                42 | o  |
 *   |      [] Examaple_indentation.nc        |                17 | o  |
 *   +----------------------------------------+-------------------+----+
 *        7.5                    :             1.75      :  0.75
 * </pre>
 *
 * <h3>Why a TreeTableView</h3>
 * <p>
 * The old explorer was a {@code TreeView}, which has one column by definition.
 * {@code TreeTableView} keeps the disclosure triangles and the indent of a tree
 * and adds a header that stays aligned over the values.
 * </p>
 *
 * <h3>Column widths</h3>
 * <p>
 * The three columns always fill the table exactly -- no empty filler strip at
 * the right, no horizontal scrollbar under a tree that fits. {@link
 * ColumnFitter} owns every width; it is installed as the table's column
 * resize policy, so a drag on a divider and a change of panel width both go
 * through the same arithmetic.
 * </p>
 * <ul>
 * <li><b>Defaults.</b> Info and R start at their share of the ratio in
 * {@link ui.design.section_dims.Directory_dim} ({@code 7.5 : 1.75 : 0.75}),
 * never below their minimums; Name takes the rest.</li>
 * <li><b>Dragging.</b> Two dividers can be dragged. Name | Info trades width
 * between Name and Info; Info | R trades between Info and R. R's right edge is
 * the panel's edge, so R is not resizable on its own. A dragged width is kept
 * in pixels for the rest of the session and forgotten at restart, where the
 * ratio applies again.</li>
 * <li><b>Narrowing the panel.</b> Name keeps its space first. While Name is
 * narrower than {@code NAME_KEEP_WIDTH}, Info gives up width down to its
 * minimum, then R down to its minimum, and only after that does Name shrink.
 * Widening the panel gives the width back in the reverse order, up to the
 * defaults or the dragged widths.</li>
 * </ul>
 * <p>
 * The width being split is the width inside the table's border, less the
 * vertical scrollbar only while that scrollbar is showing.
 * </p>
 *
 * <h3>The Info header</h3>
 * <p>
 * The Info column's header is two rows in the space of a slightly taller
 * strip: the caption "Info" above a dividing line, and beneath it the current
 * unit with a drop-down triangle. The mode row is the drop-down: it highlights
 * on hover, stays highlighted while the menu is open, and clicking it opens
 * or closes the unit menu.
 * </p>
 * <p>
 * The unit is written out in full ("By Number of Lines") when the column is
 * wide enough, and drops to one word ("Lines") when it is not; the tooltip
 * always carries the full name. Both rows use the smaller
 * {@code DIRECTORY_INFO_HEADER} font so the pair fits without padding.
 * </p>
 * <p>
 * The header has no text of its own, only this graphic. With no text to lay
 * out, JavaFX stretches a header's graphic to the header's full size, which is
 * what lets the two rows span the whole cell.
 * </p>
 *
 * <h3>Rows</h3>
 * <p>
 * Row text uses the breadcrumb bar's font, and every row is
 * {@link DirectoryRowMetrics#rowHeight()} tall -- the text line or the icon,
 * whichever is taller, plus a small pad -- so the list is as compact as it can
 * be without one row's text touching the next.
 * </p>
 *
 * <h3>Double-click</h3>
 * <p>
 * A double-click on a folder makes that folder the base folder -- the tree
 * re-roots there and the breadcrumb follows, because both go through
 * {@link NavigationActions#goTo}. Expansion is left entirely to the disclosure
 * triangle. The handler is an event <em>filter</em> on the table, because
 * {@code TreeTableRow} expands on double-click from inside its own skin and a
 * handler added afterwards cannot stop that.
 * </p>
 *
 * <h3>Rename in place</h3>
 * <p>
 * Three gestures open the name of a row for editing, all through
 * {@link #beginRename(Path)}: the right-click menu's Rename, the F2 key, and a
 * slow double-click on the name of the selected row ({@link DirectorySlowClick}).
 * The field itself is in {@link DirectoryNameCell}; the rules for a valid name
 * are in {@link DirectoryRename}; the file-system step, with its undo record
 * and the update of open editor tabs, is the {@link DirectoryRename.Mover}
 * passed to {@link #initialize(UI_Main, Function, DirectoryRename.Mover)}.
 * </p>
 * <p>
 * After a successful rename the row is updated in place
 * ({@link DirectoryTreeItem#renameTo(Path)}), so folders the user has opened
 * stay open. Renaming the tree's root folder re-roots the tree at the new path
 * instead, which also moves the breadcrumb.
 * </p>
 *
 * <h3>Right-click menus</h3>
 * <p>
 * The tree, not the cells, opens the menus, so it can tell the two places
 * apart: a click on a row gets {@link DirectoryTreeContextMenu#forItem}; a
 * click below the last row (or on a group title) gets
 * {@link DirectoryTreeContextMenu#forEmptySpace}, acting on the folder the
 * tree is showing. The menus are shown, never attached, so their shortcuts
 * are not registered window-wide.
 * </p>
 *
 * <h3>Shortcuts</h3>
 * <p>
 * While the tree has focus: Ctrl+X / Ctrl+C / Ctrl+V, Delete, F2, Ctrl+Z,
 * Ctrl+Y (also Ctrl+Shift+Z), F5 and Alt+Enter -- the same keys the menus
 * show. They are an event <em>filter</em>, so they win over anything the
 * scene might map to the same keys, and they stand aside while a name is being
 * edited. Paste from the keyboard goes into the folder of the selected row
 * (beside it), as in Windows.
 * </p>
 *
 * <h3>Refresh, sort and group</h3>
 * <p>
 * {@link #refresh()} re-reads the folders from disk and {@link
 * #applyViewSettings()} re-orders them; both keep every opened folder open,
 * the selection and the scroll position.
 * </p>
 */
public final class DirectoryTreeBuilder {

    private static final String TABLE_CLASS = "directory-tree";

    // Column style classes. JavaFX copies a column's style classes onto its
    // header, which is how the generated sheet aligns each caption.
    private static final String NAME_COLUMN_CLASS = "directory-name-column";
    private static final String INFO_COLUMN_CLASS = "directory-info-column";
    private static final String REPO_COLUMN_CLASS = "directory-repo-column";

    private static final String INFO_HEADER_CLASS = "directory-info-header";
    private static final String INFO_CAPTION_CLASS = "directory-info-caption";
    private static final String INFO_MODE_CLASS = "directory-info-mode";
    private static final String INFO_MODE_LABEL_CLASS = "directory-info-mode-label";
    private static final String INFO_ARROW_CLASS = "directory-info-arrow";
    private static final String INFO_MENU_CLASS = "directory-info-menu";
    private static final String MENU_SHOWING_CLASS = "menu-showing";
    private static final String COLUMN_HEADER_CLASS = "column-header";

    private static final String NAME_CAPTION = "Name";
    private static final String INFO_CAPTION = "Info";
    private static final String REPO_CAPTION = "R";

    private static InfoMode infoMode = InfoMode.stored();

    private static TreeTableView<Path> table;
    private static ContextMenu openModeMenu;

    /** The mode row's text, kept so a change of unit can rewrite it. */
    private static Label modeLabel;
    private static Tooltip modeTooltip;

    /** Scratch node for measuring a mode name before choosing it. */
    private static final Text MEASURE = new Text();

    // ---- rename in place ------------------------------------------------
    /** The path whose name field is open, or null. Watched by every name cell. */
    private static final ObjectProperty<Path> RENAME_TARGET = new SimpleObjectProperty<>();
    private static DirectoryRename.Mover renameMover;
    private static UI_Main ideRef;
    private static DirectorySlowClick slowClick;

    /** Run once the current rename ends, with the item's final path. */
    private static Consumer<Path> renameFollowUp;
    private static Path renameOriginal;
    private static Path renameResult;

    // ---- menus and file actions ---------------------------------------------
    private static DirectoryTreeContextMenu.Actions actions;
    private static ContextMenu openMenu;

    /** The item waiting for Paste after a Cut, drawn dimmed. */
    private static Path cutTarget;

    private static final PseudoClass GROUP_ROW = PseudoClass.getPseudoClass("group");

    /** Extra redo key on Windows/Linux, where the menu shows Ctrl+Y. */
    private static final KeyCombination REDO_ALT = new KeyCodeCombination(KeyCode.Z,
            KeyCombination.SHORTCUT_DOWN, KeyCombination.SHIFT_DOWN);

    private DirectoryTreeBuilder() {
    }

    // =====================================================================
    // Construction
    // =====================================================================

    /**
     * Creates the tree table, its two right-click menus, its shortcuts and
     * in-place rename, and installs it on the IDE controller.
     *
     * @param ide        the IDE controller
     * @param fileActions what the menus and shortcuts do; normally a
     *                   {@link DirectoryFileOps}
     * @param mover      performs a rename on disk; null disables in-place
     *                   rename
     */
    public static void initialize(UI_Main ide, DirectoryTreeContextMenu.Actions fileActions,
            DirectoryRename.Mover mover) {
        ideRef = ide;
        renameMover = mover;
        actions = fileActions;

        TreeTableView<Path> tree = new TreeTableView<>();
        tree.getStyleClass().add(TABLE_CLASS);
        tree.setShowRoot(true);
        tree.setPrefWidth(Dim.Explorer.PANEL_PREF_WIDTH);
        tree.setMinWidth(Dim.Explorer.PANEL_MIN_WIDTH);
        // Measured from the breadcrumb font and the icon size: the tightest
        // height at which rows cannot overlap. The generated sheet uses the
        // same value for -fx-cell-size.
        tree.setFixedCellSize(DirectoryRowMetrics.rowHeight());
        // ColumnFitter alone decides the widths: install() makes it the
        // table's column resize policy, so divider drags come to it too.
        tree.setTableMenuButtonVisible(false);
        tree.setPlaceholder(new Label(""));

        TreeTableColumn<Path, Path> name = buildNameColumn();
        TreeTableColumn<Path, Path> info = buildInfoColumn(tree);
        TreeTableColumn<Path, Path> repo = buildRepoColumn();

        tree.getColumns().add(name);
        tree.getColumns().add(info);
        tree.getColumns().add(repo);
        tree.setTreeColumn(name);

        tree.setRowFactory(ignored -> new GroupAwareRow());

        new ColumnFitter(tree, name, info, repo).install();
        installDoubleClick(ide, tree);
        installRenameGestures(tree);
        installContextMenus(tree);
        installShortcuts(tree);

        // A provider that learns something in the background repaints the R
        // column without anyone rebuilding the tree.
        RepoStatusRegistry.addListener(() -> {
            if (table != null) {
                table.refresh();
            }
        });

        table = tree;
        ide.projectTree = tree;
    }

    // =====================================================================
    // Columns
    // =====================================================================

    /**
     * The settings every column shares: it shows the row's own path, and it
     * cannot be sorted or reordered.
     *
     * <p>
     * Whether its right-hand divider can be dragged is decided per column:
     * Name and Info yes (the Name | Info and Info | R dividers), R no, because
     * its right edge is the panel's edge. The drag itself is carried out by
     * {@link ColumnFitter}, the table's resize policy.
     * </p>
     * <p>
     * The minimum width is zero because {@link ColumnFitter} applies the
     * design minimums itself; a column-level minimum would let a column grow
     * past its computed share and push the three past the viewport.
     * </p>
     */
    private static TreeTableColumn<Path, Path> fixedColumn(String caption, String styleClass,
            boolean resizable) {
        TreeTableColumn<Path, Path> column = new TreeTableColumn<>(caption);
        column.setCellValueFactory(features ->
                new ReadOnlyObjectWrapper<>(features.getValue().getValue()));
        column.setSortable(false);
        column.setReorderable(false);
        column.setResizable(resizable);
        column.setMinWidth(0);
        column.setMaxWidth(Double.MAX_VALUE);
        column.getStyleClass().add(styleClass);
        return column;
    }

    private static TreeTableColumn<Path, Path> buildNameColumn() {
        TreeTableColumn<Path, Path> column = fixedColumn(NAME_CAPTION, NAME_COLUMN_CLASS, true);
        column.setCellFactory(ignored -> new DirectoryNameCell());
        return column;
    }

    /**
     * A plain row that carries the {@code :group} pseudo-class while it shows
     * a {@link DirectoryGroupItem}, so the theme can give group titles their
     * own look and hide the Info and R cells on them.
     */
    private static final class GroupAwareRow extends TreeTableRow<Path> {
        @Override
        protected void updateItem(Path item, boolean empty) {
            super.updateItem(item, empty);
            pseudoClassStateChanged(GROUP_ROW, !empty && DirectoryGroupItem.isGroup(getTreeItem()));
        }
    }

    /**
     * The Info column, whose header is two rows: the caption, and the unit
     * drop-down beneath it.
     *
     * <p>
     * The header text is left null on purpose. With no text, the header's label
     * resizes its graphic to its own full width and height, so the
     * {@link VBox} below spans the whole cell.
     * </p>
     */
    private static TreeTableColumn<Path, Path> buildInfoColumn(TreeTableView<Path> tree) {
        TreeTableColumn<Path, Path> column = fixedColumn(null, INFO_COLUMN_CLASS, true);
        column.setCellFactory(ignored -> new DirectoryInfoCell(() -> infoMode));

        // Row 1: the caption. Its bottom border is the line between the rows.
        Label caption = new Label(INFO_CAPTION);
        caption.getStyleClass().add(INFO_CAPTION_CLASS);
        caption.setAlignment(Pos.CENTER);
        // Rows are pinned to the design heights. A zero minimum lets a font
        // with a taller line box than Consolas centre inside the row instead
        // of pushing the header taller.
        caption.setMinSize(0, 0);
        caption.setMaxWidth(Double.MAX_VALUE);

        // Row 2: the current unit and the triangle, as one clickable strip.
        Label mode = new Label();
        mode.getStyleClass().add(INFO_MODE_LABEL_CLASS);
        mode.setAlignment(Pos.CENTER);
        mode.setTextOverrun(OverrunStyle.ELLIPSIS);
        mode.setMinSize(0, 0);
        mode.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(mode, Priority.ALWAYS);

        double arrowWidth = Dim.Directory.HEADER_ARROW_SIZE;
        double arrowHeight = arrowWidth * Dim.Directory.HEADER_ARROW_ASPECT;
        Polygon arrow = new Polygon(
                0.0, 0.0,
                arrowWidth, 0.0,
                arrowWidth / 2.0, arrowHeight);
        arrow.getStyleClass().add(INFO_ARROW_CLASS);

        // Height, padding, spacing and highlight insets come from the generated
        // sheet; the colours, including hover and menu-open, from the theme.
        HBox modeRow = new HBox(mode, arrow);
        modeRow.getStyleClass().add(INFO_MODE_CLASS);
        modeRow.setAlignment(Pos.CENTER);
        modeRow.setMinWidth(0);
        modeRow.setMaxWidth(Double.MAX_VALUE);
        modeRow.setCursor(Cursor.HAND);

        modeTooltip = new Tooltip();
        Tooltip.install(modeRow, modeTooltip);

        VBox header = new VBox(caption, modeRow);
        header.getStyleClass().add(INFO_HEADER_CLASS);
        header.setFillWidth(true);
        header.setMinSize(0, 0);
        header.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);

        modeRow.setOnMouseClicked(event -> {
            if (event.getButton() == MouseButton.PRIMARY) {
                event.consume();
                toggleModeMenu(header, modeRow, tree);
            }
        });

        // The full name or the short one is chosen from the width the label
        // actually has, so it is re-chosen whenever that width or the font
        // changes. Choosing never changes the width -- the label always takes
        // whatever the row leaves it -- so this cannot loop.
        mode.widthProperty().addListener(observable -> fitModeText());
        mode.fontProperty().addListener(observable -> fitModeText());

        modeLabel = mode;
        fitModeText();

        column.setGraphic(header);
        return column;
    }

    /**
     * Writes the current unit into the mode row: the full name if it fits, the
     * one-word name if that fits, and otherwise nothing -- only the drop-down
     * triangle, which still opens the menu. The Info column can now be
     * narrowed below the width of the one-word names, and a clipped "Fu..."
     * reads worse than a bare triangle. The tooltip always carries the full
     * name.
     */
    private static void fitModeText() {
        Label label = modeLabel;
        if (label == null) {
            return;
        }
        InfoMode mode = infoMode;

        Insets insets = label.getInsets();
        double available = label.getWidth() - insets.getLeft() - insets.getRight();
        String full = mode.label();
        String chosen;
        if (available <= 0 || textWidth(full, label.getFont()) <= available) {
            // Before the first layout the width is unknown; the full name is
            // the right first guess and the width listener corrects it.
            chosen = full;
        } else if (textWidth(mode.shortLabel(), label.getFont()) <= available) {
            chosen = mode.shortLabel();
        } else {
            chosen = "";
        }

        if (!chosen.equals(label.getText())) {
            label.setText(chosen);
        }
        if (modeTooltip != null) {
            modeTooltip.setText(INFO_CAPTION + ": " + full);
        }
    }

    private static double textWidth(String text, Font font) {
        MEASURE.setFont(font);
        MEASURE.setText(text);
        return Math.ceil(MEASURE.getLayoutBounds().getWidth());
    }

    private static TreeTableColumn<Path, Path> buildRepoColumn() {
        TreeTableColumn<Path, Path> column = fixedColumn(REPO_CAPTION, REPO_COLUMN_CLASS, false);
        column.setCellFactory(ignored -> new DirectoryRepoCell());
        return column;
    }

    // =====================================================================
    // Column widths
    // =====================================================================

    /**
     * Sizes the three columns, and is the table's column resize policy.
     *
     * <h4>The rule</h4>
     * <ol>
     * <li>Info and R want their <i>preferred</i> width: the width the user
     * dragged them to this session, or else their ratio share of the usable
     * width, never below their minimums.</li>
     * <li>Name takes what is left, but is protected down to
     * {@link #nameKeep(double)}: if the remainder is smaller, Info gives up
     * width down to its minimum, then R down to its minimum.</li>
     * <li>Only when both are at their minimums does Name go below the
     * protected width.</li>
     * </ol>
     * <p>
     * The preferred widths are never changed by narrowing, only by dragging, so
     * widening the panel again brings Info and R back to exactly where they
     * were. Nothing is stored: a restart starts from the ratio.
     * </p>
     *
     * <h4>Dragging</h4>
     * <p>
     * JavaFX hands a divider drag to the resize policy as "column X, delta
     * d". The Name | Info divider belongs to Name, so a drag there moves width
     * between Name and Info; the Info | R divider belongs to Info, so a drag
     * there moves width between Info and R and Name does not move. Returning
     * false when nothing could change keeps the divider under the mouse: JavaFX
     * then keeps accumulating the delta until the drag comes back into range.
     * </p>
     *
     * <h4>Why not a plain binding</h4>
     * <p>
     * The width the rows can use depends on whether the vertical scrollbar is
     * showing, and a short tree has none. This class finds the table's real
     * vertical scrollbar once the skin is built and listens to its visibility
     * and width as well as to the table's own size.
     * </p>
     *
     * <h4>Rounding</h4>
     * <p>
     * Info and R are whole pixels and Name receives the exact remainder, so
     * the three sum to the usable width with no fractional overflow that would
     * summon a horizontal scrollbar.
     * </p>
     */
    private static final class ColumnFitter {

        private final TreeTableView<Path> tree;
        private final TreeTableColumn<Path, Path> name;
        private final TreeTableColumn<Path, Path> info;
        private final TreeTableColumn<Path, Path> repo;
        private final InvalidationListener refit = observable -> fit();

        private ScrollBar verticalBar;

        /** Dragged Info width for this session, or -1 for the ratio default. */
        private double infoPreferred = -1;

        /** Dragged R width for this session, or -1 for the ratio default. */
        private double repoPreferred = -1;

        ColumnFitter(TreeTableView<Path> tree,
                TreeTableColumn<Path, Path> name,
                TreeTableColumn<Path, Path> info,
                TreeTableColumn<Path, Path> repo) {
            this.tree = tree;
            this.name = name;
            this.info = info;
            this.repo = repo;
        }

        void install() {
            tree.setColumnResizePolicy(this::resize);
            tree.widthProperty().addListener(refit);
            tree.insetsProperty().addListener(refit);
            // The scrollbar is created with the skin, which is created on the
            // first CSS pass after the table joins a scene.
            tree.skinProperty().addListener(observable -> Platform.runLater(this::attachScrollBar));
            if (tree.getSkin() != null) {
                attachScrollBar();
            }
            fit();
        }

        private void attachScrollBar() {
            if (verticalBar != null) {
                return;
            }
            for (Node node : tree.lookupAll(".scroll-bar")) {
                if (node instanceof ScrollBar bar
                        && bar.getOrientation() == Orientation.VERTICAL
                        && bar.getParent() instanceof VirtualFlow) {
                    verticalBar = bar;
                    bar.visibleProperty().addListener(refit);
                    bar.widthProperty().addListener(refit);
                    break;
                }
            }
            fit();
        }

        // ---- resize policy ----------------------------------------------

        /**
         * The table's column resize policy.
         *
         * @param features the column being dragged and the drag delta; a null
         *                 column means the table itself changed size
         * @return true if the widths changed
         */
        @SuppressWarnings("rawtypes")
        private Boolean resize(TreeTableView.ResizeFeatures features) {
            Object column = features == null ? null : features.getColumn();
            Double rawDelta = features == null ? null : features.getDelta();
            double delta = rawDelta == null ? 0 : rawDelta;

            if (column == null) {
                fit();
                return Boolean.TRUE;
            }
            double usable = Math.floor(usableWidth());
            if (usable <= 0 || delta == 0) {
                return Boolean.FALSE;
            }

            double infoNow = info.getWidth();
            double repoNow = repo.getWidth();

            if (column == name) {
                // Name | Info: Name grows by delta, Info shrinks by it.
                double infoMax = Math.max(Dim.Directory.INFO_MIN_WIDTH,
                        usable - repoNow - nameKeep(usable));
                double target = clamp(Math.round(infoNow - delta),
                        Dim.Directory.INFO_MIN_WIDTH, infoMax);
                if (target == infoNow) {
                    return Boolean.FALSE;
                }
                infoPreferred = target;
                repoPreferred = repoNow;
                fit();
                return Boolean.TRUE;
            }

            if (column == info) {
                // Info | R: Info grows by delta, R shrinks by it; Name stays.
                double pair = infoNow + repoNow;
                double target = clamp(Math.round(infoNow + delta),
                        Dim.Directory.INFO_MIN_WIDTH, pair - Dim.Directory.REPO_MIN_WIDTH);
                if (target == infoNow) {
                    return Boolean.FALSE;
                }
                infoPreferred = target;
                repoPreferred = pair - target;
                fit();
                return Boolean.TRUE;
            }

            return Boolean.FALSE;
        }

        // ---- fitting ------------------------------------------------------

        private void fit() {
            double usable = Math.floor(usableWidth());
            if (usable <= 0) {
                return;
            }

            double infoWidth = infoPreferred >= 0
                    ? Math.max(Dim.Directory.INFO_MIN_WIDTH, infoPreferred)
                    : Math.max(Dim.Directory.INFO_MIN_WIDTH, Math.floor(usable * Dim.Directory.INFO_SHARE));
            double repoWidth = repoPreferred >= 0
                    ? Math.max(Dim.Directory.REPO_MIN_WIDTH, repoPreferred)
                    : Math.max(Dim.Directory.REPO_MIN_WIDTH, Math.floor(usable * Dim.Directory.REPO_SHARE));

            // Name keeps its space first: Info, then R, give way.
            double shortfall = nameKeep(usable) - (usable - infoWidth - repoWidth);
            if (shortfall > 0) {
                double fromInfo = Math.min(shortfall, infoWidth - Dim.Directory.INFO_MIN_WIDTH);
                infoWidth -= fromInfo;
                shortfall -= fromInfo;
            }
            if (shortfall > 0) {
                double fromRepo = Math.min(shortfall, repoWidth - Dim.Directory.REPO_MIN_WIDTH);
                repoWidth -= fromRepo;
            }

            double nameWidth = Math.max(Dim.Directory.NAME_MIN_WIDTH, usable - infoWidth - repoWidth);

            apply(name, nameWidth);
            apply(info, infoWidth);
            apply(repo, repoWidth);
        }

        /**
         * The width Name is protected down to: {@code NAME_KEEP_WIDTH}, or less
         * when the panel is so narrow that Info and R at their minimums leave
         * less than that.
         */
        private static double nameKeep(double usable) {
            double room = usable - Dim.Directory.INFO_MIN_WIDTH - Dim.Directory.REPO_MIN_WIDTH;
            return Math.max(Dim.Directory.NAME_MIN_WIDTH, Math.min(Dim.Directory.NAME_KEEP_WIDTH, room));
        }

        private double usableWidth() {
            Insets insets = tree.getInsets();
            double inner = tree.getWidth() - insets.getLeft() - insets.getRight();

            double scrollBar;
            if (verticalBar == null) {
                scrollBar = Dim.Directory.SCROLLBAR_ALLOWANCE;
            } else if (verticalBar.isVisible()) {
                scrollBar = verticalBar.getWidth();
            } else {
                scrollBar = 0;
            }
            return inner - scrollBar;
        }

        private static double clamp(double value, double min, double max) {
            return Math.max(min, Math.min(max, value));
        }

        private static void apply(TreeTableColumn<Path, Path> column, double width) {
            if (Double.compare(column.getPrefWidth(), width) != 0) {
                column.setPrefWidth(width);
            }
        }
    }

    // =====================================================================
    // The Info header menu
    // =====================================================================

    /**
     * Opens the unit menu under the Info header, right-aligned to it, or
     * closes it if it is already open.
     *
     * <p>
     * In practice the click that closes an open menu is usually swallowed by
     * the menu's own auto-hide, which already does the right thing; the check
     * here covers the case where it is not.
     * </p>
     */
    private static void toggleModeMenu(Node header, Node modeRow, TreeTableView<Path> tree) {
        if (openModeMenu != null && openModeMenu.isShowing()) {
            openModeMenu.hide();
            return;
        }

        ContextMenu menu = new ContextMenu();
        menu.getStyleClass().add(INFO_MENU_CLASS);
        ToggleGroup group = new ToggleGroup();

        for (InfoMode mode : InfoMode.values()) {
            RadioMenuItem item = new RadioMenuItem(mode.label());
            item.setToggleGroup(group);
            item.setSelected(mode == infoMode);
            item.setOnAction(event -> applyMode(mode, tree));
            menu.getItems().add(item);
        }

        Node anchor = columnHeaderOf(header);

        menu.setOnShown(event -> {
            if (!modeRow.getStyleClass().contains(MENU_SHOWING_CLASS)) {
                modeRow.getStyleClass().add(MENU_SHOWING_CLASS);
            }
            alignRight(menu, anchor);
        });
        menu.setOnHidden(event -> {
            modeRow.getStyleClass().remove(MENU_SHOWING_CLASS);
            if (openModeMenu == menu) {
                openModeMenu = null;
            }
        });

        openModeMenu = menu;
        menu.show(anchor, Side.BOTTOM, 0, Dim.Directory.MENU_OFFSET_Y);
    }

    /**
     * Moves a shown menu so its right edge lines up with the anchor's. The Info
     * column sits near the panel's right side, and a left-aligned menu would
     * run out past the panel.
     */
    private static void alignRight(ContextMenu menu, Node anchor) {
        // The popup window is wider than the visible frame by its drop shadow,
        // so the frame is measured on screen and the window shifted by the
        // difference, rather than guessing the shadow's size.
        Node frame = menu.getSkin() == null ? null : menu.getSkin().getNode();
        Bounds target = anchor.localToScreen(anchor.getLayoutBounds());
        Bounds actual = frame == null ? null : frame.localToScreen(frame.getLayoutBounds());
        if (target == null || actual == null) {
            return;
        }
        menu.setX(menu.getX() + (target.getMaxX() - actual.getMaxX()));
    }

    /**
     * @return the column header cell containing {@code node}, or {@code node}
     *         itself if it is not inside one
     */
    private static Node columnHeaderOf(Node node) {
        Parent parent = node.getParent();
        while (parent != null) {
            if (parent.getStyleClass().contains(COLUMN_HEADER_CLASS)) {
                return parent;
            }
            parent = parent.getParent();
        }
        return node;
    }

    private static void applyMode(InfoMode mode, TreeTableView<Path> tree) {
        if (mode == null || mode == infoMode) {
            return;
        }
        infoMode = mode;
        InfoMode.store(mode);
        fitModeText();
        tree.refresh();
    }

    /**
     * @return the unit the Info column is currently showing
     */
    public static InfoMode infoMode() {
        return infoMode;
    }

    // =====================================================================
    // Double-click
    // =====================================================================

    /**
     * Makes a double-clicked folder the base folder, and a double-clicked file
     * open in the editor.
     */
    private static void installDoubleClick(UI_Main ide, TreeTableView<Path> tree) {
        tree.addEventFilter(MouseEvent.MOUSE_PRESSED, event -> {
            if (event.getButton() != MouseButton.PRIMARY || event.getClickCount() != 2) {
                return;
            }
            // A double-click inside an open rename field selects a word.
            if (DirectorySlowClick.isInsideTextInput(event.getTarget())) {
                return;
            }

            TreeTableRow<?> row = rowUnder(event.getTarget());
            if (row != null && !row.isEmpty() && row.getTreeItem() instanceof DirectoryGroupItem group) {
                // A group title opens and closes like Windows' group headers.
                event.consume();
                group.setExpanded(!group.isExpanded());
                return;
            }

            Path path = pathUnder(event.getTarget());
            if (path == null) {
                return;
            }

            // Consumed either way: without this the row's own skin toggles the
            // folder open on the second click, which is exactly the behaviour
            // being replaced.
            event.consume();

            if (Files.isDirectory(path)) {
                setAsBaseFolder(ide, path);
            } else if (Files.isRegularFile(path)) {
                EditorManager.openFileDirectly(ide, path);
            }
        });
    }

    /**
     * Re-roots the tree on a folder, which also moves the breadcrumb.
     *
     * <p>
     * {@code goTo} loads the folder as the project, and loading a project is
     * the single operation that sets the tree root and pushes the path to the
     * breadcrumb, so the two cannot disagree.
     * </p>
     */
    private static void setAsBaseFolder(UI_Main ide, Path folder) {
        Path current = NavigationActions.projectFolder(ide);
        if (FolderPaths.same(current, folder)) {
            // Already the root. Re-loading would collapse everything the user
            // has opened underneath it for no visible gain.
            return;
        }
        NavigationActions.goTo(ide, folder);
    }

    /**
     * @param target an event target inside the tree
     * @return the path of the row containing it, or null
     */
    static Path rowPathUnder(EventTarget target) {
        return pathUnder(target);
    }

    /**
     * Walks up from whatever was clicked to the row that contains it.
     *
     * @param target the event target
     * @return the row's path, or null if the click missed every row
     */
    private static Path pathUnder(EventTarget target) {
        TreeTableRow<?> row = rowUnder(target);
        if (row == null) {
            return null;
        }
        Object item = row.getItem();
        return (item instanceof Path path) ? path : null;
    }

    /** The row containing an event target, or null. */
    private static TreeTableRow<?> rowUnder(EventTarget target) {
        Node node = (target instanceof Node n) ? n : null;
        while (node != null) {
            if (node instanceof TreeTableRow<?> row) {
                return row;
            }
            node = node.getParent();
        }
        return null;
    }

    /** True if the target is in the column header strip. */
    private static boolean isInsideHeader(EventTarget target) {
        Node node = (target instanceof Node n) ? n : null;
        while (node != null) {
            if (node.getStyleClass().contains(COLUMN_HEADER_CLASS)
                    || node.getStyleClass().contains("column-header-background")) {
                return true;
            }
            node = node.getParent();
        }
        return false;
    }

    // =====================================================================
    // Rename in place
    // =====================================================================

    /** F2 and the slow double-click. The menu calls {@link #beginRename} directly. */
    private static void installRenameGestures(TreeTableView<Path> tree) {
        slowClick = new DirectorySlowClick(tree, DirectoryTreeBuilder::beginRename);
        slowClick.install();

        tree.addEventHandler(KeyEvent.KEY_PRESSED, event -> {
            if (event.getCode() != KeyCode.F2 || isRenaming()
                    || DirectorySlowClick.isInsideTextInput(event.getTarget())) {
                return;
            }
            TreeItem<Path> item = tree.getSelectionModel().getSelectedItem();
            if (item != null && item.getValue() != null) {
                beginRename(item.getValue());
                event.consume();
            }
        });
    }

    /**
     * Opens the name of {@code path} for editing in its row: selects the row,
     * scrolls it into view if needed, and turns its name into a text field.
     * Does nothing if in-place rename was not enabled or the path is not
     * currently shown in the tree.
     *
     * @param path the file or folder to rename
     */
    public static void beginRename(Path path) {
        beginRename(path, null);
    }

    /**
     * {@link #beginRename(Path)}, then runs {@code followUp} once the rename
     * ends -- committed, unchanged or cancelled -- with the item's final path.
     * Used by New, which opens a new file in the editor under whatever name
     * it is given. If the rename cannot start, {@code followUp} runs at once.
     *
     * @param path     the item
     * @param followUp receives the final path; may be null
     */
    public static void beginRename(Path path, Consumer<Path> followUp) {
        if (table == null || path == null || renameMover == null || !Files.exists(path)) {
            runFollowUp(followUp, path);
            return;
        }
        if (slowClick != null) {
            slowClick.cancel();
        }
        revealItem(path);
        int row = rowOf(path);
        if (row < 0) {
            runFollowUp(followUp, path);
            return;
        }
        RENAME_TARGET.set(null);
        renameFollowUp = followUp;
        renameOriginal = path;
        renameResult = null;
        table.getSelectionModel().clearAndSelect(row);
        if (!isRowVisible(row)) {
            table.scrollTo(row);
        }
        table.requestFocus();
        // After the scroll has laid the rows out, so the right cell exists.
        Platform.runLater(() -> RENAME_TARGET.set(path));
    }

    private static void runFollowUp(Consumer<Path> followUp, Path path) {
        if (followUp != null) {
            Platform.runLater(() -> followUp.accept(path));
        }
    }

    /** Closes an open rename field without renaming anything. */
    public static void cancelRename() {
        RENAME_TARGET.set(null);
        Consumer<Path> followUp = renameFollowUp;
        Path finalPath = renameResult != null ? renameResult : renameOriginal;
        renameFollowUp = null;
        renameOriginal = null;
        renameResult = null;
        if (followUp != null) {
            runFollowUp(followUp, finalPath);
        }
    }

    /**
     * @return true while a name field is open
     */
    public static boolean isRenaming() {
        return RENAME_TARGET.get() != null;
    }

    /**
     * @return the path whose name field is open; observed by the name cells
     */
    static ReadOnlyObjectProperty<Path> renameTargetProperty() {
        return RENAME_TARGET;
    }

    /**
     * Validates and performs a rename typed into a row's field.
     *
     * @param item  the row's tree item
     * @param typed what the user typed
     * @return null when the rename succeeded or there was nothing to do;
     *         otherwise the sentence to show under the field
     */
    static String commitRename(TreeItem<Path> item, String typed) {
        if (item == null || item.getValue() == null || renameMover == null) {
            return null;
        }
        Path source = item.getValue();
        String name = typed == null ? "" : typed.strip();
        if (name.equals(DirectoryRename.nameOf(source))) {
            return null; // unchanged
        }
        String error = DirectoryRename.validate(source, name);
        if (error != null) {
            return error;
        }
        Path moved;
        try {
            moved = renameMover.move(source, source.resolveSibling(name));
        } catch (IOException | RuntimeException ex) {
            return DirectoryRename.describe(ex);
        }
        renameResult = moved;
        Platform.runLater(() -> applyRenamed(item, moved));
        return null;
    }

    /** Shows a completed rename in the tree without rebuilding it. */
    private static void applyRenamed(TreeItem<Path> item, Path moved) {
        if (table == null || moved == null) {
            return;
        }
        if (item == table.getRoot()) {
            // The root is the project folder: re-root there, which also moves
            // the breadcrumb and ide.currentFolder.
            ProjectManager.loadProjectFromPath(ideRef, moved);
            return;
        }
        if (item instanceof DirectoryTreeItem node) {
            node.renameTo(moved);
        } else {
            item.setValue(moved);
        }
        int row = table.getRow(item);
        if (row >= 0) {
            table.getSelectionModel().clearAndSelect(row);
            if (!isRowVisible(row)) {
                table.scrollTo(row);
            }
        }
        table.refresh();
    }

    /** Row index of a path among the rows currently shown, or -1. */
    private static int rowOf(Path path) {
        int count = table.getExpandedItemCount();
        for (int i = 0; i < count; i++) {
            TreeItem<Path> item = table.getTreeItem(i);
            if (item != null && path.equals(item.getValue())) {
                return i;
            }
        }
        return -1;
    }

    private static boolean isRowVisible(int row) {
        VirtualFlow<?> flow = (VirtualFlow<?>) table.lookup(".virtual-flow");
        if (flow == null || flow.getFirstVisibleCell() == null || flow.getLastVisibleCell() == null) {
            return false;
        }
        return row >= flow.getFirstVisibleCell().getIndex() && row <= flow.getLastVisibleCell().getIndex();
    }

    // =====================================================================
    // Right-click menus
    // =====================================================================

    /**
     * One handler for the whole tree: a row gets the item menu, empty space
     * (and a group title) gets the folder menu.
     */
    private static void installContextMenus(TreeTableView<Path> tree) {
        tree.addEventHandler(ContextMenuEvent.CONTEXT_MENU_REQUESTED, event -> {
            if (actions == null || isRenaming()
                    || DirectorySlowClick.isInsideTextInput(event.getTarget())
                    || isInsideHeader(event.getTarget())) {
                return;
            }

            TreeItem<Path> item;
            if (event.isKeyboardTrigger()) {
                item = tree.getSelectionModel().getSelectedItem();
            } else {
                TreeTableRow<?> row = rowUnder(event.getTarget());
                item = (row == null || row.isEmpty()) ? null : tree.getTreeItem(row.getIndex());
            }

            ContextMenu menu;
            if (item != null && item.getValue() != null) {
                int index = tree.getRow(item);
                if (index >= 0) {
                    tree.getSelectionModel().clearAndSelect(index);
                }
                menu = DirectoryTreeContextMenu.forItem(item.getValue(), actions);
            } else if (item instanceof DirectoryGroupItem group) {
                menu = DirectoryTreeContextMenu.forEmptySpace(group.folder(), actions);
            } else {
                // Windows clears the selection when you right-click empty space.
                tree.getSelectionModel().clearSelection();
                menu = DirectoryTreeContextMenu.forEmptySpace(rootFolder(), actions);
            }
            event.consume();
            showMenu(menu, tree, event.getScreenX(), event.getScreenY());
        });
        // A left click anywhere closes a menu that is still open.
        tree.addEventFilter(MouseEvent.MOUSE_PRESSED, event -> {
            if (event.getButton() == MouseButton.PRIMARY && openMenu != null) {
                openMenu.hide();
            }
        });
    }

    private static void showMenu(ContextMenu menu, Node owner, double x, double y) {
        if (openMenu != null && openMenu.isShowing()) {
            openMenu.hide();
        }
        if (menu == null) {
            return;
        }
        openMenu = menu;
        menu.setOnHidden(event -> {
            if (openMenu == menu) {
                openMenu = null;
            }
        });
        menu.show(owner, x, y);
    }

    // =====================================================================
    // Shortcuts
    // =====================================================================

    private static void installShortcuts(TreeTableView<Path> tree) {
        tree.addEventFilter(KeyEvent.KEY_PRESSED, event -> {
            if (actions == null || isRenaming() || DirectorySlowClick.isInsideTextInput(event.getTarget())) {
                return;
            }
            Path selected = selectedPath();
            boolean handled = true;
            if (DirectoryTreeContextMenu.CUT.match(event)) {
                actions.cut(selected);
            } else if (DirectoryTreeContextMenu.COPY.match(event)) {
                actions.copy(selected);
            } else if (DirectoryTreeContextMenu.PASTE.match(event)) {
                actions.paste(pasteTarget());
            } else if (DirectoryTreeContextMenu.DELETE.match(event)) {
                actions.delete(selected);
            } else if (DirectoryTreeContextMenu.UNDO.match(event)) {
                actions.undo();
            } else if (DirectoryTreeContextMenu.REDO.match(event) || REDO_ALT.match(event)) {
                actions.redo();
            } else if (DirectoryTreeContextMenu.REFRESH.match(event)) {
                actions.refresh();
            } else if (DirectoryTreeContextMenu.PROPERTIES.match(event)) {
                actions.properties(selected != null ? selected : rootFolder());
            } else {
                handled = false;
            }
            if (handled) {
                event.consume();
            }
        });
    }

    /**
     * Where a keyboard Paste lands: the folder that holds the selected row
     * (so the pasted item appears beside it), or the tree's folder.
     */
    private static Path pasteTarget() {
        TreeItem<Path> item = table == null ? null : table.getSelectionModel().getSelectedItem();
        if (item == null || item == table.getRoot()) {
            return rootFolder();
        }
        if (item instanceof DirectoryGroupItem group) {
            return group.folder();
        }
        DirectoryTreeItem folder = DirectoryTreeItem.parentFolder(item);
        return folder == null ? rootFolder() : folder.getValue();
    }

    // =====================================================================
    // Cut marker
    // =====================================================================

    /**
     * Dims one item as "cut, waiting for Paste" (or none).
     *
     * @param path the item, or null to clear
     */
    public static void markCut(Path path) {
        cutTarget = path;
        if (table != null) {
            table.refresh();
        }
    }

    /** @return the item dimmed as cut, or null */
    static Path cutTarget() {
        return cutTarget;
    }

    // =====================================================================
    // Queries
    // =====================================================================

    /**
     * The font the rows are drawn in, read from a live name cell, so it is
     * whatever the design stylesheet gives the tree (the breadcrumb font).
     *
     * @return the row font, or null before any row has been drawn
     */
    public static Font rowFont() {
        if (table == null) {
            return null;
        }
        for (Node node : table.lookupAll(".directory-name-cell")) {
            if (node instanceof DirectoryNameCell cell && cell.getFont() != null) {
                return cell.getFont();
            }
        }
        return null;
    }

    /** @return the folder the tree is showing (its root), or null */
    public static Path rootFolder() {
        if (table == null || table.getRoot() == null) {
            return null;
        }
        return table.getRoot().getValue();
    }

    /** @return the selected row's path, or null (none, or a group title) */
    public static Path selectedPath() {
        if (table == null) {
            return null;
        }
        TreeItem<Path> item = table.getSelectionModel().getSelectedItem();
        return item == null ? null : item.getValue();
    }

    /**
     * Selects the row of a path, opening its folders and group if needed and
     * scrolling it into view.
     *
     * @param path the item
     */
    public static void select(Path path) {
        if (table == null || path == null) {
            return;
        }
        revealItem(path);
        int row = rowOf(path);
        if (row < 0) {
            return;
        }
        table.getSelectionModel().clearAndSelect(row);
        if (!isRowVisible(row)) {
            table.scrollTo(row);
        }
    }

    /**
     * Expands every loaded folder and group on the way to a path, so its row
     * exists. Folders that were never opened are not read for this.
     */
    private static void revealItem(Path path) {
        TreeItem<Path> found = findItem(table.getRoot(), path);
        if (found == null) {
            return;
        }
        for (TreeItem<Path> parent = found.getParent(); parent != null; parent = parent.getParent()) {
            if (!parent.isExpanded()) {
                parent.setExpanded(true);
            }
        }
    }

    private static TreeItem<Path> findItem(TreeItem<Path> node, Path path) {
        if (node == null) {
            return null;
        }
        if (path.equals(node.getValue())) {
            return node;
        }
        boolean descend = node instanceof DirectoryGroupItem
                || (node.getValue() != null && path.startsWith(node.getValue())
                        && (!(node instanceof DirectoryTreeItem dir) || dir.isLoaded()));
        if (!descend) {
            return null;
        }
        for (TreeItem<Path> child : node.getChildren()) {
            TreeItem<Path> hit = findItem(child, path);
            if (hit != null) {
                return hit;
            }
        }
        return null;
    }

    // =====================================================================
    // Refresh, sort, group
    // =====================================================================

    /**
     * Re-reads every opened folder from disk (Refresh / F5, and after any
     * file operation), keeping opened folders open, the selection and the
     * scroll position.
     */
    public static void refresh() {
        if (table == null) {
            return;
        }
        if (!(table.getRoot() instanceof DirectoryTreeItem root)) {
            if (ideRef != null) {
                ProjectManager.refreshProjectTree(ideRef);
            }
            return;
        }
        preservingView(root::reload);
    }

    /**
     * Re-orders and re-groups every opened folder after a Sort by or Group by
     * change, without reading the disk.
     */
    public static void applyViewSettings() {
        if (table == null || !(table.getRoot() instanceof DirectoryTreeItem root)) {
            return;
        }
        preservingView(root::arrangeAll);
    }

    /** Runs a change to the tree's rows and puts the selection and scroll back. */
    private static void preservingView(Runnable change) {
        Path selected = selectedPath();
        int firstVisible = firstVisibleRow();

        change.run();

        if (selected != null) {
            int row = rowOf(selected);
            if (row >= 0) {
                table.getSelectionModel().clearAndSelect(row);
            } else {
                table.getSelectionModel().clearSelection();
            }
        }
        if (firstVisible >= 0) {
            table.scrollTo(Math.min(firstVisible, Math.max(0, table.getExpandedItemCount() - 1)));
        }
        table.refresh();
    }

    private static int firstVisibleRow() {
        VirtualFlow<?> flow = (VirtualFlow<?>) table.lookup(".virtual-flow");
        if (flow == null || flow.getFirstVisibleCell() == null) {
            return -1;
        }
        return flow.getFirstVisibleCell().getIndex();
    }

    /**
     * Redraws every visible row. Call after a theme switch, so rows drawn with
     * the previous icon set pick up the new one.
     *
     * @param ide the IDE controller
     */
    public static void refreshIcons(UI_Main ide) {
        if (ide != null && ide.projectTree != null) {
            ide.projectTree.refresh();
        }
    }
}
