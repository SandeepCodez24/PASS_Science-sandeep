package ui.directory;

import java.io.File;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Deque;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Stream;
import javafx.application.Platform;
import javafx.scene.control.Alert;
import javafx.scene.control.Tab;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import ui.UI_Main;
import ui.design.AstraFrame;
import ui.editor.EditorFileInfo;
import ui.editor.EditorFileStatus;
import ui.editor.EditorUIHelper;
import ui.managers.EditorManager;

/**
 * Everything the File Explorer's right-click menus and keyboard shortcuts do
 * to files: clipboard, paste, delete, new, rename, refresh, undo and redo.
 *
 * <p>
 * This was an inner part of {@code Main_Window}; it moved here when the menus
 * grew to two, so the window class only wires it up.
 * </p>
 *
 * <h3>Clipboard</h3>
 * <p>
 * Cut and Copy put the item on the <b>system</b> clipboard as a file, so it
 * can be pasted into Windows Explorer / Finder too, and Paste accepts files
 * copied there. A Cut is remembered by Astra: pasting it moves the item,
 * shows it dimmed until then, and empties the clipboard afterwards. A file
 * cut in Windows Explorer arrives as a copy, because the operating system's
 * cut marker is not visible to Java.
 * </p>
 *
 * <h3>Paste over a name already taken</h3>
 * <p>
 * Paste asks first, for each such item: <b>Replace</b>, <b>Keep a Copy</b> (the
 * default, as nothing is lost) or <b>Cancel</b>. Replace deletes the existing
 * item the way Delete does, so it goes to the bin and Undo brings it back.
 * Keep a Copy takes the free name from {@link #uniqueName}. This also covers
 * pasting a copied item into its own folder; a Cut pasted there still does
 * nothing, without asking.
 * </p>
 *
 * <h3>Delete</h3>
 * <p>
 * Delete asks first, then moves the item to the Recycle Bin (Trash on
 * macOS/Linux). To keep <b>Undo</b> working, a private copy is kept for the
 * session (in the temp folder, removed when Astra exits); Undo puts that copy
 * back. Items larger than {@link #UNDO_COPY_LIMIT} are not copied -- the
 * confirmation says so -- and are restored from the bin by hand. If the bin
 * is unavailable, the item is moved into the private store instead, so it is
 * never destroyed outright.
 * </p>
 *
 * <h3>Undo and Redo</h3>
 * <p>
 * Every change made from the explorer is recorded: rename, cut-paste (move),
 * copy-paste, delete and new. Undo and Redo walk that history. They act on
 * the file system only -- the editor's own undo is unrelated.
 * </p>
 *
 * <h3>Open editor tabs</h3>
 * <p>
 * Rename and move re-point open tabs at the new path
 * ({@link #updateOpenTabsForMovedPath}). Every change also re-checks the open
 * tabs against the disk ({@link EditorFileStatus#refresh}), so a tab whose
 * file was just deleted -- directly, or inside a deleted folder -- has its
 * title struck out, and Undo of that delete clears the strike again.
 * </p>
 */
public final class DirectoryFileOps implements DirectoryTreeContextMenu.Actions {

    /** Items above this size are deleted without an undo copy. */
    static final long UNDO_COPY_LIMIT = 256L * 1024 * 1024;

    // ---- the buttons of the paste question, left to right -------------------
    private static final int REPLACE = 0;
    private static final int KEEP_COPY = 1;
    private static final int CANCEL_PASTE = 2;

    private final UI_Main ide;
    private final History history = new History();
    private final BackupStore backups = new BackupStore();

    /** The item that was Cut and not yet pasted, or null. */
    private Path cutSource;

    /**
     * @param ide the IDE controller
     */
    public DirectoryFileOps(UI_Main ide) {
        this.ide = Objects.requireNonNull(ide);
    }

    // =====================================================================
    // Item actions
    // =====================================================================

    @Override
    public boolean canModify(Path item) {
        return item != null && Files.exists(item) && !item.equals(DirectoryTreeBuilder.rootFolder());
    }

    @Override
    public void cut(Path item) {
        if (!canModify(item)) {
            return;
        }
        putOnClipboard(item);
        cutSource = normal(item);
        DirectoryTreeBuilder.markCut(item);
    }

    @Override
    public void copy(Path item) {
        if (item == null || !Files.exists(item)) {
            return;
        }
        putOnClipboard(item);
        cutSource = null;
        DirectoryTreeBuilder.markCut(null);
    }

    @Override
    public void rename(Path item) {
        DirectoryTreeBuilder.beginRename(item);
    }

    @Override
    public void properties(Path item) {
        DirectoryShell.showProperties(item, ide.stage);
    }

    @Override
    public void delete(Path item) {
        if (!canModify(item)) {
            return;
        }
        boolean folder = Files.isDirectory(item);
        long size = sizeOf(item);
        boolean undoable = size <= UNDO_COPY_LIMIT;

        String kind = folder ? "folder" : "file";
        StringBuilder text = new StringBuilder(DirectoryRename.nameOf(item));
        if (!undoable) {
            text.append("\n\nThis item is too large for Undo. It can still be restored from the ")
                    .append(DirectoryShell.trashName()).append('.');
        }

        // An AstraFrame dialog rather than an Alert, as Reset CLI History is:
        // square, a hairline outline, the panels' title strip and the menus'
        // body colour. Enter confirms, Esc cancels.
        boolean confirmed = AstraFrame.confirm(
                ide.stage,
                folder ? "Delete Folder" : "Delete File",
                "Move this " + kind + " to the " + DirectoryShell.trashName() + "?",
                text.toString(),
                "Delete",
                "Cancel");
        if (!confirmed) {
            return;
        }

        // Copying and trashing can take a moment on a big folder; keep the
        // window responsive and finish on the FX thread.
        DirectoryShell.background(() -> {
            try {
                DeleteOp op = deleteNow(item, undoable);
                Platform.runLater(() -> {
                    if (op != null) {
                        history.record(op);
                    }
                    if (normal(item).equals(cutSource)) {
                        cutSource = null;
                        DirectoryTreeBuilder.markCut(null);
                    }
                    afterChange();
                });
            } catch (IOException | UncheckedIOException ex) {
                Platform.runLater(() -> {
                    showError("Delete failed", describe(ex));
                    afterChange();
                });
            }
        });
    }

    // =====================================================================
    // Folder / empty-space actions
    // =====================================================================

    @Override
    public boolean canPaste() {
        Clipboard clipboard = Clipboard.getSystemClipboard();
        if (!clipboard.hasFiles()) {
            return false;
        }
        for (File file : clipboard.getFiles()) {
            if (file.exists()) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void paste(Path folder) {
        if (folder == null || !Files.isDirectory(folder) || !canPaste()) {
            return;
        }
        List<File> files = Clipboard.getSystemClipboard().getFiles();
        boolean move = cutSource != null && files.size() == 1
                && normal(files.get(0).toPath()).equals(cutSource);

        List<FileOp> done = new ArrayList<>();
        Path last = null;
        List<String> problems = new ArrayList<>();
        boolean cancelled = false;
        for (File file : files) {
            Path source = file.toPath();
            if (!Files.exists(source)) {
                continue;
            }
            if (Files.isDirectory(source) && normal(folder).startsWith(normal(source))) {
                problems.add("'" + DirectoryRename.nameOf(source) + "' can't be pasted into itself.");
                continue;
            }
            Path wanted = folder.resolve(source.getFileName().toString());
            boolean onItself = normal(source).equals(normal(wanted));
            if (move && onItself) {
                continue; // cut and pasted in the same folder: nothing to do
            }

            int answer = Files.exists(wanted) ? askPasteConflict(wanted, onItself, move) : KEEP_COPY;
            if (answer == CANCEL_PASTE) {
                cancelled = true;
                break; // a paste of several items stops here; what is done stays done
            }
            if (answer == REPLACE && onItself) {
                continue; // replacing an item with itself leaves it as it is
            }
            if (answer == REPLACE && normal(source).startsWith(normal(wanted))) {
                problems.add("'" + DirectoryRename.nameOf(wanted) + "' can't be replaced by an item inside it.");
                continue;
            }
            try {
                if (answer == REPLACE) {
                    pasteReplacing(source, wanted, move, done);
                    last = wanted;
                } else {
                    Path target = uniqueName(wanted, !move);
                    done.add(pasteOne(source, target, move));
                    last = target;
                }
            } catch (IOException | UncheckedIOException ex) {
                problems.add(describe(ex));
            }
        }

        // A cancelled cut stays on the clipboard, to be pasted somewhere else.
        if (move && !cancelled) {
            cutSource = null;
            DirectoryTreeBuilder.markCut(null);
            Clipboard.getSystemClipboard().clear();
        }
        if (!done.isEmpty()) {
            history.record(done.size() == 1 ? done.get(0) : new CompoundOp(move ? "Move" : "Copy", done));
        }
        afterChange();
        if (last != null) {
            DirectoryTreeBuilder.select(last);
        }
        if (!problems.isEmpty()) {
            showError("Paste", String.join("\n", problems));
        }
    }

    /**
     * Asks what to do with a pasted item whose name is already taken.
     *
     * @param target   the item already there
     * @param onItself true when that item is the one being pasted
     * @param move     true for a Cut, false for a Copy
     * @return {@link #REPLACE}, {@link #KEEP_COPY} or {@link #CANCEL_PASTE}
     */
    private int askPasteConflict(Path target, boolean onItself, boolean move) {
        String kind = Files.isDirectory(target) ? "folder" : "file";
        String trash = DirectoryShell.trashName();

        StringBuilder text = new StringBuilder();
        if (onItself) {
            text.append("This is the same ").append(kind).append(", so Replace leaves it as it is.");
        } else {
            text.append("Replace moves the existing ").append(kind).append(" to the ").append(trash).append('.');
            if (sizeOf(target) > UNDO_COPY_LIMIT) {
                text.append(" It is too large for Undo, but can still be restored from the ")
                        .append(trash).append('.');
            }
        }
        text.append("\n\nKeep a Copy pastes it as '")
                .append(DirectoryRename.nameOf(uniqueName(target, !move))).append("'.");

        return AstraFrame.choose(
                ide.stage,
                "Paste",
                "A " + kind + " named '" + DirectoryRename.nameOf(target) + "' already exists in this folder.",
                text.toString(),
                KEEP_COPY,
                "Replace",
                "Keep a Copy",
                "Cancel");
    }

    /** Pastes one item at a free path and returns the step that undoes it. */
    private FileOp pasteOne(Path source, Path target, boolean move) throws IOException {
        if (move) {
            moveAny(source, target);
            updateOpenTabsForMovedPath(ide, source, target);
            return new MoveOp(source, target);
        }
        copyRecursive(source, target);
        return new CopyOp(target);
    }

    /**
     * Pastes one item over the item at {@code target}, which is deleted the
     * way Delete does it: an undo copy when allowed, then the bin. If the paste
     * then fails, the old item is put back.
     *
     * @param done receives the undo steps, in order
     */
    private void pasteReplacing(Path source, Path target, boolean move, List<FileOp> done) throws IOException {
        DeleteOp removed = deleteNow(target, sizeOf(target) <= UNDO_COPY_LIMIT);
        try {
            FileOp pasted = pasteOne(source, target, move);
            if (removed != null) {
                done.add(removed);
            }
            done.add(pasted);
        } catch (IOException | UncheckedIOException ex) {
            // A failed copy leaves a partial item, which is safe to remove. A
            // failed move may have emptied the source, so its target is kept.
            if (!move) {
                deleteRecursive(target);
            }
            if (removed != null && !Files.exists(target)) {
                removed.undo();
            }
            throw ex;
        }
        if (normal(target).equals(cutSource)) {
            cutSource = null;
            DirectoryTreeBuilder.markCut(null);
        }
    }

    @Override
    public void create(Path folder, NewItemKind kind) {
        if (folder == null || !Files.isDirectory(folder) || kind == null) {
            return;
        }
        Path target;
        try {
            if (kind.isFolder()) {
                target = uniqueName(folder.resolve(kind.baseName()), true);
                Files.createDirectory(target);
            } else {
                target = uniqueUntitled(folder, kind.baseName(), kind.extension());
                Files.writeString(target, kind.template(), StandardCharsets.UTF_8);
            }
        } catch (IOException ex) {
            showError("Could not create " + kind.label().toLowerCase(), describe(ex));
            return;
        }
        history.record(new CreateOp(target, kind.label()));
        afterChange();

        // Straight into rename, as in Windows; a file opens in the editor
        // under whatever name it ends up with.
        DirectoryTreeBuilder.beginRename(target, finalPath -> {
            if (!kind.isFolder() && finalPath != null && Files.isRegularFile(finalPath)) {
                EditorManager.openFileDirectly(ide, finalPath);
            }
        });
    }

    @Override
    public void refresh() {
        afterChange();
    }

    @Override
    public void openInFileManager(Path folder) {
        DirectoryShell.openInFileManager(folder, message -> showError(DirectoryShell.openInFileManagerLabel(), message));
    }

    @Override
    public void viewChanged() {
        DirectoryTreeBuilder.applyViewSettings();
    }

    // =====================================================================
    // Undo / Redo
    // =====================================================================

    @Override
    public String undoText() {
        FileOp op = history.peekUndo();
        return op == null ? null : "Undo " + op.label();
    }

    @Override
    public String redoText() {
        FileOp op = history.peekRedo();
        return op == null ? null : "Redo " + op.label();
    }

    @Override
    public void undo() {
        try {
            history.undo();
        } catch (IOException | UncheckedIOException ex) {
            showError("Undo failed", describe(ex));
        }
        afterChange();
    }

    @Override
    public void redo() {
        try {
            history.redo();
        } catch (IOException | UncheckedIOException ex) {
            showError("Redo failed", describe(ex));
        }
        afterChange();
    }

    // =====================================================================
    // Rename (the tree's DirectoryRename.Mover)
    // =====================================================================

    /**
     * The file-system side of an in-place rename, called by the tree once the
     * typed name has been validated.
     *
     * @param source the item
     * @param target its new path
     * @return the item's new path
     * @throws IOException if the file system refused
     */
    public Path renameInPlace(Path source, Path target) throws IOException {
        Path moved = DirectoryRename.move(source, target);
        history.record(new RenameOp(source, moved));
        updateOpenTabsForMovedPath(ide, source, moved);
        if (normal(source).equals(cutSource)) {
            cutSource = null;
            DirectoryTreeBuilder.markCut(null);
        }
        NcMetrics.invalidateAll();
        return moved;
    }

    // =====================================================================
    // Open editor tabs
    // =====================================================================

    /**
     * Points every open tab at an item's new location: the item itself and,
     * when a folder moved, every open file inside it. The tab title follows
     * the new file name and keeps its unsaved {@code *}.
     *
     * @param ide     the IDE controller
     * @param oldPath where the item was
     * @param newPath where it is now
     */
    public static void updateOpenTabsForMovedPath(UI_Main ide, Path oldPath, Path newPath) {
        if (ide == null || ide.editorTabs == null || oldPath == null || newPath == null) {
            return;
        }
        for (Tab tab : ide.editorTabs.getTabs()) {
            Object ud = tab.getUserData();
            if (!(ud instanceof EditorFileInfo info) || info.path == null || !info.path.startsWith(oldPath)) {
                continue;
            }
            Path updated = info.path.equals(oldPath)
                    ? newPath
                    : newPath.resolve(oldPath.relativize(info.path));
            info.path = updated;

            boolean dirty = tab.getText() != null && tab.getText().endsWith("*");
            String name = updated.getFileName().toString();
            tab.setText(dirty ? name + "*" : name);

            if (ide.editorTabs.getSelectionModel().getSelectedItem() == tab) {
                EditorUIHelper.updateFooter(ide, updated, name);
            }
        }
    }

    // =====================================================================
    // Internals
    // =====================================================================

    /**
     * Runs after every change: drops cached counts, re-reads the tree, and
     * strikes out (or restores) the title of any open tab whose file came or
     * went.
     */
    private void afterChange() {
        NcMetrics.invalidateAll();
        DirectoryTreeBuilder.refresh();
        EditorFileStatus.refresh(ide);
    }

    private void putOnClipboard(Path item) {
        ClipboardContent content = new ClipboardContent();
        content.putFiles(List.of(item.toFile()));
        content.putString(item.toAbsolutePath().toString());
        Clipboard.getSystemClipboard().setContent(content);
    }

    /**
     * Deletes an item for real: an undo copy (when allowed), then the bin.
     * Runs on the shell worker thread for a user delete, on the FX thread
     * for a Redo.
     *
     * @return the undo record, or null when the item was too large to copy
     */
    private DeleteOp deleteNow(Path item, boolean keepCopy) throws IOException {
        Path copy = keepCopy ? backups.copyOf(item) : null;
        if (DirectoryShell.moveToTrash(item)) {
            return copy == null ? null : new DeleteOp(item, copy);
        }
        // No bin available: park the item in the private store instead.
        if (copy != null) {
            deleteRecursive(item);
            return new DeleteOp(item, copy);
        }
        Path parked = backups.stash(item);
        return new DeleteOp(item, parked);
    }

    private void themed(Alert alert) {
        if (ide.stage != null) {
            alert.initOwner(ide.stage);
        }
        if (ide.scene != null) {
            alert.getDialogPane().getStylesheets().addAll(ide.scene.getStylesheets());
        }
    }

    private void showError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        themed(alert);
        alert.show();
    }

    private static String describe(Exception ex) {
        if (ex instanceof UncheckedIOException u && u.getCause() != null) {
            ex = u.getCause();
        }
        if (ex instanceof FileAlreadyExistsException f) {
            return "'" + f.getFile() + "' already exists.";
        }
        return DirectoryRename.describe(ex);
    }

    private static Path normal(Path path) {
        return path.toAbsolutePath().normalize();
    }

    /**
     * A free name next to {@code wanted}: {@code name - Copy.ext},
     * {@code name - Copy (2).ext} for a copy (Windows' own scheme), or
     * {@code name (2).ext} otherwise.
     *
     * <p>
     * A {@code .nc} file cannot take those names -- they contain spaces and
     * brackets, which the Neural Code naming rule ({@link NcFileNames}) does
     * not allow -- so it is named the MATLAB way instead:
     * {@code Copy_of_name.nc}, {@code Copy_2_of_name.nc} for a copy, and
     * {@code name_2.nc} otherwise.
     * </p>
     */
    static Path uniqueName(Path wanted, boolean copyStyle) {
        if (!Files.exists(wanted)) {
            return wanted;
        }
        String fileName = wanted.getFileName().toString();
        boolean folder = Files.isDirectory(wanted);
        int dot = folder ? -1 : fileName.lastIndexOf('.');
        String base = dot > 0 ? fileName.substring(0, dot) : fileName;
        String ext = dot > 0 ? fileName.substring(dot) : "";
        Path parent = wanted.getParent();
        if (!folder && NcFileNames.isNc(fileName)) {
            return uniqueNcName(parent, base, ext, copyStyle);
        }
        if (copyStyle) {
            Path first = parent.resolve(base + " - Copy" + ext);
            if (!Files.exists(first)) {
                return first;
            }
            for (int i = 2; ; i++) {
                Path next = parent.resolve(base + " - Copy (" + i + ")" + ext);
                if (!Files.exists(next)) {
                    return next;
                }
            }
        }
        for (int i = 2; ; i++) {
            Path next = parent.resolve(base + " (" + i + ")" + ext);
            if (!Files.exists(next)) {
                return next;
            }
        }
    }

    /**
     * MATLAB's naming for a .nc clash: {@code Copy_of_name.nc},
     * {@code Copy_2_of_name.nc}, ... for a copy; {@code name_2.nc},
     * {@code name_3.nc}, ... otherwise. Every candidate starts with a letter
     * and has no spaces, so it is a valid .nc name whenever {@code base} is.
     */
    private static Path uniqueNcName(Path parent, String base, String ext, boolean copyStyle) {
        if (copyStyle) {
            Path first = parent.resolve("Copy_of_" + base + ext);
            if (!Files.exists(first)) {
                return first;
            }
            for (int i = 2; ; i++) {
                Path next = parent.resolve("Copy_" + i + "_of_" + base + ext);
                if (!Files.exists(next)) {
                    return next;
                }
            }
        }
        for (int i = 2; ; i++) {
            Path next = parent.resolve(base + "_" + i + ext);
            if (!Files.exists(next)) {
                return next;
            }
        }
    }

    /**
     * {@code Untitled.nc}, {@code Untitled1.nc}, {@code Untitled2.nc}... --
     * the same numbering the Home ribbon's New uses for editor tabs.
     */
    static Path uniqueUntitled(Path folder, String base, String ext) {
        Path candidate = folder.resolve(base + ext);
        for (int i = 1; Files.exists(candidate); i++) {
            candidate = folder.resolve(base + i + ext);
        }
        return candidate;
    }

    static void moveAny(Path source, Path target) throws IOException {
        if (Files.exists(target)) {
            throw new FileAlreadyExistsException(target.toString());
        }
        try {
            Files.move(source, target);
        } catch (IOException direct) {
            // Across drives a folder cannot be moved in one step.
            if (!Files.isDirectory(source)) {
                throw direct;
            }
            copyRecursive(source, target);
            deleteRecursive(source);
        }
    }

    static void copyRecursive(Path source, Path target) throws IOException {
        if (Files.exists(target)) {
            throw new FileAlreadyExistsException(target.toString());
        }
        if (!Files.isDirectory(source)) {
            Files.copy(source, target, StandardCopyOption.COPY_ATTRIBUTES);
            return;
        }
        try (Stream<Path> stream = Files.walk(source)) {
            stream.forEach(path -> {
                try {
                    Path destination = target.resolve(source.relativize(path).toString());
                    if (Files.isDirectory(path)) {
                        Files.createDirectories(destination);
                    } else {
                        Files.copy(path, destination, StandardCopyOption.COPY_ATTRIBUTES);
                    }
                } catch (IOException e) {
                    throw new UncheckedIOException(e);
                }
            });
        }
    }

    static void deleteRecursive(Path path) throws IOException {
        if (!Files.exists(path)) {
            return;
        }
        if (Files.isDirectory(path)) {
            try (Stream<Path> stream = Files.walk(path)) {
                stream.sorted(Comparator.reverseOrder()).forEach(p -> {
                    try {
                        Files.deleteIfExists(p);
                    } catch (IOException e) {
                        throw new UncheckedIOException(e);
                    }
                });
            }
        } else {
            Files.deleteIfExists(path);
        }
    }

    private static long sizeOf(Path path) {
        if (!Files.isDirectory(path)) {
            try {
                return Files.size(path);
            } catch (IOException ex) {
                return 0;
            }
        }
        AtomicLong total = new AtomicLong();
        try {
            Files.walkFileTree(path, new SimpleFileVisitor<>() {
                @Override
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                    return total.addAndGet(attrs.size()) > UNDO_COPY_LIMIT
                            ? FileVisitResult.TERMINATE
                            : FileVisitResult.CONTINUE;
                }

                @Override
                public FileVisitResult visitFileFailed(Path file, IOException exc) {
                    return FileVisitResult.CONTINUE;
                }
            });
        } catch (IOException ignored) {
            // Whatever was counted decides.
        }
        return total.get();
    }

    // =====================================================================
    // History
    // =====================================================================

    /** One undoable step. */
    private interface FileOp {
        String label();

        void undo() throws IOException;

        void redo() throws IOException;
    }

    private static final class History {
        private static final int LIMIT = 100;
        private final Deque<FileOp> undo = new ArrayDeque<>();
        private final Deque<FileOp> redo = new ArrayDeque<>();

        void record(FileOp op) {
            undo.push(op);
            redo.clear();
            while (undo.size() > LIMIT) {
                undo.removeLast();
            }
        }

        FileOp peekUndo() {
            return undo.peek();
        }

        FileOp peekRedo() {
            return redo.peek();
        }

        void undo() throws IOException {
            FileOp op = undo.poll();
            if (op != null) {
                op.undo();
                redo.push(op);
            }
        }

        void redo() throws IOException {
            FileOp op = redo.poll();
            if (op != null) {
                op.redo();
                undo.push(op);
            }
        }
    }

    private final class RenameOp implements FileOp {
        private final Path source;
        private final Path target;

        RenameOp(Path source, Path target) {
            this.source = source;
            this.target = target;
        }

        @Override
        public String label() {
            return "Rename";
        }

        @Override
        public void undo() throws IOException {
            DirectoryRename.move(target, source);
            updateOpenTabsForMovedPath(ide, target, source);
        }

        @Override
        public void redo() throws IOException {
            DirectoryRename.move(source, target);
            updateOpenTabsForMovedPath(ide, source, target);
        }
    }

    private final class MoveOp implements FileOp {
        private final Path source;
        private final Path target;

        MoveOp(Path source, Path target) {
            this.source = source;
            this.target = target;
        }

        @Override
        public String label() {
            return "Move";
        }

        @Override
        public void undo() throws IOException {
            moveAny(target, source);
            updateOpenTabsForMovedPath(ide, target, source);
        }

        @Override
        public void redo() throws IOException {
            moveAny(source, target);
            updateOpenTabsForMovedPath(ide, source, target);
        }
    }

    /** A paste-as-copy: undo parks the copy, redo brings it back. */
    private final class CopyOp implements FileOp {
        private final Path target;
        private Path parked;

        CopyOp(Path target) {
            this.target = target;
        }

        @Override
        public String label() {
            return "Copy";
        }

        @Override
        public void undo() throws IOException {
            parked = backups.stash(target);
        }

        @Override
        public void redo() throws IOException {
            if (parked != null) {
                moveAny(parked, target);
                parked = null;
            }
        }
    }

    /** New Folder / New Script / ...: undo parks the item, redo restores it. */
    private final class CreateOp implements FileOp {
        private final Path target;
        private final String what;
        private Path parked;

        CreateOp(Path target, String what) {
            this.target = target;
            this.what = what;
        }

        @Override
        public String label() {
            return what;
        }

        @Override
        public void undo() throws IOException {
            parked = backups.stash(target);
        }

        @Override
        public void redo() throws IOException {
            if (parked != null) {
                moveAny(parked, target);
                parked = null;
            }
        }
    }

    /** A delete: undo restores the private copy; redo deletes again. */
    private final class DeleteOp implements FileOp {
        private final Path original;
        private Path copy;

        DeleteOp(Path original, Path copy) {
            this.original = original;
            this.copy = copy;
        }

        @Override
        public String label() {
            return "Delete";
        }

        @Override
        public void undo() throws IOException {
            if (copy == null) {
                throw new IOException("No copy was kept of '" + DirectoryRename.nameOf(original) + "'.");
            }
            moveAny(copy, original);
            copy = null;
        }

        @Override
        public void redo() throws IOException {
            DeleteOp again = deleteNow(original, true);
            copy = again == null ? null : again.copy;
        }
    }

    private static final class CompoundOp implements FileOp {
        private final String label;
        private final List<FileOp> steps;

        CompoundOp(String label, List<FileOp> steps) {
            this.label = label;
            this.steps = List.copyOf(steps);
        }

        @Override
        public String label() {
            return label;
        }

        @Override
        public void undo() throws IOException {
            for (int i = steps.size() - 1; i >= 0; i--) {
                steps.get(i).undo();
            }
        }

        @Override
        public void redo() throws IOException {
            for (FileOp step : steps) {
                step.redo();
            }
        }
    }

    // =====================================================================
    // Private store for undo copies
    // =====================================================================

    /**
     * A folder in the temp directory, one per session, holding the copies
     * that make Delete, Copy and New undoable. Emptied when Astra exits.
     */
    private static final class BackupStore {
        private Path root;

        private synchronized Path slot() throws IOException {
            if (root == null) {
                root = Files.createTempDirectory("astra-file-ops-");
                Path created = root;
                Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                    try {
                        deleteRecursive(created);
                    } catch (IOException | UncheckedIOException ignored) {
                        // Left for the OS temp cleaner.
                    }
                }, "astra-file-ops-cleanup"));
            }
            Path slot = root.resolve(Long.toString(System.nanoTime()));
            Files.createDirectories(slot);
            return slot;
        }

        /** Moves an item into the store. */
        Path stash(Path item) throws IOException {
            Path target = slot().resolve(item.getFileName().toString());
            moveAny(item, target);
            return target;
        }

        /** Copies an item into the store, leaving the original in place. */
        Path copyOf(Path item) throws IOException {
            Path target = slot().resolve(item.getFileName().toString());
            copyRecursive(item, target);
            return target;
        }
    }
}
