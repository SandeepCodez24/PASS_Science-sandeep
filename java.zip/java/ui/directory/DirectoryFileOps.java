package ui.directory;

import java.io.File;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Deque;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Stream;
import javafx.application.Platform;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Tab;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import ui.UI_Main;
import ui.editor.EditorFileInfo;
import ui.editor.EditorUIHelper;
import ui.managers.EditorManager;

/**
 * Everything the File Explorer's right-click menus and keyboard shortcuts do
 * to files: clipboard, paste, delete, new, rename, refresh, undo and redo.
 *
 * <p>
 * This was an inner part of {@code Main_Window}; it moved here when the menus
 * grew to two, so the window class only wires it up.
 * </p>
 *
 * <h3>Clipboard</h3>
 * <p>
 * Cut and Copy put the item on the <b>system</b> clipboard as a file, so it
 * can be pasted into Windows Explorer / Finder too, and Paste accepts files
 * copied there. A Cut is remembered by Astra: pasting it moves the item,
 * shows it dimmed until then, and empties the clipboard afterwards. A file
 * cut in Windows Explorer arrives as a copy, because the operating system's
 * cut marker is not visible to Java.
 * </p>
 *
 * <h3>Delete</h3>
 * <p>
 * Delete asks first, then moves the item to the Recycle Bin (Trash on
 * macOS/Linux). To keep <b>Undo</b> working, a private copy is kept for the
 * session (in the temp folder, removed when Astra exits); Undo puts that copy
 * back. Items larger than {@link #UNDO_COPY_LIMIT} are not copied -- the
 * confirmation says so -- and are restored from the bin by hand. If the bin
 * is unavailable, the item is moved into the private store instead, so it is
 * never destroyed outright.
 * </p>
 *
 * <h3>Undo and Redo</h3>
 * <p>
 * Every change made from the explorer is recorded: rename, cut-paste (move),
 * copy-paste, delete and new. Undo and Redo walk that history. They act on
 * the file system only -- the editor's own undo is unrelated.
 * </p>
 */
public final class DirectoryFileOps implements DirectoryTreeContextMenu.Actions {

    /** Items above this size are deleted without an undo copy. */
    static final long UNDO_COPY_LIMIT = 256L * 1024 * 1024;

    private final UI_Main ide;
    private final History history = new History();
    private final BackupStore backups = new BackupStore();

    /** The item that was Cut and not yet pasted, or null. */
    private Path cutSource;

    /**
     * @param ide the IDE controller
     */
    public DirectoryFileOps(UI_Main ide) {
        this.ide = Objects.requireNonNull(ide);
    }

    // =====================================================================
    // Item actions
    // =====================================================================

    @Override
    public boolean canModify(Path item) {
        return item != null && Files.exists(item) && !item.equals(DirectoryTreeBuilder.rootFolder());
    }

    @Override
    public void cut(Path item) {
        if (!canModify(item)) {
            return;
        }
        putOnClipboard(item);
        cutSource = normal(item);
        DirectoryTreeBuilder.markCut(item);
    }

    @Override
    public void copy(Path item) {
        if (item == null || !Files.exists(item)) {
            return;
        }
        putOnClipboard(item);
        cutSource = null;
        DirectoryTreeBuilder.markCut(null);
    }

    @Override
    public void rename(Path item) {
        DirectoryTreeBuilder.beginRename(item);
    }

    @Override
    public void properties(Path item) {
        DirectoryShell.showProperties(item, ide.stage);
    }

    @Override
    public void delete(Path item) {
        if (!canModify(item)) {
            return;
        }
        boolean folder = Files.isDirectory(item);
        long size = sizeOf(item);
        boolean undoable = size <= UNDO_COPY_LIMIT;

        String kind = folder ? "folder" : "file";
        StringBuilder text = new StringBuilder()
                .append("Are you sure you want to move this ").append(kind)
                .append(" to the ").append(DirectoryShell.trashName()).append("?\n\n")
                .append(DirectoryRename.nameOf(item));
        if (!undoable) {
            text.append("\n\nThis item is too large for Undo. It can still be restored from the ")
                    .append(DirectoryShell.trashName()).append('.');
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION, text.toString(), ButtonType.YES, ButtonType.NO);
        confirm.setTitle(folder ? "Delete Folder" : "Delete File");
        confirm.setHeaderText(null);
        themed(confirm);
        if (confirm.showAndWait().filter(b -> b == ButtonType.YES).isEmpty()) {
            return;
        }

        // Copying and trashing can take a moment on a big folder; keep the
        // window responsive and finish on the FX thread.
        DirectoryShell.background(() -> {
            try {
                DeleteOp op = deleteNow(item, undoable);
                Platform.runLater(() -> {
                    if (op != null) {
                        history.record(op);
                    }
                    if (normal(item).equals(cutSource)) {
                        cutSource = null;
                        DirectoryTreeBuilder.markCut(null);
                    }
                    afterChange();
                });
            } catch (IOException | UncheckedIOException ex) {
                Platform.runLater(() -> {
                    showError("Delete failed", describe(ex));
                    afterChange();
                });
            }
        });
    }

    // =====================================================================
    // Folder / empty-space actions
    // =====================================================================

    @Override
    public boolean canPaste() {
        Clipboard clipboard = Clipboard.getSystemClipboard();
        if (!clipboard.hasFiles()) {
            return false;
        }
        for (File file : clipboard.getFiles()) {
            if (file.exists()) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void paste(Path folder) {
        if (folder == null || !Files.isDirectory(folder) || !canPaste()) {
            return;
        }
        List<File> files = Clipboard.getSystemClipboard().getFiles();
        boolean move = cutSource != null && files.size() == 1
                && normal(files.get(0).toPath()).equals(cutSource);

        List<FileOp> done = new ArrayList<>();
        Path last = null;
        List<String> problems = new ArrayList<>();
        for (File file : files) {
            Path source = file.toPath();
            if (!Files.exists(source)) {
                continue;
            }
            if (Files.isDirectory(source) && normal(folder).startsWith(normal(source))) {
                problems.add("'" + DirectoryRename.nameOf(source) + "' can't be pasted into itself.");
                continue;
            }
            try {
                if (move) {
                    if (source.getParent() != null && normal(source.getParent()).equals(normal(folder))) {
                        continue; // cut and pasted in the same folder: nothing to do
                    }
                    Path target = uniqueName(folder.resolve(source.getFileName().toString()), false);
                    moveAny(source, target);
                    updateOpenTabsForMovedPath(ide, source, target);
                    done.add(new MoveOp(source, target));
                    last = target;
                } else {
                    Path target = uniqueName(folder.resolve(source.getFileName().toString()), true);
                    copyRecursive(source, target);
                    done.add(new CopyOp(target));
                    last = target;
                }
            } catch (IOException | UncheckedIOException ex) {
                problems.add(describe(ex));
            }
        }

        if (move) {
            cutSource = null;
            DirectoryTreeBuilder.markCut(null);
            Clipboard.getSystemClipboard().clear();
        }
        if (!done.isEmpty()) {
            history.record(done.size() == 1 ? done.get(0) : new CompoundOp(move ? "Move" : "Copy", done));
        }
        afterChange();
        if (last != null) {
            DirectoryTreeBuilder.select(last);
        }
        if (!problems.isEmpty()) {
            showError("Paste", String.join("\n", problems));
        }
    }

    @Override
    public void create(Path folder, NewItemKind kind) {
        if (folder == null || !Files.isDirectory(folder) || kind == null) {
            return;
        }
        Path target;
        try {
            if (kind.isFolder()) {
                target = uniqueName(folder.resolve(kind.baseName()), true);
                Files.createDirectory(target);
            } else {
                target = uniqueUntitled(folder, kind.baseName(), kind.extension());
                Files.writeString(target, kind.template(), StandardCharsets.UTF_8);
            }
        } catch (IOException ex) {
            showError("Could not create " + kind.label().toLowerCase(), describe(ex));
            return;
        }
        history.record(new CreateOp(target, kind.label()));
        afterChange();

        // Straight into rename, as in Windows; a file opens in the editor
        // under whatever name it ends up with.
        DirectoryTreeBuilder.beginRename(target, finalPath -> {
            if (!kind.isFolder() && finalPath != null && Files.isRegularFile(finalPath)) {
                EditorManager.openFileDirectly(ide, finalPath);
            }
        });
    }

    @Override
    public void refresh() {
        afterChange();
    }

    @Override
    public void openInFileManager(Path folder) {
        DirectoryShell.openInFileManager(folder, message -> showError(DirectoryShell.openInFileManagerLabel(), message));
    }

    @Override
    public void viewChanged() {
        DirectoryTreeBuilder.applyViewSettings();
    }

    // =====================================================================
    // Undo / Redo
    // =====================================================================

    @Override
    public String undoText() {
        FileOp op = history.peekUndo();
        return op == null ? null : "Undo " + op.label();
    }

    @Override
    public String redoText() {
        FileOp op = history.peekRedo();
        return op == null ? null : "Redo " + op.label();
    }

    @Override
    public void undo() {
        try {
            history.undo();
        } catch (IOException | UncheckedIOException ex) {
            showError("Undo failed", describe(ex));
        }
        afterChange();
    }

    @Override
    public void redo() {
        try {
            history.redo();
        } catch (IOException | UncheckedIOException ex) {
            showError("Redo failed", describe(ex));
        }
        afterChange();
    }

    // =====================================================================
    // Rename (the tree's DirectoryRename.Mover)
    // =====================================================================

    /**
     * The file-system side of an in-place rename, called by the tree once the
     * typed name has been validated.
     *
     * @param source the item
     * @param target its new path
     * @return the item's new path
     * @throws IOException if the file system refused
     */
    public Path renameInPlace(Path source, Path target) throws IOException {
        Path moved = DirectoryRename.move(source, target);
        history.record(new RenameOp(source, moved));
        updateOpenTabsForMovedPath(ide, source, moved);
        if (normal(source).equals(cutSource)) {
            cutSource = null;
            DirectoryTreeBuilder.markCut(null);
        }
        NcMetrics.invalidateAll();
        return moved;
    }

    // =====================================================================
    // Open editor tabs
    // =====================================================================

    /**
     * Points every open tab at an item's new location: the item itself and,
     * when a folder moved, every open file inside it. The tab title follows
     * the new file name and keeps its unsaved {@code *}.
     *
     * @param ide     the IDE controller
     * @param oldPath where the item was
     * @param newPath where it is now
     */
    public static void updateOpenTabsForMovedPath(UI_Main ide, Path oldPath, Path newPath) {
        if (ide == null || ide.editorTabs == null || oldPath == null || newPath == null) {
            return;
        }
        for (Tab tab : ide.editorTabs.getTabs()) {
            Object ud = tab.getUserData();
            if (!(ud instanceof EditorFileInfo info) || info.path == null || !info.path.startsWith(oldPath)) {
                continue;
            }
            Path updated = info.path.equals(oldPath)
                    ? newPath
                    : newPath.resolve(oldPath.relativize(info.path));
            info.path = updated;

            boolean dirty = tab.getText() != null && tab.getText().endsWith("*");
            String name = updated.getFileName().toString();
            tab.setText(dirty ? name + "*" : name);

            if (ide.editorTabs.getSelectionModel().getSelectedItem() == tab) {
                EditorUIHelper.updateFooter(ide, updated, name);
            }
        }
    }

    // =====================================================================
    // Internals
    // =====================================================================

    private void afterChange() {
        NcMetrics.invalidateAll();
        DirectoryTreeBuilder.refresh();
    }

    private void putOnClipboard(Path item) {
        ClipboardContent content = new ClipboardContent();
        content.putFiles(List.of(item.toFile()));
        content.putString(item.toAbsolutePath().toString());
        Clipboard.getSystemClipboard().setContent(content);
    }

    /**
     * Deletes an item for real: an undo copy (when allowed), then the bin.
     * Runs on the shell worker thread for a user delete, on the FX thread
     * for a Redo.
     *
     * @return the undo record, or null when the item was too large to copy
     */
    private DeleteOp deleteNow(Path item, boolean keepCopy) throws IOException {
        Path copy = keepCopy ? backups.copyOf(item) : null;
        if (DirectoryShell.moveToTrash(item)) {
            return copy == null ? null : new DeleteOp(item, copy);
        }
        // No bin available: park the item in the private store instead.
        if (copy != null) {
            deleteRecursive(item);
            return new DeleteOp(item, copy);
        }
        Path parked = backups.stash(item);
        return new DeleteOp(item, parked);
    }

    private void themed(Alert alert) {
        if (ide.stage != null) {
            alert.initOwner(ide.stage);
        }
        if (ide.scene != null) {
            alert.getDialogPane().getStylesheets().addAll(ide.scene.getStylesheets());
        }
    }

    private void showError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        themed(alert);
        alert.show();
    }

    private static String describe(Exception ex) {
        if (ex instanceof UncheckedIOException u && u.getCause() != null) {
            ex = u.getCause();
        }
        if (ex instanceof FileAlreadyExistsException f) {
            return "'" + f.getFile() + "' already exists.";
        }
        return DirectoryRename.describe(ex);
    }

    private static Path normal(Path path) {
        return path.toAbsolutePath().normalize();
    }

    /**
     * A free name next to {@code wanted}: {@code name - Copy.ext},
     * {@code name - Copy (2).ext} for a copy (Windows' own scheme), or
     * {@code name (2).ext} otherwise.
     */
    static Path uniqueName(Path wanted, boolean copyStyle) {
        if (!Files.exists(wanted)) {
            return wanted;
        }
        String fileName = wanted.getFileName().toString();
        boolean folder = Files.isDirectory(wanted);
        int dot = folder ? -1 : fileName.lastIndexOf('.');
        String base = dot > 0 ? fileName.substring(0, dot) : fileName;
        String ext = dot > 0 ? fileName.substring(dot) : "";
        Path parent = wanted.getParent();
        if (copyStyle) {
            Path first = parent.resolve(base + " - Copy" + ext);
            if (!Files.exists(first)) {
                return first;
            }
            for (int i = 2; ; i++) {
                Path next = parent.resolve(base + " - Copy (" + i + ")" + ext);
                if (!Files.exists(next)) {
                    return next;
                }
            }
        }
        for (int i = 2; ; i++) {
            Path next = parent.resolve(base + " (" + i + ")" + ext);
            if (!Files.exists(next)) {
                return next;
            }
        }
    }

    /**
     * {@code Untitled.nc}, {@code Untitled1.nc}, {@code Untitled2.nc}... --
     * the same numbering the Home ribbon's New uses for editor tabs.
     */
    static Path uniqueUntitled(Path folder, String base, String ext) {
        Path candidate = folder.resolve(base + ext);
        for (int i = 1; Files.exists(candidate); i++) {
            candidate = folder.resolve(base + i + ext);
        }
        return candidate;
    }

    static void moveAny(Path source, Path target) throws IOException {
        if (Files.exists(target)) {
            throw new FileAlreadyExistsException(target.toString());
        }
        try {
            Files.move(source, target);
        } catch (IOException direct) {
            // Across drives a folder cannot be moved in one step.
            if (!Files.isDirectory(source)) {
                throw direct;
            }
            copyRecursive(source, target);
            deleteRecursive(source);
        }
    }

    static void copyRecursive(Path source, Path target) throws IOException {
        if (Files.exists(target)) {
            throw new FileAlreadyExistsException(target.toString());
        }
        if (!Files.isDirectory(source)) {
            Files.copy(source, target, StandardCopyOption.COPY_ATTRIBUTES);
            return;
        }
        try (Stream<Path> stream = Files.walk(source)) {
            stream.forEach(path -> {
                try {
                    Path destination = target.resolve(source.relativize(path).toString());
                    if (Files.isDirectory(path)) {
                        Files.createDirectories(destination);
                    } else {
                        Files.copy(path, destination, StandardCopyOption.COPY_ATTRIBUTES);
                    }
                } catch (IOException e) {
                    throw new UncheckedIOException(e);
                }
            });
        }
    }

    static void deleteRecursive(Path path) throws IOException {
        if (!Files.exists(path)) {
            return;
        }
        if (Files.isDirectory(path)) {
            try (Stream<Path> stream = Files.walk(path)) {
                stream.sorted(Comparator.reverseOrder()).forEach(p -> {
                    try {
                        Files.deleteIfExists(p);
                    } catch (IOException e) {
                        throw new UncheckedIOException(e);
                    }
                });
            }
        } else {
            Files.deleteIfExists(path);
        }
    }

    private static long sizeOf(Path path) {
        if (!Files.isDirectory(path)) {
            try {
                return Files.size(path);
            } catch (IOException ex) {
                return 0;
            }
        }
        AtomicLong total = new AtomicLong();
        try {
            Files.walkFileTree(path, new SimpleFileVisitor<>() {
                @Override
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                    return total.addAndGet(attrs.size()) > UNDO_COPY_LIMIT
                            ? FileVisitResult.TERMINATE
                            : FileVisitResult.CONTINUE;
                }

                @Override
                public FileVisitResult visitFileFailed(Path file, IOException exc) {
                    return FileVisitResult.CONTINUE;
                }
            });
        } catch (IOException ignored) {
            // Whatever was counted decides.
        }
        return total.get();
    }

    // =====================================================================
    // History
    // =====================================================================

    /** One undoable step. */
    private interface FileOp {
        String label();

        void undo() throws IOException;

        void redo() throws IOException;
    }

    private static final class History {
        private static final int LIMIT = 100;
        private final Deque<FileOp> undo = new ArrayDeque<>();
        private final Deque<FileOp> redo = new ArrayDeque<>();

        void record(FileOp op) {
            undo.push(op);
            redo.clear();
            while (undo.size() > LIMIT) {
                undo.removeLast();
            }
        }

        FileOp peekUndo() {
            return undo.peek();
        }

        FileOp peekRedo() {
            return redo.peek();
        }

        void undo() throws IOException {
            FileOp op = undo.poll();
            if (op != null) {
                op.undo();
                redo.push(op);
            }
        }

        void redo() throws IOException {
            FileOp op = redo.poll();
            if (op != null) {
                op.redo();
                undo.push(op);
            }
        }
    }

    private final class RenameOp implements FileOp {
        private final Path source;
        private final Path target;

        RenameOp(Path source, Path target) {
            this.source = source;
            this.target = target;
        }

        @Override
        public String label() {
            return "Rename";
        }

        @Override
        public void undo() throws IOException {
            DirectoryRename.move(target, source);
            updateOpenTabsForMovedPath(ide, target, source);
        }

        @Override
        public void redo() throws IOException {
            DirectoryRename.move(source, target);
            updateOpenTabsForMovedPath(ide, source, target);
        }
    }

    private final class MoveOp implements FileOp {
        private final Path source;
        private final Path target;

        MoveOp(Path source, Path target) {
            this.source = source;
            this.target = target;
        }

        @Override
        public String label() {
            return "Move";
        }

        @Override
        public void undo() throws IOException {
            moveAny(target, source);
            updateOpenTabsForMovedPath(ide, target, source);
        }

        @Override
        public void redo() throws IOException {
            moveAny(source, target);
            updateOpenTabsForMovedPath(ide, source, target);
        }
    }

    /** A paste-as-copy: undo parks the copy, redo brings it back. */
    private final class CopyOp implements FileOp {
        private final Path target;
        private Path parked;

        CopyOp(Path target) {
            this.target = target;
        }

        @Override
        public String label() {
            return "Copy";
        }

        @Override
        public void undo() throws IOException {
            parked = backups.stash(target);
        }

        @Override
        public void redo() throws IOException {
            if (parked != null) {
                moveAny(parked, target);
                parked = null;
            }
        }
    }

    /** New Folder / New Script / ...: undo parks the item, redo restores it. */
    private final class CreateOp implements FileOp {
        private Path target;
        private final String what;
        private Path parked;

        CreateOp(Path target, String what) {
            this.target = target;
            this.what = what;
        }

        @Override
        public String label() {
            return what;
        }

        @Override
        public void undo() throws IOException {
            parked = backups.stash(target);
        }

        @Override
        public void redo() throws IOException {
            if (parked != null) {
                moveAny(parked, target);
                parked = null;
            }
        }
    }

    /** A delete: undo restores the private copy; redo deletes again. */
    private final class DeleteOp implements FileOp {
        private final Path original;
        private Path copy;

        DeleteOp(Path original, Path copy) {
            this.original = original;
            this.copy = copy;
        }

        @Override
        public String label() {
            return "Delete";
        }

        @Override
        public void undo() throws IOException {
            if (copy == null) {
                throw new IOException("No copy was kept of '" + DirectoryRename.nameOf(original) + "'.");
            }
            moveAny(copy, original);
            copy = null;
        }

        @Override
        public void redo() throws IOException {
            DeleteOp again = deleteNow(original, true);
            copy = again == null ? null : again.copy;
        }
    }

    private static final class CompoundOp implements FileOp {
        private final String label;
        private final List<FileOp> steps;

        CompoundOp(String label, List<FileOp> steps) {
            this.label = label;
            this.steps = List.copyOf(steps);
        }

        @Override
        public String label() {
            return label;
        }

        @Override
        public void undo() throws IOException {
            for (int i = steps.size() - 1; i >= 0; i--) {
                steps.get(i).undo();
            }
        }

        @Override
        public void redo() throws IOException {
            for (FileOp step : steps) {
                step.redo();
            }
        }
    }

    // =====================================================================
    // Private store for undo copies
    // =====================================================================

    /**
     * A folder in the temp directory, one per session, holding the copies
     * that make Delete, Copy and New undoable. Emptied when Astra exits.
     */
    private static final class BackupStore {
        private Path root;

        private synchronized Path slot() throws IOException {
            if (root == null) {
                root = Files.createTempDirectory("astra-file-ops-");
                Path created = root;
                Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                    try {
                        deleteRecursive(created);
                    } catch (IOException | UncheckedIOException ignored) {
                        // Left for the OS temp cleaner.
                    }
                }, "astra-file-ops-cleanup"));
            }
            Path slot = root.resolve(Long.toString(System.nanoTime()));
            Files.createDirectories(slot);
            return slot;
        }

        /** Moves an item into the store. */
        Path stash(Path item) throws IOException {
            Path target = slot().resolve(item.getFileName().toString());
            moveAny(item, target);
            return target;
        }

        /** Copies an item into the store, leaving the original in place. */
        Path copyOf(Path item) throws IOException {
            Path target = slot().resolve(item.getFileName().toString());
            copyRecursive(item, target);
            return target;
        }
    }
}
