package ui.ribbon_interface.tool_bar;

import java.io.File;
import java.util.List;

import javafx.application.Platform;
import javafx.scene.control.ToolBar;
import javafx.scene.image.ImageView;
import multiphysics.UI_MP_Main;
import plot.PlotWindow;
import ui.UI_Main;
import ui.design.Dim;
import ui.editor.homeTab.Export.UI_Home_Export_Main;
import ui.editor.homeTab.Import.UI_Home_Import_Main;
import ui.editor.homeTab.Process.UI_Home_Process_Main;
import ui.editor.homeTab.StepFileRunner;
import ui.explorer.NeuralLinkWindow;
import ui.managers.EditorManager;
import ui.managers.TerminalManager;
import ui.ribbon_interface.tool_groups.RibbonAnalysis;
import ui.ribbon_interface.tool_groups.RibbonGroup;
import ui.ribbon_interface.tool_groups.RibbonItems;
import ui.ribbon_interface.tool_groups.RibbonSplitButton;
import ui.ui_functions.tools.HomeRibbonIcons;

/**
 * Builds the Home tab's ribbon band.
 *
 * <p>
 * Eight compartments span the ribbon width in the ratio 2:2:1:1:1:2:2:1 out
 * of 16 units, divided by mild vertical rules, with the remaining 4 units left
 * free at the right-hand edge. A compartment is never narrower than its
 * labels need; see {@link RibbonBand}.
 * </p>
 *
 * <pre>
 *   Files      New / Open / Save              (split buttons)
 *   Data       Import / Process / Export      (wired)
 *   Visualisation  Plot                       (wired)
 *   Modelling  Multi Physics                  (stub)
 *   Graphical  Neural Link                    (wired)
 *   Compute    Step / Run / Stop              (Step is a stub)
 *   Analysis   No. of Computation, Execution Time  (readouts)
 *   AI Help    Code Bot                       (stub)
 * </pre>
 */
public final class HomeRibbon {

    // =====================================================================
    // Home-ribbon icon assets -- light and dark, all under /icons/home_icons
    // =====================================================================
    // Every ribbon icon now lives inside a single folder:
    //     src/main/resources/icons/home_icons
    // The light asset is the plain base name; the dark asset is the same
    // base name with a "_dark" suffix. Both carry the .png extension.
    //
    // Constants below hold BASE NAMES ONLY (no folder, no "_dark", no
    // extension). They are handed to HomeRibbonIcons, which appends the
    // suffix for the active theme and re-points every icon in place when the
    // theme is toggled -- exactly as HomeFilesIcons does for New/Open/Save.
    private static final String IC_RUN           = "ic_04_run";
    private static final String IC_STOP          = "ic_07_stop";        // was ic_07_exit
    private static final String IC_PLOT          = "ic_27_newplot";
    private static final String IC_NEURAL_LINK   = "ic_26_neural_link";

    private static final String IC_IMPORT_DATA   = "ic_h_01_import_data";
    private static final String IC_PROCESS_DATA  = "ic_h_02_process_data";
    private static final String IC_EXPORT_DATA   = "ic_h_03_export_data";
    private static final String IC_MULTI_PHYSICS = "ic_h_04_multi_physics";
    private static final String IC_STEP          = "ic_h_05_step";
    private static final String IC_CODE_BOT      = "ic_h_06_code_bot";

    // --- Files compartment assets (unchanged) -----------------------------
    // Base names only: HomeFilesIcons appends the theme folder and the
    // extension, so the same constant serves the light and dark sets.
    private static final String IC_F_NEW = "new";
    private static final String IC_F_NEW_SCRIPT = "new_script";
    private static final String IC_F_NEW_FUNCTION = "new_function";
    private static final String IC_F_NEW_CLASS = "new_class";
    private static final String IC_F_NEW_TXT = "new_txt";

    private static final String IC_F_OPEN = "open";
    private static final String IC_F_OPEN_FILE = "open_file";
    private static final String IC_F_OPEN_LAST = "open_last_project";
    private static final String IC_F_OPEN_ROOT = "open_root_folder";

    private static final String IC_F_SAVE = "save";
    private static final String IC_F_SAVE_AS = "save_as";
    private static final String IC_F_SAVE_ROOT = "save_root";
    private static final String IC_F_SAVE_IN = "save_in";

    private HomeRibbon() {
    }

    /**
     * Builds a live-themed graphic for a Home-ribbon icon at the ribbon's
     * standard icon size. The returned view re-points itself between the light
     * and {@code _dark} art whenever the theme is toggled.
     *
     * @param base the icon base name, e.g. {@code "ic_04_run"}
     * @return the configured, theme-aware icon view
     */
    private static ImageView ic(String base) {
        return HomeRibbonIcons.icon(base, Dim.ToolBand.ICON_SIZE);
    }

    /**
     * Builds the Home band.
     *
     * <p>
     * The compartments are handed to a {@link RibbonBand}, which gives each
     * one {@code max(units x unit, natural width)} and collapses them right
     * to left into drop-down buttons when the window is too narrow -- so no
     * label is ever cut to "...". The unit ratios in
     * {@code Dim.ToolBand.Home} still set the look on a wide window.
     * </p>
     *
     * @param ide the IDE controller
     * @return the Home ToolBar, ready to drop into the toolbar StackPane
     */
    public static ToolBar build(UI_Main ide) {
        List<RibbonGroup> groups = List.of(
                filesGroup(ide),
                dataGroup(ide),
                visualisationGroup(ide),
                modellingGroup(ide),
                graphicalGroup(ide),
                computeGroup(ide),
                analysisGroup(),
                aiHelpGroup(ide));

        RibbonBand band = new RibbonBand(Dim.ToolBand.Home.TOTAL_UNITS,
                "home-ribbon-root", "home-ribbon-toolbar");
        band.addGroups(groups);

        // RibbonBar, not ToolBar: the stock ToolBarSkin's snapped fit test
        // sends the whole band into the ">>" overflow popup on displays that
        // are not at 100% scaling. See RibbonBar.
        RibbonBar bar = new RibbonBar(band, "menu-toolbar", "home-ribbon-toolbar");
        bar.setPrefHeight(Dim.ToolBand.ROW_HEIGHT);
        bar.setMinHeight(Dim.ToolBand.ROW_HEIGHT);
        return bar;
    }

    // =====================================================================
    // 1. Files -- 2 units -- three split buttons
    // =====================================================================
    // Each control is one rounded rectangle: the icon runs the default
    // action, the triangle strip beneath the label opens the drop-down.
    // See RibbonSplitButton for the two-zone hover behaviour.
    private static RibbonGroup filesGroup(UI_Main ide) {
        RibbonSplitButton newBtn = RibbonItems.split(
                "New", IC_F_NEW, "New Neural Code script (.nc)",
                () -> EditorManager.newNeuralCodeFile(ide),
                RibbonItems.menuItem("Script", IC_F_NEW_SCRIPT,
                        () -> EditorManager.newNeuralCodeFile(ide)),
                RibbonItems.menuItem("Function", IC_F_NEW_FUNCTION,
                        () -> EditorManager.newFunctionFile(ide)),
                RibbonItems.menuItem("Class", IC_F_NEW_CLASS,
                        () -> EditorManager.newClassFile(ide)),
                RibbonItems.menuItem("Plain Text", IC_F_NEW_TXT,
                        () -> EditorManager.newPlainTextFile(ide)));

        RibbonSplitButton openBtn = RibbonItems.split(
                "Open", IC_F_OPEN, "Open a Neural Code file (.nc)",
                () -> EditorManager.openNcFile(ide),
                RibbonItems.menuItem("Open File", IC_F_OPEN_FILE,
                        () -> EditorManager.openFile(ide)),
                RibbonItems.menuItem("Open Folder", IC_F_OPEN,
                        () -> EditorManager.openProjectFolder(ide)),
                RibbonItems.menuItem("Open Last Project", IC_F_OPEN_LAST,
                        () -> EditorManager.openLastProject(ide)),
                RibbonItems.menuItem("Open Root Folder", IC_F_OPEN_ROOT,
                        () -> EditorManager.openRootFolder(ide)));

        RibbonSplitButton saveBtn = RibbonItems.split(
                "Save", IC_F_SAVE, "Save the current file",
                () -> EditorManager.saveCurrentFile(ide),
                RibbonItems.menuItem("Save", IC_F_SAVE,
                        () -> EditorManager.saveCurrentFile(ide)),
                RibbonItems.menuItem("Save As", IC_F_SAVE_AS,
                        () -> EditorManager.saveAsFile(ide)),
                RibbonItems.menuItem("Save Root", IC_F_SAVE_ROOT,
                        () -> EditorManager.saveToProjectRoot(ide)),
                RibbonItems.menuItem("Save In", IC_F_SAVE_IN,
                        () -> EditorManager.saveInFolder(ide)));

        // Extra drop-down width on top of what the entries need at the regular
        // menu font. The factors live in HomeBand_dim.
        newBtn.withMenuWidthScale(Dim.ToolBand.Home.MENU_WIDTH_SCALE_NEW);
        openBtn.withMenuWidthScale(Dim.ToolBand.Home.MENU_WIDTH_SCALE_OPEN);
        saveBtn.withMenuWidthScale(Dim.ToolBand.Home.MENU_WIDTH_SCALE_SAVE);

        return new RibbonGroup("Files", Dim.ToolBand.Home.UNITS_FILES).withItems(newBtn, openBtn, saveBtn);
    }

    // =====================================================================
    // 2. Data -- 2 units -- each item opens its own window
    // =====================================================================
    // Short visible labels: three items share 2 units, so "Process Data"
    // at full length collides with its neighbours below roughly 2000px.
    // The "Data" caption underneath supplies the missing noun; the full
    // name still shows in the tooltip and in each window's title bar.
    //
    // The window shells live under ui.editor.homeTab.{Import,Process,Export}
    // so each stage owns its own package alongside its future back end.
    private static RibbonGroup dataGroup(UI_Main ide) {
        return new RibbonGroup("Data", Dim.ToolBand.Home.UNITS_DATA).withItems(
                RibbonItems.item("Import", "Import Data", ic(IC_IMPORT_DATA),
                        () -> openWindow(ide, "Import Data",
                                () -> UI_Home_Import_Main.open(ide))),
                RibbonItems.item("Process", "Process Data", ic(IC_PROCESS_DATA),
                        () -> openWindow(ide, "Process Data",
                                () -> UI_Home_Process_Main.open(ide))),
                RibbonItems.item("Export", "Export Data", ic(IC_EXPORT_DATA),
                        () -> openWindow(ide, "Export Data",
                                () -> UI_Home_Export_Main.open(ide))));
    }

    /**
     * Opens a Data window on the FX thread, reporting any failure to the
     * Command Window rather than letting it vanish into an uncaught handler.
     * Mirrors how the Plot button guards its own window construction.
     *
     * @param ide    the IDE controller
     * @param name   feature name, used in the failure message
     * @param opener the window's open call
     */
    private static void openWindow(UI_Main ide, String name, Runnable opener) {
        Platform.runLater(() -> {
            try {
                opener.run();
            } catch (Exception ex) {
                TerminalManager.println(ide, name + " window failed: " + ex.getMessage());
                ex.printStackTrace();
            }
        });
    }

    // =====================================================================
    // 3. Visualisation -- 1 unit
    // =====================================================================
    private static RibbonGroup visualisationGroup(UI_Main ide) {
        return new RibbonGroup("Visualisation", Dim.ToolBand.Home.UNITS_VISUALISATION).withItems(
                RibbonItems.item("Plot", ic(IC_PLOT), () -> Platform.runLater(() -> {
                    try {
                        File currentFolder = (ide.currentFolder != null)
                                ? ide.currentFolder.toFile()
                                : null;
                        PlotWindow pw = new PlotWindow(ide, currentFolder);
                        pw.show();
                    } catch (Exception ex) {
                        TerminalManager.println(ide, "Plot window failed: " + ex.getMessage());
                        ex.printStackTrace();
                    }
                })));
    }

    // =====================================================================
    // 4. Modelling -- 1 unit
    // =====================================================================
    private static RibbonGroup modellingGroup(UI_Main ide) {
        return new RibbonGroup("Modelling", Dim.ToolBand.Home.UNITS_MODELLING).withItems(
                RibbonItems.item("Multi Physics", ic(IC_MULTI_PHYSICS),
                        () -> UI_MP_Main.open(ide.stage)));
    }

    // =====================================================================
    // 5. Graphical -- 1 unit
    // =====================================================================
    private static RibbonGroup graphicalGroup(UI_Main ide) {
        return new RibbonGroup("Graphical", Dim.ToolBand.Home.UNITS_GRAPHICAL).withItems(
                RibbonItems.item("Neural Link", ic(IC_NEURAL_LINK),
                        () -> NeuralLinkWindow.open(ide.stage)));
    }

    // =====================================================================
    // 6. Compute -- 2 units -- Step is new, Run and Stop keep their wiring
    // =====================================================================
    private static RibbonGroup computeGroup(UI_Main ide) {
        return new RibbonGroup("Compute", Dim.ToolBand.Home.UNITS_COMPUTE).withItems(
                RibbonItems.item("Step", ic(IC_STEP), () -> StepFileRunner.step(ide)),
                RibbonItems.item("Run", ic(IC_RUN), () -> EditorManager.runCurrentFile(ide)),
                RibbonItems.item("Stop", ic(IC_STOP), () -> {
                    StepFileRunner.reset(ide);          // clear arrow + highlight, rewind
                    if (ide.isProgramRunning()) {
                        ide.stopProgram();
                    }
                }));
    }

    // =====================================================================
    // 7. Analysis -- 2 units -- readouts, not buttons
    // =====================================================================
    private static RibbonGroup analysisGroup() {
        return new RibbonGroup("Analysis", Dim.ToolBand.Home.UNITS_ANALYSIS).withContent(RibbonAnalysis.buildContent());
    }

    // =====================================================================
    // 8. AI Help -- 1 unit
    // =====================================================================
    private static RibbonGroup aiHelpGroup(UI_Main ide) {
        return new RibbonGroup("AI Help", Dim.ToolBand.Home.UNITS_AI_HELP).withItems(
                RibbonItems.stub("Code Bot", ic(IC_CODE_BOT), ide));
    }
}
