package ui.ribbon_interface.tool_bar;

import java.io.File;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.application.Platform;
import javafx.beans.binding.BooleanBinding;
import javafx.scene.control.ToolBar;
import javafx.scene.image.ImageView;
import multiphysics.UI_MP_Main;
import plot.PlotWindow;
import ui.UI_Main;
import ui.cli.CLI_Main;
import ui.codebot.CodeBotHost;
import ui.design.Dim;
import ui.design.LiveHeight;
import ui.editor.homeTab.Export.UI_Home_Export_Main;
import ui.editor.homeTab.Import.UI_Home_Import_Main;
import ui.editor.homeTab.Process.UI_Home_Process_Main;
import ui.editor.homeTab.StepFileRunner;
import ui.explorer.NeuralLinkWindow;
import ui.explorer.shortcut.MainWindowShortcutHandler;
import ui.managers.EditorManager;
import ui.managers.TerminalManager;
import ui.ribbon_interface.tool_groups.RibbonAnalysis;
import ui.ribbon_interface.tool_groups.RibbonGroup;
import ui.ribbon_interface.tool_groups.RibbonItems;
import ui.ribbon_interface.tool_groups.RibbonSplitButton;
import ui.ribbon_interface.tool_groups.RibbonViews;
import ui.ui_functions.tools.HomeRibbonIcons;

/**
 * Builds the Home tab's ribbon band.
 *
 * <p>
 * Nine compartments span the ribbon width in the ratio 2:2:1:1:1:2:2:1:1 out
 * of 16 units, divided by mild vertical rules, with the remaining 3 units left
 * free at the right-hand edge. A compartment is never narrower than its
 * labels need; see {@link RibbonBand}.
 * </p>
 *
 * <pre>
 *   Files      New / Open / Save              (split buttons)
 *   Data       Import / Process / Export      (wired)
 *   Visualisation  Plot                       (wired)
 *   Modelling  Multi Physics                  (stub)
 *   Graphical  Neural Link                    (wired)
 *   Compute    Step / Run / Stop              (Stop enabled only while running)
 *   Analysis   No. of Computation, Execution Time  (readouts)
 *   Views      Full Screen / Search Code      (toggle rows; third row free)
 *   AI Help    Code Bot                       (opens the Code Bot panel)
 * </pre>
 *
 * <p>
 * Views took its unit from the free space. Full Screen moved here from
 * Settings &gt; Layout; Search Code is a third way into the editor's find bar,
 * beside Ctrl+F and the right-click menu. See {@link RibbonViews}.
 * </p>
 */
public final class HomeRibbon {

    private static final Logger LOG = Logger.getLogger(HomeRibbon.class.getName());

    // =====================================================================
    // Home-ribbon icon assets -- light and dark, all under /icons/home_icons
    // =====================================================================
    // Every ribbon icon now lives inside a single folder:
    //     src/main/resources/icons/home_icons
    // The light asset is the plain base name; the dark asset is the same
    // base name with a "_dark" suffix. Both carry the .png extension.
    //
    // Constants below hold BASE NAMES ONLY (no folder, no "_dark", no
    // extension). They are handed to HomeRibbonIcons, which appends the
    // suffix for the active theme and re-points every icon in place when the
    // theme is toggled -- exactly as HomeFilesIcons does for New/Open/Save.
    private static final String IC_RUN           = "ic_04_run";
    private static final String IC_STOP          = "ic_07_stop";        // was ic_07_exit
    private static final String IC_PLOT          = "ic_27_newplot";
    private static final String IC_NEURAL_LINK   = "ic_26_neural_link";

    private static final String IC_IMPORT_DATA   = "ic_h_01_import_data";
    private static final String IC_PROCESS_DATA  = "ic_h_02_process_data";
    private static final String IC_EXPORT_DATA   = "ic_h_03_export_data";
    private static final String IC_MULTI_PHYSICS = "ic_h_04_multi_physics";
    private static final String IC_STEP          = "ic_h_05_step";
    private static final String IC_CODE_BOT      = "ic_h_06_code_bot";

    // --- Files compartment assets (unchanged) -----------------------------
    // Base names only: HomeFilesIcons appends the theme folder and the
    // extension, so the same constant serves the light and dark sets.
    private static final String IC_F_NEW = "new";
    private static final String IC_F_NEW_SCRIPT = "new_script";
    private static final String IC_F_NEW_FUNCTION = "new_function";
    private static final String IC_F_NEW_CLASS = "new_class";
    private static final String IC_F_NEW_TXT = "new_txt";

    private static final String IC_F_OPEN = "open";
    private static final String IC_F_OPEN_FILE = "open_file";
    private static final String IC_F_OPEN_LAST = "open_last_project";
    private static final String IC_F_OPEN_ROOT = "open_root_folder";

    private static final String IC_F_SAVE = "save";
    private static final String IC_F_SAVE_AS = "save_as";
    private static final String IC_F_SAVE_ROOT = "save_root";
    private static final String IC_F_SAVE_IN = "save_in";

    /** Opacity of the Stop item while nothing is running (Modena's disabled value). */
    private static final double STOP_DISABLED_OPACITY = 0.4;

    private HomeRibbon() {
    }

    /**
     * Builds a live-themed graphic for a Home-ribbon icon at the ribbon's
     * standard icon size. The returned view re-points itself between the light
     * and {@code _dark} art whenever the theme is toggled.
     *
     * @param base the icon base name, e.g. {@code "ic_04_run"}
     * @return the configured, theme-aware icon view
     */
    private static ImageView ic(String base) {
        return HomeRibbonIcons.icon(base, Dim.ToolBand.ICON_SIZE);
    }

    /**
     * Builds the Home band.
     *
     * <p>
     * The compartments are handed to a {@link RibbonBand}, which gives each
     * one {@code max(units x unit, natural width)} and collapses them right
     * to left into drop-down buttons when the window is too narrow -- so no
     * label is ever cut to "...". The unit ratios in
     * {@code Dim.ToolBand.Home} still set the look on a wide window.
     * </p>
     *
     * @param ide the IDE controller
     * @return the Home ToolBar, ready to drop into the toolbar StackPane
     */
    public static ToolBar build(UI_Main ide) {
        List<RibbonGroup> groups = List.of(
                filesGroup(ide),
                dataGroup(ide),
                visualisationGroup(ide),
                modellingGroup(ide),
                graphicalGroup(ide),
                computeGroup(ide),
                analysisGroup(),
                viewsGroup(),
                aiHelpGroup(ide));

        RibbonBand band = new RibbonBand(Dim.ToolBand.Home.TOTAL_UNITS,
                "home-ribbon-root", "home-ribbon-toolbar");
        band.addGroups(groups);

        // RibbonBar, not ToolBar: the stock ToolBarSkin's snapped fit test
        // sends the whole band into the ">>" overflow popup on displays that
        // are not at 100% scaling. See RibbonBar.
        RibbonBar bar = new RibbonBar(band, "menu-toolbar", "home-ribbon-toolbar");
        // Live: the band grows with the Font Size setting.
        LiveHeight.pinAtLeast(bar, () -> Dim.ToolBand.ROW_HEIGHT);

        // The Views toggles carry their own colour pair; attached to the main
        // scene once this bar is in it.
        RibbonViews.installStylesheets(bar);
        return bar;
    }

    // =====================================================================
    // 1. Files -- 2 units -- three split buttons
    // =====================================================================
    // Each control is one rounded rectangle: the icon runs the default
    // action, the triangle strip beneath the label opens the drop-down.
    // See RibbonSplitButton for the two-zone hover behaviour.
    //
    // Shortcuts: an entry with a key shows it at its right edge. The keys
    // are defined and handled in MainWindowShortcutHandler; the menus only
    // display the same constants, so the two cannot disagree.
    //   Script Ctrl+N | Open File Ctrl+O | Open Folder Ctrl+Shift+O
    //   Save Ctrl+S   | Save As Ctrl+Shift+S
    //
    // Icons: Open Folder and Save reuse the ribbon's own Open and Save art;
    // the other ten are the coloured set in /icons/HomeFiles/{light,dark}.
    private static RibbonGroup filesGroup(UI_Main ide) {
        RibbonSplitButton newBtn = RibbonItems.split(
                "New", IC_F_NEW, "New Neural Code script (.nc)",
                () -> EditorManager.newNeuralCodeFile(ide),
                RibbonItems.menuItem("Script", IC_F_NEW_SCRIPT, MainWindowShortcutHandler.NEW_SCRIPT,
                        () -> EditorManager.newNeuralCodeFile(ide)),
                RibbonItems.menuItem("Function", IC_F_NEW_FUNCTION,
                        () -> EditorManager.newFunctionFile(ide)),
                RibbonItems.menuItem("Class", IC_F_NEW_CLASS,
                        () -> EditorManager.newClassFile(ide)),
                RibbonItems.menuItem("Plain Text", IC_F_NEW_TXT,
                        () -> EditorManager.newPlainTextFile(ide)));

        RibbonSplitButton openBtn = RibbonItems.split(
                "Open", IC_F_OPEN, "Open a Neural Code file (.nc)",
                () -> EditorManager.openNcFile(ide),
                RibbonItems.menuItem("Open File", IC_F_OPEN_FILE, MainWindowShortcutHandler.OPEN_FILE,
                        () -> EditorManager.openFile(ide)),
                RibbonItems.menuItem("Open Folder", IC_F_OPEN, MainWindowShortcutHandler.OPEN_FOLDER,
                        () -> EditorManager.openProjectFolder(ide)),
                RibbonItems.menuItem("Open Last Project", IC_F_OPEN_LAST,
                        () -> EditorManager.openLastProject(ide)),
                RibbonItems.menuItem("Open Root Folder", IC_F_OPEN_ROOT,
                        () -> EditorManager.openRootFolder(ide)));

        RibbonSplitButton saveBtn = RibbonItems.split(
                "Save", IC_F_SAVE, "Save the current file",
                () -> EditorManager.saveCurrentFile(ide),
                RibbonItems.menuItem("Save", IC_F_SAVE, MainWindowShortcutHandler.SAVE,
                        () -> EditorManager.saveCurrentFile(ide)),
                RibbonItems.menuItem("Save As", IC_F_SAVE_AS, MainWindowShortcutHandler.SAVE_AS,
                        () -> EditorManager.saveAsFile(ide)),
                RibbonItems.menuItem("Save Root", IC_F_SAVE_ROOT,
                        () -> EditorManager.saveToProjectRoot(ide)),
                RibbonItems.menuItem("Save In", IC_F_SAVE_IN,
                        () -> EditorManager.saveInFolder(ide)));

        // The three drop-downs are the narrow menu width (90 % of the common
        // one), set by RibbonSplitButton; the old per-button scale factors in
        // HomeBand_dim no longer apply.

        return new RibbonGroup("Files", Dim.ToolBand.Home.UNITS_FILES).withItems(newBtn, openBtn, saveBtn);
    }

    // =====================================================================
    // 2. Data -- 2 units -- each item opens its own window
    // =====================================================================
    // Short visible labels: three items share 2 units, so "Process Data"
    // at full length collides with its neighbours below roughly 2000px.
    // The "Data" caption underneath supplies the missing noun; the full
    // name still shows in the tooltip and in each window's title bar.
    //
    // The window shells live under ui.editor.homeTab.{Import,Process,Export}
    // so each stage owns its own package alongside its future back end.
    private static RibbonGroup dataGroup(UI_Main ide) {
        return new RibbonGroup("Data", Dim.ToolBand.Home.UNITS_DATA).withItems(
                RibbonItems.item("Import", "Import Data", ic(IC_IMPORT_DATA),
                        () -> openWindow(ide, "Import Data",
                                () -> UI_Home_Import_Main.open(ide))),
                RibbonItems.item("Process", "Process Data", ic(IC_PROCESS_DATA),
                        () -> openWindow(ide, "Process Data",
                                () -> UI_Home_Process_Main.open(ide))),
                RibbonItems.item("Export", "Export Data", ic(IC_EXPORT_DATA),
                        () -> openWindow(ide, "Export Data",
                                () -> UI_Home_Export_Main.open(ide))));
    }

    /**
     * Opens a Data window on the FX thread, reporting any failure to the
     * Command Window rather than letting it vanish into an uncaught handler.
     * Mirrors how the Plot button guards its own window construction.
     *
     * @param ide    the IDE controller
     * @param name   feature name, used in the failure message
     * @param opener the window's open call
     */
    private static void openWindow(UI_Main ide, String name, Runnable opener) {
        Platform.runLater(() -> {
            try {
                opener.run();
            } catch (Exception ex) {
                TerminalManager.println(ide, name + " window failed: " + ex.getMessage());
                LOG.log(Level.WARNING, name + " window failed", ex);
            }
        });
    }

    // =====================================================================
    // 3. Visualisation -- 1 unit
    // =====================================================================
    private static RibbonGroup visualisationGroup(UI_Main ide) {
        return new RibbonGroup("Visualisation", Dim.ToolBand.Home.UNITS_VISUALISATION).withItems(
                RibbonItems.item("Plot", ic(IC_PLOT), () -> Platform.runLater(() -> {
                    try {
                        File currentFolder = (ide.currentFolder != null)
                                ? ide.currentFolder.toFile()
                                : null;
                        PlotWindow pw = new PlotWindow(ide, currentFolder);
                        pw.show();
                    } catch (Exception ex) {
                        TerminalManager.println(ide, "Plot window failed: " + ex.getMessage());
                        LOG.log(Level.WARNING, "Plot window failed", ex);
                    }
                })));
    }

    // =====================================================================
    // 4. Modelling -- 1 unit
    // =====================================================================
    private static RibbonGroup modellingGroup(UI_Main ide) {
        return new RibbonGroup("Modelling", Dim.ToolBand.Home.UNITS_MODELLING).withItems(
                RibbonItems.item("Multi Physics", ic(IC_MULTI_PHYSICS),
                        () -> UI_MP_Main.open(ide.stage)));
    }

    // =====================================================================
    // 5. Graphical -- 1 unit
    // =====================================================================
    private static RibbonGroup graphicalGroup(UI_Main ide) {
        return new RibbonGroup("Graphical", Dim.ToolBand.Home.UNITS_GRAPHICAL).withItems(
                RibbonItems.item("Neural Link", ic(IC_NEURAL_LINK),
                        () -> NeuralLinkWindow.open(ide.stage)));
    }

    // =====================================================================
    // 6. Compute -- 2 units -- Step / Run / Stop
    // =====================================================================
    // Stop goes through CLI_Main.stopExecution, the one path shared with F6,
    // Ctrl+C in the console and the Command Window's three-dot menu. It used
    // to call ide.stopProgram(), which killed nc.exe for good and left the
    // console answering "UPI terminal is not running." to everything.
    //
    // Stop is greyed out while nothing is running: enabled while a command or
    // script executes, or while a step run is in progress (so the step arrow
    // can always be cleared between clicks).
    private static RibbonGroup computeGroup(UI_Main ide) {
        var stop = RibbonItems.item("Stop", ic(IC_STOP), () -> CLI_Main.stopExecution(ide));

        // busyShownProperty: Stop lights up only for a command that runs
        // longer than a moment, so a quick command (k = 5) does not flash it.
        BooleanBinding idle = CLI_Main.busyShownProperty().not()
                .and(StepFileRunner.activeProperty().not());
        stop.disableProperty().bind(idle);
        // Set, not bound: if the item is a Button, Modena styles :disabled
        // opacity itself and a bound opacity would make CSS log errors.
        stop.setOpacity(idle.get() ? STOP_DISABLED_OPACITY : 1.0);
        idle.addListener((obs, was, now) -> stop.setOpacity(now ? STOP_DISABLED_OPACITY : 1.0));

        return new RibbonGroup("Compute", Dim.ToolBand.Home.UNITS_COMPUTE).withItems(
                RibbonItems.item("Step", ic(IC_STEP), () -> StepFileRunner.step(ide)),
                RibbonItems.item("Run", ic(IC_RUN), () -> EditorManager.runCurrentFile(ide)),
                stop);
    }

    // =====================================================================
    // 7. Analysis -- 2 units -- readouts, not buttons
    // =====================================================================
    private static RibbonGroup analysisGroup() {
        return new RibbonGroup("Analysis", Dim.ToolBand.Home.UNITS_ANALYSIS).withContent(RibbonAnalysis.buildContent());
    }

    // =====================================================================
    // 8. Views -- 1 unit -- Full Screen / Search Code toggle rows
    // =====================================================================
    // Two rectangular toggles stacked in the top two thirds of the column;
    // the bottom third is kept free for later. Each toggle follows the real
    // state (the stage, the find bar), so Esc, F11 and Ctrl+F keep it right.
    private static RibbonGroup viewsGroup() {
        // Collapsed on a narrow window, it shows only the triangle: the row
        // icons are too small to stand in for the compartment at full size.
        return new RibbonGroup("Views", Dim.ToolBand.Home.UNITS_VIEWS)
                .withContent(RibbonViews.buildContent())
                .withoutFaceIcon();
    }

    // =====================================================================
    // 9. AI Help -- 1 unit
    // =====================================================================
    // Code Bot toggles the Code Bot Assistant at the bottom of the File
    // Explorer (40% of its height, draggable). It replaces the stub that
    // only printed "code bot is clicked" in the Command Window.
    private static RibbonGroup aiHelpGroup(UI_Main ide) {
        return new RibbonGroup("AI Help", Dim.ToolBand.Home.UNITS_AI_HELP).withItems(
                RibbonItems.item("Code Bot", "Code Bot Assistant", ic(IC_CODE_BOT),
                        () -> CodeBotHost.toggle(ide)));
    }
}
