package ui.ribbon_interface.tool_bar;

import javafx.geometry.Orientation;
import javafx.scene.control.Button;
import javafx.scene.control.Separator;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.StackPane;
import ui.UI_Main;
import ui.design.Dim;
import ui.explorer.PanelTitleBar;
import ui.explorer.TitleBarIcon;
import ui.ui_functions.tools.ToolbarState;

/**
 * Collapses the Row-2 tool band upward, leaving the tab strip and the
 * quick-access bar in place.
 *
 * <p>
 * Two ways in and out: the toggle button at the end of the breadcrumb path bar,
 * and a double-click on the active tab (wired in {@code ToolbarRibbon}).
 * </p>
 *
 * <h3>The tab shape follows the band</h3>
 * <p>
 * With the band open, the selected tab is open at the bottom and shares the
 * band's colour, so the two read as one surface. Collapse the band and there is
 * nothing underneath for the tab to join -- an open-bottomed tab would then be
 * a box with a missing edge sitting on the quick-access bar. So collapsing also
 * puts {@code Dim.RibbonBar.COLLAPSED_CLASS} on the strip, and the generated
 * stylesheet answers by restoring the strip's bottom padding, the tab's bottom
 * border and its bottom corner radii. Expanding takes the class off again.
 * </p>
 * <p>
 * The class goes on the strip rather than on the tab itself because the strip's
 * padding changes too, and because it then covers all six tabs whichever one
 * happens to be selected.
 * </p>
 */
public final class RibbonCollapse {

    private static boolean collapsed = false;
    private static TitleBarIcon icon;

    private RibbonCollapse() {
    }

    /**
     * Adds the toggle to the quick-access bar, just after the breadcrumb path
     * and separated from it by a vertical rule.
     *
     * <p>
     * Call after {@code ToolbarManager.setupToolbars(ide)}, since the bar does
     * not exist before then.
     * </p>
     *
     * @param ide the IDE controller
     */
    public static void installQuickAccessToggle(UI_Main ide) {
        ToolBar bar = ToolbarState.quickAccessBar;
        if (bar == null) {
            return;
        }

        icon = new TitleBarIcon(TitleBarIcon.RIBBON_COLLAPSE, Dim.QuickBar.TOGGLE_ICON_SIZE);
        // active stays false: this button sits on the quick-access bar, not on
        // a navy strip, so its tone follows the theme alone -- dark glyph on
        // the light bar, light glyph on the dark one.
        Button toggle = PanelTitleBar.glyphButton(icon, "Collapse / expand the tool bar");
        toggle.getStyleClass().add("quick-bar-toggle");
        toggle.setOnAction(e -> toggle());

        Separator rule = new Separator(Orientation.VERTICAL);

        int pathIndex = bar.getItems().indexOf(ToolbarState.quickPathLabel);
        if (pathIndex >= 0) {
            bar.getItems().add(pathIndex + 1, rule);
            bar.getItems().add(pathIndex + 2, toggle);
        } else {
            bar.getItems().addAll(rule, toggle);
        }

        // The band starts expanded, but say so explicitly rather than trusting
        // the strip to have been built without the class on it.
        applyTabShape();
    }

    /**
     * Flips the band between shown and hidden.
     */
    public static void toggle() {
        setCollapsed(!collapsed);
    }

    /**
     * @param collapse true to hide the band, false to show it
     */
    public static void setCollapsed(boolean collapse) {
        StackPane stack = ToolbarState.toolbarStack;
        if (stack == null) {
            return;
        }
        collapsed = collapse;

        // Unmanaged as well as invisible, so the enclosing VBox reclaims the
        // height instead of leaving a blank band behind.
        stack.setVisible(!collapse);
        stack.setManaged(!collapse);

        applyTabShape();

        if (icon != null) {
            icon.setBase(collapse ? TitleBarIcon.RIBBON_EXPAND : TitleBarIcon.RIBBON_COLLAPSE);
        }
    }

    /**
     * @return true if the band is hidden
     */
    public static boolean isCollapsed() {
        return collapsed;
    }

    /**
     * Puts the tab into its open or collapsed shape.
     *
     * <p>
     * Two halves, and they are deliberately in different places:
     * </p>
     * <ul>
     * <li>The marker class on the Row-1 strip drives the <i>drawing</i> --
     * which corners round, which edges get a border. That is CSS's job and it
     * does it well.</li>
     * <li>{@code ToolbarRibbon.setBandCollapsed} re-applies the tabs' layout
     * <i>margins</i>, which is what actually moves the tab's bottom edge off
     * the band. Margins are not styleable, so this cannot be done from the
     * stylesheet -- that is the point of them here.</li>
     * </ul>
     * <p>
     * Safe to call before the strip or the tabs exist; both halves no-op and
     * the next call picks it up.
     * </p>
     */
    private static void applyTabShape() {
        ui.ui_functions.tools.ToolbarRibbon.setBandCollapsed(collapsed);

        ToolBar strip = ToolbarState.ribbonBar;
        if (strip == null) {
            return;
        }
        String marker = Dim.RibbonBar.COLLAPSED_CLASS;
        if (collapsed) {
            if (!strip.getStyleClass().contains(marker)) {
                strip.getStyleClass().add(marker);
            }
        } else {
            strip.getStyleClass().remove(marker);
        }
    }
}
