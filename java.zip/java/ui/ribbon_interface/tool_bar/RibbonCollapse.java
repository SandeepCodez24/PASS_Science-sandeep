package ui.ribbon_interface.tool_bar;

import javafx.geometry.Orientation;
import javafx.scene.control.Button;
import javafx.scene.control.Separator;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.StackPane;
import ui.UI_Main;
import ui.explorer.PanelTitleBar;
import ui.explorer.TitleBarIcon;
import ui.ui_functions.tools.ToolbarState;

/**
 * Collapses the Row-2 tool band upward, leaving the tab strip and the
 * quick-access bar in place.
 *
 * <p>
 * Two ways in and out: the toggle button at the end of the breadcrumb path bar,
 * and a double-click on the active tab (wired in {@code ToolbarRibbon}).
 * </p>
 */
public final class RibbonCollapse {

    private static boolean collapsed = false;
    private static TitleBarIcon icon;

    private RibbonCollapse() {
    }

    /**
     * Adds the toggle to the quick-access bar, just after the breadcrumb path
     * and separated from it by a vertical rule.
     *
     * <p>
     * Call after {@code ToolbarManager.setupToolbars(ide)}, since the bar does
     * not exist before then.
     * </p>
     *
     * @param ide the IDE controller
     */
    public static void installQuickAccessToggle(UI_Main ide) {
        ToolBar bar = ToolbarState.quickAccessBar;
        if (bar == null) {
            return;
        }

        icon = new TitleBarIcon(TitleBarIcon.RIBBON_COLLAPSE, 14);
        // active stays false: this button sits on the quick-access bar, not on
        // a navy strip, so its tone follows the theme alone -- dark glyph on
        // the light bar, light glyph on the dark one.
        Button toggle = PanelTitleBar.glyphButton(icon, "Collapse / expand the tool bar");
        toggle.getStyleClass().add("quick-bar-toggle");
        toggle.setOnAction(e -> toggle());

        Separator rule = new Separator(Orientation.VERTICAL);

        int pathIndex = bar.getItems().indexOf(ToolbarState.quickPathLabel);
        if (pathIndex >= 0) {
            bar.getItems().add(pathIndex + 1, rule);
            bar.getItems().add(pathIndex + 2, toggle);
        } else {
            bar.getItems().addAll(rule, toggle);
        }
    }

    /**
     * Flips the band between shown and hidden.
     */
    public static void toggle() {
        setCollapsed(!collapsed);
    }

    /**
     * @param collapse true to hide the band, false to show it
     */
    public static void setCollapsed(boolean collapse) {
        StackPane stack = ToolbarState.toolbarStack;
        if (stack == null) {
            return;
        }
        collapsed = collapse;

        // Unmanaged as well as invisible, so the enclosing VBox reclaims the
        // height instead of leaving a blank band behind.
        stack.setVisible(!collapse);
        stack.setManaged(!collapse);

        if (icon != null) {
            icon.setBase(collapse ? TitleBarIcon.RIBBON_EXPAND : TitleBarIcon.RIBBON_COLLAPSE);
        }
    }

    /**
     * @return true if the band is hidden
     */
    public static boolean isCollapsed() {
        return collapsed;
    }
}
