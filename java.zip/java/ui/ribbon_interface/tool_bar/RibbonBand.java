package ui.ribbon_interface.tool_bar;

import java.util.ArrayList;
import java.util.List;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.geometry.Bounds;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Tooltip;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.TextAlignment;
import javafx.stage.Popup;
import ui.design.Dim;
import ui.ribbon_interface.tool_groups.RibbonGroup;

/**
 * The content of a compartment band (Home, Signals, Settings): lays the
 * compartments out left to right, one divider after each, and never cuts a
 * label.
 *
 * <h3>How the width is shared</h3>
 * <p>
 * The band is divided into {@code totalUnits} equal units, as before. Each
 * compartment asks for {@code units x unit}, but is never given less than its
 * natural width -- the width at which every label and its caption show in
 * full. What is left over is the free space at the right edge.
 * </p>
 *
 * <p>
 * As the window narrows, room is given up in this order:
 * </p>
 * <ol>
 * <li><b>The free space</b> on the right.</li>
 * <li><b>The ratio padding.</b> The unit shrinks, so compartments that were
 * wider than they needed come down towards their natural widths.</li>
 * <li><b>Whole compartments</b>, right to left. A collapsed compartment becomes
 * one button -- its first icon over a small triangle, with its caption beneath
 * -- and clicking it shows the full compartment in a drop-down panel. This is
 * the MATLAB toolstrip behaviour.</li>
 * </ol>
 * <p>
 * At no point does a label shrink into "...".
 * </p>
 *
 * <h3>Why a custom Pane</h3>
 * <p>
 * An {@code HBox} cannot express "the larger of a ratio and a natural width,
 * then collapse from the right". Doing it with bindings is what produced the
 * old min = pref = max = unit share, and the ellipses with it. The whole rule
 * fits in {@link #layoutChildren()}.
 * </p>
 */
public final class RibbonBand extends Pane {

    /** Style class on the drop-down panel of a collapsed compartment. */
    public static final String POPUP_CLASS = "ribbon-collapse-popup";

    /** Style class on a collapsed compartment's button. */
    public static final String COLLAPSED_BUTTON_CLASS = "ribbon-collapsed-button";

    /** Style class on the triangle inside that button. */
    public static final String COLLAPSED_ARROW_CLASS = "ribbon-collapsed-arrow";

    private final double totalUnits;
    private final String rootStyleClass;
    private final String toolbarStyleClass;
    private final List<Slot> slots = new ArrayList<>();

    /**
     * @param totalUnits        the number of units the band is divided into
     * @param rootStyleClass    the band's own class, e.g.
     *                          {@code "home-ribbon-root"}
     * @param toolbarStyleClass the class on the owning bar, e.g.
     *                          {@code "home-ribbon-toolbar"}; also put on
     *                          the drop-down panels so they pick up the
     *                          band's padding and colours
     */
    public RibbonBand(double totalUnits, String rootStyleClass, String toolbarStyleClass) {
        this.totalUnits = Math.max(1, totalUnits);
        this.rootStyleClass = rootStyleClass;
        this.toolbarStyleClass = toolbarStyleClass;

        if (rootStyleClass != null) {
            getStyleClass().add(rootStyleClass);
        }

        // Anything that cannot fit is clipped at the band's edge rather than
        // painted over the quick-access row or the panels below. With the
        // stage minimum width in place this should never actually trigger.
        Rectangle clip = new Rectangle();
        clip.widthProperty().bind(widthProperty());
        clip.heightProperty().bind(heightProperty());
        setClip(clip);
    }

    /**
     * Adds compartments, left to right.
     *
     * @param groups the compartments
     * @return this band, for chaining
     */
    public RibbonBand addGroups(List<RibbonGroup> groups) {
        for (RibbonGroup group : groups) {
            addGroup(group);
        }
        return this;
    }

    /**
     * Adds one compartment, followed by its divider.
     *
     * @param group the compartment
     * @return this band, for chaining
     */
    public RibbonBand addGroup(RibbonGroup group) {
        Slot slot = new Slot(group);
        slots.add(slot);
        getChildren().addAll(group, slot.face, slot.separator);
        slot.face.setVisible(false);
        return this;
    }

    // =====================================================================
    // Measurement
    // =====================================================================

    private double separatorsWidth() {
        return slots.size() * Dim.ToolBand.SEPARATOR_WIDTH;
    }

    @Override
    protected double computePrefWidth(double height) {
        Insets in = getInsets();
        double total = in.getLeft() + in.getRight() + separatorsWidth();
        for (Slot s : slots) {
            total += s.group.naturalWidth();
        }
        return total;
    }

    /** Every compartment collapsed: the narrowest this band can be drawn. */
    @Override
    protected double computeMinWidth(double height) {
        Insets in = getInsets();
        double total = in.getLeft() + in.getRight() + separatorsWidth();
        for (Slot s : slots) {
            total += s.face.naturalWidth();
        }
        return total;
    }

    @Override
    protected double computePrefHeight(double width) {
        Insets in = getInsets();
        double tallest = 0;
        for (Slot s : slots) {
            tallest = Math.max(tallest, s.group.prefHeight(-1));
        }
        return in.getTop() + in.getBottom() + tallest;
    }

    // =====================================================================
    // Layout
    // =====================================================================

    @Override
    protected void layoutChildren() {
        int n = slots.size();
        if (n == 0) {
            return;
        }

        Insets in = getInsets();
        double x = in.getLeft();
        double y = in.getTop();
        double width = getWidth() - in.getLeft() - in.getRight();
        double height = getHeight() - in.getTop() - in.getBottom();
        double seps = separatorsWidth();

        double[] natural = new double[n];
        double[] faces = new double[n];
        for (int i = 0; i < n; i++) {
            natural[i] = slots.get(i).group.naturalWidth();
            faces[i] = slots.get(i).face.naturalWidth();
        }

        // 1. How many compartments, counted from the right, must collapse so
        //    that the rest fit at their natural widths?
        int expanded = n;
        while (expanded > 0) {
            double need = seps;
            for (int i = 0; i < n; i++) {
                need += (i < expanded) ? natural[i] : faces[i];
            }
            if (need <= width + 0.5) {
                break;
            }
            expanded--;
        }

        // 2. The unit for the compartments still open. Starts at the full
        //    ratio unit and comes down only as far as needed, so the free
        //    space on the right is always the first thing to go.
        double faceTotal = 0;
        for (int i = expanded; i < n; i++) {
            faceTotal += faces[i];
        }
        double available = width - seps - faceTotal;
        double fullUnit = Math.max(0, (width - seps) / totalUnits);
        double unit = solveUnit(natural, expanded, available, fullUnit);

        // 3. Place everything.
        double margin = Dim.ToolBand.SEPARATOR_MARGIN_V;
        for (int i = 0; i < n; i++) {
            Slot s = slots.get(i);
            boolean collapse = i >= expanded;
            s.setCollapsed(collapse);

            double w = collapse
                    ? faces[i]
                    : Math.max(natural[i], s.group.getUnits() * unit);
            double left = snapPositionX(x);
            double right = snapPositionX(x + w);

            Region shown = collapse ? s.face : s.group;
            // A compartment currently open in its drop-down belongs to the
            // pop-up, not to this band, so it is not positioned here.
            if (shown.getParent() == this) {
                shown.resizeRelocate(left, y, right - left, height);
            }
            x += w;

            double sepLeft = snapPositionX(x);
            s.separator.resizeRelocate(sepLeft, y + margin,
                    Dim.ToolBand.SEPARATOR_WIDTH, Math.max(0, height - 2 * margin));
            x += Dim.ToolBand.SEPARATOR_WIDTH;
        }
    }

    /**
     * The largest unit {@code u <= fullUnit} for which the open compartments,
     * each at {@code max(natural, units x u)}, fit in {@code available}.
     */
    private double solveUnit(double[] natural, int expanded, double available, double fullUnit) {
        if (totalWidth(natural, expanded, fullUnit) <= available) {
            return fullUnit;
        }
        double low = 0;
        double high = fullUnit;
        for (int step = 0; step < 32; step++) {
            double mid = (low + high) / 2;
            if (totalWidth(natural, expanded, mid) <= available) {
                low = mid;
            } else {
                high = mid;
            }
        }
        return low;
    }

    private double totalWidth(double[] natural, int expanded, double unit) {
        double total = 0;
        for (int i = 0; i < expanded; i++) {
            total += Math.max(natural[i], slots.get(i).group.getUnits() * unit);
        }
        return total;
    }

    // =====================================================================
    // One compartment, its collapsed face, its divider and its drop-down
    // =====================================================================
    private final class Slot {

        final RibbonGroup group;
        final RibbonGroup face;
        final Region separator = RibbonLayout.separator();
        final Popup popup = new Popup();
        final StackPane popupRoot = new StackPane();
        boolean collapsed = false;

        Slot(RibbonGroup group) {
            this.group = group;
            this.face = new RibbonGroup(group.getTitle(), 0).withItems(faceButton(group));

            popupRoot.getStyleClass().addAll("menu-panel", "menu-toolbar", POPUP_CLASS);
            if (toolbarStyleClass != null) {
                popupRoot.getStyleClass().add(toolbarStyleClass);
            }
            if (rootStyleClass != null) {
                popupRoot.getStyleClass().add(rootStyleClass);
            }
            // Plain buttons (Run, Plot, Fit, ...) close the panel once they
            // have done their job. The handler runs after the button's own,
            // because the action event bubbles up from the button.
            popupRoot.addEventHandler(ActionEvent.ACTION, e -> popup.hide());

            popup.getContent().add(popupRoot);
            popup.setAutoHide(true);
            popup.setHideOnEscape(true);
            popup.setOnHidden(e -> returnGroup());
        }

        /**
         * The collapsed compartment's button: the compartment's first icon
         * over a small triangle, or its title over the triangle when it has
         * no icon (Analysis). The icon view mirrors the original's image, so
         * a theme switch repaints it with everything else.
         */
        private Button faceButton(RibbonGroup source) {
            Region arrow = new Region();
            arrow.getStyleClass().addAll("ribbon-split-arrow", COLLAPSED_ARROW_CLASS);
            arrow.setMouseTransparent(true);

            Button button = new Button();
            ImageView original = source.findIcon();
            if (original != null) {
                ImageView copy = new ImageView();
                copy.imageProperty().bind(original.imageProperty());
                copy.fitWidthProperty().bind(original.fitWidthProperty());
                copy.fitHeightProperty().bind(original.fitHeightProperty());
                copy.setPreserveRatio(original.isPreserveRatio());
                copy.setSmooth(true);
                VBox graphic = new VBox(Dim.ToolBand.COLLAPSED_ARROW_GAP, copy, arrow);
                graphic.setAlignment(Pos.CENTER);
                button.setGraphic(graphic);
                button.setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            } else {
                button.setText(source.getTitle());
                button.setGraphic(arrow);
                button.setContentDisplay(ContentDisplay.BOTTOM);
                button.setGraphicTextGap(Dim.ToolBand.COLLAPSED_ARROW_GAP);
            }

            button.setAlignment(Pos.CENTER);
            button.setTextAlignment(TextAlignment.CENTER);
            button.setFocusTraversable(false);
            button.setMinHeight(Dim.ToolBand.ITEM_HEIGHT);
            button.setPrefHeight(Dim.ToolBand.ITEM_HEIGHT);
            button.setMaxHeight(Dim.ToolBand.ITEM_HEIGHT);
            button.getStyleClass().addAll("menu-item-button", "ribbon-item-button",
                    COLLAPSED_BUTTON_CLASS);
            button.setTooltip(new Tooltip("Show the " + source.getTitle() + " tools"));
            button.setOnAction(e -> togglePopup(button));
            return button;
        }

        void setCollapsed(boolean collapse) {
            if (collapse != collapsed) {
                collapsed = collapse;
                // Widened past this compartment while its drop-down was open:
                // close it, which puts the compartment back in the band.
                // Deferred, because hiding changes the child list and this is
                // called from inside a layout pass.
                if (!collapse && popup.isShowing()) {
                    Platform.runLater(popup::hide);
                }
            }
            face.setVisible(collapse);
            group.setVisible(!collapse || group.getParent() != RibbonBand.this);
        }

        private void togglePopup(Button anchor) {
            if (popup.isShowing()) {
                popup.hide();
                return;
            }
            // A node can have only one parent: lend the compartment to the
            // pop-up for as long as it is open.
            getChildren().remove(group);
            group.setVisible(true);
            popupRoot.getChildren().setAll(group);

            Bounds b = anchor.localToScreen(anchor.getBoundsInLocal());
            if (b == null) {
                returnGroup();
                return;
            }
            popup.show(anchor, b.getMinX(), b.getMaxY());
        }

        private void returnGroup() {
            popupRoot.getChildren().clear();
            if (group.getParent() == null) {
                // Behind the face and the divider in z-order; the position is
                // set by the next layout pass.
                getChildren().add(0, group);
            }
            group.setVisible(!collapsed);
            requestLayout();
        }
    }
}
