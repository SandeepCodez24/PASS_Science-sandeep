package ui.ribbon_interface.tool_bar;

import java.util.List;

import javafx.application.Platform;
import javafx.beans.binding.DoubleBinding;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Labeled;
import javafx.scene.control.ToolBar;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.text.TextAlignment;
import ui.UI_Main;
import ui.editor.signalTab.SignalRegistry;
import ui.editor.signalTab.SignalRegistry.Domain;
import ui.editor.signalTab.SignalRegistry.Signal;
import ui.editor.signalTab.SignalRegistry.Source;
import ui.editor.signalTab.UI_Signal_ActuatorCompare_Main;
import ui.editor.signalTab.UI_Signal_DeliverArtificial_Main;
import ui.editor.signalTab.UI_Signal_DeliverReal_Main;
import ui.editor.signalTab.UI_Signal_Extract_Main;
import ui.editor.signalTab.UI_Signal_FeedArtificial_Main;
import ui.editor.signalTab.UI_Signal_FeedReal_Main;
import ui.editor.signalTab.UI_Signal_Fit_Main;
import ui.editor.signalTab.UI_Signal_Process_Main;
import ui.editor.signalTab.UI_Signal_SensorCompare_Main;
import ui.editor.signalTab.UI_Signal_Set_Main;
import ui.editor.signalTab.UI_Signal_Transform_Main;
import ui.managers.TerminalManager;
import ui.ribbon_interface.tool_groups.RibbonCompareButton;
import ui.ribbon_interface.tool_groups.RibbonGroup;
import ui.ui_functions.tools.SignalIcons;

/**
 * Builds the Signals tab's ribbon band.
 *
 * <p>
 * Five compartments span the band in the ratio 3.5:2:1:3.5:1 out of 14 units,
 * divided by the same mild vertical rules the Home band uses, with the
 * remaining 3 units left free at the right-hand edge:
 * </p>
 *
 * <pre>
 *   Sensors      Feed Artificial / [Select 1 | Select 2 : Compare] / Feed Real
 *   Series       Fit / Process / Extract
 *   Domain       Transform
 *   Actuators    Deliver Artificial / [Select 1 | Select 2 : Compare] / Deliver Real
 *   Environment  Set
 * </pre>
 *
 * <p>
 * Every plain button opens its own placeholder window under
 * {@code ui.editor.signalTab}; one file per button, so each can be filled in
 * separately. The two compare controls are the exception -- their selectors
 * read the live {@link SignalRegistry} and their Compare zone opens a working
 * comparison window.
 * </p>
 */
public final class SignalRibbon {

    // Icon base names under /icons/SignalIcons. SignalIcons appends the theme
    // folder and the extension, so one constant serves the light and dark sets.
    private static final String IC_FEED_ARTIFICIAL = "feed_artificial";
    private static final String IC_FEED_REAL = "feed_real";
    private static final String IC_FIT = "fit";
    private static final String IC_PROCESS = "process";
    private static final String IC_EXTRACT = "extract";
    private static final String IC_TRANSFORM = "transform";
    private static final String IC_DELIVER_ARTIFICIAL = "deliver_artificial";
    private static final String IC_DELIVER_REAL = "deliver_real";
    private static final String IC_SET = "set";

    private SignalRibbon() {
    }

    /**
     * Builds the Signals band, replacing the old flat row of Compile / Build /
     * Clean / Rebuild / Settings buttons.
     *
     * @param ide the IDE controller
     * @return the Signals ToolBar, ready to drop into the toolbar StackPane
     */
    public static ToolBar build(UI_Main ide) {

        List<RibbonGroup> groups = List.of(
                sensorsGroup(ide),
                seriesGroup(ide),
                domainGroup(ide),
                actuatorsGroup(ide),
                environmentGroup(ide));

        ToolBar bar = new ToolBar();
        bar.getStyleClass().addAll("menu-toolbar", "signal-ribbon-toolbar");
        bar.setPrefHeight(RibbonLayout.ROW_HEIGHT);
        bar.setMinHeight(RibbonLayout.ROW_HEIGHT);

        // One unit = (usable width) / 14, recomputed live as the window
        // resizes. Five dividers are subtracted, not four: Environment gets a
        // closing rule as well, so the free space is fenced off from Set.
        DoubleBinding unit = SignalLayout.unitWidth(bar, SignalLayout.SEPARATOR_COUNT);

        HBox root = new HBox();
        root.setAlignment(Pos.CENTER_LEFT);
        root.setSpacing(0);
        root.setFillHeight(true);
        root.getStyleClass().add("signal-ribbon-root");

        for (RibbonGroup group : groups) {
            group.bindWidthTo(unit);
            root.getChildren().add(group);
            root.getChildren().add(RibbonLayout.separator());
        }

        // The 3 free units. A growing spacer rather than a fixed width, so any
        // sub-pixel rounding slack lands here instead of shifting the
        // compartments.
        Region trailingFreeSpace = new Region();
        trailingFreeSpace.getStyleClass().add("ribbon-free-space");
        HBox.setHgrow(trailingFreeSpace, Priority.ALWAYS);
        root.getChildren().add(trailingFreeSpace);

        // A single root child means the ToolBar never renders an overflow
        // button, which would otherwise appear the moment the ratios add up to
        // slightly more than the available width.
        root.prefWidthProperty().bind(bar.widthProperty().subtract(RibbonLayout.TOOLBAR_H_INSET));

        bar.getItems().setAll(root);
        return bar;
    }

    // =====================================================================
    // 1. Sensors -- 3.5 units
    // =====================================================================
    private static RibbonGroup sensorsGroup(UI_Main ide) {

        RibbonCompareButton<Signal> compare = new RibbonCompareButton<Signal>(
                SignalRegistry::displayName)
                .withLeft("Select 1", () -> SignalRegistry.list(Domain.SENSOR, Source.ARTIFICIAL))
                .withRight("Select 2", () -> SignalRegistry.list(Domain.SENSOR, Source.REAL))
                .withAction("Compare", (artificial, real) -> openWindow(ide, "Compare Sensor Signals",
                        () -> UI_Signal_SensorCompare_Main.open(ide, artificial, real)))
                .withActionTooltips(
                        "Compare the fed artificial and real sensor signals",
                        "Choose an artificial and a real signal first");

        return new RibbonGroup("Sensors", SignalLayout.UNITS_SENSORS).withItems(
                item("Feed Artificial", "Feed an artificial sensor signal", IC_FEED_ARTIFICIAL,
                        () -> openWindow(ide, "Feed Artificial",
                                () -> UI_Signal_FeedArtificial_Main.open(ide))),
                compare,
                item("Feed Real", "Feed a real sensor signal", IC_FEED_REAL,
                        () -> openWindow(ide, "Feed Real",
                                () -> UI_Signal_FeedReal_Main.open(ide))));
    }

    // =====================================================================
    // 2. Series -- 2 units
    // =====================================================================
    private static RibbonGroup seriesGroup(UI_Main ide) {
        return new RibbonGroup("Series", SignalLayout.UNITS_SERIES).withItems(
                item("Fit", "Fit a model to a series", IC_FIT,
                        () -> openWindow(ide, "Fit", () -> UI_Signal_Fit_Main.open(ide))),
                item("Process", "Process a series", IC_PROCESS,
                        () -> openWindow(ide, "Process", () -> UI_Signal_Process_Main.open(ide))),
                item("Extract", "Extract from a series", IC_EXTRACT,
                        () -> openWindow(ide, "Extract", () -> UI_Signal_Extract_Main.open(ide))));
    }

    // =====================================================================
    // 3. Domain -- 1 unit
    // =====================================================================
    private static RibbonGroup domainGroup(UI_Main ide) {
        return new RibbonGroup("Domain", SignalLayout.UNITS_DOMAIN).withItems(
                item("Transform", "Transform between domains", IC_TRANSFORM,
                        () -> openWindow(ide, "Transform",
                                () -> UI_Signal_Transform_Main.open(ide))));
    }

    // =====================================================================
    // 4. Actuators -- 3.5 units
    // =====================================================================
    private static RibbonGroup actuatorsGroup(UI_Main ide) {

        RibbonCompareButton<Signal> compare = new RibbonCompareButton<Signal>(
                SignalRegistry::displayName)
                .withLeft("Select 1", () -> SignalRegistry.list(Domain.ACTUATOR, Source.ARTIFICIAL))
                .withRight("Select 2", () -> SignalRegistry.list(Domain.ACTUATOR, Source.REAL))
                .withAction("Compare", (artificial, real) -> openWindow(ide, "Compare Actuator Signals",
                        () -> UI_Signal_ActuatorCompare_Main.open(ide, artificial, real)))
                .withActionTooltips(
                        "Compare the delivered artificial and real actuator signals",
                        "Choose an artificial and a real signal first");

        return new RibbonGroup("Actuators", SignalLayout.UNITS_ACTUATORS).withItems(
                item("Deliver Artificial", "Deliver an artificial actuator signal",
                        IC_DELIVER_ARTIFICIAL,
                        () -> openWindow(ide, "Deliver Artificial",
                                () -> UI_Signal_DeliverArtificial_Main.open(ide))),
                compare,
                item("Deliver Real", "Deliver a real actuator signal", IC_DELIVER_REAL,
                        () -> openWindow(ide, "Deliver Real",
                                () -> UI_Signal_DeliverReal_Main.open(ide))));
    }

    // =====================================================================
    // 5. Environment -- 1 unit
    // =====================================================================
    private static RibbonGroup environmentGroup(UI_Main ide) {
        return new RibbonGroup("Environment", SignalLayout.UNITS_ENVIRONMENT).withItems(
                item("Set", "Set the environment", IC_SET,
                        () -> openWindow(ide, "Set", () -> UI_Signal_Set_Main.open(ide))));
    }

    // =====================================================================
    // Shared plumbing
    // =====================================================================

    /**
     * Builds one icon-on-top ribbon item backed by the theme-aware Signals
     * icon set.
     *
     * <p>
     * Deliberately not routed through {@code RibbonItems}: those helpers load
     * from a fixed path through {@code ToolbarIcons}, whereas these icons come
     * from {@link SignalIcons}, which re-points the views already on screen
     * when the theme changes.
     * </p>
     *
     * @param label    text beneath the icon
     * @param tooltip  full feature description
     * @param iconName icon base name under {@code /icons/SignalIcons}
     * @param action   what to run on click
     * @return the configured button
     */
    private static Button item(String label, String tooltip, String iconName, Runnable action) {
        Button button = new Button(label,
                SignalIcons.icon(iconName, RibbonLayout.ICON_SIZE));
        style(button);
        button.setTooltip(new Tooltip(tooltip));
        button.setOnAction(e -> action.run());
        return button;
    }

    /**
     * Opens a Signals window on the FX thread, reporting any failure to the
     * Command Window rather than letting it vanish into an uncaught handler.
     * Mirrors how the Home band guards its own window construction.
     *
     * @param ide    the IDE controller
     * @param name   feature name, used in the failure message
     * @param opener the window's open call
     */
    private static void openWindow(UI_Main ide, String name, Runnable opener) {
        Platform.runLater(() -> {
            try {
                opener.run();
            } catch (Exception ex) {
                TerminalManager.println(ide, name + " window failed: " + ex.getMessage());
                ex.printStackTrace();
            }
        });
    }

    /**
     * Applies the shared icon-on-top geometry and style hooks, matching what
     * {@code RibbonItems} does for the Home band.
     *
     * @param b the button to style
     */
    private static void style(Labeled b) {
        b.setContentDisplay(ContentDisplay.TOP);
        b.setGraphicTextGap(4);
        b.setAlignment(Pos.CENTER);
        b.setTextAlignment(TextAlignment.CENTER);
        b.setWrapText(false);
        b.setFocusTraversable(false);
        b.setMinHeight(RibbonLayout.ITEM_HEIGHT);
        b.setPrefHeight(RibbonLayout.ITEM_HEIGHT);
        b.setMaxHeight(RibbonLayout.ITEM_HEIGHT);
        // No inline colours: the theme CSS owns the palette.
        b.setStyle("");
        if (!b.getStyleClass().contains("menu-item-button")) {
            b.getStyleClass().add("menu-item-button");
        }
        if (!b.getStyleClass().contains("ribbon-item-button")) {
            b.getStyleClass().add("ribbon-item-button");
        }
    }
}
