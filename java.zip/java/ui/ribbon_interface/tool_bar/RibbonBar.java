package ui.ribbon_interface.tool_bar;

import javafx.scene.control.SkinBase;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.Region;
import ui.design.Dim; 
/**
 * A {@link ToolBar} that hosts exactly one full-width content region and has
 * no overflow behaviour whatsoever.
 *
 * <p>
 * <b>Why this class exists.</b> The stock {@code ToolBarSkin} decides whether
 * an item fits by comparing snapped sizes:
 * </p>
 *
 * <pre>
 *   if (snapSizeX(x) + snapSizeX(node.prefWidth(-1)) &gt; snapSizeX(available))
 *           -&gt; move the node into the overflow popup
 * </pre>
 *
 * <p>
 * {@code snapSizeX} rounds to whole <i>physical</i> pixels. On a display at
 * 100% Windows scaling that grid is 1.0 logical px and a
 * {@code prefWidth = barWidth - CONSTANT} binding lands exactly inside the
 * available width. At 125% the grid becomes 0.8 logical px and at 150% it
 * becomes 0.667; the child's pref width snaps up while the available width
 * snaps down, the comparison flips, and because the band is a single child the
 * <i>entire</i> ribbon disappears into the overflow popup behind a "&gt;&gt;"
 * chevron. That popup is its own window, so it also paints over the panels
 * underneath instead of sitting in the band.
 * </p>
 *
 * <p>
 * The skin below simply resizes its one child to the content box on every
 * layout pass. There is no fitting test, so there is nothing for the snapping
 * grid to get wrong, and the band renders identically at 100%, 125%, 150% and
 * 175%.
 * </p>
 *
 * <p>
 * The class still extends {@code ToolBar} on purpose: {@code UI_Main} declares
 * {@code homeTB} / {@code compileTB} as {@code ToolBar}, and
 * {@code ToolbarStyling}, {@code ToolbarRibbon}, {@code RibbonCollapse} and the
 * toolbar {@code StackPane} all keep working untouched. Note that
 * {@link #getItems()} stays empty by design -- the content is owned by the
 * skin, not by the items list -- so any helper that walks
 * {@code toolbar.getItems()} will simply find nothing here, exactly as it did
 * before when the list held one anonymous {@code HBox}.
 * </p>
 */
public final class RibbonBar extends ToolBar {

    private final Region content;

    /**
     * @param content       the band's root region; it is sized to the bar's
     *                      full content box on every layout pass
     * @param styleClasses  style classes to add, e.g. {@code "menu-toolbar"}
     *                      and {@code "home-ribbon-toolbar"}
     */
    public RibbonBar(Region content, String... styleClasses) {
        this.content = content;

        if (styleClasses != null) {
            for (String styleClass : styleClasses) {
                if (styleClass != null && !getStyleClass().contains(styleClass)) {
                    getStyleClass().add(styleClass);
                }
            }
        }

        // Never let the band impose a minimum width on the window. A ribbon
        // that is too narrow should compress, not force the stage wider or
        // push a horizontal scrollbar onto the layout above it.
        setMinWidth(0);
        content.setMinWidth(0);
        content.setMaxWidth(Double.MAX_VALUE);

        setSkin(new RibbonBarSkin(this, content));
    }

    /**
     * @return the band's root region, for callers that need to reach inside
     *         (a compact-mode listener, a theme repaint, a test)
     */
    public Region getContent() {
        return content;
    }

    // =====================================================================
    // Skin
    // =====================================================================
    private static final class RibbonBarSkin extends SkinBase<ToolBar> {

        private final Region content;

        RibbonBarSkin(ToolBar bar, Region content) {
            super(bar);
            this.content = content;
            getChildren().setAll(content);
        }

        /**
         * The whole point of the class: one child, the full content box, no
         * fitting test and therefore no overflow.
         */
        @Override
        protected void layoutChildren(double contentX, double contentY,
                double contentWidth, double contentHeight) {
            content.resizeRelocate(contentX, contentY, contentWidth, contentHeight);
        }

        @Override
        protected double computeMinWidth(double height, double topInset, double rightInset,
                double bottomInset, double leftInset) {
            // Insets only. The band must always be free to shrink.
            return leftInset + rightInset;
        }

        @Override
        protected double computePrefWidth(double height, double topInset, double rightInset,
                double bottomInset, double leftInset) {
            return leftInset + rightInset + content.prefWidth(height);
        }

        @Override
        protected double computeMaxWidth(double height, double topInset, double rightInset,
                double bottomInset, double leftInset) {
            return Double.MAX_VALUE;
        }

        @Override
        protected double computeMinHeight(double width, double topInset, double rightInset,
                double bottomInset, double leftInset) {
            return topInset + bottomInset +Dim.ToolBand.ROW_HEIGHT;
        }

        @Override
        protected double computePrefHeight(double width, double topInset, double rightInset,
                double bottomInset, double leftInset) {
            return topInset + bottomInset + Dim.ToolBand.ROW_HEIGHT;
        }

        @Override
        protected double computeMaxHeight(double width, double topInset, double rightInset,
                double bottomInset, double leftInset) {
            return computePrefHeight(width, topInset, rightInset, bottomInset, leftInset);
        }
    }
}
