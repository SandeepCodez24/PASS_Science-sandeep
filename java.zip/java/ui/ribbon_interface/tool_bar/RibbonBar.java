package ui.ribbon_interface.tool_bar;

import javafx.scene.control.SkinBase;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.Region;
import ui.design.Dim;

/**
 * A {@link ToolBar} that hosts exactly one full-width content region and has
 * no overflow behaviour whatsoever.
 *
 * <p>
 * <b>Why this class exists.</b> The stock {@code ToolBarSkin} decides whether
 * an item fits by comparing snapped sizes:
 * </p>
 *
 * <pre>
 *   if (snapSizeX(x) + snapSizeX(node.prefWidth(-1)) &gt; snapSizeX(available))
 *           -&gt; move the node into the overflow popup
 * </pre>
 *
 * <p>
 * {@code snapSizeX} rounds to whole <i>physical</i> pixels. At 125% Windows
 * scaling the grid becomes 0.8 logical px and at 150% it becomes 0.667; the
 * child's pref width snaps up while the available width snaps down, the
 * comparison flips, and because the band is a single child the <i>entire</i>
 * ribbon disappears into the overflow popup behind a "&gt;&gt;" chevron.
 * </p>
 *
 * <p>
 * The skin below simply resizes its one child to the content box on every
 * layout pass. There is no fitting test, so there is nothing for the snapping
 * grid to get wrong. Anything that does not fit is the content's own business:
 * {@link RibbonBand} collapses compartments, and the Row-1 strip row in
 * {@code ToolbarRibbon} drops the search box before anything else.
 * </p>
 *
 * <h3>Two uses</h3>
 * <ul>
 * <li><b>Row 2</b> (Home, Signals, Settings): built with its content, at
 * {@code Dim.ToolBand.ROW_HEIGHT}.</li>
 * <li><b>Row 1</b> (the tab strip): built empty in {@code ToolbarSetup} at
 * {@code Dim.RibbonBar.HEIGHT}, and filled later by {@code ToolbarRibbon}
 * through {@link #setContent(Region)}. Row 1 used to be a stock
 * {@code ToolBar}, so it carried the same snapping hazard as Row 2 did.</li>
 * </ul>
 *
 * <p>
 * The class still extends {@code ToolBar} on purpose: {@code UI_Main} and
 * {@code ToolbarState} declare these fields as {@code ToolBar}, and every
 * helper that styles or swaps toolbars keeps working. {@link #getItems()} stays
 * empty by design -- the content is owned by the skin.
 * </p>
 */
public final class RibbonBar extends ToolBar {

    private Region content;
    private final double contentHeight;
    private final RibbonBarSkin skin;

    /**
     * A Row-2 band at {@code Dim.ToolBand.ROW_HEIGHT}.
     *
     * @param content      the band's root region
     * @param styleClasses style classes to add, e.g. {@code "menu-toolbar"}
     *                     and {@code "home-ribbon-toolbar"}
     */
    public RibbonBar(Region content, String... styleClasses) {
        this(content, Dim.ToolBand.ROW_HEIGHT, styleClasses);
    }

    /**
     * A bar of any fixed content height.
     *
     * @param content       the root region; resized to the bar's full content
     *                      box on every layout pass
     * @param contentHeight height of that content box, without the bar's own
     *                      vertical padding
     * @param styleClasses  style classes to add
     */
    public RibbonBar(Region content, double contentHeight, String... styleClasses) {
        this.content = content;
        this.contentHeight = contentHeight;

        if (styleClasses != null) {
            for (String styleClass : styleClasses) {
                if (styleClass != null && !getStyleClass().contains(styleClass)) {
                    getStyleClass().add(styleClass);
                }
            }
        }

        // The bar itself never imposes a minimum width on the window; its
        // content decides what to do when space runs out.
        setMinWidth(0);
        content.setMaxWidth(Double.MAX_VALUE);

        skin = new RibbonBarSkin(this);
        setSkin(skin);
    }

    /**
     * @return the root region, for callers that need to reach inside
     */
    public Region getContent() {
        return content;
    }

    /**
     * Replaces the root region. Used by the Row-1 strip, which is created
     * before the tabs that fill it exist.
     *
     * @param newContent the new root region
     */
    public void setContent(Region newContent) {
        if (newContent == null || newContent == content) {
            return;
        }
        content = newContent;
        content.setMaxWidth(Double.MAX_VALUE);
        skin.refresh();
        requestLayout();
    }

    // =====================================================================
    // Skin
    // =====================================================================
    private static final class RibbonBarSkin extends SkinBase<ToolBar> {

        private final RibbonBar bar;

        RibbonBarSkin(RibbonBar bar) {
            super(bar);
            this.bar = bar;
            refresh();
        }

        void refresh() {
            getChildren().setAll(bar.content);
        }

        /**
         * The whole point of the class: one child, the full content box, no
         * fitting test and therefore no overflow.
         */
        @Override
        protected void layoutChildren(double contentX, double contentY,
                double contentWidth, double contentHeight) {
            bar.content.resizeRelocate(contentX, contentY, contentWidth, contentHeight);
        }

        @Override
        protected double computeMinWidth(double height, double topInset, double rightInset,
                double bottomInset, double leftInset) {
            // Insets only. The stage's minimum width is what keeps the
            // window usable; the bar never forces it wider.
            return leftInset + rightInset;
        }

        @Override
        protected double computePrefWidth(double height, double topInset, double rightInset,
                double bottomInset, double leftInset) {
            return leftInset + rightInset + bar.content.prefWidth(height);
        }

        @Override
        protected double computeMaxWidth(double height, double topInset, double rightInset,
                double bottomInset, double leftInset) {
            return Double.MAX_VALUE;
        }

        @Override
        protected double computeMinHeight(double width, double topInset, double rightInset,
                double bottomInset, double leftInset) {
            return topInset + bottomInset + bar.contentHeight;
        }

        @Override
        protected double computePrefHeight(double width, double topInset, double rightInset,
                double bottomInset, double leftInset) {
            return topInset + bottomInset + bar.contentHeight;
        }

        @Override
        protected double computeMaxHeight(double width, double topInset, double rightInset,
                double bottomInset, double leftInset) {
            return computePrefHeight(width, topInset, rightInset, bottomInset, leftInset);
        }
    }
}
