package ui.ribbon_interface.tool_bar;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBase;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Labeled;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Tooltip;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.TextAlignment;
import ui.design.Dim;
import ui.design.UIScale;
import ui.editor.EditorViewSettings;
import ui.layout.FullScreenToggle;
import ui.layout.LayoutManager;
import ui.layout.WindowLayout;
import ui.ribbon_interface.tool_groups.RibbonGroup;
import ui.ui_functions.tools.LayoutIcons;
import ui.ui_functions.tools.SettingsIcons;

/**
 * The Layout band: the contextual band that takes the Settings band's place
 * when the Layout button is clicked, the way Word swaps in its Equation tools.
 *
 * <pre>
 *  | Visuals | Layouts                                        | View | Gutter          | Zoom        |
 *  | Layout  | Default  Bot  Editor-CLI  Directory  Ed-Bot-CLI | Full | Line     Line   | Reset Zoom  |
 *  |         |          Centered         Centered        Custom| Scrn | Numbers  Folders| Zoom In/Out |
 * </pre>
 *
 * <h3>The Layouts gallery</h3>
 * <p>
 * The six layout tiles sit together in one rounded box -- white on the light
 * theme -- the way MATLAB groups its plot types, so they read as one set of
 * alternatives rather than six loose buttons. The box fills the Layouts
 * compartment; the tiles share its width equally. Its geometry is
 * {@code Dim.Layout.GALLERY_*}; its two colours (outline and fill) are
 * {@code .layout-gallery} in {@code layout_{light,dark}.css}.
 * </p>
 *
 * <h3>Opening and closing</h3>
 * <p>
 * {@link #open()} puts this band into the Settings tab's {@link RibbonBar}
 * with {@link RibbonBar#setContent}; {@link #close()} puts the Settings band
 * back. The band closes on: the Layout button at its left edge (drawn pressed
 * while the band is open), Esc, and switching to another ribbon tab. Picking
 * a layout does not close it, so several can be tried in a row.
 * </p>
 *
 * <h3>State</h3>
 * <p>
 * Every toggle follows the state it controls rather than holding its own:
 * the layout tiles follow {@link LayoutManager#currentProperty()}, Full Screen
 * follows the stage (so Esc and F11 keep it right), and the gutter toggles
 * follow {@link EditorViewSettings}. The Reset Zoom tooltip shows the current
 * zoom level.
 * </p>
 *
 * <p>
 * The band is a {@link RibbonBand}, so on a narrow window its compartments
 * collapse into drop-downs from the right, like every other band. Unit
 * shares are in {@code Dim.Layout}.
 * </p>
 */
public final class LayoutRibbon {

    private static final String TOGGLE_CLASS = "layout-toggle";
    private static final String RETURN_CLASS = "layout-return-button";
    private static final String ZOOM_CLASS = "layout-zoom-button";
    private static final String GALLERY_CLASS = "layout-gallery";
    private static final String TILE_CLASS = "layout-tile";

    /**
     * On every button of this band. The layout CSS selects on it, so its rules
     * outrank the ribbon sheet's, and still apply inside a collapsed
     * compartment's drop-down, which lives outside the band.
     */
    private static final String ITEM_CLASS = "layout-band-item";

    private static RibbonBar bar;
    private static Region settingsBand;
    private static RibbonBand layoutBand;
    private static boolean open;

    private LayoutRibbon() {
    }

    /**
     * Connects the band to the Settings tab's bar. Called once by
     * {@code SettingsRibbon.build}.
     *
     * @param settingsBar the Settings tab's Row-2 bar
     * @param settings    the Settings band, restored on {@link #close()}
     */
    public static void attach(RibbonBar settingsBar, Region settings) {
        bar = settingsBar;
        settingsBand = settings;
        // Switching to another ribbon tab hides this bar; the Settings tab
        // then opens on its own band again.
        bar.visibleProperty().addListener((obs, was, isNow) -> {
            if (!isNow) {
                close();
            }
        });
    }

    /** Shows the Layout band in place of the Settings band. */
    public static void open() {
        if (bar == null || open) {
            return;
        }
        if (layoutBand == null) {
            layoutBand = build();
        }
        bar.setContent(layoutBand);
        open = true;
    }

    /** Puts the Settings band back. Safe to call when the band is closed. */
    public static void close() {
        if (bar == null || !open) {
            return;
        }
        bar.setContent(settingsBand);
        open = false;
    }

    /** Opens the band, or closes it if open. */
    public static void toggle() {
        if (open) {
            close();
        } else {
            open();
        }
    }

    /** @return true while the Layout band is showing */
    public static boolean isOpen() {
        return open;
    }

    // =====================================================================
    // Build
    // =====================================================================

    private static RibbonBand build() {
        RibbonBand band = new RibbonBand(Dim.Layout.TOTAL_UNITS,
                "settings-ribbon-root", "settings-ribbon-toolbar");
        band.getStyleClass().add("layout-ribbon-root");
        band.addGroups(List.of(
                returnGroup(),
                layoutsGroup(),
                viewGroup(),
                gutterGroup(),
                zoomGroup()));
        return band;
    }

    // ---- Visuals: the way back ----------------------------------------------

    private static RibbonGroup returnGroup() {
        Button back = new Button("Layout", SettingsIcons.icon(SettingsIcons.LAYOUT, Dim.ToolBand.ICON_SIZE));
        style(back);
        back.getStyleClass().add(RETURN_CLASS);
        back.setTooltip(new Tooltip("Back to the Settings tools (Esc)"));
        back.setOnAction(e -> close());
        return new RibbonGroup("Visuals", Dim.Layout.UNITS_RETURN).withItems(back);
    }

    // ---- Layouts ------------------------------------------------------------

    private static RibbonGroup layoutsGroup() {
        ToggleGroup group = new ToggleGroup();
        Map<WindowLayout, ToggleButton> tiles = new EnumMap<>(WindowLayout.class);
        GalleryRow gallery = new GalleryRow(Dim.Layout.GALLERY_TILE_SPACING);

        for (WindowLayout layout : WindowLayout.values()) {
            ImageView icon = LayoutIcons.icon(layout.iconName(), Dim.ToolBand.ICON_SIZE);
            if (layout.isArrangement()) {
                ToggleButton tile = new ToggleButton(layout.label(), icon);
                style(tile);
                tile.getStyleClass().add(TOGGLE_CLASS);
                tile.setToggleGroup(group);
                tile.setTooltip(new Tooltip(layout.tooltip()));
                tile.setOnAction(e -> {
                    // A second click would deselect it; the layout on screen
                    // must always stay marked. Clicking it again re-applies
                    // it, which resets its dividers.
                    tile.setSelected(true);
                    LayoutManager.apply(layout);
                });
                tiles.put(layout, tile);
                gallery.getChildren().add(galleryTile(tile));
            } else {
                Button custom = new Button(layout.label(), icon);
                style(custom);
                custom.setTooltip(new Tooltip(layout.tooltip()));
                custom.setOnAction(e -> LayoutManager.apply(layout));
                gallery.getChildren().add(galleryTile(custom));
            }
        }

        Runnable sync = () -> {
            ToggleButton selected = tiles.get(LayoutManager.current());
            if (selected != null) {
                selected.setSelected(true);
            }
        };
        LayoutManager.currentProperty().addListener((obs, was, isNow) -> sync.run());
        sync.run();
        return new RibbonGroup("Layouts", Dim.Layout.UNITS_LAYOUTS).withContent(gallery);
    }

    /**
     * A tile inside the gallery: the ordinary item geometry, a little shorter
     * so the tiles, the box padding and its outline together are exactly one
     * item row high.
     */
    private static ButtonBase galleryTile(ButtonBase tile) {
        tile.setMinHeight(Dim.Layout.GALLERY_TILE_HEIGHT);
        tile.setPrefHeight(Dim.Layout.GALLERY_TILE_HEIGHT);
        tile.setMaxHeight(Dim.Layout.GALLERY_TILE_HEIGHT);
        tile.setMaxWidth(Double.MAX_VALUE);
        // Transparent inside the box (see .layout-tile in the layout CSS), so
        // the white fill shows through every tile but the selected one.
        tile.getStyleClass().add(TILE_CLASS);
        return tile;
    }

    // ---- View: Full Screen ----------------------------------------------------

    private static RibbonGroup viewGroup() {
        ImageView icon = LayoutIcons.icon(LayoutIcons.FULLSCREEN_ENTER, Dim.ToolBand.ICON_SIZE);
        ToggleButton full = new ToggleButton("Full Screen", icon);
        style(full);
        full.getStyleClass().add(TOGGLE_CLASS);

        Runnable sync = () -> {
            boolean on = FullScreenToggle.isFullScreen();
            full.setSelected(on);
            LayoutIcons.setName(icon, on ? LayoutIcons.FULLSCREEN_EXIT : LayoutIcons.FULLSCREEN_ENTER);
            full.setTooltip(new Tooltip(on ? "Leave full screen (Esc / F11)" : "Full screen (F11)"));
        };
        full.setOnAction(e -> {
            FullScreenToggle.toggle();
            sync.run();
        });
        FullScreenToggle.fullScreenProperty().addListener((obs, was, isNow) -> sync.run());
        sync.run();
        return new RibbonGroup("View", Dim.Layout.UNITS_VIEW).withItems(full);
    }

    // ---- Gutter: Line Numbers, Line Folders ----------------------------------

    private static RibbonGroup gutterGroup() {
        ToggleButton numbers = new ToggleButton("Line Numbers",
                LayoutIcons.icon(LayoutIcons.LINE_NUMBERS, Dim.ToolBand.ICON_SIZE));
        style(numbers);
        numbers.getStyleClass().add(TOGGLE_CLASS);
        numbers.setTooltip(new Tooltip("Show or hide line numbers in the editor gutter"));
        numbers.setSelected(EditorViewSettings.showLineNumbers());
        numbers.setOnAction(e -> EditorViewSettings.setLineNumbers(numbers.isSelected()));
        EditorViewSettings.lineNumbersProperty().addListener((obs, was, isNow) -> numbers.setSelected(isNow));

        ToggleButton folders = new ToggleButton("Line Folders",
                LayoutIcons.icon(LayoutIcons.LINE_FOLDERS, Dim.ToolBand.ICON_SIZE));
        style(folders);
        folders.getStyleClass().add(TOGGLE_CLASS);
        folders.setTooltip(new Tooltip(
                "Show or hide the fold column in the editor gutter.\nHiding it expands every collapsed block."));
        folders.setSelected(EditorViewSettings.showLineFolders());
        folders.setOnAction(e -> EditorViewSettings.setLineFolders(folders.isSelected()));
        EditorViewSettings.lineFoldersProperty().addListener((obs, was, isNow) -> folders.setSelected(isNow));

        return new RibbonGroup("Gutter", Dim.Layout.UNITS_GUTTER).withItems(numbers, folders);
    }

    // ---- Zoom: three small rows -------------------------------------------------

    private static RibbonGroup zoomGroup() {
        Button reset = zoomRow("Reset Zoom", LayoutIcons.ZOOM_RESET, EditorViewSettings::resetZoom);
        Button in = zoomRow("Zoom In", LayoutIcons.ZOOM_IN, EditorViewSettings::zoomIn);
        Button out = zoomRow("Zoom Out", LayoutIcons.ZOOM_OUT, EditorViewSettings::zoomOut);
        // Each button is enabled only when it would change something: Reset
        // away from 100%, Zoom In below the 500% cap, Zoom Out above 10%. The
        // tooltips carry the current level and the step.
        Runnable sync = () -> {
            String now = "\nNow: " + EditorViewSettings.zoomPercent();
            reset.setDisable(EditorViewSettings.isDefaultZoom());
            in.setDisable(EditorViewSettings.isMaxZoom());
            out.setDisable(EditorViewSettings.isMinZoom());
            reset.setTooltip(new Tooltip("Back to the default view, 100% (Ctrl + 0)" + now));
            in.setTooltip(new Tooltip("Zoom in the editor by 15%, up to 500% (Ctrl + =, Ctrl + wheel)" + now));
            out.setTooltip(new Tooltip("Zoom out the editor by 10%, down to 10% (Ctrl + -, Ctrl + wheel)" + now));
        };
        EditorViewSettings.zoomProperty().addListener((obs, was, isNow) -> sync.run());
        sync.run();

        VBox rows = new VBox(Dim.Layout.ZOOM_ROW_SPACING, reset, in, out);
        rows.setAlignment(Pos.CENTER_LEFT);
        rows.setFillWidth(true);
        rows.getStyleClass().add("layout-zoom-rows");
        return new RibbonGroup("Zoom", Dim.Layout.UNITS_ZOOM).withContent(rows);
    }

    private static Button zoomRow(String text, String iconName, Runnable action) {
        Button b = new Button(text, LayoutIcons.icon(iconName, Dim.Layout.ZOOM_ICON_SIZE));
        b.setContentDisplay(ContentDisplay.LEFT);
        b.setGraphicTextGap(Dim.Layout.ZOOM_GRAPHIC_GAP);
        b.setAlignment(Pos.CENTER_LEFT);
        b.setFocusTraversable(false);
        b.setWrapText(false);
        b.setPadding(new Insets(Dim.Layout.ZOOM_ROW_PAD_V, Dim.Layout.ZOOM_ROW_PAD_H,
                Dim.Layout.ZOOM_ROW_PAD_V, Dim.Layout.ZOOM_ROW_PAD_H));
        b.setMinHeight(Dim.Layout.ZOOM_ROW_HEIGHT);
        b.setPrefHeight(Dim.Layout.ZOOM_ROW_HEIGHT);
        b.setMaxHeight(Dim.Layout.ZOOM_ROW_HEIGHT);
        b.setMinWidth(Region.USE_PREF_SIZE);
        b.setMaxWidth(Double.MAX_VALUE);
        b.getStyleClass().addAll("menu-item-button", ITEM_CLASS, ZOOM_CLASS);
        // Shape from the design layer, colour from layout_{light,dark}.css.
        b.setStyle("-fx-background-radius: " + UIScale.fmt(Dim.ToolBand.ITEM_RADIUS) + ";");
        b.setOnAction(e -> action.run());
        return b;
    }

    // =====================================================================
    // Shared styling
    // =====================================================================

    /** Same icon-on-top geometry and style hooks as the other bands. */
    private static void style(ButtonBase b) {
        styleLabeled(b);
        b.setFocusTraversable(false);
        b.getStyleClass().add(ITEM_CLASS);
    }

    private static void styleLabeled(Labeled b) {
        b.setContentDisplay(ContentDisplay.TOP);
        b.setGraphicTextGap(Dim.ToolBand.ITEM_GRAPHIC_GAP);
        b.setAlignment(Pos.CENTER);
        b.setTextAlignment(TextAlignment.CENTER);
        b.setWrapText(false);
        b.setMinHeight(Dim.ToolBand.ITEM_HEIGHT);
        b.setPrefHeight(Dim.ToolBand.ITEM_HEIGHT);
        b.setMaxHeight(Dim.ToolBand.ITEM_HEIGHT);
        // Never narrower than its label; see RibbonBand.
        b.setMinWidth(Region.USE_PREF_SIZE);
        b.setStyle("");
        if (!b.getStyleClass().contains("menu-item-button")) {
            b.getStyleClass().add("menu-item-button");
        }
        if (!b.getStyleClass().contains("ribbon-item-button")) {
            b.getStyleClass().add("ribbon-item-button");
        }
    }

    // =====================================================================
    // The gallery box
    // =====================================================================

    /**
     * The rounded box around the layout tiles. A row of equal-width tiles:
     * each is as wide as the widest label needs, and any extra width the
     * compartment gives the box is shared equally, so the tiles always spread
     * across the whole box.
     *
     * <p>
     * Its minimum width is its natural width, so a label is never cut to
     * "..."; when the band runs short, {@link RibbonBand} collapses the whole
     * compartment into a drop-down instead, as it does everywhere else.
     * </p>
     */
    private static final class GalleryRow extends Pane {

        private final double gap;

        GalleryRow(double gap) {
            this.gap = gap;
            getStyleClass().add(GALLERY_CLASS);
            double b = Dim.Layout.GALLERY_BORDER;
            setPadding(new Insets(Dim.Layout.GALLERY_PAD_V + b, Dim.Layout.GALLERY_PAD_H + b,
                    Dim.Layout.GALLERY_PAD_V + b, Dim.Layout.GALLERY_PAD_H + b));
            // The box paints itself: outline layer, then the fill inset by the
            // outline width. Inline, so no ribbon stylesheet rule can repaint
            // it; the two colours are looked up from the theme CSS
            // (-layout-gallery-outline / -layout-gallery-fill), so the sheet
            // still decides what they are.
            double r = Dim.Layout.GALLERY_RADIUS;
            setStyle("-fx-background-color: -layout-gallery-outline, -layout-gallery-fill;"
                    + " -fx-background-radius: " + UIScale.fmt(r) + ", " + UIScale.fmt(Math.max(0, r - b)) + ";"
                    + " -fx-background-insets: 0, " + UIScale.fmt(b) + ";");
        }

        /**
         * The width every tile needs: the widest label's, in whole pixels,
         * plus the slack guard.
         */
        private double widest() {
            double max = 0;
            for (Node child : getManagedChildren()) {
                max = Math.max(max, child.prefWidth(-1));
            }
            return Math.ceil(max) + Dim.Layout.GALLERY_TILE_SLACK;
        }

        private double naturalWidth() {
            int n = getManagedChildren().size();
            Insets in = getInsets();
            return Math.ceil(in.getLeft() + in.getRight() + n * widest() + Math.max(0, n - 1) * gap);
        }

        @Override
        protected double computePrefWidth(double height) {
            return naturalWidth();
        }

        @Override
        protected double computeMinWidth(double height) {
            return naturalWidth();
        }

        @Override
        protected double computePrefHeight(double width) {
            Insets in = getInsets();
            double tallest = 0;
            for (Node child : getManagedChildren()) {
                tallest = Math.max(tallest, child.prefHeight(-1));
            }
            return snapSizeY(in.getTop() + in.getBottom() + tallest);
        }

        @Override
        protected double computeMinHeight(double width) {
            return computePrefHeight(width);
        }

        @Override
        protected void layoutChildren() {
            List<Node> children = getManagedChildren();
            int n = children.size();
            if (n == 0) {
                return;
            }
            Insets in = getInsets();
            double top = in.getTop();
            double height = Math.max(0, getHeight() - in.getTop() - in.getBottom());
            double inner = Math.max(0, getWidth() - in.getLeft() - in.getRight() - (n - 1) * gap);
            // Whole-pixel columns: snapping each edge separately could shave a
            // fraction off a tile, and a label a fraction too narrow is cut to
            // "...". Every tile gets the same whole width; the leftover pixels
            // (fewer than n) go to the last tile.
            double column = Math.floor(inner / n);
            double leftover = inner - column * n;
            double x = Math.round(in.getLeft());
            for (int i = 0; i < n; i++) {
                Node child = children.get(i);
                double w = column + (i == n - 1 ? leftover : 0);
                double h = Math.min(height, child.prefHeight(w));
                child.resizeRelocate(x, top + (height - h) / 2, w, h);
                x += Math.round(column + gap);
            }
        }
    }
}
