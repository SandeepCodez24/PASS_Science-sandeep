package ui.ribbon_interface.tool_bar;

import javafx.beans.binding.DoubleBinding;
import javafx.scene.layout.Region;
import ui.design.section_dims.SettingsBand_dim;

/**
 * Layout behaviour for the Settings band.
 *
 * <p>
 * The unit ratios live in {@link SettingsBand_dim}; the shared band geometry
 * (heights, icon size, divider, horizontal inset) lives in
 * {@code Dim.ToolBand}, where Home and Signals read it too.
 * {@code DesignStylesheet} gives {@code .settings-ribbon-toolbar} the same
 * padding as the other two bands, which is what the unit maths assumes.
 * </p>
 *
 * <pre>
 *  | Visuals | Plots | Networks |              free               |
 *  |    3    |   1   |    1     |               11                |
 * </pre>
 */
public final class SettingsLayout {

    private SettingsLayout() {
    }

    /**
     * Width of one layout unit, live-bound to the owning ToolBar.
     *
     * @param owner the Settings ToolBar whose width drives the layout
     * @return a binding that always yields a non-negative unit width
     */
    public static DoubleBinding unitWidth(Region owner) {
        return RibbonLayout.unitWidth(owner, SettingsBand_dim.SEPARATOR_COUNT, SettingsBand_dim.TOTAL_UNITS);
    }
}
