package ui.ribbon_interface.tool_bar;

import java.util.List;

import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Labeled;
import javafx.scene.control.ToolBar;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.Region;
import javafx.scene.text.TextAlignment;
import ui.UI_Main;
import ui.design.Dim;
import ui.design.section_dims.SettingsBand_dim;
import ui.editor.settingsTab.UI_Settings_Layout_Main;
import ui.editor.settingsTab.UI_Settings_Networks_Main;
import ui.editor.settingsTab.UI_Settings_Plots_Main;
import ui.editor.settingsTab.UI_Settings_Syntax_Main;
import ui.editor.settingsTab.UI_Settings_Theme_Main;
import ui.managers.TerminalManager;
import ui.ribbon_interface.tool_groups.RibbonGroup;
import ui.ui_functions.tools.SettingsIcons;

/**
 * Builds the Settings tab's ribbon band, replacing the old flat row of dummy
 * buttons (Editor, Fonts, Formatter, Keymap, Layout, Terminal, Theme, Reset).
 *
 * <p>
 * Three compartments span the band in the ratio 3:1:1 out of 16 units,
 * divided by the same dark-grey vertical rules the Home and Signals bands use,
 * with 11 units left free at the right-hand edge:
 * </p>
 *
 * <pre>
 *   Visuals    Layout / Theme / Syntax
 *   Plots      Plot Setup
 *   Networks   Net Setup
 * </pre>
 *
 * <p>
 * Syntax is live: it opens the suggestion settings, the same window the
 * suggestion popup's "Settings..." entry opens. Every other button opens its
 * own "under development" window under {@code ui.editor.settingsTab}; one file
 * per button, so each can be built out separately.
 * </p>
 */
public final class SettingsRibbon {

    private SettingsRibbon() {
    }

    /**
     * Builds the Settings band.
     *
     * @param ide the IDE controller
     * @return the Settings ToolBar, ready to drop into the toolbar StackPane
     */
    public static ToolBar build(UI_Main ide) {

        List<RibbonGroup> groups = List.of(
                visualsGroup(ide),
                plotsGroup(ide),
                networksGroup(ide));

        // Each compartment gets max(units x unit, natural width); when even
        // the natural widths do not fit, compartments collapse right to left
        // into drop-down buttons. No label is ever cut to "...".
        RibbonBand band = new RibbonBand(SettingsBand_dim.TOTAL_UNITS,
                "settings-ribbon-root", "settings-ribbon-toolbar");
        band.addGroups(groups);

        // RibbonBar, not ToolBar: the stock ToolBarSkin's snapped fit test
        // sends the whole band into the ">>" overflow popup on displays that
        // are not at 100% scaling. See RibbonBar.
        RibbonBar bar = new RibbonBar(band, "menu-toolbar", "settings-ribbon-toolbar");
        bar.setPrefHeight(Dim.ToolBand.ROW_HEIGHT);
        bar.setMinHeight(Dim.ToolBand.ROW_HEIGHT);

        return bar;
    }

    // =====================================================================
    // 1. Visuals -- 3 units
    // =====================================================================
    private static RibbonGroup visualsGroup(UI_Main ide) {
        return new RibbonGroup("Visuals", SettingsBand_dim.UNITS_VISUALS).withItems(
                item("Layout", "Window and panel layout", SettingsIcons.LAYOUT,
                        () -> openWindow(ide, "Layout", () -> UI_Settings_Layout_Main.open(ide))),
                item("Theme", "Colour theme", SettingsIcons.THEME,
                        () -> openWindow(ide, "Theme", () -> UI_Settings_Theme_Main.open(ide))),
                item("Syntax", "Suggestion box and end auto fill settings", SettingsIcons.SYNTAX,
                        () -> openWindow(ide, "Syntax", () -> UI_Settings_Syntax_Main.open(ide))));
    }

    // =====================================================================
    // 2. Plots -- 1 unit
    // =====================================================================
    private static RibbonGroup plotsGroup(UI_Main ide) {
        return new RibbonGroup("Plots", SettingsBand_dim.UNITS_PLOTS).withItems(
                item("Plot Setup", "Plot window defaults", SettingsIcons.PLOTS,
                        () -> openWindow(ide, "Plot Setup", () -> UI_Settings_Plots_Main.open(ide))));
    }

    // =====================================================================
    // 3. Networks -- 1 unit
    // =====================================================================
    private static RibbonGroup networksGroup(UI_Main ide) {
        return new RibbonGroup("Networks", SettingsBand_dim.UNITS_NETWORKS).withItems(
                item("Net Setup", "Neural network defaults", SettingsIcons.NETWORKS,
                        () -> openWindow(ide, "Net Setup", () -> UI_Settings_Networks_Main.open(ide))));
    }

    // =====================================================================
    // Shared plumbing
    // =====================================================================

    /**
     * One icon-on-top ribbon item backed by the theme-aware Settings icons.
     *
     * @param label    text beneath the icon
     * @param tooltip  full feature description
     * @param iconName icon base name under {@code /icons/SettingsIcons}
     * @param action   what to run on click
     * @return the configured button
     */
    private static Button item(String label, String tooltip, String iconName, Runnable action) {
        Button button = new Button(label, SettingsIcons.icon(iconName, Dim.ToolBand.ICON_SIZE));
        style(button);
        button.setTooltip(new Tooltip(tooltip));
        button.setOnAction(e -> action.run());
        return button;
    }

    /**
     * Opens a Settings window on the FX thread, reporting any failure to the
     * Command Window rather than letting it vanish.
     */
    private static void openWindow(UI_Main ide, String name, Runnable opener) {
        Platform.runLater(() -> {
            try {
                opener.run();
            } catch (Exception ex) {
                TerminalManager.println(ide, name + " window failed: " + ex.getMessage());
                ex.printStackTrace();
            }
        });
    }

    /** Same icon-on-top geometry and style hooks as the other two bands. */
    private static void style(Labeled b) {
        b.setContentDisplay(ContentDisplay.TOP);
        b.setGraphicTextGap(4);
        b.setAlignment(Pos.CENTER);
        b.setTextAlignment(TextAlignment.CENTER);
        b.setWrapText(false);
        b.setFocusTraversable(false);
        b.setMinHeight(Dim.ToolBand.ITEM_HEIGHT);
        b.setPrefHeight(Dim.ToolBand.ITEM_HEIGHT);
        b.setMaxHeight(Dim.ToolBand.ITEM_HEIGHT);
        // Never narrower than its label; see RibbonBand.
        b.setMinWidth(Region.USE_PREF_SIZE);
        b.setStyle("");
        if (!b.getStyleClass().contains("menu-item-button")) {
            b.getStyleClass().add("menu-item-button");
        }
        if (!b.getStyleClass().contains("ribbon-item-button")) {
            b.getStyleClass().add("ribbon-item-button");
        }
    }
}
