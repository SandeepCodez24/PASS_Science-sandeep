package ui.ribbon_interface.tool_bar;

import javafx.beans.binding.DoubleBinding;
import javafx.scene.layout.Region;
import ui.design.Dim;

/**
 * Layout behaviour for the Signals band.
 *
 * <h3>What changed</h3>
 * <p>
 * The unit ratios now live in {@code ui.design.Dim.ToolBand.Signals}, and the
 * shared band geometry (heights, icon size, divider, horizontal inset) lives in
 * {@code Dim.ToolBand} where Home reads it too. The comment this file used to
 * carry -- keep {@code .signal-ribbon-toolbar} in step with
 * {@code .home-ribbon-toolbar} or the 14-unit ratios drift -- is no longer
 * something anyone has to remember: {@code DesignStylesheet} emits both
 * paddings from the same constant.
 * </p>
 *
 * <pre>
 *  | Sensors | Series | Domain | Actuators | Env |    free    |
 *  |   3.5   |    2   |    1   |    3.5    |  1  |      3     |
 *  |&lt;--------------------- 14 units ---------------------&gt;|
 * </pre>
 */
public final class SignalLayout {

    /** @deprecated use {@code Dim.ToolBand.Signals.TOTAL_UNITS} */
    @Deprecated
    public static final double TOTAL_UNITS = Dim.ToolBand.Signals.TOTAL_UNITS;

    /** @deprecated use {@code Dim.ToolBand.Signals.UNITS_SENSORS} */
    @Deprecated
    public static final double UNITS_SENSORS = Dim.ToolBand.Signals.UNITS_SENSORS;

    /** @deprecated use {@code Dim.ToolBand.Signals.UNITS_SERIES} */
    @Deprecated
    public static final double UNITS_SERIES = Dim.ToolBand.Signals.UNITS_SERIES;

    /** @deprecated use {@code Dim.ToolBand.Signals.UNITS_DOMAIN} */
    @Deprecated
    public static final double UNITS_DOMAIN = Dim.ToolBand.Signals.UNITS_DOMAIN;

    /** @deprecated use {@code Dim.ToolBand.Signals.UNITS_ACTUATORS} */
    @Deprecated
    public static final double UNITS_ACTUATORS = Dim.ToolBand.Signals.UNITS_ACTUATORS;

    /** @deprecated use {@code Dim.ToolBand.Signals.UNITS_ENVIRONMENT} */
    @Deprecated
    public static final double UNITS_ENVIRONMENT = Dim.ToolBand.Signals.UNITS_ENVIRONMENT;

    /** @deprecated use {@code Dim.ToolBand.Signals.FREE_UNITS} */
    @Deprecated
    public static final double FREE_UNITS = Dim.ToolBand.Signals.FREE_UNITS;

    /** @deprecated use {@code Dim.ToolBand.Signals.SEPARATOR_COUNT} */
    @Deprecated
    public static final int SEPARATOR_COUNT = Dim.ToolBand.Signals.SEPARATOR_COUNT;

    private SignalLayout() {
    }

    /**
     * Width of one layout unit, live-bound to the owning ToolBar.
     *
     * @param owner          the Signals ToolBar whose width drives the layout
     * @param separatorCount number of vertical dividers
     * @return a binding that always yields a non-negative unit width
     */
    public static DoubleBinding unitWidth(Region owner, int separatorCount) {
        return RibbonLayout.unitWidth(owner, separatorCount, Dim.ToolBand.Signals.TOTAL_UNITS);
    }
}
