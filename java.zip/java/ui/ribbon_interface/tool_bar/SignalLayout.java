package ui.ribbon_interface.tool_bar;

import javafx.beans.binding.Bindings;
import javafx.beans.binding.DoubleBinding;
import javafx.scene.layout.Region;

/**
 * Geometry for the Signals band.
 *
 * <p>
 * Separate from {@link RibbonLayout} because the two bands are divided
 * differently: Home splits its width into 16 units, Signals into 14. Heights,
 * icon size and the divider itself are still taken from {@code RibbonLayout},
 * since both bands share one {@code StackPane} and must agree on how tall a
 * row is.
 * </p>
 *
 * <pre>
 *  | Sensors | Series | Domain | Actuators | Env |     free      |
 *  |   3.5   |    2   |    1   |    3.5    |  1  |       3       |
 *  |&lt;-------------------------- 14 units ------------------------&gt;|
 * </pre>
 *
 * <p>
 * Five dividers are drawn, one after each compartment -- including one after
 * Environment, so the free space at the trailing edge is fenced off rather than
 * bleeding into the Set button.
 * </p>
 */
public final class SignalLayout {

    /** The Signals band width is always divided into this many equal units. */
    public static final double TOTAL_UNITS = 14;

    /** Sensors: Feed Artificial, the compare control, Feed Real. */
    public static final double UNITS_SENSORS = 3.5;

    /** Series: Fit, Process, Extract. */
    public static final double UNITS_SERIES = 2;

    /** Domain: Transform. */
    public static final double UNITS_DOMAIN = 1;

    /** Actuators: Deliver Artificial, the compare control, Deliver Real. */
    public static final double UNITS_ACTUATORS = 3.5;

    /** Environment: Set. */
    public static final double UNITS_ENVIRONMENT = 1;

    /** Units intentionally left free on the right-hand side. */
    public static final double FREE_UNITS = 3;

    /** Number of dividers drawn: one after each of the five compartments. */
    public static final int SEPARATOR_COUNT = 5;

    private SignalLayout() {
    }

    /**
     * Width of one layout unit, live-bound to the owning ToolBar.
     *
     * <p>
     * Mirrors {@link RibbonLayout#unitWidth(Region, int)} but divides by
     * {@link #TOTAL_UNITS}. The horizontal inset is shared with Home, so
     * {@code .signal-ribbon-toolbar} must carry the same
     * {@code -fx-padding: 4 10 4 10} as {@code .home-ribbon-toolbar}.
     * </p>
     *
     * @param owner          the Signals ToolBar whose width drives the layout
     * @param separatorCount number of vertical dividers
     * @return a binding that always yields a non-negative unit width
     */
    public static DoubleBinding unitWidth(Region owner, int separatorCount) {
        final double fixed = RibbonLayout.TOOLBAR_H_INSET
                + (separatorCount * RibbonLayout.SEPARATOR_WIDTH);
        return Bindings.createDoubleBinding(
                () -> Math.max(0, (owner.getWidth() - fixed) / TOTAL_UNITS),
                owner.widthProperty());
    }
}
