package ui.ribbon_interface.tool_bar;

import javafx.beans.binding.DoubleBinding;
import javafx.scene.layout.Region;
import ui.design.Dim;

/**
 * Layout behaviour for the Signals band.
 *
 * <p>
 * The unit ratios live in {@code ui.design.Dim.ToolBand.Signals}, and the
 * shared band geometry (heights, icon size, divider, horizontal inset) lives in
 * {@code Dim.ToolBand} where Home reads it too. {@code DesignStylesheet} emits
 * both bands' paddings from the same constant, so the 14-unit ratios cannot
 * drift away from the Home band's.
 * </p>
 *
 * <pre>
 *  | Sensors | Series | Domain | Actuators | Env |    free    |
 *  |   3.5   |    2   |    1   |    3.5    |  1  |      3     |
 *  |&lt;--------------------- 14 units ---------------------&gt;|
 * </pre>
 */
public final class SignalLayout {

    private SignalLayout() {
    }

    /**
     * Width of one layout unit, live-bound to the owning ToolBar, using the
     * band's standard divider count ({@code Dim.ToolBand.Signals.SEPARATOR_COUNT}).
     *
     * @param owner the Signals ToolBar whose width drives the layout
     * @return a binding that always yields a non-negative unit width
     */
    public static DoubleBinding unitWidth(Region owner) {
        return unitWidth(owner, Dim.ToolBand.Signals.SEPARATOR_COUNT);
    }

    /**
     * Width of one layout unit, live-bound to the owning ToolBar.
     *
     * @param owner          the Signals ToolBar whose width drives the layout
     * @param separatorCount number of vertical dividers
     * @return a binding that always yields a non-negative unit width
     */
    public static DoubleBinding unitWidth(Region owner, int separatorCount) {
        return RibbonLayout.unitWidth(owner, separatorCount, Dim.ToolBand.Signals.TOTAL_UNITS);
    }
}
