package ui.ribbon_interface.tool_bar;

import javafx.beans.binding.Bindings;
import javafx.beans.binding.DoubleBinding;
import javafx.geometry.Insets;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import ui.design.Dim;

/**
 * Layout behaviour for the Home band.
 *
 * <h3>What changed</h3>
 * <p>
 * This class used to own the band's numbers as well as its behaviour. The
 * numbers now live in {@code ui.design.Dim.ToolBand} and
 * {@code Dim.ToolBand.Home}, alongside every other dimension in the
 * application, and {@code ui.design.DesignStylesheet} emits the matching CSS.
 * That removes the coupling this file used to warn about: the horizontal inset
 * and the {@code -fx-padding} on {@code .home-ribbon-toolbar} are now one
 * constant, so they cannot drift apart.
 * </p>
 * <p>
 * What remains here is behaviour -- the live unit-width binding and the
 * separator factory -- plus a short list of aliases so existing call sites keep
 * compiling. Prefer the {@code Dim} constants in new code.
 * </p>
 *
 * <pre>
 *  | Files |  Data  | Vis | Mod | Grp | Compute | Analysis | AI |   free   |
 *  |   2   |    2   |  1  |  1  |  1  |    2    |     2    |  1 |     4    |
 *  |&lt;------------------------- 16 units -------------------------&gt;|
 * </pre>
 */
public final class RibbonLayout {

    /** @deprecated use {@code Dim.ToolBand.Home.TOTAL_UNITS} */
    @Deprecated
    public static final double TOTAL_UNITS = Dim.ToolBand.Home.TOTAL_UNITS;

    /** @deprecated use {@code Dim.ToolBand.Home.USED_UNITS} */
    @Deprecated
    public static final double USED_UNITS = Dim.ToolBand.Home.USED_UNITS;

    /** @deprecated use {@code Dim.ToolBand.Home.FREE_UNITS} */
    @Deprecated
    public static final double FREE_UNITS = Dim.ToolBand.Home.FREE_UNITS;

    /** @deprecated use {@code Dim.ToolBand.SEPARATOR_WIDTH} */
    @Deprecated
    public static final double SEPARATOR_WIDTH = Dim.ToolBand.SEPARATOR_WIDTH;

    /** @deprecated use {@code Dim.ToolBand.H_INSET} */
    @Deprecated
    public static final double TOOLBAR_H_INSET = Dim.ToolBand.H_INSET;

    /** @deprecated use {@code Dim.ToolBand.ITEM_HEIGHT} */
    @Deprecated
    public static final double ITEM_HEIGHT = Dim.ToolBand.ITEM_HEIGHT;

    /** @deprecated use {@code Dim.ToolBand.CAPTION_HEIGHT} */
    @Deprecated
    public static final double CAPTION_HEIGHT = Dim.ToolBand.CAPTION_HEIGHT;

    /** @deprecated use {@code Dim.ToolBand.GROUP_SPACING} */
    @Deprecated
    public static final double GROUP_SPACING = Dim.ToolBand.GROUP_SPACING;

    /** @deprecated use {@code Dim.ToolBand.ROW_HEIGHT} */
    @Deprecated
    public static final double ROW_HEIGHT = Dim.ToolBand.ROW_HEIGHT;

    /** @deprecated use {@code Dim.ToolBand.ICON_SIZE} */
    @Deprecated
    public static final double ICON_SIZE = Dim.ToolBand.ICON_SIZE;

    private RibbonLayout() {
    }

    /**
     * Width of one layout unit, live-bound to the owning ToolBar.
     *
     * @param owner          the Home ToolBar whose width drives the layout
     * @param separatorCount number of vertical dividers
     * @return a binding that always yields a non-negative unit width
     */
    public static DoubleBinding unitWidth(Region owner, int separatorCount) {
        return unitWidth(owner, separatorCount, Dim.ToolBand.Home.TOTAL_UNITS);
    }

    /**
     * Width of one layout unit for a band with a given unit count.
     *
     * <p>
     * Shared by Home and Signals: the two bands differ only in how many units
     * they divide into, and the inset and divider width are common to both.
     * </p>
     *
     * @param owner          the ToolBar whose width drives the layout
     * @param separatorCount number of vertical dividers
     * @param totalUnits     the band's unit count
     * @return a binding that always yields a non-negative unit width
     */
    public static DoubleBinding unitWidth(Region owner, int separatorCount, double totalUnits) {
        final double fixed = Dim.ToolBand.H_INSET
                + (separatorCount * Dim.ToolBand.SEPARATOR_WIDTH);
        return Bindings.createDoubleBinding(
                () -> Math.max(0, (owner.getWidth() - fixed) / totalUnits),
                owner.widthProperty());
    }

    /**
     * A mild vertical divider. The colour lives in the theme CSS
     * ({@code .ribbon-group-separator}); the width and the vertical inset come
     * from {@code Dim.ToolBand}.
     *
     * @return a full-height divider, inset slightly top and bottom
     */
    public static Region separator() {
        Region sep = new Region();
        sep.getStyleClass().add("ribbon-group-separator");
        sep.setMinWidth(Dim.ToolBand.SEPARATOR_WIDTH);
        sep.setPrefWidth(Dim.ToolBand.SEPARATOR_WIDTH);
        sep.setMaxWidth(Dim.ToolBand.SEPARATOR_WIDTH);
        sep.setMaxHeight(Double.MAX_VALUE);
        HBox.setMargin(sep, new Insets(
                Dim.ToolBand.SEPARATOR_MARGIN_V, 0, Dim.ToolBand.SEPARATOR_MARGIN_V, 0));
        return sep;
    }
}
