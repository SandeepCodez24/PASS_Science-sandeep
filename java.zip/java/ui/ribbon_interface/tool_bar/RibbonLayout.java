package ui.ribbon_interface.tool_bar;

import javafx.beans.binding.Bindings;
import javafx.beans.binding.DoubleBinding;
import javafx.geometry.Insets;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import ui.design.Dim;

/**
 * Layout behaviour shared by the ribbon bands.
 *
 * <p>
 * This class holds behaviour only: the live unit-width binding and the
 * separator factory. Every number the bands use lives in {@code ui.design.Dim}
 * ({@code Dim.ToolBand}, {@code Dim.ToolBand.Home}, {@code Dim.ToolBand.Signals})
 * and {@code ui.design.DesignStylesheet} emits the matching CSS, so the Java
 * geometry and the stylesheet can never drift apart.
 * </p>
 *
 * <pre>
 *  | Files |  Data  | Vis | Mod | Grp | Compute | Analysis | AI |   free   |
 *  |   2   |    2   |  1  |  1  |  1  |    2    |     2    |  1 |     4    |
 *  |&lt;------------------------- 16 units -------------------------&gt;|
 * </pre>
 */
public final class RibbonLayout {

    private RibbonLayout() {
    }

    /**
     * Width of one layout unit for the Home band, live-bound to its ToolBar.
     *
     * @param owner          the Home ToolBar whose width drives the layout
     * @param separatorCount number of vertical dividers
     * @return a binding that always yields a non-negative unit width
     */
    public static DoubleBinding unitWidth(Region owner, int separatorCount) {
        return unitWidth(owner, separatorCount, Dim.ToolBand.Home.TOTAL_UNITS);
    }

    /**
     * Width of one layout unit for a band with a given unit count.
     *
     * <p>
     * Shared by every band: they differ only in how many units they divide
     * into, and the inset and divider width are common to all of them.
     * </p>
     *
     * @param owner          the ToolBar whose width drives the layout
     * @param separatorCount number of vertical dividers
     * @param totalUnits     the band's unit count
     * @return a binding that always yields a non-negative unit width
     */
    public static DoubleBinding unitWidth(Region owner, int separatorCount, double totalUnits) {
        final double fixed = Dim.ToolBand.H_INSET
                + (separatorCount * Dim.ToolBand.SEPARATOR_WIDTH);
        return Bindings.createDoubleBinding(
                () -> Math.max(0, (owner.getWidth() - fixed) / totalUnits),
                owner.widthProperty());
    }

    /**
     * A mild vertical divider. The colour lives in the theme CSS
     * ({@code .ribbon-group-separator}); the width and the vertical inset come
     * from {@code Dim.ToolBand}.
     *
     * @return a full-height divider, inset slightly top and bottom
     */
    public static Region separator() {
        Region sep = new Region();
        sep.getStyleClass().add("ribbon-group-separator");
        sep.setMinWidth(Dim.ToolBand.SEPARATOR_WIDTH);
        sep.setPrefWidth(Dim.ToolBand.SEPARATOR_WIDTH);
        sep.setMaxWidth(Dim.ToolBand.SEPARATOR_WIDTH);
        sep.setMaxHeight(Double.MAX_VALUE);
        HBox.setMargin(sep, new Insets(
                Dim.ToolBand.SEPARATOR_MARGIN_V, 0, Dim.ToolBand.SEPARATOR_MARGIN_V, 0));
        return sep;
    }
}
