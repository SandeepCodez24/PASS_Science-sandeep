package ui.ribbon_interface.tool_bar;

import javafx.beans.binding.Bindings;
import javafx.beans.binding.DoubleBinding;
import javafx.geometry.Insets;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;

/**
 * Single source of truth for the Home ribbon's geometry.
 *
 * <p>
 * The Home band is divided into {@link #TOTAL_UNITS} equal units. The eight
 * compartments consume 12 of them in the ratio 2:2:1:1:1:2:2:1; the remaining
 * 4 units are deliberately left free at the trailing (right) edge so future
 * groups can be dropped in without re-balancing everything.
 * </p>
 *
 * <pre>
 *  | Files |  Data  | Vis | Mod | Grp | Compute | Analysis | AI |        free       |
 *  |   2   |    2   |  1  |  1  |  1  |    2    |     2    |  1 |         4         |
 *  |&lt;------------------------------ 16 units ----------------------------------&gt;|
 * </pre>
 */
public final class RibbonLayout {

    /** The ribbon width is always divided into this many equal units. */
    public static final int TOTAL_UNITS = 16;

    /** Units consumed by the eight compartments (2+2+1+1+1+2+2+1). */
    public static final int USED_UNITS = 12;

    /** Units intentionally left free on the right-hand side. */
    public static final int FREE_UNITS = TOTAL_UNITS - USED_UNITS;

    /** Width of one vertical divider between two compartments. */
    public static final double SEPARATOR_WIDTH = 1;

    /**
     * Horizontal padding of the Home ToolBar (left + right), declared in the
     * theme CSS as {@code .home-ribbon-toolbar { -fx-padding: 4 10 4 10; }}.
     * Subtracted before the unit width is computed so the ratios describe the
     * usable interior, not the raw control width.
     */
    public static final double TOOLBAR_H_INSET = 20;

    /** Height of the icon / readout row inside a compartment. */
    public static final double ITEM_HEIGHT = 66;

    /** Height of the compartment caption strip along the bottom. */
    public static final double CAPTION_HEIGHT = 18;

    /** Gap between the item row and the caption. */
    public static final double GROUP_SPACING = 2;

    /**
     * Total height of the Home band. Sized so the icon, the icon label and the
     * compartment caption are all fully visible with no clipping.
     */
    public static final double ROW_HEIGHT = ITEM_HEIGHT + GROUP_SPACING + CAPTION_HEIGHT + 10;

    /** Edge length of a compartment icon. */
    public static final int ICON_SIZE = 28;

    private RibbonLayout() {
    }

    /**
     * Width of one layout unit, live-bound to the owning ToolBar.
     *
     * @param owner          the Home ToolBar whose width drives the layout
     * @param separatorCount number of vertical dividers (compartments - 1)
     * @return a binding that always yields a non-negative unit width
     */
    public static DoubleBinding unitWidth(Region owner, int separatorCount) {
        final double fixed = TOOLBAR_H_INSET + (separatorCount * SEPARATOR_WIDTH);
        return Bindings.createDoubleBinding(
                () -> Math.max(0, (owner.getWidth() - fixed) / TOTAL_UNITS),
                owner.widthProperty());
    }

    /**
     * A mild vertical divider. The colour lives in the theme CSS
     * ({@code .ribbon-group-separator}) so light and dark can each pick a shade
     * that reads as a soft division rather than a hard rule.
     *
     * @return a 1px full-height divider, inset slightly top and bottom
     */
    public static Region separator() {
        Region sep = new Region();
        sep.getStyleClass().add("ribbon-group-separator");
        sep.setMinWidth(SEPARATOR_WIDTH);
        sep.setPrefWidth(SEPARATOR_WIDTH);
        sep.setMaxWidth(SEPARATOR_WIDTH);
        sep.setMaxHeight(Double.MAX_VALUE);
        HBox.setMargin(sep, new Insets(6, 0, 6, 0));
        return sep;
    }
}
