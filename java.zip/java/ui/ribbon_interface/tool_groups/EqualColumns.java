package ui.ribbon_interface.tool_groups;

import java.util.List;

import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.VPos;
import javafx.scene.Node;
import javafx.scene.layout.Pane;

/**
 * A row of equally wide slots whose width can never go below what its widest
 * child needs.
 *
 * <p>
 * This replaces the old pattern of binding every item's {@code prefWidth} to
 * {@code rowWidth / count}. That binding made the items equal, but it also made
 * each item's preferred width a function of the row's current width, so the row
 * had no real natural size: it reported whatever it happened to be given, and
 * the only way to stop it forcing the ribbon wider was {@code minWidth = 0} --
 * which is exactly what let the labels collapse into "Proce...".
 * </p>
 *
 * <p>
 * Here the row measures its children and nothing else:
 * </p>
 *
 * <pre>
 *   natural width = count x (widest child's pref width) + spacing x (count - 1)
 * </pre>
 *
 * <p>
 * Every slot is the same width, so a short label such as "Fit" still gets the
 * same hover rectangle as "Process". Surplus width is shared equally too. The
 * row's minimum equals its natural width, so a label is never cut: when a band
 * runs out of room, {@code RibbonBand} collapses a whole compartment instead.
 * </p>
 *
 * <p>
 * Used for a compartment's item row ({@code RibbonGroup}) and for the two
 * selectors of the compare control ({@code RibbonCompareButton}).
 * </p>
 */
public class EqualColumns extends Pane {

    private double spacing;

    /**
     * @param spacing gap between adjacent slots
     */
    public EqualColumns(double spacing) {
        this.spacing = Math.max(0, spacing);
    }

    /**
     * @param value gap between adjacent slots
     */
    public void setSpacing(double value) {
        double next = Math.max(0, value);
        if (next != spacing) {
            spacing = next;
            requestLayout();
        }
    }

    /**
     * @return gap between adjacent slots
     */
    public double getSpacing() {
        return spacing;
    }

    // =====================================================================
    // Measurement
    // =====================================================================

    private double widestChild() {
        double widest = 0;
        for (Node child : getManagedChildren()) {
            widest = Math.max(widest, snapSizeX(child.prefWidth(-1)));
        }
        return widest;
    }

    private double contentWidth(int count) {
        if (count == 0) {
            return 0;
        }
        return count * widestChild() + spacing * (count - 1);
    }

    @Override
    protected double computePrefWidth(double height) {
        Insets in = getInsets();
        return in.getLeft() + in.getRight() + contentWidth(getManagedChildren().size());
    }

    /** Same as the preferred width: this row never cuts a label. */
    @Override
    protected double computeMinWidth(double height) {
        return computePrefWidth(height);
    }

    @Override
    protected double computePrefHeight(double width) {
        Insets in = getInsets();
        double tallest = 0;
        for (Node child : getManagedChildren()) {
            tallest = Math.max(tallest, child.prefHeight(-1));
        }
        return in.getTop() + in.getBottom() + tallest;
    }

    @Override
    protected double computeMinHeight(double width) {
        Insets in = getInsets();
        double tallest = 0;
        for (Node child : getManagedChildren()) {
            tallest = Math.max(tallest, child.minHeight(-1));
        }
        return in.getTop() + in.getBottom() + tallest;
    }

    // =====================================================================
    // Layout
    // =====================================================================

    @Override
    protected void layoutChildren() {
        List<Node> children = getManagedChildren();
        int count = children.size();
        if (count == 0) {
            return;
        }

        Insets in = getInsets();
        double x = in.getLeft();
        double y = in.getTop();
        double width = getWidth() - in.getLeft() - in.getRight();
        double height = getHeight() - in.getTop() - in.getBottom();

        // Never narrower than the widest child, even if the parent hands the
        // row less than its minimum: overflowing is visible and fixable,
        // an ellipsis is exactly what this class exists to prevent.
        double slot = Math.max(widestChild(),
                (width - spacing * (count - 1)) / count);

        for (Node child : children) {
            // Fill both ways; each child's own max height still applies, so a
            // button pinned to ITEM_HEIGHT stays at that height, centred.
            layoutInArea(child, x, y, slot, height, 0, Insets.EMPTY,
                    true, true, HPos.CENTER, VPos.CENTER);
            x += slot + spacing;
        }
    }
}
