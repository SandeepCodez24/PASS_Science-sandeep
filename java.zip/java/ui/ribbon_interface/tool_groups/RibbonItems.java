package ui.ribbon_interface.tool_groups;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Labeled;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Tooltip;
import ui.UI_Main;
import ui.managers.TerminalManager;
import ui.ribbon_interface.tool_bar.RibbonLayout;
import ui.ui_functions.tools.HomeFilesIcons;
import ui.ui_functions.tools.ToolbarIcons;

/**
 * Builds the individual clickable items that sit inside a
 * {@link RibbonGroup}: icon on top, label centred beneath.
 *
 * <p>
 * Colours are never set here. Every item carries both the existing
 * {@code .menu-item-button} class (so it inherits the theme's toolbar text
 * colour straight away) and a new {@code .ribbon-item-button} class for the
 * ribbon-specific hover and sizing rules.
 * </p>
 */
public final class RibbonItems {

    /** Edge length of the icon shown beside a drop-down entry. */
    public static final double MENU_ICON_SIZE = 16;

    private RibbonItems() {
    }

    /**
     * A wired action item.
     *
     * @param text     label beneath the icon
     * @param iconPath classpath resource, e.g. {@code /icons/ic_02_open.png}
     * @param action   what to run on click
     * @return the configured button
     */
    public static Button item(String text, String iconPath, Runnable action) {
        Button b = new Button(text, ToolbarIcons.icon(iconPath, RibbonLayout.ICON_SIZE));
        style(b);
        b.setTooltip(new Tooltip(text));
        b.setOnAction(e -> action.run());
        return b;
    }

    /**
     * A wired action item whose visible label is shorter than its real name.
     * Used where the compartment caption already supplies the noun -- "Import"
     * under a caption of "Data" reads as "Import Data" without three long
     * labels colliding at narrow window widths.
     *
     * @param label    short label rendered beneath the icon
     * @param fullName full feature name, used for the tooltip
     * @param iconPath classpath resource
     * @param action   what to run on click
     * @return the configured button
     */
    public static Button item(String label, String fullName, String iconPath, Runnable action) {
        Button b = item(label, iconPath, action);
        b.setTooltip(new Tooltip(fullName));
        return b;
    }

    /**
     * A placeholder item for features whose back end is not built yet. Clicking
     * it prints "&lt;name&gt; is clicked" to the Command Window, matching the
     * convention already used by the Signals, JTAG and Commission tabs.
     *
     * @param text     label beneath the icon
     * @param iconPath classpath resource
     * @param ide      the IDE controller, used to reach the Command Window
     * @return the configured button
     */
    public static Button stub(String text, String iconPath, UI_Main ide) {
        return stub(text, text, iconPath, ide);
    }

    /**
     * A placeholder item whose visible label is shorter than its real name.
     *
     * @param label    short label rendered beneath the icon
     * @param fullName full feature name, used for the tooltip and the
     *                 "&lt;name&gt; is clicked" message
     * @param iconPath classpath resource
     * @param ide      the IDE controller
     * @return the configured button
     */
    public static Button stub(String label, String fullName, String iconPath, UI_Main ide) {
        return item(label, fullName, iconPath,
                () -> TerminalManager.println(ide, fullName + " is clicked"));
    }

    /**
     * A plain drop-down item: the whole button opens the menu, with no
     * default action of its own.
     *
     * @param text     label beneath the icon
     * @param iconPath classpath resource
     * @return the configured menu button, with no items attached yet
     */
    public static MenuButton menu(String text, String iconPath) {
        MenuButton mb = new MenuButton(text);
        mb.setGraphic(ToolbarIcons.icon(iconPath, RibbonLayout.ICON_SIZE));
        style(mb);
        mb.getStyleClass().add("ribbon-menu-button");
        return mb;
    }

    /**
     * A split item: clicking the icon or the label runs {@code primary},
     * clicking the triangle strip beneath opens {@code items}. This is what
     * the Files compartment uses; {@link #menu} remains for anywhere that
     * wants a drop-down with no default action.
     *
     * @param text     label beneath the icon
     * @param iconName icon base name under {@code /icons/HomeFiles}, without
     *                 the theme folder or the {@code .png} suffix
     * @param tooltip  tooltip body, usually naming what the default click does
     * @param primary  the default action
     * @param items    the drop-down entries, top to bottom
     * @return the configured split button
     */
    public static RibbonSplitButton split(String text, String iconName, String tooltip,
            Runnable primary, MenuItem... items) {
        return new RibbonSplitButton(text, iconName)
                .withPrimaryAction(primary)
                .withMenuItems(items)
                .setTooltip(tooltip);
    }

    /**
     * One entry of a split item's drop-down, carrying an icon from the same
     * Files set as the button above it.
     *
     * @param text     entry label
     * @param iconName icon base name under {@code /icons/HomeFiles}
     * @param action   what to run when the entry is chosen
     * @return the configured menu entry
     */
    public static MenuItem menuItem(String text, String iconName, Runnable action) {
        MenuItem mi = new MenuItem(text, HomeFilesIcons.icon(iconName, MENU_ICON_SIZE));
        mi.setOnAction(e -> action.run());
        return mi;
    }

    /**
     * Applies the shared icon-on-top geometry and style hooks.
     *
     * @param b the button or menu button to style
     */
    private static void style(Labeled b) {
        b.setContentDisplay(ContentDisplay.TOP);
        b.setGraphicTextGap(4);
        b.setAlignment(Pos.CENTER);
        b.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        b.setWrapText(false);
        b.setFocusTraversable(false);
        b.setMinHeight(RibbonLayout.ITEM_HEIGHT);
        b.setPrefHeight(RibbonLayout.ITEM_HEIGHT);
        b.setMaxHeight(RibbonLayout.ITEM_HEIGHT);
        // No inline colours: the theme CSS owns the palette.
        b.setStyle("");
        if (!b.getStyleClass().contains("menu-item-button")) {
            b.getStyleClass().add("menu-item-button");
        }
        if (!b.getStyleClass().contains("ribbon-item-button")) {
            b.getStyleClass().add("ribbon-item-button");
        }
    }
}
