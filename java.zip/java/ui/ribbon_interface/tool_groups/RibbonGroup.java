package ui.ribbon_interface.tool_groups;

import javafx.beans.binding.DoubleBinding;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import ui.design.Dim;
import ui.ribbon_interface.tool_bar.RibbonLayout;
/**
 * One compartment of a ribbon band: a row of items with the compartment name
 * captioned along the bottom edge.
 *
 * <p>
 * A group never sizes itself to its content. Its width is dictated entirely by
 * its unit share of the band (see {@link RibbonLayout} for Home,
 * {@code SignalLayout} for Signals), and its items are then distributed evenly
 * across whatever width that produces.
 * </p>
 *
 * <p>
 * The share is held as a {@code double}. Home uses whole units (2:2:1:1:1:2:2:1
 * of 16); Signals uses halves (3.5:2:1:3.5:1 of 14, with 3 left free), which is
 * why the integer constructor is now a convenience wrapper rather than the only
 * way in.
 * </p>
 */
public final class RibbonGroup extends VBox {

    private final double units;
    private final HBox itemRow = new HBox();
    private final Label caption;

    /**
     * @param title compartment name shown in the bottom caption
     * @param units this compartment's whole-unit share of the band
     */
    public RibbonGroup(String title, int units) {
        this(title, (double) units);
    }

    /**
     * @param title compartment name shown in the bottom caption
     * @param units this compartment's share of the band; fractions are allowed
     *              so a compartment can sit on a half unit
     */
    public RibbonGroup(String title, double units) {
        this.units = units;

        getStyleClass().add("ribbon-group");
        setAlignment(Pos.CENTER);
        setFillWidth(true);
        setSpacing(RibbonLayout.GROUP_SPACING);

        itemRow.setAlignment(Pos.CENTER);
        itemRow.setSpacing(2);
        itemRow.setFillHeight(true);
        itemRow.setMinHeight(Dim.ToolBand.ITEM_HEIGHT);
        itemRow.setPrefHeight(Dim.ToolBand.ITEM_HEIGHT);
        itemRow.getStyleClass().add("ribbon-group-items");
        VBox.setVgrow(itemRow, Priority.ALWAYS);

        caption = new Label(title);
        caption.getStyleClass().add("ribbon-group-caption");
        caption.setMaxWidth(Double.MAX_VALUE);
        caption.setAlignment(Pos.CENTER);
        caption.setMinHeight(Dim.ToolBand.CAPTION_HEIGHT);
        caption.setPrefHeight(Dim.ToolBand.CAPTION_HEIGHT);

        getChildren().addAll(itemRow, caption);
    }

    /**
     * Adds items that share the compartment width equally.
     *
     * @param items the item nodes, left to right
     * @return this group, for chaining
     */
    public RibbonGroup withItems(Node... items) {
        final int count = items.length;
        for (Node node : items) {
            HBox.setHgrow(node, Priority.ALWAYS);
            if (node instanceof Region region) {
                region.setMaxWidth(Double.MAX_VALUE);
                // Allow the item to shrink below its label width on narrow
                // windows instead of forcing the whole ribbon wider.
                region.setMinWidth(0);
                // Give every item in the compartment an identical share.
                // Relying on HBox.Hgrow alone would distribute only the
                // SURPLUS equally, leaving items with longer labels
                // permanently wider than their neighbours.
                region.prefWidthProperty().bind(
                        itemRow.widthProperty()
                                .subtract(itemRow.getSpacing() * Math.max(0, count - 1))
                                .divide(count));
            }
            itemRow.getChildren().add(node);
        }
        return this;
    }

    /**
     * Replaces the item row with a single custom node that fills the
     * compartment. Used by Analysis, whose content is a stack of readouts
     * rather than a row of buttons.
     *
     * @param node the node to fill the compartment
     * @return this group, for chaining
     */
    public RibbonGroup withContent(Node node) {
        HBox.setHgrow(node, Priority.ALWAYS);
        if (node instanceof Region region) {
            region.setMaxWidth(Double.MAX_VALUE);
            region.setMinWidth(0);
        }
        itemRow.getChildren().setAll(node);
        return this;
    }

    /**
     * @return this compartment's share of the band
     */
    public double getUnits() {
        return units;
    }

    /**
     * Locks this compartment's width to {@code units} multiples of the shared
     * unit width. min, pref and max are all bound so the group can neither be
     * squeezed by a wide neighbour nor stretched by spare space.
     *
     * @param unitWidth the band's live unit-width binding
     */
    public void bindWidthTo(DoubleBinding unitWidth) {
        prefWidthProperty().bind(unitWidth.multiply(units));
        minWidthProperty().bind(prefWidthProperty());
        maxWidthProperty().bind(prefWidthProperty());
    }
}
