package ui.ribbon_interface.tool_groups;

import javafx.geometry.Pos;
import javafx.geometry.Side;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Tooltip;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import ui.design.Dim;
import ui.ui_functions.tools.HomeFilesIcons;

/**
 * A MATLAB-style split button for the Files compartment.
 *
 * <p>
 * The control is one rounded rectangle containing two independently live
 * zones, stacked vertically:
 * </p>
 *
 * <pre>
 *   +---------------+
 *   |     [icon]    |   .ribbon-split-icon-zone -> runs the default action
 *   +---------------+
 *   |      New      |   .ribbon-split-menu-zone -> opens the drop-down
 *   |       v       |
 *   +---------------+
 * </pre>
 *
 * <p>
 * The label belongs to the menu zone, not to the icon. Only the icon itself
 * is the shortcut to the default action; the word beneath it and the triangle
 * beneath that are one target that opens the drop-down. That split gives the
 * menu a target worth aiming at -- with the label on the icon's side, the
 * drop-down was left with a strip a few pixels tall.
 * </p>
 *
 * <p>
 * Hovering anywhere inside lights the outer rectangle, because a JavaFX
 * parent is {@code :hover} whenever any descendant is. On top of that the
 * zone actually under the pointer takes a stronger fill, so it is always
 * visible which half a click will hit. Both effects live in the theme CSS;
 * this class only supplies the structure and the style hooks.
 * </p>
 *
 * <p>
 * {@code JavaFX}'s own {@code SplitMenuButton} is deliberately not used: it
 * lays its arrow out horizontally beside the label and draws a divider
 * between the two halves, which is the layout this control replaces.
 * </p>
 */
public final class RibbonSplitButton extends VBox {

    private final VBox iconZone = new VBox();
    private final VBox menuZone = new VBox();
    private final Region arrow = new Region();
    private final ImageView icon;
    private final Label label;
    private final ContextMenu menu = new ContextMenu();

    private final Tooltip iconTip = new Tooltip();
    private final Tooltip menuTip = new Tooltip("More options");

    private Runnable primaryAction = () -> {
    };

    /**
     * @param text     label shown beneath the icon; part of the menu zone
     * @param iconName icon base name under {@code /icons/HomeFiles}, without
     *                 the theme folder or the {@code .png} suffix
     */
    public RibbonSplitButton(String text, String iconName) {

        getStyleClass().add("ribbon-split-button");
        setAlignment(Pos.TOP_CENTER);
        setFillWidth(true);
        setSpacing(0);
        setFocusTraversable(false);
        setMinWidth(0);
        setMaxWidth(Double.MAX_VALUE);
        setMinHeight(Dim.ToolBand.ITEM_HEIGHT);
        setPrefHeight(Dim.ToolBand.ITEM_HEIGHT);

        // --- default-action zone: the icon, and nothing else --------------
        icon = HomeFilesIcons.icon(iconName, Dim.ToolBand.ICON_SIZE);

        iconZone.getStyleClass().add("ribbon-split-icon-zone");
        iconZone.setAlignment(Pos.CENTER);
        iconZone.setFillWidth(true);
        iconZone.setMinWidth(0);
        iconZone.setMaxWidth(Double.MAX_VALUE);
        iconZone.getChildren().add(icon);
        // The icon zone absorbs whatever height is left once the label and
        // the triangle have taken theirs, so the icon stays vertically
        // centred in its half however tall the ribbon row is.
        VBox.setVgrow(iconZone, Priority.ALWAYS);

        // --- drop-down zone: the label and the triangle together ----------
        label = new Label(text);
        label.getStyleClass().add("ribbon-split-label");
        label.setMaxWidth(Double.MAX_VALUE);
        label.setAlignment(Pos.CENTER);
        label.setWrapText(false);
        label.setMouseTransparent(true);

        arrow.getStyleClass().add("ribbon-split-arrow");
        arrow.setMouseTransparent(true);

        menuZone.getStyleClass().add("ribbon-split-menu-zone");
        menuZone.setAlignment(Pos.CENTER);
        menuZone.setFillWidth(true);
        menuZone.setMinWidth(0);
        menuZone.setMaxWidth(Double.MAX_VALUE);
        menuZone.getChildren().addAll(label, arrow);
        // Fixed at its natural height, so growth goes to the icon zone above.
        menuZone.setMinHeight(Region.USE_PREF_SIZE);
        menuZone.setMaxHeight(Region.USE_PREF_SIZE);

        getChildren().addAll(iconZone, menuZone);

        // --- behaviour ---------------------------------------------------
        iconZone.setOnMouseClicked(event -> {
            if (event.getButton() == MouseButton.PRIMARY) {
                event.consume();
                primaryAction.run();
            }
        });

        menuZone.setOnMouseClicked(event -> {
            if (event.getButton() == MouseButton.PRIMARY) {
                event.consume();
                toggleMenu();
            }
        });

        // Keep the menu zone lit for as long as the pop-up is on screen, so
        // the control does not look idle while its own menu is open.
        menu.setOnShowing(e -> menuZone.getStyleClass().add("menu-showing"));
        menu.setOnHidden(e -> menuZone.getStyleClass().remove("menu-showing"));
        menu.setAutoHide(true);

        Tooltip.install(iconZone, iconTip);
        Tooltip.install(menuZone, menuTip);
        setTooltip(text);
    }

    /**
     * Sets what a click on the icon does.
     *
     * @param action the default action
     * @return this button, for chaining
     */
    public RibbonSplitButton withPrimaryAction(Runnable action) {
        this.primaryAction = (action != null) ? action : () -> {
        };
        return this;
    }

    /**
     * Adds entries to the drop-down.
     *
     * @param items the menu entries, top to bottom
     * @return this button, for chaining
     */
    public RibbonSplitButton withMenuItems(MenuItem... items) {
        menu.getItems().addAll(items);
        return this;
    }

    /**
     * Sets the tooltip shown over the icon, which is the half that runs the
     * default action. The menu zone keeps its own "More options" tooltip, so
     * the two halves announce different things on hover.
     *
     * @param text tooltip body for the default action
     * @return this button, for chaining
     */
    public RibbonSplitButton setTooltip(String text) {
        iconTip.setText(text);
        return this;
    }

    /**
     * Replaces the tooltip shown over the label and triangle.
     *
     * @param text tooltip body for the drop-down
     * @return this button, for chaining
     */
    public RibbonSplitButton setMenuTooltip(String text) {
        menuTip.setText(text);
        return this;
    }

    /**
     * @return the live drop-down, so callers can add or rebuild entries
     */
    public ContextMenu getMenu() {
        return menu;
    }

    private void toggleMenu() {
        if (menu.isShowing()) {
            menu.hide();
        } else if (!menu.getItems().isEmpty()) {
            // Anchored to the whole control rather than the zone, so the
            // pop-up lines up with the left edge of the button.
            menu.show(this, Side.BOTTOM, 0, 0);
        }
    }
}
