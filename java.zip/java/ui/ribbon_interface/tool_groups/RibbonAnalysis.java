package ui.ribbon_interface.tool_groups;

import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

/**
 * Content and public update API for the Analysis compartment.
 *
 * <p>
 * Two stacked readouts show the number of computations performed and the
 * wall-clock execution time of the last run. Both display {@code 0} until the
 * execution back end starts reporting; wire it up by calling
 * {@link #setComputationCount(long)} and
 * {@link #setExecutionTimeMillis(double)} from the run pipeline (see
 * {@code EditorFileRunner} / {@code UI_MainProgramControl}).
 * </p>
 */
public final class RibbonAnalysis {

    private static RibbonReadout computations;
    private static RibbonReadout executionTime;

    private RibbonAnalysis() {
    }

    /**
     * Builds the stacked readouts. Called once while the Home ribbon is
     * assembled; a second call replaces the previously held references.
     *
     * @return the node to place inside the Analysis compartment
     */
    public static Node buildContent() {
        computations = new RibbonReadout("No. of Computation", "0");
        executionTime = new RibbonReadout("Execution Time", "0 ms");

        VBox stack = new VBox(computations, executionTime);
        stack.setAlignment(Pos.CENTER);
        stack.setFillWidth(true);
        stack.setMaxWidth(Double.MAX_VALUE);
        stack.setMinWidth(0);
        stack.getStyleClass().add("ribbon-readout-stack");

        VBox.setVgrow(computations, Priority.ALWAYS);
        VBox.setVgrow(executionTime, Priority.ALWAYS);
        return stack;
    }

    /**
     * @param count number of computations executed in the last run
     */
    public static void setComputationCount(long count) {
        if (computations != null) {
            computations.setValue(Long.toString(count));
        }
    }

    /**
     * @param millis wall-clock execution time; rendered in ms below one second
     *               and in seconds above it
     */
    public static void setExecutionTimeMillis(double millis) {
        if (executionTime == null) {
            return;
        }
        executionTime.setValue(millis < 1000
                ? String.format("%.0f ms", millis)
                : String.format("%.2f s", millis / 1000.0));
    }

    /**
     * Returns both readouts to their pre-run state.
     */
    public static void reset() {
        setComputationCount(0);
        if (executionTime != null) {
            executionTime.setValue("0 ms");
        }
    }
}
