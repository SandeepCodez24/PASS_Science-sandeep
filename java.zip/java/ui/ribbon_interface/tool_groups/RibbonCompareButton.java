package ui.ribbon_interface.tool_groups;

import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.function.Supplier;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Side;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Tooltip;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import ui.ribbon_interface.tool_bar.RibbonLayout;

/**
 * A three-zone ribbon control: two drop-down selectors side by side with an
 * action zone spanning the full width beneath them.
 *
 * <pre>
 *   +-------------------------------+
 *   | Select 1  v  |  Select 2  v   |   .ribbon-compare-select-zone  x2
 *   +-------------------------------+
 *   |           Compare             |   .ribbon-compare-action-zone
 *   +-------------------------------+
 * </pre>
 *
 * <p>
 * Same idea as {@link RibbonSplitButton} -- one outer rectangle, several live
 * zones inside it, the zone under the pointer taking a stronger fill so it is
 * always visible which part a click will hit. The difference is the split: the
 * Files control divides top/bottom into two, this one divides into two across
 * and then one along the bottom.
 * </p>
 *
 * <p>
 * Unlike the split button, the zones here are filled at rest rather than
 * transparent. Three targets in the space of one ribbon item need their edges
 * drawn, not merely implied on hover.
 * </p>
 *
 * <p>
 * The control knows nothing about signals. It is given two suppliers of
 * options, a function that names one, and a callback that receives the pair --
 * so the same class serves the Sensors and Actuators compartments, and would
 * serve anything else with the same shape.
 * </p>
 *
 * @param <T> the option type held by the two selectors
 */
public final class RibbonCompareButton<T> extends VBox {

    /** Style class added to the action zone while it has no valid pair. */
    private static final String DISABLED_CLASS = "disabled";

    private final Function<T, String> namer;

    private final SelectZone left;
    private final SelectZone right;
    private final StackPane actionZone = new StackPane();
    private final Label actionLabel = new Label("Compare");
    private final Tooltip actionTip = new Tooltip();

    private String actionReadyTip = "Compare the two selected signals";
    private String actionBlockedTip = "Choose a signal in both drop-downs first";

    private BiConsumer<T, T> action = (a, b) -> {
    };

    /**
     * @param namer renders one option as the text shown in the drop-down and,
     *              once chosen, on the selector itself
     */
    public RibbonCompareButton(Function<T, String> namer) {
        this.namer = (namer != null) ? namer : String::valueOf;

        getStyleClass().add("ribbon-compare-button");
        setAlignment(Pos.CENTER);
        setFillWidth(true);
        setSpacing(3);
        setPadding(new Insets(3));
        setFocusTraversable(false);
        setMinWidth(0);
        setMaxWidth(Double.MAX_VALUE);
        setMinHeight(RibbonLayout.ITEM_HEIGHT);
        setPrefHeight(RibbonLayout.ITEM_HEIGHT);

        left = new SelectZone("Select 1");
        right = new SelectZone("Select 2");

        HBox selectRow = new HBox(3, left, right);
        selectRow.setAlignment(Pos.CENTER);
        selectRow.setFillHeight(true);
        selectRow.setMinWidth(0);
        selectRow.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(left, Priority.ALWAYS);
        HBox.setHgrow(right, Priority.ALWAYS);
        // Equal halves regardless of which label is longer; without this the
        // zone holding "Noisy Sine 5 Hz" would permanently outgrow its twin.
        left.prefWidthProperty().bind(selectRow.widthProperty().subtract(3).divide(2));
        right.prefWidthProperty().bind(left.prefWidthProperty());
        VBox.setVgrow(selectRow, Priority.ALWAYS);

        actionLabel.getStyleClass().add("ribbon-compare-action-label");
        actionLabel.setMouseTransparent(true);

        actionZone.getStyleClass().add("ribbon-compare-action-zone");
        actionZone.setAlignment(Pos.CENTER);
        actionZone.setMinWidth(0);
        actionZone.setMaxWidth(Double.MAX_VALUE);
        actionZone.setMinHeight(22);
        actionZone.setPrefHeight(22);
        actionZone.setMaxHeight(22);
        actionZone.getChildren().add(actionLabel);
        actionZone.setOnMouseClicked(event -> {
            if (event.getButton() == MouseButton.PRIMARY) {
                event.consume();
                fire();
            }
        });

        Tooltip.install(actionZone, actionTip);

        getChildren().addAll(selectRow, actionZone);
        refreshActionState();
    }

    /**
     * Configures the left-hand selector.
     *
     * @param placeholder text shown until something is chosen
     * @param options     supplies the current options each time the drop-down
     *                    opens, so a set that grows at runtime needs no
     *                    re-wiring here
     * @return this control, for chaining
     */
    public RibbonCompareButton<T> withLeft(String placeholder, Supplier<List<T>> options) {
        left.configure(placeholder, options);
        return this;
    }

    /**
     * Configures the right-hand selector.
     *
     * @param placeholder text shown until something is chosen
     * @param options     supplies the current options on each open
     * @return this control, for chaining
     */
    public RibbonCompareButton<T> withRight(String placeholder, Supplier<List<T>> options) {
        right.configure(placeholder, options);
        return this;
    }

    /**
     * Sets the action zone's label and what a click on it does. The callback
     * only ever runs with two non-null arguments.
     *
     * @param text     label for the action zone
     * @param onAction receives the left and right selections, in that order
     * @return this control, for chaining
     */
    public RibbonCompareButton<T> withAction(String text, BiConsumer<T, T> onAction) {
        actionLabel.setText(text);
        this.action = (onAction != null) ? onAction : (a, b) -> {
        };
        return this;
    }

    /**
     * Replaces the two tooltips shown over the action zone.
     *
     * @param ready   shown once both selectors hold a value
     * @param blocked shown while either is still empty
     * @return this control, for chaining
     */
    public RibbonCompareButton<T> withActionTooltips(String ready, String blocked) {
        this.actionReadyTip = ready;
        this.actionBlockedTip = blocked;
        refreshActionState();
        return this;
    }

    /**
     * @return the left-hand selection, or null if nothing is chosen yet
     */
    public T getLeftSelection() {
        return left.selected;
    }

    /**
     * @return the right-hand selection, or null if nothing is chosen yet
     */
    public T getRightSelection() {
        return right.selected;
    }

    /**
     * Clears both selectors back to their placeholders.
     */
    public void clearSelections() {
        left.select(null);
        right.select(null);
    }

    private void fire() {
        T a = left.selected;
        T b = right.selected;
        if (a != null && b != null) {
            action.accept(a, b);
        }
    }

    private void refreshActionState() {
        boolean ready = left.selected != null && right.selected != null;
        actionTip.setText(ready ? actionReadyTip : actionBlockedTip);
        if (ready) {
            actionZone.getStyleClass().remove(DISABLED_CLASS);
        } else if (!actionZone.getStyleClass().contains(DISABLED_CLASS)) {
            actionZone.getStyleClass().add(DISABLED_CLASS);
        }
    }

    // =====================================================================
    // One selector: a filled pill holding a label and a small triangle.
    // =====================================================================
    private final class SelectZone extends HBox {

        private final Label text = new Label();
        private final Region arrow = new Region();
        private final ContextMenu menu = new ContextMenu();
        private final Tooltip tip = new Tooltip();

        private String placeholder;
        private Supplier<List<T>> options = List::of;
        private T selected;

        private SelectZone(String placeholder) {
            this.placeholder = placeholder;

            getStyleClass().add("ribbon-compare-select-zone");
            setAlignment(Pos.CENTER);
            setSpacing(3);
            setMinWidth(0);
            setMaxWidth(Double.MAX_VALUE);
            setMinHeight(22);
            setPrefHeight(22);
            setMaxHeight(22);

            text.getStyleClass().add("ribbon-compare-label");
            text.setText(placeholder);
            text.setMouseTransparent(true);
            text.setMinWidth(0);
            text.setMaxWidth(Double.MAX_VALUE);
            text.setAlignment(Pos.CENTER);
            HBox.setHgrow(text, Priority.ALWAYS);

            arrow.getStyleClass().add("ribbon-compare-arrow");
            arrow.setMouseTransparent(true);

            getChildren().addAll(text, arrow);

            setOnMouseClicked(event -> {
                if (event.getButton() == MouseButton.PRIMARY) {
                    event.consume();
                    toggleMenu();
                }
            });

            // Keep the zone lit while its own pop-up is on screen.
            menu.setOnShowing(e -> getStyleClass().add("menu-showing"));
            menu.setOnHidden(e -> getStyleClass().remove("menu-showing"));
            menu.setAutoHide(true);

            tip.setText(placeholder);
            Tooltip.install(this, tip);
        }

        private void configure(String placeholderText, Supplier<List<T>> supplier) {
            this.placeholder = placeholderText;
            this.options = (supplier != null) ? supplier : List::of;
            if (selected == null) {
                text.setText(placeholderText);
                tip.setText(placeholderText);
            }
        }

        private void toggleMenu() {
            if (menu.isShowing()) {
                menu.hide();
                return;
            }
            rebuild();
            menu.show(this, Side.BOTTOM, 0, 0);
        }

        private void rebuild() {
            menu.getItems().clear();
            List<T> current = options.get();

            if (current == null || current.isEmpty()) {
                MenuItem empty = new MenuItem("No signals available");
                empty.setDisable(true);
                menu.getItems().add(empty);
                return;
            }

            for (T option : current) {
                MenuItem entry = new MenuItem(namer.apply(option));
                entry.setOnAction(e -> select(option));
                menu.getItems().add(entry);
            }
        }

        private void select(T option) {
            selected = option;
            String label = (option != null) ? namer.apply(option) : placeholder;
            text.setText(label);
            tip.setText(label);
            refreshActionState();
        }
    }
}
