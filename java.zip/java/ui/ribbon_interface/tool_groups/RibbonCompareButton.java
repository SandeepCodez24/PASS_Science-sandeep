package ui.ribbon_interface.tool_groups;

import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.function.Supplier;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Side;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Tooltip;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import ui.design.Dim;
import ui.design.section_dims.CompareButton_dim;

/**
 * A three-zone ribbon control: two drop-down selectors side by side with an
 * action zone spanning the full width beneath them.
 *
 * <pre>
 *   +-------------------------------+
 *   | Select 1  v  |  Select 2  v   |   .ribbon-compare-select-zone  x2
 *   +-------------------------------+
 *   |           Compare             |   .ribbon-compare-action-zone
 *   +-------------------------------+
 * </pre>
 *
 * <p>
 * Same idea as {@link RibbonSplitButton} -- one outer rectangle, several live
 * zones inside it, the zone under the pointer taking a stronger fill so it is
 * always visible which part a click will hit. The difference is the split: the
 * Files control divides top/bottom into two, this one divides into two across
 * and then one along the bottom.
 * </p>
 *
 * <p>
 * Unlike the split button, the zones here are filled at rest rather than
 * transparent. Three targets in the space of one ribbon item need their edges
 * drawn, not merely implied on hover.
 * </p>
 *
 * <p>
 * The control knows nothing about signals. It is given two suppliers of
 * options, a function that names one, and a callback that receives the pair --
 * so the same class serves the Sensors and Actuators compartments, and would
 * serve anything else with the same shape.
 * </p>
 *
 * <p>
 * Geometry: the outer height is {@code Dim.ToolBand.ITEM_HEIGHT} so the control
 * lines up with the plain buttons beside it; every inner number (padding,
 * spacing, gap, zone height) comes from {@link CompareButton_dim}.
 * </p>
 *
 * @param <T> the option type held by the two selectors
 */
public final class RibbonCompareButton<T> extends VBox {

    /** Style class added to the action zone while it has no valid pair. */
    private static final String DISABLED_CLASS = "disabled";

    private final Function<T, String> namer;

    private final SelectZone left;
    private final SelectZone right;
    private final StackPane actionZone = new StackPane();
    private final Label actionLabel = new Label("Compare");
    private final Tooltip actionTip = new Tooltip();

    private String actionReadyTip = "Compare the two selected signals";
    private String actionBlockedTip = "Choose a signal in both drop-downs first";

    private BiConsumer<T, T> action = (a, b) -> {
    };

    /**
     * @param namer renders one option as the text shown in the drop-down and,
     *              once chosen, on the selector itself
     */
    public RibbonCompareButton(Function<T, String> namer) {
        this.namer = (namer != null) ? namer : String::valueOf;

        getStyleClass().add("ribbon-compare-button");
        setAlignment(Pos.CENTER);
        setFillWidth(true);
        setSpacing(CompareButton_dim.SPACING);
        setPadding(new Insets(CompareButton_dim.PADDING));
        setFocusTraversable(false);
        setMaxWidth(Double.MAX_VALUE);
        setMinHeight(Dim.ToolBand.ITEM_HEIGHT);
        setPrefHeight(Dim.ToolBand.ITEM_HEIGHT);

        left = new SelectZone("Select 1");
        right = new SelectZone("Select 2");
        // Wired here, after each zone is fully constructed, rather than from
        // inside the SelectZone constructor (which would hand out a reference
        // to a half-built object).
        left.wire();
        right.wire();

        // Two equal halves, each at least as wide as the longer of the two
        // selector labels. EqualColumns measures the zones instead of being
        // bound to its own width, so the control has a real natural width and
        // "Select 1" / "Select 2" -- or a chosen signal's name -- is never cut
        // to "...". A long signal name widens the whole compartment instead;
        // RibbonBand re-lays the band around it.
        EqualColumns selectRow = new EqualColumns(CompareButton_dim.ZONE_GAP);
        selectRow.getStyleClass().add("ribbon-compare-select-row");
        selectRow.getChildren().addAll(left, right);
        VBox.setVgrow(selectRow, Priority.ALWAYS);

        actionLabel.getStyleClass().add("ribbon-compare-action-label");
        actionLabel.setMouseTransparent(true);

        actionZone.getStyleClass().add("ribbon-compare-action-zone");
        actionZone.setAlignment(Pos.CENTER);
        actionZone.setMinWidth(Region.USE_PREF_SIZE);
        actionZone.setMaxWidth(Double.MAX_VALUE);
        actionZone.setMinHeight(CompareButton_dim.ZONE_HEIGHT);
        actionZone.setPrefHeight(CompareButton_dim.ZONE_HEIGHT);
        actionZone.setMaxHeight(CompareButton_dim.ZONE_HEIGHT);
        actionZone.getChildren().add(actionLabel);
        actionZone.setOnMouseClicked(event -> {
            if (event.getButton() == MouseButton.PRIMARY) {
                event.consume();
                fire();
            }
        });

        Tooltip.install(actionZone, actionTip);

        getChildren().addAll(selectRow, actionZone);
        refreshActionState();
    }

    /**
     * Configures the left-hand selector.
     *
     * @param placeholder text shown until something is chosen
     * @param options     supplies the current options each time the drop-down
     *                    opens, so a set that grows at runtime needs no
     *                    re-wiring here
     * @return this control, for chaining
     */
    public RibbonCompareButton<T> withLeft(String placeholder, Supplier<List<T>> options) {
        left.configure(placeholder, options);
        return this;
    }

    /**
     * Configures the right-hand selector.
     *
     * @param placeholder text shown until something is chosen
     * @param options     supplies the current options on each open
     * @return this control, for chaining
     */
    public RibbonCompareButton<T> withRight(String placeholder, Supplier<List<T>> options) {
        right.configure(placeholder, options);
        return this;
    }

    /**
     * Sets the action zone's label and what a click on it does. The callback
     * only ever runs with two non-null arguments.
     *
     * @param text     label for the action zone
     * @param onAction receives the left and right selections, in that order
     * @return this control, for chaining
     */
    public RibbonCompareButton<T> withAction(String text, BiConsumer<T, T> onAction) {
        actionLabel.setText(text);
        this.action = (onAction != null) ? onAction : (a, b) -> {
        };
        return this;
    }

    /**
     * Replaces the two tooltips shown over the action zone.
     *
     * @param ready   shown once both selectors hold a value
     * @param blocked shown while either is still empty
     * @return this control, for chaining
     */
    public RibbonCompareButton<T> withActionTooltips(String ready, String blocked) {
        this.actionReadyTip = ready;
        this.actionBlockedTip = blocked;
        refreshActionState();
        return this;
    }

    /**
     * @return the left-hand selection, or null if nothing is chosen yet
     */
    public T getLeftSelection() {
        return left.selected;
    }

    /**
     * @return the right-hand selection, or null if nothing is chosen yet
     */
    public T getRightSelection() {
        return right.selected;
    }

    /**
     * Clears both selectors back to their placeholders.
     */
    public void clearSelections() {
        left.select(null);
        right.select(null);
    }

    private void fire() {
        T a = left.selected;
        T b = right.selected;
        if (a != null && b != null) {
            action.accept(a, b);
        }
    }

    private void refreshActionState() {
        boolean ready = left.selected != null && right.selected != null;
        actionTip.setText(ready ? actionReadyTip : actionBlockedTip);
        if (ready) {
            actionZone.getStyleClass().remove(DISABLED_CLASS);
        } else if (!actionZone.getStyleClass().contains(DISABLED_CLASS)) {
            actionZone.getStyleClass().add(DISABLED_CLASS);
        }
    }

    // =====================================================================
    // One selector: a filled pill holding a label and a small triangle.
    // =====================================================================
    private final class SelectZone extends HBox {

        private final Label text = new Label();
        private final Region arrow = new Region();
        private final ContextMenu menu = new ContextMenu();
        private final Tooltip tip = new Tooltip();

        private String placeholder;
        private Supplier<List<T>> options = List::of;
        private T selected;

        /**
         * Builds the zone's own nodes. Anything that hands this zone to the
         * outside world (tooltip install, event handlers, menu callbacks) is
         * done in {@link #wire()} once construction has finished.
         */
        private SelectZone(String placeholder) {
            this.placeholder = placeholder;

            getStyleClass().add("ribbon-compare-select-zone");
            setAlignment(Pos.CENTER);
            setSpacing(3);                 // label-to-triangle gap
            setMinWidth(Region.USE_PREF_SIZE);
            setMaxWidth(Double.MAX_VALUE);
            // One zone is ZONE_HEIGHT tall, the same as the action zone below
            // it. (The previous min of ITEM_HEIGHT was larger than the max of
            // 22, so JavaFX honoured the min and the selectors were drawn a
            // full button tall, crowding the action zone.)
            setMinHeight(0);
            setPrefHeight(CompareButton_dim.ZONE_HEIGHT);
            setMaxHeight(CompareButton_dim.ZONE_HEIGHT);

            text.getStyleClass().add("ribbon-compare-label");
            text.setText(placeholder);
            text.setMouseTransparent(true);
            text.setMinWidth(Region.USE_PREF_SIZE);
            text.setMaxWidth(Double.MAX_VALUE);
            text.setAlignment(Pos.CENTER);
            HBox.setHgrow(text, Priority.ALWAYS);

            arrow.getStyleClass().add("ribbon-compare-arrow");
            arrow.setMouseTransparent(true);

            getChildren().addAll(text, arrow);

            menu.setAutoHide(true);
            tip.setText(placeholder);
        }

        /** Installs the tooltip and the event handlers. Called once, after construction. */
        private void wire() {
            setOnMouseClicked(event -> {
                if (event.getButton() == MouseButton.PRIMARY) {
                    event.consume();
                    toggleMenu();
                }
            });

            // Keep the zone lit while its own pop-up is on screen.
            menu.setOnShowing(e -> getStyleClass().add("menu-showing"));
            menu.setOnHidden(e -> getStyleClass().remove("menu-showing"));

            Tooltip.install(this, tip);
        }

        private void configure(String placeholderText, Supplier<List<T>> supplier) {
            this.placeholder = placeholderText;
            this.options = (supplier != null) ? supplier : List::of;
            if (selected == null) {
                text.setText(placeholderText);
                tip.setText(placeholderText);
            }
        }

        private void toggleMenu() {
            if (menu.isShowing()) {
                menu.hide();
                return;
            }
            rebuild();
            menu.show(this, Side.BOTTOM, 0, 0);
        }

        private void rebuild() {
            menu.getItems().clear();
            List<T> current = options.get();

            if (current == null || current.isEmpty()) {
                MenuItem empty = new MenuItem("No signals available");
                empty.setDisable(true);
                menu.getItems().add(empty);
                return;
            }

            for (T option : current) {
                MenuItem entry = new MenuItem(namer.apply(option));
                entry.setOnAction(e -> select(option));
                menu.getItems().add(entry);
            }
        }

        private void select(T option) {
            selected = option;
            String label = (option != null) ? namer.apply(option) : placeholder;
            text.setText(label);
            tip.setText(label);
            refreshActionState();
        }
    }
}
