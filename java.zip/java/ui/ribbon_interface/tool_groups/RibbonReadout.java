package ui.ribbon_interface.tool_groups;

import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

/**
 * A read-only rectangular display: caption on the first line, live value on the
 * second. Unlike every other ribbon item this is not clickable — it reports
 * state rather than triggering an action.
 */
public final class RibbonReadout extends VBox {

    private final Label valueLabel;

    /**
     * @param title        caption shown on the first line
     * @param initialValue value shown on the second line before any run
     */
    public RibbonReadout(String title, String initialValue) {
        getStyleClass().add("ribbon-readout");
        setAlignment(Pos.CENTER_LEFT);
        setSpacing(0);
        setMaxWidth(Double.MAX_VALUE);
        setMinWidth(0);

        Label titleLabel = new Label(title);
        titleLabel.getStyleClass().add("ribbon-readout-title");
        titleLabel.setMaxWidth(Double.MAX_VALUE);

        valueLabel = new Label(initialValue);
        valueLabel.getStyleClass().add("ribbon-readout-value");
        valueLabel.setMaxWidth(Double.MAX_VALUE);

        getChildren().addAll(titleLabel, valueLabel);
    }

    /**
     * Updates the displayed value. Safe to call from a background thread — the
     * update is marshalled onto the FX application thread when needed.
     *
     * @param value the new value text
     */
    public void setValue(String value) {
        if (Platform.isFxApplicationThread()) {
            valueLabel.setText(value);
        } else {
            Platform.runLater(() -> valueLabel.setText(value));
        }
    }

    /**
     * @return the value currently displayed
     */
    public String getValue() {
        return valueLabel.getText();
    }
}
