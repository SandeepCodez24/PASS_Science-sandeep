package ui.explorer;

import java.util.ArrayList;
import java.util.List;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.ToolBar;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class NeuralLinkWindow extends Application {

    public static void open(Stage owner) {
        NeuralLinkWindow window = new NeuralLinkWindow();
        Stage stage = new Stage();
        stage.initOwner(owner);
        stage.initModality(Modality.NONE);
        window.start(stage);
    }

    Pane workspace = new Pane();
    List<BlockNode> blocks = new ArrayList<>();
    List<Connection> connections = new ArrayList<>();

    BlockNode connectionStart = null;

    LineChart<Number, Number> chart;
    XYChart.Series<Number, Number> series;
    int timeStep = 0;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) {

        BorderPane root = new BorderPane();

        ToolBar topBar = new ToolBar();
        Button runBtn = new Button("Run Model");

        runBtn.setOnAction(e -> runSimulation());

        topBar.getItems().add(runBtn);

        VBox palette = new VBox(10);
        palette.setPadding(new Insets(10));
        palette.setPrefWidth(180);

        palette.getChildren().addAll(
                paletteButton("Source"),
                paletteButton("Gain"),
                paletteButton("Sum"),
                paletteButton("Scope"));

        workspace.setMinSize(1200, 800);
        drawGrid();

        ScrollPane scroll = new ScrollPane(workspace);

        VBox graphPanel = createGraphPanel();

        root.setTop(topBar);
        root.setLeft(palette);
        root.setCenter(scroll);
        root.setRight(graphPanel);

        Scene scene = new Scene(root, 1400, 700);

        stage.setScene(scene);
        stage.setTitle("Neural Link Designer");
        stage.show();
    }

    private VBox createGraphPanel() {
        NumberAxis xAxis = new NumberAxis();
        NumberAxis yAxis = new NumberAxis();

        xAxis.setLabel("Time");
        yAxis.setLabel("Output");

        chart = new LineChart<>(xAxis, yAxis);
        chart.setTitle("Scope Graph");
        chart.setCreateSymbols(false);
        chart.setAnimated(false);

        series = new XYChart.Series<>();
        chart.getData().add(series);

        VBox box = new VBox(chart);
        box.setPrefWidth(350);

        return box;
    }

    private Button paletteButton(String name) {
        Button b = new Button(name);
        b.setMaxWidth(Double.MAX_VALUE);

        b.setOnAction(e -> {

            BlockNode block = new BlockNode(name, 200, 200);
            blocks.add(block);
            workspace.getChildren().add(block);

        });

        return b;
    }

    class BlockNode extends VBox {

        String type;
        double value = 1;

        Rectangle body;

        double dragX, dragY;

        public BlockNode(String type, double x, double y) {

            this.type = type;

            Label title = new Label(type);
            title.setFont(Font.font(12));

            body = new Rectangle(100, 50);
            body.setFill(Color.LIGHTBLUE);
            body.setStroke(Color.BLACK);

            Pane pane = new Pane(body);

            this.getChildren().addAll(title, pane);

            this.setLayoutX(x);
            this.setLayoutY(y);

            setPadding(new Insets(3));

            enableDrag();
            enableEdit();
            enableConnection();
            enableDelete();
        }

        void enableDrag() {

            setOnMousePressed(e -> {
                dragX = e.getSceneX() - getLayoutX();
                dragY = e.getSceneY() - getLayoutY();
            });

            setOnMouseDragged(e -> {

                setLayoutX(e.getSceneX() - dragX);
                setLayoutY(e.getSceneY() - dragY);

                updateConnections();
            });
        }

        void enableEdit() {

            setOnMouseClicked(e -> {

                if (e.getClickCount() == 2) {

                    TextInputDialog dialog = new TextInputDialog("" + value);

                    dialog.setTitle("Parameter");
                    dialog.setHeaderText("Enter value");

                    dialog.showAndWait().ifPresent(v -> {

                        try {
                            value = Double.parseDouble(v);
                        } catch (Exception ignored) {
                        }

                    });

                }
            });
        }

        void enableConnection() {

            setOnMouseClicked(e -> {

                if (e.getButton() == MouseButton.PRIMARY) {

                    if (connectionStart == null) {

                        connectionStart = this;

                    } else {

                        Line line = new Line();

                        Connection c = new Connection(connectionStart, this, line);

                        connections.add(c);

                        workspace.getChildren().add(0, line);

                        updateConnections();

                        connectionStart = null;

                    }

                }

            });
        }

        void enableDelete() {

            setOnContextMenuRequested(e -> {
                workspace.getChildren().remove(this);
                blocks.remove(this);
            });

        }

        double output(double input) {

            switch (type) {

                case "Source":
                    return value;

                case "Gain":
                    return input * value;

                case "Sum":
                    return input + value;

                case "Scope":
                    return input;

            }

            return input;
        }
    }

    class Connection {

        BlockNode from;
        BlockNode to;
        Line line;

        public Connection(BlockNode f, BlockNode t, Line l) {
            from = f;
            to = t;
            line = l;
            line.setStrokeWidth(3);
            line.setStroke(Color.DARKBLUE);
        }
    }

    void updateConnections() {

        for (Connection c : connections) {

            c.line.setStartX(c.from.getLayoutX() + 100);
            c.line.setStartY(c.from.getLayoutY() + 40);

            c.line.setEndX(c.to.getLayoutX());
            c.line.setEndY(c.to.getLayoutY() + 40);
        }
    }

    void drawGrid() {

        int step = 25;

        for (int x = 0; x < 2000; x += step) {
            Line l = new Line(x, 0, x, 2000);
            l.setStroke(Color.LIGHTGRAY);
            workspace.getChildren().add(l);
        }

        for (int y = 0; y < 2000; y += step) {
            Line l = new Line(0, y, 2000, y);
            l.setStroke(Color.LIGHTGRAY);
            workspace.getChildren().add(l);
        }
    }

    void runSimulation() {

        if (blocks.isEmpty()) {
            alert("No blocks present");
            return;
        }

        // Calculate outputs based on block connections
        double[] blockOutputs = new double[blocks.size()];

        for (int i = 0; i < blocks.size(); i++) {
            BlockNode block = blocks.get(i);
            double input = 0;

            // Sum inputs from all connected blocks
            for (Connection conn : connections) {
                if (blocks.indexOf(conn.to) == i) {
                    int fromIndex = blocks.indexOf(conn.from);
                    if (fromIndex >= 0) {
                        input += blockOutputs[fromIndex];
                    }
                }
            }

            blockOutputs[i] = block.output(input);
        }

        // Plot final output (last block) to chart
        if (blockOutputs.length > 0) {
            plotValue(blockOutputs[blockOutputs.length - 1]);
        }
    }

    void plotValue(double value) {
        series.getData().add(new XYChart.Data<>(timeStep++, value));

        if (series.getData().size() > 60) {
            series.getData().remove(0);
        }
    }

    void alert(String msg) {

        Alert a = new Alert(Alert.AlertType.INFORMATION, msg);
        a.show();
    }
}