package ui.explorer.variable;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import ui.ui_functions.Variable;

/**
 * The type icons of the Variable Explorer, its tabs and its grid header.
 *
 * <p>
 * Every icon ships twice, under {@code /icons/variable_explorer/light/} and
 * {@code /icons/variable_explorer/dark/} (48 x 48 RGBA). The light set is drawn
 * for a light surface and the dark set for a dark one; {@link #image} picks
 * the set for the theme that is showing.
 * </p>
 *
 * <h3>Which icon a variable gets</h3>
 * <p>
 * The interpreter's {@code class} decides ({@code runtime/data/WS_PROTOCOL.md}):
 * </p>
 * <ul>
 * <li>{@code int8..int64}, {@code uint8..uint64}, {@code float8..float64}:
 * the type's own icon for a scalar ({@code 1x1}), the matrix icon for an
 * array.</li>
 * <li>{@code string}, {@code bool}, {@code complex}, {@code dict},
 * {@code cell} (matrix), {@code function_handle} (function).</li>
 * <li>Anything else is an object, named by its class: the class icon, or the
 * inherited-class icon when its lineage has a parent (known once the value
 * has been fetched).</li>
 * <li>A variable brought in by Load Workspace and not changed since shows the
 * loaded-data icon.</li>
 * </ul>
 */
public final class VariableIcons {

    /** One icon: its file name stem under the theme folder. */
    public enum Kind {
        INT8("ic_ve_01_int8"),
        INT16("ic_ve_02_int16"),
        INT32("ic_ve_03_int32"),
        INT64("ic_ve_04_int64"),
        UINT8("ic_ve_05_uint8"),
        UINT16("ic_ve_06_uint16"),
        UINT32("ic_ve_07_uint32"),
        UINT64("ic_ve_08_uint64"),
        FLOAT8("ic_ve_09_float8"),
        FLOAT16("ic_ve_10_float16"),
        FLOAT32("ic_ve_11_float32"),
        FLOAT64("ic_ve_12_float64"),
        STRING("ic_ve_13_string"),
        MATRIX("ic_ve_14_matrix"),
        DICTIONARY("ic_ve_15_dictionary"),
        FUNCTION("ic_ve_16_function"),
        CLASS("ic_ve_17_class"),
        INHERITED_CLASS("ic_ve_18_inherited_class"),
        LOADED_DATA("ic_ve_19_loaded_data"),
        BOOL("ic_ve_20_bool"),
        COMPLEX("ic_ve_21_complex");

        private final String file;

        Kind(String file) {
            this.file = file;
        }

        /** @return the file name stem, without folder or extension */
        public String file() {
            return file;
        }
    }

    private static final String DIR = "/icons/variable_explorer/";

    /** Decoded images, keyed by theme folder and kind. */
    private static final Map<String, Image> CACHE = new HashMap<>();

    private VariableIcons() {
    }

    // =====================================================================
    // Choosing
    // =====================================================================

    /**
     * The icon for an explorer row.
     *
     * @param v the row
     * @return the kind to draw
     */
    public static Kind forVariable(Variable v) {
        if (v == null) {
            return Kind.FLOAT64;
        }
        if (VariableExplorerController.isLoadedData(v)) {
            return Kind.LOADED_DATA;
        }
        return forClass(v.getDatatype(), v.getSize(), false);
    }

    /**
     * The icon for a class and size reported by the interpreter.
     *
     * @param cls       the {@code class}: float64, int32, string, dict, ...
     * @param size      the {@code size}: "1x1", "3x4"; may be null
     * @param inherited true when the value is an object whose lineage has a
     *                  parent class
     * @return the kind to draw
     */
    public static Kind forClass(String cls, String size, boolean inherited) {
        String c = cls == null ? "" : cls.strip().toLowerCase(Locale.ROOT);
        boolean scalar = isScalar(size);
        switch (c) {
            case "string":
                return Kind.STRING;
            case "bool":
                return scalar ? Kind.BOOL : Kind.MATRIX;
            case "complex":
            case "complex128":
                return scalar ? Kind.COMPLEX : Kind.MATRIX;
            case "dict":
                return Kind.DICTIONARY;
            case "cell":
                return Kind.MATRIX;
            case "function_handle":
            case "func":
            case "function":
                return Kind.FUNCTION;
            default:
                break;
        }
        Kind numeric = numeric(c);
        if (numeric != null) {
            return scalar ? numeric : Kind.MATRIX;
        }
        if (c.isEmpty()) {
            return Kind.FLOAT64;
        }
        // Any other class name is an object of a user class.
        return inherited ? Kind.INHERITED_CLASS : Kind.CLASS;
    }

    private static Kind numeric(String c) {
        return switch (c) {
            case "int8" -> Kind.INT8;
            case "int16" -> Kind.INT16;
            case "int32" -> Kind.INT32;
            case "int64", "int" -> Kind.INT64;
            case "uint8" -> Kind.UINT8;
            case "uint16" -> Kind.UINT16;
            case "uint32" -> Kind.UINT32;
            case "uint64" -> Kind.UINT64;
            case "float8" -> Kind.FLOAT8;
            case "float16" -> Kind.FLOAT16;
            case "float32" -> Kind.FLOAT32;
            case "float64", "double" -> Kind.FLOAT64;
            default -> null;
        };
    }

    /**
     * @param size "RxC"
     * @return true for "1x1" (and for an empty or unreadable size)
     */
    static boolean isScalar(String size) {
        if (size == null || size.isBlank()) {
            return true;
        }
        String s = size.replace('×', 'x').strip();
        return s.equals("1x1") || s.equals("1");
    }

    // =====================================================================
    // Drawing
    // =====================================================================

    /**
     * @param kind the icon
     * @return the image for the theme on screen, or null if the file is
     *         missing (a warning is printed once)
     */
    public static Image image(Kind kind) {
        String folder = VariableStyles.isDark() ? "dark" : "light";
        String key = folder + "/" + kind.file();
        if (CACHE.containsKey(key)) {
            return CACHE.get(key);
        }
        Image image = null;
        String path = DIR + key + ".png";
        try (InputStream in = VariableIcons.class.getResourceAsStream(path)) {
            if (in != null) {
                image = new Image(in);
            } else {
                System.err.println("Missing variable icon: " + path);
            }
        } catch (Exception e) {
            System.err.println("Variable icon unreadable: " + path + " (" + e.getMessage() + ")");
        }
        CACHE.put(key, image);
        return image;
    }

    /**
     * @param kind the icon
     * @param size edge length in pixels
     * @return a smooth, square image view
     */
    public static ImageView view(Kind kind, double size) {
        ImageView view = new ImageView(image(kind));
        view.setFitWidth(size);
        view.setFitHeight(size);
        view.setPreserveRatio(true);
        view.setSmooth(true);
        return view;
    }
}
