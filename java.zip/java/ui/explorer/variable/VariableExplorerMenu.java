package ui.explorer.variable;

import java.util.List;

import javafx.scene.control.CheckMenuItem;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import ui.layout.LayoutManager;
import ui.ui_functions.Variable;

/**
 * The Variable Explorer's menus: the three-dot options menu on its title
 * strip, and the right-click menu on its rows. Both have square corners
 * ({@link VariableStyles}).
 *
 * <pre>
 *   Reset Explorer
 *   Minimise                (Restore while it is a rail)
 *   Refresh
 *   ---------------------
 *   Save Workspace...
 *   Load Workspace...
 *   ---------------------
 *   Visual Options      >   [x] Default
 *                           [ ] Split Window
 *                           [ ] Separate Window
 *   Select All
 *   Full Screen             (Exit Full Screen while on)
 *   Print               >   Workspace Table...
 *                           Variable 's'...
 *   ---------------------
 *   Close
 * </pre>
 *
 * <p>
 * Minimise and Close work in the Default layout only; in the static layouts
 * they are greyed (Separate Window still works there: the explorer moves to
 * its own window and the other panels share the space).
 * </p>
 */
final class VariableExplorerMenu {

    private VariableExplorerMenu() {
    }

    /** @return the three-dot options menu */
    static ContextMenu options() {
        ContextMenu menu = new ContextMenu();

        MenuItem reset = item("Reset Explorer", VariableExplorerController::resetExplorer);

        MenuItem minimise = item(VariableExplorerController.isMinimised() ? "Restore" : "Minimise",
                VariableExplorerController::toggleMinimised);
        minimise.setDisable(!VariableExplorerController.canMinimise());

        MenuItem refresh = item("Refresh", VariableExplorerController::refresh);

        MenuItem save = item("Save Workspace…", VariableExplorerController::saveWorkspace);
        MenuItem load = item("Load Workspace…", VariableExplorerController::loadWorkspace);

        Menu visual = new Menu("Visual Options");
        VariableViewMode current = VariableExplorerController.mode();
        for (VariableViewMode mode : VariableViewMode.values()) {
            CheckMenuItem tick = new CheckMenuItem(mode.label());
            tick.setSelected(mode == current);
            tick.setOnAction(e -> {
                tick.setSelected(true);
                VariableExplorerController.setMode(mode);
            });
            visual.getItems().add(tick);
        }

        MenuItem selectAll = item("Select All", VariableExplorerController::selectAll);
        selectAll.setDisable(VariableExplorerController.rowCount() == 0);

        MenuItem fullScreen = item(VariableExplorerController.isFullScreen() ? "Exit Full Screen" : "Full Screen",
                VariableExplorerController::toggleFullScreen);

        Menu print = new Menu("Print");
        MenuItem printTable = item("Workspace Table…", VariableExplorerController::printTable);
        String open = VariableExplorerController.selectedVariableName();
        MenuItem printVariable = item(open == null ? "Selected Variable…" : "Variable '" + open + "'…",
                VariableExplorerController::printVariable);
        printVariable.setDisable(open == null);
        print.getItems().addAll(printTable, printVariable);

        MenuItem close = item("Close", VariableExplorerController::close);
        // The separate window can always be closed; in the main window only
        // the Default layout closes panels.
        close.setDisable(current != VariableViewMode.SEPARATE && LayoutManager.isStaticLayout());

        menu.getItems().addAll(reset, minimise, refresh, new SeparatorMenuItem(),
                save, load, new SeparatorMenuItem(),
                visual, selectAll, fullScreen, print, new SeparatorMenuItem(),
                close);
        VariableStyles.styleMenu(menu);
        return menu;
    }

    /**
     * The right-click menu on the explorer's rows.
     *
     * @param selected the selected rows (may be empty)
     * @return the menu
     */
    static ContextMenu rows(List<Variable> selected) {
        ContextMenu menu = new ContextMenu();
        boolean none = selected.isEmpty();
        boolean one = selected.size() == 1;

        MenuItem open = item(one ? "Open" : "Open Selected",
                () -> selected.forEach(VariableExplorerController::open));
        open.setDisable(none);

        MenuItem copyName = item(one ? "Copy Name" : "Copy Names",
                () -> VariableExplorerController.copyNames(selected));
        copyName.setDisable(none);

        MenuItem copyValue = item(one ? "Copy Value" : "Copy Values",
                () -> VariableExplorerController.copyValues(selected));
        copyValue.setDisable(none);

        MenuItem clear = item(one ? "Clear Variable" : "Clear Selected",
                () -> VariableExplorerController.clearVariables(selected));
        clear.setDisable(none);

        MenuItem selectAll = item("Select All", VariableExplorerController::selectAll);
        selectAll.setDisable(VariableExplorerController.rowCount() == 0);

        MenuItem print = item("Print Workspace Table…", VariableExplorerController::printTable);

        menu.getItems().addAll(open, new SeparatorMenuItem(), copyName, copyValue,
                new SeparatorMenuItem(), clear, new SeparatorMenuItem(), selectAll, print);
        VariableStyles.styleMenu(menu);
        return menu;
    }

    private static MenuItem item(String text, Runnable action) {
        MenuItem item = new MenuItem(text);
        item.setOnAction(e -> action.run());
        return item;
    }
}
