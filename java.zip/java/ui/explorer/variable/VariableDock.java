package ui.explorer.variable;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;

import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.beans.property.ReadOnlyBooleanWrapper;
import javafx.collections.ListChangeListener;
import javafx.geometry.NodeOrientation;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.Tooltip;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import ui.design.Dim;

/**
 * The variable tabs and the grid of whichever one is selected.
 *
 * <h3>Two ways to sit</h3>
 * <ul>
 * <li><b>Overlay</b> (Visual Options &gt; Default). The dock lies over the
 * editor's own tab pane. Its tab strip is laid out right to left, so the
 * first variable opened sits at the far right and each new one lands to the
 * left of the last -- the script tabs keep filling from the left. Everything
 * of the dock but the variable tabs themselves is transparent and lets the
 * mouse through, so the script tabs underneath work as before. The grid is
 * shown over the editor only while a variable tab is <em>active</em>; a click
 * on any script tab hands the editor area back to the scripts. The two
 * strips keep separate selections, so Run always runs the script tab that
 * was selected last.</li>
 * <li><b>Standalone</b> (Split Window, Separate Window, Full Screen). The
 * dock is a panel of its own: an ordinary left-to-right tab strip over the
 * grid of the selected variable. With no variable open it shows a blank,
 * numbered sheet ({@link VariableViewer#emptySheet}) rather than an empty
 * white area.</li>
 * </ul>
 *
 * <h3>Tabs carry no content</h3>
 * <p>
 * The {@link TabPane} only draws the strip. The grids live in a separate
 * layer laid out under it, which is what lets the overlay show or hide them
 * independently of the strip. Each tab's user data is a {@link Key}, never
 * an {@code EditorFileInfo}, and the tabs are never in {@code ide.editorTabs},
 * so nothing that handles script tabs -- Run, Save, search, the deleted-file
 * check -- can mistake a variable for a file.
 * </p>
 */
final class VariableDock extends Pane {

    /** A variable tab's user data: the cleaned name it shows. */
    record Key(String cleanedName) {
    }

    private final TabPane tabs = new TabPane();
    private final StackPane content = new StackPane();
    private final Node emptySheet = VariableViewer.emptySheet("No variable open");
    private final Map<String, Tab> byName = new LinkedHashMap<>();
    private final Map<Tab, VariableViewer> viewers = new LinkedHashMap<>();

    private final ReadOnlyBooleanWrapper active = new ReadOnlyBooleanWrapper(false);
    private final ReadOnlyBooleanWrapper empty = new ReadOnlyBooleanWrapper(true);
    private boolean overlay = true;
    private double lastStripWidth = -1;
    private DoubleConsumer stripWidthListener;
    private Consumer<String> closedListener;

    VariableDock() {
        getStyleClass().add("variable-dock");
        tabs.getStyleClass().addAll("variable-tabs", Dim.Editor.TAB_PANE_CLASS);
        tabs.setTabClosingPolicy(TabPane.TabClosingPolicy.ALL_TABS);
        content.getStyleClass().add("variable-dock-content");
        getChildren().addAll(tabs, content);

        tabs.getSelectionModel().selectedItemProperty().addListener((obs, was, now) -> showSelected());
        tabs.getTabs().addListener((ListChangeListener<Tab>) c -> {
            while (c.next()) {
                for (Tab removed : c.getRemoved()) {
                    forget(removed);
                }
            }
            if (tabs.getTabs().isEmpty()) {
                active.set(false);
            }
            showSelected();
            updateVisibility();
            empty.set(tabs.getTabs().isEmpty());
        });
        // A press on a variable tab makes the variables the active side, even
        // when that tab was already the selected one.
        tabs.addEventFilter(MouseEvent.MOUSE_PRESSED, e -> {
            if (isInsideTab(e.getTarget())) {
                setActive(true);
            }
        });
        tabs.skinProperty().addListener((obs, was, now) -> applyPicking());
        setOverlay(true);
    }

    // =====================================================================
    // Tabs
    // =====================================================================

    /**
     * Opens a variable, or selects it if it is open already, and makes the
     * variables the active side.
     *
     * @param cleanedName the interpreter's name
     * @param visualName  the name the user reads
     * @param sender      sends an edit command
     * @return the tab's viewer
     */
    VariableViewer open(String cleanedName, String visualName, Consumer<String> sender) {
        Tab tab = byName.get(cleanedName);
        if (tab == null) {
            VariableViewer viewer = new VariableViewer(cleanedName, visualName, sender);
            tab = new Tab();
            tab.setGraphic(tabTitle(cleanedName));
            tab.setUserData(new Key(cleanedName));
            tab.setTooltip(new Tooltip(visualName));
            byName.put(cleanedName, tab);
            viewers.put(tab, viewer);
            // Appended: in the overlay's right-to-left strip that is to the
            // left of every variable already open.
            tabs.getTabs().add(tab);
        }
        tabs.getSelectionModel().select(tab);
        setActive(true);
        showSelected();
        return viewers.get(tab);
    }

    /**
     * A variable tab's title: its icon, then its name drawn as the Variable
     * Explorer draws it (A with a lowered μ, F with g and 2 stacked), not the
     * plain-text form, which can only show a subscript that has a Unicode
     * character. Always left to right, also in the overlay's right-to-left
     * strip, so the name is never mirrored.
     */
    private static HBox tabTitle(String cleanedName) {
        HBox title = new HBox(new Region(), VariableNameRenderer.render(cleanedName));
        title.getStyleClass().add("ve-name-cell");
        title.setAlignment(Pos.CENTER_LEFT);
        title.setNodeOrientation(NodeOrientation.LEFT_TO_RIGHT);
        return title;
    }

    /** Sets the icon on a variable's tab. */
    void setIcon(String cleanedName, VariableIcons.Kind kind) {
        Tab tab = byName.get(cleanedName);
        if (tab != null && tab.getGraphic() instanceof HBox title) {
            title.getChildren().set(0, VariableIcons.view(kind, Dim.VariableExplorer.TAB_ICON_SIZE));
            tab.getProperties().put(VariableIcons.Kind.class, kind);
        }
    }

    /** Repaints every tab icon and grid caption after a theme change. */
    void refreshIcons() {
        for (Map.Entry<String, Tab> e : byName.entrySet()) {
            Object kind = e.getValue().getProperties().get(VariableIcons.Kind.class);
            if (kind instanceof VariableIcons.Kind k) {
                setIcon(e.getKey(), k);
            }
        }
        viewers.values().forEach(VariableViewer::refreshIcons);
    }

    /** @return the viewer of an open variable, or null */
    VariableViewer viewer(String cleanedName) {
        Tab tab = byName.get(cleanedName);
        return tab == null ? null : viewers.get(tab);
    }

    /** @return every open viewer, in tab order */
    List<VariableViewer> viewers() {
        return new ArrayList<>(viewers.values());
    }

    /** @return the selected variable's viewer, or null */
    VariableViewer selectedViewer() {
        Tab tab = tabs.getSelectionModel().getSelectedItem();
        return tab == null ? null : viewers.get(tab);
    }

    /** @return true when no variable is open */
    boolean isEmpty() {
        return tabs.getTabs().isEmpty();
    }

    /** @return true while no variable is open, observable */
    ReadOnlyBooleanProperty emptyProperty() {
        return empty.getReadOnlyProperty();
    }

    /** @param listener told the cleaned name of every tab that closes */
    void setOnClosed(Consumer<String> listener) {
        closedListener = listener;
    }

    private void forget(Tab tab) {
        viewers.remove(tab);
        if (tab.getUserData() instanceof Key key) {
            byName.remove(key.cleanedName());
            if (closedListener != null) {
                closedListener.accept(key.cleanedName());
            }
        }
    }

    // =====================================================================
    // Overlay / standalone, active / inactive
    // =====================================================================

    /**
     * @param on true to lie over the script tabs (Default view), false to be
     *           a panel of its own
     */
    void setOverlay(boolean on) {
        overlay = on;
        tabs.setNodeOrientation(on ? NodeOrientation.RIGHT_TO_LEFT : NodeOrientation.LEFT_TO_RIGHT);
        content.setNodeOrientation(NodeOrientation.LEFT_TO_RIGHT);
        getStyleClass().removeAll("overlay", "standalone");
        getStyleClass().add(on ? "overlay" : "standalone");
        tabs.getStyleClass().removeAll("overlay", "standalone");
        tabs.getStyleClass().add(on ? "overlay" : "standalone");
        setPickOnBounds(!on);
        applyPicking();
        if (!on) {
            notifyStripWidth(0);
        }
        setActive(active.get());
        updateVisibility();
        requestLayout();
    }

    /** @return true while lying over the script tabs */
    boolean isOverlay() {
        return overlay;
    }

    /**
     * In the overlay, true while the grid is shown over the editor. A
     * standalone dock is always showing its grid.
     *
     * @param on the new state
     */
    void setActive(boolean on) {
        boolean value = on && !tabs.getTabs().isEmpty();
        active.set(value);
        // Only the overlay has a "not in front" look; a standalone strip
        // always shows its selected tab as selected.
        tabs.getStyleClass().remove("inactive");
        if (!value && overlay) {
            tabs.getStyleClass().add("inactive");
        }
        showSelected();
    }

    /** @return the active state, observable */
    ReadOnlyBooleanProperty activeProperty() {
        return active.getReadOnlyProperty();
    }

    /** @return true while the variables own the editor area (overlay) */
    boolean isActive() {
        return active.get();
    }

    /**
     * @param listener told how wide the variable tabs are, in the overlay,
     *                 so the script strip can stop short of them
     */
    void setOnStripWidth(DoubleConsumer listener) {
        stripWidthListener = listener;
    }

    private void showSelected() {
        VariableViewer viewer = selectedViewer();
        boolean show = !overlay || active.get();
        if (viewer == null) {
            content.getChildren().setAll(overlay ? List.<Node>of() : List.<Node>of(emptySheet));
        } else {
            content.getChildren().setAll(viewer);
        }
        content.setVisible(show && (viewer != null || !overlay));
        content.setManaged(true);
    }

    private void updateVisibility() {
        // An empty overlay draws nothing at all, so it must not exist for
        // the mouse either.
        boolean visible = !overlay || !tabs.getTabs().isEmpty();
        setVisible(visible);
        setMouseTransparent(!visible);
    }

    /**
     * In the overlay only the tabs themselves may take a click: the strip's
     * background, the header area and the (empty) content area let it fall
     * through to the script tabs.
     */
    private void applyPicking() {
        tabs.setPickOnBounds(!overlay);
        for (String selector : new String[] { ".tab-header-area", ".tab-header-background",
                ".headers-region", ".tab-content-area" }) {
            for (Node n : tabs.lookupAll(selector)) {
                n.setPickOnBounds(!overlay);
            }
        }
    }

    private static boolean isInsideTab(Object target) {
        Node n = target instanceof Node node ? node : null;
        while (n != null) {
            if (n.getStyleClass().contains("tab")) {
                return true;
            }
            n = n.getParent();
        }
        return false;
    }

    // =====================================================================
    // Layout
    // =====================================================================

    @Override
    protected void layoutChildren() {
        double w = getWidth();
        double h = getHeight();
        tabs.resizeRelocate(0, 0, w, h);
        tabs.applyCss();
        tabs.layout();
        // Picking has to be set again whenever the skin has made new nodes
        // (a new tab's content area, say).
        applyPicking();

        double top = 0;
        Node area = tabs.lookup(".tab-header-area");
        if (area != null && area.isVisible()) {
            top = area.getBoundsInParent().getMaxY();
        }
        content.resizeRelocate(0, top, w, Math.max(0, h - top));

        if (overlay) {
            Node headers = tabs.lookup(".headers-region");
            double strip = 0;
            if (headers instanceof Region r && !tabs.getTabs().isEmpty()) {
                strip = r.getWidth();
            }
            notifyStripWidth(strip);
        }
    }

    private void notifyStripWidth(double width) {
        if (Math.abs(width - lastStripWidth) < 0.5) {
            return;
        }
        lastStripWidth = width;
        if (stripWidthListener != null) {
            stripWidthListener.accept(width);
        }
    }
}
