package ui.explorer.variable;

import java.lang.ref.WeakReference;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Iterator;
import java.util.List;

import javafx.collections.ObservableList;
import javafx.scene.Parent;
import javafx.scene.control.ContextMenu;
import ui.design.Dim;
import ui.design.MenuStyle;
import ui.design.Typography;
import ui.design.UIScale;
import ui.layout.custom.CustomLayoutConfig;
import ui.managers.ThemeManager;

/**
 * The Variable Explorer's stylesheets, attached to the nodes that need them.
 *
 * <h3>Two sheets</h3>
 * <ul>
 * <li><b>Colours</b> -- {@code themes/variable_explorer/variable_light.css}
 * or {@code variable_dark.css}, swapped when the theme changes.</li>
 * <li><b>Geometry</b> -- generated here from {@code Dim.VariableExplorer}
 * and {@code Typography}: square corners, menu and cell padding, fonts.
 * Numbers stay in Java, colours stay in CSS, as everywhere else in Astra.</li>
 * </ul>
 *
 * <h3>Fonts</h3>
 * <p>
 * Every text here is the one UI font size ({@code Typography.uiFontSize()}),
 * the same as the File Explorer: the table cells, its column captions (bold),
 * the value grid, the menus and the dialog. Variable names keep the code face
 * ({@code Role.VARIABLE_NAME}) so subscripts and Greek letters read as code,
 * at the same size. The sheet is rebuilt and swapped in on every attached
 * node when the Font Size setting changes.
 * </p>
 *
 * <h3>Why on the nodes and not on the scene</h3>
 * <p>
 * A stylesheet on a {@code Parent} is consulted before the scene's sheets,
 * so these rules beat the broad ones in {@code light.css} / {@code dark.css}
 * (".table-cell", ".tab-pane") without a specificity war, and they travel
 * with the nodes into the separate window.
 * </p>
 *
 * <h3>Menus</h3>
 * <p>
 * Not here any more. The three-dot menu, its submenus and the table's
 * right-click menu are ordinary application menus ({@link #styleMenu},
 * {@link MenuStyle}): the same box, colours and font as every other menu.
 * </p>
 */
public final class VariableStyles {

    /**
     * Former style class of this feature's menus. Kept for code that refers
     * to it; the menus are styled by {@link MenuStyle} now.
     */
    public static final String MENU_CLASS = "variable-explorer-menu";

    private static final String LIGHT = "/themes/variable_explorer/variable_light.css";
    private static final String DARK = "/themes/variable_explorer/variable_dark.css";

    /** Size the name offsets (3px down, 6px up) were drawn for. */
    private static final double NAME_DESIGN_SIZE = 13;

    /** A subscript's size as a share of the name. */
    private static final double SUBSCRIPT_SHARE = 0.65;

    /** A superscript's size as a share of the name. */
    private static final double SUPERSCRIPT_SHARE = 0.55;

    /** Parents carrying the sheets, so a theme change can swap them. */
    private static final List<WeakReference<Parent>> ATTACHED = new ArrayList<>();

    private static String geometry;
    private static boolean darkApplied;

    static {
        Typography.addFontSizeListener(VariableStyles::fontSizeChanged);
    }

    private VariableStyles() {
    }

    /**
     * @return true while the dark theme is on. Read from {@code ThemeManager}
     *         directly, so it is already right while the theme-change
     *         notifications are still going round.
     */
    public static boolean isDark() {
        return CustomLayoutConfig.DARK.equals(ThemeManager.getActiveTheme());
    }

    /**
     * Gives a node both sheets, in the variant for the theme on screen.
     *
     * @param parent the node
     */
    public static void attach(Parent parent) {
        if (parent == null) {
            return;
        }
        darkApplied = isDark();
        apply(parent.getStylesheets(), darkApplied);
        ATTACHED.add(new WeakReference<>(parent));
    }

    /**
     * Swaps every attached node to the sheet for the current theme. Called by
     * the controller whenever the theme changes.
     */
    public static void themeChanged() {
        boolean dark = isDark();
        darkApplied = dark;
        Iterator<WeakReference<Parent>> it = ATTACHED.iterator();
        while (it.hasNext()) {
            Parent p = it.next().get();
            if (p == null) {
                it.remove();
            } else {
                apply(p.getStylesheets(), dark);
            }
        }
    }

    /**
     * Gives a Variable Explorer menu (three-dot menu, its submenus, the
     * table's right-click menu) the application's menu look. These menus no
     * longer carry colours or geometry of their own: they are ordinary
     * {@link MenuStyle} menus, the same box as every other menu.
     *
     * @param menu the menu
     */
    public static void styleMenu(ContextMenu menu) {
        MenuStyle.apply(menu);
    }

    /**
     * Rebuilds the geometry sheet for the new UI font size and swaps it in,
     * in place, on every node and menu that carries the old one.
     */
    private static void fontSizeChanged() {
        String old = geometry;
        geometry = null;
        String fresh = geometry();
        if (old == null || old.equals(fresh)) {
            return;
        }
        Iterator<WeakReference<Parent>> it = ATTACHED.iterator();
        while (it.hasNext()) {
            Parent p = it.next().get();
            if (p == null) {
                it.remove();
                continue;
            }
            ObservableList<String> sheets = p.getStylesheets();
            int at = sheets.indexOf(old);
            if (at >= 0) {
                sheets.set(at, fresh);
            } else if (!sheets.contains(fresh)) {
                sheets.add(fresh);
            }
        }
    }

    private static void apply(ObservableList<String> sheets, boolean dark) {
        String want = url(dark ? DARK : LIGHT);
        String other = url(dark ? LIGHT : DARK);
        if (other != null) {
            sheets.remove(other);
        }
        if (want != null && !sheets.contains(want)) {
            sheets.add(want);
        }
        String geo = geometry();
        if (!sheets.contains(geo)) {
            sheets.add(geo);
        }
    }

    private static String url(String resource) {
        URL url = VariableStyles.class.getResource(resource);
        if (url == null) {
            System.err.println("Missing stylesheet: " + resource);
            return null;
        }
        return url.toExternalForm();
    }

    /**
     * The generated geometry sheet. Built after the font families have been
     * resolved, and again after each change of the UI font size.
     *
     * @return a {@code data:} URI
     */
    private static String geometry() {
        if (geometry != null) {
            return geometry;
        }
        String r = UIScale.fmt(Dim.VariableExplorer.MENU_RADIUS);
        String font = Typography.css(Typography.Role.BREADCRUMB_SEGMENT);
        String rowFont = Typography.css(Typography.Role.DIRECTORY_ROW);
        String captionFont = Typography.css(Typography.Role.DIRECTORY_HEADER);
        String headerFont = Typography.css(Typography.Role.PANEL_TITLE);
        String cellPad = UIScale.fmt(Dim.VariableExplorer.CELL_PAD_H);

        StringBuilder css = new StringBuilder(2048);
        css.append("/* GENERATED by ui.explorer.variable.VariableStyles -- geometry only */\n");

        // ---- variable tabs --------------------------------------------------
        css.append(".variable-tabs > .tab-header-area > .headers-region > .tab {\n")
                .append("    -fx-background-radius: ").append(r).append(";\n}\n");

        // ---- grid ---------------------------------------------------------
        css.append(".variable-viewer-header {\n")
                .append("    -fx-padding: 0 ").append(UIScale.fmt(Dim.VariableExplorer.HEADER_PAD_H)).append(";\n")
                .append("    -fx-spacing: ").append(UIScale.fmt(Dim.VariableExplorer.HEADER_SPACING)).append(";\n")
                .append("    -fx-border-width: 0 0 1 0;\n}\n");
        css.append(".variable-viewer-title {\n    ").append(headerFont).append("\n}\n");
        // N-D page strip (VariableViewer): the page label in the caption font,
        // the axis captions and their square selectors in the row font.
        css.append(".variable-viewer-page-title {\n    ").append(headerFont).append("\n}\n");
        css.append(".variable-viewer-page-caption, .variable-viewer-page-key .text-field {\n    ")
                .append(rowFont).append("\n}\n");
        css.append(".variable-viewer-page-key, .variable-viewer-page-key .text-field,\n")
                .append(".variable-viewer-page-key .increment-arrow-button,\n")
                .append(".variable-viewer-page-key .decrement-arrow-button {\n")
                .append("    -fx-background-radius: 0;\n    -fx-border-radius: 0;\n}\n");
        css.append(".variable-viewer-message {\n    ").append(rowFont).append("\n")
                .append("    -fx-padding: ").append(UIScale.fmt(Dim.VariableExplorer.MESSAGE_PAD)).append(";\n}\n");
        css.append(".variable-grid {\n    -fx-padding: 0;\n    -fx-background-insets: 0;\n")
                .append("    -fx-background-radius: 0;\n    -fx-border-width: 0;\n}\n");
        css.append(".variable-grid .table-cell {\n    ").append(rowFont).append("\n")
                .append("    -fx-padding: 0 ").append(cellPad).append(";\n}\n");
        css.append(".variable-grid .column-header .label {\n    ").append(rowFont).append("\n")
                .append("    -fx-font-weight: bold;\n}\n");
        css.append(".variable-grid .ve-edit-field {\n")
                .append("    -fx-background-radius: 0;\n    -fx-border-radius: 0;\n")
                .append("    -fx-background-insets: 0;\n    -fx-border-width: 1;\n")
                .append("    -fx-padding: 0 ").append(cellPad).append(";\n    ").append(rowFont).append("\n}\n");

        // ---- confirmation dialog (VariableConfirmDialog): square ----------
        String dPad = UIScale.fmt(Dim.VariableExplorer.DIALOG_PAD);
        css.append(".ve-dialog {\n    -fx-border-width: 1;\n    -fx-background-radius: 0;\n")
                .append("    -fx-border-radius: 0;\n}\n");
        css.append(".ve-dialog-title-bar {\n    -fx-padding: 0 0 0 ")
                .append(UIScale.fmt(Dim.VariableExplorer.DIALOG_TITLE_PAD_LEFT)).append(";\n")
                .append("    -fx-spacing: ").append(UIScale.fmt(Dim.VariableExplorer.DIALOG_TITLE_SPACING))
                .append(";\n}\n");
        css.append(".ve-dialog-title {\n    ").append(font).append("\n}\n");
        css.append(".ve-dialog-close {\n    -fx-background-radius: 0;\n    -fx-background-insets: 0;\n")
                .append("    -fx-border-width: 0;\n    -fx-padding: 0;\n    -fx-cursor: default;\n}\n");
        css.append(".ve-dialog-head {\n    -fx-padding: ").append(dPad).append(";\n")
                .append("    -fx-border-width: 0 0 1 0;\n}\n");
        css.append(".ve-dialog-heading {\n    ").append(headerFont).append("\n}\n");
        css.append(".ve-dialog-content {\n    -fx-padding: ").append(dPad).append(";\n")
                .append("    -fx-spacing: ").append(dPad).append(";\n}\n");
        css.append(".ve-dialog-message {\n    ").append(rowFont).append("\n}\n");
        css.append(".ve-dialog-buttons {\n    -fx-spacing: ")
                .append(UIScale.fmt(Dim.VariableExplorer.DIALOG_BUTTON_GAP)).append(";\n}\n");
        css.append(".ve-dialog-button {\n    -fx-background-radius: 0;\n    -fx-border-radius: 0;\n")
                .append("    -fx-background-insets: 0;\n    -fx-border-width: 1;\n")
                .append("    -fx-padding: ").append(UIScale.fmt(Dim.VariableExplorer.DIALOG_BUTTON_PAD_V))
                .append(" ").append(UIScale.fmt(Dim.VariableExplorer.DIALOG_BUTTON_PAD_H)).append(";\n    ")
                .append(rowFont).append("\n}\n");

        // ---- explorer table name cell ------------------------------------
        css.append(".ve-name-cell {\n    -fx-spacing: ")
                .append(UIScale.fmt(Dim.VariableExplorer.NAME_ICON_GAP)).append(";\n}\n");

        // ---- explorer table: cells and captions -----------------------------
        // The table used to inherit the 13px root size, a step above the File
        // Explorer; both are the one UI font size now. Captions are bold, as
        // in the File Explorer's header.
        css.append(".variable-explorer-table .table-cell {\n    ").append(rowFont).append("\n}\n");
        css.append(".variable-explorer-table .column-header .label {\n    ").append(captionFont)
                .append("\n    -fx-font-weight: bold;\n}\n");

        // ---- variable names ------------------------------------------------
        // Drawn by VariableNameRenderer as Text nodes in a TextFlow carrying
        // .variable-explorer. The code face at the UI size; sub- and
        // superscripts keep their proportions, and their offsets were drawn
        // for a 13px name, so they scale with the size.
        double nameSize = Typography.size(Typography.Role.VARIABLE_NAME);
        double shift = nameSize / NAME_DESIGN_SIZE;
        css.append(".variable-explorer .text {\n    ")
                .append(Typography.css(Typography.Role.VARIABLE_NAME)).append("\n}\n");
        css.append(".variable-explorer .text.subscript-single, .variable-explorer .text.subscript-greek,\n")
                .append(".variable-explorer .text.subscript-greek-single,")
                .append(" .variable-explorer .text.subscript-greek-multi,\n")
                .append(".variable-explorer .text.subscript-multi {\n")
                .append("    -fx-font-size: ").append(UIScale.fmt(nameSize * SUBSCRIPT_SHARE)).append("px;\n")
                .append("    -fx-translate-y: ").append(UIScale.fmt(3 * shift)).append("px;\n")
                .append("    -fx-translate-x: 0em;\n}\n");
        css.append(".variable-explorer .text.superscript-single, .variable-explorer .text.superscript-greek,\n")
                .append(".variable-explorer .text.superscript-greek-single,")
                .append(" .variable-explorer .text.superscript-greek-multi,\n")
                .append(".variable-explorer .text.superscript-multi {\n")
                .append("    -fx-font-size: ").append(UIScale.fmt(nameSize * SUPERSCRIPT_SHARE)).append("px;\n")
                .append("    -fx-translate-y: ").append(UIScale.fmt(-6 * shift)).append("px;\n")
                .append("    -fx-translate-x: 0em;\n}\n");
        css.append(".variable-explorer .text.subscript-superscript {\n")
                .append("    -fx-font-size: ").append(UIScale.fmt(nameSize * SUPERSCRIPT_SHARE)).append("px;\n")
                .append("    -fx-translate-y: ").append(UIScale.fmt(-1 * shift)).append("px;\n")
                .append("    -fx-translate-x: 0em;\n}\n");

        geometry = "data:text/css;base64,"
                + Base64.getEncoder().encodeToString(css.toString().getBytes(StandardCharsets.UTF_8));
        return geometry;
    }
}
