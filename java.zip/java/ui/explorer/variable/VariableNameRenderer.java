package ui.explorer.variable;

import java.util.ArrayList;
import java.util.List;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;

/** Renders variable-name subscript and superscript markers. */
public final class VariableNameRenderer {
    private static final char SUBSCRIPT_MARKER = '\u200D';
    private static final char SUPERSCRIPT_MARKER = '\u200C';

    private VariableNameRenderer() {
    }

    public static TextFlow render(String value) {
        String safeValue = value == null ? "" : value;
        List<Text> nodes = new ArrayList<>();
        StringBuilder plain = new StringBuilder();
        boolean subscript = false;
        boolean superscript = false;
        boolean braceMode = false;

        int index = 0;
        while (index < safeValue.length()) {
            char current = safeValue.charAt(index);

            if (!braceMode
                    && index + 1 < safeValue.length()
                    && safeValue.charAt(index + 1) == '{'
                    && (current == '_' || current == '^')) {
                flush(nodes, plain, subscript, superscript);
                subscript = current == '_';
                superscript = current == '^';
                braceMode = true;
                index += 2;
                continue;
            }

            if (current == SUBSCRIPT_MARKER || current == SUPERSCRIPT_MARKER) {
                flush(nodes, plain, subscript, superscript);
                char marker = current;
                while (index < safeValue.length() && safeValue.charAt(index) == marker) {
                    index++;
                }
                if (marker == SUBSCRIPT_MARKER) {
                    subscript = !subscript;
                } else {
                    superscript = !superscript;
                }
                continue;
            }

            if (braceMode && current == '}') {
                flush(nodes, plain, subscript, superscript);
                subscript = false;
                superscript = false;
                braceMode = false;
                index++;
                continue;
            }

            plain.append(current);
            index++;
        }

        flush(nodes, plain, subscript, superscript);
        TextFlow flow = new TextFlow(nodes.toArray(Text[]::new));
        flow.getStyleClass().add("variable-explorer");
        return flow;
    }

    private static void flush(
            List<Text> nodes,
            StringBuilder plain,
            boolean subscript,
            boolean superscript) {
        if (plain.length() == 0) {
            return;
        }
        Text node = new Text(plain.toString());
        if (subscript && superscript) {
            node.getStyleClass().add("subscript-superscript");
        } else if (subscript) {
            node.getStyleClass().add("subscript-single");
        } else if (superscript) {
            node.getStyleClass().add("superscript-single");
        }
        nodes.add(node);
        plain.setLength(0);
    }
}
