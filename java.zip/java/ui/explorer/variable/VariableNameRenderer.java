package ui.explorer.variable;

import java.util.List;

import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import language.semantic.VariableNameDecoder;

/**
 * Draws a variable name in its editor-visual form.
 *
 * <p>The renderer no longer parses markers out of a string. It receives already
 * decoded {@link VariableNameDecoder.Segment}s, so a name can never be
 * half-rendered and the decoding rules live in exactly one place.
 *
 * <p>The CSS classes are unchanged, so {@code light.css} / {@code dark.css}
 * need no edits.
 */
public final class VariableNameRenderer {

    private VariableNameRenderer() {
    }

    /**
     * Renders a cleaned variable name as its visual form.
     *
     * @param cleanedName the name exactly as {@code nc.exe} reported it
     * @return a laid-out {@link TextFlow}
     */
    public static TextFlow render(String cleanedName) {
        return render(VariableNameDecoder.decode(cleanedName));
    }

    /**
     * Renders pre-decoded segments.
     *
     * @param segments the decoded name
     * @return a laid-out {@link TextFlow}
     */
    public static TextFlow render(List<VariableNameDecoder.Segment> segments) {
        TextFlow flow = new TextFlow();
        flow.getStyleClass().add("variable-explorer");
        if (segments == null) {
            return flow;
        }
        for (VariableNameDecoder.Segment segment : segments) {
            if (segment.getText().isEmpty()) {
                continue;
            }
            Text node = new Text(segment.getText());
            switch (segment.getLevel()) {
                case SUBSCRIPT -> node.getStyleClass().add("subscript-single");
                case SUPERSCRIPT -> node.getStyleClass().add("superscript-single");
                default -> { }
            }
            flow.getChildren().add(node);
        }
        return flow;
    }
}
