package ui.explorer.variable;

import java.util.List;

import javafx.geometry.VPos;
import javafx.scene.layout.Region;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import language.semantic.VariableNameDecoder;

/**
 * Draws a variable name in its editor-visual form.
 *
 * <p>The renderer no longer parses markers out of a string. It receives already
 * decoded {@link VariableNameDecoder.Segment}s, so a name can never be
 * half-rendered and the decoding rules live in exactly one place.
 *
 * <p>The CSS classes are unchanged, so {@code light.css} / {@code dark.css}
 * need no edits.
 *
 * <h3>Why subscripts never showed (fixed)</h3>
 * <p>The sizes and offsets live in {@code VariableStyles} under selectors such
 * as {@code .variable-explorer .text.subscript-single}. A JavaFX {@code Text}
 * made with {@code new Text(...)} has <b>no</b> style class at all -- unlike
 * the text inside a Label or a RichTextFX area, it is not given "text" -- so
 * none of those rules ever matched and A&#8321; was drawn as a plain "A1".
 * Every segment now carries the {@code text} class, so the name gets the code
 * font and the subscript / superscript get their size and offset.</p>
 */
public final class VariableNameRenderer {

    private VariableNameRenderer() {
    }

    /**
     * Renders a cleaned variable name as its visual form.
     *
     * @param cleanedName the name exactly as {@code nc.exe} reported it
     * @return a laid-out {@link TextFlow}
     */
    public static TextFlow render(String cleanedName) {
        return render(VariableNameDecoder.decode(cleanedName));
    }

    /**
     * Renders pre-decoded segments.
     *
     * @param segments the decoded name
     * @return a laid-out {@link TextFlow}
     */
    public static TextFlow render(List<VariableNameDecoder.Segment> segments) {
        TextFlow flow = new TextFlow();
        flow.getStyleClass().add("variable-explorer");
        if (segments == null) {
            return flow;
        }
        for (int i = 0; i < segments.size(); i++) {
            VariableNameDecoder.Segment segment = segments.get(i);
            if (segment.getText().isEmpty()) {
                continue;
            }
            VariableNameDecoder.Segment next = i + 1 < segments.size() ? segments.get(i + 1) : null;
            if (segment.getLevel() == VariableNameDecoder.Level.SUBSCRIPT && next != null
                    && next.getLevel() == VariableNameDecoder.Level.SUPERSCRIPT && !next.getText().isEmpty()) {
                // F with g below and 2 above, in one column -- as the editor draws it.
                flow.getChildren().add(new ScriptColumn(text(segment), text(next)));
                i++;
                continue;
            }
            flow.getChildren().add(text(segment));
        }
        return flow;
    }

    /** One segment as a styled Text. */
    private static Text text(VariableNameDecoder.Segment segment) {
        Text node = new Text(segment.getText());
        // Needed for every ".variable-explorer .text..." rule in VariableStyles.
        node.getStyleClass().add("text");
        switch (segment.getLevel()) {
            case SUBSCRIPT -> node.getStyleClass().add("subscript-single");
            case SUPERSCRIPT -> node.getStyleClass().add("superscript-single");
            default -> { }
        }
        return node;
    }

    /**
     * A subscript and a superscript drawn in one column: both start at the
     * same x, each raised or lowered by its own CSS offset, and the column is
     * as wide as the wider of the two. Placed in the name's {@link TextFlow}
     * on the baseline, like the text around it.
     */
    static final class ScriptColumn extends Region {

        private final Text sub;
        private final Text sup;

        ScriptColumn(Text sub, Text sup) {
            this.sub = sub;
            this.sup = sup;
            sub.setTextOrigin(VPos.BASELINE);
            sup.setTextOrigin(VPos.BASELINE);
            getChildren().addAll(sub, sup);
        }

        /** Distance from the top to the baseline: the taller ascent of the two. */
        private double ascent() {
            return Math.max(-sub.getLayoutBounds().getMinY(), -sup.getLayoutBounds().getMinY());
        }

        private double descent() {
            return Math.max(sub.getLayoutBounds().getMaxY(), sup.getLayoutBounds().getMaxY());
        }

        @Override
        protected void layoutChildren() {
            double baseline = ascent();
            sub.setLayoutX(0);
            sup.setLayoutX(0);
            sub.setLayoutY(baseline);
            sup.setLayoutY(baseline);
        }

        @Override
        protected double computePrefWidth(double height) {
            return Math.max(sub.getLayoutBounds().getWidth(), sup.getLayoutBounds().getWidth());
        }

        @Override
        protected double computePrefHeight(double width) {
            return ascent() + descent();
        }

        @Override
        protected double computeMinWidth(double height) {
            return computePrefWidth(height);
        }

        @Override
        protected double computeMinHeight(double width) {
            return computePrefHeight(width);
        }

        @Override
        public double getBaselineOffset() {
            return ascent();
        }
    }
}
