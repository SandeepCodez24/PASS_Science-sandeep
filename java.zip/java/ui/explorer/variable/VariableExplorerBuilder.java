package ui.explorer.variable;

import java.util.List;
import javafx.geometry.Pos;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import ui.UI_Main;
import ui.explorer.CollapsiblePanel;
import ui.ui_functions.Variable;

/** Builds the variable explorer table and its collapsible panel. */
public final class VariableExplorerBuilder {
    private VariableExplorerBuilder() {
    }

    public static CollapsiblePanel build(UI_Main ide) {
        ide.varTable = new TableView<>();
        ide.varTable.getStyleClass().add("variable-explorer-table");
        ide.varTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
        ide.varTable.setFixedCellSize(26);

        TableColumn<Variable, String> nameColumn = createColumn("Name", "name");
        nameColumn.setCellFactory(column -> new TableCell<>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                setText(null);
                setGraphic(empty || item == null ? null : VariableNameRenderer.render(item));
                setAlignment(Pos.CENTER_LEFT);
            }
        });

        TableColumn<Variable, String> valueColumn = createTextColumn("Value", "value");
        TableColumn<Variable, String> sizeColumn = createTextColumn("Size", "size");
        TableColumn<Variable, String> datatypeColumn = createTextColumn("Datatype", "datatype");

        ide.varTable.getColumns().addAll(List.of(
                nameColumn, valueColumn, sizeColumn, datatypeColumn));
        ide.varTable.setMaxWidth(Double.MAX_VALUE);

        CollapsiblePanel panel = new CollapsiblePanel("Variable Explorer", ide.varTable);
        panel.setPrefWidth(380);
        panel.setMinWidth(320);
        panel.setMaxWidth(Double.MAX_VALUE);
        return panel;
    }

    private static TableColumn<Variable, String> createTextColumn(String title, String property) {
        TableColumn<Variable, String> column = createColumn(title, property);
        column.setCellFactory(ignored -> new TableCell<>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item);
                setGraphic(null);
                setAlignment(Pos.CENTER_LEFT);
            }
        });
        return column;
    }

    private static TableColumn<Variable, String> createColumn(String title, String property) {
        TableColumn<Variable, String> column = new TableColumn<>(title);
        column.setCellValueFactory(new PropertyValueFactory<>(property));
        return column;
    }
}
