package ui.explorer.variable;

import java.util.List;

import javafx.geometry.Pos;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import ui.UI_Main;
import ui.design.Dim;
import ui.design.Typography;
import ui.explorer.CollapsiblePanel;
import ui.explorer.signal.SignalExplorerHost;
import ui.ui_functions.Variable;
import ui.ui_functions.WorkspaceStore;

/**
 * Builds the Variable Explorer table and its collapsible panel.
 *
 * <p>The Name column is bound to the <b>cleaned</b> name (the internal key) but
 * never displays it: the cell factory renders the decoded visual form instead,
 * so &#956;<sub>j</sub> is what the user sees while {@code var_mu__sj} is what
 * the system keys on. A type icon sits in front of the name
 * ({@link VariableIcons}).
 *
 * <p>The table's items are owned by {@link WorkspaceStore}. Nothing else may
 * call {@code setItems} on it — that single-ownership rule is what makes
 * duplicate rows impossible.
 *
 * <p>The panel's body is built by {@link SignalExplorerHost}: a vertical split
 * holding the table, into which the Signal Explorer docks (bottom 20%) when it
 * is open.
 *
 * <h3>What changed</h3>
 * <ul>
 * <li><b>Three-dot menu.</b> The title strip carries an options button at its
 * right end ({@link VariableExplorerMenu#options()}): Reset Explorer,
 * Minimise, Refresh, Save / Load Workspace, Visual Options, Select All, Full
 * Screen, Print and Close.</li>
 * <li><b>Rows open variables.</b> A click anywhere in a row opens that
 * variable in a tab; Shift and Ctrl clicks select several rows; the
 * right-click menu offers Open, Copy, Clear and Select All. See
 * {@link VariableExplorerController#installTable}.</li>
 * <li><b>Type icons</b> in the Name column, light and dark sets.</li>
 * <li>The row height comes from {@code Dim.VariableExplorer} (was a literal
 * 26).</li>
 * </ul>
 */
public final class VariableExplorerBuilder {

    private VariableExplorerBuilder() {
    }

    /**
     * @param ide the IDE controller
     * @return the collapsible panel wrapping the table
     */
    public static CollapsiblePanel build(UI_Main ide) {
        ide.varTable = new TableView<>();
        ide.varTable.getStyleClass().add("variable-explorer-table");
        ide.varTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
        ide.varTable.setFixedCellSize(Dim.VariableExplorer.TABLE_ROW_HEIGHT);
        // Font Size setting: the row height grows with the text, so the fixed
        // cell size is set again whenever the size changes.
        TableView<Variable> table = ide.varTable;
        Typography.addFontSizeListener(() -> {
            table.setFixedCellSize(Dim.VariableExplorer.TABLE_ROW_HEIGHT);
            table.refresh();
        });
        ide.varTable.setPlaceholder(new javafx.scene.control.Label("No variables in the workspace"));

        TableColumn<Variable, String> nameColumn = createColumn("Name", "name");
        nameColumn.setCellFactory(column -> new TableCell<>() {
            @Override
            protected void updateItem(String cleanedName, boolean empty) {
                super.updateItem(cleanedName, empty);
                setText(null);
                Variable row = empty || getTableRow() == null ? null : getTableRow().getItem();
                if (empty || cleanedName == null || row == null) {
                    setGraphic(null);
                } else {
                    HBox box = new HBox(
                            VariableIcons.view(VariableIcons.forVariable(row), Dim.VariableExplorer.TABLE_ICON_SIZE),
                            VariableNameRenderer.render(cleanedName));
                    box.getStyleClass().add("ve-name-cell");
                    box.setAlignment(Pos.CENTER_LEFT);
                    setGraphic(box);
                }
                setAlignment(Pos.CENTER_LEFT);
            }
        });

        TableColumn<Variable, String> valueColumn = createTextColumn("Value", "value");
        TableColumn<Variable, String> sizeColumn = createTextColumn("Size", "size");
        TableColumn<Variable, String> datatypeColumn = createTextColumn("Datatype", "datatype");

        ide.varTable.getColumns().addAll(List.of(
                nameColumn, valueColumn, sizeColumn, datatypeColumn));
        ide.varTable.setMaxWidth(Double.MAX_VALUE);

        // Single ownership: from here on the store drives the rows.
        WorkspaceStore.get().bind(ide.varTable);

        // Click to open, multi-select, right-click menu, Enter.
        VariableExplorerController.installTable(ide.varTable);

        CollapsiblePanel panel = new CollapsiblePanel("Variable Explorer",
                SignalExplorerHost.buildBody(ide.varTable));
        panel.getHeader().withMenu(VariableExplorerMenu::options);
        panel.setPrefWidth(Dim.Layout.VARIABLE_PANEL_PREF_WIDTH);
        panel.setMinWidth(Dim.Layout.VARIABLE_PANEL_MIN_WIDTH);
        panel.setMaxWidth(Double.MAX_VALUE);
        return panel;
    }

    private static TableColumn<Variable, String> createTextColumn(String title, String property) {
        TableColumn<Variable, String> column = createColumn(title, property);
        column.setCellFactory(ignored -> new TableCell<>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item);
                setGraphic(null);
                setAlignment(Pos.CENTER_LEFT);
            }
        });
        return column;
    }

    private static TableColumn<Variable, String> createColumn(String title, String property) {
        TableColumn<Variable, String> column = new TableColumn<>(title);
        column.setCellValueFactory(new PropertyValueFactory<>(property));
        return column;
    }
}
