package ui.explorer.variable;

import java.util.List;

import javafx.geometry.Pos;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import ui.UI_Main;
import ui.explorer.CollapsiblePanel;
import ui.ui_functions.Variable;
import ui.ui_functions.WorkspaceStore;

/**
 * Builds the Variable Explorer table and its collapsible panel.
 *
 * <p>The Name column is bound to the <b>cleaned</b> name (the internal key) but
 * never displays it: the cell factory renders the decoded visual form instead,
 * so &#956;<sub>j</sub> is what the user sees while {@code var_mu__sj} is what
 * the system keys on.
 *
 * <p>The table's items are owned by {@link WorkspaceStore}. Nothing else may
 * call {@code setItems} on it — that single-ownership rule is what makes
 * duplicate rows impossible.
 */
public final class VariableExplorerBuilder {

    private VariableExplorerBuilder() {
    }

    /**
     * @param ide the IDE controller
     * @return the collapsible panel wrapping the table
     */
    public static CollapsiblePanel build(UI_Main ide) {
        ide.varTable = new TableView<>();
        ide.varTable.getStyleClass().add("variable-explorer-table");
        ide.varTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
        ide.varTable.setFixedCellSize(26);
        ide.varTable.setPlaceholder(new javafx.scene.control.Label("No variables in the workspace"));

        TableColumn<Variable, String> nameColumn = createColumn("Name", "name");
        nameColumn.setCellFactory(column -> new TableCell<>() {
            @Override
            protected void updateItem(String cleanedName, boolean empty) {
                super.updateItem(cleanedName, empty);
                setText(null);
                setGraphic(empty || cleanedName == null
                        ? null
                        : VariableNameRenderer.render(cleanedName));
                setAlignment(Pos.CENTER_LEFT);
            }
        });

        TableColumn<Variable, String> valueColumn = createTextColumn("Value", "value");
        TableColumn<Variable, String> sizeColumn = createTextColumn("Size", "size");
        TableColumn<Variable, String> datatypeColumn = createTextColumn("Datatype", "datatype");

        ide.varTable.getColumns().addAll(List.of(
                nameColumn, valueColumn, sizeColumn, datatypeColumn));
        ide.varTable.setMaxWidth(Double.MAX_VALUE);

        // Single ownership: from here on the store drives the rows.
        WorkspaceStore.get().bind(ide.varTable);

        CollapsiblePanel panel = new CollapsiblePanel("Variable Explorer", ide.varTable);
        panel.setPrefWidth(380);
        panel.setMinWidth(320);
        panel.setMaxWidth(Double.MAX_VALUE);
        return panel;
    }

    private static TableColumn<Variable, String> createTextColumn(String title, String property) {
        TableColumn<Variable, String> column = createColumn(title, property);
        column.setCellFactory(ignored -> new TableCell<>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item);
                setGraphic(null);
                setAlignment(Pos.CENTER_LEFT);
            }
        });
        return column;
    }

    private static TableColumn<Variable, String> createColumn(String title, String property) {
        TableColumn<Variable, String> column = new TableColumn<>(title);
        column.setCellValueFactory(new PropertyValueFactory<>(property));
        return column;
    }
}
