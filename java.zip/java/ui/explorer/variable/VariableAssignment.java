package ui.explorer.variable;

import java.util.Locale;

import ui.cli.CliSymbolCodec;

/**
 * The Neural Code lines a grid edit sends to {@code nc.exe}.
 *
 * <h3>One place for the syntax</h3>
 * <p>
 * Every command an edit can produce is built from the templates below, so
 * if the language spells element assignment differently, these strings are
 * the only thing to change.
 * </p>
 *
 * <h3>Indices</h3>
 * <p>
 * The grid numbers its rows and columns from 1, as MATLAB does, but Neural
 * Code indexes from 0 ({@link #INDEX_BASE}). So the cell the grid shows at
 * row 3, column 3 goes out as {@code A[2,2]}.
 * </p>
 *
 * <pre>
 *   A = 5;            whole value (scalars, strings, bools, complex)
 *   A[2] = 5;         one element of a vector     (grid cell 3)
 *   A[1,2] = 5;       one element of a matrix     (grid row 2, column 3)
 *   B[1,0,2] = 5;     one element of an N-D matrix (page B[1,:,:], grid row 1, column 3)
 *   d["key"] = 5;     one entry of a dictionary
 * </pre>
 *
 * <h3>The type is kept</h3>
 * <p>
 * A bare number is a {@code float64} in Neural Code, so editing an
 * {@code int32} cell to {@code 7} would turn the variable into a float. Every
 * value going into a typed number is therefore wrapped in that type's cast
 * ({@link #cast}): {@code x = int32(7);}, {@code A[2,3] = uint8(5);}.
 * {@code float64} needs no cast and gets none.
 * </p>
 *
 * <p>
 * The name is the cleaned name the interpreter knows ({@code var_mu}), so it
 * goes out as it is. What the user typed is passed through
 * {@link CliSymbolCodec#encodeLine}, exactly as a typed Command Window line
 * is, so a Greek or Tamil variable used in an expression ({@code μ*2})
 * reaches the interpreter in cleaned form. Every command ends in {@code ;},
 * so the interpreter does not echo the new value into the Command Window.
 * </p>
 */
public final class VariableAssignment {

    /** Whole value: name, expression. */
    public static final String WHOLE = "%s = %s;";

    /** One element of a vector: name, 1-based index, expression. */
    public static final String ELEMENT_1D = "%s[%d] = %s;";

    /** One element of a matrix: name, 1-based row, 1-based column, expression. */
    public static final String ELEMENT_2D = "%s[%d,%d] = %s;";

    /** One element of an N-D matrix: name, the keys joined by {@link #KEY_SEPARATOR}, expression. */
    public static final String ELEMENT_ND = "%s[%s] = %s;";

    /** Between the keys of an N-D index. */
    public static final String KEY_SEPARATOR = ",";

    /** One dictionary entry: name, key literal, expression. */
    public static final String DICT_ENTRY = "%s[%s] = %s;";

    /** A cast that keeps a number's type: type name, expression. */
    public static final String CAST = "%s(%s)";

    /**
     * The index of the first element in Neural Code: {@code A[0]} is the
     * first element, {@code A[0,0]} the top-left one.
     */
    public static final int INDEX_BASE = 0;

    private VariableAssignment() {
    }

    /**
     * @param name the cleaned variable name
     * @param expr an expression already passed through {@link #expression}
     * @return {@code name = expr;}
     */
    public static String whole(String name, String expr) {
        return String.format(Locale.ROOT, WHOLE, name, expr);
    }

    /**
     * @param name  the cleaned variable name
     * @param index 0-based position in the grid; written from {@link #INDEX_BASE}
     * @param expr  the expression
     * @return {@code name[i] = expr;}
     */
    public static String element(String name, int index, String expr) {
        return String.format(Locale.ROOT, ELEMENT_1D, name, index + INDEX_BASE, expr);
    }

    /**
     * @param name the cleaned variable name
     * @param row  0-based row in the grid; written from {@link #INDEX_BASE}
     * @param col  0-based column in the grid; written from {@link #INDEX_BASE}
     * @param expr the expression
     * @return {@code name[r,c] = expr;}
     */
    public static String element(String name, int row, int col, String expr) {
        return String.format(Locale.ROOT, ELEMENT_2D, name, row + INDEX_BASE, col + INDEX_BASE, expr);
    }

    /**
     * @param name  the cleaned variable name
     * @param index one 0-based key per axis, outermost first; each written
     *              from {@link #INDEX_BASE}
     * @param expr  the expression
     * @return {@code name[i0,i1,...,r,c] = expr;}
     */
    public static String element(String name, int[] index, String expr) {
        StringBuilder keys = new StringBuilder();
        for (int i = 0; i < index.length; i++) {
            if (i > 0) {
                keys.append(KEY_SEPARATOR);
            }
            keys.append(index[i] + INDEX_BASE);
        }
        return String.format(Locale.ROOT, ELEMENT_ND, name, keys, expr);
    }

    /**
     * @param name    the cleaned variable name
     * @param keyText the key as a literal ({@link #quote} for a text key)
     * @param expr    the expression
     * @return {@code name[key] = expr;}
     */
    public static String entry(String name, String keyText, String expr) {
        return String.format(Locale.ROOT, DICT_ENTRY, name, keyText, expr);
    }

    /**
     * Wraps an expression in the cast for a number type, so an edit keeps
     * the variable's type. Types without a cast (float64, bool, complex,
     * string, anything unknown) leave the expression as it is.
     *
     * @param type the interpreter's type name, e.g. {@code int32}
     * @param expr the expression
     * @return {@code int32(expr)}, or {@code expr}
     */
    public static String cast(String type, String expr) {
        String t = type == null ? "" : type.strip().toLowerCase(Locale.ROOT);
        boolean typed = t.matches("u?int(8|16|32|64)") || t.matches("float(8|16|32)");
        return typed ? String.format(Locale.ROOT, CAST, t, expr) : expr;
    }

    /**
     * Turns what was typed into an expression the interpreter can read.
     *
     * @param typed the cell text
     * @return the encoded expression
     * @throws IllegalArgumentException when nothing was typed
     */
    public static String expression(String typed) {
        String t = typed == null ? "" : typed.strip();
        if (t.isEmpty()) {
            throw new IllegalArgumentException("Type a value, or press Esc to cancel.");
        }
        // A trailing ';' would end the statement before ours does.
        while (t.endsWith(";")) {
            t = t.substring(0, t.length() - 1).strip();
        }
        if (t.isEmpty()) {
            throw new IllegalArgumentException("Type a value, or press Esc to cancel.");
        }
        return CliSymbolCodec.encodeLine(t);
    }

    /**
     * Writes text as a Neural Code string literal. Both {@code "} and
     * {@code '} delimit strings and each may sit inside the other, so the
     * delimiter the text does not contain is used.
     *
     * @param text the raw text
     * @return the literal, quotes included
     * @throws IllegalArgumentException when the text contains both quote
     *                                  characters, which no literal can hold
     */
    public static String quote(String text) {
        String t = text == null ? "" : text;
        if (t.indexOf('\n') >= 0 || t.indexOf('\r') >= 0) {
            throw new IllegalArgumentException("A string edited here cannot contain a line break.");
        }
        if (t.indexOf('"') < 0) {
            return "\"" + t + "\"";
        }
        if (t.indexOf('\'') < 0) {
            return "'" + t + "'";
        }
        throw new IllegalArgumentException(
                "This text holds both \" and ' quotes; assign it from the Command Window instead.");
    }
}
