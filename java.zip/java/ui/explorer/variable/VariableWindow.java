package ui.explorer.variable;

import javafx.application.Platform;
import javafx.collections.ListChangeListener;
import javafx.geometry.Orientation;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.SplitPane;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.stage.WindowEvent;
import ui.UI_Main;
import ui.design.Dim;
import ui.ui_functions.tools.PrintStudioWindow;

/**
 * Visual Options &gt; Separate Window: the Variable Explorer -- table and
 * variable tabs -- in a window of its own, titled "Workspace Window".
 * <p>
 * The right side is never left blank: the first variable in the table is
 * opened when the window appears, and with nothing open the dock shows an
 * empty numbered sheet.
 * </p>
 *
 * <pre>
 *   +-- Workspace Window --------------------------------------------+
 *   | v Variable Explorer    [:] | var1 x | var2 x |                 |
 *   | Name | Value | Size | ...  | [#] 5×5 float64                  |
 *   | A    | [[1,0..  5x5  ...   |     1    2    3    4    5        |
 *   | ...                        |  1  1    0    0    0    0        |
 *   +----------------------------------------------------------------+
 * </pre>
 *
 * <h3>Showing and hiding</h3>
 * <p>
 * Closing the window only hides it; the controller shows it again the next
 * time a script runs or a command is typed, and whenever a variable is
 * opened. It is never shown at launch: in this view the IDE starts without a
 * Variable Explorer, and the window appears with the first run.
 * </p>
 *
 * <h3>Look</h3>
 * <p>
 * The window wears the main window's stylesheets, kept in step when the
 * theme changes, so the panel inside looks exactly as it does docked. It has
 * the operating system's frame, so it can be moved, resized, maximised and
 * snapped like any other window, and the Neural Code mark on its title bar
 * and task-bar entry. It closes with the IDE.
 * </p>
 */
final class VariableWindow {

    private static final String TITLE = "Workspace Window";

    private final UI_Main ide;
    private Stage stage;
    private SplitPane split;
    private Runnable onUserClose;

    VariableWindow(UI_Main ide) {
        this.ide = ide;
    }

    /** @param action run when the user closes the window */
    void setOnUserClose(Runnable action) {
        onUserClose = action;
    }

    /**
     * Puts the panel and the variable tabs in the window and shows it.
     *
     * @param panel the Variable Explorer panel
     * @param dock  the variable tabs
     */
    void show(Node panel, Node dock) {
        ensureStage();
        if (!split.getItems().contains(panel) || !split.getItems().contains(dock)) {
            split.getItems().setAll(panel, dock);
            SplitPane.setResizableWithParent(panel, Boolean.FALSE);
            double share = Dim.VariableExplorer.WINDOW_TABLE_SHARE;
            split.setDividerPositions(share);
            Platform.runLater(() -> split.setDividerPositions(share));
        }
        if (!stage.isShowing()) {
            stage.show();
        }
        if (stage.isIconified()) {
            stage.setIconified(false);
        }
        stage.toFront();
    }

    /** Gives the panel and the tabs back (they go home to the main window) and hides. */
    void release() {
        if (split != null) {
            split.getItems().clear();
        }
        hide();
    }

    /** Hides the window; its contents stay in it. */
    void hide() {
        if (stage != null && stage.isShowing()) {
            stage.hide();
        }
    }

    /** @return the window while it is on screen, for dialogs to belong to; otherwise null */
    Window owner() {
        return stage != null && stage.isShowing() ? stage : null;
    }

    /** @return true while the window is on screen */
    boolean isShowing() {
        return stage != null && stage.isShowing();
    }

    /** Minimises the window to the task bar. */
    void minimise() {
        if (stage != null) {
            stage.setIconified(true);
        }
    }

    /** Full Screen in this view: the window fills the screen, or stops. */
    void toggleFullScreen() {
        if (stage != null) {
            stage.setFullScreen(!stage.isFullScreen());
        }
    }

    /** @return true while the window fills the screen */
    boolean isFullScreen() {
        return stage != null && stage.isFullScreen();
    }

    private void ensureStage() {
        if (stage != null) {
            return;
        }
        split = new SplitPane();
        split.setOrientation(Orientation.HORIZONTAL);
        split.getStyleClass().add("variable-window-root");
        VariableStyles.attach(split);

        Scene scene = new Scene(split, Dim.VariableExplorer.WINDOW_WIDTH, Dim.VariableExplorer.WINDOW_HEIGHT);
        if (ide.scene != null) {
            scene.getStylesheets().setAll(ide.scene.getStylesheets());
            // Follow theme swaps in the main window.
            ide.scene.getStylesheets().addListener((ListChangeListener<String>) c ->
                    scene.getStylesheets().setAll(ide.scene.getStylesheets()));
        }

        stage = new Stage();
        stage.setTitle(TITLE);
        stage.setMinWidth(Dim.VariableExplorer.WINDOW_MIN_WIDTH);
        stage.setMinHeight(Dim.VariableExplorer.WINDOW_MIN_HEIGHT);
        stage.setFullScreenExitHint("");
        PrintStudioWindow.applyIcon(stage);
        stage.setScene(scene);
        stage.setOnCloseRequest(e -> {
            e.consume();
            stage.hide();
            if (onUserClose != null) {
                onUserClose.run();
            }
        });
        if (ide.stage != null) {
            ide.stage.addEventHandler(WindowEvent.WINDOW_HIDDEN, e -> stage.hide());
        }
    }
}
