package ui.explorer.variable;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

import javafx.application.Platform;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.skin.TableColumnHeader;
import javafx.scene.image.ImageView;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import ui.design.Dim;

/**
 * The content of one variable tab: a caption strip ({@code 5×5 float64}) over
 * a MATLAB-style grid, or a message when there is nothing to show.
 *
 * <pre>
 *   [#] 5×5 float64
 *   +----+------+------+------+-----
 *   |    |  1   |  2   |  3   |  4
 *   |  1 |    1 |    0 |    0 |
 *   |  2 |    0 |    1 |    0 |
 * </pre>
 *
 * <h3>Selecting and editing</h3>
 * <ul>
 * <li>One click selects a cell; Shift and Ctrl extend the selection, and a
 * drag selects a block.</li>
 * <li>A click on a row number selects that row, a click on a column number
 * selects that column.</li>
 * <li>A double-click, F2 or Enter edits the cell. A single click on a cell
 * that is already selected does <em>not</em> start editing, as in
 * MATLAB.</li>
 * <li>Enter or leaving the cell sends the edit to the interpreter
 * ({@link VariableAssignment}); Esc cancels. The grid then refreshes from the
 * interpreter, so what it shows is always what the workspace holds.</li>
 * <li>Ctrl+C copies the selected cells, tab-separated, at full precision.</li>
 * </ul>
 *
 * <h3>N-D matrices (new)</h3>
 * <p>
 * An N-D value shows one 2-D page -- its last two axes -- at a time. A strip
 * under the caption names the page as the Command Window does
 * ({@code B[1,:,:]}) and holds one 0-based selector per leading axis:
 * </p>
 *
 * <pre>
 *   [#] 2×3×4 float64
 *   B[1,:,:]                         axis 0 [ 1 ]
 *   +----+------+------+------+------+
 * </pre>
 * <p>
 * The page is kept when the value is fetched again (an edit, a Refresh, a
 * new run) as long as the leading axes have not changed; otherwise it goes
 * back to page 0. Grid row and column numbers stay 1-based, as everywhere in
 * this grid; the page keys are the interpreter's 0-based keys.
 * </p>
 *
 * <h3>Empty rows and columns</h3>
 * <p>
 * The grid always draws at least {@code MIN_ROWS} rows and, for a matrix,
 * {@code MIN_COLUMNS} columns, so a small value still sits on a sheet the
 * way MATLAB shows it. Cells outside the data are blank and cannot be
 * edited.
 * </p>
 */
final class VariableViewer extends VBox {

    private final String cleanedName;
    private final String visualName;
    private final Consumer<String> sender;

    private final HBox header = new HBox();
    private final ImageView headerIcon = new ImageView();
    private final Label title = new Label();
    private final Label note = new Label();
    private final StackPane body = new StackPane();

    /** The N-D page strip: the page's label and one selector per leading axis. */
    private final HBox pages = new HBox();
    private final Label pageTitle = new Label();
    private final List<Spinner<Integer>> pageKeys = new ArrayList<>();

    /** True while the selectors are being set from a grid, so they do not answer. */
    private boolean settingKeys;

    private VariableGrid grid;
    private TableView<Integer> table;
    private int shownRows;
    private int shownCols;

    /** How many clicks the last mouse press on the grid had. */
    private int lastClickCount;

    /** True while an edit was asked for from the keyboard. */
    private boolean keyEdit;

    /**
     * @param cleanedName the variable's name as the interpreter knows it
     * @param visualName  the name as the user reads it
     * @param sender      sends one edit command to the interpreter
     */
    VariableViewer(String cleanedName, String visualName, Consumer<String> sender) {
        this.cleanedName = cleanedName;
        this.visualName = visualName;
        this.sender = sender;
        getStyleClass().add("variable-viewer");

        double icon = Dim.VariableExplorer.HEADER_ICON_SIZE;
        headerIcon.setFitWidth(icon);
        headerIcon.setFitHeight(icon);
        headerIcon.setPreserveRatio(true);
        headerIcon.setSmooth(true);
        title.getStyleClass().add("variable-viewer-title");
        note.getStyleClass().add("variable-viewer-note");
        Region grow = new Region();
        HBox.setHgrow(grow, Priority.ALWAYS);
        header.getChildren().addAll(headerIcon, title, grow, note);
        header.getStyleClass().add("variable-viewer-header");
        header.setAlignment(Pos.CENTER_LEFT);
        double h = Dim.VariableExplorer.HEADER_HEIGHT;
        header.setMinHeight(h);
        header.setPrefHeight(h);
        header.setMaxHeight(h);

        pageTitle.getStyleClass().add("variable-viewer-page-title");
        pages.getStyleClass().addAll("variable-viewer-header", "variable-viewer-pages");
        pages.setAlignment(Pos.CENTER_LEFT);
        pages.setMinHeight(h);
        pages.setPrefHeight(h);
        pages.setMaxHeight(h);
        showPageStrip(false);

        getChildren().addAll(header, pages, body);
        VBox.setVgrow(body, Priority.ALWAYS);
        showLoading();
    }

    /** @return the cleaned name */
    String cleanedName() {
        return cleanedName;
    }

    /** @return the name as the user reads it */
    String visualName() {
        return visualName;
    }

    /** @return the value on screen, or null while there is none */
    VariableGrid grid() {
        return grid;
    }

    // =====================================================================
    // States
    // =====================================================================

    /** "Loading" -- before the first value arrives. */
    void showLoading() {
        if (grid == null) {
            showMessage("Loading " + visualName + "…");
        }
    }

    /** The variable is not in the workspace (any more). */
    void showMissing() {
        grid = null;
        table = null;
        showPageStrip(false);
        headerIcon.setImage(null);
        title.setText(visualName);
        note.setText("");
        showMessage("The variable '" + visualName + "' does not exist.");
    }

    /**
     * Something went wrong fetching the value. The last value, if any, stays
     * on screen and the reason is shown beside the caption.
     *
     * @param message the reason
     */
    void showProblem(String message) {
        if (grid == null) {
            showMessage(message);
        } else {
            setNote(message, true);
        }
    }

    /**
     * Shows a value. When the shape has not changed the grid is reused, so
     * the scroll position and the selection stay where they were. An N-D
     * value stays on the page on screen while its leading axes are the same.
     *
     * @param next the value
     */
    void showGrid(VariableGrid next) {
        VariableGrid shown = next;
        if (grid != null && grid.isNdArray() && next.isNdArray()
                && leadingAxes(grid).equals(leadingAxes(next))) {
            shown = next.page(grid.page());
        }
        showPage(shown);
    }

    /** The axes that pick a page: every axis but the last two. */
    private static List<Integer> leadingAxes(VariableGrid g) {
        List<Integer> shape = g.ndShape();
        return shape.subList(0, Math.max(0, shape.size() - 2));
    }

    /** Puts a grid on screen as it is (its own page). */
    private void showPage(VariableGrid next) {
        boolean reuse = table != null && grid != null
                && grid.shape() == next.shape()
                && grid.rows() == next.rows()
                && grid.columns() == next.columns()
                && grid.titles().equals(next.titles());
        grid = next;
        refreshHeader();
        refreshPages();
        if (reuse) {
            table.refresh();
            return;
        }
        buildTable();
        body.getChildren().setAll(table);
    }

    // =====================================================================
    // N-D pages
    // =====================================================================

    private void showPageStrip(boolean show) {
        pages.setVisible(show);
        pages.setManaged(show);
    }

    /**
     * Shows the page strip for an N-D value and sets its selectors to the
     * page on screen; hides it for any other value. The selectors are built
     * again only when the leading axes change.
     */
    private void refreshPages() {
        if (grid == null || !grid.isNdArray() || grid.page().length == 0) {
            showPageStrip(false);
            return;
        }
        List<Integer> axes = leadingAxes(grid);
        if (!sameSelectors(axes)) {
            buildSelectors(axes);
        }
        int[] page = grid.page();
        settingKeys = true;
        try {
            for (int axis = 0; axis < pageKeys.size(); axis++) {
                pageKeys.get(axis).getValueFactory().setValue(page[axis]);
            }
        } finally {
            settingKeys = false;
        }
        pageTitle.setText(visualName + grid.pageLabel());
        showPageStrip(true);
    }

    private boolean sameSelectors(List<Integer> axes) {
        if (pageKeys.size() != axes.size()) {
            return false;
        }
        for (int axis = 0; axis < axes.size(); axis++) {
            SpinnerValueFactory.IntegerSpinnerValueFactory f =
                    (SpinnerValueFactory.IntegerSpinnerValueFactory) pageKeys.get(axis).getValueFactory();
            if (f.getMax() != Math.max(0, axes.get(axis) - 1)) {
                return false;
            }
        }
        return true;
    }

    private void buildSelectors(List<Integer> axes) {
        pageKeys.clear();
        Region grow = new Region();
        HBox.setHgrow(grow, Priority.ALWAYS);
        pages.getChildren().setAll(pageTitle, grow);
        for (int axis = 0; axis < axes.size(); axis++) {
            int size = axes.get(axis);
            Spinner<Integer> key = new Spinner<>(0, Math.max(0, size - 1), 0);
            key.setEditable(true);
            key.setDisable(size <= 1);
            key.getStyleClass().add("variable-viewer-page-key");
            key.setPrefWidth(Dim.VariableExplorer.COLUMN_WIDTH);
            key.valueProperty().addListener((obs, was, is) -> onPageKey());
            Label caption = new Label("axis " + axis);
            caption.getStyleClass().add("variable-viewer-page-caption");
            pages.getChildren().addAll(caption, key);
            pageKeys.add(key);
        }
    }

    /** A selector moved: show that page of the value already fetched. */
    private void onPageKey() {
        if (settingKeys || grid == null) {
            return;
        }
        int[] keys = new int[pageKeys.size()];
        for (int axis = 0; axis < keys.length; axis++) {
            Integer value = pageKeys.get(axis).getValue();
            keys[axis] = value == null ? 0 : value;
        }
        showPage(grid.page(keys));
    }

    /** Repaints the caption icon after a theme change. */
    void refreshIcons() {
        if (grid != null) {
            headerIcon.setImage(VariableIcons.image(
                    VariableIcons.forClass(grid.cls(), grid.size(), grid.isInherited())));
        }
    }

    private void refreshHeader() {
        refreshIcons();
        title.setText(grid.summary());
        String n = grid.note();
        if (n == null && grid.columns() > shownColsFor(grid)) {
            n = "Showing the first " + shownColsFor(grid) + " of " + grid.columns() + " columns.";
        }
        setNote(n, false);
    }

    private void setNote(String text, boolean problem) {
        note.setText(text == null ? "" : text);
        note.getStyleClass().remove("problem");
        if (problem) {
            note.getStyleClass().add("problem");
        }
    }

    private void showMessage(String text) {
        Label message = new Label(text);
        message.getStyleClass().add("variable-viewer-message");
        message.setWrapText(true);
        StackPane.setAlignment(message, Pos.TOP_LEFT);
        body.getChildren().setAll(message);
    }

    // =====================================================================
    // The grid
    // =====================================================================

    private static int shownColsFor(VariableGrid g) {
        int cols = g.columns();
        if (g.shape() == VariableGrid.Shape.MATRIX) {
            cols = Math.max(cols, Dim.VariableExplorer.MIN_COLUMNS);
        }
        return Math.min(cols, Dim.VariableExplorer.MAX_COLUMNS);
    }

    private void buildTable() {
        shownRows = Math.max(grid.rows(), Dim.VariableExplorer.MIN_ROWS);
        shownCols = shownColsFor(grid);

        TableView<Integer> t = new TableView<>();
        t.getStyleClass().add("variable-grid");
        t.setEditable(true);
        t.setFixedCellSize(Dim.VariableExplorer.CELL_HEIGHT);
        t.setColumnResizePolicy(TableView.UNCONSTRAINED_RESIZE_POLICY);
        t.getSelectionModel().setCellSelectionEnabled(true);
        t.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        t.setPlaceholder(new Label(""));

        t.getColumns().add(rowHeaderColumn());
        for (int c = 0; c < shownCols; c++) {
            t.getColumns().add(valueColumn(c));
        }
        t.setItems(rowIndices(shownRows));

        // Single click selects; a double-click (or F2 / Enter) edits.
        t.addEventFilter(MouseEvent.MOUSE_PRESSED, e -> lastClickCount = e.getClickCount());
        t.addEventHandler(MouseEvent.MOUSE_CLICKED, this::onClick);
        t.addEventFilter(KeyEvent.KEY_PRESSED, this::onKey);
        table = t;
    }

    /** A list that is 0, 1, 2, ... n-1 without storing n boxed integers. */
    private static ObservableList<Integer> rowIndices(int n) {
        return FXCollections.observableList(new AbstractList<>() {
            @Override
            public Integer get(int index) {
                return index;
            }

            @Override
            public int size() {
                return n;
            }
        });
    }

    /**
     * A blank sheet for when no variable is open: the caption strip and an
     * empty grid with numbered rows and columns, as MATLAB's Variables
     * editor shows before anything is opened. Nothing in it can be edited.
     *
     * @param caption the text on the caption strip
     * @return the sheet
     */
    static VBox emptySheet(String caption) {
        Label title = new Label(caption);
        title.getStyleClass().add("variable-viewer-title");
        HBox header = new HBox(title);
        header.getStyleClass().add("variable-viewer-header");
        header.setAlignment(Pos.CENTER_LEFT);
        double h = Dim.VariableExplorer.HEADER_HEIGHT;
        header.setMinHeight(h);
        header.setPrefHeight(h);
        header.setMaxHeight(h);

        TableView<Integer> t = new TableView<>();
        t.getStyleClass().addAll("variable-grid", "ve-empty-sheet");
        t.setEditable(false);
        t.setFixedCellSize(Dim.VariableExplorer.CELL_HEIGHT);
        t.setColumnResizePolicy(TableView.UNCONSTRAINED_RESIZE_POLICY);
        t.getSelectionModel().setCellSelectionEnabled(true);
        t.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        t.setPlaceholder(new Label(""));
        t.getColumns().add(rowHeaderColumn());
        for (int c = 0; c < Dim.VariableExplorer.MIN_COLUMNS; c++) {
            TableColumn<Integer, String> col = new TableColumn<>(String.valueOf(c + 1));
            col.setCellValueFactory(f -> new ReadOnlyStringWrapper(""));
            col.getStyleClass().add("ve-number-cell");
            col.setPrefWidth(Dim.VariableExplorer.COLUMN_WIDTH);
            col.setSortable(false);
            col.setReorderable(false);
            t.getColumns().add(col);
        }
        t.setItems(rowIndices(Dim.VariableExplorer.MIN_ROWS));

        VBox sheet = new VBox(header, t);
        sheet.getStyleClass().addAll("variable-viewer", "ve-empty-viewer");
        VBox.setVgrow(t, Priority.ALWAYS);
        return sheet;
    }

    private static TableColumn<Integer, Integer> rowHeaderColumn() {
        TableColumn<Integer, Integer> col = new TableColumn<>("");
        col.setCellValueFactory(f -> new ReadOnlyObjectWrapper<>(f.getValue()));
        col.setCellFactory(c -> new TableCell<>() {
            @Override
            protected void updateItem(Integer item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : String.valueOf(item + 1));
            }
        });
        col.getStyleClass().add("ve-row-header-column");
        double w = Dim.VariableExplorer.ROW_HEADER_WIDTH;
        col.setMinWidth(w);
        col.setPrefWidth(w);
        col.setEditable(false);
        col.setSortable(false);
        col.setReorderable(false);
        col.setResizable(false);
        return col;
    }

    private TableColumn<Integer, String> valueColumn(int c) {
        String caption;
        double width;
        boolean text;
        switch (grid.shape()) {
            case TABLE -> {
                caption = c < grid.titles().size() ? grid.titles().get(c) : String.valueOf(c + 1);
                // Every column but the last (the value) is a short one:
                // Key / Field, and an object's Type.
                boolean last = c == grid.titles().size() - 1;
                width = last ? Dim.VariableExplorer.TEXT_COLUMN_WIDTH : Dim.VariableExplorer.KEY_COLUMN_WIDTH;
                text = true;
            }
            case TEXT -> {
                caption = "1";
                width = Dim.VariableExplorer.TEXT_COLUMN_WIDTH * 2;
                text = true;
            }
            default -> {
                caption = String.valueOf(c + 1);
                width = Dim.VariableExplorer.COLUMN_WIDTH;
                text = false;
            }
        }
        TableColumn<Integer, String> col = new TableColumn<>(caption);
        col.setCellValueFactory(f -> new ReadOnlyStringWrapper(grid == null ? "" : grid.display(f.getValue(), c)));
        col.setCellFactory(x -> new GridCell(c, text));
        col.setPrefWidth(width);
        col.setSortable(false);
        col.setReorderable(false);
        col.setOnEditCommit(e -> commit(e.getTablePosition().getRow(), c, e.getNewValue()));
        return col;
    }

    // =====================================================================
    // Edits
    // =====================================================================

    private void commit(int row, int col, String typed) {
        if (grid == null) {
            return;
        }
        try {
            String command = grid.command(row, col, typed);
            setNote(null, false);
            sender.accept(command);
        } catch (IllegalArgumentException ex) {
            setNote(ex.getMessage(), true);
            if (table != null) {
                table.refresh();
            }
        }
    }

    /** A value cell: right-aligned numbers, left-aligned text, square editor. */
    private final class GridCell extends TableCell<Integer, String> {

        private final int column;
        private TextField field;

        GridCell(int column, boolean text) {
            this.column = column;
            getStyleClass().add(text ? "ve-text-cell" : "ve-number-cell");
        }

        @Override
        protected void updateItem(String item, boolean empty) {
            super.updateItem(item, empty);
            if (isEditing()) {
                return;
            }
            setText(empty ? null : item);
            setGraphic(null);
        }

        @Override
        public void startEdit() {
            int row = getIndex();
            boolean asked = lastClickCount >= 2 || keyEdit;
            keyEdit = false;
            if (!asked || grid == null || !grid.isEditable(row, column)) {
                // The table has already marked this cell as the one being
                // edited; refusing without telling it would leave it stuck
                // in that state.
                TableView<Integer> tv = getTableView();
                TableColumn<Integer, String> me = getTableColumn();
                if (tv != null) {
                    Platform.runLater(() -> {
                        TablePosition<Integer, ?> editing = tv.getEditingCell();
                        if (editing != null && editing.getRow() == row && editing.getTableColumn() == me) {
                            tv.edit(-1, null);
                        }
                    });
                }
                return;
            }
            super.startEdit();
            if (!isEditing()) {
                return;
            }
            field = new TextField(grid.editText(row, column));
            field.getStyleClass().add("ve-edit-field");
            field.setOnAction(e -> commitEdit(field.getText()));
            field.addEventFilter(KeyEvent.KEY_PRESSED, e -> {
                if (e.getCode() == KeyCode.ESCAPE) {
                    cancelEdit();
                    e.consume();
                }
            });
            // Leaving the cell keeps what was typed, as in MATLAB.
            field.focusedProperty().addListener((obs, had, has) -> {
                if (!has && isEditing() && field != null) {
                    commitEdit(field.getText());
                }
            });
            setText(null);
            setGraphic(field);
            field.selectAll();
            Platform.runLater(field::requestFocus);
        }

        @Override
        public void cancelEdit() {
            super.cancelEdit();
            field = null;
            setGraphic(null);
            setText(getItem());
        }

        @Override
        public void commitEdit(String newValue) {
            field = null;
            super.commitEdit(newValue);
            setGraphic(null);
        }
    }

    // =====================================================================
    // Mouse and keyboard
    // =====================================================================

    private void onClick(MouseEvent e) {
        if (e.getButton() != MouseButton.PRIMARY || !e.isStillSincePress() || table == null) {
            return;
        }
        // A column number: select the column.
        TableColumnHeader columnHeader = ancestor(e.getTarget(), TableColumnHeader.class);
        if (columnHeader != null) {
            TableColumn<Integer, ?> col = column(columnHeader);
            int index = col == null ? -1 : table.getColumns().indexOf(col);
            if (index > 0) {
                selectColumn(col, e.isControlDown() || e.isShortcutDown());
            }
            return;
        }
        // A row number: select the row.
        TableCell<?, ?> cell = ancestor(e.getTarget(), TableCell.class);
        if (cell != null && cell.getTableColumn() == table.getColumns().get(0) && !cell.isEmpty()) {
            selectRow(cell.getIndex(), e.isControlDown() || e.isShortcutDown());
        }
    }

    @SuppressWarnings("unchecked")
    private TableColumn<Integer, ?> column(TableColumnHeader header) {
        return header.getTableColumn() instanceof TableColumn<?, ?> c ? (TableColumn<Integer, ?>) c : null;
    }

    private void selectColumn(TableColumn<Integer, ?> col, boolean add) {
        if (!add) {
            table.getSelectionModel().clearSelection();
        }
        int last = Math.max(0, Math.max(grid == null ? 0 : grid.rows(), 1) - 1);
        table.getSelectionModel().selectRange(0, col, last, col);
    }

    private void selectRow(int row, boolean add) {
        if (!add) {
            table.getSelectionModel().clearSelection();
        }
        int lastCol = Math.max(1, Math.min(shownCols, Math.max(grid == null ? 1 : grid.columns(), 1)));
        table.getSelectionModel().selectRange(row, table.getColumns().get(1), row, table.getColumns().get(lastCol));
    }

    private void onKey(KeyEvent e) {
        if (table == null || table.getEditingCell() != null) {
            return;
        }
        if (e.isShortcutDown() && e.getCode() == KeyCode.C) {
            copySelection();
            e.consume();
            return;
        }
        if (e.getCode() == KeyCode.F2 || e.getCode() == KeyCode.ENTER) {
            // JavaFX hands the focused cell back as a raw TablePosition; the
            // column is looked up on the table instead, which is typed.
            TablePosition<?, ?> focus = table.getFocusModel().getFocusedCell();
            if (focus != null && focus.getColumn() > 0) {
                TableColumn<Integer, ?> column = table.getVisibleLeafColumn(focus.getColumn());
                if (column != null) {
                    keyEdit = true;
                    table.edit(focus.getRow(), column);
                    e.consume();
                }
            }
        }
    }

    /** Copies the selected cells as tab-separated text, full precision. */
    private void copySelection() {
        if (grid == null) {
            return;
        }
        // getSelectedCells() is a list of raw TablePositions; 'var' keeps
        // the raw type out of this code, and each cell is read as
        // TablePosition<?, ?> below.
        var cells = table.getSelectionModel().getSelectedCells();
        if (cells.isEmpty()) {
            return;
        }
        int minR = Integer.MAX_VALUE;
        int maxR = -1;
        int minC = Integer.MAX_VALUE;
        int maxC = -1;
        for (TablePosition<?, ?> p : cells) {
            if (p.getColumn() <= 0) {
                continue;
            }
            minR = Math.min(minR, p.getRow());
            maxR = Math.max(maxR, p.getRow());
            minC = Math.min(minC, p.getColumn() - 1);
            maxC = Math.max(maxC, p.getColumn() - 1);
        }
        if (maxR < 0) {
            return;
        }
        boolean[][] chosen = new boolean[maxR - minR + 1][maxC - minC + 1];
        for (TablePosition<?, ?> p : cells) {
            if (p.getColumn() > 0) {
                chosen[p.getRow() - minR][p.getColumn() - 1 - minC] = true;
            }
        }
        StringBuilder out = new StringBuilder();
        for (int r = minR; r <= maxR; r++) {
            for (int c = minC; c <= maxC; c++) {
                if (c > minC) {
                    out.append('\t');
                }
                if (chosen[r - minR][c - minC]) {
                    out.append(grid.editText(r, c));
                }
            }
            out.append('\n');
        }
        ClipboardContent content = new ClipboardContent();
        content.putString(out.toString());
        Clipboard.getSystemClipboard().setContent(content);
    }

    private static <T> T ancestor(Object target, Class<T> type) {
        Node n = target instanceof Node node ? node : null;
        while (n != null) {
            if (type.isInstance(n)) {
                return type.cast(n);
            }
            n = n.getParent();
        }
        return null;
    }
}
