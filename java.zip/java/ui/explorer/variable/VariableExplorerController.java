package ui.explorer.variable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.CompletionException;
import java.util.concurrent.TimeoutException;

import backend.workspace.WorkspaceProtocol;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.collections.ListChangeListener;
import javafx.scene.Node;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.Tab;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Region;
import javafx.stage.Window;
import ui.UI_Main;
import ui.cli.CLI_Main;
import ui.explorer.CollapsiblePanel;
import ui.explorer.PanelActivation;
import ui.layout.LayoutManager;
import ui.managers.ThemeManager;
import ui.ui_functions.Variable;
import ui.ui_functions.WorkspaceStore;
import ui.ui_functions.tools.PrintStudioWindow;
import ui.ui_functions.tools.print.PrintModel;

/**
 * Runs the Variable Explorer beyond its table: opening variables in tabs,
 * keeping those tabs live, the three-dot menu's actions, the three views of
 * Visual Options, Full Screen and Close.
 *
 * <h3>Opening a variable</h3>
 * <p>
 * A click anywhere in a row opens that variable ({@link #open}); a click
 * with Shift or Ctrl only selects, so rows can be multi-selected. Where it
 * opens depends on the view ({@link VariableViewMode}): in the editor's tab
 * strip from the right (Default), in the right half of the editor area
 * (Split Window, which only opens once a variable is open), or in the
 * Workspace Window (Separate Window). The
 * value is asked of the interpreter with
 * {@code CLI_Main.workspaceChannel().requestVariable} and laid out by
 * {@link VariableGrid}.
 * </p>
 *
 * <h3>Live tabs</h3>
 * <p>
 * Whenever the interpreter reports a new workspace, every open tab is
 * checked against its row's fingerprint. A changed value is fetched again;
 * a variable that has gone (clear, clear name, Reset Explorer) stays as a
 * tab reading "The variable 's' does not exist." A fetch refused because a
 * command is running is retried as soon as the interpreter is back at its
 * prompt.
 * </p>
 *
 * <h3>Coming back by itself</h3>
 * <ul>
 * <li>After <b>Close</b>, the Variable Explorer returns when the next
 * command or script starts, or when a layout is chosen on Settings &gt;
 * Layout.</li>
 * <li>In <b>Separate Window</b> view the window is not shown at launch; it
 * appears when the first command or script starts, and again after the user
 * closes it.</li>
 * </ul>
 *
 * <h3>Workspace Window opens the first variable</h3>
 * <p>
 * So the window's right side is never blank, the first variable in the table
 * is opened when the window appears with no tab open, or as soon as the
 * workspace has a variable. If the user then closes every tab, the window
 * keeps the empty sheet until it is next shown.
 * </p>
 *
 * <h3>Loaded data</h3>
 * <p>
 * Variables that arrive through Load Workspace show the loaded-data icon
 * until they are assigned again (their fingerprint changes).
 * </p>
 */
public final class VariableExplorerController {

    private static final String KEY_MODE = "variables.viewMode";

    private static UI_Main ide;
    private static CollapsiblePanel panel;
    private static VariableDock dock;
    private static VariableEditorArea area;
    private static VariableWindow window;
    private static VariableViewMode mode = VariableViewMode.DEFAULT;

    /** The fingerprint each open tab's value was last fetched at. */
    private static final Map<String, String> FETCHED = new HashMap<>();

    /** Tabs whose fetch was refused because a command was running. */
    private static final Set<String> WAITING = new HashSet<>();

    /** Loaded-data marks: name to the fingerprint it was loaded with. */
    private static final Map<String, String> LOADED = new HashMap<>();

    /** The workspace just before a Load Workspace, while one is pending. */
    private static Map<String, String> beforeLoad;

    private static boolean refreshQueued;
    private static boolean escapeInstalled;

    /**
     * True once the user has closed every tab in the Workspace Window: the
     * first variable is then not opened again until the window next appears.
     */
    private static boolean autoOpenDeclined;

    private VariableExplorerController() {
    }

    // =====================================================================
    // Installation
    // =====================================================================

    /**
     * Builds the variable tabs and the editor area that holds them, and
     * restores the saved view. Call from {@code Main_Window} after the
     * editor tabs and the Variable Explorer panel exist, and before
     * {@code LayoutManager.install}, which places the returned node as the
     * editor.
     *
     * @param ideRef        the IDE controller
     * @param variablePanel the Variable Explorer panel
     * @return the editor area
     */
    public static Region install(UI_Main ideRef, CollapsiblePanel variablePanel) {
        ide = ideRef;
        panel = variablePanel;
        mode = VariableViewMode.fromName(
                ide.prefs == null ? null : ide.prefs.get(KEY_MODE, VariableViewMode.DEFAULT.name()));

        dock = new VariableDock();
        dock.setOnClosed(name -> {
            FETCHED.remove(name);
            WAITING.remove(name);
        });
        dock.emptyProperty().addListener((obs, was, now) -> {
            if (now && mode == VariableViewMode.SEPARATE && window.isShowing()) {
                autoOpenDeclined = true;
            }
        });
        area = new VariableEditorArea(ide.editorTabs, dock);
        window = new VariableWindow(ide);

        // On the area for the script-strip rules, on the dock and the panel
        // because both can move to the separate window.
        VariableStyles.attach(area);
        VariableStyles.attach(dock);
        VariableStyles.attach(panel);

        dock.setOnStripWidth(area::reserve);
        dock.activeProperty().addListener((obs, was, now) -> markScriptTabs(now));
        dock.addEventFilter(MouseEvent.MOUSE_PRESSED, e -> PanelActivation.setActive(
                mode == VariableViewMode.SEPARATE || LayoutManager.isVariablesFullScreen()
                        ? PanelActivation.Panel.VARIABLE_EXPLORER
                        : PanelActivation.Panel.EDITOR));

        wireEditorTabs();
        wireWorkspace();
        wireBusy();
        wireTheme();

        if (mode == VariableViewMode.SEPARATE) {
            // The IDE starts without a Variable Explorer; the window comes
            // with the first run.
            LayoutManager.setVariablesDetached(true);
            mount(mode, false);
        } else {
            mount(mode, true);
        }
        return area;
    }

    /**
     * Wires the explorer table: multi-select, open on click, right-click
     * menu, Enter to open. Called by {@code VariableExplorerBuilder}.
     *
     * @param table the explorer table
     */
    public static void installTable(TableView<Variable> table) {
        table.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        table.setRowFactory(t -> {
            TableRow<Variable> row = new TableRow<>();
            row.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
                if (e.getButton() == MouseButton.PRIMARY && e.getClickCount() == 1
                        && e.isStillSincePress() && !row.isEmpty()
                        && !e.isShiftDown() && !e.isControlDown() && !e.isShortcutDown()) {
                    open(row.getItem());
                }
            });
            return row;
        });
        table.setOnContextMenuRequested(e -> {
            ContextMenu menu = VariableExplorerMenu.rows(
                    new ArrayList<>(table.getSelectionModel().getSelectedItems()));
            menu.show(table, e.getScreenX(), e.getScreenY());
            e.consume();
        });
        table.addEventHandler(KeyEvent.KEY_PRESSED, e -> {
            if (e.getCode() == KeyCode.ENTER) {
                new ArrayList<>(table.getSelectionModel().getSelectedItems())
                        .forEach(VariableExplorerController::open);
                e.consume();
            }
        });
    }

    private static void wireEditorTabs() {
        if (ide.editorTabs == null) {
            return;
        }
        // Any move on the script side hands the editor area back to it.
        ide.editorTabs.getSelectionModel().selectedItemProperty()
                .addListener((obs, was, now) -> dock.setActive(false));
        ide.editorTabs.getTabs().addListener((ListChangeListener<Tab>) c -> {
            while (c.next()) {
                if (c.wasAdded()) {
                    dock.setActive(false);
                    return;
                }
            }
        });
        ide.editorTabs.addEventFilter(MouseEvent.MOUSE_PRESSED, e -> {
            if (dock.isOverlay() && dock.isActive() && isInsideTab(e.getTarget())) {
                dock.setActive(false);
            }
        });
    }

    private static void wireWorkspace() {
        WorkspaceStore.get().rows().addListener((ListChangeListener<Variable>) c -> {
            if (!refreshQueued) {
                refreshQueued = true;
                Platform.runLater(() -> {
                    refreshQueued = false;
                    onWorkspaceChanged();
                });
            }
        });
    }

    private static void wireBusy() {
        CLI_Main.busyProperty().addListener((obs, was, busy) -> {
            if (Boolean.TRUE.equals(busy) && !Boolean.TRUE.equals(was)) {
                onRunStarted();
            } else if (!Boolean.TRUE.equals(busy)) {
                retryWaiting();
            }
        });
    }

    private static void wireTheme() {
        ChangeListener<Object> follow = (obs, was, now) -> Platform.runLater(() -> {
            VariableStyles.themeChanged();
            dock.refreshIcons();
            if (ide.varTable != null) {
                ide.varTable.refresh();
            }
        });
        ThemeManager.themeProperty().addListener(follow);
    }

    // =====================================================================
    // Opening and refreshing
    // =====================================================================

    /**
     * Opens a variable where the current view puts variables, or selects it
     * if it is open already.
     *
     * @param v the explorer row
     */
    public static void open(Variable v) {
        if (v == null || dock == null) {
            return;
        }
        if (mode == VariableViewMode.SEPARATE) {
            showWindow(true);
        }
        openTab(v);
    }

    /** Opens a variable in the dock, wherever the dock is now. */
    private static void openTab(Variable v) {
        String name = v.getName();
        VariableViewer viewer = dock.open(name, v.getDisplayName(), VariableExplorerController::sendEdit);
        dock.setIcon(name, VariableIcons.forVariable(v));
        if (viewer.grid() == null || !Objects.equals(FETCHED.get(name), v.getFingerprint())) {
            fetch(viewer, v);
        }
    }

    private static void fetch(VariableViewer viewer, Variable row) {
        String name = viewer.cleanedName();
        FETCHED.put(name, row == null ? "" : row.getFingerprint());
        WAITING.remove(name);
        CLI_Main.workspaceChannel().requestVariable(name).whenComplete((value, error) -> Platform.runLater(() -> {
            if (dock.viewer(name) != viewer) {
                return; // closed (or reopened) meanwhile
            }
            if (error != null) {
                FETCHED.remove(name);
                Throwable inner = error.getCause();
                Throwable cause = error instanceof CompletionException && inner != null ? inner : error;
                if (cause instanceof TimeoutException) {
                    viewer.showProblem("The interpreter did not answer; use Refresh to try again.");
                } else {
                    // Busy, restarting or not running: try again at the prompt.
                    WAITING.add(name);
                    viewer.showProblem("Waiting for the running command to finish…");
                }
                return;
            }
            if (!value.found()) {
                viewer.showMissing();
                return;
            }
            VariableGrid grid = VariableGrid.of(value);
            viewer.showGrid(grid);
            Variable current = find(name);
            dock.setIcon(name, current != null && isLoadedData(current)
                    ? VariableIcons.Kind.LOADED_DATA
                    : VariableIcons.forClass(grid.cls(), grid.size(), grid.isInherited()));
        }));
    }

    private static void onWorkspaceChanged() {
        if (beforeLoad != null) {
            for (Variable v : WorkspaceStore.get().rows()) {
                String before = beforeLoad.get(v.getName());
                if (!v.getFingerprint().isEmpty() && !v.getFingerprint().equals(before)) {
                    LOADED.put(v.getName(), v.getFingerprint());
                }
            }
            beforeLoad = null;
            if (ide.varTable != null) {
                ide.varTable.refresh();
            }
        }
        openFirstIfEmpty();
        for (VariableViewer viewer : dock.viewers()) {
            String name = viewer.cleanedName();
            Variable row = find(name);
            if (row == null) {
                FETCHED.remove(name);
                WAITING.remove(name);
                viewer.showMissing();
                continue;
            }
            dock.setIcon(name, VariableIcons.forVariable(row));
            String fp = row.getFingerprint();
            if (fp.isEmpty() || !fp.equals(FETCHED.get(name))) {
                fetch(viewer, row);
            }
        }
    }

    private static void retryWaiting() {
        if (WAITING.isEmpty()) {
            return;
        }
        for (String name : new ArrayList<>(WAITING)) {
            VariableViewer viewer = dock.viewer(name);
            if (viewer != null) {
                fetch(viewer, find(name));
            }
        }
    }

    /** A command or a script has started. */
    private static void onRunStarted() {
        if (mode == VariableViewMode.SEPARATE && !window.isShowing()) {
            showWindow(false);
            openFirstIfEmpty();
        }
        if (LayoutManager.isVariablesClosed()) {
            LayoutManager.setVariablesClosed(false);
        }
    }

    /**
     * In the Workspace Window, opens the first variable of the table when no
     * tab is open, so the right side is not blank. With an empty workspace
     * the dock keeps its empty sheet.
     */
    private static void openFirstIfEmpty() {
        if (mode != VariableViewMode.SEPARATE || !window.isShowing()
                || !dock.isEmpty() || autoOpenDeclined) {
            return;
        }
        Variable first = null;
        boolean fromTable = false;
        if (ide.varTable != null && !ide.varTable.getItems().isEmpty()) {
            first = ide.varTable.getItems().get(0); // the order the user sees
            fromTable = true;
        } else if (!WorkspaceStore.get().rows().isEmpty()) {
            first = WorkspaceStore.get().rows().get(0);
        }
        if (first == null) {
            return;
        }
        openTab(first);
        if (fromTable && ide.varTable.getSelectionModel().isEmpty()) {
            ide.varTable.getSelectionModel().clearAndSelect(0);
        }
    }

    private static Variable find(String cleanedName) {
        for (Variable v : WorkspaceStore.get().rows()) {
            if (v.getName().equals(cleanedName)) {
                return v;
            }
        }
        return null;
    }

    /** Sends one grid edit to the interpreter. */
    private static void sendEdit(String command) {
        CLI_Main.sendFromIde(ide, command);
    }

    /**
     * @param v an explorer row
     * @return true when the row came from Load Workspace and has not changed
     *         since
     */
    static boolean isLoadedData(Variable v) {
        String hash = LOADED.get(v.getName());
        return hash != null && !hash.isEmpty() && hash.equals(v.getFingerprint());
    }

    // =====================================================================
    // Views
    // =====================================================================

    /** @return the Visual Options choice */
    static VariableViewMode mode() {
        return mode;
    }

    /**
     * Switches the view. Saved, and restored at the next launch.
     *
     * @param next the view
     */
    static void setMode(VariableViewMode next) {
        if (next == null || next == mode) {
            return;
        }
        if (LayoutManager.isVariablesFullScreen()) {
            LayoutManager.setVariablesFullScreen(false, null, null);
        }
        VariableViewMode previous = mode;
        mode = next;
        if (ide.prefs != null) {
            ide.prefs.put(KEY_MODE, next.name());
        }

        if (previous == VariableViewMode.SEPARATE) {
            // Bring the panel and the tabs home before the layout wants them.
            window.release();
            mount(next, true);
            LayoutManager.setVariablesDetached(false);
            return;
        }
        if (next == VariableViewMode.SEPARATE) {
            mount(next, false);
            LayoutManager.setVariablesDetached(true);
            showWindow(true);
            openFirstIfEmpty();
            return;
        }
        mount(next, true);
    }

    /** Arranges the editor area, and keeps the script strip's look in step. */
    private static void mount(VariableViewMode view, boolean dockHere) {
        area.mount(view, dockHere);
        markScriptTabs(dock.isActive());
    }

    /**
     * Puts the panel and the variable tabs in the separate window and shows
     * it.
     *
     * @param takeFocus false when the window appears by itself (a run
     *                  started): the keyboard stays where the user is typing
     */
    private static void showWindow(boolean takeFocus) {
        if (!window.isShowing()) {
            autoOpenDeclined = false;
        }
        panel.setCollapsed(false);
        panel.setCollapseEnabled(false);
        area.releaseDock();
        dock.setOverlay(false);
        markScriptTabs(false);
        window.show(panel, dock);
        if (takeFocus) {
            PanelActivation.setActive(PanelActivation.Panel.VARIABLE_EXPLORER);
        } else if (ide.stage != null) {
            Platform.runLater(ide.stage::requestFocus);
        }
    }

    /** In the overlay, the selected script tab stops looking selected. */
    private static void markScriptTabs(boolean variablesActive) {
        if (ide.editorTabs == null) {
            return;
        }
        ide.editorTabs.getStyleClass().remove("variable-view-active");
        if (variablesActive && dock.isOverlay()) {
            ide.editorTabs.getStyleClass().add("variable-view-active");
        }
    }

    // =====================================================================
    // Menu actions
    // =====================================================================

    /** Reset Explorer: clears the workspace, after asking. */
    static void resetExplorer() {
        boolean clear = VariableConfirmDialog.ask(owner(),
                ide.scene == null ? null : ide.scene.getStylesheets(),
                "Reset Explorer",
                "Clear the whole workspace?",
                "Every variable is removed from the workspace, as if \"clear\" were typed in the "
                        + "Command Window. This cannot be undone.",
                "Clear Workspace");
        if (!clear) {
            return;
        }
        LOADED.clear();
        WorkspaceStore.get().clearAll();
        CLI_Main.sendFromIde(ide, "clear");
    }

    /** @return true while the panel is a rail */
    static boolean isMinimised() {
        return panel != null && panel.isCollapsed();
    }

    /** @return true when Minimise can do something in the current view */
    static boolean canMinimise() {
        if (mode == VariableViewMode.SEPARATE) {
            return window.isShowing();
        }
        return panel.isCollapseEnabled() && panel.getScene() != null
                && !LayoutManager.isVariablesFullScreen();
    }

    /** Minimise / Restore. */
    static void toggleMinimised() {
        if (mode == VariableViewMode.SEPARATE) {
            window.minimise();
        } else if (canMinimise() || panel.isCollapsed()) {
            panel.setCollapsed(!panel.isCollapsed());
        }
    }

    /** Refresh: a fresh workspace, and every open tab fetched again. */
    static void refresh() {
        FETCHED.clear();
        CLI_Main.reloadWorkspace();
        for (VariableViewer viewer : dock.viewers()) {
            fetch(viewer, find(viewer.cleanedName()));
        }
    }

    static void saveWorkspace() {
        VariableWorkspaceIO.save(ide, owner());
    }

    static void loadWorkspace() {
        VariableWorkspaceIO.load(ide, owner(), () -> {
            Map<String, String> snapshot = new HashMap<>();
            for (Variable v : WorkspaceStore.get().rows()) {
                snapshot.put(v.getName(), v.getFingerprint());
            }
            beforeLoad = snapshot;
        });
    }

    static void selectAll() {
        if (ide.varTable != null) {
            ide.varTable.getSelectionModel().selectAll();
            ide.varTable.requestFocus();
        }
    }

    /** @return the number of variables in the workspace */
    static int rowCount() {
        return WorkspaceStore.get().rows().size();
    }

    /** @return true while the explorer fills the window (or its own screen) */
    static boolean isFullScreen() {
        return mode == VariableViewMode.SEPARATE ? window.isFullScreen() : LayoutManager.isVariablesFullScreen();
    }

    /**
     * Full Screen: the File Explorer, the editor, the Command Window and the
     * Code Bot make way, and the Variable Explorer and its variable tabs fill
     * the window under the ribbon. Esc, the menu or choosing a layout ends
     * it. In Separate Window view the window itself goes full screen.
     */
    static void toggleFullScreen() {
        if (mode == VariableViewMode.SEPARATE) {
            window.toggleFullScreen();
            return;
        }
        if (LayoutManager.isVariablesFullScreen()) {
            LayoutManager.setVariablesFullScreen(false, null, null);
            return;
        }
        if (LayoutManager.isVariablesClosed()) {
            LayoutManager.setVariablesClosed(false);
        }
        area.releaseDock();
        dock.setOverlay(false);
        markScriptTabs(false);
        LayoutManager.setVariablesFullScreen(true, dock, () -> mount(mode, true));
        installEscape();
        PanelActivation.setActive(PanelActivation.Panel.VARIABLE_EXPLORER);
    }

    private static void installEscape() {
        if (escapeInstalled || ide.scene == null) {
            return;
        }
        escapeInstalled = true;
        // A handler, not a filter: Esc in a grid cell's editor cancels the
        // edit and is consumed there, so it never ends Full Screen.
        ide.scene.addEventHandler(KeyEvent.KEY_PRESSED, e -> {
            if (e.getCode() == KeyCode.ESCAPE && LayoutManager.isVariablesFullScreen()) {
                LayoutManager.setVariablesFullScreen(false, null, null);
                e.consume();
            }
        });
    }

    static void printTable() {
        PrintModel.Document doc = VariablePrint.table(WorkspaceStore.get().snapshot());
        PrintStudioWindow.open(ide, doc, "Print Workspace", false);
    }

    static void printVariable() {
        VariableViewer viewer = dock.selectedViewer();
        PrintModel.Document doc = viewer == null ? null : VariablePrint.variable(viewer);
        if (doc == null) {
            CLI_Main.printNotice("Print: open a variable first, and wait for its value to appear.");
            return;
        }
        PrintStudioWindow.open(ide, doc, "Print Variable", false);
    }

    /** @return the selected variable tab's name, or null when none is open */
    static String selectedVariableName() {
        VariableViewer viewer = dock == null ? null : dock.selectedViewer();
        return viewer == null ? null : viewer.visualName();
    }

    /**
     * Close: the Variable Explorer leaves the window and the editor takes
     * its place. It comes back with the next command or script, or when a
     * layout is chosen. In Separate Window view the window is hidden.
     */
    static void close() {
        if (mode == VariableViewMode.SEPARATE) {
            window.hide();
            return;
        }
        if (LayoutManager.isVariablesFullScreen()) {
            LayoutManager.setVariablesFullScreen(false, null, null);
        }
        LayoutManager.setVariablesClosed(true);
    }

    /**
     * Copy Name(s): the name as it is written ({@code A_$1}), not as it is
     * drawn (A&#8321;), so pasting it into a script or the Command Window
     * names the same variable. A pasted {@code A₁} would be refused: a
     * Unicode subscript character is not a name character.
     */
    static void copyNames(List<Variable> rows) {
        StringBuilder out = new StringBuilder();
        for (Variable v : rows) {
            out.append(v.getName()).append('\n');
        }
        toClipboard(out.toString().stripTrailing());
    }

    static void copyValues(List<Variable> rows) {
        StringBuilder out = new StringBuilder();
        for (Variable v : rows) {
            if (rows.size() > 1) {
                out.append(v.getDisplayName()).append(" = ");
            }
            out.append(v.getValue()).append('\n');
        }
        toClipboard(out.toString().stripTrailing());
    }

    /** Clear Variable / Clear Selected: {@code clear name} for each row. */
    static void clearVariables(List<Variable> rows) {
        for (Variable v : rows) {
            WorkspaceStore.get().remove(v.getName());
            CLI_Main.sendFromIde(ide, WorkspaceProtocol.clearVariableCommand(v.getName()));
        }
    }

    // =====================================================================
    // Helpers
    // =====================================================================

    private static Window owner() {
        Window w = window == null ? null : window.owner();
        return w != null ? w : ide.stage;
    }

    private static void toClipboard(String text) {
        ClipboardContent content = new ClipboardContent();
        content.putString(text);
        Clipboard.getSystemClipboard().setContent(content);
    }

    private static boolean isInsideTab(Object target) {
        Node n = target instanceof Node node ? node : null;
        while (n != null) {
            if (n.getStyleClass().contains("tab")) {
                return true;
            }
            n = n.getParent();
        }
        return false;
    }
}
