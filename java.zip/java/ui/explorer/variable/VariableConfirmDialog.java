package ui.explorer.variable;

import java.util.List;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.shape.SVGPath;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.Window;
import ui.design.Dim;

/**
 * A square-cornered confirmation box (Reset Explorer).
 *
 * <pre>
 *   +--------------------------------------------------+
 *   | NC  Reset Explorer                           [x] |   title bar
 *   +--------------------------------------------------+
 *   | Clear the whole workspace?                       |   heading
 *   +--------------------------------------------------+
 *   | Every variable is removed from the workspace...  |   message
 *   |                  [ Clear Workspace ] [ Cancel ]  |
 *   +--------------------------------------------------+
 * </pre>
 *
 * <h3>Why not an Alert</h3>
 * <p>
 * An {@code Alert} lives in a window framed by the operating system, and
 * Windows 11 rounds the corners of every such window, whatever the CSS says.
 * This box is a frameless window that draws its own title bar, so its corners
 * stay square, like the Print window's. Its buttons are square too.
 * </p>
 *
 * <p>
 * Geometry comes from {@code Dim.VariableExplorer} through the generated
 * sheet in {@link VariableStyles}; colours from {@code variable_light.css} /
 * {@code variable_dark.css}. Enter confirms, Esc cancels, the title bar drags
 * the box.
 * </p>
 */
final class VariableConfirmDialog {

    private VariableConfirmDialog() {
    }

    /**
     * Shows the box and waits for an answer.
     *
     * @param owner       the window the box belongs to (centred over it)
     * @param stylesheets the main scene's stylesheets, or null
     * @param title       the title-bar text
     * @param heading     the question
     * @param message     what will happen
     * @param confirmText the confirming button's text
     * @return true when the user confirmed
     */
    static boolean ask(Window owner, List<String> stylesheets, String title,
            String heading, String message, String confirmText) {
        boolean[] answer = { false };

        Stage stage = new Stage(StageStyle.UNDECORATED);
        stage.initModality(Modality.WINDOW_MODAL);
        if (owner != null) {
            stage.initOwner(owner);
        }
        stage.setTitle(title);
        stage.setResizable(false);
        Image icon = ownerIcon(owner);
        if (icon != null) {
            stage.getIcons().add(icon);
        }

        // ---- title bar ---------------------------------------------------
        HBox bar = new HBox();
        bar.getStyleClass().add("ve-dialog-title-bar");
        bar.setAlignment(Pos.CENTER_LEFT);
        double barH = Dim.VariableExplorer.DIALOG_TITLE_BAR_HEIGHT;
        bar.setMinHeight(barH);
        bar.setPrefHeight(barH);
        bar.setMaxHeight(barH);
        if (icon != null) {
            ImageView view = new ImageView(icon);
            double s = Dim.VariableExplorer.DIALOG_TITLE_ICON_SIZE;
            view.setFitWidth(s);
            view.setFitHeight(s);
            view.setPreserveRatio(true);
            view.setSmooth(true);
            bar.getChildren().add(view);
        }
        Label titleLabel = new Label(title);
        titleLabel.getStyleClass().add("ve-dialog-title");
        Region grow = new Region();
        HBox.setHgrow(grow, Priority.ALWAYS);

        SVGPath cross = new SVGPath();
        cross.setContent("M0,0 L10,10 M10,0 L0,10");
        cross.setStrokeWidth(1.2);
        cross.getStyleClass().add("ve-dialog-cross");
        Button close = new Button();
        close.setGraphic(cross);
        close.getStyleClass().add("ve-dialog-close");
        close.setFocusTraversable(false);
        double cw = Dim.VariableExplorer.DIALOG_CLOSE_WIDTH;
        close.setMinSize(cw, barH);
        close.setPrefSize(cw, barH);
        close.setMaxSize(cw, barH);
        close.setOnAction(e -> stage.close());
        bar.getChildren().addAll(titleLabel, grow, close);

        double[] grab = new double[2];
        bar.setOnMousePressed(e -> {
            grab[0] = stage.getX() - e.getScreenX();
            grab[1] = stage.getY() - e.getScreenY();
        });
        bar.setOnMouseDragged(e -> {
            stage.setX(e.getScreenX() + grab[0]);
            stage.setY(e.getScreenY() + grab[1]);
        });

        // ---- heading and message -----------------------------------------
        Label head = new Label(heading);
        head.getStyleClass().add("ve-dialog-heading");
        head.setWrapText(true);
        head.setMaxWidth(Double.MAX_VALUE);
        HBox headBox = new HBox(head);
        headBox.getStyleClass().add("ve-dialog-head");
        HBox.setHgrow(head, Priority.ALWAYS);

        Label body = new Label(message);
        body.getStyleClass().add("ve-dialog-message");
        body.setWrapText(true);
        body.setMaxWidth(Double.MAX_VALUE);

        // ---- buttons -----------------------------------------------------
        Button ok = new Button(confirmText);
        ok.getStyleClass().addAll("ve-dialog-button", "ve-dialog-confirm");
        ok.setDefaultButton(true);
        ok.setOnAction(e -> {
            answer[0] = true;
            stage.close();
        });
        Button cancel = new Button("Cancel");
        cancel.getStyleClass().add("ve-dialog-button");
        cancel.setCancelButton(true);
        cancel.setOnAction(e -> stage.close());
        double bw = Dim.VariableExplorer.DIALOG_BUTTON_MIN_WIDTH;
        ok.setMinWidth(bw);
        cancel.setMinWidth(bw);

        HBox buttons = new HBox(ok, cancel);
        buttons.getStyleClass().add("ve-dialog-buttons");
        buttons.setAlignment(Pos.CENTER_RIGHT);

        VBox content = new VBox(body, buttons);
        content.getStyleClass().add("ve-dialog-content");

        VBox root = new VBox(bar, headBox, content);
        root.getStyleClass().add("ve-dialog");
        root.setPrefWidth(Dim.VariableExplorer.DIALOG_WIDTH);
        VariableStyles.attach(root);

        Scene scene = new Scene(root);
        if (stylesheets != null) {
            scene.getStylesheets().setAll(stylesheets);
        }
        scene.addEventFilter(KeyEvent.KEY_PRESSED, e -> {
            if (e.getCode() == KeyCode.ESCAPE) {
                stage.close();
                e.consume();
            }
        });
        stage.setScene(scene);

        // Centre over the owner once the size is known.
        stage.setOnShown(e -> {
            if (owner != null) {
                stage.setX(owner.getX() + (owner.getWidth() - stage.getWidth()) / 2);
                stage.setY(owner.getY() + (owner.getHeight() - stage.getHeight()) / 3);
            }
            ok.requestFocus();
        });
        stage.showAndWait();
        return answer[0];
    }

    private static Image ownerIcon(Window owner) {
        if (owner instanceof Stage s && !s.getIcons().isEmpty()) {
            return s.getIcons().get(0);
        }
        return null;
    }
}
