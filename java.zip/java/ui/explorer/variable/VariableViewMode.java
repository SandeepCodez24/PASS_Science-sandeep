package ui.explorer.variable;

/**
 * Where a variable opens when its row is clicked: the three choices under the
 * Variable Explorer's three-dot menu, Visual Options.
 *
 * <pre>
 *   DEFAULT    one tab strip: scripts from the left, variables from the right
 *   SPLIT      the editor area split in two: scripts | variables, 50 / 50
 *   SEPARATE   the Variable Explorer (table + variable tabs) in its own
 *              window; the editor takes the explorer's place
 * </pre>
 *
 * <p>
 * The name is what the preference stores, so renaming a constant resets the
 * preference to {@link #DEFAULT} rather than failing.
 * </p>
 */
public enum VariableViewMode {

    DEFAULT("Default"),
    SPLIT("Split Window"),
    SEPARATE("Separate Window");

    private final String label;

    VariableViewMode(String label) {
        this.label = label;
    }

    /** @return the menu label */
    public String label() {
        return label;
    }

    /**
     * @param name a stored preference value
     * @return the matching mode, or {@link #DEFAULT} for anything unknown
     */
    public static VariableViewMode fromName(String name) {
        if (name != null) {
            for (VariableViewMode mode : values()) {
                if (mode.name().equals(name)) {
                    return mode;
                }
            }
        }
        return DEFAULT;
    }
}
