package ui.explorer.variable;

import javafx.application.Platform;
import javafx.geometry.Orientation;
import javafx.scene.Node;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TabPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import ui.design.Dim;
import ui.design.UIScale;

/**
 * The editor area as {@code LayoutManager} places it: the editor's tab pane,
 * plus -- depending on Visual Options -- the variable tabs.
 *
 * <pre>
 *   Default    [ script tabs ...                     ... var3 var2 var1 ]
 *              [ the selected script, or the active variable's grid     ]
 *
 *   Split      [ script tabs ...          | var1 var2 var3 ...          ]
 *              [ the selected script      | the selected variable       ]
 *              (only while a variable is open; with none open the
 *               script tabs fill the whole area)
 *
 *   Separate   [ script tabs ...                                        ]
 *              (the variable tabs are in the Variable Explorer window)
 * </pre>
 *
 * <p>
 * {@code ide.editorTabs} is unchanged and is still the editor to everything
 * that reads it -- Run, Save, search, folding, zoom. This node only wraps it.
 * {@code LayoutManager} treats this node as "the editor": it is what the
 * layouts put in their splits and what Custom shrinks to its tab strip.
 * </p>
 *
 * <h3>Keeping the script tabs clear of the variable tabs</h3>
 * <p>
 * In Default view the variable tabs sit at the right end of the same strip.
 * The script strip is given that much room at its right ({@link #reserve}),
 * so a long row of script tabs scrolls under its own overflow menu instead of
 * running beneath the variable tabs.
 * </p>
 */
final class VariableEditorArea extends StackPane {

    /** Modena's padding of a tab header area, except the right side. */
    private static final String HEADER_PAD_TOP = "0.416667em";
    private static final String HEADER_PAD_BOTTOM = "0";
    private static final String HEADER_PAD_LEFT = "0.833em";

    private final TabPane editorTabs;
    private final VariableDock dock;
    private SplitPane split;
    private double reserved = -1;

    /** The view last mounted, and whether the dock belonged here then. */
    private VariableViewMode mountedMode = VariableViewMode.DEFAULT;
    private boolean mountedDockHere = true;

    /** Where the user left the Split divider; restored when the split returns. */
    private double splitShare = Dim.VariableExplorer.SPLIT_SCRIPT_SHARE;
    private boolean remountQueued;

    VariableEditorArea(TabPane editorTabs, VariableDock dock) {
        this.editorTabs = editorTabs;
        this.dock = dock;
        getStyleClass().add("variable-editor-area");
        getChildren().setAll(editorTabs);

        // Split Window opens with the first variable and closes with the
        // last; the scripts have the whole area in between.
        dock.emptyProperty().addListener((obs, was, now) -> {
            if (mountedMode != VariableViewMode.SPLIT || !mountedDockHere || remountQueued) {
                return;
            }
            // Deferred: the tab list is still being changed when this fires.
            remountQueued = true;
            Platform.runLater(() -> {
                remountQueued = false;
                if (mountedMode == VariableViewMode.SPLIT && mountedDockHere) {
                    mount(mountedMode, true);
                }
            });
        });
    }

    /**
     * Arranges the editor area for a view.
     *
     * @param mode     the Visual Options choice
     * @param dockHere false while the variable tabs are somewhere else (the
     *                 separate window, Full Screen)
     */
    void mount(VariableViewMode mode, boolean dockHere) {
        mountedMode = mode;
        mountedDockHere = dockHere;
        dropSplit();
        getChildren().clear();

        if (!dockHere || mode == VariableViewMode.SEPARATE) {
            reserve(0);
            getChildren().setAll(editorTabs);
            return;
        }
        if (mode == VariableViewMode.SPLIT) {
            reserve(0);
            dock.setOverlay(false);
            if (dock.isEmpty()) {
                // No variable open: the editor takes all of the area.
                getChildren().setAll(editorTabs);
                return;
            }
            split = new SplitPane(editorTabs, dock);
            split.setOrientation(Orientation.HORIZONTAL);
            split.getStyleClass().add("variable-editor-split");
            double share = splitShare;
            split.setDividerPositions(share);
            SplitPane s = split;
            Platform.runLater(() -> s.setDividerPositions(share));
            getChildren().setAll(split);
            return;
        }
        // DEFAULT: the dock lies over the editor's tab pane.
        dock.setOverlay(true);
        getChildren().setAll(editorTabs, dock);
    }

    /**
     * Takes the dock out of this area so another parent can have it.
     */
    void releaseDock() {
        // Until the next mount, opening or closing a variable must not pull
        // the dock back here.
        mountedDockHere = false;
        if (split != null && split.getItems().contains(dock)) {
            rememberShare();
            split.getItems().remove(dock);
        }
        getChildren().remove(dock);
    }

    private void dropSplit() {
        if (split != null) {
            rememberShare();
            split.getItems().clear();
            split = null;
        }
    }

    private void rememberShare() {
        if (split != null && split.getItems().size() == 2 && split.getDividers().size() == 1) {
            double p = split.getDividerPositions()[0];
            if (p > 0.05 && p < 0.95) {
                splitShare = p;
            }
        }
    }

    /**
     * Keeps the right end of the script strip free for the variable tabs
     * (Default view). Zero gives the strip its normal padding back.
     *
     * @param width the variable tabs' width
     */
    void reserve(double width) {
        double w = width <= 0 ? 0 : width + Dim.VariableExplorer.TAB_STRIP_GAP;
        if (Math.abs(w - reserved) < 0.5) {
            return;
        }
        reserved = w;
        Node area = editorTabs.lookup(".tab-header-area");
        if (!(area instanceof Region region)) {
            // Not skinned yet: tried again on the next width report.
            reserved = -1;
            return;
        }
        if (w == 0) {
            region.setStyle("");
        } else {
            region.setStyle("-fx-padding: " + HEADER_PAD_TOP + " " + UIScale.fmt(w) + "px "
                    + HEADER_PAD_BOTTOM + " " + HEADER_PAD_LEFT + ";");
        }
    }
}
