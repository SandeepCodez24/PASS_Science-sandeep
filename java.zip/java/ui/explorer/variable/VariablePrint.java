package ui.explorer.variable;

import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import ui.ui_functions.Variable;
import ui.ui_functions.tools.print.PrintModel;

/**
 * Turns the Variable Explorer into documents the Print window can print or
 * save as PDF ({@code PrintStudioWindow}), so printing here offers the same
 * printer choice, page range, copies and Light / Dark PDF as printing a
 * script.
 *
 * <ul>
 * <li>{@link #table} -- the explorer table: Name, Value, Size, Datatype.</li>
 * <li>{@link #variable} -- one variable as its grid shows it: numbered rows
 * and columns for a matrix, Key / Value lines for a dictionary, the text for
 * a string.</li>
 * </ul>
 *
 * <p>
 * Both are plain text in the bundled monospaced face, columns padded to line
 * up. A row too wide for the page wraps, as long code lines do.
 * </p>
 */
final class VariablePrint {

    /** Widest a printed Value cell may be before it is shortened. */
    private static final int VALUE_WIDTH = 48;

    /** Widest a printed matrix column may be. */
    private static final int CELL_WIDTH = 14;

    private VariablePrint() {
    }

    /**
     * @param rows the explorer's rows, in table order
     * @return the document
     */
    static PrintModel.Document table(List<Variable> rows) {
        String[] head = { "Name", "Value", "Size", "Datatype" };
        int[] w = { head[0].length(), head[1].length(), head[2].length(), head[3].length() };
        List<String[]> cells = new ArrayList<>();
        for (Variable v : rows) {
            String[] r = {
                    nz(v.getDisplayName()),
                    clip(nz(v.getValue()), VALUE_WIDTH),
                    nz(v.getSize()),
                    nz(v.getDatatype()) };
            cells.add(r);
            for (int i = 0; i < 4; i++) {
                w[i] = Math.max(w[i], r[i].length());
            }
        }
        List<String> lines = new ArrayList<>();
        lines.add(row(head, w));
        lines.add(rule(w));
        for (String[] r : cells) {
            lines.add(row(r, w));
        }
        if (rows.isEmpty()) {
            lines.add("(no variables in the workspace)");
        }
        return document("Workspace", lines);
    }

    /**
     * @param viewer an open variable tab
     * @return the document, or null when the tab has no value yet
     */
    static PrintModel.Document variable(VariableViewer viewer) {
        VariableGrid g = viewer.grid();
        if (g == null) {
            return null;
        }
        List<String> lines = new ArrayList<>();
        lines.add(viewer.visualName() + "  " + g.summary());
        lines.add("");
        switch (g.shape()) {
            case TEXT -> lines.add(g.display(0, 0));
            case TABLE -> {
                int kw = g.titles().isEmpty() ? 3 : g.titles().get(0).length();
                for (int r = 0; r < g.rows(); r++) {
                    kw = Math.max(kw, Math.min(32, g.display(r, 0).length()));
                }
                String k = g.titles().isEmpty() ? "Key" : g.titles().get(0);
                lines.add(pad(k, kw) + "  Value");
                lines.add("-".repeat(kw) + "  " + "-".repeat(5));
                for (int r = 0; r < g.rows(); r++) {
                    lines.add(pad(clip(g.display(r, 0), 32), kw) + "  " + g.display(r, 1));
                }
            }
            default -> matrix(g, lines);
        }
        if (g.note() != null) {
            lines.add("");
            lines.add(g.note());
        }
        return document(viewer.visualName(), lines);
    }

    private static void matrix(VariableGrid g, List<String> lines) {
        int rows = g.rows();
        int cols = g.columns();
        int rw = Math.max(1, String.valueOf(rows).length());
        int[] w = new int[cols];
        for (int c = 0; c < cols; c++) {
            w[c] = String.valueOf(c + 1).length();
            for (int r = 0; r < rows; r++) {
                w[c] = Math.max(w[c], Math.min(CELL_WIDTH, g.display(r, c).length()));
            }
        }
        StringBuilder head = new StringBuilder(" ".repeat(rw)).append(" |");
        for (int c = 0; c < cols; c++) {
            head.append(' ').append(padLeft(String.valueOf(c + 1), w[c]));
        }
        lines.add(head.toString());
        lines.add("-".repeat(head.length()));
        for (int r = 0; r < rows; r++) {
            StringBuilder line = new StringBuilder(padLeft(String.valueOf(r + 1), rw)).append(" |");
            for (int c = 0; c < cols; c++) {
                line.append(' ').append(padLeft(clip(g.display(r, c), CELL_WIDTH), w[c]));
            }
            lines.add(line.toString());
        }
    }

    // =====================================================================
    // Text helpers
    // =====================================================================

    private static PrintModel.Document document(String title, List<String> text) {
        List<PrintModel.Line> lines = new ArrayList<>(text.size());
        for (int i = 0; i < text.size(); i++) {
            String t = text.get(i);
            List<PrintModel.Run> runs = t.isEmpty()
                    ? List.of()
                    : List.of(new PrintModel.Run(t, Collections.emptyList()));
            lines.add(new PrintModel.Line(i + 1, runs));
        }
        // The page header shows the document's path when it has one; a
        // path made of the title alone prints just the title there.
        Path header;
        try {
            header = Path.of(title);
        } catch (InvalidPathException e) {
            header = null;
        }
        return new PrintModel.Document(title, header, lines);
    }

    private static String row(String[] cells, int[] w) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < cells.length; i++) {
            if (i > 0) {
                out.append("  ");
            }
            out.append(i == cells.length - 1 ? cells[i] : pad(cells[i], w[i]));
        }
        return out.toString();
    }

    private static String rule(int[] w) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < w.length; i++) {
            if (i > 0) {
                out.append("  ");
            }
            out.append("-".repeat(w[i]));
        }
        return out.toString();
    }

    private static String pad(String s, int width) {
        return s.length() >= width ? s : s + " ".repeat(width - s.length());
    }

    private static String padLeft(String s, int width) {
        return s.length() >= width ? s : " ".repeat(width - s.length()) + s;
    }

    private static String clip(String s, int max) {
        return s.length() <= max ? s : s.substring(0, Math.max(0, max - 1)) + "…";
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }
}
