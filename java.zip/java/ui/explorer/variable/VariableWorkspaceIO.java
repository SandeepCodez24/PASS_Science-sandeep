package ui.explorer.variable;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import javafx.beans.value.ChangeListener;
import javafx.stage.FileChooser;
import javafx.stage.Window;
import ui.UI_Main;
import ui.cli.CLI_Main;
import ui.editor.navigation.NavigationActions;

/**
 * Save Workspace and Load Workspace, from the Variable Explorer's three-dot
 * menu.
 *
 * <p>
 * Both go through the interpreter's own functions, so the {@code .ndat}
 * file is written and read by the data engine exactly as typing them in the
 * Command Window would:
 * </p>
 * <pre>
 *   save_workspace("D:/work/run_03.ndat");
 *   load_workspace("D:/work/run_03.ndat");
 * </pre>
 * <ul>
 * <li><b>Save</b> asks where, starting in the current folder with the name
 * {@code workspace.ndat}, and adds {@code .ndat} if the name has no
 * extension. Typing {@code save_workspace()} in the Command Window still
 * saves {@code workspace.ndat} silently, as before.</li>
 * <li><b>Load</b> lists {@code .ndat} files only.</li>
 * <li>The path is written with forward slashes, which Windows accepts and
 * which no string escape can misread.</li>
 * <li>Once the interpreter is back at its prompt, a saved file is confirmed in
 * the Command Window. A load needs no message: the variables appear in the
 * Explorer.</li>
 * </ul>
 */
final class VariableWorkspaceIO {

    private static final FileChooser.ExtensionFilter NDAT =
            new FileChooser.ExtensionFilter("Neural Code workspace (*.ndat)", "*.ndat");

    private static final String DEFAULT_NAME = "workspace.ndat";

    private VariableWorkspaceIO() {
    }

    /**
     * Asks for a file and saves the workspace into it.
     *
     * @param ide   the IDE controller
     * @param owner the window the dialog belongs to
     */
    static void save(UI_Main ide, Window owner) {
        FileChooser fc = new FileChooser();
        fc.setTitle("Save Workspace");
        fc.getExtensionFilters().add(NDAT);
        fc.setSelectedExtensionFilter(NDAT);
        fc.setInitialFileName(DEFAULT_NAME);
        Path start = startFolder(ide);
        if (start != null) {
            fc.setInitialDirectory(start.toFile());
        }
        File chosen = fc.showSaveDialog(owner);
        if (chosen == null) {
            return;
        }
        if (!chosen.getName().contains(".")) {
            chosen = new File(chosen.getParentFile(), chosen.getName() + ".ndat");
        }
        Path target = chosen.toPath().toAbsolutePath();
        long before = modified(target);
        String command = "save_workspace(" + literal(target) + ");";
        CLI_Main.sendFromIde(ide, command);
        whenIdle(() -> {
            if (modified(target) > before) {
                CLI_Main.printNotice("Workspace saved: " + target);
            }
        });
    }

    /**
     * Asks for a {@code .ndat} file and loads it into the workspace.
     *
     * @param ide        the IDE controller
     * @param owner      the window the dialog belongs to
     * @param beforeSend run just before the command goes out (the controller
     *                   uses it to mark the variables that arrive as loaded)
     */
    static void load(UI_Main ide, Window owner, Runnable beforeSend) {
        FileChooser fc = new FileChooser();
        fc.setTitle("Load Workspace");
        fc.getExtensionFilters().add(NDAT);
        fc.setSelectedExtensionFilter(NDAT);
        Path start = startFolder(ide);
        if (start != null) {
            fc.setInitialDirectory(start.toFile());
        }
        File chosen = fc.showOpenDialog(owner);
        if (chosen == null) {
            return;
        }
        if (!chosen.getName().toLowerCase(java.util.Locale.ROOT).endsWith(".ndat")) {
            CLI_Main.printNotice("Load Workspace: only .ndat files can be loaded.");
            return;
        }
        if (beforeSend != null) {
            beforeSend.run();
        }
        CLI_Main.sendFromIde(ide, "load_workspace(" + literal(chosen.toPath().toAbsolutePath()) + ");");
    }

    private static Path startFolder(UI_Main ide) {
        Path folder = NavigationActions.projectFolder(ide);
        if (folder == null) {
            folder = ide.currentFolder;
        }
        return folder != null && Files.isDirectory(folder) ? folder : null;
    }

    private static String literal(Path path) {
        return VariableAssignment.quote(path.toString().replace('\\', '/'));
    }

    private static long modified(Path path) {
        try {
            return Files.exists(path) ? Files.getLastModifiedTime(path).toMillis() : -1L;
        } catch (IOException | RuntimeException e) {
            return -1L;
        }
    }

    /** Runs an action once the interpreter has answered (busy goes false). */
    private static void whenIdle(Runnable action) {
        ChangeListener<Boolean> once = new ChangeListener<>() {
            @Override
            public void changed(javafx.beans.value.ObservableValue<? extends Boolean> obs, Boolean was, Boolean busy) {
                if (!Boolean.TRUE.equals(busy)) {
                    CLI_Main.busyProperty().removeListener(this);
                    action.run();
                }
            }
        };
        CLI_Main.busyProperty().addListener(once);
    }
}
