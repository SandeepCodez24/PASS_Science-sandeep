package ui.explorer.variable;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import backend.workspace.WorkspaceProtocol;

/**
 * One variable's full value laid out as a grid: what each cell shows, what it
 * shows while being edited, whether it may be edited, and the line an edit
 * sends to the interpreter.
 *
 * <p>
 * Built from the {@code @VAR} value tree ({@code runtime/data/WS_PROTOCOL.md}).
 * Indices are 0-based here, 1-based on screen (as in MATLAB), and written
 * from {@link VariableAssignment#INDEX_BASE} (0) in the commands.
 * </p>
 *
 * <table>
 * <caption>How each value kind is laid out</caption>
 * <tr><td>num, int, bool, complex</td><td>one cell, editable</td></tr>
 * <tr><td>str</td><td>one wide cell, editable (the text, without quotes)</td></tr>
 * <tr><td>tensor</td><td>rows x columns, every element editable</td></tr>
 * <tr><td>ndarray</td><td>one 2-D page (the last two axes) at a time, every
 * element editable; {@link #page(int[])} picks the page</td></tr>
 * <tr><td>cell, cellmatrix</td><td>rows x columns, read-only summaries</td></tr>
 * <tr><td>dict</td><td>Key | Value; a scalar or text value is editable</td></tr>
 * <tr><td>object</td><td>Field | Type | Value, read-only; the types in the words
 * {@code X.base} uses ({@link #typeWord})</td></tr>
 * <tr><td>func</td><td>one cell, read-only</td></tr>
 * </table>
 *
 * <h3>N-D matrices (new)</h3>
 * <p>
 * An {@code ndarray} value ({@code "shape":[2,3,4]}, {@code "order":"row-major"})
 * is shown one page at a time: the last two axes are the grid's rows and
 * columns, and one 0-based key per leading axis picks the page -- the
 * Command Window's {@code B[1,:,:]}. Element {@code [i0,...,r,c]} of shape
 * {@code [d0,...,R,C]} sits at flat position {@code ((i0*d1 + i1)...)*R*C + r*C + c}
 * (last index fastest). The elements come as {@code data} (numbers),
 * {@code re}/{@code im} (complex) or {@code items} (one value node each:
 * text, bool, int ...); {@code "truncated":true} carries no data. A grid
 * keeps the value it was built from, so another page is built without a new
 * fetch.
 * </p>
 */
public final class VariableGrid {

    /** How the grid is drawn. */
    public enum Shape {
        /** Numbered rows and numbered columns. */
        MATRIX,
        /** One wide text cell. */
        TEXT,
        /** Two named columns: Key / Value or Field / Value. */
        TABLE
    }

    private final String name;
    private final String cls;
    private final String size;
    private final Shape shape;
    private final int rows;
    private final int cols;
    private final List<String> titles;
    private final Cells cells;
    private final Editor editor;
    private final boolean inherited;
    private final String unit;
    private final String note;
    /** Every axis of an {@code ndarray}; empty for any other value. */
    private final List<Integer> ndShape;
    /** The page on screen: one 0-based key per leading axis. */
    private final int[] page;
    /** The value this grid was built from, for {@link #page(int[])}. */
    private final WorkspaceProtocol.VariableValue source;

    /** Builds the command for one edited cell. */
    @FunctionalInterface
    private interface Editor {
        String command(int row, int col, String typed);
    }

    /**
     * Where cell text comes from. Small values are stored as arrays; a
     * tensor reads its element list on demand, so a two-million-element
     * matrix costs one list, not two million strings.
     */
    private interface Cells {
        String display(int r, int c);

        String edit(int r, int c);

        boolean editable(int r, int c);
    }

    private VariableGrid(Builder b) {
        this.name = b.name;
        this.cls = b.cls;
        this.size = b.size;
        this.shape = b.shape;
        this.rows = b.rows;
        this.cols = b.cols;
        this.titles = b.titles;
        this.cells = b.cells != null ? b.cells : b.arrayCells();
        this.editor = b.editor;
        this.inherited = b.inherited;
        this.unit = b.unit;
        this.note = b.note;
        this.ndShape = b.ndShape;
        this.page = b.page.clone();
        this.source = b.source;
    }

    // =====================================================================
    // Reading
    // =====================================================================

    /** @return the layout */
    public Shape shape() {
        return shape;
    }

    /** @return rows holding data */
    public int rows() {
        return rows;
    }

    /** @return columns holding data */
    public int columns() {
        return cols;
    }

    /** @return column captions for {@link Shape#TABLE}, otherwise empty */
    public List<String> titles() {
        return titles;
    }

    /**
     * @param r 0-based row
     * @param c 0-based column
     * @return the cell's text; empty outside the data
     */
    public String display(int r, int c) {
        if (r < 0 || c < 0 || r >= rows || c >= cols) {
            return "";
        }
        String s = cells.display(r, c);
        return s == null ? "" : s;
    }

    /**
     * @param r 0-based row
     * @param c 0-based column
     * @return the text the cell's editor starts with: full precision
     */
    public String editText(int r, int c) {
        if (r < 0 || c < 0 || r >= rows || c >= cols) {
            return "";
        }
        String s = cells.edit(r, c);
        return s == null ? display(r, c) : s;
    }

    /**
     * @param r 0-based row
     * @param c 0-based column
     * @return true when an edit of this cell can be sent to the interpreter
     */
    public boolean isEditable(int r, int c) {
        return r >= 0 && c >= 0 && r < rows && c < cols && editor != null && cells.editable(r, c);
    }

    /**
     * The line that assigns what was typed into this cell.
     *
     * @param r     0-based row
     * @param c     0-based column
     * @param typed the new text
     * @return the command
     * @throws IllegalArgumentException with a message for the user when the
     *                                  edit cannot be sent
     */
    public String command(int r, int c, String typed) {
        if (!isEditable(r, c)) {
            throw new IllegalArgumentException("This cell cannot be edited here.");
        }
        return editor.command(r, c, typed);
    }

    /** @return true for an object whose class has a parent class */
    public boolean isInherited() {
        return inherited;
    }

    /** @return the interpreter's class name */
    public String cls() {
        return cls;
    }

    /**
     * @return the caption above the grid: {@code 5×5 float64}, plus the unit
     *         when the value has one
     */
    public String summary() {
        String s = (size == null || size.isBlank() ? "" : size.replace('x', '×') + " ") + cls;
        return unit == null || unit.isBlank() ? s : s + "  ·  " + unit;
    }

    /** @return a note under the caption (truncated data), or null */
    public String note() {
        return note;
    }

    /** @return the interpreter's size string */
    public String size() {
        return size;
    }

    /** @return the cleaned variable name */
    public String name() {
        return name;
    }

    // ---- N-D pages ---------------------------------------------------------

    /** @return true for an {@code ndarray} value, shown one page at a time */
    public boolean isNdArray() {
        return !ndShape.isEmpty();
    }

    /** @return every axis of an {@code ndarray} ({@code [2, 3, 4]}); empty otherwise */
    public List<Integer> ndShape() {
        return ndShape;
    }

    /** @return the page on screen: one 0-based key per leading axis (a copy) */
    public int[] page() {
        return page.clone();
    }

    /**
     * @return the page as the Command Window labels it, without the name:
     *         {@code [1,:,:]}, {@code [0,1,:,:]}; empty for a value that has
     *         no leading axes
     */
    public String pageLabel() {
        if (page.length == 0) {
            return "";
        }
        StringBuilder label = new StringBuilder("[");
        for (int key : page) {
            label.append(key).append(',');
        }
        return label.append(":,:]").toString();
    }

    /**
     * The same value at another page. Keys out of range are clamped.
     *
     * @param keys one 0-based key per leading axis
     * @return the grid of that page; this grid when the value has no pages
     */
    public VariableGrid page(int[] keys) {
        if (!isNdArray() || source == null || Arrays.equals(keys, page)) {
            return this;
        }
        return of(source, keys);
    }

    // =====================================================================
    // Building
    // =====================================================================

    /**
     * Lays out a fetched value.
     *
     * @param v the {@code @VAR} answer; must be {@code found}
     * @return the grid
     */
    public static VariableGrid of(WorkspaceProtocol.VariableValue v) {
        return of(v, null);
    }

    /**
     * Lays out a fetched value at a chosen page.
     *
     * @param v    the {@code @VAR} answer; must be {@code found}
     * @param page for an {@code ndarray}: one 0-based key per leading axis
     *             (null or short: the missing keys are 0); ignored otherwise
     * @return the grid
     */
    public static VariableGrid of(WorkspaceProtocol.VariableValue v, int[] page) {
        Builder b = new Builder();
        b.source = v;
        b.name = v.name();
        b.cls = v.cls() == null ? "" : v.cls();
        b.size = v.size() == null ? "" : v.size();
        Map<String, Object> value = v.value() == null ? Map.of() : v.value();
        b.unit = str(value.get("unitText"));
        String k = str(value.get("k"));
        switch (k) {
            case "num", "int", "bool", "complex" -> scalar(b, value);
            case "str" -> text(b, value);
            case "tensor" -> tensor(b, value);
            case "ndarray" -> ndArray(b, value, page);
            case "cell" -> cellList(b, value);
            case "cellmatrix" -> cellMatrix(b, value);
            case "dict" -> dict(b, value, "Key", true);
            case "object" -> {
                objectFields(b, value);
                b.inherited = list(value.get("lineage")).size() > 1;
            }
            case "func" -> {
                b.matrix(1, 1);
                b.display[0][0] = "@" + str(value.get("name"));
            }
            default -> {
                b.matrix(1, 1);
                b.display[0][0] = shortText(value);
            }
        }
        return new VariableGrid(b);
    }

    private static void scalar(Builder b, Map<String, Object> value) {
        b.matrix(1, 1);
        b.display[0][0] = shortText(value);
        b.edit[0][0] = editText(value);
        b.editable[0][0] = true;
        String name = b.name;
        // num and int carry their type in "t"; keep it with a cast.
        String type = str(value.get("t"));
        b.editor = (r, c, typed) -> VariableAssignment.whole(name,
                VariableAssignment.cast(type, VariableAssignment.expression(typed)));
    }

    private static void text(Builder b, Map<String, Object> value) {
        b.shape = Shape.TEXT;
        b.rows = 1;
        b.cols = 1;
        b.alloc();
        String s = str(value.get("v"));
        b.display[0][0] = s;
        b.edit[0][0] = s;
        b.editable[0][0] = true;
        String name = b.name;
        b.editor = (r, c, typed) -> VariableAssignment.whole(name, VariableAssignment.quote(typed));
    }

    private static void tensor(Builder b, Map<String, Object> value) {
        List<Object> shape = list(value.get("shape"));
        boolean vector = shape.size() == 1;
        int rows = vector ? 1 : (shape.size() >= 2 ? intOf(shape.get(0)) : 1);
        int cols = vector ? intOf(shape.get(0)) : (shape.size() >= 2 ? intOf(shape.get(1)) : 1);
        b.shape = Shape.MATRIX;
        b.rows = rows;
        b.cols = cols;

        boolean complex = "complex128".equals(str(value.get("elem")));
        List<Object> data = list(value.get("data"));
        List<Object> re = list(value.get("re"));
        List<Object> im = list(value.get("im"));
        boolean truncated = Boolean.TRUE.equals(value.get("truncated"))
                || (complex ? re.isEmpty() : data.isEmpty()) && rows * (long) cols > 0;
        if (truncated) {
            b.note = "This value is too large to show in full; only its size is known.";
            b.cells = EMPTY;
            return;
        }

        final int width = cols;
        b.cells = new Cells() {
            @Override
            public String display(int r, int c) {
                int i = r * width + c; // row-major
                if (complex) {
                    return i < re.size() && i < im.size()
                            ? complexText(num(re.get(i)), num(im.get(i)), false) : "";
                }
                return i < data.size() ? shortNumber(num(data.get(i))) : "";
            }

            @Override
            public String edit(int r, int c) {
                int i = r * width + c;
                if (complex) {
                    return i < re.size() && i < im.size()
                            ? complexText(num(re.get(i)), num(im.get(i)), true) : "";
                }
                return i < data.size() ? fullNumber(num(data.get(i))) : "";
            }

            @Override
            public boolean editable(int r, int c) {
                int i = r * width + c;
                return complex ? i < re.size() && i < im.size() : i < data.size();
            }
        };
        String name = b.name;
        // The element list is float64 on the wire, but an int32 array reports
        // class int32; its elements are cast to that.
        String type = b.cls;
        b.editor = vector
                ? (r, c, typed) -> VariableAssignment.element(name, c,
                        VariableAssignment.cast(type, VariableAssignment.expression(typed)))
                : (r, c, typed) -> VariableAssignment.element(name, r, c,
                        VariableAssignment.cast(type, VariableAssignment.expression(typed)));
    }

    /**
     * One element source of an {@code ndarray}: numbers, complex numbers or
     * value nodes, read by flat (row-major) position.
     */
    private interface Elements {
        boolean has(long i);

        String display(long i);

        String edit(long i);

        /** The right side of the assignment that stores {@code typed} at {@code i}. */
        String expression(long i, String typed);
    }

    private static void ndArray(Builder b, Map<String, Object> value, int[] wanted) {
        List<Object> shapeList = list(value.get("shape"));
        int rank = shapeList.size();
        List<Integer> dims = new ArrayList<>(rank);
        for (Object d : shapeList) {
            dims.add(intOf(d));
        }
        int rows = rank >= 2 ? intOf(shapeList.get(rank - 2)) : 1;
        int cols = rank >= 1 ? intOf(shapeList.get(rank - 1)) : 1;

        int[] page = new int[Math.max(0, rank - 2)];
        long offset = 0;
        for (int axis = 0; axis < page.length; axis++) {
            int want = wanted != null && axis < wanted.length ? wanted[axis] : 0;
            page[axis] = Math.max(0, Math.min(want, dims.get(axis) - 1));
            offset = offset * dims.get(axis) + page[axis];
        }
        final long pageStart = offset * rows * (long) cols;

        b.shape = Shape.MATRIX;
        b.rows = rows;
        b.cols = cols;
        b.ndShape = Collections.unmodifiableList(dims);
        b.page = page;

        long count = 1;
        for (int d : dims) {
            count *= d;
        }
        Elements elements = ndElements(value);
        if (Boolean.TRUE.equals(value.get("truncated")) || elements == null && count > 0) {
            b.note = "This value is too large to show in full; only its size is known.";
            b.cells = EMPTY;
            return;
        }
        if (elements == null) {
            b.cells = EMPTY; // a zero-sized axis: nothing to show
            return;
        }

        final int width = cols;
        b.cells = new Cells() {
            @Override
            public String display(int r, int c) {
                long i = pageStart + (long) r * width + c;
                return elements.has(i) ? elements.display(i) : "";
            }

            @Override
            public String edit(int r, int c) {
                long i = pageStart + (long) r * width + c;
                return elements.has(i) ? elements.edit(i) : "";
            }

            @Override
            public boolean editable(int r, int c) {
                return elements.has(pageStart + (long) r * width + c);
            }
        };
        String name = b.name;
        b.editor = (r, c, typed) -> {
            int[] keys = Arrays.copyOf(page, page.length + 2);
            keys[page.length] = r;
            keys[page.length + 1] = c;
            return VariableAssignment.element(name, keys,
                    elements.expression(pageStart + (long) r * width + c, typed));
        };
    }

    /**
     * Reads the element list of an {@code ndarray}.
     *
     * @return the elements, or null when the value carries none
     */
    private static Elements ndElements(Map<String, Object> value) {
        String elem = str(value.get("elem"));
        List<Object> data = list(value.get("data"));
        List<Object> re = list(value.get("re"));
        List<Object> im = list(value.get("im"));
        List<Object> items = list(value.get("items"));

        if (!re.isEmpty()) {
            return new Elements() {
                @Override
                public boolean has(long i) {
                    return i < re.size() && i < im.size();
                }

                @Override
                public String display(long i) {
                    return complexText(num(re.get((int) i)), num(im.get((int) i)), false);
                }

                @Override
                public String edit(long i) {
                    return complexText(num(re.get((int) i)), num(im.get((int) i)), true);
                }

                @Override
                public String expression(long i, String typed) {
                    return VariableAssignment.expression(typed);
                }
            };
        }
        if (!data.isEmpty()) {
            return new Elements() {
                @Override
                public boolean has(long i) {
                    return i < data.size();
                }

                @Override
                public String display(long i) {
                    return shortNumber(num(data.get((int) i)));
                }

                @Override
                public String edit(long i) {
                    return fullNumber(num(data.get((int) i)));
                }

                @Override
                public String expression(long i, String typed) {
                    // float64 needs no cast; any other number type keeps its own.
                    return VariableAssignment.cast(elem, VariableAssignment.expression(typed));
                }
            };
        }
        if (!items.isEmpty()) {
            return new Elements() {
                @Override
                public boolean has(long i) {
                    return i < items.size() && isScalarKind(str(map(items.get((int) i)).get("k")));
                }

                @Override
                public String display(long i) {
                    return shortText(map(items.get((int) i)));
                }

                @Override
                public String edit(long i) {
                    return editText(map(items.get((int) i)));
                }

                @Override
                public String expression(long i, String typed) {
                    Map<String, Object> item = map(items.get((int) i));
                    // A text matrix holds text: what is typed is stored as text.
                    return "str".equals(str(item.get("k")))
                            ? VariableAssignment.quote(typed)
                            : VariableAssignment.cast(str(item.get("t")), VariableAssignment.expression(typed));
                }
            };
        }
        return null;
    }

    private static void cellList(Builder b, Map<String, Object> value) {
        List<Object> shape = list(value.get("shape"));
        List<Object> items = list(value.get("items"));
        int rows = shape.size() >= 2 ? intOf(shape.get(0)) : 1;
        int cols = shape.size() >= 2 ? intOf(shape.get(1)) : (shape.isEmpty() ? items.size() : intOf(shape.get(0)));
        b.matrix(rows, cols);
        for (int i = 0; i < items.size(); i++) {
            int r = cols == 0 ? 0 : i / cols;
            int c = cols == 0 ? 0 : i % cols;
            if (r < rows && c < cols) {
                b.display[r][c] = shortText(map(items.get(i)));
            }
        }
    }

    private static void cellMatrix(Builder b, Map<String, Object> value) {
        List<Object> rowsList = list(value.get("rows"));
        int rows = rowsList.size();
        int cols = 0;
        for (Object row : rowsList) {
            cols = Math.max(cols, list(row).size());
        }
        b.matrix(rows, cols);
        for (int r = 0; r < rows; r++) {
            List<Object> row = list(rowsList.get(r));
            for (int c = 0; c < row.size(); c++) {
                b.display[r][c] = shortText(map(row.get(c)));
            }
        }
    }

    private static void dict(Builder b, Map<String, Object> value, String keyTitle, boolean editableValues) {
        String listKey = keyTitle.equals("Key") ? "entries" : "fields";
        List<Object> entries = list(value.get(listKey));
        b.shape = Shape.TABLE;
        b.titles = List.of(keyTitle, "Value");
        b.rows = entries.size();
        b.cols = 2;
        b.alloc();
        List<String> keyLiterals = new ArrayList<>(entries.size());
        for (int r = 0; r < entries.size(); r++) {
            Map<String, Object> entry = map(entries.get(r));
            Map<String, Object> key = map(entry.get("key"));
            Map<String, Object> val = map(entry.get("value"));
            // A field list may carry its name as a plain string.
            String keyText = key.isEmpty() ? str(entry.get("key")) : shortText(key);
            b.display[r][0] = keyText;
            b.display[r][1] = shortText(val);
            keyLiterals.add(keyLiteral(key, keyText));
            String vk = str(val.get("k"));
            if (editableValues && isScalarKind(vk)) {
                b.editable[r][1] = true;
                b.edit[r][1] = editText(val);
            }
        }
        if (editableValues) {
            String name = b.name;
            List<String> kinds = new ArrayList<>();
            List<String> types = new ArrayList<>();
            for (Object e : entries) {
                Map<String, Object> val = map(map(e).get("value"));
                kinds.add(str(val.get("k")));
                types.add(str(val.get("t")));
            }
            b.editor = (r, c, typed) -> {
                String expr = "str".equals(kinds.get(r))
                        ? VariableAssignment.quote(typed)
                        : VariableAssignment.cast(types.get(r), VariableAssignment.expression(typed));
                return VariableAssignment.entry(name, keyLiterals.get(r), expr);
            };
        }
    }

    /**
     * An object's fields as Field | Type | Value. The type is written in the
     * words {@code nc.exe}'s {@code X.base} uses, so the IDE and the language
     * describe a field the same way.
     */
    /** The fields a poly1d shows, in this order; nc.exe also sends their other names (c, coef, r ...). */
    private static final List<String> POLY1D_FIELDS = List.of("coeffs", "order", "roots", "variable");

    private static void objectFields(Builder b, Map<String, Object> value) {
        List<Object> fields = list(value.get("fields"));
        if ("poly1d".equals(str(value.get("class")))) {
            List<Object> shown = new ArrayList<>();
            for (String wanted : POLY1D_FIELDS) {
                for (Object field : fields) {
                    Map<String, Object> key = map(map(field).get("key"));
                    String name = key.isEmpty() ? str(map(field).get("key")) : str(key.get("v"));
                    if (wanted.equals(name)) {
                        shown.add(field);
                        break;
                    }
                }
            }
            fields = shown;
        }
        b.shape = Shape.TABLE;
        b.titles = List.of("Field", "Type", "Value");
        b.rows = fields.size();
        b.cols = 3;
        b.alloc();
        for (int r = 0; r < fields.size(); r++) {
            Map<String, Object> entry = map(fields.get(r));
            Map<String, Object> key = map(entry.get("key"));
            Map<String, Object> val = map(entry.get("value"));
            b.display[r][0] = key.isEmpty() ? str(entry.get("key")) : shortText(key);
            b.display[r][1] = typeWord(val);
            b.display[r][2] = shortText(val);
        }
    }

    /**
     * The type of a value in the words {@code X.base} uses: {@code float64},
     * {@code int32} (and the other int / uint / float widths), {@code bool},
     * {@code complex}, {@code string}, {@code matrix}, {@code dict},
     * {@code function}, or the class name of an object.
     *
     * @param v a value node
     * @return the type word; empty for an empty node
     */
    static String typeWord(Map<String, Object> v) {
        String k = str(v.get("k"));
        return switch (k) {
            case "num", "int" -> str(v.get("t")).isEmpty() ? ("int".equals(k) ? "int64" : "float64") : str(v.get("t"));
            case "bool" -> "bool";
            case "complex" -> "complex";
            case "str" -> "string";
            case "tensor", "ndarray", "cell", "cellmatrix" -> "matrix";
            case "dict" -> "dict";
            case "func" -> "function";
            case "object" -> str(v.get("class"));
            default -> k;
        };
    }

    private static boolean isScalarKind(String k) {
        return "num".equals(k) || "int".equals(k) || "bool".equals(k) || "complex".equals(k) || "str".equals(k);
    }

    private static String keyLiteral(Map<String, Object> key, String fallback) {
        String k = str(key.get("k"));
        if ("str".equals(k) || key.isEmpty()) {
            try {
                return VariableAssignment.quote(key.isEmpty() ? fallback : str(key.get("v")));
            } catch (IllegalArgumentException e) {
                return "\"" + fallback + "\"";
            }
        }
        return editText(key);
    }

    // =====================================================================
    // Value text
    // =====================================================================

    /**
     * A one-cell summary of any value: a number, a text, or "&lt;3x4 cell&gt;".
     *
     * @param v a value node
     * @return the text
     */
    static String shortText(Map<String, Object> v) {
        String k = str(v.get("k"));
        return switch (k) {
            case "num" -> singleNumber(num(v.get("v")));
            case "int" -> str(v.get("v"));
            case "bool" -> boolText(v.get("v"));
            case "complex" -> complexText(num(v.get("re")), num(v.get("im")), false);
            case "str" -> str(v.get("v"));
            case "tensor" -> "<" + shapeText(list(v.get("shape"))) + " "
                    + ("complex128".equals(str(v.get("elem"))) ? "complex" : "float64") + ">";
            case "ndarray" -> "<" + shapeText(list(v.get("shape"))) + " "
                    + (str(v.get("elem")).isEmpty() ? "float64" : str(v.get("elem"))) + ">";
            case "cell", "cellmatrix" -> "<" + shapeText(list(v.get("shape"))) + " cell>";
            case "dict" -> "<" + list(v.get("entries")).size() + "x1 dict>";
            case "object" -> "<" + str(v.get("class")) + ">";
            case "func" -> "@" + str(v.get("name"));
            default -> v.isEmpty() ? "" : String.valueOf(v.getOrDefault("v", ""));
        };
    }

    /** The full-precision form of a scalar, for its editor. */
    private static String editText(Map<String, Object> v) {
        String k = str(v.get("k"));
        return switch (k) {
            case "num" -> fullNumber(num(v.get("v")));
            case "complex" -> complexText(num(v.get("re")), num(v.get("im")), true);
            default -> shortText(v);
        };
    }

    private static String boolText(Object o) {
        if (o instanceof Boolean bool) {
            return bool ? "true" : "false";
        }
        return String.valueOf(o);
    }

    private static String shapeText(List<Object> shape) {
        if (shape.isEmpty()) {
            return "1x1";
        }
        if (shape.size() == 1) {
            return "1x" + intOf(shape.get(0));
        }
        // Every axis: 2x3 for a matrix, 2x3x4 for an N-D one.
        StringBuilder text = new StringBuilder();
        for (Object d : shape) {
            if (text.length() > 0) {
                text.append('x');
            }
            text.append(intOf(d));
        }
        return text.toString();
    }

    /**
     * Grid text for a number: whole numbers as they are, others to four
     * decimals (MATLAB's short format), very large or small ones in
     * exponent form.
     */
    static String shortNumber(double d) {
        if (Double.isNaN(d)) {
            return "NaN";
        }
        if (Double.isInfinite(d)) {
            return d > 0 ? "Inf" : "-Inf";
        }
        if (d == Math.rint(d) && Math.abs(d) < 1e15) {
            return Long.toString((long) d);
        }
        double a = Math.abs(d);
        if (a >= 1e5 || a < 1e-4) {
            return String.format(Locale.ROOT, "%.4e", d);
        }
        String s = String.format(Locale.ROOT, "%.4f", d);
        s = s.replaceAll("0+$", "");
        return s.endsWith(".") ? s.substring(0, s.length() - 1) : s;
    }

    /**
     * A single value (not a grid cell), as nc.exe shows it: the short form,
     * except that a value which is not whole but whose short form reads as a
     * whole number is shown with the fewest digits that read back as exactly
     * it - {@code 1.0000000000000002}, {@code 0.9999999999999999}. A matrix
     * grid keeps {@link #shortNumber} ({@code 1.0000} stays {@code 1}).
     */
    static String singleNumber(double d) {
        String s = shortNumber(d);
        if (!Double.isFinite(d) || d == Math.rint(d)) {
            return s;
        }
        try {
            double shown = Double.parseDouble(s);
            if (shown == Math.rint(shown)) {
                return new BigDecimal(Double.toString(d)).toPlainString();
            }
        } catch (NumberFormatException e) {
            // a short form that is not plain digits: keep it
        }
        return s;
    }

    /** The shortest exact form of a number, without exponent where possible. */
    static String fullNumber(double d) {
        if (Double.isNaN(d)) {
            return "NaN";
        }
        if (Double.isInfinite(d)) {
            return d > 0 ? "Inf" : "-Inf";
        }
        if (d == Math.rint(d) && Math.abs(d) < 1e15) {
            return Long.toString((long) d);
        }
        String plain = new BigDecimal(Double.toString(d)).toPlainString();
        return plain.length() > 24 ? Double.toString(d) : plain;
    }

    private static String complexText(double re, double im, boolean full) {
        String a = full ? fullNumber(re) : shortNumber(re);
        String b = full ? fullNumber(Math.abs(im)) : shortNumber(Math.abs(im));
        return a + (im < 0 || (im == 0 && 1 / im < 0) ? " - " : " + ") + b + "i";
    }

    // =====================================================================
    // JSON helpers (the protocol parser hands back Maps, Lists, Numbers)
    // =====================================================================

    private static String str(Object o) {
        return o == null ? "" : String.valueOf(o);
    }

    private static double num(Object o) {
        if (o instanceof Number n) {
            return n.doubleValue();
        }
        String s = str(o).strip();
        return switch (s) {
            case "NaN" -> Double.NaN;
            case "Infinity" -> Double.POSITIVE_INFINITY;
            case "-Infinity" -> Double.NEGATIVE_INFINITY;
            default -> {
                try {
                    yield Double.parseDouble(s);
                } catch (NumberFormatException e) {
                    yield Double.NaN;
                }
            }
        };
    }

    private static int intOf(Object o) {
        double d = num(o);
        return Double.isNaN(d) ? 0 : (int) Math.max(0, Math.min(Integer.MAX_VALUE, d));
    }

    @SuppressWarnings("unchecked")
    private static List<Object> list(Object o) {
        return o instanceof List<?> l ? (List<Object>) l : Collections.emptyList();
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> map(Object o) {
        return o instanceof Map<?, ?> m ? (Map<String, Object>) m : Map.of();
    }

    /** No data: every cell blank and read-only. */
    private static final Cells EMPTY = new Cells() {
        @Override
        public String display(int r, int c) {
            return "";
        }

        @Override
        public String edit(int r, int c) {
            return "";
        }

        @Override
        public boolean editable(int r, int c) {
            return false;
        }
    };

    /** Mutable state while a grid is put together. */
    private static final class Builder {
        String name;
        String cls;
        String size;
        String unit;
        String note;
        Shape shape = Shape.MATRIX;
        int rows;
        int cols;
        List<String> titles = List.of();
        String[][] display;
        String[][] edit;
        boolean[][] editable;
        Editor editor;
        boolean inherited;
        Cells cells;
        List<Integer> ndShape = List.of();
        int[] page = new int[0];
        WorkspaceProtocol.VariableValue source;

        Cells arrayCells() {
            if (display == null) {
                return EMPTY;
            }
            String[][] d = display;
            String[][] e = edit;
            boolean[][] ok = editable;
            return new Cells() {
                @Override
                public String display(int r, int c) {
                    return d[r][c];
                }

                @Override
                public String edit(int r, int c) {
                    return e[r][c];
                }

                @Override
                public boolean editable(int r, int c) {
                    return ok[r][c];
                }
            };
        }

        void matrix(int r, int c) {
            shape = Shape.MATRIX;
            rows = Math.max(0, r);
            cols = Math.max(0, c);
            alloc();
        }

        void alloc() {
            display = new String[rows][cols];
            edit = new String[rows][cols];
            editable = new boolean[rows][cols];
        }
    }
}
