package ui.explorer.project;

import java.nio.file.Path;
import java.util.function.Function;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.TreeCell;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/** Visual cell used by the project tree. */
public final class ProjectTreeCell extends TreeCell<Path> {
    private final Function<Path, ContextMenu> contextMenuFactory;

    public ProjectTreeCell(Function<Path, ContextMenu> contextMenuFactory) {
        this.contextMenuFactory = contextMenuFactory;
        setOnContextMenuRequested(event -> refreshContextMenu());
    }

    @Override
    protected void updateItem(Path item, boolean empty) {
        super.updateItem(item, empty);
        if (empty || item == null) {
            clearCell();
            return;
        }

        setStyle("-fx-padding: 2 6 2 6; -fx-cell-size: 24;");
        Path fileName = item.getFileName();
        setText(fileName == null ? item.toString() : fileName.toString());
        setGraphic(createIconView(ProjectFileIconResolver.resolve(item)));
        setContextMenu(null);
    }

    private void refreshContextMenu() {
        Path item = getItem();
        if (isEmpty() || item == null || contextMenuFactory == null) {
            setContextMenu(null);
            return;
        }
        if (getTreeView() != null && getTreeItem() != null) {
            getTreeView().getSelectionModel().select(getTreeItem());
        }
        setContextMenu(contextMenuFactory.apply(item));
    }

    private static ImageView createIconView(Image icon) {
        if (icon == null) {
            return null;
        }
        ImageView view = new ImageView(icon);
        view.setFitWidth(16);
        view.setFitHeight(16);
        view.setPreserveRatio(true);
        view.setSmooth(true);
        return view;
    }

    private void clearCell() {
        setText(null);
        setGraphic(null);
        setStyle("");
        setContextMenu(null);
    }
}
