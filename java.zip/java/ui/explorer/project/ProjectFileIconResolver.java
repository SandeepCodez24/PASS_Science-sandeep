package ui.explorer.project;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import javafx.scene.image.Image;
import ui.explorer.support.IconLoader;

/** Resolves the display icon for a project-tree path. */
public final class ProjectFileIconResolver {
    private static final String FOLDER_ICON = "/icons/ic_28_folder.png";
    private static final String JAVA_ICON = "/icons/ic_15_java.png";
    private static final String CPP_ICON = "/icons/ic_16_cpp.png";
    private static final String TEXT_ICON = "/icons/ic_13_txt.png";
    private static final String PDF_ICON = "/icons/ic_25_pdf.png";
    private static final String POWERPOINT_ICON = "/icons/ic_24_ppt.png";
    private static final String EXCEL_ICON = "/icons/ic_23_excel.png";
    private static final String HTML_ICON = "/icons/ic_14_html.png";
    private static final String CSS_ICON = "/icons/ic_17_css.png";
    private static final String JAVASCRIPT_ICON = "/icons/ic_16_js.png";
    private static final String GENERIC_FILE_ICON = "/icons/ic_19_file.png";

    private ProjectFileIconResolver() {
    }

    public static Image resolve(Path path) {
        if (path == null) {
            return null;
        }
        String iconPath = resolveIconPath(path);
        Image icon = IconLoader.load(ProjectFileIconResolver.class, iconPath);
        if (icon == null && !GENERIC_FILE_ICON.equals(iconPath)) {
            return IconLoader.load(ProjectFileIconResolver.class, GENERIC_FILE_ICON);
        }
        return icon;
    }

    private static String resolveIconPath(Path path) {
        if (Files.isDirectory(path)) {
            return FOLDER_ICON;
        }
        Path fileName = path.getFileName();
        String name = fileName == null ? "" : fileName.toString().toLowerCase(Locale.ROOT);
        if (name.endsWith(".java")) {
            return JAVA_ICON;
        }
        if (name.endsWith(".cpp") || name.endsWith(".c")) {
            return CPP_ICON;
        }
        if (name.endsWith(".txt")) {
            return TEXT_ICON;
        }
        if (name.endsWith(".pdf")) {
            return PDF_ICON;
        }
        if (name.endsWith(".ppt") || name.endsWith(".pptx")) {
            return POWERPOINT_ICON;
        }
        if (name.endsWith(".xls") || name.endsWith(".xlsx")) {
            return EXCEL_ICON;
        }
        if (name.endsWith(".html")) {
            return HTML_ICON;
        }
        if (name.endsWith(".css")) {
            return CSS_ICON;
        }
        if (name.endsWith(".js")) {
            return JAVASCRIPT_ICON;
        }
        return GENERIC_FILE_ICON;
    }
}
