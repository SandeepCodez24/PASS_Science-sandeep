package ui.explorer.project;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.function.Function;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import ui.UI_Main;
import ui.managers.EditorManager;

/** Initializes the project tree and its interaction handlers. */
public final class ProjectTreeBuilder {
    private ProjectTreeBuilder() {
    }

    public static void initialize(
            UI_Main ide,
            Function<Path, ContextMenu> contextMenuFactory) {
        ide.projectTree = new TreeView<>();
        ide.projectTree.setPrefWidth(220);
        ide.projectTree.setCellFactory(tree -> new ProjectTreeCell(contextMenuFactory));
        ide.projectTree.setOnMouseClicked(event -> {
            if (event.getClickCount() != 2) {
                return;
            }
            TreeItem<Path> selected = ide.projectTree.getSelectionModel().getSelectedItem();
            Path path = selected == null ? null : selected.getValue();
            if (path != null && Files.isRegularFile(path)) {
                EditorManager.openFileDirectly(ide, path);
            }
        });
    }
}
