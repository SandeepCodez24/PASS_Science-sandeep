package ui.explorer.shortcut;

import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import ui.UI_Main;
import ui.managers.EditorManager;
import ui.ui_functions.tools.ToolbarState;

/** Installs application-level keyboard shortcuts for the main window. */
public final class MainWindowShortcutHandler {
    private MainWindowShortcutHandler() {
    }

    public static void install(UI_Main ide) {
        ide.scene.addEventFilter(KeyEvent.KEY_PRESSED, event -> {
            if (event.isAltDown() && event.getCode() == KeyCode.SPACE) {
                if (ToolbarState.searchField != null) {
                    ToolbarState.searchField.requestFocus();
                }
                event.consume();
                return;
            }

            if (event.isControlDown()
                    && !event.isShiftDown()
                    && event.getCode() == KeyCode.S) {
                EditorManager.saveCurrentFile(ide);
                event.consume();
                return;
            }

            if (event.isControlDown()
                    && event.isShiftDown()
                    && event.getCode() == KeyCode.S) {
                EditorManager.saveAsFile(ide);
                event.consume();
                return;
            }

            if (event.isControlDown() && event.getCode() == KeyCode.N) {
                EditorManager.newNeuralCodeFile(ide);
                event.consume();
                return;
            }

            if (event.isControlDown() && event.getCode() == KeyCode.O) {
                EditorManager.openFile(ide);
                event.consume();
                return;
            }

            if (event.getCode() == KeyCode.F5) {
                EditorManager.runCurrentFile(ide);
                event.consume();
                return;
            }

            if (event.getCode() == KeyCode.F6) {
                ide.stopProgram();
                event.consume();
            }
        });
    }
}
