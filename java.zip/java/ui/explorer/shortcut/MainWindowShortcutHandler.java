package ui.explorer.shortcut;

import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.KeyEvent;
import ui.UI_Main;
import ui.editor.EditorViewSettings;
import ui.editor.search.EditorSearch;
import ui.layout.FullScreenToggle;
import ui.managers.EditorManager;
import ui.ribbon_interface.tool_bar.LayoutRibbon;
import ui.ui_functions.tools.ToolbarState;

/**
 * Installs application-level keyboard shortcuts for the main window.
 *
 * <h3>Search (the editor's find / replace bar)</h3>
 * <ul>
 * <li><b>Ctrl + F</b> -- open the bar (a one-line selection becomes the search
 * text). With no file open it searches the root folder.</li>
 * <li><b>Ctrl + H</b> -- open the bar with its Replace row unfolded.</li>
 * <li><b>F3 / Shift + F3</b> -- next / previous match.</li>
 * <li>Enter, Shift+Enter, Esc and Alt+M / W / R / F are handled by the bar
 * itself while it has the keyboard.</li>
 * </ul>
 *
 * <h3>File shortcuts (Home &gt; Files)</h3>
 * <ul>
 * <li><b>Ctrl + N</b> -- New Script ({@link #NEW_SCRIPT}).</li>
 * <li><b>Ctrl + O</b> -- Open File, any extension ({@link #OPEN_FILE}).</li>
 * <li><b>Ctrl + Shift + O</b> -- Open Folder ({@link #OPEN_FOLDER}).</li>
 * <li><b>Ctrl + S</b> -- Save ({@link #SAVE}).</li>
 * <li><b>Ctrl + Shift + S</b> -- Save As ({@link #SAVE_AS}).</li>
 * </ul>
 * <p>
 * These five are the one definition of each key. The New / Open / Save
 * drop-downs show the same constants at the right edge of their entries
 * (display only), so the menu and the keys always agree. Each combination is
 * matched exactly: Ctrl+O no longer fires on Ctrl+Shift+O, which used to open
 * a file instead of a folder. On macOS they are Command, not Ctrl.
 * </p>
 *
 * <h3>View shortcuts (Settings &gt; Layout)</h3>
 * <ul>
 * <li><b>F11</b> -- Full Screen on / off. Esc also leaves full screen; that is
 * JavaFX's own behaviour and needs nothing here.</li>
 * <li><b>Ctrl + = / Ctrl + +</b> -- zoom the editor in.</li>
 * <li><b>Ctrl + -</b> -- zoom the editor out.</li>
 * <li><b>Ctrl + 0</b> -- reset the editor zoom.</li>
 * <li><b>Esc</b> -- close the Layout band, returning to the Settings band.
 * Installed as a handler, not a filter, so the suggestion popup and any other
 * control that uses Esc for itself consumes it first and the band stays
 * put.</li>
 * </ul>
 */
public final class MainWindowShortcutHandler {

    // ---- file shortcuts: shown in the Home ribbon's drop-downs too -------

    /** New Script. */
    public static final KeyCombination NEW_SCRIPT =
            new KeyCodeCombination(KeyCode.N, KeyCombination.SHORTCUT_DOWN);

    /** Open File (any extension). */
    public static final KeyCombination OPEN_FILE =
            new KeyCodeCombination(KeyCode.O, KeyCombination.SHORTCUT_DOWN);

    /** Open Folder. */
    public static final KeyCombination OPEN_FOLDER =
            new KeyCodeCombination(KeyCode.O, KeyCombination.SHORTCUT_DOWN, KeyCombination.SHIFT_DOWN);

    /** Save. */
    public static final KeyCombination SAVE =
            new KeyCodeCombination(KeyCode.S, KeyCombination.SHORTCUT_DOWN);

    /** Save As. */
    public static final KeyCombination SAVE_AS =
            new KeyCodeCombination(KeyCode.S, KeyCombination.SHORTCUT_DOWN, KeyCombination.SHIFT_DOWN);

    private MainWindowShortcutHandler() {
    }

    public static void install(UI_Main ide) {
        ide.scene.addEventFilter(KeyEvent.KEY_PRESSED, event -> {
            if (event.isAltDown() && event.getCode() == KeyCode.SPACE) {
                if (ToolbarState.searchField != null) {
                    ToolbarState.searchField.requestFocus();
                }
                event.consume();
                return;
            }

            if (event.isControlDown() && !event.isAltDown() && !event.isShiftDown()
                    && (event.getCode() == KeyCode.F || event.getCode() == KeyCode.H)) {
                EditorSearch.open(event.getCode() == KeyCode.H);
                event.consume();
                return;
            }

            if (event.getCode() == KeyCode.F3 && !event.isControlDown() && !event.isAltDown()) {
                if (event.isShiftDown()) {
                    EditorSearch.findPrevious();
                } else {
                    EditorSearch.findNext();
                }
                event.consume();
                return;
            }

            // ---- file shortcuts: exact matches, so Shift tells them apart --
            if (SAVE.match(event)) {
                EditorManager.saveCurrentFile(ide);
                event.consume();
                return;
            }

            if (SAVE_AS.match(event)) {
                EditorManager.saveAsFile(ide);
                event.consume();
                return;
            }

            if (NEW_SCRIPT.match(event)) {
                EditorManager.newNeuralCodeFile(ide);
                event.consume();
                return;
            }

            if (OPEN_FILE.match(event)) {
                EditorManager.openFile(ide);
                event.consume();
                return;
            }

            if (OPEN_FOLDER.match(event)) {
                EditorManager.openProjectFolder(ide);
                event.consume();
                return;
            }

            if (event.getCode() == KeyCode.F5) {
                EditorManager.runCurrentFile(ide);
                event.consume();
                return;
            }

            if (event.getCode() == KeyCode.F6) {
                ide.stopProgram();
                event.consume();
                return;
            }

            if (event.getCode() == KeyCode.F11) {
                FullScreenToggle.toggle();
                event.consume();
                return;
            }

            if (event.isControlDown() && !event.isAltDown()) {
                switch (event.getCode()) {
                    case EQUALS, PLUS, ADD -> {
                        EditorViewSettings.zoomIn();
                        event.consume();
                    }
                    case MINUS, SUBTRACT -> {
                        EditorViewSettings.zoomOut();
                        event.consume();
                    }
                    case DIGIT0, NUMPAD0 -> {
                        EditorViewSettings.resetZoom();
                        event.consume();
                    }
                    default -> {
                        // not a view shortcut
                    }
                }
            }
        });

        ide.scene.addEventHandler(KeyEvent.KEY_PRESSED, event -> {
            if (event.getCode() == KeyCode.ESCAPE && LayoutRibbon.isOpen()
                    && !FullScreenToggle.isFullScreen()) {
                LayoutRibbon.close();
                event.consume();
            }
        });
    }
}
