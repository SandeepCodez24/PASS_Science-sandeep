package ui.explorer.shortcut;

import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import ui.UI_Main;
import ui.editor.EditorViewSettings;
import ui.editor.search.EditorSearch;
import ui.layout.FullScreenToggle;
import ui.managers.EditorManager;
import ui.ribbon_interface.tool_bar.LayoutRibbon;
import ui.ui_functions.tools.ToolbarState;

/**
 * Installs application-level keyboard shortcuts for the main window.
 *
 * <h3>Search (the editor's find / replace bar)</h3>
 * <ul>
 * <li><b>Ctrl + F</b> -- open the bar (a one-line selection becomes the search
 * text). With no file open it searches the root folder.</li>
 * <li><b>Ctrl + H</b> -- open the bar with its Replace row unfolded.</li>
 * <li><b>F3 / Shift + F3</b> -- next / previous match.</li>
 * <li>Enter, Shift+Enter, Esc and Alt+M / W / R / F are handled by the bar
 * itself while it has the keyboard.</li>
 * </ul>
 *
 * <h3>View shortcuts (Settings &gt; Layout)</h3>
 * <ul>
 * <li><b>F11</b> -- Full Screen on / off. Esc also leaves full screen; that is
 * JavaFX's own behaviour and needs nothing here.</li>
 * <li><b>Ctrl + = / Ctrl + +</b> -- zoom the editor in.</li>
 * <li><b>Ctrl + -</b> -- zoom the editor out.</li>
 * <li><b>Ctrl + 0</b> -- reset the editor zoom.</li>
 * <li><b>Esc</b> -- close the Layout band, returning to the Settings band.
 * Installed as a handler, not a filter, so the suggestion popup and any other
 * control that uses Esc for itself consumes it first and the band stays
 * put.</li>
 * </ul>
 */
public final class MainWindowShortcutHandler {
    private MainWindowShortcutHandler() {
    }

    public static void install(UI_Main ide) {
        ide.scene.addEventFilter(KeyEvent.KEY_PRESSED, event -> {
            if (event.isAltDown() && event.getCode() == KeyCode.SPACE) {
                if (ToolbarState.searchField != null) {
                    ToolbarState.searchField.requestFocus();
                }
                event.consume();
                return;
            }

            if (event.isControlDown() && !event.isAltDown() && !event.isShiftDown()
                    && (event.getCode() == KeyCode.F || event.getCode() == KeyCode.H)) {
                EditorSearch.open(event.getCode() == KeyCode.H);
                event.consume();
                return;
            }

            if (event.getCode() == KeyCode.F3 && !event.isControlDown() && !event.isAltDown()) {
                if (event.isShiftDown()) {
                    EditorSearch.findPrevious();
                } else {
                    EditorSearch.findNext();
                }
                event.consume();
                return;
            }

            if (event.isControlDown()
                    && !event.isShiftDown()
                    && event.getCode() == KeyCode.S) {
                EditorManager.saveCurrentFile(ide);
                event.consume();
                return;
            }

            if (event.isControlDown()
                    && event.isShiftDown()
                    && event.getCode() == KeyCode.S) {
                EditorManager.saveAsFile(ide);
                event.consume();
                return;
            }

            if (event.isControlDown() && event.getCode() == KeyCode.N) {
                EditorManager.newNeuralCodeFile(ide);
                event.consume();
                return;
            }

            if (event.isControlDown() && event.getCode() == KeyCode.O) {
                EditorManager.openFile(ide);
                event.consume();
                return;
            }

            if (event.getCode() == KeyCode.F5) {
                EditorManager.runCurrentFile(ide);
                event.consume();
                return;
            }

            if (event.getCode() == KeyCode.F6) {
                ide.stopProgram();
                event.consume();
                return;
            }

            if (event.getCode() == KeyCode.F11) {
                FullScreenToggle.toggle();
                event.consume();
                return;
            }

            if (event.isControlDown() && !event.isAltDown()) {
                switch (event.getCode()) {
                    case EQUALS, PLUS, ADD -> {
                        EditorViewSettings.zoomIn();
                        event.consume();
                    }
                    case MINUS, SUBTRACT -> {
                        EditorViewSettings.zoomOut();
                        event.consume();
                    }
                    case DIGIT0, NUMPAD0 -> {
                        EditorViewSettings.resetZoom();
                        event.consume();
                    }
                    default -> {
                        // not a view shortcut
                    }
                }
            }
        });

        ide.scene.addEventHandler(KeyEvent.KEY_PRESSED, event -> {
            if (event.getCode() == KeyCode.ESCAPE && LayoutRibbon.isOpen()
                    && !FullScreenToggle.isFullScreen()) {
                LayoutRibbon.close();
                event.consume();
            }
        });
    }
}
