package ui.explorer;

import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.SplitPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import ui.design.Dim;
/**
 * A side panel that collapses to a narrow vertical rail, MATLAB-style.
 *
 * <p>
 * Expanded, it is a title strip above the body. Collapsed, both are replaced by
 * a {@value #RAIL_WIDTH}px rail carrying an expand triangle and the title
 * rotated on its side, and the panel's width is pinned so the SplitPane divider
 * cannot be dragged open by accident. The divider positions are captured before
 * collapsing and restored on expand, so the panel returns to the width the user
 * left it at.
 * </p>
 */
public final class CollapsiblePanel extends VBox {

    /** Width of the collapsed rail. */
    public static final double RAIL_WIDTH = Dim.Explorer.RAIL_WIDTH;

    private final String title;
    private final Node body;
    private final PanelTitleBar header;

    private VBox rail;
    private TitleBarIcon railIcon;

    private boolean collapsed = false;
    private SplitPane split;
    private double[] savedDividers;
    private double expandedMinWidth = Dim.Explorer.PANEL_MIN_WIDTH;
    private double expandedPrefWidth = Dim.Explorer.PANEL_PREF_WIDTH;

    /**
     * @param title panel name, shown in the strip and on the rail
     * @param body  the panel content (TreeView, TableView, ...)
     */
    public CollapsiblePanel(String title, Node body) {
        this.title = title;
        this.body = body;

        getStyleClass().add("titled-panel");
        setFillWidth(true);

        header = PanelTitleBar.withToggle(title, this::toggle);

        getChildren().setAll(header.getNode(), body);
        VBox.setVgrow(body, Priority.ALWAYS);
    }

    /**
     * Tells the panel which SplitPane it belongs to, so divider positions can be
     * saved and restored across a collapse.
     *
     * @param split the owning SplitPane
     */
    public void attachTo(SplitPane split) {
        this.split = split;
    }

    /**
     * @return the title strip, for registration with {@link PanelActivation}
     */
    public PanelTitleBar getHeader() {
        return header;
    }

    /**
     * @return true if the panel is currently a rail
     */
    public boolean isCollapsed() {
        return collapsed;
    }

    /**
     * Flips between rail and full panel.
     */
    public void toggle() {
        setCollapsed(!collapsed);
    }

    /**
     * @param collapse true to shrink to the rail, false to restore
     */
    public void setCollapsed(boolean collapse) {
        if (collapse == collapsed) {
            return;
        }
        collapsed = collapse;

        if (collapse) {
            // Remember how wide the user had it, and where every divider sat.
            if (getMinWidth() > 0) {
                expandedMinWidth = getMinWidth();
            }
            double current = getWidth() > 0 ? getWidth() : getPrefWidth();
            if (current > RAIL_WIDTH) {
                expandedPrefWidth = current;
            }
            if (split != null) {
                savedDividers = split.getDividerPositions();
            }

            getChildren().setAll(buildRail());
            setMinWidth(RAIL_WIDTH);
            setPrefWidth(RAIL_WIDTH);
            setMaxWidth(RAIL_WIDTH);
        } else {
            getChildren().setAll(header.getNode(), body);
            VBox.setVgrow(body, Priority.ALWAYS);

            setMinWidth(expandedMinWidth);
            setPrefWidth(expandedPrefWidth);
            setMaxWidth(Double.MAX_VALUE);

            // Applied next pulse: the width pin above has to be released before
            // the SplitPane will honour the old divider positions.
            if (split != null && savedDividers != null) {
                final double[] restore = savedDividers;
                Platform.runLater(() -> split.setDividerPositions(restore));
            }
        }

        header.setExpandedState(!collapse);
        if (railIcon != null) {
            railIcon.setBase(collapse ? TitleBarIcon.CARET_RIGHT : TitleBarIcon.CARET_DOWN);
        }
    }

    /**
     * Builds the rail once and reuses it, so its icon stays registered with the
     * header for active-state and theme repaints.
     *
     * @return the collapsed rail
     */
    private VBox buildRail() {
        if (rail != null) {
            return rail;
        }

        railIcon = new TitleBarIcon(TitleBarIcon.CARET_RIGHT, Dim.TitleBar.CARET_ICON_SIZE);
        Button expand = PanelTitleBar.glyphButton(railIcon, "Expand " + title);
        expand.setOnAction(e -> setCollapsed(false));

        Label vertical = new Label(title);
        vertical.getStyleClass().add("panel-rail-label");
        // Rotation does not affect layout bounds, so the Label goes inside a
        // Group, which reports the rotated bounds and lets the StackPane centre
        // it correctly in the narrow rail.
        vertical.setRotate(-90);
        StackPane holder = new StackPane(new Group(vertical));

        rail = new VBox(expand, holder);
        rail.setAlignment(Pos.TOP_CENTER);
        rail.getStyleClass().addAll("panel-title-bar", "panel-rail");
        VBox.setVgrow(holder, Priority.ALWAYS);

        // Keep the rail navy/grey in step with the strip it replaces.
        header.addCompanion(rail, railIcon);
        return rail;
    }
}
