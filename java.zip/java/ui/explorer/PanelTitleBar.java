package ui.explorer;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

import javafx.geometry.Bounds;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import ui.design.Dim;

/**
 * The title strip along the top edge of a panel (File Explorer, Variable
 * Explorer, Command Window, Signal Explorer).
 *
 * <p>
 * A strip can carry a leading collapse triangle, a trailing options button, a
 * trailing close mark ({@link #withClose}), or none of them. Its colour is
 * driven by the active state: the selected panel gets the navy strip, every
 * other panel grey. Both palettes live in the theme CSS via
 * {@code .panel-active} and {@code .panel-inactive}.
 * </p>
 *
 * <h3>Static layouts</h3>
 * <p>
 * Outside the Default layout nothing minimises or closes:
 * {@link #setToggleEnabled} and {@link #setCloseEnabled} fade the triangle
 * and the close mark and switch them off.
 * </p>
 */
public final class PanelTitleBar {

    /**
     * Height of the strip. Matches the collapsed height of a panel. An alias
     * for {@link Dim.TitleBar#HEIGHT} -- change the value there, not here.
     */
    public static final double HEIGHT = Dim.TitleBar.HEIGHT;

    /** The close mark: the same glyph the Code Bot's strip uses. */
    private static final String CLOSE_GLYPH = "\u2715";

    /** Opacity of the close mark at rest; 1 under the pointer. */
    private static final double CLOSE_REST_OPACITY = 0.8;

    private final String title;
    private final HBox bar = new HBox();
    private final Label titleLabel;

    private TitleBarIcon toggleIcon;
    private Button toggleButton;
    private Label closeMark;
    private boolean closeEnabled = true;
    private final List<TitleBarIcon> icons = new ArrayList<>();

    /**
     * Extra nodes that must follow this strip's active state, e.g. the vertical
     * rail a collapsed panel shows instead of the strip.
     */
    private final List<Node> companions = new ArrayList<>();

    private boolean active = false;

    private PanelTitleBar(String title) {
        this.title = title;

        titleLabel = new Label(title);
        titleLabel.getStyleClass().add("panel-title-label");

        bar.getStyleClass().add("panel-title-bar");
        bar.setAlignment(Pos.CENTER_LEFT);
        bar.setMinHeight(Dim.TitleBar.HEIGHT);
        bar.setPrefHeight(Dim.TitleBar.HEIGHT);
        bar.setMaxHeight(Dim.TitleBar.HEIGHT);
        bar.setMaxWidth(Double.MAX_VALUE);

        applyStateClasses(bar, false);
    }

    /**
     * A plain strip: title only.
     *
     * @param title text shown at the left
     * @return the strip
     */
    public static PanelTitleBar create(String title) {
        PanelTitleBar h = new PanelTitleBar(title);
        h.bar.getChildren().addAll(h.titleLabel, spacer());
        return h;
    }

    /**
     * A strip with a MATLAB-style collapse triangle immediately before the
     * title: pointing down when expanded, right when collapsed.
     *
     * @param title    text shown after the triangle
     * @param onToggle run when the triangle is clicked
     * @return the strip
     */
    public static PanelTitleBar withToggle(String title, Runnable onToggle) {
        PanelTitleBar h = new PanelTitleBar(title);
        h.toggleIcon = new TitleBarIcon(TitleBarIcon.CARET_DOWN, Dim.TitleBar.CARET_ICON_SIZE);
        h.icons.add(h.toggleIcon);

        Button t = glyphButton(h.toggleIcon, "Collapse / expand " + title);
        t.setOnAction(e -> onToggle.run());
        h.toggleButton = t;

        h.bar.getChildren().addAll(t, h.titleLabel, spacer());
        return h;
    }

    /**
     * Adds a three-dot options button at the right end of the strip.
     *
     * @param menuSupplier builds the menu fresh on each click
     * @return this strip, for chaining
     */
    public PanelTitleBar withMenu(Supplier<ContextMenu> menuSupplier) {
        TitleBarIcon dotsIcon = new TitleBarIcon(TitleBarIcon.DOTS, Dim.TitleBar.DOTS_ICON_SIZE);
        icons.add(dotsIcon);

        Button m = glyphButton(dotsIcon, title + " options");
        m.setOnAction(e -> {
            ContextMenu menu = menuSupplier.get();
            Bounds b = m.localToScreen(m.getBoundsInLocal());
            if (b != null) {
                menu.show(m, b.getMinX(), b.getMaxY());
            } else {
                menu.show(m, javafx.geometry.Side.BOTTOM, 0, 0);
            }
        });

        bar.getChildren().add(m);
        setActive(active);
        return this;
    }

    /**
     * Adds a close mark ({@code \u2715}) at the right end of the strip, as on
     * the Code Bot. It takes the title's font and colour, and brightens under
     * the pointer.
     *
     * @param onClose run when the mark is clicked
     * @return this strip, for chaining
     */
    public PanelTitleBar withClose(Runnable onClose) {
        Label close = new Label(CLOSE_GLYPH);
        close.getStyleClass().addAll("panel-title-label", "panel-title-close");
        close.setPadding(new Insets(0, Dim.TitleBar.GLYPH_BUTTON_PADDING,
                0, Dim.TitleBar.GLYPH_BUTTON_PADDING));
        close.setCursor(Cursor.HAND);
        close.setFocusTraversable(false);
        close.setOpacity(CLOSE_REST_OPACITY);
        close.setOnMouseEntered(e -> {
            if (closeEnabled) {
                close.setOpacity(1.0);
            }
        });
        close.setOnMouseExited(e -> {
            if (closeEnabled) {
                close.setOpacity(CLOSE_REST_OPACITY);
            }
        });
        Tooltip.install(close, new Tooltip("Close " + title));
        close.setOnMouseClicked(e -> {
            if (closeEnabled && e.getButton() == MouseButton.PRIMARY && onClose != null) {
                e.consume();
                onClose.run();
            }
        });
        closeMark = close;
        bar.getChildren().add(close);
        applyCloseState();
        return this;
    }

    /**
     * Fades and switches off the close mark (static layouts), or brings it
     * back. No-op on strips built without one.
     *
     * @param enabled true to allow closing
     */
    public void setCloseEnabled(boolean enabled) {
        closeEnabled = enabled;
        applyCloseState();
    }

    private void applyCloseState() {
        if (closeMark == null) {
            return;
        }
        // Disabled: Modena fades it, and it gets no mouse events.
        closeMark.setDisable(!closeEnabled);
        closeMark.setOpacity(closeEnabled ? CLOSE_REST_OPACITY : 1.0);
        closeMark.setCursor(closeEnabled ? Cursor.HAND : Cursor.DEFAULT);
    }

    /** @return the strip node */
    public HBox getNode() {
        return bar;
    }

    /** @return the panel title */
    public String getTitle() {
        return title;
    }

    /**
     * Registers a node that should share this strip's active colouring.
     *
     * @param node a node carrying the {@code .panel-title-bar} class
     * @param icon an icon on that node, or null
     */
    public void addCompanion(Node node, TitleBarIcon icon) {
        if (node != null) {
            companions.add(node);
            applyStateClasses(node, active);
        }
        if (icon != null) {
            icons.add(icon);
            icon.setActive(active);
        }
    }

    /**
     * Navy when active, grey when not.
     *
     * @param active true if this panel is the selected one
     */
    public void setActive(boolean active) {
        this.active = active;
        applyStateClasses(bar, active);
        for (Node n : companions) {
            applyStateClasses(n, active);
        }
        for (TitleBarIcon icon : icons) {
            icon.setActive(active);
        }
    }

    /** @return true if this panel is the selected one */
    public boolean isActive() {
        return active;
    }

    /**
     * Points the collapse triangle down (expanded) or right (collapsed).
     *
     * @param expanded true for the down-pointing triangle
     */
    public void setExpandedState(boolean expanded) {
        if (toggleIcon != null) {
            toggleIcon.setBase(expanded ? TitleBarIcon.CARET_DOWN : TitleBarIcon.CARET_RIGHT);
        }
    }

    /**
     * Enables or disables the collapse triangle (faded while disabled).
     * No-op on strips built without a triangle.
     *
     * @param enabled true to allow collapsing
     */
    public void setToggleEnabled(boolean enabled) {
        if (toggleButton == null) {
            return;
        }
        toggleButton.setDisable(!enabled);
        toggleButton.setTooltip(new Tooltip(enabled
                ? "Collapse / expand " + title
                : title + " cannot collapse in this layout"));
    }

    /**
     * A flat, transparent button sized for a title-strip glyph.
     *
     * @param icon the glyph
     * @param tip  tooltip text
     * @return the button
     */
    public static Button glyphButton(TitleBarIcon icon, String tip) {
        double box = Dim.TitleBar.GLYPH_BUTTON_SIZE;
        Button b = new Button("", icon.getView());
        b.getStyleClass().add("panel-title-button");
        b.setFocusTraversable(false);
        b.setMinSize(box, box);
        b.setPrefSize(box, box);
        b.setMaxSize(box, box);
        b.setTooltip(new Tooltip(tip));
        return b;
    }

    private static void applyStateClasses(Node node, boolean active) {
        node.getStyleClass().removeAll("panel-active", "panel-inactive");
        node.getStyleClass().add(active ? "panel-active" : "panel-inactive");
    }

    private static Region spacer() {
        Region r = new Region();
        HBox.setHgrow(r, Priority.ALWAYS);
        return r;
    }
}
