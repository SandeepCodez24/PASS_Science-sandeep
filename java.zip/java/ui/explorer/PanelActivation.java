package ui.explorer;

import java.util.EnumMap;
import java.util.Map;

import javafx.scene.Node;
import javafx.scene.input.MouseEvent;

/**
 * Tracks which region of the window the user last clicked in, and gives that
 * region's title strip the navy treatment while every other strip stays grey.
 *
 * <p>
 * The editor is registered as a region even though it has no strip: a click
 * in the editor deselects every panel, which is what stops the navy highlight
 * from lying about where the focus is.
 * </p>
 *
 * <h3>Nested regions</h3>
 * <p>
 * The Code Bot sits inside the File Explorer panel but is a region of its
 * own: clicking the bot makes its strip navy and the explorer's grey, and
 * clicking the tree does the reverse. This works because the activation
 * filters run from the outside in -- the explorer's filter fires first, then
 * the bot's, and the innermost region clicked is the one left active.
 * </p>
 */
public final class PanelActivation {

    /** The regions that compete for the active highlight. */
    public enum Panel {
        FILE_EXPLORER,
        VARIABLE_EXPLORER,
        COMMAND_WINDOW,
        EDITOR,
        /** The Code Bot panel at the bottom of the File Explorer. */
        CODE_BOT
    }

    private static final Map<Panel, PanelTitleBar> HEADERS = new EnumMap<>(Panel.class);

    private static Panel active = null;

    private PanelActivation() {
    }

    /**
     * Registers a region.
     *
     * <p>
     * A MOUSE_PRESSED filter is used rather than a handler so the click still
     * reaches the tree, table or text area underneath -- selecting a file and
     * activating its panel are the same gesture.
     * </p>
     *
     * @param panel  which region this is
     * @param header its title strip, or null for the editor
     * @param region the node whose clicks activate the region
     */
    public static void register(Panel panel, PanelTitleBar header, Node region) {
        if (header != null) {
            HEADERS.put(panel, header);
        }
        if (region != null) {
            region.addEventFilter(MouseEvent.MOUSE_PRESSED, e -> setActive(panel));
        }
    }

    /**
     * @param panel the region to highlight; every other strip goes grey
     */
    public static void setActive(Panel panel) {
        if (panel == active) {
            return;
        }
        active = panel;
        for (Map.Entry<Panel, PanelTitleBar> entry : HEADERS.entrySet()) {
            entry.getValue().setActive(entry.getKey() == panel);
        }
    }

    /**
     * @return the currently highlighted region, or null if none
     */
    public static Panel getActive() {
        return active;
    }

    /**
     * Repaints every registered glyph for the given theme.
     *
     * @param dark true for the dark theme
     */
    public static void setDarkTheme(boolean dark) {
        TitleBarIcon.setDarkTheme(dark);
    }

    /**
     * Clears the registry. Only needed if the whole UI is rebuilt in one
     * session; the static maps would otherwise keep the old nodes alive.
     */
    public static void reset() {
        HEADERS.clear();
        active = null;
    }
}
