package ui.explorer;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 * A title-bar glyph that swaps between a light and a dark rendering.
 *
 * <p>
 * The same control sits on backgrounds of opposite brightness depending on two
 * independent conditions, so a single PNG can never be correct everywhere:
 * </p>
 *
 * <pre>
 *                     light theme        dark theme
 *   active   (navy)   white glyph        white glyph
 *   inactive (grey)   dark  glyph        white glyph
 * </pre>
 *
 * <p>
 * Every icon therefore ships as a pair under
 * {@code /icons/title_bar_icons/} -- {@code &lt;name&gt;_on_dark.png} and
 * {@code &lt;name&gt;_on_light.png} -- and this class picks the right one from
 * {@code active || darkTheme}, re-evaluating whenever either changes.
 * </p>
 */
public final class TitleBarIcon {

    // ---- glyph names (the shared prefix of each _on_dark / _on_light pair) --
    public static final String CARET_DOWN = "ic_tb_01_caret_down";
    public static final String CARET_RIGHT = "ic_tb_02_caret_right";
    public static final String DOTS = "ic_tb_03_dots";
    public static final String CONSOLE_HIDE = "ic_tb_04_console_hide";
    public static final String CONSOLE_SHOW = "ic_tb_05_console_show";
    public static final String RIBBON_COLLAPSE = "ic_tb_06_ribbon_collapse";
    public static final String RIBBON_EXPAND = "ic_tb_07_ribbon_expand";

    private static final String DIR = "/icons/title_bar_icons/";

    /** Every live icon, so a theme switch can repaint them all at once. */
    private static final List<TitleBarIcon> REGISTRY = new ArrayList<>();

    private static boolean darkTheme = false;

    private final ImageView view = new ImageView();
    private final double size;
    private String base;
    private boolean active = false;

    /**
     * @param base glyph name, e.g. {@link #CARET_DOWN}
     * @param size rendered edge length in pixels
     */
    public TitleBarIcon(String base, double size) {
        this.base = base;
        this.size = size;
        view.setFitWidth(size);
        view.setFitHeight(size);
        view.setPreserveRatio(true);
        view.setSmooth(true);
        REGISTRY.add(this);
        apply();
    }

    /**
     * @return the node to place inside a button
     */
    public ImageView getView() {
        return view;
    }

    /**
     * Swaps which glyph is drawn, e.g. caret-down to caret-right on collapse.
     *
     * @param base the new glyph name
     */
    public void setBase(String base) {
        if (base != null && !base.equals(this.base)) {
            this.base = base;
            apply();
        }
    }

    /**
     * @param active true when the owning panel is selected, i.e. when the glyph
     *               sits on the navy strip
     */
    public void setActive(boolean active) {
        if (this.active != active) {
            this.active = active;
            apply();
        }
    }

    /**
     * Tells every live icon which theme is showing. Call after the theme
     * stylesheet changes.
     *
     * @param dark true for the dark theme
     */
    public static void setDarkTheme(boolean dark) {
        if (darkTheme == dark) {
            return;
        }
        darkTheme = dark;
        for (TitleBarIcon icon : REGISTRY) {
            icon.apply();
        }
    }

    /**
     * @return true if the dark theme is currently active
     */
    public static boolean isDarkTheme() {
        return darkTheme;
    }

    private void apply() {
        boolean onDark = active || darkTheme;
        view.setImage(load(DIR + base + (onDark ? "_on_dark.png" : "_on_light.png")));
    }

    private static Image load(String path) {
        InputStream in = TitleBarIcon.class.getResourceAsStream(path);
        if (in == null) {
            System.err.println("Missing title-bar icon: " + path);
            return null;
        }
        return new Image(in);
    }
}
