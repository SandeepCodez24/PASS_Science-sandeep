package ui.explorer.footer;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;

import ui.UI_Main;
import ui.design.Dim;
import ui.managers.ThemeManager;

/**
 * Builds the main-window status/footer bar.
 *
 * <h3>Where the numbers and colours went</h3>
 * <p>
 * This class used to carry its own geometry (padding, spacing, toggle size,
 * button font size) and its own colours as inline {@code setStyle} strings.
 * Both have moved out:
 * </p>
 * <ul>
 * <li>Geometry and font sizes now come from {@code ui.design.Dim} and
 * {@code ui.design.Typography}, emitted as CSS by
 * {@code ui.design.DesignStylesheet} under {@code .app-footer},
 * {@code .app-footer-label}, {@code .app-footer-button} and
 * {@code .footer-theme-toggle}.</li>
 * <li>Colours now live in {@code themes/light.css} and {@code themes/dark.css}
 * against those same style classes, which is also why the hover handlers are
 * gone -- {@code :hover} does that job now, and it does it for the selected
 * state too, which the old inline styling silently masked.</li>
 * </ul>
 * <p>
 * The one dimension still read from Java is {@link Dim.Footer#TOGGLE_GLYPH},
 * because it is applied to an {@link ImageView}'s fit size rather than to a
 * CSS-styleable property.
 * </p>
 *
 * <h3>The toggle is square now</h3>
 * <p>
 * It used to be a 24px circle, which made it the tallest child of the footer's
 * {@code HBox} and therefore the thing deciding the row height -- leaving the
 * error and warning buttons, at roughly 17px, floating above the optical
 * centre line. The toggle is now pinned to {@link Dim.Footer#TOGGLE_SIZE},
 * which is an alias of the shared {@code INDICATOR_SIZE} that the two count
 * buttons are also pinned to, and the footer is aligned {@code CENTER_LEFT}.
 * All three indicators are the same height, so none of them can push the
 * others off centre.
 * </p>
 */
public final class FooterBuilder {

    /** Style class carrying the footer's own colours and geometry. */
    private static final String STYLE_FOOTER = "app-footer";

    /** Style class for the status labels. */
    private static final String STYLE_LABEL = "app-footer-label";

    /** Style class for the error and warning count buttons. */
    private static final String STYLE_BUTTON = "app-footer-button";

    /** Style class for the square light/dark toggle. */
    private static final String STYLE_TOGGLE = "footer-theme-toggle";

    private FooterBuilder() {
    }

    /**
     * Builds the footer strip.
     *
     * @param ide the IDE controller; its footer fields are assigned here
     * @return the footer node
     */
    public static HBox build(UI_Main ide) {
        ide.footerFileLabel = footerLabel("");
        ide.footerCursorLabel = footerLabel(" Ln 1, Col 1 ");
        ide.footerEncodingLabel = footerLabel(" UTF-8 ");
        ide.footerStatusLabel = footerLabel(" Ready ");

        ide.footerErrorButton = footerButton("\u2716 0");
        ide.footerWarningButton = footerButton("\u26A0 0");

        ide.themeToggle = new ToggleButton();
        ide.themeToggle.getStyleClass().add(STYLE_TOGGLE);
        ide.themeToggle.setFocusTraversable(false);

        // Keep a single ImageView on the toggle and repaint its image whenever the
        // theme changes so light and dark each show their own glyph.
        ide.themeIconView = new ImageView();
        ide.themeToggle.setGraphic(ide.themeIconView);
        updateThemeIcon(ide);

        ide.themeToggle.setOnAction(event -> {
            ThemeManager.toggleTheme(ide);
            updateThemeIcon(ide);
        });

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        HBox footer = new HBox(
                ide.footerFileLabel,
                spacer,
                ide.footerErrorButton,
                ide.footerWarningButton,
                ide.footerCursorLabel,
                ide.footerEncodingLabel,
                ide.footerStatusLabel,
                ide.themeToggle);
        footer.getStyleClass().add(STYLE_FOOTER);
        return footer;
    }

    /**
     * Repaints the theme-toggle glyph to match the active theme: the sun icon in
     * dark mode and the moon icon in light mode. Safe to call at any time.
     *
     * @param ide the IDE controller
     */
    public static void updateThemeIcon(UI_Main ide) {
        if (ide == null || ide.themeToggle == null) {
            return;
        }
        if (ide.themeIconView == null) {
            ide.themeIconView = new ImageView();
            ide.themeToggle.setGraphic(ide.themeIconView);
        }
        boolean dark = "dark".equals(ide.currentTheme);
        Image icon = dark ? ide.sunIcon : ide.moonIcon;
        ide.themeIconView.setImage(icon);
        applyIconScale(ide.themeIconView, icon);
    }

    /**
     * Fits the glyph into a {@link Dim.Footer#TOGGLE_GLYPH} box.
     *
     * <h4>Why this is no longer a ratio</h4>
     * <p>
     * It used to scale the icon to a fraction of its own native resolution,
     * which meant the rendered size depended on how large the PNG on disk
     * happened to be: swap a 64px source for a 32px one and the toggle changed
     * shape. Worse, it made the whole thing dependent on the image having
     * finished decoding, because an {@code Image} that is still loading reports
     * a width and height of 0 -- and passing 0 to {@code setFitWidth} disables
     * fitting altogether, which is what made the toggle appear oversized until
     * it was clicked once. That is the bug the listener below existed to work
     * around.
     * </p>
     * <p>
     * An absolute fit size needs neither. The box is stated up front, the
     * source resolution is irrelevant, and {@code setPreserveRatio} keeps a
     * non-square glyph from distorting. Nothing has to wait for a decode, so
     * the listener is gone with it.
     * </p>
     *
     * @param view the image view on the toggle
     * @param icon the glyph being shown, possibly still decoding
     */
    private static void applyIconScale(ImageView view, Image icon) {
        if (icon == null) {
            view.setFitWidth(0);
            view.setFitHeight(0);
            return;
        }
        view.setPreserveRatio(true);
        view.setSmooth(true);
        view.setFitWidth(Dim.Footer.TOGGLE_GLYPH);
        view.setFitHeight(Dim.Footer.TOGGLE_GLYPH);
    }

    private static Label footerLabel(String text) {
        Label label = new Label(text);
        label.getStyleClass().add(STYLE_LABEL);
        return label;
    }

    private static Button footerButton(String text) {
        Button button = new Button(text);
        button.getStyleClass().add(STYLE_BUTTON);
        return button;
    }
}
