package ui.explorer.footer;

import javafx.beans.value.ChangeListener;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import ui.UI_Main;
import ui.managers.ThemeManager;

/** Builds the main-window status/footer bar. */
public final class FooterBuilder {
    private static final String FOOTER_TEXT_STYLE = "-fx-text-fill:white;";
    private static final String FOOTER_STYLE = "-fx-background-color:#004073;";
    private static final String TOGGLE_BASE_STYLE =
            "-fx-background-color: #e0e0e0;"
                    + "-fx-background-radius: 50em;"
                    + "-fx-min-width: 24px;"
                    + "-fx-min-height: 24px;";
    private static final String TOGGLE_HOVER_STYLE =
            "-fx-background-color: #d0d0d0;"
                    + "-fx-background-radius: 50em;"
                    + "-fx-min-width: 24px;"
                    + "-fx-min-height: 24px;";

    /** Glyph is drawn at this fraction of the icon's native size. */
    private static final double ICON_SCALE = 0.65;

    private FooterBuilder() {
    }

    public static HBox build(UI_Main ide) {
        ide.footerFileLabel = footerLabel("");
        ide.footerCursorLabel = footerLabel(" Ln 1, Col 1 ");
        ide.footerEncodingLabel = footerLabel(" UTF-8 ");
        ide.footerStatusLabel = footerLabel(" Ready ");

        ide.footerErrorButton = footerButton("\u2716 0");
        ide.footerWarningButton = footerButton("\u26A0 0");

        ide.themeToggle = new ToggleButton();
        ide.themeToggle.setStyle(TOGGLE_BASE_STYLE);
        ide.themeToggle.setOnMouseEntered(event -> ide.themeToggle.setStyle(TOGGLE_HOVER_STYLE));
        ide.themeToggle.setOnMouseExited(event -> ide.themeToggle.setStyle(TOGGLE_BASE_STYLE));
        // Keep a single ImageView on the toggle and repaint its image whenever the
        // theme changes so light and dark each show their own glyph.
        ide.themeIconView = new ImageView();
        ide.themeToggle.setGraphic(ide.themeIconView);
        updateThemeIcon(ide);
        ide.themeToggle.setOnAction(event -> {
            ThemeManager.toggleTheme(ide);
            updateThemeIcon(ide);
        });

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        HBox footer = new HBox(
                9,
                ide.footerFileLabel,
                spacer,
                ide.footerErrorButton,
                ide.footerWarningButton,
                ide.footerCursorLabel,
                ide.footerEncodingLabel,
                ide.footerStatusLabel,
                ide.themeToggle);
        footer.setPadding(new Insets(3.75, 7.5, 3.75, 7.5));
        footer.setStyle(FOOTER_STYLE);
        return footer;
    }

    /**
     * Repaints the theme-toggle glyph to match the active theme: the sun icon in
     * dark mode and the moon icon in light mode. Safe to call at any time.
     */
    public static void updateThemeIcon(UI_Main ide) {
        if (ide == null || ide.themeToggle == null) {
            return;
        }
        if (ide.themeIconView == null) {
            ide.themeIconView = new ImageView();
            ide.themeToggle.setGraphic(ide.themeIconView);
        }
        boolean dark = "dark".equals(ide.currentTheme);
        Image icon = dark ? ide.sunIcon : ide.moonIcon;
        ide.themeIconView.setImage(icon);
        applyIconScale(ide.themeIconView, icon);
    }

    /**
     * Scales the glyph to {@link #ICON_SCALE} of its native size.
     *
     * <p>An {@code Image} that is still decoding reports a width and height of 0,
     * and passing 0 to {@code setFitWidth}/{@code setFitHeight} disables fitting
     * altogether, which makes the ImageView paint at full resolution. That is why
     * the toggle used to appear oversized until it was clicked once. When the
     * dimensions are not available yet we wait for them with a self-removing
     * listener and scale as soon as the image reports its real size.
     */
    private static void applyIconScale(ImageView view, Image icon) {
        if (icon == null) {
            view.setFitWidth(0);
            view.setFitHeight(0);
            return;
        }
        view.setPreserveRatio(true);

        double width = icon.getWidth();
        if (width > 0) {
            view.setFitWidth(width * ICON_SCALE);
            view.setFitHeight(icon.getHeight() * ICON_SCALE);
            return;
        }

        // Not decoded yet: scale once the real dimensions arrive.
        ChangeListener<Number> onceLoaded = new ChangeListener<>() {
            @Override
            public void changed(
                    javafx.beans.value.ObservableValue<? extends Number> source,
                    Number oldWidth,
                    Number newWidth) {
                if (newWidth.doubleValue() > 0) {
                    icon.widthProperty().removeListener(this);
                    // Only scale if this icon is still the one on display.
                    if (view.getImage() == icon) {
                        view.setFitWidth(icon.getWidth() * ICON_SCALE);
                        view.setFitHeight(icon.getHeight() * ICON_SCALE);
                    }
                }
            }
        };
        icon.widthProperty().addListener(onceLoaded);
    }

    private static Label footerLabel(String text) {
        Label label = new Label(text);
        label.setStyle(FOOTER_TEXT_STYLE);
        return label;
    }

    private static Button footerButton(String text) {
        Button button = new Button(text);
        button.setStyle("-fx-padding: 3 6; -fx-font-size: 8.25;");
        return button;
    }
}
