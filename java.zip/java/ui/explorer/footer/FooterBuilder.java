package ui.explorer.footer;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import ui.UI_Main;
import ui.managers.ThemeManager;

/** Builds the main-window status/footer bar. */
public final class FooterBuilder {
    private static final String FOOTER_TEXT_STYLE = "-fx-text-fill:white;";
    private static final String FOOTER_STYLE = "-fx-background-color:#004073;";
    private static final String TOGGLE_BASE_STYLE =
            "-fx-background-color: #e0e0e0;"
                    + "-fx-background-radius: 50em;"
                    + "-fx-min-width: 32px;"
                    + "-fx-min-height: 32px;";
    private static final String TOGGLE_HOVER_STYLE =
            "-fx-background-color: #d0d0d0;"
                    + "-fx-background-radius: 50em;"
                    + "-fx-min-width: 32px;"
                    + "-fx-min-height: 32px;";

    private FooterBuilder() {
    }

    public static HBox build(UI_Main ide) {
        ide.footerFileLabel = footerLabel("");
        ide.footerCursorLabel = footerLabel(" Ln 1, Col 1 ");
        ide.footerEncodingLabel = footerLabel(" UTF-8 ");
        ide.footerStatusLabel = footerLabel(" Ready ");

        ide.footerErrorButton = footerButton("\u2716 0");
        ide.footerWarningButton = footerButton("\u26A0 0");

        ide.themeToggle = new ToggleButton();
        ide.themeToggle.setStyle(TOGGLE_BASE_STYLE);
        ide.themeToggle.setOnMouseEntered(event -> ide.themeToggle.setStyle(TOGGLE_HOVER_STYLE));
        ide.themeToggle.setOnMouseExited(event -> ide.themeToggle.setStyle(TOGGLE_BASE_STYLE));
        if (ide.moonIcon != null) {
            ide.themeToggle.setGraphic(new ImageView(ide.moonIcon));
        }
        ide.themeToggle.setOnAction(event -> ThemeManager.toggleTheme(ide));

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        HBox footer = new HBox(
                12,
                ide.footerFileLabel,
                spacer,
                ide.footerErrorButton,
                ide.footerWarningButton,
                ide.footerCursorLabel,
                ide.footerEncodingLabel,
                ide.footerStatusLabel,
                ide.themeToggle);
        footer.setPadding(new Insets(5, 10, 5, 10));
        footer.setStyle(FOOTER_STYLE);
        return footer;
    }

    private static Label footerLabel(String text) {
        Label label = new Label(text);
        label.setStyle(FOOTER_TEXT_STYLE);
        return label;
    }

    private static Button footerButton(String text) {
        Button button = new Button(text);
        button.setStyle("-fx-padding: 4 8; -fx-font-size: 11;");
        return button;
    }
}
