package ui.explorer.navigation;

import java.util.function.Supplier;

import javafx.geometry.Bounds;
import javafx.geometry.Side;
import javafx.scene.Node;
import javafx.scene.control.ContextMenu;
import javafx.stage.WindowEvent;
import ui.ui_functions.tools.ToolbarState;

/**
 * Opens a drop-down under a control, or closes it if that control's drop-down
 * is already open.
 *
 * <p>
 * Moved out of {@code ToolbarNavigation} unchanged in behaviour, so the
 * breadcrumb chevrons, the folder button and the Root / Cloud drop-downs all
 * share it.
 * </p>
 *
 * <h3>The re-open guard</h3>
 * <p>
 * A ContextMenu auto-hides on any mouse press outside itself, and the control
 * that owns it is outside itself. A second click on the same control therefore
 * fires the auto-hide and then the control's action; without
 * {@link #REOPEN_GUARD_MS} the action would re-open the menu the same click
 * just closed.
 * </p>
 *
 * <p>
 * Only one of these menus is open at a time across the whole row; opening one
 * closes any other ({@link ToolbarState#activeNavMenu}).
 * </p>
 */
public final class PopupMenuToggle {

    /** How long after a menu closes a click on its own control is ignored. */
    public static final long REOPEN_GUARD_MS = 250;

    private static final String KEY = "astra.popupMenuToggle";

    private ContextMenu menu;
    private long closedAt;

    private PopupMenuToggle() {
    }

    /**
     * Toggles the drop-down of a control.
     *
     * @param owner   the control clicked; the menu hangs below it
     * @param factory builds the menu, called only when one is about to show
     * @param onOpen  optional, run once the menu is showing
     * @param onClose optional, run once the menu has hidden
     */
    public static void toggle(Node owner, Supplier<ContextMenu> factory, Runnable onOpen, Runnable onClose) {
        if (owner == null || factory == null) {
            return;
        }
        PopupMenuToggle state = stateOf(owner);

        if (state.menu != null && state.menu.isShowing()) {
            state.menu.hide();
            return;
        }
        if (System.currentTimeMillis() - state.closedAt < REOPEN_GUARD_MS) {
            return;
        }

        ContextMenu built = factory.get();
        if (built == null || built.getItems().isEmpty()) {
            return;
        }

        ContextMenu previous = ToolbarState.activeNavMenu;
        if (previous != null && previous != built && previous.isShowing()) {
            previous.hide();
        }

        built.setAutoHide(true);
        built.setHideOnEscape(true);
        built.setOnHidden((WindowEvent e) -> {
            state.menu = null;
            state.closedAt = System.currentTimeMillis();
            if (ToolbarState.activeNavMenu == built) {
                ToolbarState.activeNavMenu = null;
            }
            if (onClose != null) {
                onClose.run();
            }
        });

        state.menu = built;
        ToolbarState.activeNavMenu = built;

        if (onOpen != null) {
            onOpen.run();
        }

        owner.applyCss();
        Bounds onScreen = owner.localToScreen(owner.getBoundsInLocal());
        if (onScreen == null) {
            built.show(owner, Side.BOTTOM, 0, 0);
            return;
        }
        built.show(owner, onScreen.getMinX(), onScreen.getMaxY());
    }

    /**
     * Convenience form with no open / close callbacks.
     *
     * @param owner   the control clicked
     * @param factory builds the menu
     */
    public static void toggle(Node owner, Supplier<ContextMenu> factory) {
        toggle(owner, factory, null, null);
    }

    /**
     * @param owner a control
     * @return true if that control's drop-down is on screen
     */
    public static boolean isOpen(Node owner) {
        Object existing = owner.getProperties().get(KEY);
        return existing instanceof PopupMenuToggle found && found.menu != null && found.menu.isShowing();
    }

    private static PopupMenuToggle stateOf(Node owner) {
        Object existing = owner.getProperties().get(KEY);
        if (existing instanceof PopupMenuToggle found) {
            return found;
        }
        PopupMenuToggle created = new PopupMenuToggle();
        owner.getProperties().put(KEY, created);
        return created;
    }
}
