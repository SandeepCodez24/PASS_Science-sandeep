package ui.explorer.navigation;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.stream.Stream;

import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBase;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.TextInputControl;
import javafx.scene.control.Tooltip;
import javafx.scene.image.ImageView;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Rectangle;
import ui.UI_Main;
import ui.design.Dim;
import ui.editor.navigation.CloudFolders;
import ui.editor.navigation.DefaultFolders;
import ui.editor.navigation.FolderPaths;
import ui.editor.navigation.NavigationActions;
import ui.editor.navigation.RootFolderStore;
import ui.ui_functions.tools.ToolbarState;

/**
 * The right half of the quick-access row: the path box.
 *
 * <pre>
 *  ( |[folder]|v|  |D:|&gt;|  |My Research Works|&gt;|  |MARL|&gt;|      empty space      )
 *        |     |      |   |                          |                    |
 *        |     |      |   +-- chevron: subfolders    |                    +-- click: edit the path
 *        |     |      +------ name: go to D:         +-- current folder: click does nothing
 *        |     +------------- This PC menu: cloud, drives, shortcuts
 *        +------------------- folder glyph: edit the path
 * </pre>
 *
 * <h3>Split pairs</h3>
 * <p>
 * Each folder name and the chevron after it are one split control, MATLAB
 * style. On hover the pair draws three vertical lines, {@code |name|>|}, inside
 * one outline, and only the half under the pointer fills:
 * </p>
 * <ul>
 * <li><b>Name</b> -- makes that folder the active folder. The last name is the
 * folder already shown, so a click on it does nothing.</li>
 * <li><b>Chevron</b> -- drops that folder's subfolders; the chevron turns from
 * {@code >} to {@code v} while the menu is open, and a second click closes
 * it. The subfolder that lies on the current path is shown bold.</li>
 * </ul>
 * <p>
 * Every folder before the last always has a chevron, since it contains at
 * least the next folder in the path. The last folder gets one only if it has
 * subfolders. That check touches the disk, which can be slow on a network or
 * OneDrive folder, so it runs on a background thread and the chevron is added
 * when the answer arrives; an answer for a path that is no longer shown is
 * dropped.
 * </p>
 * <p>
 * The This PC control at the head of the path is the same kind of pair: the
 * folder glyph switches the box to editing (as Explorer's address-bar icon
 * does), the {@code v} zone drops the cloud / drive / shortcut menu, with the
 * current drive in bold.
 * </p>
 *
 * <h3>Two modes</h3>
 * <ul>
 * <li><b>Crumbs</b> (default), as above.</li>
 * <li><b>Editing.</b> A click on any part of the box that is <em>not</em> a
 * pair turns the crumbs into a text field holding the full path, already
 * selected -- Ctrl+C copies it, typing replaces it. Enter goes there; Esc or
 * clicking away puts the crumbs back. See {@link BreadcrumbPathEditor}.</li>
 * </ul>
 * <p>
 * A right-click anywhere in the box offers Copy Path and Edit Path; on a crumb
 * it also offers copying the path up to that crumb.
 * </p>
 *
 * <h3>Menus</h3>
 * <p>
 * Every menu this class opens carries {@link #MENU_CLASS}, which gives it the
 * directory explorer's font and item padding, and has mnemonic parsing turned
 * off so a folder such as {@code GW_MARL} keeps its underscore.
 * </p>
 *
 * <h3>Long paths</h3>
 * <p>
 * The crumbs never shrink or ellipsize. When they are wider than the box, the
 * row slides left so the deepest folder stays in view, and the start is clipped
 * -- the way Explorer's address bar behaves. The box itself asks for only a
 * small preferred width and grows to fill the row, so a long path can never
 * push the ToolBar into its overflow popup.
 * </p>
 */
public final class BreadcrumbBar {

    private static final String BOX_CLASS = "quick-path-box";
    private static final String SEGMENTS_CLASS = "quick-path-segments";
    private static final String EMPTY_CLASS = "quick-path-empty";

    /** One split control: the outline around the two zones. */
    private static final String PAIR_CLASS = "quick-path-pair";
    /** Left zone of a pair: a folder name, or the This PC glyph. */
    private static final String PAIR_NAME_CLASS = "quick-path-pair-name";
    /** Right zone of a pair: the chevron, with the divider as its left edge. */
    private static final String PAIR_ARROW_CLASS = "quick-path-pair-arrow";
    /** Marks the This PC pair, which pads its zones differently. */
    private static final String ROOTS_CLASS = "quick-path-roots";
    /** A pair that has a chevron; only these show the outline on hover. */
    private static final String HAS_ARROW_CLASS = "has-arrow";
    /** The name zone of the folder being shown: no fill, no action. */
    private static final String CURRENT_CLASS = "current";
    /** A pair whose menu is open: outline and chevron fill stay on. */
    private static final String MENU_SHOWING_CLASS = "menu-showing";

    /**
     * Style class of every drop-down in the quick-access row -- the breadcrumb
     * menus here and the Root / Cloud menus of {@link NavigationBar}. It gives
     * them the directory explorer's font and item padding.
     */
    public static final String MENU_CLASS = "quick-path-menu";
    /** A menu entry on the current path (a subfolder or the current drive). */
    private static final String MENU_CURRENT_CLASS = "quick-path-menu-current";

    /** Property key under which each pair and zone remembers its folder. */
    private static final String CRUMB_PATH_KEY = "astra.crumbPath";

    /** Property key marking a node whose clicks must not start editing. */
    private static final String CONTROL_KEY = "astra.crumbControl";

    /** Subfolders listed in one drop-down before it is cut off. */
    private static final int MENU_CHILD_LIMIT = 40;

    /** Runs the "does the last folder have subfolders?" checks off the FX thread. */
    private static final ExecutorService PROBE = Executors.newCachedThreadPool(task -> {
        Thread thread = new Thread(task, "astra-breadcrumb-probe");
        thread.setDaemon(true);
        return thread;
    });

    private static HBox box;
    private static StackPane pathArea;
    private static HBox crumbRow;
    private static HBox crumbs;
    private static BreadcrumbPathEditor editor;
    private static UI_Main owner;

    private static volatile Path shown;

    /** Bumped on every redraw; a probe answer for an older redraw is ignored. FX thread only. */
    private static int renderGeneration;

    private BreadcrumbBar() {
    }

    // =================================================================
    // Construction
    // =================================================================

    /**
     * Builds the path box and publishes it through {@link ToolbarState} so the
     * collapse toggle can find its place after it.
     *
     * @param ide the IDE controller
     * @return the path box, ready to add to the quick-access ToolBar
     */
    public static Region build(UI_Main ide) {
        owner = ide;

        HBox rootsControl = buildRootsControl();

        crumbs = new HBox();
        crumbs.getStyleClass().add(SEGMENTS_CLASS);
        crumbs.setAlignment(Pos.CENTER_LEFT);
        crumbs.setMinWidth(Region.USE_PREF_SIZE);
        crumbs.setMaxWidth(Region.USE_PREF_SIZE);

        // The empty space after the last pair. Transparent, but it must
        // still catch clicks, since that is where people click to edit.
        Region filler = new Region();
        filler.setMinWidth(0);
        filler.setPickOnBounds(true);
        HBox.setHgrow(filler, Priority.ALWAYS);

        crumbRow = new HBox(crumbs, filler);
        crumbRow.setAlignment(Pos.CENTER_LEFT);
        crumbRow.setPickOnBounds(true);

        editor = new BreadcrumbPathEditor(ide, BreadcrumbBar::endEdit);
        editor.node().setVisible(false);
        editor.node().setManaged(false);

        pathArea = new StackPane(crumbRow, editor.node());
        pathArea.setAlignment(Pos.CENTER_LEFT);
        pathArea.setPickOnBounds(true);
        pathArea.setMinWidth(0);
        pathArea.setPrefWidth(0);
        HBox.setHgrow(pathArea, Priority.ALWAYS);

        Rectangle clip = new Rectangle();
        clip.widthProperty().bind(pathArea.widthProperty());
        clip.heightProperty().bind(pathArea.heightProperty());
        pathArea.setClip(clip);

        // Keep the deepest folder in view when the path is too long to fit.
        pathArea.widthProperty().addListener((o, a, b) -> followTail());
        crumbs.widthProperty().addListener((o, a, b) -> followTail());

        box = new HBox(rootsControl, pathArea);
        box.getStyleClass().add(BOX_CLASS);
        box.setAlignment(Pos.CENTER_LEFT);
        box.setMinWidth(0);
        box.setPrefWidth(Dim.BreadcrumbBar.BOX_PREF_WIDTH);
        box.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(box, Priority.ALWAYS);

        box.setOnMouseClicked(e -> {
            if (e.getButton() == MouseButton.PRIMARY
                    && e.isStillSincePress()
                    && !editor.isActive()
                    && !hitsControl(e.getTarget())) {
                e.consume();
                beginEdit();
            }
        });
        box.setOnContextMenuRequested(e -> {
            if (editor.isActive()) {
                return;
            }
            e.consume();
            ContextMenu menu = buildCopyMenu(crumbPathOf(e.getTarget()));
            menu.show(box, e.getScreenX(), e.getScreenY());
        });

        ToolbarState.quickPathSegments = crumbs;
        ToolbarState.quickPathLabel = box;

        return box;
    }

    /**
     * The This PC pair: {@code |[folder]|v|}.
     */
    private static HBox buildRootsControl() {
        Button glyphZone = new Button("",
                NaviBreadIcons.icon(NaviBreadIcons.CRUMB_FOLDER, Dim.BreadcrumbBar.ROOT_ICON_SIZE));
        glyphZone.setFocusTraversable(false);
        glyphZone.getStyleClass().add(PAIR_NAME_CLASS);
        glyphZone.setTooltip(new Tooltip("Edit the path"));
        glyphZone.setOnAction(e -> beginEdit());

        ImageView chevron = NaviBreadIcons.icon(NaviBreadIcons.CHEVRON_DOWN, Dim.BreadcrumbBar.ROOTS_ARROW_SIZE);
        Button arrowZone = new Button("", chevron);
        arrowZone.setFocusTraversable(false);
        arrowZone.getStyleClass().add(PAIR_ARROW_CLASS);
        arrowZone.setTooltip(new Tooltip("This PC - drives and shortcuts"));

        HBox split = newPair();
        split.getStyleClass().addAll(ROOTS_CLASS, HAS_ARROW_CLASS);
        split.getChildren().addAll(glyphZone, arrowZone);

        arrowZone.setOnAction(e -> PopupMenuToggle.toggle(arrowZone,
                BreadcrumbBar::buildRootsMenu,
                () -> setMenuShowing(split, true),
                () -> setMenuShowing(split, false)));
        return split;
    }

    // =================================================================
    // Public API
    // =================================================================

    /**
     * Redraws the crumbs for a folder. Safe from any thread.
     *
     * @param path the folder now shown, or null for "no project"
     */
    public static void show(Path path) {
        if (crumbs == null) {
            return;
        }
        Path resolved = FolderPaths.canonical(path);
        Platform.runLater(() -> {
            shown = resolved;
            if (editor != null && editor.isActive()) {
                editor.cancel();
            }
            render();
            NavigationBar.refreshState();
        });
    }

    /**
     * Redraws the current crumbs, for example after a drive alias changes.
     */
    public static void refresh() {
        if (crumbs == null) {
            return;
        }
        Platform.runLater(BreadcrumbBar::render);
    }

    /**
     * @return the folder the crumbs are showing, or null
     */
    public static Path shown() {
        return shown;
    }

    /**
     * Switches the box to the editable text field with the whole path
     * selected. Also reachable from the This PC glyph and the right-click menu.
     */
    public static void beginEdit() {
        if (editor == null || editor.isActive()) {
            return;
        }
        crumbRow.setVisible(false);
        editor.node().setManaged(true);
        editor.node().setVisible(true);
        editor.begin(shown);
    }

    /**
     * Drops the This PC menu (cloud, drives and shortcuts) under a control.
     *
     * @param anchor the control the menu hangs from
     */
    public static void showRootsMenu(Node anchor) {
        PopupMenuToggle.toggle(anchor, BreadcrumbBar::buildRootsMenu);
    }

    // =================================================================
    // Rendering
    // =================================================================

    private static void render() {
        int generation = ++renderGeneration;
        crumbs.getChildren().clear();
        crumbRow.setTranslateX(0);

        Path target = shown;
        if (target == null) {
            Label empty = new Label(ToolbarState.NO_PROJECT_TEXT);
            empty.getStyleClass().add(EMPTY_CLASS);
            crumbs.getChildren().add(empty);
            return;
        }

        List<Path> chain = new ArrayList<>();
        for (Path cursor = target; cursor != null; cursor = cursor.getParent()) {
            chain.add(0, cursor);
        }

        int lastIndex = chain.size() - 1;
        for (int i = 0; i <= lastIndex; i++) {
            boolean last = i == lastIndex;
            CrumbPair pair = new CrumbPair(chain.get(i), last);
            if (!last) {
                // It contains at least the next folder of the path.
                pair.addArrow();
            }
            crumbs.getChildren().add(pair.node);
            if (last) {
                probeForArrow(pair, generation);
            }
        }

        Platform.runLater(BreadcrumbBar::followTail);
    }

    /**
     * Gives the last pair its chevron once a background check confirms the
     * folder has at least one subfolder.
     */
    private static void probeForArrow(CrumbPair pair, int generation) {
        Path folder = pair.folder;
        try {
            PROBE.execute(() -> {
                if (!hasSubfolder(folder)) {
                    return;
                }
                Platform.runLater(() -> {
                    if (generation == renderGeneration) {
                        pair.addArrow();
                    }
                });
            });
        } catch (RejectedExecutionException e) {
            // Shutting down; the chevron is not worth a stack trace.
        }
    }

    /**
     * Stops at the first subfolder, so a folder full of files is not read to
     * the end. Uses the same test as {@link #buildChildMenu}, so a chevron is
     * shown exactly when its menu would list something.
     */
    private static boolean hasSubfolder(Path folder) {
        if (folder == null) {
            return false;
        }
        try (DirectoryStream<Path> entries = Files.newDirectoryStream(folder)) {
            for (Path entry : entries) {
                if (Files.isDirectory(entry)) {
                    return true;
                }
            }
        } catch (IOException | RuntimeException e) {
            return false;
        }
        return false;
    }

    /**
     * Slides the crumb row left by however much it overflows, so the deepest
     * folder is always visible.
     */
    private static void followTail() {
        if (pathArea == null || crumbs == null || crumbRow == null) {
            return;
        }
        double overflow = crumbs.getWidth() - pathArea.getWidth();
        crumbRow.setTranslateX(overflow > 0 ? -overflow : 0);
    }

    // =================================================================
    // Split pairs
    // =================================================================

    /**
     * An empty pair outline. Marked as a control, so a click that lands on its
     * one-pixel outline rather than on a zone does not start editing.
     */
    private static HBox newPair() {
        HBox pair = new HBox();
        pair.getStyleClass().add(PAIR_CLASS);
        pair.setAlignment(Pos.CENTER_LEFT);
        pair.setMinWidth(Region.USE_PREF_SIZE);
        pair.setMaxWidth(Region.USE_PREF_SIZE);
        pair.getProperties().put(CONTROL_KEY, Boolean.TRUE);
        return pair;
    }

    private static void setMenuShowing(Node pair, boolean showing) {
        List<String> classes = pair.getStyleClass();
        if (showing) {
            if (!classes.contains(MENU_SHOWING_CLASS)) {
                classes.add(MENU_SHOWING_CLASS);
            }
        } else {
            classes.remove(MENU_SHOWING_CLASS);
        }
    }

    /**
     * One {@code |name|>|} split control for a folder of the path.
     */
    private static final class CrumbPair {

        private final Path folder;
        private final HBox node;
        private Button arrow;

        /**
         * @param folder  the folder this pair stands for
         * @param current true for the folder being shown, whose name does
         *                nothing when clicked
         */
        CrumbPair(Path folder, boolean current) {
            this.folder = folder;
            this.node = newPair();
            node.getProperties().put(CRUMB_PATH_KEY, folder);

            Button name = new Button(FolderPaths.label(folder));
            name.setMnemonicParsing(false);
            name.setFocusTraversable(false);
            name.setMinWidth(Region.USE_PREF_SIZE);
            name.getStyleClass().add(PAIR_NAME_CLASS);
            name.getProperties().put(CRUMB_PATH_KEY, folder);
            if (current) {
                // Already the active folder: deliberately no action.
                name.getStyleClass().add(CURRENT_CLASS);
            } else {
                name.setOnAction(e -> {
                    if (owner != null) {
                        NavigationActions.goTo(owner, folder);
                    }
                });
            }
            node.getChildren().add(name);
        }

        /**
         * Adds the chevron zone. Safe to call twice.
         */
        void addArrow() {
            if (arrow != null) {
                return;
            }
            ImageView glyph = NaviBreadIcons.icon(NaviBreadIcons.CHEVRON_RIGHT, Dim.BreadcrumbBar.CHEVRON_SIZE);
            Button zone = new Button("", glyph);
            zone.setFocusTraversable(false);
            zone.setMinWidth(Region.USE_PREF_SIZE);
            zone.getStyleClass().add(PAIR_ARROW_CLASS);
            zone.getProperties().put(CRUMB_PATH_KEY, folder);
            zone.setOnAction(e -> PopupMenuToggle.toggle(zone,
                    () -> buildChildMenu(folder),
                    () -> {
                        NaviBreadIcons.rename(glyph, NaviBreadIcons.CHEVRON_DOWN);
                        setMenuShowing(node, true);
                    },
                    () -> {
                        NaviBreadIcons.rename(glyph, NaviBreadIcons.CHEVRON_RIGHT);
                        setMenuShowing(node, false);
                    }));
            arrow = zone;
            node.getChildren().add(zone);
            node.getStyleClass().add(HAS_ARROW_CLASS);
        }
    }

    // =================================================================
    // Editing
    // =================================================================

    private static void endEdit() {
        editor.node().setVisible(false);
        editor.node().setManaged(false);
        crumbRow.setVisible(true);
        followTail();
    }

    /**
     * @return true if the click landed on (or inside) a button, a text field
     *         or a pair outline, which must keep its own behaviour
     */
    private static boolean hitsControl(Object target) {
        Node node = (target instanceof Node n) ? n : null;
        while (node != null && node != box) {
            if (node instanceof ButtonBase
                    || node instanceof TextInputControl
                    || node.getProperties().containsKey(CONTROL_KEY)) {
                return true;
            }
            node = node.getParent();
        }
        return false;
    }

    /**
     * @return the folder of the pair under a right-click, or null
     */
    private static Path crumbPathOf(Object target) {
        Node node = (target instanceof Node n) ? n : null;
        while (node != null && node != box) {
            Object stored = node.getProperties().get(CRUMB_PATH_KEY);
            if (stored instanceof Path p) {
                return p;
            }
            node = node.getParent();
        }
        return null;
    }

    // =================================================================
    // Menus
    // =================================================================

    /**
     * A drop-down styled like every other menu of the quick-access row.
     *
     * @return an empty menu carrying {@link #MENU_CLASS}
     */
    public static ContextMenu newMenu() {
        ContextMenu menu = new ContextMenu();
        menu.getStyleClass().add(MENU_CLASS);
        return menu;
    }

    /**
     * A menu entry that shows its text literally: without this, the first
     * underscore in a folder name is taken as a mnemonic and disappears.
     *
     * @param text the entry text, shown as given
     * @param icon the entry graphic; may be null
     * @return the entry
     */
    public static MenuItem menuEntry(String text, Node icon) {
        MenuItem item = new MenuItem(text, icon);
        item.setMnemonicParsing(false);
        return item;
    }

    private static MenuItem disabledEntry(String text) {
        MenuItem item = menuEntry(text, null);
        item.setDisable(true);
        return item;
    }

    private static ImageView menuIcon(String name) {
        return NaviBreadIcons.icon(name, Dim.BreadcrumbBar.MENU_ICON_SIZE);
    }

    private static ContextMenu buildCopyMenu(Path crumbPath) {
        ContextMenu menu = newMenu();

        MenuItem copy = menuEntry("Copy Path", null);
        copy.setDisable(shown == null);
        copy.setOnAction(e -> copyToClipboard(shown));
        menu.getItems().add(copy);

        if (crumbPath != null && !FolderPaths.sameCanonical(crumbPath, shown)) {
            MenuItem copyHere = menuEntry("Copy Path to \"" + FolderPaths.label(crumbPath) + "\"", null);
            copyHere.setOnAction(e -> copyToClipboard(crumbPath));
            menu.getItems().add(copyHere);
        }

        MenuItem edit = menuEntry("Edit Path", null);
        edit.setOnAction(e -> beginEdit());
        menu.getItems().addAll(new SeparatorMenuItem(), edit);
        return menu;
    }

    private static void copyToClipboard(Path path) {
        if (path == null) {
            return;
        }
        ClipboardContent content = new ClipboardContent();
        content.putString(path.toString());
        Clipboard.getSystemClipboard().setContent(content);
    }

    /**
     * The subfolders of one folder, as the chevron after it drops them.
     */
    private static ContextMenu buildChildMenu(Path folder) {
        ContextMenu menu = newMenu();

        List<Path> children;
        try (Stream<Path> stream = Files.list(folder)) {
            children = stream
                    .filter(Files::isDirectory)
                    .sorted(Comparator.comparing(p -> p.getFileName().toString().toLowerCase(Locale.ROOT)))
                    .limit(MENU_CHILD_LIMIT + 1L)
                    .toList();
        } catch (Exception e) {
            menu.getItems().add(disabledEntry("Unable to list folders"));
            return menu;
        }

        if (children.isEmpty()) {
            menu.getItems().add(disabledEntry("No subfolders"));
            return menu;
        }

        String onPath = nextNameOnPath(folder);
        Path current = shown;

        int shownCount = Math.min(children.size(), MENU_CHILD_LIMIT);
        for (int i = 0; i < shownCount; i++) {
            Path child = children.get(i);
            MenuItem item = menuEntry(FolderPaths.label(child), menuIcon(NaviBreadIcons.CRUMB_FOLDER));
            Path childName = child.getFileName();
            if (onPath != null && childName != null && childName.toString().equalsIgnoreCase(onPath)) {
                item.getStyleClass().add(MENU_CURRENT_CLASS);
            }
            item.setOnAction(e -> {
                if (owner != null && !FolderPaths.sameCanonical(child, current)) {
                    NavigationActions.goTo(owner, child);
                }
            });
            menu.getItems().add(item);
        }
        if (children.size() > MENU_CHILD_LIMIT) {
            MenuItem more = menuEntry("More... (click the path to type it)", null);
            more.setOnAction(e -> beginEdit());
            menu.getItems().add(more);
        }
        return menu;
    }

    /**
     * @return the name of the subfolder of {@code folder} that the shown path
     *         runs through, or null if the shown path does not go below it
     */
    private static String nextNameOnPath(Path folder) {
        Path current = shown;
        if (current == null || folder == null) {
            return null;
        }
        try {
            if (!current.startsWith(folder) || current.getNameCount() <= folder.getNameCount()) {
                return null;
            }
            return current.getName(folder.getNameCount()).toString();
        } catch (RuntimeException e) {
            return null;
        }
    }

    /**
     * Cloud folders, then every reachable drive (the current one bold), then
     * the usual places: NeuralCode, Documents, Desktop, Downloads, the home
     * folder and the declared root.
     */
    private static ContextMenu buildRootsMenu() {
        ContextMenu menu = newMenu();
        UI_Main ide = owner;
        Path current = shown;
        Path currentDrive = current != null ? current.getRoot() : null;

        List<MenuItem> clouds = new ArrayList<>();
        for (Path cloud : CloudFolders.folders()) {
            MenuItem item = menuEntry(CloudFolders.label(cloud), menuIcon(NaviBreadIcons.CLOUD));
            item.setOnAction(e -> NavigationActions.goTo(ide, cloud));
            clouds.add(item);
        }

        List<MenuItem> drives = new ArrayList<>();
        for (Path root : FileSystems.getDefault().getRootDirectories()) {
            if (!FolderPaths.isFolder(root)) {
                // Empty card reader, disconnected mapped drive.
                continue;
            }
            MenuItem item = menuEntry(FolderPaths.label(root), menuIcon(NaviBreadIcons.CRUMB_FOLDER));
            if (FolderPaths.sameCanonical(root, currentDrive)) {
                item.getStyleClass().add(MENU_CURRENT_CLASS);
            }
            item.setOnAction(e -> NavigationActions.goTo(ide, root));
            drives.add(item);
        }

        Map<String, Path> places = new LinkedHashMap<>();
        places.put("NeuralCode (Home)", DefaultFolders.neuralCodeHome());
        places.put("Documents", DefaultFolders.documents());
        String home = System.getProperty("user.home");
        if (home != null && !home.isBlank()) {
            places.put("Desktop", Path.of(home, "Desktop"));
            places.put("Downloads", Path.of(home, "Downloads"));
            places.put(FolderPaths.label(Path.of(home)), Path.of(home));
        }

        List<MenuItem> shortcuts = new ArrayList<>();
        for (Map.Entry<String, Path> place : places.entrySet()) {
            Path folder = place.getValue();
            if (!FolderPaths.isFolder(folder)) {
                continue;
            }
            MenuItem item = menuEntry(place.getKey(), menuIcon(NaviBreadIcons.CRUMB_FOLDER));
            item.setOnAction(e -> NavigationActions.goTo(ide, folder));
            shortcuts.add(item);
        }
        Path declared = RootFolderStore.declared();
        if (declared != null) {
            MenuItem item = menuEntry("Root - " + FolderPaths.label(declared), menuIcon(NaviBreadIcons.ROOT));
            item.setOnAction(e -> NavigationActions.goTo(ide, declared));
            shortcuts.add(item);
        }

        // Cloud and drives read as one list, as in MATLAB; the shortcuts
        // follow after a separator.
        List<MenuItem> locations = new ArrayList<>(clouds);
        locations.addAll(drives);
        addSection(menu, locations);
        addSection(menu, shortcuts);

        if (menu.getItems().isEmpty()) {
            menu.getItems().add(disabledEntry("No drives found"));
        }
        return menu;
    }

    /** Appends a group of entries, with a separator before it if the menu is not empty. */
    private static void addSection(ContextMenu menu, List<MenuItem> section) {
        if (section.isEmpty()) {
            return;
        }
        if (!menu.getItems().isEmpty()) {
            menu.getItems().add(new SeparatorMenuItem());
        }
        menu.getItems().addAll(section);
    }
}
