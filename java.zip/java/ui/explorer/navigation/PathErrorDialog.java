package ui.explorer.navigation;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Polygon;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.Window;
import ui.design.Dim;
import ui.design.Typography;

/**
 * The Astra-style error shown when the breadcrumb is given a path that does
 * not exist.
 *
 * <pre>
 *  +--------------------------------------------------+
 *  | Error Changing Folder                        [x] |   navy strip, draggable
 *  +--------------------------------------------------+
 *  |  (!)  There is no such path:                     |
 *  |       'D:\My Research Works\MA'                  |
 *  |       Name is nonexistent or not a folder.       |
 *  +--------------------------------------------------+
 *  |                                         [  OK  ] |   light grey footer
 *  +--------------------------------------------------+
 * </pre>
 *
 * <p>
 * Modal to the IDE window and centred over it. Enter, Esc, OK and the close
 * glyph all dismiss it; the breadcrumb then goes back to the folder that was
 * showing. The window borrows the IDE scene's stylesheets, so it follows the
 * light / dark theme and the generated geometry like everything else. Colours
 * are in the theme files under {@code .path-error-*}.
 * </p>
 */
final class PathErrorDialog {

    static final String TITLE = "Error Changing Folder";

    private PathErrorDialog() {
    }

    /**
     * Shows the dialog and waits for it to be dismissed.
     *
     * @param owner the IDE window; may be null
     * @param typed the path exactly as the user typed it
     */
    static void show(Window owner, String typed) {
        Stage stage = new Stage(StageStyle.UNDECORATED);
        stage.setTitle(TITLE);
        stage.initModality(Modality.APPLICATION_MODAL);
        if (owner != null) {
            stage.initOwner(owner);
        }
        stage.setResizable(false);

        // ---- title strip ---------------------------------------------------
        Label title = new Label(TITLE);
        title.getStyleClass().add("path-error-title");

        Region titleSpacer = new Region();
        HBox.setHgrow(titleSpacer, Priority.ALWAYS);

        Button close = new Button("\u2715");
        close.getStyleClass().add("path-error-close");
        close.setFocusTraversable(false);
        close.setOnAction(e -> stage.close());

        HBox titleBar = new HBox(title, titleSpacer, close);
        titleBar.getStyleClass().add("path-error-title-bar");
        titleBar.setAlignment(Pos.CENTER_LEFT);
        makeDraggable(titleBar, stage);

        // ---- body ----------------------------------------------------------
        Label message = new Label("There is no such path:\n'" + typed + "'\n"
                + "Name is nonexistent or not a folder.");
        message.getStyleClass().add("path-error-message");
        message.setWrapText(true);
        message.setMinHeight(Region.USE_PREF_SIZE);
        message.setMaxWidth(Dim.BreadcrumbBar.DIALOG_WIDTH
                - (Dim.BreadcrumbBar.DIALOG_BODY_PAD * 2)
                - Dim.BreadcrumbBar.DIALOG_ICON_SIZE
                - Dim.BreadcrumbBar.DIALOG_BODY_SPACING
                - (Dim.BreadcrumbBar.DIALOG_BORDER * 2));
        HBox.setHgrow(message, Priority.ALWAYS);

        HBox body = new HBox(errorMark(Dim.BreadcrumbBar.DIALOG_ICON_SIZE), message);
        body.getStyleClass().add("path-error-body");
        body.setAlignment(Pos.CENTER_LEFT);

        // ---- footer --------------------------------------------------------
        Button ok = new Button("OK");
        ok.getStyleClass().add("path-error-ok");
        ok.setDefaultButton(true);
        ok.setCancelButton(true);
        ok.setOnAction(e -> stage.close());

        HBox footer = new HBox(ok);
        footer.getStyleClass().add("path-error-footer");
        footer.setAlignment(Pos.CENTER_RIGHT);

        VBox root = new VBox(titleBar, body, footer);
        root.getStyleClass().add("path-error-dialog");

        Scene scene = new Scene(root);
        if (owner != null && owner.getScene() != null) {
            scene.getStylesheets().setAll(owner.getScene().getStylesheets());
        }
        scene.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.ESCAPE || e.getCode() == KeyCode.ENTER) {
                e.consume();
                stage.close();
            }
        });
        stage.setScene(scene);

        if (owner != null) {
            stage.setOnShown(e -> {
                stage.setX(owner.getX() + (owner.getWidth() - stage.getWidth()) / 2);
                stage.setY(owner.getY() + (owner.getHeight() - stage.getHeight()) / 3);
            });
        }

        ok.requestFocus();
        stage.showAndWait();
    }

    /**
     * A red octagon with a white exclamation mark, drawn as vector shapes so it
     * is sharp at any scale and needs no image file. Colours come from
     * {@code .path-error-mark} and {@code .path-error-mark-glyph}.
     */
    private static StackPane errorMark(double size) {
        double side = size / (1 + Math.sqrt(2));
        double o = (size - side) / 2;
        Polygon octagon = new Polygon(
                o, 0,
                size - o, 0,
                size, o,
                size, size - o,
                size - o, size,
                o, size,
                0, size - o,
                0, o);
        octagon.getStyleClass().add("path-error-mark");

        Text bang = new Text("!");
        // A one-off glyph inside a custom mark, sized from the mark itself.
        bang.setFont(Font.font(Typography.uiFamily(), FontWeight.BOLD, size * 0.62));
        bang.getStyleClass().add("path-error-mark-glyph");

        StackPane mark = new StackPane(octagon, bang);
        mark.setMinSize(size, size);
        mark.setPrefSize(size, size);
        mark.setMaxSize(size, size);
        return mark;
    }

    private static void makeDraggable(HBox handle, Stage stage) {
        final double[] offset = new double[2];
        handle.setOnMousePressed(e -> {
            offset[0] = stage.getX() - e.getScreenX();
            offset[1] = stage.getY() - e.getScreenY();
        });
        handle.setOnMouseDragged(e -> {
            stage.setX(e.getScreenX() + offset[0]);
            stage.setY(e.getScreenY() + offset[1]);
        });
    }
}
