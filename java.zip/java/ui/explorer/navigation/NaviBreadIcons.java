package ui.explorer.navigation;

import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import ui.explorer.support.IconLoader;

/**
 * Loads the navigation-bar and breadcrumb icons from
 * {@code /icons/naviBread/<theme>/<name>.png}.
 *
 * <p>
 * Same pattern as {@code HomeFilesIcons}: each icon ships once per theme ink,
 * every {@link ImageView} handed out is kept in a weak registry, and
 * {@link #setDarkTheme(boolean)} re-points the ones already on screen. The
 * breadcrumb therefore no longer has to be rebuilt when the theme changes.
 * </p>
 *
 * <p>
 * The PNGs are 48px masters scaled down with smoothing. To restyle an icon,
 * overwrite its file in both theme folders; the names below are the contract.
 * </p>
 */
public final class NaviBreadIcons {

    // ---- navigation bar, in bar order ----------------------------------
    public static final String HOME = "nav_home";
    public static final String BACK = "nav_back";
    public static final String FORWARD = "nav_forward";
    public static final String UP = "nav_up";
    public static final String CLOUD = "nav_cloud";
    public static final String ROOT = "nav_root";

    // ---- Root drop-down entries ------------------------------------------
    public static final String ROOT_SET = "root_set";
    public static final String ROOT_CLEAR = "root_clear";

    // ---- breadcrumb ------------------------------------------------------
    public static final String CRUMB_FOLDER = "crumb_folder";
    public static final String CHEVRON_RIGHT = "crumb_chevron_right";
    public static final String CHEVRON_DOWN = "crumb_chevron_down";

    private static final String BASE = "/icons/naviBread/";
    private static final String NAME_KEY = "naviBreadIconName";

    private static final List<WeakReference<ImageView>> LIVE = new CopyOnWriteArrayList<>();

    private static volatile boolean dark = false;

    private NaviBreadIcons() {
    }

    /**
     * Builds a themed icon view.
     *
     * @param name one of the name constants in this class
     * @param size edge length in pixels
     * @return the configured view, already registered for theme swaps
     */
    public static ImageView icon(String name, double size) {
        ImageView view = new ImageView();
        view.getProperties().put(NAME_KEY, name);
        view.setFitWidth(size);
        view.setFitHeight(size);
        view.setPreserveRatio(true);
        view.setSmooth(true);
        view.setMouseTransparent(true);
        apply(view);
        LIVE.add(new WeakReference<>(view));
        return view;
    }

    /**
     * Points an existing view at a different icon, keeping its size and its
     * place in the registry. Used by the breadcrumb chevrons, which flip
     * between right and down while their menu is open.
     *
     * @param view a view created by {@link #icon(String, double)}
     * @param name the new icon name
     */
    public static void rename(ImageView view, String name) {
        if (view == null || name == null) {
            return;
        }
        view.getProperties().put(NAME_KEY, name);
        apply(view);
    }

    /**
     * Switches the set between the two inks and refreshes every icon on
     * screen. Safe to call when nothing has changed.
     *
     * @param useDark {@code true} for the dark-theme ink
     */
    public static void setDarkTheme(boolean useDark) {
        if (useDark == dark) {
            return;
        }
        dark = useDark;
        Iterator<WeakReference<ImageView>> it = LIVE.iterator();
        while (it.hasNext()) {
            WeakReference<ImageView> ref = it.next();
            ImageView view = ref.get();
            if (view == null) {
                LIVE.remove(ref);
            } else {
                apply(view);
            }
        }
    }

    /**
     * @return {@code true} if the dark-theme ink is selected
     */
    public static boolean isDarkTheme() {
        return dark;
    }

    /**
     * @param name an icon name
     * @return its classpath resource for the active theme
     */
    public static String path(String name) {
        return BASE + (dark ? "dark/" : "light/") + name + ".png";
    }

    private static void apply(ImageView view) {
        Object name = view.getProperties().get(NAME_KEY);
        if (name == null) {
            return;
        }
        Image image = IconLoader.load(NaviBreadIcons.class, path(name.toString()));
        if (image != null) {
            view.setImage(image);
        }
    }
}
