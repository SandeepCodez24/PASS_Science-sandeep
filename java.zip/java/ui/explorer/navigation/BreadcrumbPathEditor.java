package ui.explorer.navigation;

import java.nio.file.Path;

import javafx.application.Platform;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.stage.Window;
import ui.UI_Main;
import ui.editor.navigation.FolderPaths;
import ui.editor.navigation.NavigationActions;

/**
 * The text field the breadcrumb turns into, MATLAB-style.
 *
 * <table>
 * <caption>Keys and clicks</caption>
 * <tr><td>opens</td><td>whole path selected, so Ctrl+C copies it at once and
 * typing replaces it</td></tr>
 * <tr><td>Enter</td><td>go to the typed folder; unchanged text just closes the
 * field</td></tr>
 * <tr><td>Esc</td><td>close the field, nothing changes</td></tr>
 * <tr><td>click elsewhere</td><td>same as Esc</td></tr>
 * <tr><td>bad path</td><td>the "There is no such path" dialog; OK closes it
 * and the crumbs come back on the folder that was showing</td></tr>
 * </table>
 *
 * <p>
 * What counts as a path is decided by {@link FolderPaths#parseTyped}: quotes
 * from Explorer's "Copy as path" are stripped, {@code %VARS%} and {@code ~} are
 * expanded, and a relative path is taken relative to the folder being shown.
 * </p>
 *
 * <h3>The focus trap this avoids</h3>
 * <p>
 * Showing the error dialog takes focus from the field, and losing focus means
 * "cancel". Left alone, the cancel would run first and the field would vanish
 * under the dialog. {@link #committing} holds the focus handler off until the
 * dialog has closed.
 * </p>
 */
final class BreadcrumbPathEditor {

    private static final String EDITOR_CLASS = "quick-path-editor";

    private final UI_Main ide;
    private final Runnable onClose;
    private final TextField field = new TextField();

    private boolean active;
    private boolean committing;
    private Path startedFrom;

    /**
     * @param ide     the IDE controller
     * @param onClose run whenever the field closes, whatever the reason, so the
     *                breadcrumb can put its crumbs back
     */
    BreadcrumbPathEditor(UI_Main ide, Runnable onClose) {
        this.ide = ide;
        this.onClose = onClose;

        field.getStyleClass().add(EDITOR_CLASS);
        field.setMinWidth(0);
        field.setMaxWidth(Double.MAX_VALUE);
        field.setPromptText("Type or paste a folder path, then press Enter");

        field.setOnAction(e -> commit());
        field.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.ESCAPE) {
                e.consume();
                cancel();
            }
        });
        field.focusedProperty().addListener((obs, was, now) -> {
            if (!now && active && !committing) {
                // The user clicked somewhere else: close, but leave focus
                // wherever they clicked.
                close(false);
            }
        });
    }

    /**
     * @return the text field, for placing in the breadcrumb
     */
    TextField node() {
        return field;
    }

    /**
     * @return true while the field is open
     */
    boolean isActive() {
        return active;
    }

    /**
     * Opens the field on a folder, with its path selected.
     *
     * @param folder the folder being shown; may be null
     */
    void begin(Path folder) {
        startedFrom = folder;
        active = true;
        field.setText(folder != null ? folder.toString() : "");
        // Focus has to wait a pulse: the field has only just become visible
        // and managed, and asking before it is laid out is ignored.
        Platform.runLater(() -> {
            field.requestFocus();
            field.selectAll();
        });
    }

    /**
     * Closes the field without going anywhere.
     */
    void cancel() {
        if (!active) {
            return;
        }
        close(true);
    }

    private void commit() {
        if (!active || committing) {
            return;
        }
        committing = true;
        try {
            String typed = field.getText() == null ? "" : field.getText().trim();

            if (typed.isEmpty() || (startedFrom != null && typed.equals(startedFrom.toString()))) {
                close(true);
                return;
            }

            Path target = FolderPaths.parseTyped(typed, startedFrom);
            if (FolderPaths.isFolder(target)) {
                close(true);
                if (!FolderPaths.same(target, startedFrom)) {
                    NavigationActions.goTo(ide, target);
                }
                return;
            }

            // Not a folder, not a path at all, or a file: say so, then put the
            // crumbs back exactly as they were.
            Window ownerWindow = field.getScene() != null ? field.getScene().getWindow() : null;
            PathErrorDialog.show(ownerWindow, typed);
            close(true);
        } finally {
            committing = false;
        }
    }

    /**
     * @param reclaimFocus true after Enter / Esc / the dialog, when focus is
     *                     still on the field and would otherwise sit on a
     *                     hidden control swallowing keystrokes; false when the
     *                     user has already clicked somewhere else
     */
    private void close(boolean reclaimFocus) {
        active = false;
        field.deselect();
        if (onClose != null) {
            onClose.run();
        }
        if (reclaimFocus && ide != null && ide.editorTabs != null) {
            Platform.runLater(() -> ide.editorTabs.requestFocus());
        }
    }
}
