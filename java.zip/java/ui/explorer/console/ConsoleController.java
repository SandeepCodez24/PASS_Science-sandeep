package ui.explorer.console;

import javafx.application.Platform;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyCode;
import ui.UI_Main;
import ui.ui_functions.UI_MainProgramControl;

/** Initializes and controls the main command-window text area. */
public final class ConsoleController {
    private ConsoleController() {
    }

    public static void initialize(UI_Main ide) {
        ide.console = new TextArea();
        ide.console.getStyleClass().add("console-area");
        ide.console.setWrapText(true);
        ide.console.setPrefHeight(140);
        ide.console.setStyle("-fx-font-family: Consolas; -fx-font-size: 13;");
        ide.console.setEditable(true);
        ide.inputStart = ide.console.getLength();
        ide.console.positionCaret(ide.console.getLength());

        ide.console.setOnKeyPressed(event -> {
            if (ide.console.getCaretPosition() < ide.inputStart) {
                ide.console.positionCaret(ide.console.getLength());
            }
            if (event.getCode() == KeyCode.ENTER) {
                event.consume();
                UI_MainProgramControl.handleConsoleEnter(ide);
            } else if (event.getCode() == KeyCode.SPACE
                    || event.getCode() == KeyCode.SEMICOLON) {
                Platform.runLater(
                        () -> UI_MainProgramControl.handleConsoleStatementTerminated(ide));
            }
        });
    }
}
