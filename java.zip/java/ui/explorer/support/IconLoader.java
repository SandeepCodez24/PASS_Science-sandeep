package ui.explorer.support;

import java.net.URL;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import javafx.scene.image.Image;

/** Loads and caches classpath images used by the explorer UI. */
public final class IconLoader {
    private static final Map<String, Image> CACHE = new ConcurrentHashMap<>();

    private IconLoader() {
    }

    public static Image load(Class<?> resourceOwner, String path) {
        if (resourceOwner == null || path == null || path.isBlank()) {
            return null;
        }
        return CACHE.computeIfAbsent(path, key -> loadUncached(resourceOwner, key));
    }

    private static Image loadUncached(Class<?> resourceOwner, String path) {
        try {
            URL url = resourceOwner.getResource(path);
            if (url == null) {
                System.err.println("Resource missing: " + path);
                return null;
            }
            return new Image(url.toExternalForm(), true);
        } catch (IllegalArgumentException | NullPointerException exception) {
            System.err.println("Unable to load resource '" + path + "': " + exception.getMessage());
            return null;
        }
    }

    public static void clearCache() {
        CACHE.clear();
    }
}
