package ui.explorer.support;

import java.net.URL;
import java.util.List;
import javafx.collections.ObservableList;
import javafx.scene.Scene;

/**
 * Keeps the feature stylesheets that come in a light and a dark variant on the
 * scene, in the variant that matches the current theme.
 *
 * <pre>
 *   /themes/explorer/explorer_{light,dark}.css   File Explorer menus, group rows,
 *                                                edge strip, fallback Properties
 *   /themes/codebot/codebot_{light,dark}.css     the Code Bot panel
 * </pre>
 *
 * <p>
 * Call {@link #sync(Scene, boolean)} after the theme is applied and again
 * whenever the scene's stylesheet list changes ({@code Main_Window} does both).
 * It only touches the list when something is missing or in the wrong variant,
 * so calling it from a listener on that same list settles after one round.
 * </p>
 */
public final class FeatureStylesheets {

    /** Light / dark pairs, in the order they are appended. */
    private static final List<String[]> PAIRS = List.of(
            new String[] { "/themes/explorer/explorer_light.css", "/themes/explorer/explorer_dark.css" },
            new String[] { "/themes/codebot/codebot_light.css", "/themes/codebot/codebot_dark.css" });

    private FeatureStylesheets() {
    }

    /**
     * @param scene the main scene
     * @param dark  true for the dark theme
     */
    public static void sync(Scene scene, boolean dark) {
        if (scene == null) {
            return;
        }
        ObservableList<String> sheets = scene.getStylesheets();
        for (String[] pair : PAIRS) {
            String wanted = url(pair[dark ? 1 : 0]);
            String other = url(pair[dark ? 0 : 1]);
            if (other != null && sheets.contains(other)) {
                sheets.remove(other);
            }
            if (wanted != null && !sheets.contains(wanted)) {
                sheets.add(wanted);
            }
        }
    }

    private static String url(String resource) {
        URL url = FeatureStylesheets.class.getResource(resource);
        return url == null ? null : url.toExternalForm();
    }
}
