package ui.explorer;

import java.nio.file.Path;

import javafx.application.Platform;
import javafx.collections.ListChangeListener;
import javafx.geometry.Orientation;
import javafx.scene.Scene;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TabPane;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import ui.UI_Main;
import ui.cli.CLI_Main;
import ui.cli.EditorCommandWindow;
import ui.codebot.CodeBotHost;
import ui.design.DesignStylesheet;
import ui.design.Dim;
import ui.directory.DirectoryFileOps;
import ui.directory.DirectoryTreeBuilder;
import ui.editor.EditorUIHelper;
import ui.explorer.footer.FooterBuilder;
import ui.explorer.shortcut.MainWindowShortcutHandler;
import ui.explorer.support.FeatureStylesheets;
import ui.explorer.support.IconLoader;
import ui.explorer.variable.VariableExplorerBuilder;
import ui.managers.ThemeManager;
import ui.managers.ToolbarManager;
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
import ui.ribbon_interface.tool_bar.RibbonCollapse;
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
/**
 * Assembles the main window: explorer, editor tabs, Command Window, variable
 * explorer, ribbon and footer.
 *
 * <h3>What changed</h3>
 * <ul>
 * <li><b>File operations moved out.</b> The clipboard, paste, delete, undo
 * history and the rename step now live in
 * {@link ui.directory.DirectoryFileOps}, which serves the File Explorer's two
 * right-click menus (on an item / on empty space) and its shortcuts. This
 * class only creates it and hands it to the tree.</li>
 * <li><b>Code Bot.</b> The File Explorer's body is built by
 * {@link CodeBotHost}: a static edge strip on the left, and a vertical split
 * that takes the Code Bot under the tree when the Home ribbon's Code Bot
 * button is pressed.</li>
 * <li><b>Feature stylesheets.</b> The explorer and Code Bot sheets are kept
 * on the scene in the variant matching the theme by
 * {@link FeatureStylesheets}.</li>
 * <li><b>Rename happens in place.</b> The {@code TextInputDialog} is gone. The
 * menu's Rename (and F2, and a slow double-click) open the name inside its row
 * through {@link DirectoryTreeBuilder#beginRename(Path)}. The file-system step
 * is {@code DirectoryFileOps.renameInPlace}, handed to the tree as its
 * {@code DirectoryRename.Mover}: it moves the item, records the undo step and
 * updates open editor tabs. It no longer rebuilds the tree, so folders the
 * user has opened stay open.</li>
 * <li><b>Open tabs follow a renamed folder.</b> Renaming or moving a folder
 * now rewrites the path of every open file inside it, not only a tab whose
 * path is exactly the renamed item. A tab's unsaved {@code *} is kept.</li>
 * <li><b>Case-only renames work on Windows</b> ({@code notes.nc} to
 * {@code Notes.nc}), including their undo and redo, through
 * {@code DirectoryRename.move}.</li>
 * <li><b>The editor tab strip</b> carries the {@code editor-tabs} style class,
 * which the generated stylesheet uses to give the tab labels the breadcrumb
 * bar's font size.</li>
 * </ul>
 */
public final class Main_Window {
    private Main_Window() {
    }

    public static void buildUI(UI_Main ide) {
        ide.sunIcon = loadIcon(ide, "/icons/ic_05_sun.png");
        ide.moonIcon = loadIcon(ide, "/icons/ic_06_moon.png");
        setupProjectTree(ide);
        setupEditorTabs(ide);
        setupConsole(ide);
        // Command Window = title strip (with the three-dot options menu) over
        // the console, kept together so the whole block behaves as one region
        // in the vertical split below.
        VBox terminalBox = EditorCommandWindow.build(ide, ide.console);
        // Task 2: vertical SplitPane -> editor (top) over Command Window
        // (bottom) gives a draggable divider so the console height can be
        // resized, exactly like the left/right explorer panels.
        SplitPane centerSplit = new SplitPane(ide.editorTabs, terminalBox);
        centerSplit.setOrientation(Orientation.VERTICAL);
        centerSplit.setDividerPositions(Dim.Split.EDITOR_OVER_CONSOLE);
        SplitPane.setResizableWithParent(terminalBox, false);
        EditorCommandWindow.attachTo(centerSplit);
        // File Explorer: title strip over [edge strip | tree (+ Code Bot)],
        // collapsing to a vertical rail. The Code Bot joins the body only
        // when the Home ribbon's Code Bot button is pressed.
        CollapsiblePanel leftBox = new CollapsiblePanel("File Explorer",
                CodeBotHost.buildBody(ide, ide.projectTree));
        leftBox.setPrefWidth(Dim.Explorer.PANEL_PREF_WIDTH);
        leftBox.setMinWidth(Dim.Explorer.PANEL_MIN_WIDTH);
        leftBox.setMaxWidth(Double.MAX_VALUE);
        CollapsiblePanel rightBox = buildVariableExplorer(ide);
        SplitPane splitPane = new SplitPane(leftBox, centerSplit, rightBox);
        // The Variable Explorer opens at VARIABLE_EXPLORER_LAUNCH_SCALE of its
        // configured share (1 - MAIN_RIGHT); the editor takes the difference.
        // Launch only -- dragging the divider afterwards is unaffected.
        double variableExplorerShare = (1.0 - Dim.Split.MAIN_RIGHT)
                * Dim.Window.VARIABLE_EXPLORER_LAUNCH_SCALE;
        splitPane.setDividerPositions(Dim.Split.MAIN_LEFT, 1.0 - variableExplorerShare);
        // Each panel needs to know its SplitPane so it can put the dividers
        // back where they were when it is expanded again.
        leftBox.attachTo(splitPane);
        rightBox.attachTo(splitPane);
        // The edge strip follows the colour of this split's first divider.
        CodeBotHost.attach(leftBox, splitPane);
        // Only the clicked region keeps the navy strip; the editor is a fourth
        // region with no strip, so clicking it greys all three.
        PanelActivation.register(PanelActivation.Panel.FILE_EXPLORER, leftBox.getHeader(), leftBox);
        PanelActivation.register(PanelActivation.Panel.VARIABLE_EXPLORER, rightBox.getHeader(), rightBox);
        PanelActivation.register(PanelActivation.Panel.COMMAND_WINDOW,
                EditorCommandWindow.getHeader(), terminalBox);
        PanelActivation.register(PanelActivation.Panel.EDITOR, null, ide.editorTabs);
        // Startup highlight. Change this line to pick a different default, or
        // to Panel.EDITOR if you would rather nothing is highlighted at launch.
        PanelActivation.setActive(PanelActivation.Panel.FILE_EXPLORER);
        BorderPane root = new BorderPane(splitPane);
        ide.rootNode = root;
        ToolbarManager.setupToolbars(ide);
        // Tool-band collapse toggle, sitting just after the breadcrumb path
        // in the quick-access bar. The other way is a double-click on the
        // active tab; the Command Window has its own three-dot menu.
        RibbonCollapse.installQuickAccessToggle(ide);
        VBox top = new VBox(ToolbarManager.ribbonBar, ToolbarManager.toolbarStack, ToolbarManager.quickAccessBar);
        top.setSpacing(0);
        // Task 3: ribbon area background is navy blue (was teal). The old
        // floating Print button has moved INTO the ribbon right-cluster
        // (see ToolbarRibbon.buildRightCluster -> ic_print.png).
        top.setStyle("-fx-background-color:#004073; -fx-padding:0;");
        root.setTop(top);
        root.setBottom(buildFooter(ide));
        root.setStyle("-fx-background-color:#004073;");
        ide.scene = new Scene(root, Dim.Window.SCENE_WIDTH, Dim.Window.SCENE_HEIGHT);
        ThemeManager.applySavedTheme(ide);
        DesignStylesheet.install(ide.scene);
        FeatureStylesheets.sync(ide.scene, "dark".equals(ide.currentTheme));
        // Title-strip glyphs ship in a light and a dark tone. Repaint them
        // whenever the theme stylesheet is swapped. ThemeManager sets
        // ide.currentTheme AFTER adding the sheet, so read it a pulse later.
        PanelActivation.setDarkTheme("dark".equals(ide.currentTheme));
        FooterBuilder.updateThemeIcon(ide);
        ide.scene.getStylesheets().addListener((ListChangeListener<String>) change ->
                Platform.runLater(() -> {
                    boolean dark = "dark".equals(ide.currentTheme);
                    PanelActivation.setDarkTheme(dark);
                    FooterBuilder.updateThemeIcon(ide);
                    // Only edits the list when a variant is missing or wrong,
                    // so this listener settles after one round.
                    FeatureStylesheets.sync(ide.scene, dark);
                }));
        setupKeyboardShortcuts(ide);
    }

    public static HBox buildFooter(UI_Main ide) {
        return FooterBuilder.build(ide);
    }

    public static Image loadIcon(UI_Main ide, String path) {
        return IconLoader.load(ide.getClass(), path);
    }

    /**
     * Creates the directory tree with its file operations. The same
     * {@link DirectoryFileOps} serves the right-click menus, the keyboard
     * shortcuts and the in-place rename, so all of them share one clipboard
     * and one undo history.
     */
    private static void setupProjectTree(UI_Main ide) {
        DirectoryFileOps ops = new DirectoryFileOps(ide);
        DirectoryTreeBuilder.initialize(ide, ops, ops::renameInPlace);
    }

    private static void setupEditorTabs(UI_Main ide) {
        ide.editorTabs = new TabPane();
        // Lets the generated stylesheet size the tab labels like the breadcrumb.
        ide.editorTabs.getStyleClass().add(Dim.Editor.TAB_PANE_CLASS);
        ide.editorTabs.setTabClosingPolicy(TabPane.TabClosingPolicy.ALL_TABS);
        ide.editorTabs.getSelectionModel().selectedItemProperty().addListener((obs, oldTab, newTab) -> {
            if (newTab == null)
                return;
            // Handle both TextArea and CodeArea (wrapped in VirtualizedScrollPane)
            Object content = newTab.getContent();
            ui.editor.EditorFileInfo info = (ui.editor.EditorFileInfo) newTab.getUserData();
            Path path = info != null ? info.path : null;
            if (path != null)
                EditorUIHelper.updateFooter(ide, path, path.getFileName().toString());
            else {
                ide.footerFileLabel.setText("");
            }
            // Add caret listener only for TextArea (CodeArea handles its own caret
            // tracking)
            if (content instanceof javafx.scene.control.TextArea editor) {
                editor.caretPositionProperty().addListener((o, oldPos, newPos) -> {
                    int caret = newPos.intValue();
                    String text = editor.getText(0, caret);
                    int line = text.split("\n", -1).length;
                    int col = caret - text.lastIndexOf('\n');
                    ide.footerCursorLabel.setText(" Ln " + line + ", Col " + col);
                });
            }
        });
    }

    private static void setupConsole(UI_Main ide) {
        // CLI consolidation: the Command Window's console is now built and owned
        // by ui.cli.CLI_Main (which also attaches the shared suggestion popup).
        CLI_Main.initConsole(ide);
    }

    private static CollapsiblePanel buildVariableExplorer(UI_Main ide) {
        return VariableExplorerBuilder.build(ide);
    }

    private static void setupKeyboardShortcuts(UI_Main ide) {
        MainWindowShortcutHandler.install(ide);
    }
}
