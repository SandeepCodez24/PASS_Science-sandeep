package ui.explorer;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;

import javafx.application.Platform;
import javafx.collections.ListChangeListener;
import javafx.geometry.Orientation;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.SplitPane;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.image.Image;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import ui.UI_Main;
import ui.cli.CLI_Main;
import ui.cli.EditorCommandWindow;
import ui.design.DesignStylesheet;
import ui.design.Dim;
import ui.directory.DirectoryRename;
import ui.directory.DirectoryTreeBuilder;
import ui.directory.DirectoryTreeContextMenu;
import ui.directory.NcMetrics;
import ui.editor.EditorFileInfo;
import ui.editor.EditorUIHelper;
import ui.explorer.footer.FooterBuilder;
import ui.explorer.shortcut.MainWindowShortcutHandler;
import ui.explorer.support.IconLoader;
import ui.explorer.variable.VariableExplorerBuilder;
import ui.managers.ProjectManager;
import ui.managers.ThemeManager;
import ui.managers.ToolbarManager;
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
import ui.ribbon_interface.tool_bar.RibbonCollapse;
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
/**
 * Assembles the main window: explorer, editor tabs, Command Window, variable
 * explorer, ribbon and footer.
 *
 * <h3>What changed</h3>
 * <ul>
 * <li><b>Rename happens in place.</b> The {@code TextInputDialog} is gone. The
 * menu's Rename (and F2, and a slow double-click) open the name inside its row
 * through {@link DirectoryTreeBuilder#beginRename(Path)}. The file-system step
 * is {@link #renameInPlace}, handed to the tree as its
 * {@link DirectoryRename.Mover}: it moves the item, records the undo step and
 * updates open editor tabs. It no longer rebuilds the tree, so folders the
 * user has opened stay open.</li>
 * <li><b>Open tabs follow a renamed folder.</b> Renaming or moving a folder
 * now rewrites the path of every open file inside it, not only a tab whose
 * path is exactly the renamed item. A tab's unsaved {@code *} is kept.</li>
 * <li><b>Case-only renames work on Windows</b> ({@code notes.nc} to
 * {@code Notes.nc}), including their undo and redo, through
 * {@link DirectoryRename#move(Path, Path)}.</li>
 * <li><b>The editor tab strip</b> carries the {@code editor-tabs} style class,
 * which the generated stylesheet uses to give the tab labels the breadcrumb
 * bar's font size.</li>
 * </ul>
 */
public final class Main_Window {
    private Main_Window() {
    }

    private static final FileClipboard fileClipboard = new FileClipboard();
    private static final FileOperationHistory fileHistory = new FileOperationHistory();

    public static void buildUI(UI_Main ide) {
        ide.sunIcon = loadIcon(ide, "/icons/ic_05_sun.png");
        ide.moonIcon = loadIcon(ide, "/icons/ic_06_moon.png");
        setupProjectTree(ide);
        setupEditorTabs(ide);
        setupConsole(ide);
        // Command Window = title strip (with the three-dot options menu) over
        // the console, kept together so the whole block behaves as one region
        // in the vertical split below.
        VBox terminalBox = EditorCommandWindow.build(ide, ide.console);
        // Task 2: vertical SplitPane -> editor (top) over Command Window
        // (bottom) gives a draggable divider so the console height can be
        // resized, exactly like the left/right explorer panels.
        SplitPane centerSplit = new SplitPane(ide.editorTabs, terminalBox);
        centerSplit.setOrientation(Orientation.VERTICAL);
        centerSplit.setDividerPositions(Dim.Split.EDITOR_OVER_CONSOLE);
        SplitPane.setResizableWithParent(terminalBox, false);
        EditorCommandWindow.attachTo(centerSplit);
        // File Explorer: title strip + tree, collapsing to a vertical rail.
        CollapsiblePanel leftBox = new CollapsiblePanel("File Explorer", ide.projectTree);
        leftBox.setPrefWidth(Dim.Explorer.PANEL_PREF_WIDTH);
        leftBox.setMinWidth(Dim.Explorer.PANEL_MIN_WIDTH);
        leftBox.setMaxWidth(Double.MAX_VALUE);
        CollapsiblePanel rightBox = buildVariableExplorer(ide);
        SplitPane splitPane = new SplitPane(leftBox, centerSplit, rightBox);
        // The Variable Explorer opens at VARIABLE_EXPLORER_LAUNCH_SCALE of its
        // configured share (1 - MAIN_RIGHT); the editor takes the difference.
        // Launch only -- dragging the divider afterwards is unaffected.
        double variableExplorerShare = (1.0 - Dim.Split.MAIN_RIGHT)
                * Dim.Window.VARIABLE_EXPLORER_LAUNCH_SCALE;
        splitPane.setDividerPositions(Dim.Split.MAIN_LEFT, 1.0 - variableExplorerShare);
        // Each panel needs to know its SplitPane so it can put the dividers
        // back where they were when it is expanded again.
        leftBox.attachTo(splitPane);
        rightBox.attachTo(splitPane);
        // Only the clicked region keeps the navy strip; the editor is a fourth
        // region with no strip, so clicking it greys all three.
        PanelActivation.register(PanelActivation.Panel.FILE_EXPLORER, leftBox.getHeader(), leftBox);
        PanelActivation.register(PanelActivation.Panel.VARIABLE_EXPLORER, rightBox.getHeader(), rightBox);
        PanelActivation.register(PanelActivation.Panel.COMMAND_WINDOW,
                EditorCommandWindow.getHeader(), terminalBox);
        PanelActivation.register(PanelActivation.Panel.EDITOR, null, ide.editorTabs);
        // Startup highlight. Change this line to pick a different default, or
        // to Panel.EDITOR if you would rather nothing is highlighted at launch.
        PanelActivation.setActive(PanelActivation.Panel.FILE_EXPLORER);
        BorderPane root = new BorderPane(splitPane);
        ide.rootNode = root;
        ToolbarManager.setupToolbars(ide);
        // Tool-band collapse toggle, sitting just after the breadcrumb path
        // in the quick-access bar. The other way is a double-click on the
        // active tab; the Command Window has its own three-dot menu.
        RibbonCollapse.installQuickAccessToggle(ide);
        VBox top = new VBox(ToolbarManager.ribbonBar, ToolbarManager.toolbarStack, ToolbarManager.quickAccessBar);
        top.setSpacing(0);
        // Task 3: ribbon area background is navy blue (was teal). The old
        // floating Print button has moved INTO the ribbon right-cluster
        // (see ToolbarRibbon.buildRightCluster -> ic_print.png).
        top.setStyle("-fx-background-color:#004073; -fx-padding:0;");
        root.setTop(top);
        root.setBottom(buildFooter(ide));
        root.setStyle("-fx-background-color:#004073;");
        ide.scene = new Scene(root, Dim.Window.SCENE_WIDTH, Dim.Window.SCENE_HEIGHT);
        ThemeManager.applySavedTheme(ide);
        DesignStylesheet.install(ide.scene);
        // Title-strip glyphs ship in a light and a dark tone. Repaint them
        // whenever the theme stylesheet is swapped. ThemeManager sets
        // ide.currentTheme AFTER adding the sheet, so read it a pulse later.
        PanelActivation.setDarkTheme("dark".equals(ide.currentTheme));
        FooterBuilder.updateThemeIcon(ide);
        ide.scene.getStylesheets().addListener((ListChangeListener<String>) change ->
                Platform.runLater(() -> {
                    PanelActivation.setDarkTheme("dark".equals(ide.currentTheme));
                    FooterBuilder.updateThemeIcon(ide);
                }));
        setupKeyboardShortcuts(ide);
    }

    public static HBox buildFooter(UI_Main ide) {
        return FooterBuilder.build(ide);
    }

    public static Image loadIcon(UI_Main ide, String path) {
        return IconLoader.load(ide.getClass(), path);
    }

    private static void setupProjectTree(UI_Main ide) {
        DirectoryTreeContextMenu.Actions actions = new DirectoryTreeContextMenu.Actions(
                path -> fileClipboard.set(path, true),
                path -> fileClipboard.set(path, false),
                path -> pasteTo(path, ide),
                path -> deletePath(path, ide),
                path -> renamePath(path, ide),
                () -> {
                    if (fileHistory.canUndo()) {
                        fileHistory.undo();
                        ProjectManager.refreshProjectTree(ide);
                    }
                },
                () -> {
                    if (fileHistory.canRedo()) {
                        fileHistory.redo();
                        ProjectManager.refreshProjectTree(ide);
                    }
                },
                fileClipboard::hasContent,
                () -> true,
                () -> true,
                fileHistory::canUndo,
                fileHistory::canRedo);
        DirectoryTreeBuilder.initialize(
                ide,
                path -> DirectoryTreeContextMenu.create(path, actions),
                (source, target) -> renameInPlace(source, target, ide));
    }

    private static void pasteTo(Path item, UI_Main ide) {
        if (!fileClipboard.hasContent()) {
            return;
        }
        Path targetDir = Files.isDirectory(item) ? item : item.getParent();
        if (targetDir == null || !Files.isDirectory(targetDir)) {
            return;
        }
        Path source = fileClipboard.getSource();
        if (source == null || !Files.exists(source)) {
            return;
        }
        Path destination = targetDir.resolve(source.getFileName());
        destination = resolveExistingTarget(destination);
        try {
            if (fileClipboard.isCut()) {
                Files.move(source, destination);
                fileHistory.record(new MoveOperation(source, destination, ide));
                updateOpenTabsForMovedPath(ide, source, destination);
                fileClipboard.clear();
            } else {
                copyRecursive(source, destination);
                fileHistory.record(new CopyOperation(source, destination));
            }
            ProjectManager.refreshProjectTree(ide);
        } catch (IOException | UncheckedIOException ex) {
            showError("Paste failed", ex.getMessage());
        }
    }

    private static void deletePath(Path item, UI_Main ide) {
        if (!Files.exists(item)) {
            return;
        }
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                "Delete '" + item.getFileName() + "'? This cannot be undone without using Undo.",
                ButtonType.YES, ButtonType.NO);
        confirm.setHeaderText("Confirm Delete");
        confirm.showAndWait()
                .filter(response -> response == ButtonType.YES)
                .ifPresent(response -> {
                    try {
                        Path backup = backupPath(item);
                        Files.move(item, backup);
                        fileHistory.record(new DeleteOperation(item, backup, ide));
                        ProjectManager.refreshProjectTree(ide);
                    } catch (IOException ex) {
                        showError("Delete failed", ex.getMessage());
                    }
                });
    }

    /**
     * The menu's Rename: opens the name for editing in its own row.
     */
    private static void renamePath(Path item, UI_Main ide) {
        DirectoryTreeBuilder.beginRename(item);
    }

    /**
     * The file-system side of an in-place rename, called by the tree once the
     * typed name has been validated.
     *
     * @return the item's new path
     */
    private static Path renameInPlace(Path source, Path target, UI_Main ide) throws IOException {
        Path moved = DirectoryRename.move(source, target);
        fileHistory.record(new RenameOperation(source, moved, ide));
        updateOpenTabsForMovedPath(ide, source, moved);
        // Line / function / class counts are cached by path.
        NcMetrics.invalidateAll();
        return moved;
    }

    /**
     * Points every open tab at the item's new location: the item itself and,
     * when a folder moved, every open file inside it. The tab title follows
     * the new file name and keeps its unsaved {@code *}.
     */
    private static void updateOpenTabsForMovedPath(UI_Main ide, Path oldPath, Path newPath) {
        if (ide == null || ide.editorTabs == null || oldPath == null || newPath == null) {
            return;
        }
        for (Tab tab : ide.editorTabs.getTabs()) {
            Object ud = tab.getUserData();
            if (!(ud instanceof EditorFileInfo info) || info.path == null || !info.path.startsWith(oldPath)) {
                continue;
            }
            Path updated = info.path.equals(oldPath)
                    ? newPath
                    : newPath.resolve(oldPath.relativize(info.path));
            info.path = updated;

            boolean dirty = tab.getText() != null && tab.getText().endsWith("*");
            String name = updated.getFileName().toString();
            tab.setText(dirty ? name + "*" : name);

            if (ide.editorTabs.getSelectionModel().getSelectedItem() == tab) {
                EditorUIHelper.updateFooter(ide, updated, name);
            }
        }
    }

    private static void showError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private static Path backupPath(Path source) {
        Path tmp = Path.of(System.getProperty("java.io.tmpdir"), "upi-file-ops");
        try {
            Files.createDirectories(tmp);
        } catch (IOException ignored) {
        }
        return tmp.resolve(source.getFileName().toString() + "-backup-" + System.nanoTime());
    }

    private static Path resolveExistingTarget(Path target) {
        if (!Files.exists(target)) {
            return target;
        }
        String fileName = target.getFileName().toString();
        String base = fileName;
        String ext = "";
        int dot = fileName.lastIndexOf('.');
        if (dot > 0) {
            base = fileName.substring(0, dot);
            ext = fileName.substring(dot);
        }
        int index = 1;
        Path parent = target.getParent();
        while (Files.exists(target)) {
            target = parent.resolve(base + " (" + index++ + ")" + ext);
        }
        return target;
    }

    private static void copyRecursive(Path source, Path target) throws IOException {
        if (Files.isDirectory(source)) {
            try (java.util.stream.Stream<Path> stream = Files.walk(source)) {
                stream.forEach(path -> {
                    try {
                        Path relative = source.relativize(path);
                        Path destination = target.resolve(relative);
                        if (Files.isDirectory(path)) {
                            Files.createDirectories(destination);
                        } else {
                            Files.copy(path, destination);
                        }
                    } catch (IOException e) {
                        throw new UncheckedIOException(e);
                    }
                });
            }
        } else {
            Files.copy(source, target);
        }
    }

    private static class FileClipboard {
        private Path source;
        private boolean cut;

        void set(Path source, boolean cut) {
            this.source = source;
            this.cut = cut;
            Clipboard clipboard = Clipboard.getSystemClipboard();
            ClipboardContent content = new ClipboardContent();
            content.putString(source.toString());
            clipboard.setContent(content);
        }

        boolean hasContent() {
            return source != null && Files.exists(source);
        }

        Path getSource() {
            return source;
        }

        boolean isCut() {
            return cut;
        }

        void clear() {
            source = null;
            cut = false;
        }
    }

    private static class FileOperationHistory {
        private final java.util.Deque<FileOperation> undoStack = new java.util.ArrayDeque<>();
        private final java.util.Deque<FileOperation> redoStack = new java.util.ArrayDeque<>();

        void record(FileOperation op) {
            undoStack.push(op);
            redoStack.clear();
        }

        boolean canUndo() {
            return !undoStack.isEmpty();
        }

        boolean canRedo() {
            return !redoStack.isEmpty();
        }

        void undo() {
            if (canUndo()) {
                FileOperation op = undoStack.pop();
                op.undo();
                redoStack.push(op);
            }
        }

        void redo() {
            if (canRedo()) {
                FileOperation op = redoStack.pop();
                op.redo();
                undoStack.push(op);
            }
        }
    }

    private interface FileOperation {
        void undo();

        void redo();
    }

    private static class CopyOperation implements FileOperation {
        private final Path source;
        private final Path target;

        CopyOperation(Path source, Path target) {
            this.source = source;
            this.target = target;
        }

        @Override
        public void undo() {
            try {
                if (Files.exists(target)) {
                    deleteRecursive(target);
                }
            } catch (IOException | UncheckedIOException ignored) {
            }
        }

        @Override
        public void redo() {
            try {
                copyRecursive(source, target);
            } catch (IOException | UncheckedIOException ignored) {
            }
        }
    }

    private static class MoveOperation implements FileOperation {
        private final Path source;
        private final Path target;
        private final UI_Main ide;

        MoveOperation(Path source, Path target, UI_Main ide) {
            this.source = source;
            this.target = target;
            this.ide = ide;
        }

        @Override
        public void undo() {
            try {
                if (Files.exists(target)) {
                    Files.move(target, source);
                    updateOpenTabsForMovedPath(ide, target, source);
                }
            } catch (IOException ignored) {
            }
        }

        @Override
        public void redo() {
            try {
                if (Files.exists(source)) {
                    Files.move(source, target);
                    updateOpenTabsForMovedPath(ide, source, target);
                }
            } catch (IOException ignored) {
            }
        }
    }

    private static class RenameOperation implements FileOperation {
        private final Path source;
        private final Path target;
        private final UI_Main ide;

        RenameOperation(Path source, Path target, UI_Main ide) {
            this.source = source;
            this.target = target;
            this.ide = ide;
        }

        @Override
        public void undo() {
            try {
                if (Files.exists(target)) {
                    DirectoryRename.move(target, source);
                    updateOpenTabsForMovedPath(ide, target, source);
                }
            } catch (IOException ignored) {
            }
        }

        @Override
        public void redo() {
            try {
                if (Files.exists(source)) {
                    DirectoryRename.move(source, target);
                    updateOpenTabsForMovedPath(ide, source, target);
                }
            } catch (IOException ignored) {
            }
        }
    }

    private static class DeleteOperation implements FileOperation {
        private final Path original;
        private final Path backup;
        private final UI_Main ide;

        DeleteOperation(Path original, Path backup, UI_Main ide) {
            this.original = original;
            this.backup = backup;
            this.ide = ide;
        }

        @Override
        public void undo() {
            try {
                if (Files.exists(backup)) {
                    Files.move(backup, original);
                    updateOpenTabsForMovedPath(ide, backup, original);
                }
            } catch (IOException ignored) {
            }
        }

        @Override
        public void redo() {
            try {
                if (Files.exists(original)) {
                    Files.move(original, backup);
                }
            } catch (IOException ignored) {
            }
        }
    }

    private static void deleteRecursive(Path path) throws IOException {
        if (Files.isDirectory(path)) {
            try (java.util.stream.Stream<Path> stream = Files.walk(path)) {
                stream.sorted(java.util.Comparator.reverseOrder()).forEach(p -> {
                    try {
                        Files.deleteIfExists(p);
                    } catch (IOException e) {
                        throw new UncheckedIOException(e);
                    }
                });
            }
        } else {
            Files.deleteIfExists(path);
        }
    }

    private static void setupEditorTabs(UI_Main ide) {
        ide.editorTabs = new TabPane();
        // Lets the generated stylesheet size the tab labels like the breadcrumb.
        ide.editorTabs.getStyleClass().add(Dim.Editor.TAB_PANE_CLASS);
        ide.editorTabs.setTabClosingPolicy(TabPane.TabClosingPolicy.ALL_TABS);
        ide.editorTabs.getSelectionModel().selectedItemProperty().addListener((obs, oldTab, newTab) -> {
            if (newTab == null)
                return;
            // Handle both TextArea and CodeArea (wrapped in VirtualizedScrollPane)
            Object content = newTab.getContent();
            ui.editor.EditorFileInfo info = (ui.editor.EditorFileInfo) newTab.getUserData();
            Path path = info != null ? info.path : null;
            if (path != null)
                EditorUIHelper.updateFooter(ide, path, path.getFileName().toString());
            else {
                ide.footerFileLabel.setText("");
            }
            // Add caret listener only for TextArea (CodeArea handles its own caret
            // tracking)
            if (content instanceof javafx.scene.control.TextArea editor) {
                editor.caretPositionProperty().addListener((o, oldPos, newPos) -> {
                    int caret = newPos.intValue();
                    String text = editor.getText(0, caret);
                    int line = text.split("\n", -1).length;
                    int col = caret - text.lastIndexOf('\n');
                    ide.footerCursorLabel.setText(" Ln " + line + ", Col " + col);
                });
            }
        });
    }

    private static void setupConsole(UI_Main ide) {
        // CLI consolidation: the Command Window's console is now built and owned
        // by ui.cli.CLI_Main (which also attaches the shared suggestion popup).
        CLI_Main.initConsole(ide);
    }

    private static CollapsiblePanel buildVariableExplorer(UI_Main ide) {
        return VariableExplorerBuilder.build(ide);
    }

    private static void setupKeyboardShortcuts(UI_Main ide) {
        MainWindowShortcutHandler.install(ide);
    }
}
