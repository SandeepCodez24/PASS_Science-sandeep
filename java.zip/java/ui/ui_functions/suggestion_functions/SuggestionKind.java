package ui.ui_functions.suggestion_functions;

/**
 * What a suggestion row actually <i>is</i>, so the popup can show the user a
 * MATLAB-style type marker instead of one undifferentiated icon.
 *
 * <p>
 * Until now every row carried only a coarse category string ({@code "Variable"},
 * {@code "Function"}), and {@code SuggestionCellRenderer} mapped both onto the
 * same two legacy PNGs. A declared {@code A = 1} and a declared
 * {@code D = "india"} were visually identical, and a user-written function was
 * indistinguishable from a built-in one. This enum is the missing axis.
 *
 * <h3>Where the value comes from</h3>
 * <ul>
 * <li>Variables: inferred from the literal on the right-hand side of {@code =}
 * by {@link LiteralTypeInference}, recorded at discovery time in
 * {@link VariableKindIndex}.</li>
 * <li>Functions / classes: decided by the producer — the built-in catalogue
 * publishes {@link #FUNCTION_BUILTIN}, source-discovered definitions publish
 * {@link #FUNCTION_USER} / {@link #CLASS_USER}.</li>
 * </ul>
 *
 * <p>
 * <b>Interim design.</b> Inference from the RHS literal is deliberately a
 * stop-gap. When the Variable Explorer's central data store lands, the kind
 * should be read from the authoritative workspace record instead — only
 * {@link VariableKindIndex#kindFor(String)} needs to change, because nothing
 * else in the suggestion pipeline knows how the kind was derived.
 */
public enum SuggestionKind {

    /** Integer literal: {@code A = 1}. */
    VARIABLE_INT("variable_int", "integer"),

    /** Real literal: {@code C = 3.14}, {@code B = 2.0}. */
    VARIABLE_FLOAT("variable_float", "double"),

    /** Quoted literal: {@code D = "india"}. */
    VARIABLE_STRING("variable_string", "string"),

    /** Boolean literal: {@code flag = true}. */
    VARIABLE_BOOLEAN("variable_boolean", "logical"),

    /** Brace literal: {@code m = {a: 1, b: 2}}. */
    VARIABLE_DICT("variable_dict", "dictionary"),

    /**
     * Declared, but the type cannot be read off the literal — a call result
     * ({@code அ = sin(0)}), an expression, or a forward reference. Never leave a
     * row without an icon; an unresolved variable is still a variable.
     */
    VARIABLE_GENERIC("variable_generic", "variable"),

    /** A function from the built-in catalogue. */
    FUNCTION_BUILTIN("function_builtin", "built-in function"),

    /** A function defined in the user's own source. */
    FUNCTION_USER("function_user", "user function"),

    /** A class defined in the user's own source. */
    CLASS_USER("class_user", "user class");

    private final String iconBaseName;
    private final String typeLabel;

    SuggestionKind(String iconBaseName, String typeLabel) {
        this.iconBaseName = iconBaseName;
        this.typeLabel = typeLabel;
    }

    /**
     * @return the icon file stem under {@code /icons/suggestions/}, without the
     *         size suffix or extension
     */
    public String getIconBaseName() {
        return iconBaseName;
    }

    /**
     * @return a short human type word, used to build descriptions such as
     *         {@code "1x1 double"}
     */
    public String getTypeLabel() {
        return typeLabel;
    }

    /** @return true when this kind describes a variable rather than callable code */
    public boolean isVariable() {
        return this == VARIABLE_INT
                || this == VARIABLE_FLOAT
                || this == VARIABLE_STRING
                || this == VARIABLE_BOOLEAN
                || this == VARIABLE_DICT
                || this == VARIABLE_GENERIC;
    }
}
