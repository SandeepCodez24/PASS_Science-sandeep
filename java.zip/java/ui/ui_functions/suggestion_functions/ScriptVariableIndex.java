package ui.ui_functions.suggestion_functions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import language.replace.Greek;
import language.replace.Malayalam;
import language.replace.Sanskrit;
import language.replace.Tamil;
import language.replace.Telugu;

/**
 * The single source of truth that answers, for any script glyph the user may
 * have declared as a variable:
 *
 * <ul>
 * <li><b>What did the user type to produce it?</b> &nbsp; {@code α → "alpha"},
 * {@code ஆ → "aa"}, {@code अ → "a"} &nbsp;— the <i>roman key</i>.</li>
 * <li><b>What should the popup say about it?</b> &nbsp;
 * {@code "alpha : Greek letter"}, {@code "aa : Tamil vowel"},
 * {@code "ki : Tamil consonant-vowel"} &nbsp;— the <i>description</i>.</li>
 * <li><b>Which script does it belong to?</b> &nbsp;— the <i>script order</i>,
 * used as a deterministic tie-break when ranking suggestions.</li>
 * </ul>
 *
 * <h3>Why this class exists</h3>
 * Before this class, {@code VariableDiscoveryEngine} indexed a discovered
 * variable by its <b>rendered glyph</b>. Typing {@code a} therefore matched
 * only the ASCII {@code A}; {@code α}, {@code அ}, {@code ஆ}, {@code अ} and
 * {@code आ} were invisible to the filter even though the user had declared all
 * of them with an {@code a}-prefixed command. Indexing by the roman key makes
 * every one of those variables answer to {@code a}, which is exactly what the
 * user expects.
 *
 * <p>
 * The index is derived from the very same {@code SYMBOL_MAP} tables that the
 * live-replacement engine uses, so it can never drift out of sync with the
 * language definitions.
 */
public final class ScriptVariableIndex {

    /** Deterministic script ordering used as a ranking tie-break. */
    public static final int ORDER_ENGLISH = 0;
    public static final int ORDER_GREEK = 1;
    public static final int ORDER_TAMIL = 2;
    public static final int ORDER_SANSKRIT = 3;
    public static final int ORDER_TELUGU = 4;
    public static final int ORDER_MALAYALAM = 5;
    public static final int ORDER_UNKNOWN = 9;

    /** Virama / pulli code points: the mark that makes a pure consonant. */
    private static final char TAMIL_PULLI = '\u0BCD';
    private static final char TELUGU_VIRAMA = '\u0C4D';
    private static final char MALAYALAM_VIRAMA = '\u0D4D';
    private static final char DEVANAGARI_VIRAMA = '\u094D';

    /** Sanskrit roman keys that are vowels (स्वर). */
    private static final Set<String> SANSKRIT_VOWELS = new HashSet<>(Arrays.asList(
            "a", "aa", "i", "ii", "u", "uu", "r", "rr", "l", "ll", "e", "ai", "o", "au"));

    /** Sanskrit roman keys that are compound letters (संयुक्ताक्षर). */
    private static final Set<String> SANSKRIT_COMPOUNDS = new HashSet<>(Arrays.asList(
            "ksha", "tra", "gya"));

    /** glyph → entry. */
    private static final Map<String, Entry> BY_GLYPH = new HashMap<>();

    /** Every entry, in registration order (Greek, Tamil, Sanskrit, Telugu, Malayalam). */
    private static final List<Entry> ALL = new ArrayList<>();

    private ScriptVariableIndex() {
        // Utility class – no instances.
    }

    /**
     * One indexed glyph: the character the editor displays, the roman key the
     * user typed to get it, the human description and the script it came from.
     */
    public static final class Entry {
        private final String glyph;
        private final String romanKey;
        private final String description;
        private final String fullCode;
        private final int scriptOrder;

        Entry(String glyph, String romanKey, String description, String fullCode, int scriptOrder) {
            this.glyph = glyph;
            this.romanKey = romanKey;
            this.description = description;
            this.fullCode = fullCode;
            this.scriptOrder = scriptOrder;
        }

        /** The rendered character, e.g. {@code "ஆ"}. */
        public String getGlyph() {
            return glyph;
        }

        /** The romanised search key, e.g. {@code "aa"}. */
        public String getRomanKey() {
            return romanKey;
        }

        /** Popup description, e.g. {@code "aa : Tamil vowel"}. */
        public String getDescription() {
            return description;
        }

        /** The full command form, e.g. {@code "\var(\tamil(\aa))"}. */
        public String getFullCode() {
            return fullCode;
        }

        /** Script ordering constant, e.g. {@link #ORDER_TAMIL}. */
        public int getScriptOrder() {
            return scriptOrder;
        }
    }

    static {
        indexGreek();
        indexTamil();
        indexSanskrit();
        indexTelugu();
        indexMalayalam();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PUBLIC LOOKUP API
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * The romanised key for a glyph.
     *
     * @param glyph a single rendered character such as {@code "α"} or {@code "ஆ"}
     * @return the roman key ({@code "alpha"}, {@code "aa"}), or {@code null}
     *         when the glyph is not a known script character
     */
    public static String romanKeyFor(String glyph) {
        Entry entry = BY_GLYPH.get(glyph);
        return entry == null ? null : entry.getRomanKey();
    }

    /**
     * The popup description for a glyph.
     *
     * @param glyph a single rendered character
     * @return e.g. {@code "ki : Tamil consonant-vowel"}, or {@code null} when
     *         the glyph is not a known script character
     */
    public static String descriptionFor(String glyph) {
        Entry entry = BY_GLYPH.get(glyph);
        return entry == null ? null : entry.getDescription();
    }

    /**
     * The description for a full command code, used when building the static
     * suggestion tables.
     *
     * @param fullCode   e.g. {@code "\var(\tamil(\ki))"}
     * @param glyph      the symbol the code produces
     * @param fallback   description to use when the glyph is unknown
     * @return the specific description, or {@code fallback}
     */
    public static String descriptionForCode(String fullCode, String glyph, String fallback) {
        String specific = descriptionFor(glyph);
        return specific != null ? specific : fallback;
    }

    /**
     * Script ordering constant for a glyph. Plain ASCII identifiers are treated
     * as English so they always sort first.
     *
     * @param text a variable name
     * @return one of the {@code ORDER_*} constants
     */
    public static int scriptOrderFor(String text) {
        if (text == null || text.isEmpty()) {
            return ORDER_UNKNOWN;
        }
        Entry entry = BY_GLYPH.get(text);
        if (entry != null) {
            return entry.getScriptOrder();
        }
        return isPlainAscii(text) ? ORDER_ENGLISH : ORDER_UNKNOWN;
    }

    /** True when every character is a plain ASCII identifier character. */
    public static boolean isPlainAscii(String text) {
        if (text == null || text.isEmpty()) {
            return false;
        }
        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);
            boolean ok = (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')
                    || (ch >= '0' && ch <= '9') || ch == '_';
            if (!ok) {
                return false;
            }
        }
        return true;
    }

    /**
     * Every romanised key that should match a typed prefix for this name.
     * For an ASCII name that is just the name itself; for a glyph it is the
     * roman key <i>and</i> the glyph (so a user who pastes {@code ஆ} still
     * finds it).
     *
     * @param name the variable name as it appears in the editor
     * @return one or two lower-cased search keys, never empty
     */
    public static List<String> searchKeysFor(String name) {
        List<String> keys = new ArrayList<>(2);
        if (name == null || name.isEmpty()) {
            return keys;
        }
        String roman = romanKeyFor(name);
        if (roman != null) {
            keys.add(roman.toLowerCase());
        }
        keys.add(name.toLowerCase());
        return keys;
    }

    /**
     * The primary ranking key for a name: the roman key when the name is a
     * script glyph, otherwise the name itself.
     *
     * @param name the variable name as it appears in the editor
     * @return the lower-cased key used for prefix matching and alphabetisation
     */
    public static String primaryKeyFor(String name) {
        if (name == null || name.isEmpty()) {
            return "";
        }
        String roman = romanKeyFor(name);
        return (roman != null ? roman : name).toLowerCase();
    }

    /** All indexed entries (defensive copy). */
    public static List<Entry> allEntries() {
        return new ArrayList<>(ALL);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // INDEX CONSTRUCTION
    // ─────────────────────────────────────────────────────────────────────────

    private static void indexGreek() {
        if (Greek.SYMBOL_MAP == null) {
            return;
        }
        // Stable order so "alpha" is indexed before "omega" for equal glyphs.
        for (Map.Entry<String, String> e : sorted(Greek.SYMBOL_MAP).entrySet()) {
            String code = e.getKey();
            String glyph = e.getValue();
            String roman = extractRomanKey(code, "\\var(\\", ")");
            if (roman == null) {
                continue;
            }
            register(glyph, roman, roman + " : Greek letter", code, ORDER_GREEK);
        }
    }

    private static void indexTamil() {
        indexIndic(Tamil.TAMIL_VOWEL_MAP, "\\var(\\tamil(", "Tamil", true,
                TAMIL_PULLI, ORDER_TAMIL);
        indexIndic(Tamil.TAMIL_CONSONANT_MAP, "\\var(\\tamil(", "Tamil", false,
                TAMIL_PULLI, ORDER_TAMIL);
    }

    private static void indexTelugu() {
        indexIndic(Telugu.TELUGU_VOWEL_MAP, "\\var(\\telugu(", "Telugu", true,
                TELUGU_VIRAMA, ORDER_TELUGU);
        indexIndic(Telugu.TELUGU_CONSONANT_MAP, "\\var(\\telugu(", "Telugu", false,
                TELUGU_VIRAMA, ORDER_TELUGU);
    }

    private static void indexMalayalam() {
        indexIndic(Malayalam.MALAYALAM_VOWEL_MAP, "\\var(\\malayalam(", "Malayalam", true,
                MALAYALAM_VIRAMA, ORDER_MALAYALAM);
        indexIndic(Malayalam.MALAYALAM_CONSONANT_MAP, "\\var(\\malayalam(", "Malayalam", false,
                MALAYALAM_VIRAMA, ORDER_MALAYALAM);
    }

    /**
     * Sanskrit keeps vowels, consonants, compounds and {@code ॐ} in one map, so
     * the category is decided from the roman key rather than from which map the
     * entry came out of.
     */
    private static void indexSanskrit() {
        if (Sanskrit.SYMBOL_MAP == null) {
            return;
        }
        for (Map.Entry<String, String> e : sorted(Sanskrit.SYMBOL_MAP).entrySet()) {
            String code = e.getKey();
            String glyph = e.getValue();
            // Sanskrit registers both \var(\sanskrit(\x)) and the legacy
            // \var(\sanskrit(x)). Index the preferred backslash form only.
            if (!code.startsWith("\\var(\\sanskrit(\\")) {
                continue;
            }
            String roman = extractRomanKey(code, "\\var(\\sanskrit(", "))");
            if (roman == null) {
                continue;
            }
            String category;
            if ("om".equals(roman)) {
                category = "Sanskrit symbol";
            } else if (SANSKRIT_VOWELS.contains(roman)) {
                category = "Sanskrit vowel";
            } else if (SANSKRIT_COMPOUNDS.contains(roman)) {
                category = "Sanskrit compound";
            } else if (containsVirama(glyph, DEVANAGARI_VIRAMA)) {
                category = "Sanskrit pure consonant";
            } else {
                category = "Sanskrit consonant";
            }
            register(glyph, roman, roman + " : " + category, code, ORDER_SANSKRIT);
        }
    }

    /**
     * Shared indexer for the Indic scripts, all of which share the same map
     * shape and the same vowel / consonant / consonant-vowel distinction.
     *
     * @param map        the symbol map to walk
     * @param prefix     the command prefix, e.g. {@code "\var(\tamil("}
     * @param scriptName human-readable script name used in the description
     * @param vowelMap   true when {@code map} is the vowel table
     * @param virama     the script's virama / pulli character
     * @param order      the script ordering constant
     */
    private static void indexIndic(Map<String, String> map, String prefix, String scriptName,
            boolean vowelMap, char virama, int order) {
        if (map == null) {
            return;
        }
        for (Map.Entry<String, String> e : sorted(map).entrySet()) {
            String code = e.getKey();
            String glyph = e.getValue();
            String roman = extractRomanKey(code, prefix, "))");
            if (roman == null) {
                continue;
            }
            String category;
            if (vowelMap) {
                category = scriptName + " vowel";
            } else if (containsVirama(glyph, virama)) {
                // க் / ക് / క్  – a consonant with its inherent vowel stripped.
                category = scriptName + " pure consonant";
            } else if (glyph.codePointCount(0, glyph.length()) > 1) {
                // கி / கா  – base consonant plus a dependent vowel sign.
                category = scriptName + " consonant-vowel";
            } else {
                // க  – bare consonant carrying its inherent vowel.
                category = scriptName + " consonant";
            }
            register(glyph, roman, roman + " : " + category, code, order);
        }
    }

    /**
     * Registers a glyph. The <b>shortest</b> roman key wins when two commands
     * produce the same glyph, because the shortest form is the one the user is
     * most likely to have typed and the one that reads best in the popup.
     */
    private static void register(String glyph, String roman, String description,
            String fullCode, int order) {
        if (glyph == null || glyph.isBlank() || roman == null || roman.isBlank()) {
            return;
        }
        Entry existing = BY_GLYPH.get(glyph);
        if (existing != null && existing.getRomanKey().length() <= roman.length()) {
            return;
        }
        Entry entry = new Entry(glyph, roman, description, fullCode, order);
        BY_GLYPH.put(glyph, entry);
        ALL.add(entry);
    }

    /**
     * Pulls the roman token out of a full command code.
     * {@code "\var(\tamil(\ki))"} with prefix {@code "\var(\tamil("} yields
     * {@code "ki"}.
     */
    private static String extractRomanKey(String code, String prefix, String suffix) {
        if (code == null || !code.startsWith(prefix)) {
            return null;
        }
        String token = code.substring(prefix.length());
        if (token.endsWith(suffix)) {
            token = token.substring(0, token.length() - suffix.length());
        }
        while (token.endsWith(")")) {
            token = token.substring(0, token.length() - 1);
        }
        if (token.startsWith("\\")) {
            token = token.substring(1);
        }
        return token.isBlank() ? null : token;
    }

    private static boolean containsVirama(String glyph, char virama) {
        return glyph != null && glyph.indexOf(virama) >= 0;
    }

    /** Symbol maps are HashMaps; sort so index construction is reproducible. */
    private static Map<String, String> sorted(Map<String, String> source) {
        List<String> keys = new ArrayList<>(source.keySet());
        keys.sort((a, b) -> {
            int byLength = Integer.compare(a.length(), b.length());
            return byLength != 0 ? byLength : a.compareTo(b);
        });
        Map<String, String> out = new LinkedHashMap<>();
        for (String key : keys) {
            out.put(key, source.get(key));
        }
        return out;
    }
}
