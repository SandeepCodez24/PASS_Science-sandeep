package ui.ui_functions.suggestion_functions;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The fixed fields and methods of the objects {@code nc.exe}'s
 * {@code load_*}, {@code io_detect} and {@code io_preview} return, for the
 * suggestion popup after {@code D.} ({@code docs/IO_Phase1_Frontend_Handover.md}
 * sections 4.7 and 5, {@code IO_Phase2_3_Frontend_Handover.md} sections 5 and 6).
 *
 * <p>
 * Only the names every file gives are listed. Column, key, tag, sheet and
 * variable names come from the file itself ({@code D.Max_Temp_C}), so they
 * are known only once the script has run.
 */
final class IoObjectMembers {

    private IoObjectMembers() {
    }

    /** One object class: its name, fixed fields and methods ({@code name(inputs)}). */
    record ObjectClass(String name, List<String> fields, List<String> methods) {
    }

    private static final List<String> DELIMITED = List.of("default", "sheets", "cols", "rows", "data", "schema",
            "boxes", "comments", "raw_lines", "file", "format", "dlm");
    private static final List<String> CONFIG = List.of("default", "sections", "key_order", "boxes", "comments",
            "env_vars", "file");
    private static final List<String> BINARY = List.of("bytes", "size", "endian", "file", "offset", "box_bytes",
            "header", "boxes", "dtype", "records");
    private static final List<String> BINARY_METHODS = List.of("view(dtype=\"uint8\", shape=\"\", offset=0, count=-1)",
            "slice_bytes(start, end)");
    private static final List<String> WORKBOOK = List.of("sheets", "default", "meta");
    private static final List<String> IMAGE = List.of("pixels", "tensor", "width", "height", "channels", "shape",
            "R", "G", "B", "A", "dpi", "color_space", "exif", "icc", "boxes", "bit_depth", "frames", "delay", "file",
            "format");
    private static final List<String> COLUMNAR = List.of("cols", "rows", "data", "schema", "default", "types",
            "groups", "stats", "kv_meta", "boxes", "codec", "created_by", "skipped");

    private static final Map<String, ObjectClass> BY_FUNCTION = new HashMap<>();

    static {
        ObjectClass delimited = new ObjectClass("NcDelimited", DELIMITED, List.of("sheet(name_or_number)"));
        for (String f : List.of("csv", "tsv", "txt", "dat")) {
            BY_FUNCTION.put("load_" + f, delimited);
        }
        BY_FUNCTION.put("load_json", new ObjectClass("NcJson",
                List.of("default", "key_order", "boxes", "file", "items"),
                List.of("keys()", "values()", "query(path)", "to_table(path=\"\")", "get(key)")));
        BY_FUNCTION.put("load_xml", new ObjectClass("NcXml",
                List.of("root", "comments", "boxes", "namespaces", "file"), List.of("xpath(expr)")));
        ObjectClass html = new ObjectClass("NcHtml",
                List.of("default", "tables", "table_names", "title", "meta", "boxes", "links", "images", "text",
                        "file", "root"),
                List.of("xpath(expr)", "select(css)", "table(name_or_index)"));
        BY_FUNCTION.put("load_html", html);
        BY_FUNCTION.put("load_htm", html);
        ObjectClass yaml = new ObjectClass("NcConfig", concat(CONFIG, List.of("docs", "anchors")), List.of());
        BY_FUNCTION.put("load_yaml", yaml);
        BY_FUNCTION.put("load_yml", yaml);
        BY_FUNCTION.put("load_ini", new ObjectClass("NcConfig", concat(CONFIG, List.of("defaults")), List.of()));
        BY_FUNCTION.put("load_bin", new ObjectClass("NcBinary", BINARY, BINARY_METHODS));
        BY_FUNCTION.put("load_custom", new ObjectClass("NcCustom", BINARY, BINARY_METHODS));

        List<String> sheet = List.of("sheet(name)");
        BY_FUNCTION.put("load_xlsx", new ObjectClass("NcWorkbook", WORKBOOK, sheet));
        BY_FUNCTION.put("load_xls", new ObjectClass("NcWorkbook", WORKBOOK, sheet));
        BY_FUNCTION.put("load_xlsm", new ObjectClass("NcWorkbook",
                concat(WORKBOOK, List.of("vba_macros", "vba_modules", "vba_project")), sheet));
        BY_FUNCTION.put("load_xlsb", new ObjectClass("NcWorkbook", concat(WORKBOOK, List.of("bin_blocks")), sheet));
        ObjectClass image = new ObjectClass("NcImage", IMAGE, List.of());
        for (String f : List.of("png", "jpg", "jpeg", "tiff", "bmp", "gif")) {
            BY_FUNCTION.put("load_" + f, image);
        }
        BY_FUNCTION.put("load_dicom", new ObjectClass("NcImage",
                concat(IMAGE, List.of("tags", "patient", "study", "modality")), List.of()));
        ObjectClass audio = new ObjectClass("NcAudio",
                List.of("wave", "y", "fs", "duration", "channels", "frames", "bits", "codec", "ch", "left", "right",
                        "t", "tags", "boxes", "cues"),
                List.of("slice(t1, t2)"));
        for (String f : List.of("wav", "flac", "ogg", "mp3")) {
            BY_FUNCTION.put("load_" + f, audio);
        }
        BY_FUNCTION.put("load_mat", new ObjectClass("NcMat",
                List.of("vars", "default", "header", "boxes", "version", "var_info", "file"), List.of("info(name)")));
        BY_FUNCTION.put("load_fig", new ObjectClass("NcFigure",
                List.of("axes", "default", "boxes", "legend", "colormap", "name", "file"), List.of("show()")));
        ObjectClass fits = new ObjectClass("NcFits", List.of("hdus", "hdu_names", "primary", "boxes", "file"),
                List.of());
        BY_FUNCTION.put("load_fits", fits);
        BY_FUNCTION.put("load_fit", fits);
        ObjectClass database = new ObjectClass("NcDatabase",
                List.of("tables", "views", "schemas", "boxes", "uri", "format", "schema_name"),
                List.of("query(sql, params=\"\")"));
        for (String f : List.of("sqlite", "postgresql", "mysql", "oracle", "sqlserver")) {
            BY_FUNCTION.put("load_" + f, database);
        }
        ObjectClass h5 = new ObjectClass("NcH5File",
                List.of("groups", "datasets", "attrs", "boxes", "format", "superblock", "swaths", "grids"),
                List.of("read(path=\"\", slice=\"\")"));
        for (String f : List.of("h5", "hdf", "he5")) {
            BY_FUNCTION.put("load_" + f, h5);
        }
        ObjectClass netcdf = new ObjectClass("NcNetCDF",
                List.of("vars", "dims", "coords", "attrs", "boxes", "format", "unlimited", "default"),
                List.of("read(var=\"\", slice=\"\")"));
        BY_FUNCTION.put("load_nc", netcdf);
        BY_FUNCTION.put("load_cdf", netcdf);
        BY_FUNCTION.put("load_parquet", new ObjectClass("NcParquet", COLUMNAR, List.of()));
        BY_FUNCTION.put("load_feather", new ObjectClass("NcFeather", COLUMNAR, List.of()));
        BY_FUNCTION.put("load_orc", new ObjectClass("NcOrc", COLUMNAR, List.of()));
        ObjectClass video = new ObjectClass("NcVideo",
                List.of("fps", "count", "width", "height", "duration", "codec", "fourcc", "format", "audio",
                        "subtitles", "chapters", "boxes", "decodable", "loaded", "frames", "has_audio", "audio_codec",
                        "file"),
                List.of("frame(i)", "at_time(sec)",
                        "read(frames=\"\", time=\"\", stride=1, roi=\"\", scale=\"\", gray=false)"));
        for (String f : List.of("mp4", "avi", "m4v", "mov")) {
            BY_FUNCTION.put("load_" + f, video);
        }
        ObjectClass shapes = new ObjectClass("NcShapefile",
                List.of("features", "geom", "attrs", "bbox", "crs", "epsg", "prj", "index_offsets", "boxes",
                        "encoding", "geom_type", "count"),
                List.of());
        for (String f : List.of("shp", "shx", "dbf")) {
            BY_FUNCTION.put("load_" + f, shapes);
        }
        ObjectClass raster = new ObjectClass("NcGeoRaster",
                List.of("raster", "bands", "crs", "epsg", "crs_name", "wkt", "transform", "bounds", "bounds_native",
                        "res", "nodata", "width", "height", "count", "dtype", "overviews", "tags", "boxes",
                        "georeferenced", "file"),
                List.of("sample(lon, lat)"));
        BY_FUNCTION.put("load_tif", raster);
        BY_FUNCTION.put("load_geotiff", raster);
        BY_FUNCTION.put("load_gpx", new ObjectClass("NcGpx",
                List.of("table", "tracks", "routes", "waypoints", "extensions", "boxes"), List.of()));
        BY_FUNCTION.put("load_kml", new ObjectClass("NcKml",
                List.of("table", "placemarks", "folders", "camera", "boxes"), List.of()));
        BY_FUNCTION.put("io_detect", new ObjectClass("NcDetection",
                List.of("format", "category", "confidence", "reason", "compressed", "available", "read", "load",
                        "save"),
                List.of()));
        BY_FUNCTION.put("io_preview", new ObjectClass("NcPreview",
                List.of("format", "kind", "cols", "rows", "total_rows", "boxes", "note", "code"), List.of()));
    }

    /**
     * @param function a called name, e.g. {@code load_csv}
     * @return the class of the object it returns, or null when it returns none
     */
    static ObjectClass forFunction(String function) {
        return function == null ? null : BY_FUNCTION.get(function);
    }

    private static List<String> concat(List<String> a, List<String> b) {
        List<String> out = new java.util.ArrayList<>(a);
        out.addAll(b);
        return List.copyOf(out);
    }
}
