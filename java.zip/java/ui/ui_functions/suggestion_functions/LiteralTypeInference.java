package ui.ui_functions.suggestion_functions;

import java.util.regex.Pattern;

/**
 * Infers a variable's {@link SuggestionKind} from the literal written on the
 * right-hand side of its declaration.
 *
 * <pre>
 *   A = 1;              &rarr; VARIABLE_INT
 *   B = 2.0;            &rarr; VARIABLE_FLOAT
 *   C = 3.14;           &rarr; VARIABLE_FLOAT
 *   D = "india";        &rarr; VARIABLE_STRING
 *   &#2965;&#3007; = "&#2970;&#3019;&#2996; &#2984;&#3006;&#2975;&#3009;";  &rarr; VARIABLE_STRING
 *   flag = true;        &rarr; VARIABLE_BOOLEAN
 *   m = {a: 1};         &rarr; VARIABLE_DICT
 *   &#2949; = sin(0);          &rarr; VARIABLE_GENERIC   (call result, not a literal)
 *   A = unit_matrix(5); &rarr; VARIABLE_GENERIC
 * </pre>
 *
 * <h3>Why literal-only, and why that is safe</h3>
 * This class deliberately refuses to guess. It reads a literal or it returns
 * {@link SuggestionKind#VARIABLE_GENERIC}; it never chases an identifier back to
 * its own declaration and never evaluates an expression. A wrong icon is worse
 * than a neutral one — it tells the user something false about their data — so
 * every ambiguous case degrades to the generic marker.
 *
 * <p>
 * <b>Interim by design.</b> Once the Variable Explorer's central data store
 * exists it will know the real runtime type, including for call results this
 * class must abstain on. At that point this becomes the fallback used only
 * before first evaluation.
 */
public final class LiteralTypeInference {

    private LiteralTypeInference() {
        // Utility class – no instances.
    }

    /** {@code 1}, {@code -5}, {@code +42}, {@code 007}. */
    private static final Pattern INT_LITERAL = Pattern.compile("^[+-]?\\d+$");

    /**
     * {@code 2.0}, {@code 3.14}, {@code .5}, {@code 1e-3}, {@code 6.02E23}.
     * A decimal point or an exponent is what separates this from an integer.
     */
    private static final Pattern FLOAT_LITERAL = Pattern.compile(
            "^[+-]?(?:\\d+\\.\\d*|\\.\\d+|\\d+)(?:[eE][+-]?\\d+)?$");

    /** Hexadecimal / binary / octal integers. */
    private static final Pattern RADIX_INT_LITERAL = Pattern.compile(
            "^[+-]?0[xXbBoO][0-9a-fA-F]+$");

    /**
     * Read the kind of a declaration from its right-hand side.
     *
     * @param rightHandSide the raw text after {@code =}, comment already stripped
     * @return the inferred kind, never null
     */
    public static SuggestionKind infer(String rightHandSide) {
        String value = normalise(rightHandSide);
        if (value.isEmpty()) {
            return SuggestionKind.VARIABLE_GENERIC;
        }

        // ── String: any quoted literal, in any script ────────────────────────
        // The closing quote must be present, otherwise the user is still typing
        // and we should not commit to a type yet.
        if (isQuoted(value, '"') || isQuoted(value, '\'')) {
            return SuggestionKind.VARIABLE_STRING;
        }

        // ── Boolean ─────────────────────────────────────────────────────────
        if ("true".equals(value) || "false".equals(value)) {
            return SuggestionKind.VARIABLE_BOOLEAN;
        }

        // ── Dictionary / map ────────────────────────────────────────────────
        // A brace literal. An empty {} is still unambiguously a dictionary.
        if (value.startsWith("{") && value.endsWith("}")) {
            return SuggestionKind.VARIABLE_DICT;
        }

        // ── Numbers ─────────────────────────────────────────────────────────
        if (RADIX_INT_LITERAL.matcher(value).matches()) {
            return SuggestionKind.VARIABLE_INT;
        }
        if (INT_LITERAL.matcher(value).matches()) {
            return SuggestionKind.VARIABLE_INT;
        }
        if (FLOAT_LITERAL.matcher(value).matches()) {
            return SuggestionKind.VARIABLE_FLOAT;
        }

        // A call, an expression, a bare identifier, a bracket literal: all
        // unknown until the engine evaluates them.
        return SuggestionKind.VARIABLE_GENERIC;
    }

    /**
     * Take everything after the first {@code =} of a declaration line.
     *
     * @param line the declaration line, comment already stripped
     * @return the right-hand side, or "" when the line has no usable {@code =}
     */
    public static String rightHandSideOf(String line) {
        if (line == null) {
            return "";
        }
        int eq = indexOfAssignment(line);
        if (eq < 0 || eq + 1 >= line.length()) {
            return "";
        }
        return line.substring(eq + 1);
    }

    /**
     * Locates the assignment {@code =}, skipping the comparison operators
     * {@code ==}, {@code !=}, {@code <=} and {@code >=} so a condition is never
     * mistaken for a declaration.
     *
     * @param line the line to scan
     * @return the index of the assignment operator, or -1
     */
    private static int indexOfAssignment(String line) {
        for (int i = 0; i < line.length(); i++) {
            if (line.charAt(i) != '=') {
                continue;
            }
            boolean partOfComparison =
                    (i + 1 < line.length() && line.charAt(i + 1) == '=')
                            || (i > 0 && "=!<>+-*/".indexOf(line.charAt(i - 1)) >= 0);
            if (!partOfComparison) {
                return i;
            }
        }
        return -1;
    }

    /** Strips whitespace and one trailing statement terminator. */
    private static String normalise(String rightHandSide) {
        if (rightHandSide == null) {
            return "";
        }
        String value = rightHandSide.trim();
        while (value.endsWith(";")) {
            value = value.substring(0, value.length() - 1).trim();
        }
        return value;
    }

    /** True when the value opens and closes with the given quote character. */
    private static boolean isQuoted(String value, char quote) {
        return value.length() >= 2
                && value.charAt(0) == quote
                && value.charAt(value.length() - 1) == quote;
    }
}
