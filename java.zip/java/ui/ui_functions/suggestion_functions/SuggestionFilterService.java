package ui.ui_functions.suggestion_functions;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import ui.ui_functions.FunctionProvider;
import ui.ui_functions.SuggestionProvider.Suggestion;
import ui.ui_functions.SuggestionProvider.SuggestionContext;
import ui.ui_functions.suggestion_functions.SuggestionSettings.Group;

/**
 * Filters, ranks and returns suggestions for a given input and context.
 *
 * <h3>What changed: a name typed in full is not offered back</h3>
 * Once the typed word <b>is</b> a complete name -- exactly, case included --
 * that row is dropped, because accepting it would change nothing. Longer
 * names that still start with the typed text stay, so with {@code A1} and
 * {@code A10}..{@code A17} declared:
 *
 * <pre>
 *   typed  A      popup  A1, A10 ... A17
 *   typed  A1     popup  A10 ... A17          (A1 itself is gone)
 *   typed  A11    popup  closed               (nothing longer matches)
 *   typed  a11    popup  A11                  (case differs: not a full match)
 *   typed  sqr    popup  sqrt()               (sqr() itself is gone)
 *   typed  sqrt   popup  closed
 * </pre>
 *
 * The rule covers every row the user can name in full: declared and styled
 * variables, class members, user functions, methods and classes, built-in
 * functions and keywords, and {@code .nc} scripts. Script letters and
 * {@code \var(} / {@code \con(} rows are untouched, since accepting them
 * produces a glyph or a command rather than the text already typed. The row
 * is removed <i>before</i> the fifteen-row limit is applied, so it never costs
 * a longer match its place. The editor and the Command Window both reach this
 * class through {@code SuggestionPopup}, so both behave the same way; an empty
 * result closes the popup as it always has.
 *
 * <h3>Earlier change: prefix match only</h3>
 * Every producer admits a row only when its key <b>starts with</b> what was
 * typed. {@code sq} now lists {@code sqr()} and {@code sqrt()} and nothing
 * else; it used to list anything <i>containing</i> the letters as well. Script
 * letters still match on their roman key, so {@code a} still surfaces
 * {@code A, &#945;, &#2949;, &#2950;, &#2309;, &#2310;}, and inside
 * {@code \var(\tamil(\k} the Tamil rows still narrow on {@code k}.
 *
 * <h3>What changed: script files</h3>
 * {@code .nc} scripts in the working folder are offered by name (without
 * {@code .nc}) through {@link NcFileIndex}, in their own tier below variables
 * and functions. They are governed by {@link Group#FILES}. The editor passes
 * the name of the file being edited, which is never offered; the Command
 * Window passes nothing. Files appear only in the plain code context, never
 * inside {@code \var(}, {@code \con(}, a styled group or after {@code Owner.}.
 *
 * <h3>Earlier change: the user chooses the groups</h3>
 * Every producer below belongs to exactly one {@link SuggestionSettings}
 * group, and runs only while that group is ticked:
 *
 * <pre>
 *   Variables          declared variables, styled variables, class members
 *   Functions          built-ins, keywords and operators, user functions,
 *                      user classes, class methods
 *   Script files       .nc scripts in the working folder
 *   UniCode Constants  \var( / \con( commands, script commands, script
 *                      letters, physics constants, sub/superscript digits,
 *                      recently used symbols
 * </pre>
 *
 * The gate sits on the producers rather than on the finished list, so a
 * switched-off group costs nothing and cannot crowd a ticked group out of the
 * fifteen-row limit. With every group off the result is always empty.
 *
 * <h3>What changed: the user's own functions and classes</h3>
 * <ol>
 * <li><b>User functions are offered as {@code f(x)}.</b> They sit in the same
 * tier as declared variables -- the user wrote them -- above the built-in
 * catalogue.</li>
 * <li><b>User classes are offered by name.</b></li>
 * <li><b>{@code A.} completes members.</b> Once the input has the form
 * {@code Owner.prefix}, and {@code Owner} is a class in this file (or a
 * variable built from one, {@code r = A(3)}), only that class's members are
 * listed: the variables its {@code base} declares, then its methods.
 * {@code base} and {@code info} themselves never appear. An owner that is not
 * a known class yields no rows, so the popup closes instead of offering
 * unrelated names after a dot.</li>
 * </ol>
 *
 * <h3>Earlier changes</h3>
 * <ol>
 * <li><b>Script variables are matched by their roman key.</b> A declared
 * {@code ஆ} carries the search key {@code "aa"}, a declared {@code α} carries
 * {@code "alpha"}. One typed {@code a} therefore surfaces
 * {@code A, α, அ, ஆ, अ, आ} together instead of only the ASCII {@code A}.</li>
 * <li><b>Ordering moved to {@link SuggestionRanker}.</b> Tier first
 * (variables &rarr; recents &rarr; functions &rarr; commands), then exact match,
 * prefix, key length, case, script and alphabetical order inside the tier.</li>
 * <li><b>{@code \var(\} now offers the script commands.</b>
 * {@code \tamil(}, {@code \sanskrit(}, {@code \telugu(} and
 * {@code \malayalam(} are listed above the Greek letters, so the user can reach
 * any script from the one entry point.</li>
 * <li><b>Descriptions are specific.</b> Rows read {@code "alpha : Greek
 * letter"} and {@code "ki : Tamil consonant-vowel"} instead of a shared group
 * label.</li>
 * </ol>
 */
public final class SuggestionFilterService {

    private SuggestionFilterService() {
        // Utility class – no instances.
    }

    /** Maximum rows the popup will ever show. */
    private static final int MAX_RESULTS = 15;

    /** Sentinel declaration order for rows that are not declared variables. */
    private static final int NO_DECLARATION = Integer.MAX_VALUE;

    /** {@code Owner.prefix}: member completion. The prefix may be empty. */
    private static final Pattern MEMBER_ACCESS = Pattern.compile(
            "^([\\p{L}_][\\p{L}\\p{M}\\p{N}_]*)\\.([\\p{L}\\p{M}\\p{N}_]*)$");

    /** The script entry commands offered right after {@code \var(\}. */
    private static final List<String[]> SCRIPT_COMMANDS = Arrays.asList(
            new String[] { "\\tamil(", "tamil", "Tamil script" },
            new String[] { "\\sanskrit(", "sanskrit", "Sanskrit script" },
            new String[] { "\\telugu(", "telugu", "Telugu script" },
            new String[] { "\\malayalam(", "malayalam", "Malayalam script" });

    /**
     * Get suggestions matching the current input, filtered by context.
     *
     * @param input    the current text being typed
     * @param fullText the full code text for context detection
     * @return list of matching suggestions sorted by relevance
     */
    public static List<Suggestion> getSuggestionsFiltered(String input, String fullText) {
        return getSuggestionsFiltered(input, fullText, null);
    }

    /**
     * As {@link #getSuggestionsFiltered(String, String)}, naming the script
     * being edited so it is not offered back to itself.
     *
     * @param input        the current text being typed
     * @param fullText     the full code text for context detection
     * @param excludedFile the file being edited ({@code AAAA} or
     *                     {@code AAAA.nc}); null to exclude nothing, as the
     *                     Command Window does
     * @return list of matching suggestions sorted by relevance
     */
    public static List<Suggestion> getSuggestionsFiltered(String input, String fullText, String excludedFile) {
        if (input == null || !SuggestionSettings.anyPopupGroupEnabled()) {
            return new ArrayList<>();
        }

        SuggestionContext context = ContextDetector.detectContext(fullText);
        // The word exactly as typed, case intact, for the full-name rule.
        String typed = input.trim();

        Matcher memberAccess = MEMBER_ACCESS.matcher(typed);
        if (memberAccess.matches()) {
            return getMemberSuggestions(memberAccess.group(1), memberAccess.group(2), typed);
        }

        if (input.startsWith("\\")) {
            if (context == SuggestionContext.GENERAL) {
                return getBackslashCommandSuggestions(input);
            }
            String normalizedInput = normalizeSuggestionInput(input);
            return getSuggestionsWithContext(normalizedInput, context, excludedFile, typed);
        }

        String normalizedInput = normalizeSuggestionInput(input);
        if (normalizedInput.isEmpty()) {
            if (isSymbolContext(context)) {
                return getSuggestionsWithContext("", context, excludedFile, typed);
            }
            return new ArrayList<>();
        }
        return getSuggestionsWithContext(normalizedInput, context, excludedFile, typed);
    }

    private static boolean isSymbolContext(SuggestionContext context) {
        return context == SuggestionContext.GREEK
                || context == SuggestionContext.TAMIL
                || context == SuggestionContext.SANSKRIT
                || context == SuggestionContext.HINDI
                || context == SuggestionContext.TELUGU
                || context == SuggestionContext.MALAYALAM
                || context == SuggestionContext.UNICONSTANT;
    }

    private static List<Suggestion> getBackslashCommandSuggestions(String input) {
        if (!SuggestionSettings.isEnabled(Group.UNICODE)) {
            return new ArrayList<>();
        }
        String prefix = input == null ? "" : input.substring(1).toLowerCase();
        List<Suggestion> results = new ArrayList<>();
        if (prefix.isEmpty() || prefix.startsWith("v")) {
            results.add(new Suggestion("\\var(", "Start variable symbol context", "\\var(", "SpecialCommand"));
        }
        if (prefix.isEmpty() || prefix.startsWith("c")) {
            results.add(new Suggestion("\\con(", "Start physics constant context", "\\con(", "SpecialCommand"));
        }
        return results;
    }

    private static String normalizeSuggestionInput(String input) {
        String normalized = input.trim().toLowerCase();
        // Strip leading backslash (from patterns like \con(\ )
        if (normalized.startsWith("\\")) {
            normalized = normalized.substring(1);
        }
        while (!normalized.isEmpty()) {
            char last = normalized.charAt(normalized.length() - 1);
            if (last == '_' || last == '^') {
                normalized = normalized.substring(0, normalized.length() - 1);
            } else {
                break;
            }
        }
        return normalized;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // MAIN QUERY
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Get suggestions for a specific context.
     *
     * @param input        the current text being typed (already normalised, lower case)
     * @param context      the detected context
     * @param excludedFile the script being edited, never offered; may be null
     * @param typed        the word exactly as typed; a row naming it in full is dropped
     * @return list of matching suggestions sorted by the ranking model
     */
    private static List<Suggestion> getSuggestionsWithContext(String input, SuggestionContext context,
            String excludedFile, String typed) {
        String lowerInput = input == null ? "" : input.toLowerCase();
        List<SuggestionRanker.Ranked> rows = new ArrayList<>();

        boolean editorContext = context == SuggestionContext.GENERAL
                || context == SuggestionContext.SUBSCRIPT
                || context == SuggestionContext.SUPERSCRIPT;

        boolean variables = SuggestionSettings.isEnabled(Group.VARIABLES);
        boolean functions = SuggestionSettings.isEnabled(Group.FUNCTIONS);
        boolean unicode = SuggestionSettings.isEnabled(Group.UNICODE);
        boolean files = SuggestionSettings.isEnabled(Group.FILES);

        if (editorContext) {
            if (variables) {
                addStyledVariables(rows, lowerInput);
                addDeclaredVariables(rows, lowerInput);
            }
            if (functions) {
                addUserFunctions(rows, lowerInput);
                addUserClasses(rows, lowerInput);
            }
            if (unicode) {
                addRecentlyUsed(rows, lowerInput);
            }
            if (functions) {
                addFunctions(rows, input, lowerInput);
            }
            // Scripts belong to plain code only: not inside a styled group.
            if (files && context == SuggestionContext.GENERAL && !lowerInput.isEmpty()) {
                addScriptFiles(rows, lowerInput, excludedFile);
            }
        }

        if (unicode) {
            if (context == SuggestionContext.GREEK) {
                // \var(\  – let the user pivot into any other script from here.
                addScriptCommands(rows, lowerInput);
            }
            addStaticSymbols(rows, lowerInput, context);
        }

        dropCompletedName(rows, typed);
        return SuggestionRanker.order(rows, MAX_RESULTS);
    }

    // ── Tier 0: styled variables ─────────────────────────────────────────────

    private static void addStyledVariables(List<SuggestionRanker.Ranked> rows, String lowerInput) {
        for (Map.Entry<String, String> entry : SuggestionRegistry.discoveredStyledVariables.entrySet()) {
            String raw = entry.getKey();
            String display = entry.getValue();
            if (!startsWith(raw, lowerInput) && !startsWith(display, lowerInput)) {
                continue;
            }
            Suggestion suggestion = new Suggestion(raw, "Styled variable", display, "StyledVariable",
                    VariableKindIndex.kindFor(raw));
            rows.add(new SuggestionRanker.Ranked(suggestion,
                    SuggestionRanker.TIER_STYLED_VARIABLE,
                    raw, display,
                    ScriptVariableIndex.ORDER_ENGLISH, NO_DECLARATION, lowerInput));
        }
    }

    // ── Tier 1: variables declared above the caret ───────────────────────────

    /**
     * The heart of the fix. Each discovered variable is matched against its
     * roman search keys rather than against its rendered glyph, and it carries
     * a script-specific description into the popup.
     */
    private static void addDeclaredVariables(List<SuggestionRanker.Ranked> rows, String lowerInput) {
        for (DiscoveredVariable variable : SuggestionRegistry.discoveredVariableInfo.values()) {
            // Prefix only: the roman keys (alpha, aa, ki ...) are prefixes too,
            // so every a-rooted variable still matches a typed 'a'.
            if (!variable.matchesPrefix(lowerInput)) {
                continue;
            }
            // The code is the rendered glyph itself, so accepting the row
            // inserts α / ஆ / अ directly rather than the \var(...) source form.
            Suggestion suggestion = new Suggestion(
                    variable.getName(),
                    variable.getDescription(),
                    variable.getName(),
                    "Variable",
                    VariableKindIndex.kindFor(variable.getName()));
            rows.add(new SuggestionRanker.Ranked(suggestion,
                    SuggestionRanker.TIER_VARIABLE,
                    variable.getPrimaryKey(), variable.getName(),
                    variable.getScriptOrder(), variable.getDeclarationOrder(), lowerInput));
        }
    }

    // ── Tier 1: the user's own functions and classes ─────────────────────────

    /**
     * Functions defined in this file. Accepting a row inserts {@code f(} with
     * the caret inside, exactly like a built-in.
     */
    private static void addUserFunctions(List<SuggestionRanker.Ranked> rows, String lowerInput) {
        for (DiscoveredFunction function : SuggestionRegistry.discoveredFunctions.values()) {
            if (!startsWith(function.getName(), lowerInput) && !startsWith(function.getPrimaryKey(), lowerInput)) {
                continue;
            }
            Suggestion suggestion = new Suggestion(
                    function.getName(),
                    "User function",
                    function.signature(),
                    "UserFunction",
                    SuggestionKind.FUNCTION_USER);
            rows.add(new SuggestionRanker.Ranked(suggestion,
                    SuggestionRanker.TIER_VARIABLE,
                    function.getPrimaryKey(), function.getName(),
                    ScriptVariableIndex.ORDER_ENGLISH, function.getDeclarationOrder(), lowerInput));
        }
    }

    /** Classes defined in this file, inserted by name. */
    private static void addUserClasses(List<SuggestionRanker.Ranked> rows, String lowerInput) {
        for (DiscoveredClass declared : SuggestionRegistry.discoveredClasses.values()) {
            if (!startsWith(declared.getName(), lowerInput) && !startsWith(declared.getPrimaryKey(), lowerInput)) {
                continue;
            }
            Suggestion suggestion = new Suggestion(
                    declared.getName(),
                    "User class",
                    declared.getName(),
                    "UserClass",
                    SuggestionKind.CLASS_USER);
            rows.add(new SuggestionRanker.Ranked(suggestion,
                    SuggestionRanker.TIER_VARIABLE,
                    declared.getPrimaryKey(), declared.getName(),
                    ScriptVariableIndex.ORDER_ENGLISH, declared.getDeclarationOrder(), lowerInput));
        }
    }

    // ── Member completion: Owner.prefix ──────────────────────────────────────

    /**
     * Members of one class. Variables declared in {@code base} come first, then
     * methods. Each row's code is the full {@code Owner.member} text, so
     * accepting it replaces exactly what was typed.
     *
     * @param owner  the text before the dot, as typed
     * @param prefix the text after the dot, possibly empty
     * @param typed  {@code Owner.prefix} exactly as typed; a member named in full is dropped
     * @return the matching members, or an empty list for an unknown owner
     */
    private static List<Suggestion> getMemberSuggestions(String owner, String prefix, String typed) {
        DiscoveredClass declared = SuggestionRegistry.resolveClass(owner);
        if (declared == null) {
            return new ArrayList<>();
        }

        String lowerPrefix = prefix == null ? "" : prefix.toLowerCase();
        List<SuggestionRanker.Ranked> rows = new ArrayList<>();
        boolean variables = SuggestionSettings.isEnabled(Group.VARIABLES);
        boolean functions = SuggestionSettings.isEnabled(Group.FUNCTIONS);

        for (Map.Entry<String, Integer> entry : declared.getMembers().entrySet()) {
            if (!variables) {
                break;
            }
            String member = entry.getKey();
            if (!startsWith(member, lowerPrefix)) {
                continue;
            }
            String code = owner + "." + member;
            Suggestion suggestion = new Suggestion(
                    code,
                    "Member of " + declared.getName(),
                    code,
                    "ClassMember",
                    VariableKindIndex.kindFor(declared.getName() + "." + member));
            rows.add(new SuggestionRanker.Ranked(suggestion,
                    SuggestionRanker.TIER_VARIABLE,
                    member, member,
                    ScriptVariableIndex.scriptOrderFor(member), entry.getValue(), lowerPrefix));
        }

        for (DiscoveredFunction method : declared.getMethods().values()) {
            if (!functions) {
                break;
            }
            if (!startsWith(method.getName(), lowerPrefix) && !startsWith(method.getPrimaryKey(), lowerPrefix)) {
                continue;
            }
            Suggestion suggestion = new Suggestion(
                    owner + "." + method.getName(),
                    "Method of " + declared.getName(),
                    owner + "." + method.signature(),
                    "UserFunction",
                    SuggestionKind.FUNCTION_USER);
            rows.add(new SuggestionRanker.Ranked(suggestion,
                    SuggestionRanker.TIER_FUNCTION,
                    method.getPrimaryKey(), method.getName(),
                    ScriptVariableIndex.ORDER_ENGLISH, method.getDeclarationOrder(), lowerPrefix));
        }

        dropCompletedName(rows, typed);
        return SuggestionRanker.order(rows, MAX_RESULTS);
    }

    // ── Tier 2: recently used symbols ────────────────────────────────────────

    private static void addRecentlyUsed(List<SuggestionRanker.Ranked> rows, String lowerInput) {
        for (Map.Entry<String, String> entry : SuggestionRegistry.recentlyUsedSymbols.entrySet()) {
            String simpleName = entry.getKey();
            String fullFormat = entry.getValue();
            if (!fullFormat.startsWith("\\var(")) {
                continue;
            }
            if (!startsWith(simpleName, lowerInput)) {
                continue;
            }
            String symbolDisplay = SuggestionRegistry.recentlyUsedSymbolDisplays
                    .getOrDefault(simpleName, simpleName);
            String description = ScriptVariableIndex.descriptionForCode(
                    fullFormat, symbolDisplay, "Recently Used");
            Suggestion suggestion = new Suggestion(fullFormat, description, symbolDisplay, "Variable");
            rows.add(new SuggestionRanker.Ranked(suggestion,
                    SuggestionRanker.TIER_RECENTLY_USED,
                    simpleName, symbolDisplay,
                    ScriptVariableIndex.scriptOrderFor(symbolDisplay), NO_DECLARATION, lowerInput));
        }
    }

    // ── Tier 3: built-in functions ───────────────────────────────────────────

    private static void addFunctions(List<SuggestionRanker.Ranked> rows, String input, String lowerInput) {
        List<String> matchingFunctions = FunctionProvider.getFilteredFunctions(input);
        for (String funcKey : matchingFunctions) {
            String description = FunctionProvider.getFunctionDescription(funcKey);
            String displayName = FunctionProvider.getFunctionDisplayName(funcKey);
            // Belt and braces: whatever FunctionProvider's own filter admits,
            // only a name that starts with the typed text is shown.
            if (!startsWith(FunctionProvider.extractFunctionName(funcKey), lowerInput)
                    && !startsWith(displayName, lowerInput)) {
                continue;
            }
            Suggestion suggestion = new Suggestion(funcKey, description, displayName, "Function",
                    SuggestionKind.FUNCTION_BUILTIN);
            rows.add(new SuggestionRanker.Ranked(suggestion,
                    SuggestionRanker.TIER_FUNCTION,
                    funcKey, displayName,
                    ScriptVariableIndex.ORDER_ENGLISH, NO_DECLARATION, lowerInput));
        }
    }

    // ── Tier 4: script entry commands after \var(\ ───────────────────────────

    /**
     * Offers {@code \tamil(}, {@code \sanskrit(}, {@code \telugu(} and
     * {@code \malayalam(} while the caret sits in {@code \var(\}. Previously
     * only Greek letters appeared there, so the other scripts were unreachable
     * unless the whole command was typed from memory.
     */
    private static void addScriptCommands(List<SuggestionRanker.Ranked> rows, String lowerInput) {
        for (String[] command : SCRIPT_COMMANDS) {
            String code = command[0];
            String key = command[1];
            String description = command[2];
            if (!key.startsWith(lowerInput) && !lowerInput.isEmpty()) {
                continue;
            }
            Suggestion suggestion = new Suggestion(code, description, code, "SpecialCommand");
            rows.add(new SuggestionRanker.Ranked(suggestion,
                    SuggestionRanker.TIER_COMMAND,
                    key, code,
                    ScriptVariableIndex.ORDER_ENGLISH, NO_DECLARATION, lowerInput));
        }
    }

    // ── Tier 4/5: the static symbol tables ───────────────────────────────────

    /**
     * Walks {@link SuggestionRegistry#allSuggestions} and keeps only what the
     * current context allows. Script symbols are matched on their roman key
     * ({@code alpha}, {@code ki}) rather than on the raw command string, so
     * {@code \var(} noise can no longer produce phantom matches.
     */
    private static void addStaticSymbols(List<SuggestionRanker.Ranked> rows, String lowerInput,
            SuggestionContext context) {
        boolean symbolContextHasHits = false;
        List<SuggestionRanker.Ranked> simpleFallbacks = new ArrayList<>();

        for (Suggestion s : SuggestionRegistry.allSuggestions) {
            String category = s.getCategory();
            if (!categoryAllowed(category, context)) {
                continue;
            }

            String matchKey = matchKeyFor(s);
            if (!symbolPrefixMatch(matchKey, lowerInput)) {
                continue;
            }

            boolean isSimpleFallback = category != null && category.endsWith("Simple");
            int tier = isSimpleFallback ? SuggestionRanker.TIER_OTHER : SuggestionRanker.TIER_COMMAND;

            String display = s.getDisplay();
            SuggestionRanker.Ranked row = new SuggestionRanker.Ranked(s, tier,
                    matchKey, display,
                    ScriptVariableIndex.scriptOrderFor(display), NO_DECLARATION, lowerInput);

            if (isSimpleFallback) {
                simpleFallbacks.add(row);
            } else {
                symbolContextHasHits = true;
                rows.add(row);
            }
        }

        // When the real script symbols matched, the duplicate simple-name rows
        // are pure noise and are dropped.
        if (!symbolContextHasHits) {
            rows.addAll(simpleFallbacks);
        }
    }

    /**
     * The token a static suggestion should be matched against: the roman key
     * for a script glyph, the constant name for a physics constant, and the
     * code itself for anything else.
     */
    private static String matchKeyFor(Suggestion s) {
        String display = s.getDisplay();
        String roman = display == null ? null : ScriptVariableIndex.romanKeyFor(display);
        if (roman != null) {
            return roman;
        }
        String code = s.getCode();
        if ("Uniconstant".equals(s.getCategory()) && code.startsWith("\\con(\\") && code.endsWith(")")) {
            return code.substring("\\con(\\".length(), code.length() - 1);
        }
        return code;
    }

    /** Whether a suggestion category may appear in the given context. */
    private static boolean categoryAllowed(String category, SuggestionContext context) {
        if (category == null) {
            return false;
        }
        switch (context) {
            case GREEK:
                return "Greek".equals(category) || "GreekSimple".equals(category);
            case TAMIL:
                return "Tamil".equals(category) || "TamilSimple".equals(category);
            case SANSKRIT:
                return "Sanskrit".equals(category) || "SanskritSimple".equals(category);
            case HINDI:
                return "Hindi".equals(category) || "HindiSimple".equals(category);
            case TELUGU:
                return "Telugu".equals(category) || "TeluguSimple".equals(category);
            case MALAYALAM:
                return "Malayalam".equals(category) || "MalayalamSimple".equals(category);
            case UNICONSTANT:
                return "Uniconstant".equals(category);
            case SUBSCRIPT:
            case SUPERSCRIPT:
                // Symbol completion stays available inside a styled group.
                return "Greek".equals(category) || "GreekSimple".equals(category)
                        || "Tamil".equals(category) || "TamilSimple".equals(category)
                        || "Math".equals(category);
            case GENERAL:
            default:
                // GENERAL means the caret is NOT inside \var(...) or \con(...),
                // so the raw symbol tables must stay out of the way. Declared
                // variables already cover every script the user actually used.
                return !isScriptCategory(category) && !"Uniconstant".equals(category);
        }
    }

    private static boolean isScriptCategory(String category) {
        return "Greek".equals(category) || "GreekSimple".equals(category)
                || "Tamil".equals(category) || "TamilSimple".equals(category)
                || "Sanskrit".equals(category) || "SanskritSimple".equals(category)
                || "Telugu".equals(category) || "TeluguSimple".equals(category)
                || "Malayalam".equals(category) || "MalayalamSimple".equals(category)
                || "Hindi".equals(category) || "HindiSimple".equals(category);
    }

    // ── Tier 4: .nc scripts in the working folder ────────────────────────────

    /**
     * Scripts whose name starts with the typed text. Accepting a row inserts
     * the bare name ({@code sct_01}), which the Command Window runs as is.
     *
     * @param excludedFile the script being edited; never offered
     */
    private static void addScriptFiles(List<SuggestionRanker.Ranked> rows, String lowerInput, String excludedFile) {
        int order = 0;
        for (NcFileIndex.Entry entry : NcFileIndex.matching(lowerInput, excludedFile)) {
            String name = entry.getName();
            Path folder = entry.getFile().getParent();
            String description = entry.isInWorkingFolder() || folder == null || folder.getFileName() == null
                    ? "NC script"
                    : "NC script \u2013 " + folder.getFileName();
            Suggestion suggestion = new Suggestion(name, description, name, "NcFile", SuggestionKind.NC_FILE);
            rows.add(new SuggestionRanker.Ranked(suggestion,
                    SuggestionRanker.TIER_FILE,
                    name, name,
                    ScriptVariableIndex.ORDER_ENGLISH, order++, lowerInput));
        }
    }

    // ── Matching helpers ─────────────────────────────────────────────────────

    /** Case-insensitive prefix test; a null candidate never matches. */
    private static boolean startsWith(String candidate, String lowerPrefix) {
        if (candidate == null) {
            return false;
        }
        return lowerPrefix == null || lowerPrefix.isEmpty()
                || candidate.toLowerCase().startsWith(lowerPrefix);
    }

    /**
     * Prefix test for the static symbol tables.
     *
     * <p>
     * A symbol's key may be a roman name ({@code alpha}) or a full command
     * ({@code \var(\tamil(\ki))}), and the typed text may carry the context
     * it was typed in ({@code tamil(\k}). Both are reduced to their last
     * segment -- the part after the final backslash, closing brackets removed
     * -- and compared as prefixes: {@code k} against {@code ki}. This keeps
     * script completion exactly as selective as before while dropping the
     * mid-word hits that {@code contains} allowed.
     */
    private static boolean symbolPrefixMatch(String key, String lowerInput) {
        String query = querySegment(lowerInput == null ? "" : lowerInput.toLowerCase());
        if (query.isEmpty()) {
            return true;
        }
        return keySegment(key == null ? "" : key.toLowerCase()).startsWith(query);
    }

    /**
     * The name inside a key: brackets at the end are dropped first, so
     * {@code \var(\tamil(\ki))} gives {@code ki}, {@code \var(} gives
     * {@code var} and {@code sum(} gives {@code sum}.
     */
    private static String keySegment(String key) {
        String trimmed = key;
        while (trimmed.endsWith(")") || trimmed.endsWith("(")) {
            trimmed = trimmed.substring(0, trimmed.length() - 1);
        }
        int cut = Math.max(trimmed.lastIndexOf('\\'), trimmed.lastIndexOf('('));
        return cut >= 0 ? trimmed.substring(cut + 1) : trimmed;
    }

    /**
     * What is being typed right now: the text after the last backslash or
     * bracket. {@code tamil(\k} gives {@code k}; {@code tamil(} or
     * {@code tamil(\} gives the empty string, which lists the whole context.
     */
    private static String querySegment(String input) {
        int cut = Math.max(input.lastIndexOf('\\'), input.lastIndexOf('('));
        return cut >= 0 ? input.substring(cut + 1) : input;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CONTEXT-FREE VARIANT
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Get suggestions matching the current input (context-free variant).
     *
     * @param input the current text being typed (e.g. "\var" or "\v")
     * @return list of matching suggestions sorted by relevance
     */
    public static List<Suggestion> getSuggestions(String input) {
        if (input == null || input.trim().isEmpty() || !SuggestionSettings.anyPopupGroupEnabled()) {
            return new ArrayList<>();
        }
        String lowerInput = input.toLowerCase();
        List<SuggestionRanker.Ranked> rows = new ArrayList<>();

        for (Suggestion s : SuggestionRegistry.allSuggestions) {
            if (!SuggestionSettings.isEnabled(Group.UNICODE)) {
                break;
            }
            String matchKey = matchKeyFor(s);
            if (!symbolPrefixMatch(matchKey, lowerInput)) {
                continue;
            }
            rows.add(new SuggestionRanker.Ranked(s, SuggestionRanker.TIER_OTHER,
                    matchKey, s.getDisplay(),
                    ScriptVariableIndex.scriptOrderFor(s.getDisplay()), NO_DECLARATION, lowerInput));
        }

        if (SuggestionSettings.isEnabled(Group.VARIABLES)) {
            addStyledVariables(rows, lowerInput);
            addDeclaredVariables(rows, lowerInput);
        }
        if (SuggestionSettings.isEnabled(Group.FUNCTIONS)) {
            addUserFunctions(rows, lowerInput);
            addUserClasses(rows, lowerInput);
        }

        dropCompletedName(rows, input.trim());
        return SuggestionRanker.order(rows, MAX_RESULTS);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // FULL-NAME RULE
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Removes every row whose name is exactly what was typed (case-sensitive),
     * leaving longer names that merely start with it. Called before ranking so
     * the fifteen-row limit is applied to what is actually shown.
     *
     * @param rows  the candidate rows, modified in place
     * @param typed the word as typed; null or empty removes nothing
     */
    private static void dropCompletedName(List<SuggestionRanker.Ranked> rows, String typed) {
        if (typed == null || typed.isEmpty()) {
            return;
        }
        rows.removeIf(row -> typed.equals(completedName(row.getSuggestion())));
    }

    /**
     * The text a row completes to, as the user would type it in full, or null
     * for rows the full-name rule does not apply to (script letters, physics
     * constants, {@code \var(} / {@code \con(} commands, recents written in
     * {@code \var(...)} form).
     */
    private static String completedName(Suggestion s) {
        String category = s.getCategory();
        String code = s.getCode();
        if (category == null || code == null) {
            return null;
        }
        switch (category) {
            case "Function":
                // The catalogue key may carry brackets or a signature; the
                // user types only the bare name.
                return FunctionProvider.extractFunctionName(code);
            case "Variable":
                return code.startsWith("\\") ? null : code;
            case "StyledVariable":
            case "UserFunction":
            case "UserClass":
            case "ClassMember":
            case "NcFile":
                return code;
            default:
                return null;
        }
    }
}
