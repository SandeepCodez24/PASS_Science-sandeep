package ui.ui_functions.suggestion_functions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import ui.ui_functions.FunctionProvider;
import ui.ui_functions.SuggestionProvider.Suggestion;
import ui.ui_functions.SuggestionProvider.SuggestionContext;

/**
 * Filters, ranks and returns suggestions for a given input and context.
 *
 * <h3>What changed</h3>
 * <ol>
 * <li><b>Script variables are matched by their roman key.</b> A declared
 * {@code ஆ} carries the search key {@code "aa"}, a declared {@code α} carries
 * {@code "alpha"}. One typed {@code a} therefore surfaces
 * {@code A, α, அ, ஆ, अ, आ} together instead of only the ASCII {@code A}.</li>
 * <li><b>Ordering moved to {@link SuggestionRanker}.</b> Tier first
 * (variables &rarr; recents &rarr; functions &rarr; commands), then exact match,
 * prefix, key length, case, script and alphabetical order inside the tier.</li>
 * <li><b>{@code \var(\} now offers the script commands.</b>
 * {@code \tamil(}, {@code \sanskrit(}, {@code \telugu(} and
 * {@code \malayalam(} are listed above the Greek letters, so the user can reach
 * any script from the one entry point.</li>
 * <li><b>Descriptions are specific.</b> Rows read {@code "alpha : Greek
 * letter"} and {@code "ki : Tamil consonant-vowel"} instead of a shared group
 * label.</li>
 * </ol>
 */
public final class SuggestionFilterService {

    private SuggestionFilterService() {
        // Utility class – no instances.
    }

    /** Maximum rows the popup will ever show. */
    private static final int MAX_RESULTS = 15;

    /** Sentinel declaration order for rows that are not declared variables. */
    private static final int NO_DECLARATION = Integer.MAX_VALUE;

    /** The script entry commands offered right after {@code \var(\}. */
    private static final List<String[]> SCRIPT_COMMANDS = Arrays.asList(
            new String[] { "\\tamil(", "tamil", "Tamil script" },
            new String[] { "\\sanskrit(", "sanskrit", "Sanskrit script" },
            new String[] { "\\telugu(", "telugu", "Telugu script" },
            new String[] { "\\malayalam(", "malayalam", "Malayalam script" });

    /**
     * Get suggestions matching the current input, filtered by context.
     *
     * @param input    the current text being typed
     * @param fullText the full code text for context detection
     * @return list of matching suggestions sorted by relevance
     */
    public static List<Suggestion> getSuggestionsFiltered(String input, String fullText) {
        SuggestionContext context = ContextDetector.detectContext(fullText);

        if (input == null) {
            return new ArrayList<>();
        }

        if (input.startsWith("\\")) {
            if (context == SuggestionContext.GENERAL) {
                return getBackslashCommandSuggestions(input);
            }
            String normalizedInput = normalizeSuggestionInput(input);
            return getSuggestionsWithContext(normalizedInput, context);
        }

        String normalizedInput = normalizeSuggestionInput(input);
        if (normalizedInput.isEmpty()) {
            if (isSymbolContext(context)) {
                return getSuggestionsWithContext("", context);
            }
            return new ArrayList<>();
        }
        return getSuggestionsWithContext(normalizedInput, context);
    }

    private static boolean isSymbolContext(SuggestionContext context) {
        return context == SuggestionContext.GREEK
                || context == SuggestionContext.TAMIL
                || context == SuggestionContext.SANSKRIT
                || context == SuggestionContext.HINDI
                || context == SuggestionContext.TELUGU
                || context == SuggestionContext.MALAYALAM
                || context == SuggestionContext.UNICONSTANT;
    }

    private static List<Suggestion> getBackslashCommandSuggestions(String input) {
        String prefix = input == null ? "" : input.substring(1).toLowerCase();
        List<Suggestion> results = new ArrayList<>();
        if (prefix.isEmpty() || prefix.startsWith("v")) {
            results.add(new Suggestion("\\var(", "Start variable symbol context", "\\var(", "SpecialCommand"));
        }
        if (prefix.isEmpty() || prefix.startsWith("c")) {
            results.add(new Suggestion("\\con(", "Start physics constant context", "\\con(", "SpecialCommand"));
        }
        return results;
    }

    private static String normalizeSuggestionInput(String input) {
        String normalized = input.trim().toLowerCase();
        // Strip leading backslash (from patterns like \con(\ )
        if (normalized.startsWith("\\")) {
            normalized = normalized.substring(1);
        }
        while (!normalized.isEmpty()) {
            char last = normalized.charAt(normalized.length() - 1);
            if (last == '_' || last == '^') {
                normalized = normalized.substring(0, normalized.length() - 1);
            } else {
                break;
            }
        }
        return normalized;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // MAIN QUERY
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Get suggestions for a specific context.
     *
     * @param input   the current text being typed (already normalised, lower case)
     * @param context the detected context
     * @return list of matching suggestions sorted by the ranking model
     */
    private static List<Suggestion> getSuggestionsWithContext(String input, SuggestionContext context) {
        String lowerInput = input == null ? "" : input.toLowerCase();
        List<SuggestionRanker.Ranked> rows = new ArrayList<>();

        boolean editorContext = context == SuggestionContext.GENERAL
                || context == SuggestionContext.SUBSCRIPT
                || context == SuggestionContext.SUPERSCRIPT;

        if (editorContext) {
            addStyledVariables(rows, lowerInput);
            addDeclaredVariables(rows, lowerInput);
            addRecentlyUsed(rows, lowerInput);
            addFunctions(rows, input, lowerInput);
        }

        if (context == SuggestionContext.GREEK) {
            // \var(\  – let the user pivot into any other script from here.
            addScriptCommands(rows, lowerInput);
        }

        addStaticSymbols(rows, lowerInput, context);

        return SuggestionRanker.order(rows, MAX_RESULTS);
    }

    // ── Tier 0: styled variables ─────────────────────────────────────────────

    private static void addStyledVariables(List<SuggestionRanker.Ranked> rows, String lowerInput) {
        for (Map.Entry<String, String> entry : SuggestionRegistry.discoveredStyledVariables.entrySet()) {
            String raw = entry.getKey();
            String display = entry.getValue();
            if (!raw.toLowerCase().contains(lowerInput) && !display.toLowerCase().contains(lowerInput)) {
                continue;
            }
            Suggestion suggestion = new Suggestion(raw, "Styled variable", display, "StyledVariable",
                    VariableKindIndex.kindFor(raw));
            rows.add(new SuggestionRanker.Ranked(suggestion,
                    SuggestionRanker.TIER_STYLED_VARIABLE,
                    raw, display,
                    ScriptVariableIndex.ORDER_ENGLISH, NO_DECLARATION, lowerInput));
        }
    }

    // ── Tier 1: variables declared above the caret ───────────────────────────

    /**
     * The heart of the fix. Each discovered variable is matched against its
     * roman search keys rather than against its rendered glyph, and it carries
     * a script-specific description into the popup.
     */
    private static void addDeclaredVariables(List<SuggestionRanker.Ranked> rows, String lowerInput) {
        for (DiscoveredVariable variable : SuggestionRegistry.discoveredVariableInfo.values()) {
            boolean prefixHit = variable.matchesPrefix(lowerInput);
            if (!prefixHit && !variable.matchesLoose(lowerInput)) {
                continue;
            }
            // The code is the rendered glyph itself, so accepting the row
            // inserts α / ஆ / अ directly rather than the \var(...) source form.
            Suggestion suggestion = new Suggestion(
                    variable.getName(),
                    variable.getDescription(),
                    variable.getName(),
                    "Variable",
                    VariableKindIndex.kindFor(variable.getName()));
            rows.add(new SuggestionRanker.Ranked(suggestion,
                    SuggestionRanker.TIER_VARIABLE,
                    variable.getPrimaryKey(), variable.getName(),
                    variable.getScriptOrder(), variable.getDeclarationOrder(), lowerInput));
        }
    }

    // ── Tier 2: recently used symbols ────────────────────────────────────────

    private static void addRecentlyUsed(List<SuggestionRanker.Ranked> rows, String lowerInput) {
        for (Map.Entry<String, String> entry : SuggestionRegistry.recentlyUsedSymbols.entrySet()) {
            String simpleName = entry.getKey();
            String fullFormat = entry.getValue();
            if (!fullFormat.startsWith("\\var(")) {
                continue;
            }
            if (!simpleName.toLowerCase().contains(lowerInput)) {
                continue;
            }
            String symbolDisplay = SuggestionRegistry.recentlyUsedSymbolDisplays
                    .getOrDefault(simpleName, simpleName);
            String description = ScriptVariableIndex.descriptionForCode(
                    fullFormat, symbolDisplay, "Recently Used");
            Suggestion suggestion = new Suggestion(fullFormat, description, symbolDisplay, "Variable");
            rows.add(new SuggestionRanker.Ranked(suggestion,
                    SuggestionRanker.TIER_RECENTLY_USED,
                    simpleName, symbolDisplay,
                    ScriptVariableIndex.scriptOrderFor(symbolDisplay), NO_DECLARATION, lowerInput));
        }
    }

    // ── Tier 3: built-in functions ───────────────────────────────────────────

    private static void addFunctions(List<SuggestionRanker.Ranked> rows, String input, String lowerInput) {
        List<String> matchingFunctions = FunctionProvider.getFilteredFunctions(input);
        for (String funcKey : matchingFunctions) {
            String description = FunctionProvider.getFunctionDescription(funcKey);
            String displayName = FunctionProvider.getFunctionDisplayName(funcKey);
            Suggestion suggestion = new Suggestion(funcKey, description, displayName, "Function",
                    SuggestionKind.FUNCTION_BUILTIN);
            rows.add(new SuggestionRanker.Ranked(suggestion,
                    SuggestionRanker.TIER_FUNCTION,
                    funcKey, displayName,
                    ScriptVariableIndex.ORDER_ENGLISH, NO_DECLARATION, lowerInput));
        }
    }

    // ── Tier 4: script entry commands after \var(\ ───────────────────────────

    /**
     * Offers {@code \tamil(}, {@code \sanskrit(}, {@code \telugu(} and
     * {@code \malayalam(} while the caret sits in {@code \var(\}. Previously
     * only Greek letters appeared there, so the other scripts were unreachable
     * unless the whole command was typed from memory.
     */
    private static void addScriptCommands(List<SuggestionRanker.Ranked> rows, String lowerInput) {
        for (String[] command : SCRIPT_COMMANDS) {
            String code = command[0];
            String key = command[1];
            String description = command[2];
            if (!key.startsWith(lowerInput) && !lowerInput.isEmpty()) {
                continue;
            }
            Suggestion suggestion = new Suggestion(code, description, code, "SpecialCommand");
            rows.add(new SuggestionRanker.Ranked(suggestion,
                    SuggestionRanker.TIER_COMMAND,
                    key, code,
                    ScriptVariableIndex.ORDER_ENGLISH, NO_DECLARATION, lowerInput));
        }
    }

    // ── Tier 4/5: the static symbol tables ───────────────────────────────────

    /**
     * Walks {@link SuggestionRegistry#allSuggestions} and keeps only what the
     * current context allows. Script symbols are matched on their roman key
     * ({@code alpha}, {@code ki}) rather than on the raw command string, so
     * {@code \var(} noise can no longer produce phantom matches.
     */
    private static void addStaticSymbols(List<SuggestionRanker.Ranked> rows, String lowerInput,
            SuggestionContext context) {
        boolean symbolContextHasHits = false;
        List<SuggestionRanker.Ranked> simpleFallbacks = new ArrayList<>();

        for (Suggestion s : SuggestionRegistry.allSuggestions) {
            String category = s.getCategory();
            if (!categoryAllowed(category, context)) {
                continue;
            }

            String matchKey = matchKeyFor(s);
            if (!matchKey.toLowerCase().contains(lowerInput)) {
                continue;
            }

            boolean isSimpleFallback = category != null && category.endsWith("Simple");
            int tier = isSimpleFallback ? SuggestionRanker.TIER_OTHER : SuggestionRanker.TIER_COMMAND;

            String display = s.getDisplay();
            SuggestionRanker.Ranked row = new SuggestionRanker.Ranked(s, tier,
                    matchKey, display,
                    ScriptVariableIndex.scriptOrderFor(display), NO_DECLARATION, lowerInput);

            if (isSimpleFallback) {
                simpleFallbacks.add(row);
            } else {
                symbolContextHasHits = true;
                rows.add(row);
            }
        }

        // When the real script symbols matched, the duplicate simple-name rows
        // are pure noise and are dropped.
        if (!symbolContextHasHits) {
            rows.addAll(simpleFallbacks);
        }
    }

    /**
     * The token a static suggestion should be matched against: the roman key
     * for a script glyph, the constant name for a physics constant, and the
     * code itself for anything else.
     */
    private static String matchKeyFor(Suggestion s) {
        String display = s.getDisplay();
        String roman = display == null ? null : ScriptVariableIndex.romanKeyFor(display);
        if (roman != null) {
            return roman;
        }
        String code = s.getCode();
        if ("Uniconstant".equals(s.getCategory()) && code.startsWith("\\con(\\") && code.endsWith(")")) {
            return code.substring("\\con(\\".length(), code.length() - 1);
        }
        return code;
    }

    /** Whether a suggestion category may appear in the given context. */
    private static boolean categoryAllowed(String category, SuggestionContext context) {
        if (category == null) {
            return false;
        }
        switch (context) {
            case GREEK:
                return "Greek".equals(category) || "GreekSimple".equals(category);
            case TAMIL:
                return "Tamil".equals(category) || "TamilSimple".equals(category);
            case SANSKRIT:
                return "Sanskrit".equals(category) || "SanskritSimple".equals(category);
            case HINDI:
                return "Hindi".equals(category) || "HindiSimple".equals(category);
            case TELUGU:
                return "Telugu".equals(category) || "TeluguSimple".equals(category);
            case MALAYALAM:
                return "Malayalam".equals(category) || "MalayalamSimple".equals(category);
            case UNICONSTANT:
                return "Uniconstant".equals(category);
            case SUBSCRIPT:
            case SUPERSCRIPT:
                // Symbol completion stays available inside a styled group.
                return "Greek".equals(category) || "GreekSimple".equals(category)
                        || "Tamil".equals(category) || "TamilSimple".equals(category)
                        || "Math".equals(category);
            case GENERAL:
            default:
                // GENERAL means the caret is NOT inside \var(...) or \con(...),
                // so the raw symbol tables must stay out of the way. Declared
                // variables already cover every script the user actually used.
                return !isScriptCategory(category) && !"Uniconstant".equals(category);
        }
    }

    private static boolean isScriptCategory(String category) {
        return "Greek".equals(category) || "GreekSimple".equals(category)
                || "Tamil".equals(category) || "TamilSimple".equals(category)
                || "Sanskrit".equals(category) || "SanskritSimple".equals(category)
                || "Telugu".equals(category) || "TeluguSimple".equals(category)
                || "Malayalam".equals(category) || "MalayalamSimple".equals(category)
                || "Hindi".equals(category) || "HindiSimple".equals(category);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CONTEXT-FREE VARIANT
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Get suggestions matching the current input (context-free variant).
     *
     * @param input the current text being typed (e.g. "\var" or "\v")
     * @return list of matching suggestions sorted by relevance
     */
    public static List<Suggestion> getSuggestions(String input) {
        if (input == null || input.trim().isEmpty()) {
            return new ArrayList<>();
        }
        String lowerInput = input.toLowerCase();
        List<SuggestionRanker.Ranked> rows = new ArrayList<>();

        for (Suggestion s : SuggestionRegistry.allSuggestions) {
            String matchKey = matchKeyFor(s);
            if (!matchKey.toLowerCase().contains(lowerInput)) {
                continue;
            }
            rows.add(new SuggestionRanker.Ranked(s, SuggestionRanker.TIER_OTHER,
                    matchKey, s.getDisplay(),
                    ScriptVariableIndex.scriptOrderFor(s.getDisplay()), NO_DECLARATION, lowerInput));
        }

        addStyledVariables(rows, lowerInput);
        addDeclaredVariables(rows, lowerInput);

        return SuggestionRanker.order(rows, MAX_RESULTS);
    }
}
