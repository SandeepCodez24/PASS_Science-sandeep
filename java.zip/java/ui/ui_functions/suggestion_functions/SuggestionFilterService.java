package ui.ui_functions.suggestion_functions;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import ui.ui_functions.FunctionProvider;
import ui.ui_functions.SuggestionProvider.Suggestion;
import ui.ui_functions.SuggestionProvider.SuggestionContext;

/**
 * Filters, ranks and returns suggestions for a given input and context.
 *
 * <p>
 * Extracted from {@code SuggestionProvider}'s query API
 * ({@code getSuggestionsFiltered}, {@code getBackslashCommandSuggestions},
 * {@code normalizeSuggestionInput}, {@code getSuggestionsWithContext},
 * {@code getSuggestions}, {@code getCategoryPriority}).
 */
public final class SuggestionFilterService {

    private SuggestionFilterService() {
        // Utility class – no instances.
    }

    /**
     * Get suggestions matching the current input, filtered by context.
     *
     * @param input    the current text being typed
     * @param fullText the full code text for context detection
     * @return list of matching suggestions sorted by relevance
     */
    public static List<Suggestion> getSuggestionsFiltered(String input, String fullText) {
        SuggestionContext context = ContextDetector.detectContext(fullText);

        if (input == null) {
            return new ArrayList<>();
        }

        if (input.startsWith("\\")) {
            if (context == SuggestionContext.GENERAL) {
                return getBackslashCommandSuggestions(input);
            }
            String normalizedInput = normalizeSuggestionInput(input);
            return getSuggestionsWithContext(normalizedInput, context);
        }

        String normalizedInput = normalizeSuggestionInput(input);
        if (normalizedInput.isEmpty()) {
            if (context == SuggestionContext.GREEK || context == SuggestionContext.TAMIL
                    || context == SuggestionContext.SANSKRIT
                    || context == SuggestionContext.HINDI || context == SuggestionContext.TELUGU
                    || context == SuggestionContext.MALAYALAM
                    || context == SuggestionContext.UNICONSTANT) {
                return getSuggestionsWithContext("", context);
            }
            return new ArrayList<>();
        }

        return getSuggestionsWithContext(normalizedInput, context);
    }

    private static List<Suggestion> getBackslashCommandSuggestions(String input) {
        String prefix = input == null ? "" : input.substring(1).toLowerCase();
        List<Suggestion> results = new ArrayList<>();

        if (prefix.isEmpty() || prefix.startsWith("v")) {
            results.add(new Suggestion("\\var(", "Start variable symbol context", "\\var(", "SpecialCommand"));
        }
        if (prefix.isEmpty() || prefix.startsWith("c")) {
            results.add(new Suggestion("\\con(", "Start physics constant context", "\\con(", "SpecialCommand"));
        }

        return results;
    }

    private static String normalizeSuggestionInput(String input) {
        String normalized = input.trim().toLowerCase();
        // Strip leading backslash (from patterns like \con(\)
        if (normalized.startsWith("\\")) {
            normalized = normalized.substring(1);
        }
        while (!normalized.isEmpty()) {
            char last = normalized.charAt(normalized.length() - 1);
            if (last == '_' || last == '^') {
                normalized = normalized.substring(0, normalized.length() - 1);
            } else {
                break;
            }
        }
        return normalized;
    }

    /**
     * Get suggestions for a specific context.
     *
     * @param input   the current text being typed
     * @param context the detected context (GREEK, TAMIL, SANSKRIT, or GENERAL)
     * @return list of matching suggestions sorted by relevance
     */
    private static List<Suggestion> getSuggestionsWithContext(String input, SuggestionContext context) {
        String lowerInput = input.toLowerCase();
        List<Suggestion> results = new ArrayList<>();
        List<Suggestion> styledVariableSuggestions = new ArrayList<>();
        List<Suggestion> variableSuggestions = new ArrayList<>();
        List<Suggestion> functionSuggestions = new ArrayList<>();
        List<Suggestion> symbolSuggestions = new ArrayList<>(); // Greek/Tamil/Sanskrit/etc with Unicode
        List<Suggestion> otherSuggestions = new ArrayList<>();

        // Filter suggestions based on context
        for (Suggestion s : SuggestionRegistry.allSuggestions) {
            boolean matchesCode;
            boolean matchesDisplay;

            // For Uniconstant, extract token for matching (e.g. "pi" from "\con(\pi)")
            if ("Uniconstant".equals(s.getCategory()) && s.getCode().startsWith("\\con(\\")) {
                String token = s.getCode().substring("\\con(\\".length(), s.getCode().length() - 1);
                matchesCode = token.toLowerCase().contains(lowerInput);
            } else {
                matchesCode = s.getCode().toLowerCase().contains(lowerInput);
            }

            matchesDisplay = s.getDisplay() != null
                    && s.getDisplay().toLowerCase().contains(lowerInput);
            if (!matchesCode && !matchesDisplay)
                continue;

            switch (context) {
                case GREEK:
                    // Prioritize actual Greek symbols over simple names.
                    if ("Greek".equals(s.getCategory())) {
                        symbolSuggestions.add(s);
                    } else if ("GreekSimple".equals(s.getCategory())) {
                        otherSuggestions.add(s);
                    }
                    break;

                case TAMIL:
                case SANSKRIT:
                case HINDI:
                case TELUGU:
                case MALAYALAM:
                    // Prioritize actual script symbols over simple names.
                    if ((context == SuggestionContext.TAMIL && "Tamil".equals(s.getCategory()))
                            || (context == SuggestionContext.SANSKRIT && "Sanskrit".equals(s.getCategory()))
                            || (context == SuggestionContext.HINDI && "Hindi".equals(s.getCategory()))
                            || (context == SuggestionContext.TELUGU && "Telugu".equals(s.getCategory()))
                            || (context == SuggestionContext.MALAYALAM && "Malayalam".equals(s.getCategory()))) {
                        symbolSuggestions.add(s);
                    } else if ((context == SuggestionContext.TAMIL && "TamilSimple".equals(s.getCategory()))
                            || (context == SuggestionContext.SANSKRIT && "SanskritSimple".equals(s.getCategory()))
                            || (context == SuggestionContext.HINDI && "HindiSimple".equals(s.getCategory()))
                            || (context == SuggestionContext.TELUGU && "TeluguSimple".equals(s.getCategory()))
                            || (context == SuggestionContext.MALAYALAM && "MalayalamSimple".equals(s.getCategory()))) {
                        otherSuggestions.add(s);
                    }
                    break;

                case SUBSCRIPT:
                case SUPERSCRIPT:
                    if ("Greek".equals(s.getCategory()) || "GreekSimple".equals(s.getCategory())
                            || "Tamil".equals(s.getCategory()) || "TamilSimple".equals(s.getCategory())
                            || "Math".equals(s.getCategory())) {
                        symbolSuggestions.add(s);
                    } else {
                        // Keep normal editor suggestions available in sub/sup mode as well.
                        otherSuggestions.add(s);
                    }
                    break;

                case UNICONSTANT:
                    // Show physics constants suggestions
                    if ("Uniconstant".equals(s.getCategory())) {
                        symbolSuggestions.add(s);
                    }
                    break;

                case GENERAL:
                default:
                    // Include all matching suggestions except special symbol contexts
                    // (since GENERAL means we're not in \var(...) or \con(...) context)
                    if (!"GreekSimple".equals(s.getCategory()) &&
                            !"Greek".equals(s.getCategory()) &&
                            !"TamilSimple".equals(s.getCategory()) &&
                            !"Tamil".equals(s.getCategory()) &&
                            !"SanskritSimple".equals(s.getCategory()) &&
                            !"Sanskrit".equals(s.getCategory()) &&
                            !"TeluguSimple".equals(s.getCategory()) &&
                            !"Telugu".equals(s.getCategory()) &&
                            !"MalayalamSimple".equals(s.getCategory()) &&
                            !"Malayalam".equals(s.getCategory()) &&
                            !"Uniconstant".equals(s.getCategory())) {
                        otherSuggestions.add(s);
                    }
            }
        }

        // In non-symbol-only contexts, add discovered variables/functions with
        // priority. Keeps normal editor completion active in SUB/SUPERSCRIPT too.
        if (context == SuggestionContext.GENERAL
                || context == SuggestionContext.SUBSCRIPT
                || context == SuggestionContext.SUPERSCRIPT) {
            for (Map.Entry<String, String> entry : SuggestionRegistry.discoveredStyledVariables.entrySet()) {
                String raw = entry.getKey();
                String display = entry.getValue();
                if (raw.toLowerCase().contains(lowerInput) || display.toLowerCase().contains(lowerInput)) {
                    styledVariableSuggestions.add(new Suggestion(raw, "Styled variable", display, "StyledVariable"));
                }
            }

            for (String varName : SuggestionRegistry.discoveredVariables) {
                if (varName.toLowerCase().contains(lowerInput)) {
                    variableSuggestions.add(new Suggestion(varName, "Variable", varName, "Variable"));
                }
            }

            // Add recently used symbols with high priority (suggest full correct format)
            for (Map.Entry<String, String> entry : SuggestionRegistry.recentlyUsedSymbols.entrySet()) {
                String simpleName = entry.getKey();
                String fullFormat = entry.getValue();
                if (!fullFormat.startsWith("\\var(")) {
                    continue;
                }
                if (simpleName.toLowerCase().contains(lowerInput)) {
                    String symbolDisplay = SuggestionRegistry.recentlyUsedSymbolDisplays
                            .getOrDefault(simpleName, simpleName);
                    variableSuggestions.add(new Suggestion(fullFormat, "Recently Used", symbolDisplay, "Variable"));
                }
            }

            // Add matching functions from FunctionProvider (alphabetically sorted)
            List<String> matchingFunctions = FunctionProvider.getFilteredFunctions(input);
            for (String funcKey : matchingFunctions) {
                String description = FunctionProvider.getFunctionDescription(funcKey);
                String displayName = FunctionProvider.getFunctionDisplayName(funcKey);
                functionSuggestions.add(new Suggestion(funcKey, description, displayName, "Function"));
            }
        }

        // When actual script symbols are available, hide duplicate simple-name
        // fallbacks.
        if (!symbolSuggestions.isEmpty()) {
            if (context == SuggestionContext.GREEK) {
                otherSuggestions.removeIf(s -> "GreekSimple".equals(s.getCategory()));
            } else if (context == SuggestionContext.TAMIL) {
                otherSuggestions.removeIf(s -> "TamilSimple".equals(s.getCategory()));
            } else if (context == SuggestionContext.SANSKRIT) {
                otherSuggestions.removeIf(s -> "SanskritSimple".equals(s.getCategory()));
            } else if (context == SuggestionContext.HINDI) {
                otherSuggestions.removeIf(s -> "HindiSimple".equals(s.getCategory()));
            } else if (context == SuggestionContext.TELUGU) {
                otherSuggestions.removeIf(s -> "TeluguSimple".equals(s.getCategory()));
            } else if (context == SuggestionContext.MALAYALAM) {
                otherSuggestions.removeIf(s -> "MalayalamSimple".equals(s.getCategory()));
            }
        }

        // Assemble results by context.
        switch (context) {
            case GREEK:
            case TAMIL:
            case SANSKRIT:
            case HINDI:
            case TELUGU:
            case MALAYALAM:
                // Symbol contexts: actual symbols first, then simple-name fallbacks.
                // (Bug fix: HINDI now grouped here too, so any Hindi symbols are not
                // silently dropped by falling through to the GENERAL branch.)
                results.addAll(symbolSuggestions);
                results.addAll(otherSuggestions);
                break;

            case UNICONSTANT:
                // Physics constants context: show constant suggestions
                results.addAll(symbolSuggestions);
                break;

            case SUBSCRIPT:
            case SUPERSCRIPT:
                // Mirror GENERAL logic first, then append symbol-focused completions.
                results.addAll(styledVariableSuggestions);
                results.addAll(variableSuggestions);
                results.addAll(functionSuggestions);
                results.addAll(symbolSuggestions);
                results.addAll(otherSuggestions);
                break;

            case GENERAL:
            default:
                results.addAll(styledVariableSuggestions);
                results.addAll(variableSuggestions);
                results.addAll(functionSuggestions);
                results.addAll(otherSuggestions);
                break;
        }

        // Sort within each priority by relevance
        if (context != SuggestionContext.GENERAL) {
            results.sort((a, b) -> {
                // For Uniconstant, extract token for prefix matching
                String aCodeForMatch = a.getCode();
                String bCodeForMatch = b.getCode();
                if ("Uniconstant".equals(a.getCategory()) && a.getCode().startsWith("\\con(\\")) {
                    aCodeForMatch = a.getCode().substring("\\con(\\".length(), a.getCode().length() - 1);
                }
                if ("Uniconstant".equals(b.getCategory()) && b.getCode().startsWith("\\con(\\")) {
                    bCodeForMatch = b.getCode().substring("\\con(\\".length(), b.getCode().length() - 1);
                }

                // Prioritize exact prefix matches
                boolean aPrefix = aCodeForMatch.toLowerCase().startsWith(lowerInput);
                boolean bPrefix = bCodeForMatch.toLowerCase().startsWith(lowerInput);
                if (aPrefix != bPrefix)
                    return aPrefix ? -1 : 1;

                // Then by category priority
                int catPriority = getCategoryPriority(a.getCategory()) - getCategoryPriority(b.getCategory());
                if (catPriority != 0)
                    return catPriority;

                // Finally by code length (shorter first)
                return Integer.compare(aCodeForMatch.length(), bCodeForMatch.length());
            });
        }

        return results.stream().limit(15).collect(Collectors.toList());
    }

    /**
     * Get suggestions matching the current input (context-free variant).
     *
     * @param input the current text being typed (e.g. "\var" or "\v")
     * @return list of matching suggestions sorted by relevance
     */
    public static List<Suggestion> getSuggestions(String input) {
        if (input == null || input.trim().isEmpty()) {
            return new ArrayList<>();
        }

        String lowerInput = input.toLowerCase();
        List<Suggestion> results = new ArrayList<>();

        // Add matching static suggestions (Greek, Tamil, Keywords, etc.)
        results.addAll(SuggestionRegistry.allSuggestions.stream()
                .filter(s -> s.getCode().toLowerCase().contains(lowerInput))
                .collect(Collectors.toList()));

        // Add matching discovered styled variables
        for (Map.Entry<String, String> entry : SuggestionRegistry.discoveredStyledVariables.entrySet()) {
            String raw = entry.getKey();
            String display = entry.getValue();
            if (raw.toLowerCase().contains(lowerInput) || display.toLowerCase().contains(lowerInput)) {
                results.add(new Suggestion(raw, "Styled variable", display, "StyledVariable"));
            }
        }

        for (String varName : SuggestionRegistry.discoveredVariables) {
            if (varName.toLowerCase().contains(lowerInput)) {
                results.add(new Suggestion(varName, "Variable", varName, "Variable"));
            }
        }

        // Sort by relevance
        results.sort((a, b) -> {
            boolean aPrefix = a.getCode().toLowerCase().startsWith(lowerInput);
            boolean bPrefix = b.getCode().toLowerCase().startsWith(lowerInput);
            if (aPrefix != bPrefix)
                return aPrefix ? -1 : 1;

            int catPriority = getCategoryPriority(a.getCategory()) - getCategoryPriority(b.getCategory());
            if (catPriority != 0)
                return catPriority;

            return Integer.compare(a.getCode().length(), b.getCode().length());
        });

        return results.stream().limit(15).collect(Collectors.toList());
    }

    /** Get category priority for sorting (lower = higher priority). */
    private static int getCategoryPriority(String category) {
        if ("StyledVariable".equals(category))
            return 0; // Styled variables: HIGHEST PRIORITY
        if ("Variable".equals(category))
            return 1; // Variables: SECOND PRIORITY
        if ("Function".equals(category))
            return 2; // Functions: THIRD PRIORITY
        if ("GreekSimple".equals(category))
            return 3; // Simple Greek names (alpha, beta)
        if ("TamilSimple".equals(category))
            return 4; // Simple Tamil names
        if ("SanskritSimple".equals(category))
            return 4; // Simple Sanskrit names
        if ("TeluguSimple".equals(category))
            return 4; // Simple Telugu names
        if ("MalayalamSimple".equals(category))
            return 4; // Simple Malayalam names
        if ("Keyword".equals(category))
            return 5;
        if ("Greek".equals(category))
            return 6; // Full Greek format lower priority
        if ("Tamil".equals(category))
            return 7; // Full Tamil format lower priority
        if ("Sanskrit".equals(category))
            return 7;
        if ("Telugu".equals(category))
            return 7;
        if ("Malayalam".equals(category))
            return 7;
        if ("Math".equals(category))
            return 8;
        return 9; // Default
    }
}
