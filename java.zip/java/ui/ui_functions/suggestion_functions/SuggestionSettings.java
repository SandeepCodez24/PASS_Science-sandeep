package ui.ui_functions.suggestion_functions;

import java.lang.ref.WeakReference;
import java.util.EnumMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;

/**
 * The user's choice of what the suggestion popup may offer, and whether block
 * closers are auto-filled.
 *
 * <h3>The five switches</h3>
 * <table>
 * <caption>Groups and what they govern</caption>
 * <tr><th>Group</th><th>Default</th><th>Governs</th></tr>
 * <tr><td>{@link Group#VARIABLES}</td><td>on</td><td>declared variables,
 * styled (sub/superscript) variables, class members</td></tr>
 * <tr><td>{@link Group#FUNCTIONS}</td><td>on</td><td>built-in functions,
 * language keywords and operators ({@code if}, {@code for}, {@code while},
 * {@code if not}, {@code &&} ...), user functions, user classes, methods</td></tr>
 * <tr><td>{@link Group#FILES}</td><td>on</td><td>{@code .nc} scripts in the
 * working folder (and any added search folder), offered by name in the
 * editor and the Command Window; the file being edited is never offered</td></tr>
 * <tr><td>{@link Group#END_AUTOFILL}</td><td>off</td><td>NOT a popup group:
 * the {@code :}-triggered skeleton insertion ({@code fnend}, {@code iend},
 * {@code wend}, {@code fend}, {@code csend}) in the editor</td></tr>
 * <tr><td>{@link Group#UNICODE}</td><td>on</td><td>{@code \var(} /
 * {@code \con(}, Greek / Tamil / Sanskrit / Telugu / Malayalam letters,
 * physics constants, sub/superscript digits, recently used symbols</td></tr>
 * </table>
 *
 * <p>
 * With every popup group off, the popup never opens.
 *
 * <h3>Persistence</h3>
 * Same mechanism as {@code RootFolderStore}: {@link Preferences}, so the
 * choice survives restarts and needs no file of its own.
 *
 * <h3>Listeners</h3>
 * Held weakly. Every editor tab builds its own popup, and a popup registered
 * strongly here would outlive its closed tab forever.
 */
public final class SuggestionSettings {

    /** One switch in the settings. */
    public enum Group {
        VARIABLES("Variable suggestions",
                "Variables declared in this file, including styled names and class members",
                true, true),
        FUNCTIONS("Function suggestions",
                "Built-in functions, keywords (if, for, while ...), operators, your functions and classes",
                true, true),
        FILES("Script file suggestions",
                ".nc scripts in the current folder, by name (the file you are editing is never offered)",
                true, true),
        END_AUTOFILL("End auto fill suggestions",
                "Typing ':' after if / for / while / function / class inserts the matching closer",
                false, false),
        UNICODE("UniCode Constants",
                "\\var( and \\con( commands, script letters, physics constants, sub/superscripts",
                true, true);

        private final String label;
        private final String description;
        private final boolean defaultOn;
        private final boolean popupGroup;

        Group(String label, String description, boolean defaultOn, boolean popupGroup) {
            this.label = label;
            this.description = description;
            this.defaultOn = defaultOn;
            this.popupGroup = popupGroup;
        }

        /** @return the text shown beside the tick box */
        public String label() {
            return label;
        }

        /** @return a one-line explanation, for tooltips and the settings window */
        public String description() {
            return description;
        }

        /** @return the factory setting */
        public boolean defaultOn() {
            return defaultOn;
        }

        /** @return true when this group filters popup rows (END_AUTOFILL does not) */
        public boolean isPopupGroup() {
            return popupGroup;
        }

        private String key() {
            return name().toLowerCase();
        }
    }

    private static final Preferences PREFS = Preferences.userRoot().node("astra/suggestions");

    private static final Map<Group, Boolean> CACHE = new EnumMap<>(Group.class);

    private static final List<WeakReference<Runnable>> LISTENERS = new CopyOnWriteArrayList<>();

    static {
        for (Group group : Group.values()) {
            CACHE.put(group, PREFS.getBoolean(group.key(), group.defaultOn()));
        }
    }

    private SuggestionSettings() {
    }

    /**
     * @param group the switch
     * @return whether it is ticked
     */
    public static boolean isEnabled(Group group) {
        Boolean value = CACHE.get(group);
        return value == null ? group.defaultOn() : value;
    }

    /**
     * Ticks or unticks a switch, stores it and notifies listeners. Setting a
     * switch to the value it already has does nothing.
     *
     * @param group   the switch
     * @param enabled the new state
     */
    public static void setEnabled(Group group, boolean enabled) {
        if (isEnabled(group) == enabled) {
            return;
        }
        CACHE.put(group, enabled);
        PREFS.putBoolean(group.key(), enabled);
        flush();
        fire();
    }

    /** Puts every switch back to its factory setting. */
    public static void restoreDefaults() {
        boolean changed = false;
        for (Group group : Group.values()) {
            if (isEnabled(group) != group.defaultOn()) {
                CACHE.put(group, group.defaultOn());
                PREFS.putBoolean(group.key(), group.defaultOn());
                changed = true;
            }
        }
        if (changed) {
            flush();
            fire();
        }
    }

    /** @return true when at least one popup group is ticked */
    public static boolean anyPopupGroupEnabled() {
        for (Group group : Group.values()) {
            if (group.isPopupGroup() && isEnabled(group)) {
                return true;
            }
        }
        return false;
    }

    /** @return whether the {@code :}-triggered closer insertion is on */
    public static boolean isEndAutofillEnabled() {
        return isEnabled(Group.END_AUTOFILL);
    }

    /**
     * Registers a callback run after any switch changes. Held weakly: keep a
     * strong reference to the {@link Runnable} for as long as it should fire.
     *
     * @param listener the callback
     */
    public static void addListener(Runnable listener) {
        if (listener != null) {
            LISTENERS.add(new WeakReference<>(listener));
        }
    }

    /**
     * @param listener a callback previously registered
     */
    public static void removeListener(Runnable listener) {
        LISTENERS.removeIf(ref -> ref.get() == null || ref.get() == listener);
    }

    private static void flush() {
        try {
            PREFS.flush();
        } catch (BackingStoreException ignored) {
            // The value still holds for this session.
        }
    }

    private static void fire() {
        Iterator<WeakReference<Runnable>> it = LISTENERS.iterator();
        while (it.hasNext()) {
            WeakReference<Runnable> ref = it.next();
            Runnable listener = ref.get();
            if (listener == null) {
                LISTENERS.remove(ref);
                continue;
            }
            try {
                listener.run();
            } catch (RuntimeException e) {
                e.printStackTrace();
            }
        }
    }
}
