package ui.ui_functions.suggestion_functions;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.function.Supplier;
import java.util.regex.Pattern;

/**
 * The {@code .nc} scripts the suggestion popup may offer by name.
 *
 * <h3>Where it looks</h3>
 * <ol>
 * <li><b>The working folder</b> -- the folder the Command Window resolves
 * script names against ({@code ide.getCurrentFolder()}, the same folder
 * {@code CLI_Main} sends to {@code nc.exe} with {@code @cmd setpwd}).</li>
 * <li><b>Added search folders</b>, in the order they were added. Nothing adds
 * one yet; when an {@code addpath}-style command lands it only has to call
 * {@link #addSearchFolder(Path)}, and those scripts appear with no other
 * change.</li>
 * </ol>
 * Folders are scanned one level deep (no subfolders). When two folders hold the
 * same name, the first one wins, which is also the one {@code nc.exe} would
 * run.
 *
 * <h3>What is offered</h3>
 * <ul>
 * <li>The name <b>without</b> {@code .nc}: {@code sct_01}. {@code nc.exe}
 * accepts both forms.</li>
 * <li>Only names that can be typed as one word ({@code sct_01},
 * {@code மாதிரி}). A file such as {@code my test.nc} or {@code 01_run.nc}
 * cannot be completed from a typed prefix, so it is left out rather than
 * inserted as broken text.</li>
 * <li>Never the file being edited: {@link #matching(String, String)} takes the
 * name to exclude, so typing in {@code AAAA.nc} never offers {@code AAAA}.
 * The Command Window excludes nothing.</li>
 * <li>Never the interpreter's own {@code cleaned_Runfile.nc}.</li>
 * </ul>
 *
 * <h3>Cost</h3>
 * The popup asks on every keystroke, so a folder is re-read only when its
 * modification time changes (a file was added, removed or renamed) or when the
 * cached listing is older than {@link #MAX_AGE_MS}. Everything else is served
 * from memory.
 */
public final class NcFileIndex {

    private NcFileIndex() {
        // Utility class – no instances.
    }

    /** One offerable script. */
    public static final class Entry {
        private final String name;
        private final Path file;
        private final boolean inWorkingFolder;

        Entry(String name, Path file, boolean inWorkingFolder) {
            this.name = name;
            this.file = file;
            this.inWorkingFolder = inWorkingFolder;
        }

        /** @return the script name without {@code .nc} */
        public String getName() {
            return name;
        }

        /** @return the file on disk */
        public Path getFile() {
            return file;
        }

        /** @return true when the file sits in the working folder itself */
        public boolean isInWorkingFolder() {
            return inWorkingFolder;
        }
    }

    private static final String EXTENSION = ".nc";

    /** The interpreter's generated file, never offered. */
    private static final String CLEANED_RUNFILE = "cleaned_runfile";

    /** A cached listing older than this is re-read even if the folder looks unchanged. */
    private static final long MAX_AGE_MS = 3000;

    /** A name that can be typed as one word and completed from a prefix. */
    private static final Pattern TYPEABLE = Pattern.compile("[\\p{L}_][\\p{L}\\p{M}\\p{N}_]*");

    private static volatile Supplier<Path> workingFolderSupplier = () -> null;

    private static final Set<Path> SEARCH_FOLDERS = Collections.synchronizedSet(new LinkedHashSet<>());

    private static final Map<Path, Listing> CACHE = new HashMap<>();

    private static final class Listing {
        final long folderModified;
        final long readAt;
        final List<Path> files;

        Listing(long folderModified, long readAt, List<Path> files) {
            this.folderModified = folderModified;
            this.readAt = readAt;
            this.files = files;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // Configuration
    // ─────────────────────────────────────────────────────────────────────

    /**
     * Where the working folder comes from. Called by the editor and the Command
     * Window with {@code ide::getCurrentFolder}; calling it again is harmless.
     *
     * @param supplier supplies the current working folder; may return null
     */
    public static void setWorkingFolderSupplier(Supplier<Path> supplier) {
        workingFolderSupplier = supplier == null ? () -> null : supplier;
    }

    /**
     * Adds a folder whose scripts are offered too (the future {@code addpath}).
     *
     * @param folder the folder
     */
    public static void addSearchFolder(Path folder) {
        if (folder != null) {
            SEARCH_FOLDERS.add(folder.toAbsolutePath().normalize());
        }
    }

    /** @param folder a folder previously added */
    public static void removeSearchFolder(Path folder) {
        if (folder != null) {
            SEARCH_FOLDERS.remove(folder.toAbsolutePath().normalize());
        }
    }

    /** Removes every added search folder; the working folder is unaffected. */
    public static void clearSearchFolders() {
        SEARCH_FOLDERS.clear();
    }

    /** @return the added search folders, in order */
    public static List<Path> getSearchFolders() {
        synchronized (SEARCH_FOLDERS) {
            return new ArrayList<>(SEARCH_FOLDERS);
        }
    }

    /** Forgets every cached listing, so the next query re-reads the disk. */
    public static void invalidate() {
        synchronized (CACHE) {
            CACHE.clear();
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // Query
    // ─────────────────────────────────────────────────────────────────────

    /**
     * Scripts whose name starts with {@code prefix}, case-insensitively.
     *
     * @param prefix       what the user typed (any case)
     * @param excludedName the script being edited, with or without
     *                     {@code .nc}; null to exclude nothing
     * @return the matching scripts, working folder first, then added folders
     */
    public static List<Entry> matching(String prefix, String excludedName) {
        String lowerPrefix = prefix == null ? "" : prefix.toLowerCase(Locale.ROOT);
        String excluded = stripExtension(excludedName);

        Map<String, Entry> byName = new LinkedHashMap<>();
        Path working = normalized(workingFolderSupplier.get());
        if (working != null) {
            collect(working, true, lowerPrefix, excluded, byName);
        }
        for (Path folder : getSearchFolders()) {
            if (!folder.equals(working)) {
                collect(folder, false, lowerPrefix, excluded, byName);
            }
        }
        return new ArrayList<>(byName.values());
    }

    /**
     * The script name shown on an editor tab: {@code AAAA.nc*} becomes
     * {@code AAAA}. Used by the editor to exclude its own file.
     *
     * @param tabTitle the tab's text, possibly with the unsaved-changes marker
     * @return the bare name, or null for an empty title
     */
    public static String nameFromTabTitle(String tabTitle) {
        if (tabTitle == null) {
            return null;
        }
        String title = tabTitle.trim();
        while (title.startsWith("*")) {
            title = title.substring(1).trim();
        }
        while (title.endsWith("*")) {
            title = title.substring(0, title.length() - 1).trim();
        }
        return title.isEmpty() ? null : stripExtension(title);
    }

    // ─────────────────────────────────────────────────────────────────────
    // Internals
    // ─────────────────────────────────────────────────────────────────────

    private static void collect(Path folder, boolean working, String lowerPrefix, String excluded,
            Map<String, Entry> byName) {
        for (Path file : listing(folder)) {
            String name = stripExtension(file.getFileName().toString());
            String key = name.toLowerCase(Locale.ROOT);
            if (!key.startsWith(lowerPrefix)
                    || key.equals(CLEANED_RUNFILE)
                    || (excluded != null && name.equalsIgnoreCase(excluded))
                    || !TYPEABLE.matcher(name).matches()
                    || byName.containsKey(key)) {
                continue;
            }
            byName.put(key, new Entry(name, file, working));
        }
    }

    /** The folder's {@code .nc} files, from the cache when it is still fresh. */
    private static List<Path> listing(Path folder) {
        long modified = lastModified(folder);
        if (modified < 0) {
            return Collections.emptyList();
        }
        long now = System.currentTimeMillis();
        synchronized (CACHE) {
            Listing cached = CACHE.get(folder);
            if (cached != null && cached.folderModified == modified && now - cached.readAt < MAX_AGE_MS) {
                return cached.files;
            }
        }

        List<Path> files = new ArrayList<>();
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(folder)) {
            for (Path entry : stream) {
                String fileName = entry.getFileName().toString();
                if (fileName.toLowerCase(Locale.ROOT).endsWith(EXTENSION) && Files.isRegularFile(entry)) {
                    files.add(entry);
                }
            }
        } catch (IOException | SecurityException e) {
            // An unreadable folder offers nothing; it must never break typing.
            return Collections.emptyList();
        }
        files.sort((a, b) -> a.getFileName().toString().compareToIgnoreCase(b.getFileName().toString()));
        List<Path> frozen = Collections.unmodifiableList(files);

        synchronized (CACHE) {
            CACHE.put(folder, new Listing(modified, now, frozen));
        }
        return frozen;
    }

    private static long lastModified(Path folder) {
        try {
            if (!Files.isDirectory(folder)) {
                return -1;
            }
            return Files.getLastModifiedTime(folder).toMillis();
        } catch (IOException | SecurityException e) {
            return -1;
        }
    }

    private static Path normalized(Path folder) {
        return folder == null ? null : folder.toAbsolutePath().normalize();
    }

    private static String stripExtension(String name) {
        if (name == null) {
            return null;
        }
        String trimmed = name.trim();
        if (trimmed.toLowerCase(Locale.ROOT).endsWith(EXTENSION)) {
            trimmed = trimmed.substring(0, trimmed.length() - EXTENSION.length());
        }
        return trimmed.isEmpty() ? null : trimmed;
    }
}
