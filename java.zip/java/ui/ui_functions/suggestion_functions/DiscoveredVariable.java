package ui.ui_functions.suggestion_functions;

import java.util.List;

/**
 * A variable the parser found in the editor text, carried together with
 * everything the suggestion ranker needs to place it correctly.
 *
 * <p>
 * The critical field is {@link #getPrimaryKey()}. For an ASCII variable it is
 * simply the lower-cased name; for a script glyph it is the <b>roman key</b>
 * that produced the glyph ({@code α → "alpha"}, {@code ஆ → "aa"}). Matching on
 * the primary key is what lets a single typed {@code a} surface
 * {@code A, α, அ, ஆ, अ, आ} together.
 */
public final class DiscoveredVariable {

    private final String name;
    private final String primaryKey;
    private final List<String> searchKeys;
    private final String description;
    private final int scriptOrder;
    private final int declarationOrder;

    /**
     * @param name             the variable exactly as it is rendered in the editor
     * @param declarationOrder zero-based index of the declaration line, so
     *                         earlier declarations can break ranking ties
     */
    public DiscoveredVariable(String name, int declarationOrder) {
        this.name = name;
        this.declarationOrder = declarationOrder;
        this.primaryKey = ScriptVariableIndex.primaryKeyFor(name);
        this.searchKeys = ScriptVariableIndex.searchKeysFor(name);
        this.scriptOrder = ScriptVariableIndex.scriptOrderFor(name);
        String scripted = ScriptVariableIndex.descriptionFor(name);
        // A Greek/Tamil/Sanskrit/Telugu/Malayalam variable shows its own
        // identity ("aa : Tamil vowel"); a plain English one just says
        // "Variable", which is already unambiguous.
        this.description = scripted != null ? scripted : "Variable";
    }

    /** The rendered name, e.g. {@code "ஆ"} or {@code "A"}. */
    public String getName() {
        return name;
    }

    /** Lower-cased key used for prefix matching and alphabetisation. */
    public String getPrimaryKey() {
        return primaryKey;
    }

    /** Every lower-cased key that should match a typed prefix. */
    public List<String> getSearchKeys() {
        return searchKeys;
    }

    /** Popup description: the script-specific one when available. */
    public String getDescription() {
        return description;
    }

    /** One of the {@code ScriptVariableIndex.ORDER_*} constants. */
    public int getScriptOrder() {
        return scriptOrder;
    }

    /** Zero-based declaration line index. */
    public int getDeclarationOrder() {
        return declarationOrder;
    }

    /**
     * True when any search key starts with the typed prefix.
     *
     * @param lowerInput the already lower-cased typed prefix
     * @return whether this variable should be offered
     */
    public boolean matchesPrefix(String lowerInput) {
        if (lowerInput == null || lowerInput.isEmpty()) {
            return true;
        }
        for (String key : searchKeys) {
            if (key.startsWith(lowerInput)) {
                return true;
            }
        }
        return false;
    }

    /**
     * True when any search key contains the typed text. Used as a widened
     * fallback so a mid-word match is still reachable, ranked below prefixes.
     *
     * @param lowerInput the already lower-cased typed text
     * @return whether this variable contains the input anywhere
     */
    public boolean matchesLoose(String lowerInput) {
        if (lowerInput == null || lowerInput.isEmpty()) {
            return true;
        }
        for (String key : searchKeys) {
            if (key.contains(lowerInput)) {
                return true;
            }
        }
        return false;
    }
}
