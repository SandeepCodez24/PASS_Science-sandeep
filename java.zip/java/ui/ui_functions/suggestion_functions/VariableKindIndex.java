package ui.ui_functions.suggestion_functions;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Remembers the inferred {@link SuggestionKind} of every discovered variable,
 * keyed by the variable name exactly as it appears in the editor.
 *
 * <p>
 * Kept separate from {@code DiscoveredVariable} on purpose: type is the one
 * attribute that will stop being inferred once the Variable Explorer's central
 * data store is in place. Isolating it here means the eventual switch touches
 * {@link #kindFor(String)} and nothing else — the discovery engine, the filter
 * service and the renderer all keep working unchanged.
 *
 * <p>
 * Populated by {@link VariableDiscoveryEngine} on every text change, read by
 * {@code SuggestionFilterService} when it builds a variable row.
 */
public final class VariableKindIndex {

    private VariableKindIndex() {
        // Utility class – no instances.
    }

    /** Variable name &rarr; inferred kind. Insertion-ordered for stable debugging. */
    private static final Map<String, SuggestionKind> KINDS = new LinkedHashMap<>();

    /** Variable name &rarr; the literal it was declared with, for the type label. */
    private static final Map<String, String> LITERALS = new LinkedHashMap<>();

    /** Drops everything. Called at the start of each discovery pass. */
    public static void clear() {
        KINDS.clear();
        LITERALS.clear();
    }

    /**
     * Records the kind for one variable.
     *
     * <p>
     * <b>Re-assignment policy:</b> a later assignment overwrites an earlier one,
     * because the most recent literal is the closest thing we have to the
     * variable's current state. The single exception is that a
     * {@link SuggestionKind#VARIABLE_GENERIC} result never overwrites a kind we
     * already resolved — {@code x = 1} followed by {@code x = f(x)} keeps the
     * integer marker rather than regressing to the neutral one.
     *
     * @param name        the variable name as written
     * @param rightHandSide the literal after {@code =}
     */
    public static void record(String name, String rightHandSide) {
        if (name == null || name.isBlank()) {
            return;
        }
        SuggestionKind kind = LiteralTypeInference.infer(rightHandSide);
        SuggestionKind existing = KINDS.get(name);
        if (kind == SuggestionKind.VARIABLE_GENERIC && existing != null) {
            return;
        }
        KINDS.put(name, kind);
        if (rightHandSide != null) {
            LITERALS.put(name, rightHandSide.trim());
        }
    }

    /** Records a non-variable declaration (user function or class). */
    public static void recordKind(String name, SuggestionKind kind) {
        if (name == null || name.isBlank() || kind == null) {
            return;
        }
        KINDS.put(name, kind);
    }

    /**
     * @param name the variable name as written in the editor
     * @return the recorded kind, or {@link SuggestionKind#VARIABLE_GENERIC} when
     *         the variable is unknown — never null, so the renderer always has
     *         an icon to draw
     */
    public static SuggestionKind kindFor(String name) {
        if (name == null) {
            return SuggestionKind.VARIABLE_GENERIC;
        }
        return KINDS.getOrDefault(name, SuggestionKind.VARIABLE_GENERIC);
    }

    /**
     * A MATLAB-style type label for the right-hand column of the popup, e.g.
     * {@code "1x1 double"} or {@code "1x1 string"}.
     *
     * @param name the variable name
     * @return a short type description
     */
    public static String typeLabelFor(String name) {
        SuggestionKind kind = kindFor(name);
        if (kind == SuggestionKind.VARIABLE_GENERIC) {
            return "Variable";
        }
        return "1x1 " + kind.getTypeLabel();
    }

    /**
     * @param name the variable name
     * @return the literal the variable was last assigned, or null
     */
    public static String literalFor(String name) {
        return LITERALS.get(name);
    }
}
