package ui.ui_functions.suggestion_functions;

import org.fxmisc.richtext.CodeArea;

import javafx.geometry.Bounds;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;

/**
 * Computes caret screen coordinates and popup sizing for the suggestion popup.
 *
 * <p>
 * Extracted from {@code SuggestionPopup}'s {@code getCaretScreenXY(...)} and
 * {@code updatePopupHeight(...)}.
 */
public final class PopupPositioner {

    private PopupPositioner() {
        // Utility class – no instances.
    }

    /** Height per suggestion cell (single-line with right-side description). */
    private static final double CELL_HEIGHT = 32.0;

    /**
     * Update popup height dynamically based on item count.
     * <ul>
     * <li>1–4 suggestions: shrink to fit content (no scrolling)</li>
     * <li>5+ suggestions: show ~8 items then enable scrolling</li>
     * </ul>
     *
     * @param list      the suggestion {@code ListView}
     * @param itemCount number of suggestions currently shown
     */
    public static void updatePopupHeight(ListView<?> list, int itemCount) {
        if (itemCount <= 4) {
            list.setPrefHeight(itemCount * CELL_HEIGHT);
        } else {
            double maxVisibleHeight = 8 * CELL_HEIGHT; // ~256px before scrolling
            list.setPrefHeight(maxVisibleHeight);
        }
    }

    /**
     * Returns {@code [screenX, screenY]} of the bottom-left of the caret for a
     * {@link CodeArea}, or {@code null} if it cannot be determined.
     */
    public static double[] getCaretScreenXY(CodeArea editor) {
        try {
            // RichTextFX exposes optional caret bounds in screen coordinates.
            java.util.Optional<Bounds> opt = editor.getCaretBounds();
            if (opt.isPresent()) {
                Bounds b = opt.get();
                return new double[] { b.getMinX(), b.getMaxY() };
            }

            // Fallback: use the editor's own screen bounds + a rough estimate.
            Bounds editorScreen = editor.localToScreen(editor.getBoundsInLocal());
            if (editorScreen != null) {
                return new double[] { editorScreen.getMinX() + 20,
                        editorScreen.getMinY() + 60 };
            }
        } catch (Exception ex) {
            System.err.println("[PopupPositioner] CodeArea caret bounds error: " + ex.getMessage());
        }
        return null;
    }

    /**
     * Returns {@code [screenX, screenY]} for a {@link TextArea} by counting lines.
     * JavaFX doesn't expose the caret pixel location for a TextArea directly, so
     * it is estimated from line number × line height.
     */
    public static double[] getCaretScreenXY(TextArea editor) {
        try {
            int caretPos = editor.getCaretPosition();
            String text = editor.getText();
            String before = text.substring(0, Math.min(caretPos, text.length()));

            // Which line the caret is on (0-based)
            int lineNum = before.split("\n", -1).length - 1;

            // Estimate column (chars from last newline)
            int lastNL = before.lastIndexOf('\n');
            int colNum = (lastNL == -1) ? caretPos : caretPos - lastNL - 1;

            Bounds b = editor.localToScreen(editor.getBoundsInLocal());
            if (b == null)
                return null;

            // Typical metrics for Consolas 16px
            double lineHeight = 22.0;
            double charWidth = 9.6;
            double topPad = 8.0;
            double leftPad = 8.0;

            double x = b.getMinX() + leftPad + colNum * charWidth;
            double y = b.getMinY() + topPad + (lineNum + 1) * lineHeight;

            return new double[] { x, y };
        } catch (Exception ex) {
            System.err.println("[PopupPositioner] TextArea caret bounds error: " + ex.getMessage());
        }
        return null;
    }
}
