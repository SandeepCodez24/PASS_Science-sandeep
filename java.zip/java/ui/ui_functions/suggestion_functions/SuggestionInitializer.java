package ui.ui_functions.suggestion_functions;

import language.replace.Greek;
import language.replace.Malayalam;
import language.replace.Sanskrit;
import language.replace.Subscript;
import language.replace.Superscript;
import language.replace.Tamil;
import language.replace.Telugu;
import language.replace.Uniconstant;
import ui.ui_functions.SuggestionProvider.Suggestion;

/**
 * Builds the static suggestion tables (Greek, Tamil, Sanskrit, Malayalam,
 * Telugu, Uniconstant, subscript/superscript) into
 * {@link SuggestionRegistry#allSuggestions}.
 *
 * <h3>Descriptions are now per-letter, not per-group</h3>
 * Every script row used to carry a shared group label — twenty-four Greek rows
 * all reading {@code "Greek letter"}, every Tamil consonant reading
 * {@code "Tamil consonant"} — which told the user nothing about the row they
 * were about to accept. Descriptions now come from
 * {@link ScriptVariableIndex}, which derives them from the same symbol maps the
 * replacement engine uses:
 *
 * <pre>
 *   &#945;   alpha : Greek letter
 *   &#2950;   aa : Tamil vowel
 *   &#2965;&#3007;  ki : Tamil consonant-vowel
 *   &#2965;&#3021;  ik : Tamil pure consonant
 *   &#2310;   aa : Sanskrit vowel
 * </pre>
 *
 * <p>
 * The group label survives only as a fallback for a glyph the index does not
 * know, so a future addition to a symbol map can never render a blank row.
 */
public final class SuggestionInitializer {

    private SuggestionInitializer() {
        // Utility class – no instances.
    }

    /** Initialize all available suggestions from various symbol sets. */
    public static void initializeSuggestions() {
        // Greek symbols
        addGreekSuggestions();
        addGreekSimpleNames();

        // Tamil vowels and consonants
        addTamilSuggestions();
        addTamilSimpleNames();

        // Sanskrit symbols
        addSanskritSuggestions();
        addSanskritSimpleNames();

        // Malayalam symbols
        addMalayalamSuggestions();
        addMalayalamSimpleNames();

        // Telugu symbols
        addTeluguSuggestions();
        addTeluguSimpleNames();

        // Uniconstant physics constants
        addUniconstantSuggestions();

        // Subscript and superscript
        addSubscriptSuperscriptSuggestions();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // SHARED HELPERS
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Adds every entry of a symbol map, giving each row the specific
     * description the index derived for that glyph.
     *
     * @param map          the symbol map to publish
     * @param groupLabel   fallback description for an unindexed glyph
     * @param category     the suggestion category
     */
    private static void addFromMap(java.util.Map<String, String> map, String groupLabel, String category) {
        if (map == null) {
            return;
        }
        map.forEach((code, symbol) -> {
            String description = ScriptVariableIndex.descriptionForCode(code, symbol, groupLabel);
            SuggestionRegistry.allSuggestions.add(new Suggestion(code, description, symbol, category));
        });
    }

    /**
     * Adds the short-form rows (bare roman keys such as {@code aa}) that the
     * styled subscript / superscript modes insert. The description is resolved
     * through the glyph the key produces, so a simple row is just as
     * informative as a full one.
     *
     * @param map        the symbol map that defines the keys
     * @param prefix     the command prefix, e.g. {@code "\var(\tamil("}
     * @param groupLabel fallback description
     * @param category   the suggestion category, e.g. {@code "TamilSimple"}
     */
    private static void addSimpleNamesFromMap(java.util.Map<String, String> map, String prefix,
            String groupLabel, String category) {
        if (map == null) {
            return;
        }
        map.forEach((code, symbol) -> {
            String simple = stripToSimpleName(code, prefix);
            if (simple == null || simple.isBlank()) {
                return;
            }
            String description = ScriptVariableIndex.descriptionForCode(code, symbol, groupLabel);
            SuggestionRegistry.allSuggestions.add(new Suggestion(simple, description, symbol, category));
        });
    }

    /** {@code \var(\tamil(\ki))} + prefix {@code \var(\tamil(} &rarr; {@code ki}. */
    private static String stripToSimpleName(String code, String prefix) {
        if (code == null || !code.startsWith(prefix)) {
            return null;
        }
        String simple = code.substring(prefix.length());
        while (simple.endsWith(")")) {
            simple = simple.substring(0, simple.length() - 1);
        }
        if (simple.startsWith("\\")) {
            simple = simple.substring(1);
        }
        return simple;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GREEK
    // ─────────────────────────────────────────────────────────────────────────

    /** Add Greek symbol suggestions from Greek.SYMBOL_MAP. */
    private static void addGreekSuggestions() {
        addFromMap(Greek.SYMBOL_MAP, "Greek letter", "Greek");
    }

    /**
     * Add simple-form Greek letter names (alpha, beta, gamma, etc.) for
     * contextual use. These appear after {@code \var(} or when a symbol was
     * recently used.
     */
    private static void addGreekSimpleNames() {
        addSimpleNamesFromMap(Greek.SYMBOL_MAP, "\\var(\\", "Greek letter", "GreekSimple");
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TAMIL
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Add Tamil vowel and consonant suggestions from Tamil.TAMIL_VOWEL_MAP and
     * TAMIL_CONSONANT_MAP.
     */
    private static void addTamilSuggestions() {
        addFromMap(Tamil.TAMIL_VOWEL_MAP, "Tamil vowel", "Tamil");
        addFromMap(Tamil.TAMIL_CONSONANT_MAP, "Tamil consonant", "Tamil");
    }

    /**
     * Add simple-form Tamil names for contextual use after
     * {@code \var(\tamil(}.
     *
     * <p>
     * <b>Bug fix:</b> the list used to be a hand-maintained array of about
     * sixty keys, so the great majority of the ~250 entries in
     * {@code TAMIL_CONSONANT_MAP} had no short form at all, and the array also
     * carried keys ({@code "Nha"}, {@code "ea"}) that no longer matched the
     * map. Deriving the list from the map keeps the two permanently in sync.
     */
    private static void addTamilSimpleNames() {
        addSimpleNamesFromMap(Tamil.TAMIL_VOWEL_MAP, "\\var(\\tamil(", "Tamil vowel", "TamilSimple");
        addSimpleNamesFromMap(Tamil.TAMIL_CONSONANT_MAP, "\\var(\\tamil(", "Tamil consonant", "TamilSimple");
    }

    // ─────────────────────────────────────────────────────────────────────────
    // SANSKRIT
    // ─────────────────────────────────────────────────────────────────────────

    private static void addSanskritSuggestions() {
        addFromMap(Sanskrit.SYMBOL_MAP, "Sanskrit symbol", "Sanskrit");
    }

    private static void addSanskritSimpleNames() {
        addSimpleNamesFromMap(Sanskrit.SYMBOL_MAP, "\\var(\\sanskrit(", "Sanskrit symbol", "SanskritSimple");
    }

    // ─────────────────────────────────────────────────────────────────────────
    // MALAYALAM
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Add Malayalam vowel and consonant suggestions from
     * Malayalam.MALAYALAM_VOWEL_MAP and MALAYALAM_CONSONANT_MAP.
     */
    private static void addMalayalamSuggestions() {
        addFromMap(Malayalam.MALAYALAM_VOWEL_MAP, "Malayalam vowel", "Malayalam");
        addFromMap(Malayalam.MALAYALAM_CONSONANT_MAP, "Malayalam consonant", "Malayalam");
    }

    private static void addMalayalamSimpleNames() {
        addSimpleNamesFromMap(Malayalam.MALAYALAM_VOWEL_MAP, "\\var(\\malayalam(",
                "Malayalam vowel", "MalayalamSimple");
        addSimpleNamesFromMap(Malayalam.MALAYALAM_CONSONANT_MAP, "\\var(\\malayalam(",
                "Malayalam consonant", "MalayalamSimple");
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TELUGU
    // ─────────────────────────────────────────────────────────────────────────

    private static void addTeluguSuggestions() {
        addFromMap(Telugu.TELUGU_VOWEL_MAP, "Telugu vowel", "Telugu");
        addFromMap(Telugu.TELUGU_CONSONANT_MAP, "Telugu consonant", "Telugu");
    }

    private static void addTeluguSimpleNames() {
        addSimpleNamesFromMap(Telugu.TELUGU_VOWEL_MAP, "\\var(\\telugu(", "Telugu vowel", "TeluguSimple");
        addSimpleNamesFromMap(Telugu.TELUGU_CONSONANT_MAP, "\\var(\\telugu(", "Telugu consonant", "TeluguSimple");
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CONSTANTS / SCRIPT MARKERS
    // ─────────────────────────────────────────────────────────────────────────

    /** Add physics constant suggestions from Uniconstant.SYMBOL_MAP. */
    private static void addUniconstantSuggestions() {
        if (Uniconstant.SYMBOL_MAP != null) {
            Uniconstant.SYMBOL_MAP.forEach((code, symbol) -> {
                // code is in format: \con(\pi), \con(\gravity), etc.
                // Store full format so when selected, it inserts complete code.
                String token = code;
                if (token.startsWith("\\con(\\") && token.endsWith(")")) {
                    token = token.substring("\\con(\\".length(), token.length() - 1);
                }
                SuggestionRegistry.allSuggestions.add(new Suggestion(
                        code,
                        token + " : Physics constant",
                        symbol,
                        "Uniconstant"));
            });
        }
    }

    /** Add subscript and superscript suggestions from Subscript / Superscript. */
    private static void addSubscriptSuperscriptSuggestions() {
        for (char ch = '0'; ch <= '9'; ch++) {
            if (Superscript.hasUnicode(ch)) {
                SuggestionRegistry.allSuggestions
                        .add(new Suggestion("^" + ch, "Superscript " + ch, Superscript.unicode(ch), "Math"));
            }
            if (Subscript.hasNumericSubscript(ch)) {
                SuggestionRegistry.allSuggestions
                        .add(new Suggestion("_" + ch, "Subscript " + ch, Subscript.numericSubscript(ch), "Math"));
            }
        }
    }
}
