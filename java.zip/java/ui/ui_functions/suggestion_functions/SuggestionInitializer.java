package ui.ui_functions.suggestion_functions;

import language.replace.Greek;
import language.replace.Malayalam;
import language.replace.Sanskrit;
import language.replace.Subscript;
import language.replace.Superscript;
import language.replace.Tamil;
import language.replace.Telugu;
import language.replace.Uniconstant;
import ui.ui_functions.SuggestionProvider.Suggestion;

/**
 * Builds the static suggestion tables (Greek, Tamil, Sanskrit, Malayalam,
 * Telugu, Uniconstant, subscript/superscript) into
 * {@link SuggestionRegistry#allSuggestions}.
 *
 * <p>
 * Extracted verbatim from {@code SuggestionProvider}'s {@code add*} family so
 * the initialization logic lives in one focused place.
 */
public final class SuggestionInitializer {

    private SuggestionInitializer() {
        // Utility class – no instances.
    }

    /** Initialize all available suggestions from various symbol sets. */
    public static void initializeSuggestions() {
        // Greek symbols
        addGreekSuggestions();
        addGreekSimpleNames();

        // Tamil vowels and consonants
        addTamilSuggestions();
        addTamilSimpleNames();

        // Sanskrit symbols
        addSanskritSuggestions();
        addSanskritSimpleNames();

        // Malayalam symbols
        addMalayalamSuggestions();
        addMalayalamSimpleNames();

        // Telugu symbols
        addTeluguSuggestions();
        addTeluguSimpleNames();

        // Uniconstant physics constants
        addUniconstantSuggestions();

        // Subscript and superscript
        addSubscriptSuperscriptSuggestions();
    }

    /**
     * Add simple-form Greek letter names (alpha, beta, gamma, etc.) for contextual
     * use. These appear after \var( or when a symbol was recently used.
     */
    private static void addGreekSimpleNames() {
        String[] greekNames = {
                "alpha", "beta", "gamma", "delta", "epsilon", "zeta", "eta", "theta",
                "iota", "kappa", "lambda", "mu", "nu", "xi", "omicron", "pi",
                "rho", "sigma", "tau", "upsilon", "phi", "chi", "psi", "omega"
        };

        for (String name : greekNames) {
            String lookupKey = "\\var(\\" + name + ")";
            String symbol = Greek.SYMBOL_MAP.get(lookupKey);
            String display = symbol != null ? symbol : name;
            SuggestionRegistry.allSuggestions
                    .add(new Suggestion(lookupKey, "Greek letter (simple)", display, "GreekSimple"));
        }
    }

    /** Add simple-form Tamil names for contextual use after \var(\tamil( */
    private static void addTamilSimpleNames() {
        // Tamil vowels
        String[] tamilVowels = {
                "a", "aa", "e", "ee", "u", "uu", "ea", "eaa", "i", "o", "oo", "au", "akg"
        };

        for (String vowel : tamilVowels) {
            SuggestionRegistry.allSuggestions
                    .add(new Suggestion(vowel, "Tamil vowel (simple)", vowel, "TamilSimple"));
        }

        // Tamil consonants - key names
        String[] tamilConsonants = {
                "ka", "kaa", "ki", "kii", "ik",
                "nga", "ngaa", "ngi",
                "cha", "chaa", "chi",
                "gna", "gnaa", "gni",
                "da", "daa", "di", "id",
                "tha", "thaa", "thi",
                "pa", "paa", "pi", "ip",
                "ma", "maa", "mi",
                "ya", "yaa", "yi",
                "ra", "raa", "ri",
                "la", "laa", "li",
                "va", "vaa", "vi",
                "zha", "zhaa", "zhi",
                "na", "naa",
                "Na", "Naa", "Ni",
                "Nha", "Nhaa", "Nhi",
                "iN", "iNn", "ing", "ina"
        };

        for (String consonant : tamilConsonants) {
            SuggestionRegistry.allSuggestions
                    .add(new Suggestion(consonant, "Tamil consonant (simple)", consonant, "TamilSimple"));
        }
    }

    private static void addSanskritSimpleNames() {
        if (Sanskrit.SYMBOL_MAP == null)
            return;
        for (String key : Sanskrit.SYMBOL_MAP.keySet()) {
            String simple = key;
            if (simple.startsWith("\\var(\\sanskrit(")) {
                simple = simple.substring("\\var(\\sanskrit(".length());
                if (simple.endsWith(")")) {
                    simple = simple.substring(0, simple.length() - 1);
                }
                if (simple.endsWith("))")) {
                    simple = simple.substring(0, simple.length() - 2);
                }
            }
            if (simple.startsWith("\\")) {
                simple = simple.substring(1);
            }
            if (!simple.isBlank()) {
                SuggestionRegistry.allSuggestions
                        .add(new Suggestion(simple, "Sanskrit simple", simple, "SanskritSimple"));
            }
        }
    }

    private static void addSanskritSuggestions() {
        if (Sanskrit.SYMBOL_MAP != null) {
            Sanskrit.SYMBOL_MAP.forEach(
                    (code, symbol) -> SuggestionRegistry.allSuggestions
                            .add(new Suggestion(code, "Sanskrit symbol", symbol, "Sanskrit")));
        }
    }

    /** Add Greek symbol suggestions from Greek.SYMBOL_MAP */
    private static void addGreekSuggestions() {
        if (Greek.SYMBOL_MAP != null) {
            Greek.SYMBOL_MAP.forEach(
                    (code, symbol) -> SuggestionRegistry.allSuggestions
                            .add(new Suggestion(code, "Greek letter", symbol, "Greek")));
        }
    }

    /**
     * Add Tamil vowel and consonant suggestions from Tamil.TAMIL_VOWEL_MAP and
     * TAMIL_CONSONANT_MAP
     */
    private static void addTamilSuggestions() {
        if (Tamil.TAMIL_VOWEL_MAP != null) {
            Tamil.TAMIL_VOWEL_MAP.forEach(
                    (code, symbol) -> SuggestionRegistry.allSuggestions
                            .add(new Suggestion(code, "Tamil vowel", symbol, "Tamil")));
        }

        if (Tamil.TAMIL_CONSONANT_MAP != null) {
            Tamil.TAMIL_CONSONANT_MAP.forEach(
                    (code, symbol) -> SuggestionRegistry.allSuggestions
                            .add(new Suggestion(code, "Tamil consonant", symbol, "Tamil")));
        }
    }

    /**
     * Add Malayalam vowel and consonant suggestions from
     * Malayalam.MALAYALAM_VOWEL_MAP and MALAYALAM_CONSONANT_MAP
     */
    private static void addMalayalamSuggestions() {
        if (Malayalam.MALAYALAM_VOWEL_MAP != null) {
            Malayalam.MALAYALAM_VOWEL_MAP.forEach(
                    (code, symbol) -> SuggestionRegistry.allSuggestions
                            .add(new Suggestion(code, "Malayalam vowel", symbol, "Malayalam")));
        }

        if (Malayalam.MALAYALAM_CONSONANT_MAP != null) {
            Malayalam.MALAYALAM_CONSONANT_MAP.forEach(
                    (code, symbol) -> SuggestionRegistry.allSuggestions
                            .add(new Suggestion(code, "Malayalam consonant", symbol, "Malayalam")));
        }
    }

    private static void addMalayalamSimpleNames() {
        if (Malayalam.MALAYALAM_VOWEL_MAP != null) {
            for (String code : Malayalam.MALAYALAM_VOWEL_MAP.keySet()) {
                String simple = code;
                if (simple.startsWith("\\var(\\malayalam(")) {
                    simple = simple.substring("\\var(\\malayalam(".length());
                    if (simple.endsWith("))")) {
                        simple = simple.substring(0, simple.length() - 2);
                    } else if (simple.endsWith(")")) {
                        simple = simple.substring(0, simple.length() - 1);
                    }
                }
                if (simple.startsWith("\\")) {
                    simple = simple.substring(1);
                }
                if (!simple.isBlank()) {
                    SuggestionRegistry.allSuggestions
                            .add(new Suggestion(simple, "Malayalam vowel (simple)", simple, "MalayalamSimple"));
                }
            }
        }

        if (Malayalam.MALAYALAM_CONSONANT_MAP != null) {
            for (String code : Malayalam.MALAYALAM_CONSONANT_MAP.keySet()) {
                String simple = code;
                if (simple.startsWith("\\var(\\malayalam(")) {
                    simple = simple.substring("\\var(\\malayalam(".length());
                    if (simple.endsWith("))")) {
                        simple = simple.substring(0, simple.length() - 2);
                    } else if (simple.endsWith(")")) {
                        simple = simple.substring(0, simple.length() - 1);
                    }
                }
                if (simple.startsWith("\\")) {
                    simple = simple.substring(1);
                }
                if (!simple.isBlank()) {
                    SuggestionRegistry.allSuggestions
                            .add(new Suggestion(simple, "Malayalam consonant (simple)", simple, "MalayalamSimple"));
                }
            }
        }
    }

    private static void addTeluguSuggestions() {
        if (Telugu.TELUGU_VOWEL_MAP != null) {
            Telugu.TELUGU_VOWEL_MAP.forEach(
                    (code, symbol) -> SuggestionRegistry.allSuggestions
                            .add(new Suggestion(code, "Telugu vowel", symbol, "Telugu")));
        }

        if (Telugu.TELUGU_CONSONANT_MAP != null) {
            Telugu.TELUGU_CONSONANT_MAP.forEach(
                    (code, symbol) -> SuggestionRegistry.allSuggestions
                            .add(new Suggestion(code, "Telugu consonant", symbol, "Telugu")));
        }
    }

    private static void addTeluguSimpleNames() {
        if (Telugu.TELUGU_VOWEL_MAP != null) {
            for (String code : Telugu.TELUGU_VOWEL_MAP.keySet()) {
                String simple = code;
                if (simple.startsWith("\\var(\\telugu(")) {
                    simple = simple.substring("\\var(\\telugu(".length());
                    if (simple.endsWith("))")) {
                        simple = simple.substring(0, simple.length() - 2);
                    } else if (simple.endsWith(")")) {
                        simple = simple.substring(0, simple.length() - 1);
                    }
                }
                if (simple.startsWith("\\")) {
                    simple = simple.substring(1);
                }
                if (!simple.isBlank()) {
                    SuggestionRegistry.allSuggestions
                            .add(new Suggestion(simple, "Telugu vowel (simple)", simple, "TeluguSimple"));
                }
            }
        }

        if (Telugu.TELUGU_CONSONANT_MAP != null) {
            for (String code : Telugu.TELUGU_CONSONANT_MAP.keySet()) {
                String simple = code;
                if (simple.startsWith("\\var(\\telugu(")) {
                    simple = simple.substring("\\var(\\telugu(".length());
                    if (simple.endsWith("))")) {
                        simple = simple.substring(0, simple.length() - 2);
                    } else if (simple.endsWith(")")) {
                        simple = simple.substring(0, simple.length() - 1);
                    }
                }
                if (simple.startsWith("\\")) {
                    simple = simple.substring(1);
                }
                if (!simple.isBlank()) {
                    SuggestionRegistry.allSuggestions
                            .add(new Suggestion(simple, "Telugu consonant (simple)", simple, "TeluguSimple"));
                }
            }
        }
    }

    /** Add physics constant suggestions from Uniconstant.SYMBOL_MAP */
    private static void addUniconstantSuggestions() {
        if (Uniconstant.SYMBOL_MAP != null) {
            Uniconstant.SYMBOL_MAP.forEach((code, symbol) -> {
                // code is in format: \con(\pi), \con(\gravity), etc.
                // Store full format so when selected, it inserts complete code.
                SuggestionRegistry.allSuggestions.add(new Suggestion(
                        code, // Full format: "\con(\pi)" for insertion
                        "Physics constant",
                        symbol, // Unicode symbol display
                        "Uniconstant"));
            });
        }
    }

    /** Add subscript and superscript suggestions from Subscript and Superscript maps */
    private static void addSubscriptSuperscriptSuggestions() {
        for (char ch = '0'; ch <= '9'; ch++) {
            if (Superscript.hasUnicode(ch)) {
                SuggestionRegistry.allSuggestions
                        .add(new Suggestion("^" + ch, "Superscript " + ch, Superscript.unicode(ch), "Math"));
            }
            if (Subscript.hasNumericSubscript(ch)) {
                SuggestionRegistry.allSuggestions
                        .add(new Suggestion("_" + ch, "Subscript " + ch, Subscript.numericSubscript(ch), "Math"));
            }
        }
    }
}
