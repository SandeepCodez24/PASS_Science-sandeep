package ui.ui_functions.suggestion_functions;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import ui.ui_functions.SuggestionProvider.Suggestion;

/**
 * Central holder for all shared, static suggestion state.
 *
 * <p>
 * Previously these collections lived as {@code private static} fields inside
 * {@code SuggestionProvider}. They are now centralized here with
 * package-private visibility so every helper in
 * {@code ui.ui_functions.suggestion_functions} can read/write them directly,
 * while the outside world keeps going through the {@code SuggestionProvider}
 * facade.
 *
 * <h3>User-defined code</h3>
 * Three collections hold what the user wrote in the current file, so the
 * popup can offer it back:
 * <ul>
 * <li>{@link #discoveredFunctions} -- top-level functions, in all three header
 * shapes;</li>
 * <li>{@link #discoveredClasses} -- classes, each carrying the variables its
 * {@code base} declares and its other methods;</li>
 * <li>{@link #instanceClasses} -- variables assigned from a class constructor
 * ({@code r = A(3)}), so {@code r.} completes like {@code A.}.</li>
 * </ul>
 * All three are rebuilt from scratch on every discovery pass, so they only
 * ever describe the current file.
 */
public final class SuggestionRegistry {

    private SuggestionRegistry() {
        // Utility holder – no instances.
    }

    /** Master list of every static suggestion. */
    static final List<Suggestion> allSuggestions = new ArrayList<>();

    /** Plain variable names discovered from the editor text. */
    static final Set<String> discoveredVariables = new LinkedHashSet<>();

    /**
     * Discovered variables with their roman search keys, script-specific
     * descriptions and declaration order.
     *
     * <p>
     * This is the collection that fixes the "only {@code A} shows up" bug: it
     * is keyed by the rendered name but each entry also carries the roman key
     * ({@code α → "alpha"}, {@code ஆ → "aa"}) that the filter actually matches
     * against, so one typed {@code a} surfaces every {@code a}-rooted variable
     * regardless of script.
     */
    static final Map<String, DiscoveredVariable> discoveredVariableInfo = new LinkedHashMap<>();

    /** Styled variables: raw code → encoded display. */
    static final Map<String, String> discoveredStyledVariables = new LinkedHashMap<>();

    /** User functions defined at file level: name → function. */
    static final Map<String, DiscoveredFunction> discoveredFunctions = new LinkedHashMap<>();

    /** User classes: name → class (with its base members and methods). */
    static final Map<String, DiscoveredClass> discoveredClasses = new LinkedHashMap<>();

    /** Variables built from a user class: variable name → class name. */
    static final Map<String, String> instanceClasses = new LinkedHashMap<>();

    /** Recently used symbols: simple name → full format. */
    static final Map<String, String> recentlyUsedSymbols = new LinkedHashMap<>();

    /** Recently used symbols: simple name → actual symbol character. */
    static final Map<String, String> recentlyUsedSymbolDisplays = new LinkedHashMap<>();

    static {
        // Build the static symbol tables exactly once, when the class loads.
        SuggestionInitializer.initializeSuggestions();
    }

    /**
     * No-op used by the facade to guarantee this class (and therefore the static
     * initializer above) is loaded before any lookups happen.
     */
    public static void ensureInitialized() {
        // Referencing the class is enough to trigger the static block.
    }

    /** Defensive copy of all static suggestions. */
    public static List<Suggestion> getAllSuggestions() {
        return new ArrayList<>(allSuggestions);
    }

    /** Defensive copy of the discovered user functions. */
    public static List<DiscoveredFunction> getDiscoveredFunctions() {
        return new ArrayList<>(discoveredFunctions.values());
    }

    /** Defensive copy of the discovered user classes. */
    public static List<DiscoveredClass> getDiscoveredClasses() {
        return new ArrayList<>(discoveredClasses.values());
    }

    /**
     * Resolves a name used before a {@code .}: a class name directly, or a
     * variable that was assigned from a class constructor.
     *
     * @param owner the text before the dot
     * @return the class, or null when the name is neither
     */
    public static DiscoveredClass resolveClass(String owner) {
        if (owner == null || owner.isEmpty()) {
            return null;
        }
        DiscoveredClass direct = discoveredClasses.get(owner);
        if (direct != null) {
            return direct;
        }
        String className = instanceClasses.get(owner);
        return className == null ? null : discoveredClasses.get(className);
    }

    /** Defensive copy of the discovered variable metadata. */
    public static List<DiscoveredVariable> getDiscoveredVariableInfo() {
        return new ArrayList<>(discoveredVariableInfo.values());
    }
}
