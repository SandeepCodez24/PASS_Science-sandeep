package ui.ui_functions.suggestion_functions;

import language.language_ui.handler.NcBlockScanner;

/**
 * Answers one question for the suggestion trigger: is the caret sitting in
 * code, or in text the language does not read -- a string literal or a
 * comment?
 *
 * <h3>No new scanner</h3>
 * String and comment rules already live in exactly two places that agree with
 * each other, {@code SourceModel} and {@link NcBlockScanner}. This class adds a
 * third <i>user</i> of those rules, not a third copy of them:
 *
 * <pre>
 *   masked = NcBlockScanner.logicalCode(textBeforeCaret + "x")
 * </pre>
 *
 * The sentinel {@code x} survives only when the caret is in code. Inside an
 * open literal it is blanked to a space; after a {@code #} or {@code \\}
 * comment marker it is cut off with the rest of the comment. The editor's
 * {@code :} autofill already uses the same trick to decide whether a colon is
 * syntax, so the popup and the autofill can never disagree about where a
 * string ends.
 *
 * <h3>Continuations</h3>
 * A literal may be split across lines with a trailing {@code ~~}. The lines of
 * the current continuation group are joined first, exactly as
 * {@code SourceModel} joins them, so the second half of a split message is
 * still recognised as being inside the string.
 */
public final class SuggestionScope {

    private static final String CONTINUATION = "~~";
    private static final char SENTINEL = 'x';

    private SuggestionScope() {
    }

    /**
     * @param document the whole editor text
     * @param caret    the caret offset in {@code document}
     * @return true when suggestions must not open: the caret is inside a
     *         string literal or a comment
     */
    public static boolean isSuppressed(String document, int caret) {
        if (document == null || document.isEmpty()) {
            return false;
        }
        int safeCaret = Math.max(0, Math.min(caret, document.length()));
        return isSuppressedInLine(logicalLineBefore(document, safeCaret));
    }

    /**
     * Same test for a single line of input, such as the Command Window prompt.
     *
     * @param textBeforeCaret the line's text from its start up to the caret
     * @return true inside a string literal or a comment
     */
    public static boolean isSuppressedInLine(String textBeforeCaret) {
        if (textBeforeCaret == null || textBeforeCaret.isEmpty()) {
            return false;
        }
        String masked = NcBlockScanner.logicalCode(textBeforeCaret + SENTINEL);
        return masked.isEmpty() || masked.charAt(masked.length() - 1) != SENTINEL;
    }

    /**
     * The text of the current logical line up to the caret: every earlier
     * physical line of the same {@code ~~} group, with its marker removed,
     * followed by the current line up to the caret.
     */
    private static String logicalLineBefore(String document, int caret) {
        int lineStart = document.lastIndexOf('\n', Math.max(0, caret - 1)) + 1;
        if (caret == 0) {
            lineStart = 0;
        }
        StringBuilder joined = new StringBuilder(document.substring(lineStart, caret));

        int cursor = lineStart;
        while (cursor > 0) {
            int prevEnd = cursor - 1; // the '\n' ending the previous line
            int prevStart = document.lastIndexOf('\n', Math.max(0, prevEnd - 1)) + 1;
            if (prevEnd == 0) {
                prevStart = 0;
            }
            String previous = stripTrailingWhitespace(document.substring(prevStart, prevEnd));
            if (!previous.endsWith(CONTINUATION)) {
                break;
            }
            joined.insert(0, previous.substring(0, previous.length() - CONTINUATION.length()));
            cursor = prevStart;
        }
        return joined.toString();
    }

    private static String stripTrailingWhitespace(String text) {
        int end = text.length();
        while (end > 0 && Character.isWhitespace(text.charAt(end - 1))) {
            end--;
        }
        return text.substring(0, end);
    }
}
