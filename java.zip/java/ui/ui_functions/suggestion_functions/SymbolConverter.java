package ui.ui_functions.suggestion_functions;

import java.util.Map;

import language.replace.Greek;
import language.replace.Malayalam;
import language.replace.Sanskrit;
import language.replace.Tamil;
import language.replace.Telugu;
import ui.ui_functions.SuggestionProvider.Suggestion;

/**
 * Converts simple symbol names to their Unicode characters, extracts simple
 * names back out of full symbol codes, and maintains the recently-used cache.
 *
 * <p>
 * Extracted from {@code SuggestionProvider}'s
 * {@code getSymbolCharacter} / {@code extractSimpleSymbolName} /
 * {@code addRecentlyUsedSymbol}.
 */
public final class SymbolConverter {

    private SymbolConverter() {
        // Utility class – no instances.
    }

    /**
     * Convert a symbol name to its actual Unicode character.
     * Examples: "alpha" → "α", "kaa" → "கா", "mu" → "μ".
     *
     * @param symbolName the simple name (e.g. "alpha", "mu", "kaa", "i")
     * @return the actual Unicode symbol, or the original name if not found
     */
    public static String getSymbolCharacter(String symbolName) {
        if (symbolName == null || symbolName.isEmpty()) {
            return symbolName;
        }

        String lowerName = symbolName.toLowerCase().trim();

        // Greek
        if (Greek.SYMBOL_MAP != null) {
            String[] possibleKeys = {
                    "\\" + lowerName,
                    "\\var(\\" + lowerName + ")",
                    "\\" + symbolName
            };
            for (String key : possibleKeys) {
                if (Greek.SYMBOL_MAP.containsKey(key)) {
                    return Greek.SYMBOL_MAP.get(key);
                }
            }
            for (Map.Entry<String, String> entry : Greek.SYMBOL_MAP.entrySet()) {
                if (entry.getKey().contains("\\" + lowerName)) {
                    return entry.getValue();
                }
            }
        }

        // Sanskrit
        if (Sanskrit.SYMBOL_MAP != null) {
            String[] possibleSanskritKeys = {
                    "\\" + lowerName,
                    "\\var(\\sanskrit(\\" + lowerName + "))",
                    "\\" + symbolName
            };
            for (String key : possibleSanskritKeys) {
                if (Sanskrit.SYMBOL_MAP.containsKey(key)) {
                    return Sanskrit.SYMBOL_MAP.get(key);
                }
            }
            for (Map.Entry<String, String> entry : Sanskrit.SYMBOL_MAP.entrySet()) {
                if (entry.getKey().contains("\\" + lowerName)) {
                    return entry.getValue();
                }
            }
        }

        // Tamil vowels
        if (Tamil.TAMIL_VOWEL_MAP != null) {
            String[] possibleTamilVowelKeys = {
                    "\\" + lowerName,
                    "\\var(\\tamil(\\" + lowerName + "))",
                    "\\" + symbolName
            };
            for (String key : possibleTamilVowelKeys) {
                if (Tamil.TAMIL_VOWEL_MAP.containsKey(key)) {
                    return Tamil.TAMIL_VOWEL_MAP.get(key);
                }
            }
            for (Map.Entry<String, String> entry : Tamil.TAMIL_VOWEL_MAP.entrySet()) {
                if (entry.getKey().contains("\\" + lowerName)) {
                    return entry.getValue();
                }
            }
        }

        // Tamil consonants
        if (Tamil.TAMIL_CONSONANT_MAP != null) {
            String[] possibleTamilConsonantKeys = {
                    "\\" + lowerName,
                    "\\var(\\tamil(\\" + lowerName + "))",
                    "\\" + symbolName
            };
            for (String key : possibleTamilConsonantKeys) {
                if (Tamil.TAMIL_CONSONANT_MAP.containsKey(key)) {
                    return Tamil.TAMIL_CONSONANT_MAP.get(key);
                }
            }
            for (Map.Entry<String, String> entry : Tamil.TAMIL_CONSONANT_MAP.entrySet()) {
                if (entry.getKey().contains("\\" + lowerName)) {
                    return entry.getValue();
                }
            }
        }

        // Malayalam vowels
        if (Malayalam.MALAYALAM_VOWEL_MAP != null) {
            String[] possibleMalayalamVowelKeys = {
                    "\\" + lowerName,
                    "\\var(\\malayalam(\\" + lowerName + "))",
                    "\\" + symbolName
            };
            for (String key : possibleMalayalamVowelKeys) {
                if (Malayalam.MALAYALAM_VOWEL_MAP.containsKey(key)) {
                    return Malayalam.MALAYALAM_VOWEL_MAP.get(key);
                }
            }
            for (Map.Entry<String, String> entry : Malayalam.MALAYALAM_VOWEL_MAP.entrySet()) {
                if (entry.getKey().contains("\\" + lowerName)) {
                    return entry.getValue();
                }
            }
        }

        // Malayalam consonants
        if (Malayalam.MALAYALAM_CONSONANT_MAP != null) {
            String[] possibleMalayalamConsonantKeys = {
                    "\\" + lowerName,
                    "\\var(\\malayalam(\\" + lowerName + "))",
                    "\\" + symbolName
            };
            for (String key : possibleMalayalamConsonantKeys) {
                if (Malayalam.MALAYALAM_CONSONANT_MAP.containsKey(key)) {
                    return Malayalam.MALAYALAM_CONSONANT_MAP.get(key);
                }
            }
            for (Map.Entry<String, String> entry : Malayalam.MALAYALAM_CONSONANT_MAP.entrySet()) {
                if (entry.getKey().contains("\\" + lowerName)) {
                    return entry.getValue();
                }
            }
        }

        // Telugu vowels
        if (Telugu.TELUGU_VOWEL_MAP != null) {
            String[] possibleTeluguVowelKeys = {
                    "\\" + lowerName,
                    "\\var(\\telugu(\\" + lowerName + "))",
                    "\\" + symbolName
            };
            for (String key : possibleTeluguVowelKeys) {
                if (Telugu.TELUGU_VOWEL_MAP.containsKey(key)) {
                    return Telugu.TELUGU_VOWEL_MAP.get(key);
                }
            }
            for (Map.Entry<String, String> entry : Telugu.TELUGU_VOWEL_MAP.entrySet()) {
                if (entry.getKey().contains("\\" + lowerName)) {
                    return entry.getValue();
                }
            }
        }

        // Telugu consonants
        if (Telugu.TELUGU_CONSONANT_MAP != null) {
            String[] possibleTeluguConsonantKeys = {
                    "\\" + lowerName,
                    "\\var(\\telugu(\\" + lowerName + "))",
                    "\\" + symbolName
            };
            for (String key : possibleTeluguConsonantKeys) {
                if (Telugu.TELUGU_CONSONANT_MAP.containsKey(key)) {
                    return Telugu.TELUGU_CONSONANT_MAP.get(key);
                }
            }
            for (Map.Entry<String, String> entry : Telugu.TELUGU_CONSONANT_MAP.entrySet()) {
                if (entry.getKey().contains("\\" + lowerName)) {
                    return entry.getValue();
                }
            }
        }

        // Fallback: check registry for actual symbol categories
        for (Suggestion s : SuggestionRegistry.allSuggestions) {
            if ("Greek".equals(s.getCategory()) && s.getCode().equalsIgnoreCase(lowerName)) {
                return s.getDisplay();
            }
        }
        for (Suggestion s : SuggestionRegistry.allSuggestions) {
            if ("Tamil".equals(s.getCategory()) && s.getCode().equalsIgnoreCase(lowerName)) {
                return s.getDisplay();
            }
        }

        // Not found, return original name
        return symbolName;
    }

    /**
     * Extract the simple symbol name from a full symbol code.
     * Examples: \var(\alpha) → alpha, \var(\tamil(\i)) → i.
     *
     * <p>
     * <b>Bug fix:</b> the script-specific prefixes ({@code \var(\tamil(},
     * {@code \var(\sanskrit(}, {@code \var(\malayalam(}, {@code \var(\telugu(})
     * are now checked <i>before</i> the generic Greek prefix {@code \var(\}.
     * Previously the Greek branch (which only checks {@code \var(\ ... )})
     * matched Tamil/Sanskrit/etc codes first and returned a wrong value such as
     * {@code "tamil(\i)"} instead of {@code "i"}.
     *
     * @param symbolCode the full symbol code
     * @return the simple name, or the original code if not a symbol format
     */
    private static String extractSimpleSymbolName(String symbolCode) {
        if (symbolCode == null || symbolCode.isEmpty()) {
            return symbolCode;
        }

        // For Tamil: \var(\tamil(\i)) → i   (check specific scripts first)
        if (symbolCode.startsWith("\\var(\\tamil(") && symbolCode.endsWith("))")) {
            String extracted = symbolCode.substring("\\var(\\tamil(".length());
            if (extracted.endsWith("))")) {
                extracted = extracted.substring(0, extracted.length() - 2);
            } else if (extracted.endsWith(")")) {
                extracted = extracted.substring(0, extracted.length() - 1);
            }
            if (extracted.startsWith("\\")) {
                extracted = extracted.substring(1);
            }
            return extracted;
        }

        // For Sanskrit: \var(\sanskrit(\a)) → a
        if (symbolCode.startsWith("\\var(\\sanskrit(") && symbolCode.endsWith("))")) {
            String extracted = symbolCode.substring("\\var(\\sanskrit(".length());
            if (extracted.endsWith("))")) {
                extracted = extracted.substring(0, extracted.length() - 2);
            } else if (extracted.endsWith(")")) {
                extracted = extracted.substring(0, extracted.length() - 1);
            }
            if (extracted.startsWith("\\")) {
                extracted = extracted.substring(1);
            }
            return extracted;
        }

        // For Malayalam: \var(\malayalam(\a)) → a
        if (symbolCode.startsWith("\\var(\\malayalam(") && symbolCode.endsWith("))")) {
            String extracted = symbolCode.substring("\\var(\\malayalam(".length());
            if (extracted.endsWith("))")) {
                extracted = extracted.substring(0, extracted.length() - 2);
            } else if (extracted.endsWith(")")) {
                extracted = extracted.substring(0, extracted.length() - 1);
            }
            if (extracted.startsWith("\\")) {
                extracted = extracted.substring(1);
            }
            return extracted;
        }

        // For Telugu: \var(\telugu(\a)) → a
        if (symbolCode.startsWith("\\var(\\telugu(") && symbolCode.endsWith("))")) {
            String extracted = symbolCode.substring("\\var(\\telugu(".length());
            if (extracted.endsWith("))")) {
                extracted = extracted.substring(0, extracted.length() - 2);
            } else if (extracted.endsWith(")")) {
                extracted = extracted.substring(0, extracted.length() - 1);
            }
            if (extracted.startsWith("\\")) {
                extracted = extracted.substring(1);
            }
            return extracted;
        }

        // For Greek (generic fallback): \var(\alpha) → alpha
        if (symbolCode.startsWith("\\var(\\") && symbolCode.endsWith(")")) {
            String extracted = symbolCode.substring(5); // Remove \var(
            if (extracted.endsWith(")")) {
                extracted = extracted.substring(0, extracted.length() - 1); // Remove )
            }
            if (extracted.startsWith("\\")) {
                extracted = extracted.substring(1); // Remove leading \
            }
            return extracted;
        }

        // For Uniconstant: \con(\pi) → pi
        // Return original if not a recognized symbol format
        return symbolCode;
    }

    /**
     * Add a symbol to the recently-used set.
     * Stores the mapping from simple name → full format and symbol character.
     *
     * @param symbolCode the symbol code (full format like \var(\alpha) preferred)
     */
    public static void addRecentlyUsedSymbol(String symbolCode) {
        if (symbolCode != null && !symbolCode.trim().isEmpty()) {
            String fullFormat = symbolCode.trim();

            // Keep this cache dedicated to actual symbol shortcuts only.
            // Styled variables like name_{sub} should not appear as raw fallback entries.
            if (!fullFormat.startsWith("\\var(")) {
                return;
            }

            String simpleName = extractSimpleSymbolName(fullFormat);

            // Store mapping: simple name → full format
            SuggestionRegistry.recentlyUsedSymbols.put(simpleName.toLowerCase(), fullFormat);

            // Also store the actual symbol character for display
            String symbolDisplay = getSymbolCharacter(simpleName);
            SuggestionRegistry.recentlyUsedSymbolDisplays.put(simpleName.toLowerCase(), symbolDisplay);

            // Keep only last 20 recently used
            if (SuggestionRegistry.recentlyUsedSymbols.size() > 20) {
                String keyToRemove = SuggestionRegistry.recentlyUsedSymbols.keySet().iterator().next();
                SuggestionRegistry.recentlyUsedSymbols.remove(keyToRemove);
                SuggestionRegistry.recentlyUsedSymbolDisplays.remove(keyToRemove);
            }
        }
    }
}
