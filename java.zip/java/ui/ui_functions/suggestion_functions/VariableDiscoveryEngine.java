package ui.ui_functions.suggestion_functions;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Parses the editor text and discovers variables (plain + styled) that should
 * be offered as autocomplete suggestions.
 *
 * <p>
 * Populates {@link SuggestionRegistry#discoveredVariables},
 * {@link SuggestionRegistry#discoveredVariableInfo} and
 * {@link SuggestionRegistry#discoveredStyledVariables}.
 *
 * <h3>Bug fix: non-English declarations were never discovered</h3>
 * Every declaration pattern used the ASCII-only identifier class
 * {@code [a-zA-Z_][a-zA-Z0-9_]*}. A line such as
 *
 * <pre>
 *   &#945; = 1.24;
 *   &#2949; = sin(0);
 *   &#2965;&#3007; = "&#2970;&#3019;&#2996; &#2984;&#3006;&#2975;&#3009;";
 * </pre>
 *
 * therefore matched nothing at all, so Greek / Tamil / Sanskrit / Telugu /
 * Malayalam variables simply did not exist as far as the suggestion popup was
 * concerned. Typing {@code a} could only ever surface the ASCII {@code A}.
 *
 * <p>
 * The patterns below use Unicode properties ({@code \p{L}} letters,
 * {@code \p{M}} combining marks — required because Tamil / Malayalam / Telugu
 * consonant-vowel forms such as {@code &#2965;&#3007;} are a base letter plus a
 * dependent vowel sign — and {@code \p{N}} digits), so every script is
 * discovered on equal footing.
 *
 * <h3>Declaration order is now recorded</h3>
 * Each variable remembers the line it was declared on. The ranker uses that as
 * a final tie-break so variables appear in the order the user wrote them.
 */
public final class VariableDiscoveryEngine {

    private VariableDiscoveryEngine() {
        // Utility class – no instances.
    }

    /**
     * A Neural Code identifier: starts with any Unicode letter or underscore,
     * continues with letters, combining marks (dependent vowel signs / virama),
     * digits and underscores.
     */
    private static final String IDENT = "[\\p{L}_][\\p{L}\\p{M}\\p{N}_]*";

    /** Nothing identifier-like may precede a match (a manual word boundary). */
    private static final String NOT_IDENT_BEFORE = "(?<![\\p{L}\\p{M}\\p{N}_])";

    // ── Styled (subscript / superscript) declarations ────────────────────────

    private static final Pattern STYLED = Pattern.compile(
            NOT_IDENT_BEFORE + "(" + IDENT + ")(?:__|_)\\{([^}]+)\\}(\\^\\{([^}]+)\\})?\\s*=");

    private static final Pattern SUP_ONLY = Pattern.compile(
            NOT_IDENT_BEFORE + "(" + IDENT + ")\\^\\{([^}]+)\\}\\s*=");

    private static final Pattern LIVE_STYLED = Pattern.compile(
            NOT_IDENT_BEFORE + "(" + IDENT + ")(?:\\u200D{1,3}([^\\u200D\\n\\r=]+)\\u200D{1,3})?"
                    + "(?:\\u200C{3}([^\\u200C\\n\\r=]+)\\u200C{3})?\\s*=");

    // ── Plain declarations ───────────────────────────────────────────────────

    private static final Pattern DECL = Pattern.compile(
            NOT_IDENT_BEFORE + "(var|let|const)\\s+(" + IDENT + ")\\s*=");

    private static final Pattern TYPED = Pattern.compile(
            NOT_IDENT_BEFORE + "(" + IDENT + ")\\s+(" + IDENT + ")\\s*[=;]");

    /**
     * Bare assignment. The {@code (?!=)} lookahead keeps {@code ==}, {@code >=},
     * {@code <=} and {@code !=} comparisons from being mistaken for
     * declarations.
     */
    private static final Pattern BARE = Pattern.compile(
            NOT_IDENT_BEFORE + "(" + IDENT + ")\\s*=(?!=)");

    private static final Pattern FUNC = Pattern.compile(
            NOT_IDENT_BEFORE + "function\\s+(" + IDENT + ")\\s*\\(");

    private static final Set<String> KEYWORDS_AND_TYPES = new HashSet<>(Arrays.asList(
            "var", "let", "const", "int", "float", "double", "String", "boolean",
            "List", "Map", "Set", "Array", "Object", "function", "class", "if",
            "else", "for", "while", "return", "break", "continue", "true", "false",
            "null", "void", "static", "public", "private", "protected", "new"));

    /**
     * Extract variable names from the code and add them as suggestions.
     * Handles keyword declarations, type declarations, bare assignments,
     * function definitions, and styled (subscript/superscript) variables, in
     * every supported script.
     *
     * @param text the full code text
     */
    public static void updateVariablesFromText(String text) {
        SuggestionRegistry.discoveredVariables.clear();
        SuggestionRegistry.discoveredVariableInfo.clear();
        SuggestionRegistry.discoveredStyledVariables.clear();
        VariableKindIndex.clear();
        if (text == null || text.isEmpty()) {
            return;
        }

        Set<String> styledBaseNames = new HashSet<>();

        // Scan line by line: comment lines are skipped outright and the line
        // index becomes the declaration order used for ranking tie-breaks.
        String[] lines = text.split("\\R", -1);
        for (int lineIndex = 0; lineIndex < lines.length; lineIndex++) {
            String line = stripComment(lines[lineIndex]);
            if (line.isBlank()) {
                continue;
            }
            scanStyled(line, styledBaseNames);
            scanPlain(line, lineIndex, styledBaseNames);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // LINE SCANNING
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Removes a trailing comment and returns "" for a banner line.
     * The sample scripts use {@code ####} banners and {@code \\} trailing
     * notes; neither must ever be parsed as a declaration.
     */
    private static String stripComment(String rawLine) {
        if (rawLine == null) {
            return "";
        }
        String line = rawLine;
        int hash = line.indexOf('#');
        if (hash >= 0) {
            line = line.substring(0, hash);
        }
        int trailingNote = line.indexOf("\\\\");
        if (trailingNote >= 0) {
            line = line.substring(0, trailingNote);
        }
        int lineComment = line.indexOf("//");
        if (lineComment >= 0) {
            line = line.substring(0, lineComment);
        }
        return line;
    }

    /** Pattern 0 / 0b / 0c: styled (subscript / superscript) declarations. */
    private static void scanStyled(String line, Set<String> styledBaseNames) {
        // Pattern 0: v_{x} = 1, v_{x}^{2} = 1
        Matcher styledMatcher = STYLED.matcher(line);
        while (styledMatcher.find()) {
            String base = styledMatcher.group(1);
            String sub = styledMatcher.group(2);
            String sup = styledMatcher.group(4);
            String raw = base + "__{" + sub + "}";
            String display = base + "[SUB:" + sub + "]";
            if (sup != null && !sup.isEmpty()) {
                raw += "^{" + sup + "}";
                display += "[SUP:" + sup + "]";
            }
            styledBaseNames.add(base);
            SuggestionRegistry.discoveredStyledVariables.put(raw, display);
        }

        // Pattern 0b: x^{2} = 9
        Matcher supOnlyMatcher = SUP_ONLY.matcher(line);
        while (supOnlyMatcher.find()) {
            String base = supOnlyMatcher.group(1);
            String sup = supOnlyMatcher.group(2);
            String raw = base + "^{" + sup + "}";
            String display = base + "[SUP:" + sup + "]";
            styledBaseNames.add(base);
            SuggestionRegistry.discoveredStyledVariables.put(raw, display);
        }

        // Pattern 0c: already converted by the live replacement engine.
        // Subscript groups use U+200D (ZWJ), superscript U+200C (ZWNJ).
        Matcher liveStyledMatcher = LIVE_STYLED.matcher(line);
        while (liveStyledMatcher.find()) {
            String base = liveStyledMatcher.group(1);
            String sub = liveStyledMatcher.group(2);
            String sup = liveStyledMatcher.group(3);
            boolean hasSub = sub != null && !sub.isBlank();
            boolean hasSup = sup != null && !sup.isBlank();
            if (!hasSub && !hasSup) {
                continue;
            }
            String raw = base;
            String display = base;
            if (hasSub) {
                raw += "__{" + sub + "}";
                display += "[SUB:" + sub + "]";
            }
            if (hasSup) {
                raw += "^{" + sup + "}";
                display += "[SUP:" + sup + "]";
            }
            styledBaseNames.add(base);
            SuggestionRegistry.discoveredStyledVariables.put(raw, display);
        }
    }

    /** Patterns 1–4: plain declarations, in any script. */
    private static void scanPlain(String line, int lineIndex, Set<String> styledBaseNames) {
        // Pattern 1: var/let/const name = ...
        Matcher m1 = DECL.matcher(line);
        while (m1.find()) {
            // The pattern ends at '=', so everything after the match end is the
            // literal. Taking it per-match rather than per-line keeps
            // "a = 1; b = "x";" correct instead of typing both from the first
            // right-hand side.
            record(m1.group(2), lineIndex, styledBaseNames, line.substring(m1.end()));
        }

        // Pattern 2: type-declared variables like: int x, String name
        Matcher m2 = TYPED.matcher(line);
        while (m2.find()) {
            String type = m2.group(1);
            String varName = m2.group(2);
            if (!isKeywordOrType(type)) {
                record(varName, lineIndex, styledBaseNames, line.substring(m2.end()));
            }
        }

        // Pattern 3: bare assignments (no var/let/const keyword)
        Matcher m3 = BARE.matcher(line);
        while (m3.find()) {
            record(m3.group(1), lineIndex, styledBaseNames, line.substring(m3.end()));
        }

        // Pattern 4: function / method definitions. Not a variable — this is
        // the user's own code, and it gets the user-function marker rather than
        // the built-in one.
        Matcher m4 = FUNC.matcher(line);
        while (m4.find()) {
            String functionName = m4.group(1);
            record(functionName, lineIndex, styledBaseNames, "");
            VariableKindIndex.recordKind(functionName, SuggestionKind.FUNCTION_USER);
        }
    }

    /**
     * Registers one discovered variable, building its roman search keys and
     * script-specific description on the way in.
     */
    private static void record(String varName, int lineIndex, Set<String> styledBaseNames,
            String rightHandSide) {
        if (varName == null || varName.isBlank()) {
            return;
        }
        if (isKeywordOrType(varName) || styledBaseNames.contains(varName)) {
            return;
        }

        SuggestionRegistry.discoveredVariables.add(varName);
        VariableKindIndex.record(varName, rightHandSide);

        // First declaration wins, so the recorded line index is the line the
        // variable was introduced on rather than the last line it was touched.
        SuggestionRegistry.discoveredVariableInfo.computeIfAbsent(
                varName, name -> new DiscoveredVariable(name, lineIndex));
    }

    /** Check if a string is a common keyword or type name. */
    private static boolean isKeywordOrType(String word) {
        return KEYWORDS_AND_TYPES.contains(word);
    }
}
