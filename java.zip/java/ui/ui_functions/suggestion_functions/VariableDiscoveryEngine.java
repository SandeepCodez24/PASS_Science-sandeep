package ui.ui_functions.suggestion_functions;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Parses the editor text and discovers variables (plain + styled) that should
 * be offered as autocomplete suggestions.
 *
 * <p>
 * Populates {@link SuggestionRegistry#discoveredVariables} and
 * {@link SuggestionRegistry#discoveredStyledVariables}. Extracted from
 * {@code SuggestionProvider.updateVariablesFromText}.
 */
public final class VariableDiscoveryEngine {

    private VariableDiscoveryEngine() {
        // Utility class – no instances.
    }

    // Pre-compiled patterns (compiling once instead of per-call is a small win).
    private static final Pattern STYLED = Pattern.compile(
            "\\b([a-zA-Z_][a-zA-Z0-9_]*)(?:__|_)\\{([^}]+)\\}(\\^\\{([^}]+)\\})?\\s*=");
    private static final Pattern SUP_ONLY = Pattern.compile(
            "\\b([a-zA-Z_][a-zA-Z0-9_]*)\\^\\{([^}]+)\\}\\s*=");
    private static final Pattern LIVE_STYLED = Pattern.compile(
            "\\b([a-zA-Z_][a-zA-Z0-9_]*)(?:\\u200D{1,3}([^\\u200D\\n\\r=]+)\\u200D{1,3})?"
                    + "(?:\\u200C{3}([^\\u200C\\n\\r=]+)\\u200C{3})?\\s*=");
    private static final Pattern DECL = Pattern.compile(
            "\\b(var|let|const)\\s+([a-zA-Z_][a-zA-Z0-9_]*)\\s*=");
    private static final Pattern TYPED = Pattern.compile(
            "\\b([a-zA-Z_][a-zA-Z0-9_]*)\\s+([a-zA-Z_][a-zA-Z0-9_]*)\\s*[=;]");
    private static final Pattern BARE = Pattern.compile(
            "\\b([a-zA-Z_][a-zA-Z0-9_]*)\\s*=");
    private static final Pattern FUNC = Pattern.compile(
            "\\bfunction\\s+([a-zA-Z_][a-zA-Z0-9_]*)\\s*\\(");

    private static final Set<String> KEYWORDS_AND_TYPES = new HashSet<>(Arrays.asList(
            "var", "let", "const", "int", "float", "double", "String", "boolean",
            "List", "Map", "Set", "Array", "Object", "function", "class", "if",
            "else", "for", "while", "return", "break", "continue", "true", "false",
            "null", "void", "static", "public", "private", "protected", "new"));

    /**
     * Extract variable names from the code and add them as suggestions.
     * Handles keyword declarations, type declarations, bare assignments,
     * function definitions, and styled (subscript/superscript) variables.
     *
     * @param text the full code text
     */
    public static void updateVariablesFromText(String text) {
        SuggestionRegistry.discoveredVariables.clear();
        SuggestionRegistry.discoveredStyledVariables.clear();

        if (text == null || text.isEmpty())
            return;

        Set<String> styledBaseNames = new HashSet<>();

        // Pattern 0: Styled variable assignments with optional superscript.
        // Matches: v_{x} = 1, v_{x}^{2} = 1
        Matcher styledMatcher = STYLED.matcher(text);
        while (styledMatcher.find()) {
            String base = styledMatcher.group(1);
            String sub = styledMatcher.group(2);
            String sup = styledMatcher.group(4);

            String raw = base + "__{" + sub + "}";
            String display = base + "[SUB:" + sub + "]";
            if (sup != null && !sup.isEmpty()) {
                raw += "^{" + sup + "}";
                display += "[SUP:" + sup + "]";
            }

            styledBaseNames.add(base);
            SuggestionRegistry.discoveredStyledVariables.put(raw, display);
        }

        // Pattern 0b: Superscript-only styled variable assignments.
        // Matches: x^{2} = 9
        Matcher supOnlyMatcher = SUP_ONLY.matcher(text);
        while (supOnlyMatcher.find()) {
            String base = supOnlyMatcher.group(1);
            String sup = supOnlyMatcher.group(2);

            String raw = base + "^{" + sup + "}";
            String display = base + "[SUP:" + sup + "]";

            styledBaseNames.add(base);
            SuggestionRegistry.discoveredStyledVariables.put(raw, display);
        }

        // Pattern 0c: Variables already converted by the live replacement engine.
        // Subscript groups use U+200D (ZWJ), superscript groups use U+200C (ZWNJ).
        Matcher liveStyledMatcher = LIVE_STYLED.matcher(text);
        while (liveStyledMatcher.find()) {
            String base = liveStyledMatcher.group(1);
            String sub = liveStyledMatcher.group(2);
            String sup = liveStyledMatcher.group(3);

            boolean hasSub = sub != null && !sub.isBlank();
            boolean hasSup = sup != null && !sup.isBlank();
            if (!hasSub && !hasSup) {
                continue;
            }

            String raw = base;
            String display = base;

            if (hasSub) {
                raw += "__{" + sub + "}";
                display += "[SUB:" + sub + "]";
            }
            if (hasSup) {
                raw += "^{" + sup + "}";
                display += "[SUP:" + sup + "]";
            }

            styledBaseNames.add(base);
            SuggestionRegistry.discoveredStyledVariables.put(raw, display);
        }

        // Pattern 1: var/let/const name = ...
        Matcher m1 = DECL.matcher(text);
        while (m1.find()) {
            String varName = m1.group(2);
            if (!styledBaseNames.contains(varName)) {
                SuggestionRegistry.discoveredVariables.add(varName);
            }
        }

        // Pattern 2: Type-declared variables like: int x, String name, etc.
        Matcher m2 = TYPED.matcher(text);
        while (m2.find()) {
            String type = m2.group(1);
            String varName = m2.group(2);
            if (!isKeywordOrType(type) && !isKeywordOrType(varName) && !styledBaseNames.contains(varName)) {
                SuggestionRegistry.discoveredVariables.add(varName);
            }
        }

        // Pattern 3: Bare variable assignments (no var/let/const keyword)
        Matcher m3 = BARE.matcher(text);
        while (m3.find()) {
            String varName = m3.group(1);
            if (!isKeywordOrType(varName) && !styledBaseNames.contains(varName)) {
                SuggestionRegistry.discoveredVariables.add(varName);
            }
        }

        // Pattern 4: Function/method definitions
        Matcher m4 = FUNC.matcher(text);
        while (m4.find()) {
            String funcName = m4.group(1);
            SuggestionRegistry.discoveredVariables.add(funcName);
        }
    }

    /** Check if a string is a common keyword or type name. */
    private static boolean isKeywordOrType(String word) {
        return KEYWORDS_AND_TYPES.contains(word);
    }
}
