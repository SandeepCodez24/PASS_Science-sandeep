package ui.ui_functions.suggestion_functions;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import language.language_ui.handler.NcBlockScanner;
import language.syntax.syntax_checker.BlockHeaderGrammar;

/**
 * Parses the editor text and discovers what the user declared, so the
 * suggestion popup can offer it back.
 *
 * <p>
 * Populates, in {@link SuggestionRegistry}: {@code discoveredVariables},
 * {@code discoveredVariableInfo}, {@code discoveredStyledVariables},
 * {@code discoveredFunctions}, {@code discoveredClasses} and
 * {@code instanceClasses}.
 *
 * <h3>What changed: user functions and classes</h3>
 * <ol>
 * <li><b>Every function header shape is read.</b> The old pattern,
 * {@code function\s+name\s*\(}, only matched {@code function f(x)}. A function
 * written {@code function ASD = f(x):} or {@code function [a, b] = f(x):} was
 * never discovered, and {@code ASD} was registered instead through the
 * bare-assignment rule. Headers are now read with {@link BlockHeaderGrammar},
 * the same grammar the error checker uses.</li>
 * <li><b>Functions are their own rows.</b> A user function used to be stored as
 * a <i>variable</i> with a function icon. It now goes into
 * {@code discoveredFunctions} and is offered as {@code f(x)}, inserting
 * {@code f(} with the caret inside the brackets.</li>
 * <li><b>Classes are discovered, with their members.</b> The block structure is
 * tracked while scanning, and every variable declared inside a class's
 * {@code base} function -- {@code base.age = 1;} or {@code age = 1;} -- is
 * recorded as a member of that class. {@code base} and {@code info} themselves
 * are never offered; other methods are.</li>
 * <li><b>Instances are linked to their class.</b> {@code r = A(3);} records
 * {@code r} as an {@code A}, so {@code r.} completes like {@code A.}.</li>
 * <li><b>Field assignments are no longer global variables.</b> The
 * bare-assignment rule used to register {@code age} from
 * {@code base.age = "age";}. A name preceded by {@code .} is now skipped.</li>
 * <li><b>Comments are stripped the way the checker strips them.</b> A
 * {@code #} inside a string no longer truncates the line, and {@code //} --
 * integer division in Neural Code -- is no longer treated as a comment.</li>
 * </ol>
 *
 * <h3>Non-English declarations</h3>
 * The patterns use Unicode properties ({@code \p{L}} letters, {@code \p{M}}
 * combining marks, {@code \p{N}} digits), so Greek / Tamil / Sanskrit / Telugu /
 * Malayalam variables are discovered on equal footing with ASCII ones. Each
 * variable remembers the line it was declared on, which the ranker uses as a
 * final tie-break.
 */
public final class VariableDiscoveryEngine {

    private VariableDiscoveryEngine() {
        // Utility class – no instances.
    }

    /**
     * A Neural Code identifier: starts with any Unicode letter or underscore,
     * continues with letters, combining marks (dependent vowel signs / virama),
     * digits and underscores.
     */
    private static final String IDENT = "[\\p{L}_][\\p{L}\\p{M}\\p{N}_]*";

    /** Nothing identifier-like may precede a match (a manual word boundary). */
    private static final String NOT_IDENT_BEFORE = "(?<![\\p{L}\\p{M}\\p{N}_])";

    /** As {@link #NOT_IDENT_BEFORE}, and not a field after a dot either. */
    private static final String NOT_IDENT_OR_DOT_BEFORE = "(?<![\\p{L}\\p{M}\\p{N}_.])";

    // ── Styled (subscript / superscript) declarations ────────────────────────

    private static final Pattern STYLED = Pattern.compile(
            NOT_IDENT_BEFORE + "(" + IDENT + ")(?:__|_)\\{([^}]+)\\}(\\^\\{([^}]+)\\})?\\s*=");

    private static final Pattern SUP_ONLY = Pattern.compile(
            NOT_IDENT_BEFORE + "(" + IDENT + ")\\^\\{([^}]+)\\}\\s*=");

    private static final Pattern LIVE_STYLED = Pattern.compile(
            NOT_IDENT_BEFORE + "(" + IDENT + ")(?:\\u200D{1,3}([^\\u200D\\n\\r=]+)\\u200D{1,3})?"
                    + "(?:\\u200C{3}([^\\u200C\\n\\r=]+)\\u200C{3})?\\s*=");

    // ── Plain declarations ───────────────────────────────────────────────────

    private static final Pattern DECL = Pattern.compile(
            NOT_IDENT_BEFORE + "(var|let|const)\\s+(" + IDENT + ")\\s*=");

    private static final Pattern TYPED = Pattern.compile(
            NOT_IDENT_BEFORE + "(" + IDENT + ")\\s+(" + IDENT + ")\\s*[=;]");

    /**
     * Bare assignment. The {@code (?!=)} lookahead keeps {@code ==}, {@code >=},
     * {@code <=} and {@code !=} comparisons from being mistaken for
     * declarations, and the lookbehind keeps {@code obj.field = ...} from
     * registering {@code field}.
     */
    private static final Pattern BARE = Pattern.compile(
            NOT_IDENT_OR_DOT_BEFORE + "(" + IDENT + ")\\s*=(?!=)");

    /** {@code r = A(...)}: a variable built from a constructor call. */
    private static final Pattern CONSTRUCTOR_ASSIGN = Pattern.compile(
            NOT_IDENT_OR_DOT_BEFORE + "(" + IDENT + ")\\s*=\\s*(" + IDENT + ")\\s*\\(");

    // ── Class members, read inside `base` ────────────────────────────────────

    /** {@code base.age = ...} */
    private static final Pattern BASE_FIELD = Pattern.compile(
            NOT_IDENT_OR_DOT_BEFORE + "base\\s*\\.\\s*(" + IDENT + ")\\s*=(?!=)");

    /** {@code age = ...} at the start of a statement. */
    private static final Pattern STATEMENT_ASSIGN = Pattern.compile(
            "(?:^|;)\\s*(" + IDENT + ")\\s*=(?!=)");

    private static final Set<String> KEYWORDS_AND_TYPES = new HashSet<>(Arrays.asList(
            "var", "let", "const", "int", "float", "double", "String", "boolean",
            "List", "Map", "Set", "Array", "Object", "function", "class", "if",
            "else", "elseif", "for", "while", "return", "break", "continue", "true", "false",
            "null", "void", "static", "public", "private", "protected", "new",
            "iend", "fend", "wend", "fnend", "csend", "publish", "base"));

    /** One open block while scanning. */
    private static final class Frame {
        final String closer;
        /** Set on a class frame. */
        final DiscoveredClass declaredClass;
        /** Set on a {@code base} function frame: the class its variables belong to. */
        final DiscoveredClass memberOwner;

        Frame(String closer, DiscoveredClass declaredClass, DiscoveredClass memberOwner) {
            this.closer = closer;
            this.declaredClass = declaredClass;
            this.memberOwner = memberOwner;
        }
    }

    /**
     * Extract every declaration from the code and register it for suggestion.
     *
     * @param text the full code text
     */
    public static void updateVariablesFromText(String text) {
        SuggestionRegistry.discoveredVariables.clear();
        SuggestionRegistry.discoveredVariableInfo.clear();
        SuggestionRegistry.discoveredStyledVariables.clear();
        SuggestionRegistry.discoveredFunctions.clear();
        SuggestionRegistry.discoveredClasses.clear();
        SuggestionRegistry.instanceClasses.clear();
        VariableKindIndex.clear();
        if (text == null || text.isEmpty()) {
            return;
        }

        Set<String> styledBaseNames = new HashSet<>();
        Deque<Frame> frames = new ArrayDeque<>();
        List<String[]> constructorCandidates = new ArrayList<>();

        String[] lines = text.split("\\R", -1);
        for (int lineIndex = 0; lineIndex < lines.length; lineIndex++) {
            String raw = lines[lineIndex];
            String code = NcBlockScanner.codeWithoutComment(raw);
            if (code.isBlank()) {
                continue;
            }
            String masked = NcBlockScanner.logicalCode(raw);
            String logical = masked.trim();

            String firstWord = BlockHeaderGrammar.firstWord(logical);
            if (BlockHeaderGrammar.isCloser(firstWord)) {
                popFrame(frames, firstWord);
                continue;
            }

            BlockHeaderGrammar.Header header = BlockHeaderGrammar.parse(logical);
            if (header != null && header.kind() == BlockHeaderGrammar.Kind.FUNCTION) {
                handleFunctionHeader(header, lineIndex, frames, styledBaseNames);
                continue;
            }
            if (header != null && header.kind() == BlockHeaderGrammar.Kind.CLASS) {
                handleClassHeader(header, lineIndex, frames);
                continue;
            }
            if (header != null && header.kind().opensBlock()) {
                frames.push(new Frame(header.kind().closer(), null, null));
            }

            scanStyled(code, styledBaseNames);
            scanPlain(code, lineIndex, styledBaseNames);
            collectConstructorCalls(masked, constructorCandidates);

            DiscoveredClass owner = memberOwner(frames);
            if (owner != null) {
                collectMembers(masked, code, owner, lineIndex);
            }
        }

        // Classes may be declared below the line that instantiates them, so the
        // links are resolved once every class is known.
        for (String[] candidate : constructorCandidates) {
            if (SuggestionRegistry.discoveredClasses.containsKey(candidate[1])) {
                SuggestionRegistry.instanceClasses.putIfAbsent(candidate[0], candidate[1]);
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // BLOCK STRUCTURE
    // ─────────────────────────────────────────────────────────────────────────

    private static void handleFunctionHeader(BlockHeaderGrammar.Header header, int lineIndex,
            Deque<Frame> frames, Set<String> styledBaseNames) {
        String name = header.name();
        Frame top = frames.peek();
        DiscoveredClass enclosingClass = top != null ? top.declaredClass : null;
        DiscoveredClass memberOwner = null;

        if (name != null) {
            DiscoveredFunction function = new DiscoveredFunction(
                    name, header.parameters(), header.outputs(), lineIndex);
            if (enclosingClass != null) {
                if ("base".equals(name)) {
                    memberOwner = enclosingClass;
                } else if (!"info".equals(name)) {
                    enclosingClass.addMethod(function);
                }
            } else {
                SuggestionRegistry.discoveredFunctions.putIfAbsent(name, function);
                VariableKindIndex.recordKind(name, SuggestionKind.FUNCTION_USER);
            }

            // Inputs and outputs are names the body uses.
            for (String parameter : header.parameters()) {
                record(parameter, lineIndex, styledBaseNames, "");
            }
            for (String output : header.outputs()) {
                record(output, lineIndex, styledBaseNames, "");
            }
        }

        frames.push(new Frame("fnend", null, memberOwner));
    }

    private static void handleClassHeader(BlockHeaderGrammar.Header header, int lineIndex, Deque<Frame> frames) {
        DiscoveredClass declared = null;
        String name = header.name();
        if (name != null) {
            declared = SuggestionRegistry.discoveredClasses.computeIfAbsent(
                    name, n -> new DiscoveredClass(n, header.parameters(), lineIndex));
            VariableKindIndex.recordKind(name, SuggestionKind.CLASS_USER);
        }
        frames.push(new Frame("csend", declared, null));
    }

    /** Pops down to the frame this closer ends; an orphan closer is ignored. */
    private static void popFrame(Deque<Frame> frames, String closer) {
        for (Frame frame : frames) {
            if (frame.closer.equals(closer)) {
                Frame popped;
                do {
                    popped = frames.pop();
                } while (popped != frame);
                return;
            }
        }
    }

    /** The class whose members are being declared, when inside its {@code base}. */
    private static DiscoveredClass memberOwner(Deque<Frame> frames) {
        for (Frame frame : frames) {
            if ("fnend".equals(frame.closer)) {
                // Only the innermost function decides: a nested helper is not base.
                return frame.memberOwner;
            }
        }
        return null;
    }

    /**
     * Records the variables a {@code base} line declares.
     *
     * @param masked the line with string bodies blanked (same offsets as code)
     * @param code   the line with literals intact, for type inference
     */
    private static void collectMembers(String masked, String code, DiscoveredClass owner, int lineIndex) {
        Matcher field = BASE_FIELD.matcher(masked);
        while (field.find()) {
            addMember(owner, field.group(1), lineIndex, code.substring(field.end()));
        }
        Matcher local = STATEMENT_ASSIGN.matcher(masked);
        while (local.find()) {
            addMember(owner, local.group(1), lineIndex, code.substring(local.end()));
        }
    }

    private static void addMember(DiscoveredClass owner, String member, int lineIndex, String rightHandSide) {
        if (member == null || member.isBlank() || isKeywordOrType(member)) {
            return;
        }
        owner.addMember(member, lineIndex);
        VariableKindIndex.record(owner.getName() + "." + member, rightHandSide);
    }

    private static void collectConstructorCalls(String masked, List<String[]> candidates) {
        Matcher matcher = CONSTRUCTOR_ASSIGN.matcher(masked);
        while (matcher.find()) {
            candidates.add(new String[] { matcher.group(1), matcher.group(2) });
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // LINE SCANNING
    // ─────────────────────────────────────────────────────────────────────────

    /** Pattern 0 / 0b / 0c: styled (subscript / superscript) declarations. */
    private static void scanStyled(String line, Set<String> styledBaseNames) {
        // Pattern 0: v_{x} = 1, v_{x}^{2} = 1
        Matcher styledMatcher = STYLED.matcher(line);
        while (styledMatcher.find()) {
            String base = styledMatcher.group(1);
            String sub = styledMatcher.group(2);
            String sup = styledMatcher.group(4);
            String raw = base + "__{" + sub + "}";
            String display = base + "[SUB:" + sub + "]";
            if (sup != null && !sup.isEmpty()) {
                raw += "^{" + sup + "}";
                display += "[SUP:" + sup + "]";
            }
            styledBaseNames.add(base);
            SuggestionRegistry.discoveredStyledVariables.put(raw, display);
        }

        // Pattern 0b: x^{2} = 9
        Matcher supOnlyMatcher = SUP_ONLY.matcher(line);
        while (supOnlyMatcher.find()) {
            String base = supOnlyMatcher.group(1);
            String sup = supOnlyMatcher.group(2);
            String raw = base + "^{" + sup + "}";
            String display = base + "[SUP:" + sup + "]";
            styledBaseNames.add(base);
            SuggestionRegistry.discoveredStyledVariables.put(raw, display);
        }

        // Pattern 0c: already converted by the live replacement engine.
        // Subscript groups use U+200D (ZWJ), superscript U+200C (ZWNJ).
        Matcher liveStyledMatcher = LIVE_STYLED.matcher(line);
        while (liveStyledMatcher.find()) {
            String base = liveStyledMatcher.group(1);
            String sub = liveStyledMatcher.group(2);
            String sup = liveStyledMatcher.group(3);
            boolean hasSub = sub != null && !sub.isBlank();
            boolean hasSup = sup != null && !sup.isBlank();
            if (!hasSub && !hasSup) {
                continue;
            }
            String raw = base;
            String display = base;
            if (hasSub) {
                raw += "__{" + sub + "}";
                display += "[SUB:" + sub + "]";
            }
            if (hasSup) {
                raw += "^{" + sup + "}";
                display += "[SUP:" + sup + "]";
            }
            styledBaseNames.add(base);
            SuggestionRegistry.discoveredStyledVariables.put(raw, display);
        }
    }

    /** Patterns 1–3: plain declarations, in any script. */
    private static void scanPlain(String line, int lineIndex, Set<String> styledBaseNames) {
        // Pattern 1: var/let/const name = ...
        Matcher m1 = DECL.matcher(line);
        while (m1.find()) {
            // The pattern ends at '=', so everything after the match end is the
            // literal. Taking it per-match rather than per-line keeps
            // "a = 1; b = "x";" correct instead of typing both from the first
            // right-hand side.
            record(m1.group(2), lineIndex, styledBaseNames, line.substring(m1.end()));
        }

        // Pattern 2: type-declared variables like: int x, String name
        Matcher m2 = TYPED.matcher(line);
        while (m2.find()) {
            String type = m2.group(1);
            String varName = m2.group(2);
            if (!isKeywordOrType(type)) {
                record(varName, lineIndex, styledBaseNames, line.substring(m2.end()));
            }
        }

        // Pattern 3: bare assignments (no var/let/const keyword)
        Matcher m3 = BARE.matcher(line);
        while (m3.find()) {
            record(m3.group(1), lineIndex, styledBaseNames, line.substring(m3.end()));
        }

        // Function and class headers are handled before this method is reached,
        // through BlockHeaderGrammar, so there is no header pattern here.
    }

    /**
     * Registers one discovered variable, building its roman search keys and
     * script-specific description on the way in.
     */
    private static void record(String varName, int lineIndex, Set<String> styledBaseNames,
            String rightHandSide) {
        if (varName == null || varName.isBlank()) {
            return;
        }
        if (isKeywordOrType(varName) || styledBaseNames.contains(varName)) {
            return;
        }
        // A user function or class name is not a variable, even if assigned.
        Map<String, DiscoveredFunction> functions = SuggestionRegistry.discoveredFunctions;
        if (functions.containsKey(varName) || SuggestionRegistry.discoveredClasses.containsKey(varName)) {
            return;
        }

        SuggestionRegistry.discoveredVariables.add(varName);
        VariableKindIndex.record(varName, rightHandSide);

        // First declaration wins, so the recorded line index is the line the
        // variable was introduced on rather than the last line it was touched.
        SuggestionRegistry.discoveredVariableInfo.computeIfAbsent(
                varName, name -> new DiscoveredVariable(name, lineIndex));
    }

    /** Check if a string is a common keyword or type name. */
    private static boolean isKeywordOrType(String word) {
        return KEYWORDS_AND_TYPES.contains(word);
    }
}
