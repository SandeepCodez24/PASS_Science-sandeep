package ui.ui_functions.suggestion_functions;

import java.util.Comparator;
import java.util.List;

import ui.ui_functions.SuggestionProvider.Suggestion;

/**
 * The single place that decides <b>what order the popup shows things in</b>.
 *
 * <h3>Two-level model: tier first, then score inside the tier</h3>
 * Tiers never interleave. A variable the user declared three lines ago always
 * outranks a built-in function, no matter how well the function name matches,
 * because a user who declared something wants it back.
 *
 * <pre>
 *   Tier 0  Styled variables      v&#8331;, x&#178;  (subscript / superscript declarations)
 *   Tier 1  Declared variables    A, &#945;, &#2949;, &#2949;&#2949;, &#2309;, &#2310;
 *   Tier 2  Recently used         \var(
 *   Tier 3  Built-in functions    adj(), det()
 *   Tier 4  Language commands     \var(, \con(, \tamil(, \sanskrit(, ...
 *   Tier 5  Everything else
 * </pre>
 *
 * <h3>Score inside a tier</h3>
 * <ol>
 * <li><b>Exact key match before prefix match.</b> Typing {@code a} makes
 * {@code A} (key {@code "a"}) outrank {@code &#2949;&#2949;} (key {@code "aa"}),
 * which in turn outranks {@code &#945;} (key {@code "alpha"}).</li>
 * <li><b>Prefix match before loose (mid-word) match.</b></li>
 * <li><b>Shorter key first</b> — {@code a} &rarr; {@code aa} &rarr;
 * {@code alpha}.</li>
 * <li><b>Case-exact before case-folded</b>, so a typed {@code A} prefers
 * {@code A} over {@code a}.</li>
 * <li><b>Script order</b>, deterministic: English &rarr; Greek &rarr; Tamil
 * &rarr; Sanskrit &rarr; Telugu &rarr; Malayalam.</li>
 * <li><b>Alphabetical on the roman key.</b></li>
 * <li><b>Declaration order</b>, so ties resolve to the order the user wrote
 * them.</li>
 * </ol>
 *
 * <p>
 * Worked example — the caret sits on an empty line of the sample script and the
 * user types {@code a}. Every one of these is a Tier&nbsp;1 variable:
 *
 * <pre>
 *   A    a : Variable                 exact, len 1, English
 *   &#2949;    a : Tamil vowel              exact, len 1, Tamil
 *   &#2309;    a : Sanskrit vowel           exact, len 1, Sanskrit
 *   &#2949;&#2949;   aa : Tamil vowel             prefix, len 2, Tamil
 *   &#2310;    aa : Sanskrit vowel          prefix, len 2, Sanskrit
 *   &#945;    alpha : Greek letter         prefix, len 5, Greek
 * </pre>
 *
 * then Tier 2 {@code \var(}, then Tier 3 {@code adj()}.
 */
public final class SuggestionRanker {

    /** Tier constants. Lower sorts first and tiers never interleave. */
    public static final int TIER_STYLED_VARIABLE = 0;
    public static final int TIER_VARIABLE = 1;
    public static final int TIER_RECENTLY_USED = 2;
    public static final int TIER_FUNCTION = 3;
    public static final int TIER_COMMAND = 4;
    public static final int TIER_OTHER = 5;

    private SuggestionRanker() {
        // Utility class – no instances.
    }

    /**
     * One ranked row: the suggestion plus the pre-computed numbers the
     * comparator needs. Computing them once per row instead of inside the
     * comparator keeps the sort O(n log n) in comparisons rather than in string
     * operations.
     */
    public static final class Ranked {
        private final Suggestion suggestion;
        private final int tier;
        private final String key;
        private final int scriptOrder;
        private final int declarationOrder;
        private final int exactRank;
        private final int prefixRank;
        private final int caseRank;

        /**
         * @param suggestion       the row to show
         * @param tier             one of the {@code TIER_*} constants
         * @param key              the roman / plain key used for matching
         * @param rawDisplay       the text as it will be rendered, for case comparison
         * @param scriptOrder      a {@code ScriptVariableIndex.ORDER_*} constant
         * @param declarationOrder declaration line index, or a large value when
         *                         the row is not a declared variable
         * @param input            the raw text the user typed
         */
        public Ranked(Suggestion suggestion, int tier, String key, String rawDisplay,
                int scriptOrder, int declarationOrder, String input) {
            this.suggestion = suggestion;
            this.tier = tier;
            this.key = key == null ? "" : key;
            this.scriptOrder = scriptOrder;
            this.declarationOrder = declarationOrder;

            String lowerInput = input == null ? "" : input.toLowerCase();
            String lowerKey = this.key.toLowerCase();

            this.exactRank = lowerKey.equals(lowerInput) ? 0 : 1;
            this.prefixRank = lowerKey.startsWith(lowerInput) ? 0 : 1;

            String display = rawDisplay == null ? this.key : rawDisplay;
            boolean caseExact = input != null && !input.isEmpty()
                    && (display.startsWith(input) || this.key.startsWith(input));
            this.caseRank = caseExact ? 0 : 1;
        }

        public Suggestion getSuggestion() {
            return suggestion;
        }

        public int getTier() {
            return tier;
        }
    }

    /**
     * The ordering described in the class documentation.
     *
     * @return a comparator over pre-scored rows
     */
    public static Comparator<Ranked> comparator() {
        return Comparator
                .comparingInt((Ranked r) -> r.tier)
                .thenComparingInt(r -> r.exactRank)
                .thenComparingInt(r -> r.prefixRank)
                .thenComparingInt(r -> r.key.length())
                .thenComparingInt(r -> r.caseRank)
                .thenComparingInt(r -> r.scriptOrder)
                .thenComparing(r -> r.key)
                .thenComparingInt(r -> r.declarationOrder);
    }

    /**
     * Sorts in place and unwraps to plain suggestions.
     *
     * @param rows  the scored rows
     * @param limit maximum number of rows to return
     * @return the ordered suggestions, at most {@code limit} of them
     */
    public static List<Suggestion> order(List<Ranked> rows, int limit) {
        rows.sort(comparator());
        return rows.stream()
                .limit(limit)
                .map(Ranked::getSuggestion)
                .toList();
    }
}
