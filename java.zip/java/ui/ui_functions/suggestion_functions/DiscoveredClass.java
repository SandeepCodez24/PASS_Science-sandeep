package ui.ui_functions.suggestion_functions;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * A class the user defined in the current file.
 *
 * <h3>Members come from {@code base}</h3>
 * In Neural Code a class's {@code base} function is its constructor and where
 * its variables live. What the user wants to reach after typing {@code A.} is
 * the variables {@code base} declares -- {@code A.age}, {@code A.mass} -- and
 * its methods. Both {@code base.age = 1;} and a plain {@code age = 1;} inside
 * {@code base} count as a member.
 *
 * <h3>{@code .base} and {@code .info} are built in (changed)</h3>
 * {@code A.base} (a dict of the fields) and {@code A.info} (a dict of the
 * class's functions) are now real, built into {@code nc.exe}; the popup offers
 * them after {@code A.} beside the fields and methods. The constructor is
 * kept ({@link #getConstructor()}) so its inputs can be offered inside
 * {@code A(...)}, and the parent ({@link #getParent()}) so inherited fields
 * and methods are offered too.
 *
 * <p>
 * Any further function in the class body (other than {@code base}) is kept as
 * a method and offered as {@code A.name(...)}.
 */
public final class DiscoveredClass {

    private final String name;
    private final List<String> parameters;
    private final int declarationOrder;
    private final String parent;
    private DiscoveredFunction constructor;
    private final Map<String, Integer> members = new LinkedHashMap<>();
    private final Map<String, DiscoveredFunction> methods = new LinkedHashMap<>();

    /**
     * @param name             the class name as written
     * @param parameters       the header's parameters
     * @param declarationOrder zero-based line index of the header
     */
    public DiscoveredClass(String name, List<String> parameters, int declarationOrder) {
        this.name = name;
        this.parameters = List.copyOf(parameters);
        this.declarationOrder = declarationOrder;
        // class Square(Shape): -- the name in the brackets is the parent.
        this.parent = parameters.isEmpty() ? null : parameters.get(0);
    }

    /** @return the parent class's name ({@code Shape} in {@code class Square(Shape):}), or null */
    public String getParent() {
        return parent;
    }

    /** @return the constructor ({@code function base(...)}), or null when the class has none */
    public DiscoveredFunction getConstructor() {
        return constructor;
    }

    /** Records the class's {@code base} function. The first one wins. */
    void setConstructor(DiscoveredFunction base) {
        if (constructor == null) {
            constructor = base;
        }
    }

    public String getName() {
        return name;
    }

    public List<String> getParameters() {
        return parameters;
    }

    public int getDeclarationOrder() {
        return declarationOrder;
    }

    /** Lower-cased name, used for matching and ranking. */
    public String getPrimaryKey() {
        return name.toLowerCase(Locale.ROOT);
    }

    /** @return {@code Name(a, b)} */
    public String signature() {
        return name + "(" + String.join(", ", parameters) + ")";
    }

    /**
     * Records a variable declared in {@code base}. The first declaration wins.
     *
     * @param member the member name
     * @param line   zero-based line of the declaration
     */
    void addMember(String member, int line) {
        members.putIfAbsent(member, line);
    }

    /**
     * Records a method other than {@code base}. The first definition wins.
     *
     * @param method the method
     */
    void addMethod(DiscoveredFunction method) {
        methods.putIfAbsent(method.getName(), method);
    }

    /** @return member name to declaration line, in declaration order */
    public Map<String, Integer> getMembers() {
        return Collections.unmodifiableMap(members);
    }

    /** @return method name to method, in declaration order */
    public Map<String, DiscoveredFunction> getMethods() {
        return Collections.unmodifiableMap(methods);
    }

    /**
     * @param lowerInput the already lower-cased typed text
     * @return true when the name contains the input anywhere
     */
    public boolean matchesLoose(String lowerInput) {
        return lowerInput == null || lowerInput.isEmpty() || getPrimaryKey().contains(lowerInput);
    }
}
