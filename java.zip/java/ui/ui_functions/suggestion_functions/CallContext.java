package ui.ui_functions.suggestion_functions;

import java.util.ArrayDeque;
import java.util.Collections;
import java.util.Deque;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import language.semantic.CodeSegments;

/**
 * Where the caret is when it sits at the start of an argument of a call:
 * which call, on which receiver, and which inputs the call already names.
 * The suggestion popup uses it to offer the called function's input names
 * as {@code name=} rows.
 *
 * <pre>
 *   C = Add(x|            callee Add, nothing named yet      offers x1=, x2=
 *   C = Add(x1=10, x|     callee Add, x1 named               offers x2=
 *   a = s.area(sc|        receiver s, callee area            offers scale=
 *   G(1, b=f(|            the innermost call is f
 * </pre>
 *
 * The caret must be at the start of an argument: right after {@code (} or a
 * {@code ,} of that call, with only the word being typed in between. Inside a
 * string, a comment, a matrix {@code [ ]} or a dict {@code { }} there is no
 * call context.
 *
 * @param callee   the called name ({@code Add}, {@code area})
 * @param receiver the name before the dot for a method call, or null
 * @param named    the input names this call already gives by name
 */
public record CallContext(String callee, String receiver, Set<String> named) {

    /** A Neural Code name, subscript and superscript markers included. */
    private static final String NAME = "[\\p{L}_][\\p{L}\\p{M}\\p{N}_$@]*";

    /** {@code name =} at the start of an argument; {@code ==} is a comparison. */
    private static final Pattern NAMED = Pattern.compile("^\\s*(" + NAME + ")\\s*=(?!=)");

    /** The word being typed, at the end of the text. */
    private static final Pattern TRAILING_WORD = Pattern.compile("[\\p{L}\\p{M}\\p{N}_$@]*$");

    /**
     * @param textBeforeCaret the document up to the caret
     * @return the call the caret is an argument of, or null
     */
    public static CallContext at(String textBeforeCaret) {
        if (textBeforeCaret == null || textBeforeCaret.isEmpty()) {
            return null;
        }
        String masked = mask(textBeforeCaret);
        Matcher word = TRAILING_WORD.matcher(masked);
        int wordStart = word.find() ? word.start() : masked.length();

        // The innermost bracket still open at the word.
        Deque<Integer> open = new ArrayDeque<>();
        for (int i = 0; i < wordStart; i++) {
            char c = masked.charAt(i);
            if (c == '(' || c == '[' || c == '{') {
                open.push(i);
            } else if ((c == ')' || c == ']' || c == '}') && !open.isEmpty()) {
                open.pop();
            }
        }
        if (open.isEmpty() || masked.charAt(open.peek()) != '(') {
            return null;
        }
        int bracket = open.peek();

        // Only at the start of an argument: after '(' or a top-level ','.
        int before = wordStart - 1;
        while (before > bracket && Character.isWhitespace(masked.charAt(before))) {
            before--;
        }
        if (before != bracket && masked.charAt(before) != ',') {
            return null;
        }

        String callee = nameEndingAt(masked, bracket);
        if (callee == null) {
            return null;
        }
        int calleeStart = bracket - callee.length();
        while (calleeStart > 0 && masked.charAt(calleeStart - 1) == ' ') {
            calleeStart--;
        }
        String receiver = null;
        if (calleeStart > 0 && masked.charAt(calleeStart - 1) == '.') {
            receiver = nameEndingAt(masked, calleeStart - 1);
        }
        return new CallContext(callee, receiver, namedBefore(masked, bracket + 1, wordStart));
    }

    /** The names given by name in the arguments between {@code from} and {@code to}. */
    private static Set<String> namedBefore(String masked, int from, int to) {
        Set<String> named = new LinkedHashSet<>();
        int depth = 0;
        int start = from;
        for (int i = from; i <= to; i++) {
            char c = i < to ? masked.charAt(i) : ',';
            if (c == '(' || c == '[' || c == '{') {
                depth++;
            } else if (c == ')' || c == ']' || c == '}') {
                depth = Math.max(0, depth - 1);
            } else if (c == ',' && depth == 0) {
                Matcher m = NAMED.matcher(masked.substring(start, i));
                if (m.find()) {
                    named.add(m.group(1));
                }
                start = i + 1;
            }
        }
        return Collections.unmodifiableSet(named);
    }

    /** The name written just before offset {@code end} (spaces allowed), or null. */
    private static String nameEndingAt(String s, int end) {
        int e = end;
        while (e > 0 && s.charAt(e - 1) == ' ') {
            e--;
        }
        int b = e;
        while (b > 0 && isNamePart(s.charAt(b - 1))) {
            b--;
        }
        if (b == e || !(Character.isLetter(s.charAt(b)) || s.charAt(b) == '_')) {
            return null;
        }
        return s.substring(b, e);
    }

    private static boolean isNamePart(char c) {
        if (Character.isLetterOrDigit(c) || c == '_' || c == '$' || c == '@') {
            return true;
        }
        int type = Character.getType(c);
        return type == Character.NON_SPACING_MARK || type == Character.COMBINING_SPACING_MARK;
    }

    /**
     * The text with string bodies and comments blanked, offsets kept: a
     * bracket in {@code "a(b"} or after {@code #} is not code.
     */
    private static String mask(String text) {
        StringBuilder out = new StringBuilder(text.length());
        char quote = 0;
        int transposeAt = -1;
        boolean comment = false;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '\n') {
                comment = false;
                quote = 0;
                out.append(c);
                continue;
            }
            if (comment) {
                out.append(' ');
                continue;
            }
            if (quote != 0) {
                if (c == quote && (i == 0 || text.charAt(i - 1) != '\\')) {
                    quote = 0;
                    out.append(c);
                } else {
                    out.append(' ');
                }
                continue;
            }
            if (c == '\'' && CodeSegments.isTranspose(text, i, transposeAt)) {
                transposeAt = i;
                out.append(' ');
                continue;
            }
            if (c == '"' || c == '\'') {
                quote = c;
                out.append(c);
                continue;
            }
            if (c == '#' || (c == '\\' && i + 1 < text.length() && text.charAt(i + 1) == '\\')) {
                comment = true;
                out.append(' ');
                continue;
            }
            out.append(c);
        }
        return out.toString();
    }
}
