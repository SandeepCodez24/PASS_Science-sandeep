package ui.ui_functions.suggestion_functions;

import java.util.function.BooleanSupplier;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.OverrunStyle;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

import ui.ui_functions.FunctionProvider;
import ui.ui_functions.SuggestionProvider.Suggestion;

/**
 * Renders a single suggestion row: type icon + styled code text (with
 * {@code [SUB:...]} / {@code [SUP:...]} markers) + right-aligned description,
 * honouring the current theme.
 *
 * <h3>What changed</h3>
 * <ol>
 * <li><b>Rows are 15% shorter.</b> Vertical padding drops from 6px to 3px,
 * taking the row from ~26px to {@link #ROW_HEIGHT}px. The font and the 16px
 * icon are untouched — the popup gets tighter without the text getting
 * smaller, which is the only way to shrink a list without hurting
 * legibility.</li>
 * <li><b>The icon now states the type.</b> It used to be one of two legacy
 * PNGs chosen from the coarse category string, so {@code A = 1} and
 * {@code D = "india"} looked identical. Icons now come from
 * {@link SuggestionIconProvider}, keyed by {@link SuggestionKind}, so an
 * integer, a float, a string, a boolean, a dictionary, a built-in function, a
 * user function and a user class each read at a glance.</li>
 * <li><b>Icons are cached, not re-decoded.</b> The old code built a
 * {@code new Image(...)} inside {@code updateItem}, i.e. on every keystroke and
 * every scroll tick. That classpath lookup and PNG decode is now done once per
 * kind.</li>
 * </ol>
 */
public final class SuggestionCellRenderer {

    private SuggestionCellRenderer() {
        // Factory holder – no instances (use {@link #createCell}).
    }

    /**
     * Fixed row height, 15% below the previous ~26px.
     *
     * <p>
     * Exposed so {@code SuggestionPopup} can size the popup from the same
     * number the cells actually use. When the two disagree the list either
     * clips its last row or leaves a dead strip at the bottom.
     */
    public static final double ROW_HEIGHT = 22;

    /** Vertical padding inside a row. */
    private static final double ROW_PADDING_Y = 3;

    /** Horizontal padding inside a row. */
    private static final double ROW_PADDING_X = 8;

    /**
     * Create a {@link ListCell} for the suggestion list.
     *
     * @param darkThemeSupplier supplies the <i>current</i> dark-theme flag so the
     *                          cell always paints with the live theme even after
     *                          {@code setTheme(...)} is called
     * @return a configured list cell
     */
    public static ListCell<Suggestion> createCell(BooleanSupplier darkThemeSupplier) {
        return new SuggestionCell(darkThemeSupplier);
    }

    /** ListCell implementation for a single suggestion. */
    private static final class SuggestionCell extends ListCell<Suggestion> {

        private final BooleanSupplier darkThemeSupplier;

        SuggestionCell(BooleanSupplier darkThemeSupplier) {
            this.darkThemeSupplier = darkThemeSupplier;
            // Pin the height so a tall glyph — Tamil and Malayalam
            // consonant-vowel forms are noticeably taller than Latin — cannot
            // push one row out of step with its neighbours.
            setPrefHeight(ROW_HEIGHT);
            setMinHeight(ROW_HEIGHT);
            setMaxHeight(ROW_HEIGHT);
        }

        @Override
        protected void updateItem(Suggestion item, boolean empty) {
            super.updateItem(item, empty);

            if (empty || item == null) {
                setGraphic(null);
                setText(null);
                setStyle("");
                return;
            }

            boolean darkTheme = darkThemeSupplier.getAsBoolean();

            // Get display text and build styled node.
            String displayText = item.getDisplay();

            // For functions: show template with empty parameters.
            if ("Function".equals(item.getCategory())) {
                displayText = FunctionProvider.getFunctionTemplate(item.getCode());
            }

            // Build styled node that renders [SUB:...] and [SUP:...] markers.
            Node graphic = buildStyledNode(displayText, isSelected(), darkTheme);

            // Right-side readable description.
            Label descriptionLabel = new Label(item.getDescription());
            descriptionLabel.setWrapText(false);
            descriptionLabel.setStyle("-fx-font-family: 'Consolas'; -fx-font-size: 11;");
            descriptionLabel.setTextFill(Color.web(
                    darkTheme ? PopupThemeManager.DARK_DESCRIPTION_TEXT
                            : PopupThemeManager.LIGHT_DESCRIPTION_TEXT));
            descriptionLabel.setMaxWidth(220);
            descriptionLabel.setTextOverrun(OverrunStyle.ELLIPSIS);
            descriptionLabel.setAlignment(Pos.CENTER_RIGHT);

            Region spacer = new Region();
            HBox.setHgrow(spacer, Priority.ALWAYS);

            HBox cellContent = new HBox();
            cellContent.setAlignment(Pos.CENTER_LEFT);
            cellContent.setSpacing(8);

            // Type-aware icon, resolved once and cached.
            cellContent.getChildren().add(iconFor(item));
            cellContent.getChildren().add(graphic);
            cellContent.getChildren().add(spacer);
            cellContent.getChildren().add(descriptionLabel);

            setPadding(new Insets(ROW_PADDING_Y, ROW_PADDING_X, ROW_PADDING_Y, ROW_PADDING_X));
            setGraphic(cellContent);

            if (isSelected()) {
                setStyle("-fx-background-color: "
                        + (darkTheme ? PopupThemeManager.DARK_SELECTION_BG : PopupThemeManager.LIGHT_SELECTION_BG)
                        + "; -fx-text-fill: "
                        + (darkTheme ? PopupThemeManager.DARK_POPUP_TEXT : PopupThemeManager.LIGHT_POPUP_TEXT) + ";");
            } else {
                setStyle("-fx-background-color: "
                        + (darkTheme ? PopupThemeManager.DARK_POPUP_BG : PopupThemeManager.LIGHT_POPUP_BG)
                        + "; -fx-text-fill: "
                        + (darkTheme ? PopupThemeManager.DARK_POPUP_TEXT : PopupThemeManager.LIGHT_POPUP_TEXT) + ";");
            }
        }

        /**
         * The row's icon. A suggestion that already carries an explicit kind
         * wins; anything older is resolved from its category, with variables
         * looked up in {@link VariableKindIndex} so they still get their
         * inferred type icon.
         */
        private Node iconFor(Suggestion item) {
            SuggestionKind kind = item.getKind();
            if (kind == null) {
                kind = SuggestionIconProvider.kindForCategory(item.getCategory(), item.getCode());
            }
            return SuggestionIconProvider.iconFor(kind);
        }
    }

    /**
     * Build a styled JavaFX node from display text containing {@code [SUB:...]}
     * and {@code [SUP:...]} markers.
     * <ul>
     * <li>{@code [SUB:content]} → 9px font, cyan, translateY +5 (shifts down)</li>
     * <li>{@code [SUP:content]} → 9px font, yellow-green, translateY -5 (up)</li>
     * <li>Plain text → 13px font, normal (theme-aware) colour</li>
     * </ul>
     */
    static Node buildStyledNode(String displayText, boolean isSelected, boolean darkTheme) {
        HBox hbox = new HBox();
        hbox.setAlignment(Pos.CENTER_LEFT);
        hbox.setSpacing(0);

        if (displayText == null || displayText.isEmpty()) {
            return hbox;
        }

        int idx = 0;
        while (idx < displayText.length()) {
            // Check for [SUB: marker
            if (displayText.startsWith("[SUB:", idx)) {
                int endIdx = displayText.indexOf("]", idx);
                if (endIdx != -1) {
                    String subContent = displayText.substring(idx + 5, endIdx);
                    Text subText = new Text(subContent);
                    subText.setFont(Font.font("Consolas", 9));
                    subText.setFill(Color.web(
                            darkTheme ? PopupThemeManager.DARK_MARKER_SUB : PopupThemeManager.LIGHT_MARKER_SUB));
                    subText.setTranslateY(5);
                    hbox.getChildren().add(subText);
                    idx = endIdx + 1;
                    continue;
                }
            }

            // Check for [SUP: marker
            if (displayText.startsWith("[SUP:", idx)) {
                int endIdx = displayText.indexOf("]", idx);
                if (endIdx != -1) {
                    String supContent = displayText.substring(idx + 5, endIdx);
                    Text supText = new Text(supContent);
                    supText.setFont(Font.font("Consolas", 9));
                    supText.setFill(Color.web(
                            darkTheme ? PopupThemeManager.DARK_MARKER_SUP : PopupThemeManager.LIGHT_MARKER_SUP));
                    supText.setTranslateY(-5);
                    hbox.getChildren().add(supText);
                    idx = endIdx + 1;
                    continue;
                }
            }

            // Find next marker
            int nextMarker = displayText.length();
            int subMarker = displayText.indexOf("[SUB:", idx);
            int supMarker = displayText.indexOf("[SUP:", idx);
            if (subMarker != -1) {
                nextMarker = Math.min(nextMarker, subMarker);
            }
            if (supMarker != -1) {
                nextMarker = Math.min(nextMarker, supMarker);
            }

            // Add plain text segment
            if (nextMarker > idx) {
                String plainSegment = displayText.substring(idx, nextMarker);
                Text plainText = new Text(plainSegment);
                plainText.setFont(Font.font("Consolas", 13));
                plainText.setFill(Color.web(
                        darkTheme ? PopupThemeManager.DARK_POPUP_TEXT : PopupThemeManager.LIGHT_POPUP_TEXT));
                hbox.getChildren().add(plainText);
                idx = nextMarker;
            } else {
                idx++;
            }
        }

        return hbox.getChildren().isEmpty() ? new Text(displayText) : hbox;
    }
}
