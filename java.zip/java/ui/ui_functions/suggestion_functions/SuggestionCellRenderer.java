package ui.ui_functions.suggestion_functions;

import java.util.function.BooleanSupplier;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.OverrunStyle;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import ui.ui_functions.FunctionProvider;
import ui.ui_functions.SuggestionProvider.Suggestion;

/**
 * Renders a single suggestion row: category icon + styled code text
 * (with {@code [SUB:...]} / {@code [SUP:...]} markers) + right-aligned
 * description, honouring the current theme.
 *
 * <p>
 * Extracted from {@code SuggestionPopup}'s inner {@code SuggestionCell} class
 * plus {@code buildStyledNode(...)} and {@code getCategoryIcon(...)}.
 */
public final class SuggestionCellRenderer {

    private SuggestionCellRenderer() {
        // Factory holder – no instances (use {@link #createCell}).
    }

    /**
     * Create a {@link ListCell} for the suggestion list.
     *
     * @param darkThemeSupplier supplies the <i>current</i> dark-theme flag so the
     *                          cell always paints with the live theme even after
     *                          {@code setTheme(...)} is called
     * @return a configured list cell
     */
    public static ListCell<Suggestion> createCell(BooleanSupplier darkThemeSupplier) {
        return new SuggestionCell(darkThemeSupplier);
    }

    /** ListCell implementation for a single suggestion. */
    private static final class SuggestionCell extends ListCell<Suggestion> {

        private final BooleanSupplier darkThemeSupplier;

        SuggestionCell(BooleanSupplier darkThemeSupplier) {
            this.darkThemeSupplier = darkThemeSupplier;
        }

        @Override
        protected void updateItem(Suggestion item, boolean empty) {
            super.updateItem(item, empty);

            if (empty || item == null) {
                setGraphic(null);
                setText(null);
                setStyle("");
                return;
            }

            boolean darkTheme = darkThemeSupplier.getAsBoolean();

            // Get display text and build styled node.
            String displayText = item.getDisplay();

            // For functions: show template with empty parameters (use code/key for detection)
            if ("Function".equals(item.getCategory())) {
                displayText = FunctionProvider.getFunctionTemplate(item.getCode());
            }

            // Build styled node that renders [SUB:...] and [SUP:...] markers.
            Node graphic = buildStyledNode(displayText, isSelected(), darkTheme);

            // Right-side readable description.
            Label descriptionLabel = new Label(item.getDescription());
            descriptionLabel.setWrapText(false);
            descriptionLabel.setStyle("-fx-font-family: 'Consolas'; -fx-font-size: 11;");
            // Plain popup: description keeps its normal ink whether or not the
            // row is selected (selection is only a soft neutral band now).
            descriptionLabel.setTextFill(Color.web(
                    darkTheme ? PopupThemeManager.DARK_DESCRIPTION_TEXT
                            : PopupThemeManager.LIGHT_DESCRIPTION_TEXT));
            descriptionLabel.setMaxWidth(220);
            descriptionLabel.setTextOverrun(OverrunStyle.ELLIPSIS);
            descriptionLabel.setAlignment(Pos.CENTER_RIGHT);

            Region spacer = new Region();
            HBox.setHgrow(spacer, Priority.ALWAYS);

            // Build complete cell with icon + text.
            HBox cellContent = new HBox();
            cellContent.setAlignment(Pos.CENTER_LEFT);
            cellContent.setSpacing(8);

            // Add category icon.
            ImageView icon = getCategoryIcon(item.getCategory());
            cellContent.getChildren().add(icon);

            // Add styled text content and push description to the right.
            cellContent.getChildren().add(graphic);
            cellContent.getChildren().add(spacer);
            cellContent.getChildren().add(descriptionLabel);

            setPadding(new Insets(6, 8, 6, 8));
            setGraphic(cellContent);

            if (isSelected()) {
                // Plain popup: soft neutral band + normal text ink (no coloured
                // bar, no white text).
                setStyle("-fx-background-color: "
                        + (darkTheme ? PopupThemeManager.DARK_SELECTION_BG : PopupThemeManager.LIGHT_SELECTION_BG)
                        + "; -fx-text-fill: "
                        + (darkTheme ? PopupThemeManager.DARK_POPUP_TEXT : PopupThemeManager.LIGHT_POPUP_TEXT) + ";");
            } else {
                setStyle("-fx-background-color: "
                        + (darkTheme ? PopupThemeManager.DARK_POPUP_BG : PopupThemeManager.LIGHT_POPUP_BG)
                        + "; -fx-text-fill: "
                        + (darkTheme ? PopupThemeManager.DARK_POPUP_TEXT : PopupThemeManager.LIGHT_POPUP_TEXT) + ";");
            }
        }
    }

    /**
     * Build a styled JavaFX node from display text containing {@code [SUB:...]}
     * and {@code [SUP:...]} markers.
     * <ul>
     * <li>{@code [SUB:content]} → 9px font, cyan, translateY +5 (shifts down)</li>
     * <li>{@code [SUP:content]} → 9px font, yellow-green, translateY -5 (up)</li>
     * <li>Plain text → 13px font, normal (theme-aware) colour</li>
     * </ul>
     */
    static Node buildStyledNode(String displayText, boolean isSelected, boolean darkTheme) {
        HBox hbox = new HBox();
        hbox.setAlignment(Pos.CENTER_LEFT);
        hbox.setSpacing(0);

        if (displayText == null || displayText.isEmpty()) {
            return hbox;
        }

        int idx = 0;
        while (idx < displayText.length()) {
            // Check for [SUB: marker
            if (displayText.startsWith("[SUB:", idx)) {
                int endIdx = displayText.indexOf("]", idx);
                if (endIdx != -1) {
                    String subContent = displayText.substring(idx + 5, endIdx);
                    Text subText = new Text(subContent);
                    subText.setFont(Font.font("Consolas", 9));
                    subText.setFill(Color.web(
                            darkTheme ? PopupThemeManager.DARK_MARKER_SUB : PopupThemeManager.LIGHT_MARKER_SUB));
                    subText.setTranslateY(5); // Shift down
                    hbox.getChildren().add(subText);
                    idx = endIdx + 1;
                    continue;
                }
            }

            // Check for [SUP: marker
            if (displayText.startsWith("[SUP:", idx)) {
                int endIdx = displayText.indexOf("]", idx);
                if (endIdx != -1) {
                    String supContent = displayText.substring(idx + 5, endIdx);
                    Text supText = new Text(supContent);
                    supText.setFont(Font.font("Consolas", 9));
                    supText.setFill(Color.web(
                            darkTheme ? PopupThemeManager.DARK_MARKER_SUP : PopupThemeManager.LIGHT_MARKER_SUP));
                    supText.setTranslateY(-5); // Shift up
                    hbox.getChildren().add(supText);
                    idx = endIdx + 1;
                    continue;
                }
            }

            // Find next marker
            int nextMarker = displayText.length();
            int subMarker = displayText.indexOf("[SUB:", idx);
            int supMarker = displayText.indexOf("[SUP:", idx);
            if (subMarker != -1)
                nextMarker = Math.min(nextMarker, subMarker);
            if (supMarker != -1)
                nextMarker = Math.min(nextMarker, supMarker);

            // Add plain text segment
            if (nextMarker > idx) {
                String plainSegment = displayText.substring(idx, nextMarker);
                Text plainText = new Text(plainSegment);
                plainText.setFont(Font.font("Consolas", 13));
                plainText.setFill(Color.web(
                        darkTheme ? PopupThemeManager.DARK_POPUP_TEXT : PopupThemeManager.LIGHT_POPUP_TEXT));
                hbox.getChildren().add(plainText);
                idx = nextMarker;
            } else {
                // Skip this character if it doesn't match any marker
                idx++;
            }
        }

        return hbox.getChildren().isEmpty() ? new Text(displayText) : hbox;
    }

    /**
     * Get a category icon {@link ImageView} for the suggestion type.
     * Falls back to the variable icon for unknown categories.
     */
    static ImageView getCategoryIcon(String category) {
        String iconPath;

        if ("StyledVariable".equals(category) || "Variable".equals(category)) {
            iconPath = "/icons/icons8-variable-50.png";
        } else if ("Function".equals(category)) {
            iconPath = "/icons/icons8-function-49.png";
        } else {
            iconPath = "/icons/icons8-variable-50.png"; // Fallback
        }

        try {
            Image img = new Image(SuggestionCellRenderer.class.getResourceAsStream(iconPath));
            ImageView imgView = new ImageView(img);
            imgView.setFitWidth(16);
            imgView.setFitHeight(16);
            imgView.setPreserveRatio(true);
            return imgView;
        } catch (Exception e) {
            // Fallback: empty image view if the icon fails to load.
            ImageView fallback = new ImageView();
            fallback.setFitWidth(16);
            fallback.setFitHeight(16);
            return fallback;
        }
    }
}
