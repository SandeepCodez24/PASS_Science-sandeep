package ui.ui_functions.suggestion_functions;

import ui.ui_functions.SuggestionProvider.SuggestionContext;

/**
 * Detects the active suggestion context (which script / notation the caret is
 * currently inside) by scanning the text backwards for the last unclosed
 * {@code \var(}, {@code \con(}, {@code \tamil(}, subscript {@code __} /
 * superscript {@code ^^} markers, etc.
 *
 * <p>
 * Extracted from {@code SuggestionProvider.detectContext}.
 */
public final class ContextDetector {

    private ContextDetector() {
        // Utility class – no instances.
    }

    /**
     * Matches the "raw token" that can legally follow a {@code __} / {@code ^^}
     * marker while the user is still inside subscript/superscript mode:
     * Unicode letters/digits, underscore, backslash and parentheses (the latter
     * two so the context survives after live replacement rewrites the token into
     * things like {@code \tamil(...)}).
     *
     * <p>
     * <b>Bug fix:</b> the original literal was over-escaped
     * ({@code "[\\\\p{L}\\\\p{N}_\\\\\\\\()]*"}), which compiled to a character
     * class of literal characters {@code \ p { L } N _ ( )} instead of the
     * intended Unicode letter/number properties. As a result subscript /
     * superscript context was almost never detected for ordinary input. The
     * corrected pattern below uses real {@code \p{L}} / {@code \p{N}} properties.
     */
    private static final String SUB_SUP_TAIL_REGEX = "[\\p{L}\\p{N}_\\\\()]*";

    /**
     * Detect the current context from the full text.
     *
     * @param text the full code text
     * @return the detected context
     */
    public static SuggestionContext detectContext(String text) {
        if (text == null || text.isEmpty()) {
            return SuggestionContext.GENERAL;
        }

        int lastSubscriptMode = text.lastIndexOf("__");
        int lastSuperscriptMode = text.lastIndexOf("^^");
        if (lastSubscriptMode != -1 || lastSuperscriptMode != -1) {
            int markerIndex = Math.max(lastSubscriptMode, lastSuperscriptMode);
            String tail = text.substring(markerIndex + 2);
            // Accept unicode letters too, so sub/sup mode keeps context after
            // Greek/Tamil live replacement updates the raw token.
            if (tail.matches(SUB_SUP_TAIL_REGEX)) {
                return lastSubscriptMode > lastSuperscriptMode
                        ? SuggestionContext.SUBSCRIPT
                        : SuggestionContext.SUPERSCRIPT;
            }
        }

        // Check for \con(\ context (physics constants)
        int lastUniconIdx = text.lastIndexOf("\\con(\\");
        if (lastUniconIdx != -1) {
            int closeParenIdx = text.indexOf(")", lastUniconIdx);
            if (closeParenIdx == -1) {
                // We're inside \con(\...), show constant suggestions
                return SuggestionContext.UNICONSTANT;
            }
        }

        // Find the last unclosed \var( or \var(\tamil(
        int lastVarIdx = text.lastIndexOf("\\var(");
        if (lastVarIdx == -1) {
            return SuggestionContext.GENERAL;
        }

        // Check if there's a closing ) after the last \var(
        int closeParenIdx = text.indexOf(")", lastVarIdx);

        // If no closing paren, we're still inside \var(
        if (closeParenIdx == -1) {
            int tamilIdx = text.indexOf("\\tamil(", lastVarIdx);
            int sanskritIdx = text.indexOf("\\sanskrit(", lastVarIdx);
            int hindiIdx = text.indexOf("\\hindi(", lastVarIdx);
            int teluguIdx = text.indexOf("\\telugu(", lastVarIdx);
            int malayalamIdx = text.indexOf("\\malayalam(", lastVarIdx);
            if (tamilIdx != -1) {
                int closeTamilParen = text.indexOf(")", tamilIdx);
                if (closeTamilParen == -1) {
                    return SuggestionContext.TAMIL;
                }
            }
            if (sanskritIdx != -1) {
                int closeSanskritParen = text.indexOf(")", sanskritIdx);
                if (closeSanskritParen == -1) {
                    return SuggestionContext.SANSKRIT;
                }
            }
            if (hindiIdx != -1) {
                int closeHindiParen = text.indexOf(")", hindiIdx);
                if (closeHindiParen == -1) {
                    return SuggestionContext.HINDI;
                }
            }
            if (teluguIdx != -1) {
                int closeTeluguParen = text.indexOf(")", teluguIdx);
                if (closeTeluguParen == -1) {
                    return SuggestionContext.TELUGU;
                }
            }
            if (malayalamIdx != -1) {
                int closeMalayalamParen = text.indexOf(")", malayalamIdx);
                if (closeMalayalamParen == -1) {
                    return SuggestionContext.MALAYALAM;
                }
            }
            return SuggestionContext.GREEK;
        }

        // Check if a script marker is between the \var( and its closing )
        int tamilIdx = text.indexOf("\\tamil(", lastVarIdx);
        int sanskritIdx = text.indexOf("\\sanskrit(", lastVarIdx);
        int hindiIdx = text.indexOf("\\hindi(", lastVarIdx);
        int teluguIdx = text.indexOf("\\telugu(", lastVarIdx);
        int malayalamIdx = text.indexOf("\\malayalam(", lastVarIdx);
        if (tamilIdx != -1 && tamilIdx < closeParenIdx) {
            int closeTamilParen = text.indexOf(")", tamilIdx);
            if (closeTamilParen == -1 || closeTamilParen > closeParenIdx) {
                return SuggestionContext.TAMIL;
            }
        }
        if (sanskritIdx != -1 && sanskritIdx < closeParenIdx) {
            int closeSanskritParen = text.indexOf(")", sanskritIdx);
            if (closeSanskritParen == -1 || closeSanskritParen > closeParenIdx) {
                return SuggestionContext.SANSKRIT;
            }
        }
        if (hindiIdx != -1 && hindiIdx < closeParenIdx) {
            int closeHindiParen = text.indexOf(")", hindiIdx);
            if (closeHindiParen == -1 || closeHindiParen > closeParenIdx) {
                return SuggestionContext.HINDI;
            }
        }
        if (teluguIdx != -1 && teluguIdx < closeParenIdx) {
            int closeTeluguParen = text.indexOf(")", teluguIdx);
            if (closeTeluguParen == -1 || closeTeluguParen > closeParenIdx) {
                return SuggestionContext.TELUGU;
            }
        }
        if (malayalamIdx != -1 && malayalamIdx < closeParenIdx) {
            int closeMalayalamParen = text.indexOf(")", malayalamIdx);
            if (closeMalayalamParen == -1 || closeMalayalamParen > closeParenIdx) {
                return SuggestionContext.MALAYALAM;
            }
        }

        return SuggestionContext.GENERAL;
    }
}
