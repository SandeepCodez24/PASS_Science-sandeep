package ui.ui_functions.suggestion_functions;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Side;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.CustomMenuItem;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.Tooltip;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import ui.design.MenuStyle;
import ui.ui_functions.suggestion_functions.SuggestionSettings.Group;
import ui.ui_functions.tools.SettingsIcons;

/**
 * The hint strip along the bottom of the suggestion popup, and the popup's
 * settings menu.
 *
 * <h3>The settings icon</h3>
 * <p>
 * The old vertical ellipsis ({@code ⋮}) was a font glyph at 12 px in the
 * muted description ink: two pixels wide, and on the light strip nearly
 * invisible. It is replaced by a small vector glyph drawn here -- three slider
 * tracks with one knob each:
 * </p>
 *
 * <pre>
 *   ----o-----     .  &lt;- accent dot: some suggestion groups are off
 *   -o--------
 *   ------o---
 * </pre>
 *
 * <ul>
 * <li><b>What it says.</b> Sliders read as "tune what is suggested", which is
 * exactly what the menu behind it does; three dots only said "more".</li>
 * <li><b>The accent dot.</b> Whenever one or more suggestion groups are
 * switched off, a small accent dot sits at the icon's top-right corner, so a
 * shorter list is never mistaken for a list with nothing more to offer. It
 * updates the moment a box in the menu is ticked or cleared.</li>
 * <li><b>Sharp at any scale.</b> Shapes, not a font or a PNG, so it is crisp
 * at 100 % and 150 % and needs no light / dark image pair.</li>
 * <li><b>Colours from CSS.</b> The tracks and knobs take the strip's text
 * colour, the dot the theme's accent, and the hover fill the title strips'
 * button hover -- all tokens, in {@code themes/shared/surfaces.css} section 6.
 * Each knob is ringed in the strip's own colour, which cuts the track either
 * side so the knob reads as sitting on it.</li>
 * </ul>
 *
 * <h3>The menu</h3>
 *
 * <pre>
 *   [x] Variable suggestions
 *   [x] Function suggestions
 *   [ ] End auto fill suggestions
 *   [x] UniCode Constants
 *   ---------------------------
 *   (gear) Settings...
 * </pre>
 *
 * <ul>
 * <li>The four boxes write straight to {@link SuggestionSettings}, which is
 * persisted, and ticking a box does <b>not</b> close the menu, so several can
 * be changed in one visit. The popup re-filters its rows immediately through
 * {@code onSettingsChanged}.</li>
 * <li>"Settings..." opens the same window as the Settings ribbon's Syntax
 * button, through {@code onOpenSettings}.</li>
 * <li>While the menu is open the button keeps its hover fill
 * ({@code .menu-showing}), so it is clear what the menu belongs to.</li>
 * </ul>
 *
 * <h3>Constraints this component still respects</h3>
 * <ol>
 * <li><b>It never takes keyboard focus.</b> Key handling lives on the list and
 * on the editor; a focusable footer would swallow the first arrow key.</li>
 * <li><b>It sits outside the scroll pane</b>, so it never scrolls away.</li>
 * </ol>
 *
 * <h3>Colours</h3>
 * <p>
 * No colour is set from Java any more. The strip is {@code .suggestion-footer}
 * (the inactive title-strip colour, like every other sub-window's strip), the
 * hint {@code .suggestion-footer-hint}. The popup attaches the shared sheets
 * to its content ({@code SurfaceSheets.attach}), so both follow the theme.
 * The {@code darkTheme} parameters are kept so existing callers compile.
 * </p>
 */
public final class SuggestionFooterBar {

    private SuggestionFooterBar() {
        // Factory holder – no instances (use {@link #create}).
    }

    /** Fixed footer height. Deliberately short so it costs almost no popup space. */
    public static final double FOOTER_HEIGHT = 22;

    /** Edge of the square hit area around the settings icon. */
    private static final double MENU_BUTTON_SIZE = 18;

    /** Corner rounding of the button's hover fill. */
    private static final double MENU_BUTTON_RADIUS = 3;

    /** Edge of the gear icon beside "Settings...". */
    private static final double MENU_ICON_SIZE = 14;

    // ---- the slider glyph, in pixels at scale 1.0 ----------------------------

    /** Length of each slider track. */
    private static final double GLYPH_WIDTH = 12;

    /** Thickness of a track. */
    private static final double TRACK_THICKNESS = 1.5;

    /** Distance between the centres of two tracks. */
    private static final double TRACK_PITCH = 4;

    /** Radius of a knob. */
    private static final double KNOB_RADIUS = 1.75;

    /** Width of the ring cut around each knob (and the dot). */
    private static final double KNOB_RING = 1.25;

    /** Where each knob sits along its track, as a share of the track. */
    private static final double[] KNOB_AT = { 0.70, 0.25, 0.55 };

    /** Radius of the accent dot. */
    private static final double BADGE_RADIUS = 2;

    // ---- style classes (colours in surfaces.css, section 6) ----------------

    private static final String FOOTER_CLASS = "suggestion-footer";
    private static final String HINT_CLASS = "suggestion-footer-hint";
    private static final String BUTTON_CLASS = "suggestion-settings-button";
    private static final String TRACK_CLASS = "suggestion-settings-track";
    private static final String KNOB_CLASS = "suggestion-settings-knob";
    private static final String BADGE_CLASS = "suggestion-settings-badge";
    private static final String SHOWING_CLASS = "menu-showing";

    /** The accept-key hint shown to the user. */
    private static final String HINT_TEXT = "Press Tab or Enter to accept";

    /** The full key contract, surfaced on hover. */
    private static final String HINT_TOOLTIP =
            "Tab or Enter accepts the highlighted suggestion.\n"
                    + "Left or Right arrow dismisses it without accepting.\n"
                    + "Esc closes the list.";

    private static final String BUTTON_TIP = "Suggestion settings";
    private static final String BUTTON_TIP_FILTERED =
            "Suggestion settings\nSome suggestion groups are switched off.";

    /**
     * Build the footer without a menu. Kept so any older caller compiles.
     *
     * @param darkTheme unused; colours come from the stylesheets
     * @return a non-focusable, fixed-height footer bar
     */
    public static Region create(boolean darkTheme) {
        return create(darkTheme, null, null);
    }

    /**
     * Build the footer.
     *
     * @param darkTheme         unused; colours come from the stylesheets.
     *                          Kept so existing callers compile.
     * @param onSettingsChanged run after a box in the menu is ticked or
     *                          unticked, so the popup can re-filter; may be null
     * @param onOpenSettings    run when "Settings..." is chosen; may be null,
     *                          in which case the entry is disabled
     * @return a non-focusable, fixed-height footer bar
     */
    public static Region create(boolean darkTheme, Runnable onSettingsChanged, Runnable onOpenSettings) {
        Label hint = new Label(HINT_TEXT);
        hint.getStyleClass().add(HINT_CLASS);
        hint.setStyle("-fx-font-family: 'Consolas'; -fx-font-size: 11;");
        hint.setTooltip(new Tooltip(HINT_TOOLTIP));

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        StackPane menuButton = buildMenuButton(onSettingsChanged, onOpenSettings);

        HBox footer = new HBox(hint, spacer, menuButton);
        footer.getStyleClass().add(FOOTER_CLASS);
        footer.setAlignment(Pos.CENTER_LEFT);
        footer.setPadding(new Insets(0, 4, 0, 10));
        footer.setMinHeight(FOOTER_HEIGHT);
        footer.setPrefHeight(FOOTER_HEIGHT);
        footer.setMaxHeight(FOOTER_HEIGHT);
        // The 1 px line along the top; its colour is in surfaces.css.
        footer.setStyle("-fx-border-width: 1 0 0 0;");

        // Never steal focus or swallow a key: the list keeps full key control.
        footer.setFocusTraversable(false);
        footer.setMouseTransparent(false);
        return footer;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // The settings button and its glyph
    // ─────────────────────────────────────────────────────────────────────────

    private static StackPane buildMenuButton(Runnable onSettingsChanged, Runnable onOpenSettings) {
        Circle badge = new Circle(BADGE_RADIUS);
        javafx.scene.Group glyph = buildGlyph(badge);
        glyph.setMouseTransparent(true);

        StackPane button = new StackPane(glyph);
        button.getStyleClass().add(BUTTON_CLASS);
        button.setStyle("-fx-background-radius: " + MENU_BUTTON_RADIUS + ";");
        button.setMinSize(MENU_BUTTON_SIZE, MENU_BUTTON_SIZE);
        button.setPrefSize(MENU_BUTTON_SIZE, MENU_BUTTON_SIZE);
        button.setMaxSize(MENU_BUTTON_SIZE, MENU_BUTTON_SIZE);
        button.setFocusTraversable(false);

        Tooltip tip = new Tooltip(BUTTON_TIP);
        Tooltip.install(button, tip);
        Runnable refreshBadge = () -> {
            boolean filtered = anyGroupOff();
            badge.setVisible(filtered);
            tip.setText(filtered ? BUTTON_TIP_FILTERED : BUTTON_TIP);
        };
        refreshBadge.run();

        Runnable onChanged = () -> {
            refreshBadge.run();
            if (onSettingsChanged != null) {
                onSettingsChanged.run();
            }
        };

        button.setOnMouseClicked(e -> {
            if (e.getButton() != MouseButton.PRIMARY) {
                return;
            }
            ContextMenu menu = buildMenu(onChanged, onOpenSettings);
            button.getStyleClass().add(SHOWING_CLASS);
            menu.setOnHidden(ev -> button.getStyleClass().remove(SHOWING_CLASS));
            // To the right of the icon, so the menu never covers the rows it
            // is about to filter.
            menu.show(button, Side.RIGHT, 2, 0);
            e.consume();
        });
        return button;
    }

    /**
     * Three slider tracks, a knob on each, and the accent dot at the top-right
     * corner. Laid out in a fixed box so the glyph sits centred in the button
     * whether or not the dot shows.
     */
    private static javafx.scene.Group buildGlyph(Circle badge) {
        javafx.scene.Group glyph = new javafx.scene.Group();

        double height = TRACK_PITCH * 2 + KNOB_RADIUS * 2 + KNOB_RING;
        double top = (height - TRACK_PITCH * 2) / 2.0;

        // An invisible frame fixing the glyph's bounds.
        Rectangle frame = new Rectangle(0, 0, GLYPH_WIDTH + BADGE_RADIUS, height);
        frame.setFill(null);
        frame.setStroke(null);
        glyph.getChildren().add(frame);

        for (int i = 0; i < 3; i++) {
            double cy = top + i * TRACK_PITCH;
            Rectangle track = new Rectangle(0, cy - TRACK_THICKNESS / 2.0, GLYPH_WIDTH, TRACK_THICKNESS);
            track.getStyleClass().add(TRACK_CLASS);
            glyph.getChildren().add(track);
        }
        // Knobs after every track, so each ring cuts its track cleanly.
        for (int i = 0; i < 3; i++) {
            double cy = top + i * TRACK_PITCH;
            Circle knob = new Circle(GLYPH_WIDTH * KNOB_AT[i], cy, KNOB_RADIUS);
            knob.setStrokeWidth(KNOB_RING);
            knob.getStyleClass().add(KNOB_CLASS);
            glyph.getChildren().add(knob);
        }

        badge.setCenterX(GLYPH_WIDTH + BADGE_RADIUS * 0.25);
        badge.setCenterY(BADGE_RADIUS * 0.5);
        badge.setStrokeWidth(KNOB_RING);
        badge.getStyleClass().add(BADGE_CLASS);
        glyph.getChildren().add(badge);
        return glyph;
    }

    /** @return true if at least one suggestion group is switched off */
    private static boolean anyGroupOff() {
        for (Group group : Group.values()) {
            if (!SuggestionSettings.isEnabled(group)) {
                return true;
            }
        }
        return false;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // The menu
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * A fresh menu each time it opens, so the boxes always show the stored
     * state -- even if the Settings window changed it in between.
     */
    private static ContextMenu buildMenu(Runnable onSettingsChanged, Runnable onOpenSettings) {
        ContextMenu menu = MenuStyle.apply(new ContextMenu());
        menu.setAutoHide(true);

        for (Group group : Group.values()) {
            CheckBox box = new CheckBox(group.label());
            box.setSelected(SuggestionSettings.isEnabled(group));
            box.setFocusTraversable(false);
            box.setTooltip(new Tooltip(group.description()));
            box.selectedProperty().addListener((obs, was, now) -> {
                SuggestionSettings.setEnabled(group, now);
                if (onSettingsChanged != null) {
                    onSettingsChanged.run();
                }
            });
            // hideOnClick = false: ticking one box leaves the menu open.
            CustomMenuItem item = new CustomMenuItem(box, false);
            menu.getItems().add(item);
        }

        menu.getItems().add(new SeparatorMenuItem());

        MenuItem settings = new MenuItem("Settings...", SettingsIcons.icon(SettingsIcons.SYNTAX, MENU_ICON_SIZE));
        settings.setDisable(onOpenSettings == null);
        settings.setOnAction(e -> {
            menu.hide();
            if (onOpenSettings != null) {
                onOpenSettings.run();
            }
        });
        menu.getItems().add(settings);
        return menu;
    }
}
