package ui.ui_functions.suggestion_functions;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;

/**
 * The hint strip along the bottom of the suggestion popup, mirroring the
 * familiar "Press tab to accept" bar.
 *
 * <p>
 * The wording names every accept key the editor actually binds, so the hint
 * never drifts from {@code EditorSuggestionHandler}'s key handling:
 * <b>Tab</b> and <b>Enter</b> accept; the arrow keys, documented in the tooltip,
 * step away without accepting.
 *
 * <h3>Two constraints this component must respect</h3>
 * <ol>
 * <li><b>It must not take focus.</b> The popup's key handling lives on the list
 * and on the editor. A focusable footer would swallow the first arrow key and
 * break the non-destructive dismissal.</li>
 * <li><b>It must sit outside the scroll pane.</b> Placed inside the list it
 * would scroll away with the rows; it belongs in the popup's container, below
 * the list.</li>
 * </ol>
 */
public final class SuggestionFooterBar {

    private SuggestionFooterBar() {
        // Factory holder – no instances (use {@link #create}).
    }

    /** Fixed footer height. Deliberately short so it costs almost no popup space. */
    public static final double FOOTER_HEIGHT = 22;

    /** The accept-key hint shown to the user. */
    private static final String HINT_TEXT = "Press Tab or Enter to accept";

    /** The full key contract, surfaced on hover. */
    private static final String HINT_TOOLTIP =
            "Tab or Enter accepts the highlighted suggestion.\n"
                    + "Left or Right arrow dismisses it without accepting.\n"
                    + "Esc closes the list.";

    /**
     * Build the footer.
     *
     * @param darkTheme whether the popup is currently in dark mode
     * @return a non-focusable, fixed-height footer bar
     */
    public static Region create(boolean darkTheme) {
        Label hint = new Label(HINT_TEXT);
        hint.setStyle("-fx-font-family: 'Consolas'; -fx-font-size: 11;");
        hint.setTextFill(javafx.scene.paint.Color.web(
                darkTheme ? PopupThemeManager.DARK_DESCRIPTION_TEXT
                        : PopupThemeManager.LIGHT_DESCRIPTION_TEXT));
        hint.setTooltip(new javafx.scene.control.Tooltip(HINT_TOOLTIP));

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        // The overflow affordance: a quiet vertical ellipsis on the right, the
        // natural home for a future "Suggestions settings" menu.
        Label overflow = new Label("\u22EE");
        overflow.setStyle("-fx-font-size: 12;");
        overflow.setTextFill(javafx.scene.paint.Color.web(
                darkTheme ? PopupThemeManager.DARK_DESCRIPTION_TEXT
                        : PopupThemeManager.LIGHT_DESCRIPTION_TEXT));

        HBox footer = new HBox(hint, spacer, overflow);
        footer.setAlignment(Pos.CENTER_LEFT);
        footer.setPadding(new Insets(0, 8, 0, 10));
        footer.setMinHeight(FOOTER_HEIGHT);
        footer.setPrefHeight(FOOTER_HEIGHT);
        footer.setMaxHeight(FOOTER_HEIGHT);

        // Never steal focus or swallow a key: the list keeps full key control.
        footer.setFocusTraversable(false);
        footer.setMouseTransparent(false);

        footer.setStyle(style(darkTheme));
        return footer;
    }

    /** Footer background plus the 1px separator line above it. */
    private static String style(boolean darkTheme) {
        String background = darkTheme ? "#2B2B2B" : "#F5F6F8";
        String border = darkTheme ? "#3C3F41" : "#D6DBE3";
        return "-fx-background-color: " + background + ";"
                + "-fx-border-color: " + border + " transparent transparent transparent;"
                + "-fx-border-width: 1 0 0 0;";
    }
}
