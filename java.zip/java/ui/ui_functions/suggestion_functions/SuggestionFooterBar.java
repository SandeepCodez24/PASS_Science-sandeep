package ui.ui_functions.suggestion_functions;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Side;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.CustomMenuItem;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.Tooltip;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import ui.ui_functions.suggestion_functions.SuggestionSettings.Group;
import ui.ui_functions.tools.SettingsIcons;

/**
 * The hint strip along the bottom of the suggestion popup, and the popup's
 * settings menu.
 *
 * <h3>The three-dot menu</h3>
 * The vertical ellipsis on the right is now a button. It opens a small menu:
 *
 * <pre>
 *   [x] Variable suggestions
 *   [x] Function suggestions
 *   [ ] End auto fill suggestions
 *   [x] UniCode Constants
 *   ---------------------------
 *   (gear) Settings...
 * </pre>
 *
 * <ul>
 * <li>The four boxes write straight to {@link SuggestionSettings}, which is
 * persisted, and ticking a box does <b>not</b> close the menu, so several can
 * be changed in one visit. The popup re-filters its rows immediately through
 * {@code onSettingsChanged}.</li>
 * <li>"Settings..." opens the same window as the Settings ribbon's Syntax
 * button, through {@code onOpenSettings}.</li>
 * </ul>
 *
 * <h3>Constraints this component still respects</h3>
 * <ol>
 * <li><b>It never takes keyboard focus.</b> Key handling lives on the list and
 * on the editor; a focusable footer would swallow the first arrow key.</li>
 * <li><b>It sits outside the scroll pane</b>, so it never scrolls away.</li>
 * </ol>
 */
public final class SuggestionFooterBar {

    private SuggestionFooterBar() {
        // Factory holder – no instances (use {@link #create}).
    }

    /** Fixed footer height. Deliberately short so it costs almost no popup space. */
    public static final double FOOTER_HEIGHT = 22;

    /** Edge of the square hit area around the three dots. */
    private static final double MENU_BUTTON_SIZE = 18;

    /** Edge of the gear icon beside "Settings...". */
    private static final double MENU_ICON_SIZE = 14;

    /** The accept-key hint shown to the user. */
    private static final String HINT_TEXT = "Press Tab or Enter to accept";

    /** The full key contract, surfaced on hover. */
    private static final String HINT_TOOLTIP =
            "Tab or Enter accepts the highlighted suggestion.\n"
                    + "Left or Right arrow dismisses it without accepting.\n"
                    + "Esc closes the list.";

    /**
     * Build the footer without a menu. Kept so any older caller compiles.
     *
     * @param darkTheme whether the popup is currently in dark mode
     * @return a non-focusable, fixed-height footer bar
     */
    public static Region create(boolean darkTheme) {
        return create(darkTheme, null, null);
    }

    /**
     * Build the footer.
     *
     * @param darkTheme         whether the popup is currently in dark mode
     * @param onSettingsChanged run after a box in the menu is ticked or
     *                          unticked, so the popup can re-filter; may be null
     * @param onOpenSettings    run when "Settings..." is chosen; may be null,
     *                          in which case the entry is disabled
     * @return a non-focusable, fixed-height footer bar
     */
    public static Region create(boolean darkTheme, Runnable onSettingsChanged, Runnable onOpenSettings) {
        String inkMuted = darkTheme ? PopupThemeManager.DARK_DESCRIPTION_TEXT
                : PopupThemeManager.LIGHT_DESCRIPTION_TEXT;

        Label hint = new Label(HINT_TEXT);
        hint.setStyle("-fx-font-family: 'Consolas'; -fx-font-size: 11;");
        hint.setTextFill(Color.web(inkMuted));
        hint.setTooltip(new Tooltip(HINT_TOOLTIP));

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        StackPane menuButton = buildMenuButton(darkTheme, inkMuted, onSettingsChanged, onOpenSettings);

        HBox footer = new HBox(hint, spacer, menuButton);
        footer.setAlignment(Pos.CENTER_LEFT);
        footer.setPadding(new Insets(0, 4, 0, 10));
        footer.setMinHeight(FOOTER_HEIGHT);
        footer.setPrefHeight(FOOTER_HEIGHT);
        footer.setMaxHeight(FOOTER_HEIGHT);

        // Never steal focus or swallow a key: the list keeps full key control.
        footer.setFocusTraversable(false);
        footer.setMouseTransparent(false);

        footer.setStyle(style(darkTheme));
        return footer;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // The three-dot button and its menu
    // ─────────────────────────────────────────────────────────────────────────

    private static StackPane buildMenuButton(boolean darkTheme, String ink,
            Runnable onSettingsChanged, Runnable onOpenSettings) {
        Label dots = new Label("\u22EE");
        dots.setStyle("-fx-font-size: 12; -fx-font-weight: bold;");
        dots.setTextFill(Color.web(ink));
        dots.setMouseTransparent(true);

        StackPane button = new StackPane(dots);
        button.setMinSize(MENU_BUTTON_SIZE, MENU_BUTTON_SIZE);
        button.setPrefSize(MENU_BUTTON_SIZE, MENU_BUTTON_SIZE);
        button.setMaxSize(MENU_BUTTON_SIZE, MENU_BUTTON_SIZE);
        button.setFocusTraversable(false);
        Tooltip.install(button, new Tooltip("Suggestion settings"));

        String idle = "-fx-background-color: transparent; -fx-background-radius: 3;";
        String hover = "-fx-background-color: " + (darkTheme ? "#3A3D41" : "#E1E5EB")
                + "; -fx-background-radius: 3;";
        button.setStyle(idle);
        button.setOnMouseEntered(e -> button.setStyle(hover));
        button.setOnMouseExited(e -> button.setStyle(idle));

        button.setOnMouseClicked(e -> {
            if (e.getButton() != MouseButton.PRIMARY) {
                return;
            }
            ContextMenu menu = buildMenu(onSettingsChanged, onOpenSettings);
            // To the right of the dots, so the menu never covers the rows it
            // is about to filter.
            menu.show(button, Side.RIGHT, 2, 0);
            e.consume();
        });
        return button;
    }

    /**
     * A fresh menu each time it opens, so the boxes always show the stored
     * state -- even if the Settings window changed it in between.
     */
    private static ContextMenu buildMenu(Runnable onSettingsChanged, Runnable onOpenSettings) {
        ContextMenu menu = new ContextMenu();
        menu.setAutoHide(true);

        for (Group group : Group.values()) {
            CheckBox box = new CheckBox(group.label());
            box.setSelected(SuggestionSettings.isEnabled(group));
            box.setFocusTraversable(false);
            box.setTooltip(new Tooltip(group.description()));
            box.selectedProperty().addListener((obs, was, now) -> {
                SuggestionSettings.setEnabled(group, now);
                if (onSettingsChanged != null) {
                    onSettingsChanged.run();
                }
            });
            // hideOnClick = false: ticking one box leaves the menu open.
            CustomMenuItem item = new CustomMenuItem(box, false);
            menu.getItems().add(item);
        }

        menu.getItems().add(new SeparatorMenuItem());

        MenuItem settings = new MenuItem("Settings...", SettingsIcons.icon(SettingsIcons.SYNTAX, MENU_ICON_SIZE));
        settings.setDisable(onOpenSettings == null);
        settings.setOnAction(e -> {
            menu.hide();
            if (onOpenSettings != null) {
                onOpenSettings.run();
            }
        });
        menu.getItems().add(settings);
        return menu;
    }

    /** Footer background plus the 1px separator line above it. */
    private static String style(boolean darkTheme) {
        String background = darkTheme ? "#2B2B2B" : "#F5F6F8";
        String border = darkTheme ? "#3C3F41" : "#D6DBE3";
        return "-fx-background-color: " + background + ";"
                + "-fx-border-color: " + border + " transparent transparent transparent;"
                + "-fx-border-width: 1 0 0 0;";
    }
}
