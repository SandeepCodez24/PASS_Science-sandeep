package ui.ui_functions.suggestion_functions;

/**
 * Centralizes the colour palette and the {@code ListView} CSS used by the
 * suggestion popup, for both light and dark themes.
 *
 * <p>
 * Extracted from {@code SuggestionPopup}'s colour constants and
 * {@code applyThemeStyles()}.
 */
public final class PopupThemeManager {

    private PopupThemeManager() {
        // Utility class – no instances.
    }

    // ── Light theme ─────────────────────────────────────────────────────────
    public static final String LIGHT_POPUP_BG = "#ffffff";
    public static final String LIGHT_POPUP_TEXT = "#000000";
    public static final String LIGHT_POPUP_BORDER = "#c8c8c8";
    // Plain, neutral hover/selection tint (no coloured "title bar" look).
    public static final String LIGHT_SELECTION_BG = "#eaeaea";
    public static final String LIGHT_DESCRIPTION_TEXT = "#555555";
    public static final String LIGHT_MARKER_SUB = "#7ec8e3";
    public static final String LIGHT_MARKER_SUP = "#b5cea8";

    // ── Dark theme ──────────────────────────────────────────────────────────
    public static final String DARK_POPUP_BG = "#252526";
    public static final String DARK_POPUP_TEXT = "#e6e6e6";
    public static final String DARK_POPUP_BORDER = "#3a3a3a";
    // Plain, neutral hover/selection tint (no coloured "title bar" look).
    public static final String DARK_SELECTION_BG = "#2d2d2e";
    public static final String DARK_DESCRIPTION_TEXT = "#cfcfcf";
    public static final String DARK_MARKER_SUB = "#9ed8ea";
    public static final String DARK_MARKER_SUP = "#cbdc9a";

    /**
     * Build the {@code ListView} inline style for the given theme.
     *
     * @param darkTheme {@code true} for the dark palette
     * @return a JavaFX CSS string suitable for {@code ListView#setStyle}
     */
    public static String listStyle(boolean darkTheme) {
        String background = darkTheme ? DARK_POPUP_BG : LIGHT_POPUP_BG;
        String text = darkTheme ? DARK_POPUP_TEXT : LIGHT_POPUP_TEXT;
        String border = darkTheme ? DARK_POPUP_BORDER : LIGHT_POPUP_BORDER;

        return """
                -fx-font-family: 'Consolas';
                -fx-font-size: 13;
                -fx-control-inner-background: %s;
                -fx-background-color: %s;
                -fx-text-fill: %s;
                -fx-border-color: %s;
                -fx-border-width: 1;
                -fx-padding: 0;
                -fx-spacing: 0;
                """.formatted(background, background, text, border);
    }
}
