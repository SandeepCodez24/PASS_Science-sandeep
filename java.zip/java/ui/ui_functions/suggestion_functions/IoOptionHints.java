package ui.ui_functions.suggestion_functions;

import java.util.Map;
import java.util.regex.Pattern;

/**
 * Short hints for the {@code name=} rows of a data I/O call: the values an
 * option takes and whether a position counts from 0 or 1
 * ({@code docs/IO_Phase1_Frontend_Handover.md} 6.2,
 * {@code IO_Phase2_3_Frontend_Handover.md} 3 and 4.1). Shown after the usage
 * in the row's description.
 */
final class IoOptionHints {

    private IoOptionHints() {
    }

    private static final Pattern DATABASE = Pattern.compile("save_(sqlite|postgresql|mysql|oracle|sqlserver)");
    private static final Pattern IMAGE = Pattern.compile("read_(png|jpg|jpeg|tiff|bmp|gif|dicom)");
    private static final Pattern AUDIO = Pattern.compile("read_(wav|flac|ogg|mp3)");

    /** Hints that hold for every I/O function with that option. */
    private static final Map<String, String> COMMON = Map.ofEntries(
            Map.entry("rows", "1-based: [1:500], a list, or \"1:500\""),
            Map.entry("cols", "1-based positions, names, or [1:5]"),
            Map.entry("sheet", "a name, or a number from 1"),
            Map.entry("bands", "1-based: [1, 2, 3]"),
            Map.entry("slice", "1-based \"1:10, :, 5\" (a range from 0 reads Python style)"),
            Map.entry("groups", "1-based (a 0 switches to 0-based)"),
            Map.entry("frames", "0-based: [0, 10, 20] or [0:100]"),
            Map.entry("window", "[x, y, w, h] in pixels from 0"),
            Map.entry("roi", "[x, y, w, h] in pixels from 0"),
            Map.entry("quote", "\"minimal\" or \"all\""),
            Map.entry("endian", "\"little\" or \"big\""),
            Map.entry("theme", "\"navy\", \"light\" or \"minimal\""),
            Map.entry("nan_mode", "\"null\" or \"str\""),
            Map.entry("enc", "\"utf-8\", \"utf-8-sig\", \"latin-1\", \"cp1252\" or \"utf-16\""),
            Map.entry("dlm", "\",\", \"\\t\", \";\", \"|\", \"\\s+\" or \"auto\""),
            Map.entry("hdr", "-1 detect, 0 none, n = header row"),
            Map.entry("doc", "a number from 0, or \"all\""),
            Map.entry("max_size", "\"48kb\", \"5mb\", \"2gb\" or bytes"),
            Map.entry("ver", "\"v5\", \"v7\" or \"v7.3\""),
            Map.entry("struct_as", "\"dict\" or \"object\""),
            Map.entry("chunks", "\"auto\", \"none\" or sizes [64, 64]"),
            Map.entry("geom_type", "\"point\", \"multipoint\", \"line\" or \"polygon\""),
            Map.entry("crs", "\"EPSG:4326\", \"EPSG:3857\" or a UTM \"EPSG:326NN\""),
            Map.entry("subsampling", "\"4:2:0\" or \"4:4:4\""),
            Map.entry("channels", "\"rgb\", \"gray\" or \"rgba\""),
            Map.entry("op", "\"read\", \"load\" or \"save\""),
            Map.entry("table", "0-based index, id or caption"));

    /**
     * @param function the called I/O function
     * @param input    one of its inputs
     * @return the hint, or null when there is none
     */
    static String hint(String function, String input) {
        int cut = function.indexOf('_');
        String fmt = cut < 0 ? "" : function.substring(cut + 1);
        switch (input) {
            case "mode":
                if (DATABASE.matcher(function).matches()) {
                    return "\"append\", \"replace\", \"upsert\" or \"fail\"";
                }
                return function.startsWith("save_") ? "\"w\" or \"a\"" : null;
            case "mode_type":
                return fmt.equals("gpx") ? "\"track\", \"waypoint\" or \"route\"" : "\"line\", \"point\" or \"polygon\"";
            case "layer":
                return fmt.equals("gpx") ? "\"tracks\", \"waypoints\" or \"routes\""
                        : "\"placemarks\", \"paths\" or \"polygons\"";
            case "codec":
                return fmt.equals("tiff") ? "\"lzw\", \"deflate\", \"packbits\" or \"none\"" : "\"h264\" or \"mjpeg\"";
            case "format":
                return fmt.equals("nc") || fmt.equals("cdf") ? "\"nc4\", \"classic\" or \"64bit\"" : null;
            case "dtype":
                if (IMAGE.matcher(function).matches()) {
                    return "\"uint8\", \"uint16\", \"float32\" or \"float64\"";
                }
                return AUDIO.matcher(function).matches() ? "\"float32\", \"float64\" or \"int16\"" : null;
            case "table":
                return fmt.startsWith("htm") ? COMMON.get("table") : null;
            case "compress":
                return compress(fmt, function.startsWith("save_"));
            default:
                return COMMON.get(input);
        }
    }

    private static String compress(String fmt, boolean save) {
        if (!save) {
            return null;
        }
        switch (fmt) {
            case "parquet":
                return "\"zstd\", \"snappy\", \"lz4\", \"gzip\" or \"none\"";
            case "feather":
                return "\"zstd\", \"lz4\" or \"none\"";
            case "orc":
                return "\"zstd\", \"snappy\", \"lz4\", \"zlib\" or \"none\"";
            case "h5", "hdf", "he5":
                return "\"gzip\", \"lzf\" or \"none\"";
            case "nc", "cdf":
                return "\"zlib\" or \"none\"";
            case "tif", "geotiff":
                return "\"deflate\", \"lzw\", \"zstd\" or \"none\"";
            case "fits", "fit":
                return "\"rice\", \"gzip\" or \"none\"";
            case "csv", "tsv", "txt", "dat", "json", "xml", "bin", "custom":
                return "\"none\" or \"gz\"";
            default:
                return "\"yes\" or \"no\"";
        }
    }
}
