package ui.ui_functions.suggestion_functions;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * A function the user defined in the current file, as read from its header.
 *
 * <p>
 * Covers all three accepted header shapes -- {@code function f(x):},
 * {@code function y = f(x):} and {@code function [a, b] = f(x):} -- so the
 * popup can show the real signature ({@code f(x)}) rather than a bare name.
 * The same class describes a class method; the owning
 * {@link DiscoveredClass} holds those.
 *
 * <h3>Defaults (new)</h3>
 * An input may carry a default value ({@code area(scale=1)}). The default's
 * text is kept beside its name, so the popup shows the real signature and
 * the named-value rows ({@code scale=}) can say what they belong to.
 */
public final class DiscoveredFunction {

    private final String name;
    private final List<String> parameters;
    private final List<String> outputs;
    private final List<String> defaults;
    private final int declarationOrder;

    /**
     * @param name             the function name as written
     * @param parameters       declared input names, in order
     * @param outputs          declared output names, in order
     * @param declarationOrder zero-based line index of the header
     */
    public DiscoveredFunction(String name, List<String> parameters, List<String> outputs, int declarationOrder) {
        this(name, parameters, outputs, null, declarationOrder);
    }

    /**
     * @param name             the function name as written
     * @param parameters       declared input names, in order
     * @param outputs          declared output names, in order
     * @param defaults         per input, its default's text or null; null for
     *                         no defaults at all
     * @param declarationOrder zero-based line index of the header
     */
    public DiscoveredFunction(String name, List<String> parameters, List<String> outputs, List<String> defaults,
            int declarationOrder) {
        this.name = name;
        this.parameters = List.copyOf(parameters);
        this.outputs = List.copyOf(outputs);
        List<String> padded = new ArrayList<>(parameters.size());
        for (int i = 0; i < parameters.size(); i++) {
            padded.add(defaults != null && i < defaults.size() ? defaults.get(i) : null);
        }
        this.defaults = Collections.unmodifiableList(padded);
        this.declarationOrder = declarationOrder;
    }

    public String getName() {
        return name;
    }

    public List<String> getParameters() {
        return parameters;
    }

    public List<String> getOutputs() {
        return outputs;
    }

    /** @return per input, its default's text, or null when it has none */
    public List<String> getDefaults() {
        return defaults;
    }

    public int getDeclarationOrder() {
        return declarationOrder;
    }

    /** Lower-cased name, used for matching and ranking. */
    public String getPrimaryKey() {
        return name.toLowerCase(Locale.ROOT);
    }

    /** @return {@code name(a, b=1)}: the inputs as written, defaults included */
    public String signature() {
        StringBuilder text = new StringBuilder(name).append('(');
        for (int i = 0; i < parameters.size(); i++) {
            if (i > 0) {
                text.append(", ");
            }
            text.append(parameters.get(i));
            if (defaults.get(i) != null) {
                text.append('=').append(defaults.get(i));
            }
        }
        return text.append(')').toString();
    }

    /**
     * @param lowerInput the already lower-cased typed prefix
     * @return true when the name starts with the input
     */
    public boolean matchesPrefix(String lowerInput) {
        return lowerInput == null || lowerInput.isEmpty() || getPrimaryKey().startsWith(lowerInput);
    }

    /**
     * @param lowerInput the already lower-cased typed text
     * @return true when the name contains the input anywhere
     */
    public boolean matchesLoose(String lowerInput) {
        return lowerInput == null || lowerInput.isEmpty() || getPrimaryKey().contains(lowerInput);
    }
}
