package ui.ui_functions.suggestion_functions;

import java.util.List;
import java.util.Locale;

/**
 * A function the user defined in the current file, as read from its header.
 *
 * <p>
 * Covers all three accepted header shapes -- {@code function f(x):},
 * {@code function y = f(x):} and {@code function [a, b] = f(x):} -- so the
 * popup can show the real signature ({@code f(x)}) rather than a bare name.
 * The same class describes a class method; the owning
 * {@link DiscoveredClass} holds those.
 */
public final class DiscoveredFunction {

    private final String name;
    private final List<String> parameters;
    private final List<String> outputs;
    private final int declarationOrder;

    /**
     * @param name             the function name as written
     * @param parameters       declared input names, in order
     * @param outputs          declared output names, in order
     * @param declarationOrder zero-based line index of the header
     */
    public DiscoveredFunction(String name, List<String> parameters, List<String> outputs, int declarationOrder) {
        this.name = name;
        this.parameters = List.copyOf(parameters);
        this.outputs = List.copyOf(outputs);
        this.declarationOrder = declarationOrder;
    }

    public String getName() {
        return name;
    }

    public List<String> getParameters() {
        return parameters;
    }

    public List<String> getOutputs() {
        return outputs;
    }

    public int getDeclarationOrder() {
        return declarationOrder;
    }

    /** Lower-cased name, used for matching and ranking. */
    public String getPrimaryKey() {
        return name.toLowerCase(Locale.ROOT);
    }

    /** @return {@code name(a, b)} */
    public String signature() {
        return name + "(" + String.join(", ", parameters) + ")";
    }

    /**
     * @param lowerInput the already lower-cased typed prefix
     * @return true when the name starts with the input
     */
    public boolean matchesPrefix(String lowerInput) {
        return lowerInput == null || lowerInput.isEmpty() || getPrimaryKey().startsWith(lowerInput);
    }

    /**
     * @param lowerInput the already lower-cased typed text
     * @return true when the name contains the input anywhere
     */
    public boolean matchesLoose(String lowerInput) {
        return lowerInput == null || lowerInput.isEmpty() || getPrimaryKey().contains(lowerInput);
    }
}
