package ui.ui_functions.suggestion_functions;

import java.util.EnumMap;
import java.util.Map;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Region;
import javafx.scene.Node;

/**
 * Loads and caches the suggestion-row icons from
 * {@code src/main/resources/icons/suggestions}.
 *
 * <h3>Why a cache</h3>
 * {@code SuggestionCellRenderer} previously built a {@code new Image(...)} on
 * every {@code updateItem} call. A {@link javafx.scene.control.ListCell} is
 * re-rendered on every keystroke, on every scroll tick and on every selection
 * change, so each of those was a fresh classpath lookup and a fresh PNG decode
 * on the JavaFX application thread. Decoding the image once per
 * {@link SuggestionKind} and handing out cheap {@link ImageView} wrappers
 * removes that work from the typing path entirely.
 *
 * <h3>Resource layout</h3>
 *
 * <pre>
 *   src/main/resources/icons/suggestions/variable_int_16.png
 *   src/main/resources/icons/suggestions/variable_float_16.png
 *   ...
 *   src/main/resources/icons/suggestions/class_user_16.png
 * </pre>
 *
 * The {@code _32} variants ship alongside for HiDPI; switch {@link #ICON_PIXELS}
 * and the loader picks them up without any other change.
 *
 * <h3>Script rows reuse the {@code .nc} file icon</h3>
 * {@link SuggestionKind#NC_FILE} has no file in {@code icons/suggestions/}. It
 * loads {@code /icons/ic_19_file.png}, the same icon the file directory shows
 * for a {@code .nc} file, decoded straight to the 16px row size so it stays
 * crisp. One picture means one meaning across the whole IDE.
 */
public final class SuggestionIconProvider {

    private SuggestionIconProvider() {
        // Utility class – no instances.
    }

    /** Folder holding the generated icon set. */
    private static final String ICON_FOLDER = "/icons/suggestions/";

    /** The project's {@code .nc} file icon, reused for script rows. */
    private static final String NC_FILE_ICON = "/icons/ic_19_file.png";

    /** Source pixel size to load. 16 is the crisp 1x size for a 22px row. */
    private static final int ICON_PIXELS = 16;

    /** Rendered size in the cell. */
    private static final double DISPLAY_SIZE = 16;

    /** One decoded image per kind, built lazily and kept for the session. */
    private static final Map<SuggestionKind, Image> CACHE = new EnumMap<>(SuggestionKind.class);

    /**
     * An icon node for the given kind.
     *
     * @param kind the row's kind; null falls back to the generic variable icon
     * @return a node sized to the icon column — never null, so the text columns
     *         of every row stay aligned even when an icon fails to load
     */
    public static Node iconFor(SuggestionKind kind) {
        SuggestionKind resolved = kind == null ? SuggestionKind.VARIABLE_GENERIC : kind;
        Image image = CACHE.computeIfAbsent(resolved, SuggestionIconProvider::load);
        if (image == null) {
            return placeholder();
        }
        ImageView view = new ImageView(image);
        view.setFitWidth(DISPLAY_SIZE);
        view.setFitHeight(DISPLAY_SIZE);
        view.setPreserveRatio(true);
        view.setSmooth(true);
        return view;
    }

    /**
     * Resolves a row that only knows its legacy category string. Variables route
     * through {@link VariableKindIndex} so they get their inferred type icon;
     * everything else maps to a sensible default.
     *
     * @param category the legacy suggestion category
     * @param code     the row's code, used as the variable-name key
     * @return the kind to draw
     */
    public static SuggestionKind kindForCategory(String category, String code) {
        if (category == null) {
            return SuggestionKind.VARIABLE_GENERIC;
        }
        switch (category) {
            case "Function":
                return SuggestionKind.FUNCTION_BUILTIN;
            case "UserFunction":
                return SuggestionKind.FUNCTION_USER;
            case "UserClass":
                return SuggestionKind.CLASS_USER;
            case "NcFile":
                return SuggestionKind.NC_FILE;
            case "Variable":
            case "StyledVariable":
                return VariableKindIndex.kindFor(code);
            default:
                // Script letters, commands and constants are symbols the user is
                // about to turn into a variable, so the generic marker is right.
                return SuggestionKind.VARIABLE_GENERIC;
        }
    }

    /** Decodes one icon, returning null when the resource is missing. */
    private static Image load(SuggestionKind kind) {
        boolean ncFile = kind == SuggestionKind.NC_FILE;
        String path = ncFile ? NC_FILE_ICON
                : ICON_FOLDER + kind.getIconBaseName() + "_" + ICON_PIXELS + ".png";
        try (var stream = SuggestionIconProvider.class.getResourceAsStream(path)) {
            if (stream == null) {
                return null;
            }
            // The shared .nc icon is larger than a row icon: decode it at the
            // row size with smoothing rather than shrinking it on every paint.
            return ncFile
                    ? new Image(stream, DISPLAY_SIZE, DISPLAY_SIZE, true, true)
                    : new Image(stream);
        } catch (Exception e) {
            // A missing icon must never break completion. The caller draws a
            // blank spacer so the row still lines up.
            return null;
        }
    }

    /** Invisible node occupying exactly the icon column width. */
    private static Node placeholder() {
        Region spacer = new Region();
        spacer.setMinSize(DISPLAY_SIZE, DISPLAY_SIZE);
        spacer.setPrefSize(DISPLAY_SIZE, DISPLAY_SIZE);
        spacer.setMaxSize(DISPLAY_SIZE, DISPLAY_SIZE);
        return spacer;
    }
}
