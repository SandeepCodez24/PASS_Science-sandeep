package ui.ui_functions;

import java.util.List;

import ui.ui_functions.suggestion_functions.SuggestionFilterService;
import ui.ui_functions.suggestion_functions.SuggestionRegistry;
import ui.ui_functions.suggestion_functions.SymbolConverter;
import ui.ui_functions.suggestion_functions.VariableDiscoveryEngine;

/**
 * Provides autocomplete suggestions for the UPI editor.
 *
 * <p>
 * This class is now a <b>thin facade</b>. All heavy logic lives in the
 * {@code ui.ui_functions.suggestion_functions} package:
 * <ul>
 * <li>{@link SuggestionRegistry} – shared static state (suggestion lists,
 * discovered variables, recently-used caches)</li>
 * <li>{@code SuggestionInitializer} – builds the static symbol tables</li>
 * <li>{@link VariableDiscoveryEngine} – parses variables from editor text</li>
 * <li>{@code ContextDetector} – decides the active script/notation context</li>
 * <li>{@link SuggestionFilterService} – filtering / ranking / retrieval</li>
 * <li>{@link SymbolConverter} – name→symbol conversion + recents</li>
 * </ul>
 *
 * <p>
 * The public method signatures and the nested {@link Suggestion} /
 * {@link SuggestionContext} types are preserved so existing callers
 * (e.g. {@code SuggestionPopup}, {@code EditorManager}) compile unchanged.
 */
public class SuggestionProvider {

    static {
        // Force the registry (and therefore suggestion initialization) to load.
        SuggestionRegistry.ensureInitialized();
    }

    /** Context types for filtering suggestions. */
    public enum SuggestionContext {
        GREEK, // After \var(
        TAMIL, // After \var(\tamil(
        SANSKRIT, // After \var(\sanskrit(
        HINDI, // After \var(\hindi(
        TELUGU, // After \var(\telugu(
        MALAYALAM, // After \var(\malayalam(
        UNICONSTANT, // After \con(
        SUBSCRIPT, // While typing with __ mode
        SUPERSCRIPT, // While typing with ^^ mode
        GENERAL // Any other context
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PUBLIC API (delegates only – behavior lives in suggestion_functions)
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Extract variable names from the code and register them as suggestions.
     *
     * @param text the full code text
     */
    public static void updateVariablesFromText(String text) {
        VariableDiscoveryEngine.updateVariablesFromText(text);
    }

    /**
     * Get suggestions matching the current input, filtered by context.
     *
     * @param input    the current text being typed
     * @param fullText the full code text for context detection
     * @return list of matching suggestions sorted by relevance
     */
    public static List<Suggestion> getSuggestionsFiltered(String input, String fullText) {
        return SuggestionFilterService.getSuggestionsFiltered(input, fullText);
    }

    /**
     * Get suggestions matching the current input (context-free variant).
     *
     * @param input the current text being typed (e.g. "\var" or "\v")
     * @return list of matching suggestions sorted by relevance
     */
    public static List<Suggestion> getSuggestions(String input) {
        return SuggestionFilterService.getSuggestions(input);
    }

    /** Get all available suggestions (for initialization or reference). */
    public static List<Suggestion> getAllSuggestions() {
        return SuggestionRegistry.getAllSuggestions();
    }

    /**
     * Convert a symbol name to its actual Unicode character.
     *
     * @param symbolName the simple name (e.g. "alpha", "mu", "kaa", "i")
     * @return the actual Unicode symbol, or the original name if not found
     */
    public static String getSymbolCharacter(String symbolName) {
        return SymbolConverter.getSymbolCharacter(symbolName);
    }

    /**
     * Add a symbol to the recently-used cache.
     *
     * @param symbolCode the symbol code (full format like \var(\alpha) preferred)
     */
    public static void addRecentlyUsedSymbol(String symbolCode) {
        SymbolConverter.addRecentlyUsedSymbol(symbolCode);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // SHARED DATA MODEL (kept inside SuggestionProvider by request)
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Suggestion data class.
     */
    public static class Suggestion {
        private final String code; // What to type
        private final String description; // Human-readable description
        private final String display; // What character/symbol it produces
        private final String category; // Category for grouping

        public Suggestion(String code, String description, String display, String category) {
            this.code = code;
            this.description = description;
            this.display = display;
            this.category = category;
        }

        public String getCode() {
            return code;
        }

        public String getDescription() {
            return description;
        }

        public String getDisplay() {
            return display;
        }

        public String getCategory() {
            return category;
        }

        @Override
        public String toString() {
            return code + " → " + display + " (" + description + ")";
        }
    }
}
