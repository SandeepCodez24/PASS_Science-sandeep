package ui.ui_functions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

////////////////////////////////////////////////////////////////
import language.replace.Greek;
import language.replace.Malayalam;
import language.replace.Sanskrit;
import language.replace.Subscript;
import language.replace.Superscript;
import language.replace.Tamil;
import language.replace.Telugu;
import language.replace.Uniconstant;
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
/**
 * Provides autocomplete suggestions for UPI editor.
 * Handles Greek symbols, Tamil characters, UPI keywords, and special syntax.
 */
public class SuggestionProvider {

    private static final List<Suggestion> allSuggestions = new ArrayList<>();
    private static final Set<String> discoveredVariables = new LinkedHashSet<>();
    private static final Map<String, String> discoveredStyledVariables = new LinkedHashMap<>(); // raw code -> encoded
                                                                                                // display
    private static final Map<String, String> recentlyUsedSymbols = new LinkedHashMap<>(); // Maps simple name → full
                                                                                          // format
    private static final Map<String, String> recentlyUsedSymbolDisplays = new LinkedHashMap<>(); // Maps simple name →
                                                                                                 // actual symbol
                                                                                                 // character

    // Context types for filtering suggestions
    enum SuggestionContext {
        GREEK, // After \var(
        TAMIL, // After \var(\tamil(
        SANSKRIT, // After \var(\sanskrit(
        HINDI, // After \var(\hindi(
        TELUGU, // After \var(\telugu(
        MALAYALAM, // After \var(\malayalam(
        UNICONSTANT, // After \con(
        SUBSCRIPT, // While typing with __ mode
        SUPERSCRIPT, // While typing with ^^ mode
        GENERAL // Any other context
    }

    static {
        initializeSuggestions();
    }

    /**
     * Initialize all available suggestions from various symbol sets and keywords.
     */
    private static void initializeSuggestions() {
        // Greek symbols
        addGreekSuggestions();
        addGreekSimpleNames();

        // Tamil vowels and consonants
        addTamilSuggestions();
        addTamilSimpleNames();
        // Sanskrit symbols
        addSanskritSuggestions();
        addSanskritSimpleNames();

        // Malayalam symbols
        addMalayalamSuggestions();
        addMalayalamSimpleNames();

        // Telugu symbols
        addTeluguSuggestions();
        addTeluguSimpleNames();

        // Uniconstant physics constants
        addUniconstantSuggestions();

        // Subscript and superscript
        addSubscriptSuperscriptSuggestions();
    }

    /**
     * Add simple-form Greek letter names (alpha, beta, gamma, etc.) for contextual
     * use.
     * These appear after \var( or when symbol was recently used.
     */
    private static void addGreekSimpleNames() {
        String[] greekNames = {
                "alpha", "beta", "gamma", "delta", "epsilon", "zeta", "eta", "theta",
                "iota", "kappa", "lambda", "mu", "nu", "xi", "omicron", "pi",
                "rho", "sigma", "tau", "upsilon", "phi", "chi", "psi", "omega"
        };

        for (String name : greekNames) {
            String lookupKey = "\\var(\\" + name + ")";
            String symbol = Greek.SYMBOL_MAP.get(lookupKey);
            String display = symbol != null ? symbol : name;
            allSuggestions.add(new Suggestion(lookupKey, "Greek letter (simple)", display, "GreekSimple"));
        }
    }

    /**
     * Add simple-form Tamil names for contextual use after \var(\tamil(
     */
    private static void addTamilSimpleNames() {
        // Tamil vowels
        String[] tamilVowels = {
                "a", "aa", "e", "ee", "u", "uu", "ea", "eaa", "i", "o", "oo", "au", "akg"
        };

        for (String vowel : tamilVowels) {
            allSuggestions.add(new Suggestion(vowel, "Tamil vowel (simple)", vowel, "TamilSimple"));
        }

        // Tamil consonants - key names
        String[] tamilConsonants = {
                "ka", "kaa", "ki", "kii", "ik",
                "nga", "ngaa", "ngi",
                "cha", "chaa", "chi",
                "gna", "gnaa", "gni",
                "da", "daa", "di", "id",
                "tha", "thaa", "thi",
                "pa", "paa", "pi", "ip",
                "ma", "maa", "mi",
                "ya", "yaa", "yi",
                "ra", "raa", "ri",
                "la", "laa", "li",
                "va", "vaa", "vi",
                "zha", "zhaa", "zhi",
                "na", "naa",
                "Na", "Naa", "Ni",
                "Nha", "Nhaa", "Nhi",
                "iN", "iNn", "ing", "ina"
        };

        for (String consonant : tamilConsonants) {
            allSuggestions.add(new Suggestion(consonant, "Tamil consonant (simple)", consonant, "TamilSimple"));
        }
    }

    private static void addSanskritSimpleNames() {
        if (Sanskrit.SYMBOL_MAP == null)
            return;
        for (String key : Sanskrit.SYMBOL_MAP.keySet()) {
            String simple = key;
            if (simple.startsWith("\\var(\\sanskrit(")) {
                simple = simple.substring("\\var(\\sanskrit(".length());
                if (simple.endsWith(")")) {
                    simple = simple.substring(0, simple.length() - 1);
                }
                if (simple.endsWith("))")) {
                    simple = simple.substring(0, simple.length() - 2);
                }
            }
            if (simple.startsWith("\\")) {
                simple = simple.substring(1);
            }
            if (!simple.isBlank()) {
                allSuggestions.add(new Suggestion(simple, "Sanskrit simple", simple, "SanskritSimple"));
            }
        }
    }

    private static void addSanskritSuggestions() {
        if (Sanskrit.SYMBOL_MAP != null) {
            Sanskrit.SYMBOL_MAP.forEach(
                    (code, symbol) -> allSuggestions.add(new Suggestion(code, "Sanskrit symbol", symbol, "Sanskrit")));
        }
    }

    /**
     * Add Greek symbol suggestions from Greek.SYMBOL_MAP
     */
    private static void addGreekSuggestions() {
        if (Greek.SYMBOL_MAP != null) {
            Greek.SYMBOL_MAP.forEach(
                    (code, symbol) -> allSuggestions.add(new Suggestion(code, "Greek letter", symbol, "Greek")));
        }
    }

    /**
     * Add Tamil vowel and consonant suggestions from Tamil.TAMIL_VOWEL_MAP and
     * TAMIL_CONSONANT_MAP
     */
    private static void addTamilSuggestions() {
        if (Tamil.TAMIL_VOWEL_MAP != null) {
            Tamil.TAMIL_VOWEL_MAP.forEach(
                    (code, symbol) -> allSuggestions.add(new Suggestion(code, "Tamil vowel", symbol, "Tamil")));
        }

        if (Tamil.TAMIL_CONSONANT_MAP != null) {
            Tamil.TAMIL_CONSONANT_MAP.forEach(
                    (code, symbol) -> allSuggestions.add(new Suggestion(code, "Tamil consonant", symbol, "Tamil")));
        }
    }

    /**
     * Add Malayalam vowel and consonant suggestions from
     * Malayalam.MALAYALAM_VOWEL_MAP and
     * MALAYALAM_CONSONANT_MAP
     */
    private static void addMalayalamSuggestions() {
        if (Malayalam.MALAYALAM_VOWEL_MAP != null) {
            Malayalam.MALAYALAM_VOWEL_MAP.forEach(
                    (code, symbol) -> allSuggestions.add(new Suggestion(code, "Malayalam vowel", symbol, "Malayalam")));
        }

        if (Malayalam.MALAYALAM_CONSONANT_MAP != null) {
            Malayalam.MALAYALAM_CONSONANT_MAP.forEach(
                    (code, symbol) -> allSuggestions
                            .add(new Suggestion(code, "Malayalam consonant", symbol, "Malayalam")));
        }
    }

    private static void addMalayalamSimpleNames() {
        if (Malayalam.MALAYALAM_VOWEL_MAP != null) {
            for (String code : Malayalam.MALAYALAM_VOWEL_MAP.keySet()) {
                String simple = code;
                if (simple.startsWith("\\var(\\malayalam(")) {
                    simple = simple.substring("\\var(\\malayalam(".length());
                    if (simple.endsWith("))")) {
                        simple = simple.substring(0, simple.length() - 2);
                    } else if (simple.endsWith(")")) {
                        simple = simple.substring(0, simple.length() - 1);
                    }
                }
                if (simple.startsWith("\\")) {
                    simple = simple.substring(1);
                }
                if (!simple.isBlank()) {
                    allSuggestions.add(new Suggestion(simple, "Malayalam vowel (simple)", simple, "MalayalamSimple"));
                }
            }
        }

        if (Malayalam.MALAYALAM_CONSONANT_MAP != null) {
            for (String code : Malayalam.MALAYALAM_CONSONANT_MAP.keySet()) {
                String simple = code;
                if (simple.startsWith("\\var(\\malayalam(")) {
                    simple = simple.substring("\\var(\\malayalam(".length());
                    if (simple.endsWith("))")) {
                        simple = simple.substring(0, simple.length() - 2);
                    } else if (simple.endsWith(")")) {
                        simple = simple.substring(0, simple.length() - 1);
                    }
                }
                if (simple.startsWith("\\")) {
                    simple = simple.substring(1);
                }
                if (!simple.isBlank()) {
                    allSuggestions
                            .add(new Suggestion(simple, "Malayalam consonant (simple)", simple, "MalayalamSimple"));
                }
            }
        }
    }

    private static void addTeluguSuggestions() {
        if (Telugu.TELUGU_VOWEL_MAP != null) {
            Telugu.TELUGU_VOWEL_MAP.forEach(
                    (code, symbol) -> allSuggestions.add(new Suggestion(code, "Telugu vowel", symbol, "Telugu")));
        }

        if (Telugu.TELUGU_CONSONANT_MAP != null) {
            Telugu.TELUGU_CONSONANT_MAP.forEach(
                    (code, symbol) -> allSuggestions.add(new Suggestion(code, "Telugu consonant", symbol, "Telugu")));
        }
    }

    private static void addTeluguSimpleNames() {
        if (Telugu.TELUGU_VOWEL_MAP != null) {
            for (String code : Telugu.TELUGU_VOWEL_MAP.keySet()) {
                String simple = code;
                if (simple.startsWith("\\var(\\telugu(")) {
                    simple = simple.substring("\\var(\\telugu(".length());
                    if (simple.endsWith("))")) {
                        simple = simple.substring(0, simple.length() - 2);
                    } else if (simple.endsWith(")")) {
                        simple = simple.substring(0, simple.length() - 1);
                    }
                }
                if (simple.startsWith("\\")) {
                    simple = simple.substring(1);
                }
                if (!simple.isBlank()) {
                    allSuggestions.add(new Suggestion(simple, "Telugu vowel (simple)", simple, "TeluguSimple"));
                }
            }
        }

        if (Telugu.TELUGU_CONSONANT_MAP != null) {
            for (String code : Telugu.TELUGU_CONSONANT_MAP.keySet()) {
                String simple = code;
                if (simple.startsWith("\\var(\\telugu(")) {
                    simple = simple.substring("\\var(\\telugu(".length());
                    if (simple.endsWith("))")) {
                        simple = simple.substring(0, simple.length() - 2);
                    } else if (simple.endsWith(")")) {
                        simple = simple.substring(0, simple.length() - 1);
                    }
                }
                if (simple.startsWith("\\")) {
                    simple = simple.substring(1);
                }
                if (!simple.isBlank()) {
                    allSuggestions.add(new Suggestion(simple, "Telugu consonant (simple)", simple, "TeluguSimple"));
                }
            }
        }
    }

    /**
     * Add physics constant suggestions from Uniconstant.SYMBOL_MAP
     */
    private static void addUniconstantSuggestions() {
        if (Uniconstant.SYMBOL_MAP != null) {
            Uniconstant.SYMBOL_MAP.forEach((code, symbol) -> {
                // code is in format: \con(\pi), \con(\gravity), etc.
                // Store full format so when selected, it inserts complete code
                allSuggestions.add(new Suggestion(
                        code, // Full format: "\con(\pi)" for insertion
                        "Physics constant",
                        symbol, // Unicode symbol display: 𝝅, 𝒈, etc.
                        "Uniconstant"));
            });
        }
    }

    /**
     * Add subscript and superscript suggestions from Subscript and Superscript maps
     */
    private static void addSubscriptSuperscriptSuggestions() {
        for (char ch = '0'; ch <= '9'; ch++) {
            if (Superscript.hasUnicode(ch)) {
                allSuggestions.add(new Suggestion("^" + ch, "Superscript " + ch, Superscript.unicode(ch), "Math"));
            }
            if (Subscript.hasNumericSubscript(ch)) {
                allSuggestions.add(new Suggestion("_" + ch, "Subscript " + ch, Subscript.numericSubscript(ch), "Math"));
            }
        }
    }

    /**
     * Extract variable names from the code and add them as suggestions.
     * Looks for patterns like: var x = 5, let name = "test", const value = ...
     * Also handles type-declared variables: int x, String str, etc.
     * Also handles bare assignments: sample = 30, myVar = "hello", etc.
     * 
     * @param text the full code text
     */
    public static void updateVariablesFromText(String text) {
        discoveredVariables.clear();
        discoveredStyledVariables.clear();

        if (text == null || text.isEmpty())
            return;

        Set<String> styledBaseNames = new HashSet<>();

        // Pattern 0: Styled variable assignments with optional superscript.
        // Matches: v_{x} = 1, v_{x}^{2} = 1
        String styledPattern = "\\b([a-zA-Z_][a-zA-Z0-9_]*)(?:__|_)\\{([^}]+)\\}(\\^\\{([^}]+)\\})?\\s*=";
        java.util.regex.Pattern styled = java.util.regex.Pattern.compile(styledPattern);
        java.util.regex.Matcher styledMatcher = styled.matcher(text);
        while (styledMatcher.find()) {
            String base = styledMatcher.group(1);
            String sub = styledMatcher.group(2);
            String sup = styledMatcher.group(4);

            String raw = base + "__{" + sub + "}";
            String display = base + "[SUB:" + sub + "]";
            if (sup != null && !sup.isEmpty()) {
                raw += "^{" + sup + "}";
                display += "[SUP:" + sup + "]";
            }

            styledBaseNames.add(base);
            discoveredStyledVariables.put(raw, display);
        }

        // Pattern 0b: Superscript-only styled variable assignments.
        // Matches: x^{2} = 9
        String supOnlyPattern = "\\b([a-zA-Z_][a-zA-Z0-9_]*)\\^\\{([^}]+)\\}\\s*=";
        java.util.regex.Pattern supOnly = java.util.regex.Pattern.compile(supOnlyPattern);
        java.util.regex.Matcher supOnlyMatcher = supOnly.matcher(text);
        while (supOnlyMatcher.find()) {
            String base = supOnlyMatcher.group(1);
            String sup = supOnlyMatcher.group(2);

            String raw = base + "^{" + sup + "}";
            String display = base + "[SUP:" + sup + "]";

            styledBaseNames.add(base);
            discoveredStyledVariables.put(raw, display);
        }

        // Pattern 0c: Variables already converted by live replacement engine.
        // Subscript group markers use U+200D (ZWJ), superscript groups use U+200C
        // (ZWNJ).
        // Matches base plus optional marker groups produced by live replacement.
        String liveStyledPattern = "\\b([a-zA-Z_][a-zA-Z0-9_]*)(?:\\u200D{1,3}([^\\u200D\\n\\r=]+)\\u200D{1,3})?(?:\\u200C{3}([^\\u200C\\n\\r=]+)\\u200C{3})?\\s*=";
        java.util.regex.Pattern liveStyled = java.util.regex.Pattern.compile(liveStyledPattern);
        java.util.regex.Matcher liveStyledMatcher = liveStyled.matcher(text);
        while (liveStyledMatcher.find()) {
            String base = liveStyledMatcher.group(1);
            String sub = liveStyledMatcher.group(2);
            String sup = liveStyledMatcher.group(3);

            boolean hasSub = sub != null && !sub.isBlank();
            boolean hasSup = sup != null && !sup.isBlank();
            if (!hasSub && !hasSup) {
                continue;
            }

            String raw = base;
            String display = base;

            if (hasSub) {
                raw += "__{" + sub + "}";
                display += "[SUB:" + sub + "]";
            }
            if (hasSup) {
                raw += "^{" + sup + "}";
                display += "[SUP:" + sup + "]";
            }

            styledBaseNames.add(base);
            discoveredStyledVariables.put(raw, display);
        }

        // Pattern 1: var/let/const name = ...
        // Matches: var x = 5, let sample = 30, const PI = 3.14
        String pattern1 = "\\b(var|let|const)\\s+([a-zA-Z_][a-zA-Z0-9_]*)\\s*=";
        java.util.regex.Pattern p1 = java.util.regex.Pattern.compile(pattern1);
        java.util.regex.Matcher m1 = p1.matcher(text);
        while (m1.find()) {
            String varName = m1.group(2);
            if (!styledBaseNames.contains(varName)) {
                discoveredVariables.add(varName);
            }
        }

        // Pattern 2: Type-declared variables like: int x, String name, etc.
        // Matches: int x = 5, String str = "hello", float num;
        String pattern2 = "\\b([a-zA-Z_][a-zA-Z0-9_]*)\\s+([a-zA-Z_][a-zA-Z0-9_]*)\\s*[=;]";
        java.util.regex.Pattern p2 = java.util.regex.Pattern.compile(pattern2);
        java.util.regex.Matcher m2 = p2.matcher(text);
        while (m2.find()) {
            String type = m2.group(1);
            String varName = m2.group(2);
            // Avoid common keywords and variable types
            if (!isKeywordOrType(type) && !isKeywordOrType(varName) && !styledBaseNames.contains(varName)) {
                discoveredVariables.add(varName);
            }
        }

        // Pattern 3: Bare variable assignments (no var/let/const keyword)
        // Matches: sample = 30, myVar = "test", x=5
        String pattern3 = "\\b([a-zA-Z_][a-zA-Z0-9_]*)\\s*=";
        java.util.regex.Pattern p3 = java.util.regex.Pattern.compile(pattern3);
        java.util.regex.Matcher m3 = p3.matcher(text);
        while (m3.find()) {
            String varName = m3.group(1);
            // Only add if not a keyword and not already added
            if (!isKeywordOrType(varName) && !styledBaseNames.contains(varName)) {
                discoveredVariables.add(varName);
            }
        }

        // Pattern 4: Function/method definitions
        // Matches: function myFunc, myFunc() { }, void doSomething()
        String pattern4 = "\\bfunction\\s+([a-zA-Z_][a-zA-Z0-9_]*)\\s*\\(";
        java.util.regex.Pattern p4 = java.util.regex.Pattern.compile(pattern4);
        java.util.regex.Matcher m4 = p4.matcher(text);
        while (m4.find()) {
            String funcName = m4.group(1);
            discoveredVariables.add(funcName);
        }
    }

    /**
     * Check if a string is a common keyword or type name.
     */
    private static boolean isKeywordOrType(String word) {
        Set<String> keywordsAndTypes = new HashSet<>(Arrays.asList(
                "var", "let", "const", "int", "float", "double", "String", "boolean",
                "List", "Map", "Set", "Array", "Object", "function", "class", "if",
                "else", "for", "while", "return", "break", "continue", "true", "false",
                "null", "void", "static", "public", "private", "protected", "new"));
        return keywordsAndTypes.contains(word);
    }

    /**
     * Detect the current context from the full text and cursor position.
     * Looks backwards from the end to find \var( or \var(\tamil(
     * 
     * @param text the full code text
     * @return the detected context
     */
    private static SuggestionContext detectContext(String text) {
        if (text == null || text.isEmpty()) {
            return SuggestionContext.GENERAL;
        }

        int lastSubscriptMode = text.lastIndexOf("__");
        int lastSuperscriptMode = text.lastIndexOf("^^");
        if (lastSubscriptMode != -1 || lastSuperscriptMode != -1) {
            int markerIndex = Math.max(lastSubscriptMode, lastSuperscriptMode);
            String tail = text.substring(markerIndex + 2);
            // Accept unicode letters too, so sub/sup mode keeps context after
            // Greek/Tamil live replacement updates the raw token.
            if (tail.matches("[\\\\p{L}\\\\p{N}_\\\\\\\\()]*")) {
                return lastSubscriptMode > lastSuperscriptMode
                        ? SuggestionContext.SUBSCRIPT
                        : SuggestionContext.SUPERSCRIPT;
            }
        }

        // Check for \con(\ context (physics constants)
        int lastUniconIdx = text.lastIndexOf("\\con(\\");
        if (lastUniconIdx != -1) {
            int closeParenIdx = text.indexOf(")", lastUniconIdx);
            if (closeParenIdx == -1) {
                // We're inside \con(\...), show constant suggestions
                return SuggestionContext.UNICONSTANT;
            }
        }

        // Find the last unclosed \var( or \var(\tamil(
        int lastVarIdx = text.lastIndexOf("\\var(");
        if (lastVarIdx == -1) {
            return SuggestionContext.GENERAL;
        }

        // Check if there's a closing ) after the last \var(
        int closeParenIdx = text.indexOf(")", lastVarIdx);

        // If no closing paren, we're still inside \var(
        if (closeParenIdx == -1) {
            // Check if \tamil( exists after \var(
            int tamilIdx = text.indexOf("\\tamil(", lastVarIdx);
            int sanskritIdx = text.indexOf("\\sanskrit(", lastVarIdx);
            int hindiIdx = text.indexOf("\\hindi(", lastVarIdx);
            int teluguIdx = text.indexOf("\\telugu(", lastVarIdx);
            int malayalamIdx = text.indexOf("\\malayalam(", lastVarIdx);
            if (tamilIdx != -1) {
                int closeTamilParen = text.indexOf(")", tamilIdx);
                if (closeTamilParen == -1) {
                    return SuggestionContext.TAMIL;
                }
            }
            if (sanskritIdx != -1) {
                int closeSanskritParen = text.indexOf(")", sanskritIdx);
                if (closeSanskritParen == -1) {
                    return SuggestionContext.SANSKRIT;
                }
            }
            if (hindiIdx != -1) {
                int closeHindiParen = text.indexOf(")", hindiIdx);
                if (closeHindiParen == -1) {
                    return SuggestionContext.HINDI;
                }
            }
            if (teluguIdx != -1) {
                int closeTeluguParen = text.indexOf(")", teluguIdx);
                if (closeTeluguParen == -1) {
                    return SuggestionContext.TELUGU;
                }
            }
            if (malayalamIdx != -1) {
                int closeMalayalamParen = text.indexOf(")", malayalamIdx);
                if (closeMalayalamParen == -1) {
                    return SuggestionContext.MALAYALAM;
                }
            }
            return SuggestionContext.GREEK;
        }

        // Check if \tamil( is between the \var( and )
        int tamilIdx = text.indexOf("\\tamil(", lastVarIdx);
        int sanskritIdx = text.indexOf("\\sanskrit(", lastVarIdx);
        int hindiIdx = text.indexOf("\\hindi(", lastVarIdx);
        int teluguIdx = text.indexOf("\\telugu(", lastVarIdx);
        int malayalamIdx = text.indexOf("\\malayalam(", lastVarIdx);
        if (tamilIdx != -1 && tamilIdx < closeParenIdx) {
            int closeTamilParen = text.indexOf(")", tamilIdx);
            if (closeTamilParen == -1 || closeTamilParen > closeParenIdx) {
                return SuggestionContext.TAMIL;
            }
        }
        if (sanskritIdx != -1 && sanskritIdx < closeParenIdx) {
            int closeSanskritParen = text.indexOf(")", sanskritIdx);
            if (closeSanskritParen == -1 || closeSanskritParen > closeParenIdx) {
                return SuggestionContext.SANSKRIT;
            }
        }
        if (hindiIdx != -1 && hindiIdx < closeParenIdx) {
            int closeHindiParen = text.indexOf(")", hindiIdx);
            if (closeHindiParen == -1 || closeHindiParen > closeParenIdx) {
                return SuggestionContext.HINDI;
            }
        }
        if (teluguIdx != -1 && teluguIdx < closeParenIdx) {
            int closeTeluguParen = text.indexOf(")", teluguIdx);
            if (closeTeluguParen == -1 || closeTeluguParen > closeParenIdx) {
                return SuggestionContext.TELUGU;
            }
        }
        if (malayalamIdx != -1 && malayalamIdx < closeParenIdx) {
            int closeMalayalamParen = text.indexOf(")", malayalamIdx);
            if (closeMalayalamParen == -1 || closeMalayalamParen > closeParenIdx) {
                return SuggestionContext.MALAYALAM;
            }
        }

        return SuggestionContext.GENERAL;
    }

    /**
     * Get suggestions matching the current input, filtered by context.
     * 
     * @param input    the current text being typed
     * @param fullText the full code text for context detection
     * @return list of matching suggestions sorted by relevance
     */
    public static List<Suggestion> getSuggestionsFiltered(String input, String fullText) {
        SuggestionContext context = detectContext(fullText);

        if (input == null) {
            return new ArrayList<>();
        }

        if (input.startsWith("\\")) {
            if (context == SuggestionContext.GENERAL) {
                return getBackslashCommandSuggestions(input);
            }
            String normalizedInput = normalizeSuggestionInput(input);
            return getSuggestionsWithContext(normalizedInput, context);
        }

        String normalizedInput = normalizeSuggestionInput(input);
        if (normalizedInput.isEmpty()) {
            if (context == SuggestionContext.GREEK || context == SuggestionContext.TAMIL
                    || context == SuggestionContext.SANSKRIT
                    || context == SuggestionContext.HINDI || context == SuggestionContext.TELUGU
                    || context == SuggestionContext.MALAYALAM
                    || context == SuggestionContext.UNICONSTANT) {
                return getSuggestionsWithContext("", context);
            }
            return new ArrayList<>();
        }

        return getSuggestionsWithContext(normalizedInput, context);
    }

    private static List<Suggestion> getBackslashCommandSuggestions(String input) {
        String prefix = input == null ? "" : input.substring(1).toLowerCase();
        List<Suggestion> results = new ArrayList<>();

        if (prefix.isEmpty() || prefix.startsWith("v")) {
            results.add(new Suggestion("\\var(", "Start variable symbol context", "\\var(", "SpecialCommand"));
        }
        if (prefix.isEmpty() || prefix.startsWith("c")) {
            results.add(new Suggestion("\\con(", "Start physics constant context", "\\con(", "SpecialCommand"));
        }

        return results;
    }

    private static String normalizeSuggestionInput(String input) {
        String normalized = input.trim().toLowerCase();
        // Strip leading backslash (from patterns like \con(\)
        if (normalized.startsWith("\\")) {
            normalized = normalized.substring(1);
        }
        while (!normalized.isEmpty()) {
            char last = normalized.charAt(normalized.length() - 1);
            if (last == '_' || last == '^') {
                normalized = normalized.substring(0, normalized.length() - 1);
            } else {
                break;
            }
        }
        return normalized;
    }

    /**
     * Get suggestions for a specific context.
     * 
     * @param input   the current text being typed
     * @param context the detected context (GREEK, TAMIL, SANSKRIT, or GENERAL)
     * @return list of matching suggestions sorted by relevance
     */
    private static List<Suggestion> getSuggestionsWithContext(String input, SuggestionContext context) {
        String lowerInput = input.toLowerCase();
        List<Suggestion> results = new ArrayList<>();
        List<Suggestion> styledVariableSuggestions = new ArrayList<>();
        List<Suggestion> variableSuggestions = new ArrayList<>();
        List<Suggestion> functionSuggestions = new ArrayList<>();
        List<Suggestion> symbolSuggestions = new ArrayList<>(); // For actual symbols (Greek/Tamil/Sanskrit/Hindi with
                                                                // Unicode)
        List<Suggestion> otherSuggestions = new ArrayList<>();

        // Filter suggestions based on context
        for (Suggestion s : allSuggestions) {
            boolean matchesCode = false;
            boolean matchesDisplay = false;

            // For Uniconstant, extract token for matching (e.g., "pi" from "\con(\pi)")
            if ("Uniconstant".equals(s.getCategory()) && s.getCode().startsWith("\\con(\\")) {
                String token = s.getCode().substring("\\con(\\".length(), s.getCode().length() - 1);
                matchesCode = token.toLowerCase().contains(lowerInput);
            } else {
                matchesCode = s.getCode().toLowerCase().contains(lowerInput);
            }

            matchesDisplay = s.getDisplay() != null
                    && s.getDisplay().toLowerCase().contains(lowerInput);
            if (!matchesCode && !matchesDisplay)
                continue;

            switch (context) {
                case GREEK:
                    // Prioritize actual Greek symbols (Greek category) over simple names
                    // (GreekSimple)
                    if ("Greek".equals(s.getCategory())) {
                        symbolSuggestions.add(s);
                    } else if ("GreekSimple".equals(s.getCategory())) {
                        otherSuggestions.add(s);
                    }
                    break;

                case TAMIL:
                case SANSKRIT:
                case HINDI:
                case TELUGU:
                case MALAYALAM:
                    // Prioritize actual script symbols over simple names.
                    if ((context == SuggestionContext.TAMIL && "Tamil".equals(s.getCategory()))
                            || (context == SuggestionContext.SANSKRIT && "Sanskrit".equals(s.getCategory()))
                            || (context == SuggestionContext.HINDI && "Hindi".equals(s.getCategory()))
                            || (context == SuggestionContext.TELUGU && "Telugu".equals(s.getCategory()))
                            || (context == SuggestionContext.MALAYALAM && "Malayalam".equals(s.getCategory()))) {
                        symbolSuggestions.add(s);
                    } else if ((context == SuggestionContext.TAMIL && "TamilSimple".equals(s.getCategory()))
                            || (context == SuggestionContext.SANSKRIT && "SanskritSimple".equals(s.getCategory()))
                            || (context == SuggestionContext.HINDI && "HindiSimple".equals(s.getCategory()))
                            || (context == SuggestionContext.TELUGU && "TeluguSimple".equals(s.getCategory()))
                            || (context == SuggestionContext.MALAYALAM && "MalayalamSimple".equals(s.getCategory()))) {
                        otherSuggestions.add(s);
                    }
                    break;

                case SUBSCRIPT:
                case SUPERSCRIPT:
                    if ("Greek".equals(s.getCategory()) || "GreekSimple".equals(s.getCategory())
                            || "Tamil".equals(s.getCategory()) || "TamilSimple".equals(s.getCategory())
                            || "Math".equals(s.getCategory())) {
                        symbolSuggestions.add(s);
                    } else {
                        // Keep normal editor suggestions available in sub/sup mode as well.
                        otherSuggestions.add(s);
                    }
                    break;

                case UNICONSTANT:
                    // Show physics constants suggestions
                    if ("Uniconstant".equals(s.getCategory())) {
                        symbolSuggestions.add(s);
                    }
                    break;

                case GENERAL:
                default:
                    // Include all matching suggestions except special symbol contexts
                    // (since GENERAL means we're not in \var(...) or \con(...) context)
                    if (!"GreekSimple".equals(s.getCategory()) &&
                            !"Greek".equals(s.getCategory()) &&
                            !"TamilSimple".equals(s.getCategory()) &&
                            !"Tamil".equals(s.getCategory()) &&
                            !"SanskritSimple".equals(s.getCategory()) &&
                            !"Sanskrit".equals(s.getCategory()) &&
                            !"TeluguSimple".equals(s.getCategory()) &&
                            !"Telugu".equals(s.getCategory()) &&
                            !"MalayalamSimple".equals(s.getCategory()) &&
                            !"Malayalam".equals(s.getCategory()) &&
                            !"Uniconstant".equals(s.getCategory())) {
                        otherSuggestions.add(s);
                    }
            }
        }

        // In non-symbol-only contexts, add discovered variables/functions with
        // priority.
        // This keeps normal editor completion behavior active in SUBSCRIPT/SUPERSCRIPT
        // modes too.
        if (context == SuggestionContext.GENERAL
                || context == SuggestionContext.SUBSCRIPT
                || context == SuggestionContext.SUPERSCRIPT) {
            for (Map.Entry<String, String> entry : discoveredStyledVariables.entrySet()) {
                String raw = entry.getKey();
                String display = entry.getValue();
                if (raw.toLowerCase().contains(lowerInput) || display.toLowerCase().contains(lowerInput)) {
                    styledVariableSuggestions.add(new Suggestion(raw, "Styled variable", display, "StyledVariable"));
                }
            }

            for (String varName : discoveredVariables) {
                if (varName.toLowerCase().contains(lowerInput)) {
                    variableSuggestions.add(new Suggestion(varName, "Variable", varName, "Variable"));
                }
            }

            // Add recently used symbols with high priority (suggest full correct format)
            for (Map.Entry<String, String> entry : recentlyUsedSymbols.entrySet()) {
                String simpleName = entry.getKey();
                String fullFormat = entry.getValue();
                if (!fullFormat.startsWith("\\var(")) {
                    continue;
                }
                if (simpleName.toLowerCase().contains(lowerInput)) {
                    // Get the pre-computed symbol character display
                    String symbolDisplay = recentlyUsedSymbolDisplays.getOrDefault(simpleName, simpleName);
                    // Show the actual symbol as display, but use full format as code
                    variableSuggestions.add(new Suggestion(fullFormat, "Recently Used", symbolDisplay, "Variable"));
                }
            }

            // Add matching functions from FunctionProvider (alphabetically sorted)
            List<String> matchingFunctions = FunctionProvider.getFilteredFunctions(input);
            for (String funcKey : matchingFunctions) {
                String description = FunctionProvider.getFunctionDescription(funcKey);
                String displayName = FunctionProvider.getFunctionDisplayName(funcKey);
                // Create suggestion with: code=key (for insertion), display=displayName (for
                // UI)
                functionSuggestions.add(new Suggestion(funcKey, description, displayName, "Function"));
            }
        }

        // When actual script symbols are available, hide duplicate simple-name
        // fallbacks.
        if (!symbolSuggestions.isEmpty()) {
            if (context == SuggestionContext.GREEK) {
                otherSuggestions.removeIf(s -> "GreekSimple".equals(s.getCategory()));
            } else if (context == SuggestionContext.TAMIL) {
                otherSuggestions.removeIf(s -> "TamilSimple".equals(s.getCategory()));
            } else if (context == SuggestionContext.SANSKRIT) {
                otherSuggestions.removeIf(s -> "SanskritSimple".equals(s.getCategory()));
            } else if (context == SuggestionContext.TELUGU) {
                otherSuggestions.removeIf(s -> "TeluguSimple".equals(s.getCategory()));
            } else if (context == SuggestionContext.MALAYALAM) {
                otherSuggestions.removeIf(s -> "MalayalamSimple".equals(s.getCategory()));
            }
        }

        // Assemble results by context.
        switch (context) {
            case GREEK:
            case TAMIL:
            case SANSKRIT:
            case TELUGU:
            case MALAYALAM:
                // Symbol contexts: actual symbols first, then simple-name fallbacks.
                results.addAll(symbolSuggestions);
                results.addAll(otherSuggestions);
                break;

            case UNICONSTANT:
                // Physics constants context: show constant suggestions
                results.addAll(symbolSuggestions);
                break;

            case SUBSCRIPT:
            case SUPERSCRIPT:
                // Mirror GENERAL logic first, then append symbol-focused completions.
                results.addAll(styledVariableSuggestions);
                results.addAll(variableSuggestions);
                results.addAll(functionSuggestions);
                results.addAll(symbolSuggestions);
                results.addAll(otherSuggestions);
                break;

            case GENERAL:
            default:
                results.addAll(styledVariableSuggestions);
                results.addAll(variableSuggestions);
                results.addAll(functionSuggestions);
                results.addAll(otherSuggestions);
                break;
        }

        // Sort within each priority by relevance
        if (context != SuggestionContext.GENERAL) {
            // Non-GENERAL contexts: sort by standard rules
            results.sort((a, b) -> {
                // For Uniconstant, extract token for prefix matching
                String aCodeForMatch = a.getCode();
                String bCodeForMatch = b.getCode();
                if ("Uniconstant".equals(a.getCategory()) && a.getCode().startsWith("\\con(\\")) {
                    aCodeForMatch = a.getCode().substring("\\con(\\".length(), a.getCode().length() - 1);
                }
                if ("Uniconstant".equals(b.getCategory()) && b.getCode().startsWith("\\con(\\")) {
                    bCodeForMatch = b.getCode().substring("\\con(\\".length(), b.getCode().length() - 1);
                }

                // Prioritize exact prefix matches
                boolean aPrefix = aCodeForMatch.toLowerCase().startsWith(lowerInput);
                boolean bPrefix = bCodeForMatch.toLowerCase().startsWith(lowerInput);
                if (aPrefix != bPrefix)
                    return aPrefix ? -1 : 1;

                // Prioritize GreekSimple and TamilSimple in appropriate contexts
                int catPriority = getCategoryPriority(a.getCategory()) - getCategoryPriority(b.getCategory());
                if (catPriority != 0)
                    return catPriority;

                // Finally by code length (shorter first)
                return Integer.compare(aCodeForMatch.length(), bCodeForMatch.length());
            });
        }

        return results.stream().limit(15).collect(Collectors.toList());
    }

    /**
     * Convert a symbol name to its actual Unicode character.
     * Examples: "alpha" → "α", "kaa" → "கా", "mu" → "μ"
     * 
     * @param symbolName the simple name (e.g., "alpha", "mu", "kaa", "i")
     * @return the actual Unicode symbol, or the original name if not found
     */
    public static String getSymbolCharacter(String symbolName) {
        if (symbolName == null || symbolName.isEmpty()) {
            return symbolName;
        }

        String lowerName = symbolName.toLowerCase().trim();

        // Try to find in native Greek map by constructing full key format
        if (Greek.SYMBOL_MAP != null) {
            // Try exact match with full format keys
            String[] possibleKeys = {
                    "\\" + lowerName,
                    "\\var(\\" + lowerName + ")",
                    "\\" + symbolName
            };

            for (String key : possibleKeys) {
                if (Greek.SYMBOL_MAP.containsKey(key)) {
                    return Greek.SYMBOL_MAP.get(key);
                }
            }

            // Try partial match - search through all keys
            for (Map.Entry<String, String> entry : Greek.SYMBOL_MAP.entrySet()) {
                if (entry.getKey().contains("\\" + lowerName)) {
                    return entry.getValue();
                }
            }
        }

        // Try to find in native Sanskrit map using proper format
        if (Sanskrit.SYMBOL_MAP != null) {
            String[] possibleSanskritKeys = {
                    "\\" + lowerName,
                    "\\var(\\sanskrit(\\" + lowerName + "))",
                    "\\" + symbolName
            };

            for (String key : possibleSanskritKeys) {
                if (Sanskrit.SYMBOL_MAP.containsKey(key)) {
                    return Sanskrit.SYMBOL_MAP.get(key);
                }
            }

            for (Map.Entry<String, String> entry : Sanskrit.SYMBOL_MAP.entrySet()) {
                if (entry.getKey().contains("\\" + lowerName)) {
                    return entry.getValue();
                }
            }
        }

        // Try to find in native Tamil maps using proper format
        if (Tamil.TAMIL_VOWEL_MAP != null) {
            // Try exact match with full format keys
            String[] possibleTamilVowelKeys = {
                    "\\" + lowerName,
                    "\\var(\\tamil(\\" + lowerName + "))",
                    "\\" + symbolName
            };

            for (String key : possibleTamilVowelKeys) {
                if (Tamil.TAMIL_VOWEL_MAP.containsKey(key)) {
                    return Tamil.TAMIL_VOWEL_MAP.get(key);
                }
            }

            // Try partial match - search through all keys
            for (Map.Entry<String, String> entry : Tamil.TAMIL_VOWEL_MAP.entrySet()) {
                if (entry.getKey().contains("\\" + lowerName)) {
                    return entry.getValue();
                }
            }
        }

        if (Tamil.TAMIL_CONSONANT_MAP != null) {
            // Try exact match with full format keys
            String[] possibleTamilConsonantKeys = {
                    "\\" + lowerName,
                    "\\var(\\tamil(\\" + lowerName + "))",
                    "\\" + symbolName
            };

            for (String key : possibleTamilConsonantKeys) {
                if (Tamil.TAMIL_CONSONANT_MAP.containsKey(key)) {
                    return Tamil.TAMIL_CONSONANT_MAP.get(key);
                }
            }

            // Try partial match - search through all keys
            for (Map.Entry<String, String> entry : Tamil.TAMIL_CONSONANT_MAP.entrySet()) {
                if (entry.getKey().contains("\\" + lowerName)) {
                    return entry.getValue();
                }
            }
        }

        if (Malayalam.MALAYALAM_VOWEL_MAP != null) {
            // Try exact match with full format keys
            String[] possibleMalayalamVowelKeys = {
                    "\\" + lowerName,
                    "\\var(\\malayalam(\\" + lowerName + "))",
                    "\\" + symbolName
            };

            for (String key : possibleMalayalamVowelKeys) {
                if (Malayalam.MALAYALAM_VOWEL_MAP.containsKey(key)) {
                    return Malayalam.MALAYALAM_VOWEL_MAP.get(key);
                }
            }

            // Try partial match - search through all keys
            for (Map.Entry<String, String> entry : Malayalam.MALAYALAM_VOWEL_MAP.entrySet()) {
                if (entry.getKey().contains("\\" + lowerName)) {
                    return entry.getValue();
                }
            }
        }

        if (Malayalam.MALAYALAM_CONSONANT_MAP != null) {
            // Try exact match with full format keys
            String[] possibleMalayalamConsonantKeys = {
                    "\\" + lowerName,
                    "\\var(\\malayalam(\\" + lowerName + "))",
                    "\\" + symbolName
            };

            for (String key : possibleMalayalamConsonantKeys) {
                if (Malayalam.MALAYALAM_CONSONANT_MAP.containsKey(key)) {
                    return Malayalam.MALAYALAM_CONSONANT_MAP.get(key);
                }
            }

            // Try partial match - search through all keys
            for (Map.Entry<String, String> entry : Malayalam.MALAYALAM_CONSONANT_MAP.entrySet()) {
                if (entry.getKey().contains("\\" + lowerName)) {
                    return entry.getValue();
                }
            }
        }

        if (Telugu.TELUGU_VOWEL_MAP != null) {
            String[] possibleTeluguVowelKeys = {
                    "\\" + lowerName,
                    "\\var(\\telugu(\\" + lowerName + "))",
                    "\\" + symbolName
            };

            for (String key : possibleTeluguVowelKeys) {
                if (Telugu.TELUGU_VOWEL_MAP.containsKey(key)) {
                    return Telugu.TELUGU_VOWEL_MAP.get(key);
                }
            }

            for (Map.Entry<String, String> entry : Telugu.TELUGU_VOWEL_MAP.entrySet()) {
                if (entry.getKey().contains("\\" + lowerName)) {
                    return entry.getValue();
                }
            }
        }

        if (Telugu.TELUGU_CONSONANT_MAP != null) {
            String[] possibleTeluguConsonantKeys = {
                    "\\" + lowerName,
                    "\\var(\\telugu(\\" + lowerName + "))",
                    "\\" + symbolName
            };

            for (String key : possibleTeluguConsonantKeys) {
                if (Telugu.TELUGU_CONSONANT_MAP.containsKey(key)) {
                    return Telugu.TELUGU_CONSONANT_MAP.get(key);
                }
            }

            for (Map.Entry<String, String> entry : Telugu.TELUGU_CONSONANT_MAP.entrySet()) {
                if (entry.getKey().contains("\\" + lowerName)) {
                    return entry.getValue();
                }
            }
        }

        // Fallback: check allSuggestions for actual symbol categories
        for (Suggestion s : allSuggestions) {
            if ("Greek".equals(s.getCategory()) && s.getCode().equalsIgnoreCase(lowerName)) {
                return s.getDisplay();
            }
        }

        for (Suggestion s : allSuggestions) {
            if ("Tamil".equals(s.getCategory()) && s.getCode().equalsIgnoreCase(lowerName)) {
                return s.getDisplay();
            }
        }

        // Not found, return original name
        return symbolName;
    }

    /**
     * Examples: \var(\alpha) → alpha, \var(\tamil(\i)) → i
     * 
     * @param symbolCode the full symbol code
     * @return the simple name, or the original code if not a symbol format
     */
    private static String extractSimpleSymbolName(String symbolCode) {
        if (symbolCode == null || symbolCode.isEmpty()) {
            return symbolCode;
        }

        // For Greek: \var(\alpha) → alpha
        if (symbolCode.startsWith("\\var(\\") && symbolCode.endsWith(")")) {
            String extracted = symbolCode.substring(5); // Remove \var(
            if (extracted.endsWith(")")) {
                extracted = extracted.substring(0, extracted.length() - 1); // Remove )
            }
            if (extracted.startsWith("\\")) {
                extracted = extracted.substring(1); // Remove leading \
            }
            return extracted;
        }

        // For Tamil: \var(\tamil(\i)) → i
        if (symbolCode.startsWith("\\var(\\tamil(") && symbolCode.endsWith("))")) {
            String extracted = symbolCode.substring(12); // Remove \var(\tamil(
            if (extracted.endsWith("))")) {
                extracted = extracted.substring(0, extracted.length() - 2); // Remove ))
            } else if (extracted.endsWith(")")) {
                extracted = extracted.substring(0, extracted.length() - 1); // Remove )
            }
            if (extracted.startsWith("\\")) {
                extracted = extracted.substring(1); // Remove leading \
            }
            return extracted;
        }

        // For Sanskrit: \var(\sanskrit(\a)) → a
        if (symbolCode.startsWith("\\var(\\sanskrit(") && symbolCode.endsWith("))")) {
            String extracted = symbolCode.substring("\\var(\\sanskrit(".length());
            if (extracted.endsWith("))")) {
                extracted = extracted.substring(0, extracted.length() - 2);
            } else if (extracted.endsWith(")")) {
                extracted = extracted.substring(0, extracted.length() - 1);
            }
            if (extracted.startsWith("\\")) {
                extracted = extracted.substring(1);
            }
            return extracted;
        }

        // For Malayalam: \var(\malayalam(\a)) → a
        if (symbolCode.startsWith("\\var(\\malayalam(") && symbolCode.endsWith("))")) {
            String extracted = symbolCode.substring("\\var(\\malayalam(".length());
            if (extracted.endsWith("))")) {
                extracted = extracted.substring(0, extracted.length() - 2);
            } else if (extracted.endsWith(")")) {
                extracted = extracted.substring(0, extracted.length() - 1);
            }
            if (extracted.startsWith("\\")) {
                extracted = extracted.substring(1);
            }
            return extracted;
        }

        // For Telugu: \var(\telugu(\a)) → a
        if (symbolCode.startsWith("\\var(\\telugu(") && symbolCode.endsWith("))")) {
            String extracted = symbolCode.substring("\\var(\\telugu(".length());
            if (extracted.endsWith("))")) {
                extracted = extracted.substring(0, extracted.length() - 2);
            } else if (extracted.endsWith(")")) {
                extracted = extracted.substring(0, extracted.length() - 1);
            }
            if (extracted.startsWith("\\")) {
                extracted = extracted.substring(1);
            }
            return extracted;
        }

        // For Uniconstant: \con(\pi) → pi
        // Return original if not a recognized symbol format
        return symbolCode;
    }

    /**
     * Add a symbol to the recently used set.
     * Stores the mapping from simple name → full format and symbol character.
     * This allows suggesting the full correct syntax on subsequent uses.
     * 
     * @param symbolCode the symbol code (can be full format like \var(\alpha) or
     *                   simple like alpha)
     */
    public static void addRecentlyUsedSymbol(String symbolCode) {
        if (symbolCode != null && !symbolCode.trim().isEmpty()) {
            String fullFormat = symbolCode.trim();

            // Keep this cache dedicated to actual symbol shortcuts only.
            // Styled variables like name_{sub} should not appear as raw fallback entries.
            if (!fullFormat.startsWith("\\var(")) {
                return;
            }

            String simpleName = extractSimpleSymbolName(fullFormat);

            // Store mapping: simple name → full format
            recentlyUsedSymbols.put(simpleName.toLowerCase(), fullFormat);

            // Also store the actual symbol character for display
            String symbolDisplay = getSymbolCharacter(simpleName);
            recentlyUsedSymbolDisplays.put(simpleName.toLowerCase(), symbolDisplay);

            // Keep only last 20 recently used
            if (recentlyUsedSymbols.size() > 20) {
                String keyToRemove = recentlyUsedSymbols.keySet().iterator().next();
                recentlyUsedSymbols.remove(keyToRemove);
                recentlyUsedSymbolDisplays.remove(keyToRemove);
            }
        }
    }

    /**
     * Get suggestions matching the current input.
     * 
     * @param input the current text being typed (e.g., "\var" or "\v")
     * @return list of matching suggestions sorted by relevance
     */
    public static List<Suggestion> getSuggestions(String input) {
        if (input == null || input.trim().isEmpty()) {
            return new ArrayList<>();
        }

        String lowerInput = input.toLowerCase();
        List<Suggestion> results = new ArrayList<>();

        // Add matching static suggestions (Greek, Tamil, Keywords, etc.)
        results.addAll(allSuggestions.stream()
                .filter(s -> s.getCode().toLowerCase().contains(lowerInput))
                .collect(Collectors.toList()));

        // Add matching discovered variables
        for (Map.Entry<String, String> entry : discoveredStyledVariables.entrySet()) {
            String raw = entry.getKey();
            String display = entry.getValue();
            if (raw.toLowerCase().contains(lowerInput) || display.toLowerCase().contains(lowerInput)) {
                results.add(new Suggestion(raw, "Styled variable", display, "StyledVariable"));
            }
        }

        for (String varName : discoveredVariables) {
            if (varName.toLowerCase().contains(lowerInput)) {
                results.add(new Suggestion(varName, "Variable", varName, "Variable"));
            }
        }

        // Sort by relevance
        results.sort((a, b) -> {
            // Prioritize exact prefix matches
            boolean aPrefix = a.getCode().toLowerCase().startsWith(lowerInput);
            boolean bPrefix = b.getCode().toLowerCase().startsWith(lowerInput);
            if (aPrefix != bPrefix)
                return aPrefix ? -1 : 1;

            // Prioritize Variables over other categories
            int catPriority = getCategoryPriority(a.getCategory()) - getCategoryPriority(b.getCategory());
            if (catPriority != 0)
                return catPriority;

            // Finally by code length (shorter first)
            return Integer.compare(a.getCode().length(), b.getCode().length());
        });

        return results.stream().limit(15).collect(Collectors.toList());
    }

    /**
     * Get category priority for sorting (lower = higher priority).
     */
    private static int getCategoryPriority(String category) {
        // Priority order: Variables first, then Functions (alphabetical), then others
        if ("StyledVariable".equals(category))
            return 0; // Styled variables: HIGHEST PRIORITY
        if ("Variable".equals(category))
            return 1; // Variables: SECOND PRIORITY
        if ("Function".equals(category))
            return 2; // Functions: THIRD PRIORITY
        if ("GreekSimple".equals(category))
            return 3; // Simple Greek names (alpha, beta)
        if ("TamilSimple".equals(category))
            return 4; // Simple Tamil names
        if ("SanskritSimple".equals(category))
            return 4; // Simple Sanskrit names
        if ("TeluguSimple".equals(category))
            return 4; // Simple Telugu names
        if ("MalayalamSimple".equals(category))
            return 4; // Simple Malayalam names
        if ("Keyword".equals(category))
            return 5;
        if ("Greek".equals(category))
            return 6; // Full Greek format lower priority
        if ("Tamil".equals(category))
            return 7; // Full Tamil format lower priority
        if ("Sanskrit".equals(category))
            return 7; // Full Sanskrit format lower priority
        if ("Telugu".equals(category))
            return 7; // Full Telugu format lower priority
        if ("Malayalam".equals(category))
            return 7; // Full Malayalam format lower priority
        if ("Math".equals(category))
            return 8;
        return 9; // Default
    }

    /**
     * Get all available suggestions (for initialization or reference).
     */
    public static List<Suggestion> getAllSuggestions() {
        return new ArrayList<>(allSuggestions);
    }

    /**
     * Suggestion data class.
     */
    public static class Suggestion {
        private final String code; // What to type
        private final String description; // Human-readable description
        private final String display; // What character/symbol it produces
        private final String category; // Category for grouping

        public Suggestion(String code, String description, String display, String category) {
            this.code = code;
            this.description = description;
            this.display = display;
            this.category = category;
        }

        public String getCode() {
            return code;
        }

        public String getDescription() {
            return description;
        }

        public String getDisplay() {
            return display;
        }

        public String getCategory() {
            return category;
        }

        @Override
        public String toString() {
            return code + " → " + display + " (" + description + ")";
        }
    }
}
