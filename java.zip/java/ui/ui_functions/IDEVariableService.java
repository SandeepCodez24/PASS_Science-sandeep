package ui.ui_functions;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javafx.collections.FXCollections;
import javafx.scene.control.Tab;
import javafx.scene.control.TableView;
import language.language_engine.VariableFileWriter;
import ui.editor.EditorTextOperations;
import ui.managers.LanguageDesignManager;


public final class IDEVariableService {

    private static final String CONSOLE_SOURCE = "console";

    private static final Pattern ENTRY_START = Pattern.compile("^\"([^\"]+)\"\\s*:\\s*\\{$");
    private static final Pattern FIELD = Pattern.compile("^\"(size|type|value)\"\\s*:\\s*(.*)$");
    private static final Pattern NUMBER_TOKEN = Pattern.compile("[+-]?(?:\\d+\\.\\d+|\\d+)(?:[eE][+-]?\\d+)?");
    private static final Pattern INTEGER_TOKEN = Pattern.compile("[+-]?\\d+");

    private IDEVariableService() {
    }

    public static List<String> getVariableNames(TableView<Variable> varTable) {

        if (varTable == null || varTable.getItems().isEmpty())
            return List.of();

        return varTable.getItems()
                .stream()
                .map(Variable::getName)
                .distinct()
                .collect(Collectors.toList());
    }

    public static List<Double> getVariableValues(TableView<Variable> varTable, String name) {

        if (varTable == null || varTable.getItems().isEmpty())
            return List.of();

        return varTable.getItems()
                .stream()
                .filter(v -> v.getName().equals(name))
                .map(Variable::getValue)
                .flatMap(value -> parseNumericValues(value).stream())
                .collect(Collectors.toList());
    }

    public static void loadVariablesFromFile(TableView<Variable> varTable, Path variableFilePath) {
        if (varTable == null) {
            return;
        }

        if (variableFilePath == null || !Files.exists(variableFilePath)) {
            varTable.getItems().clear();
            return;
        }

        List<Variable> parsed = new ArrayList<>();
        try {
            List<String> lines = Files.readAllLines(variableFilePath);
            parsed = parseVariablesFromLines(lines, variableFilePath == null ? null : variableFilePath.toString());
        } catch (IOException e) {
            varTable.getItems().clear();
            return;
        }

        varTable.setItems(FXCollections.observableArrayList(parsed));
    }

    public static void loadVariablesFromFiles(TableView<Variable> varTable, List<Path> variableFilePaths) {
        if (varTable == null)
            return;
        if (variableFilePaths == null || variableFilePaths.isEmpty()) {
            varTable.getItems().clear();
            return;
        }

        // Deduplicate paths to avoid loading the same file multiple times
        java.util.LinkedHashSet<Path> set = new java.util.LinkedHashSet<>();
        for (Path p : variableFilePaths)
            if (p != null)
                set.add(p);

        List<Variable> all = new ArrayList<>();
        for (Path p : set) {
            if (!Files.exists(p))
                continue;
            try {
                List<String> lines = Files.readAllLines(p);
                List<Variable> parsed = parseVariablesFromLines(lines, p.toString());
                all.addAll(parsed);
            } catch (IOException ignored) {
            }
        }

        varTable.setItems(FXCollections.observableArrayList(all));
    }

    public static void writeCombinedVariablesFile(Path outputPath, List<Tab> upiTabs, List<Variable> consoleVariables) {
        writeCombinedVariablesFile(outputPath, upiTabs, consoleVariables, List.of());
    }

    public static void writeCombinedVariablesFile(Path outputPath, List<Tab> upiTabs, List<Variable> consoleVariables,
            List<Variable> existingVariables) {
        if (outputPath == null || upiTabs == null) {
            return;
        }

        List<Variable> all = collectVariablesFromTabsAndConsole(upiTabs, consoleVariables);

        try {
            Files.writeString(outputPath, buildVariableDictionary(all), StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING);
        } catch (IOException ignored) {
        }
    }

    public static void writeCombinedJavaDictionaryFile(Path outputPath, List<Tab> upiTabs, List<Variable> consoleVariables) {
        writeCombinedJavaDictionaryFile(outputPath, upiTabs, consoleVariables, List.of());
    }

    public static void writeCombinedJavaDictionaryFile(Path outputPath, List<Tab> upiTabs, List<Variable> consoleVariables,
            List<Variable> existingVariables) {
        if (outputPath == null || upiTabs == null) {
            return;
        }

        List<Variable> currentVariables = collectVariablesFromTabsAndConsole(upiTabs, consoleVariables);

        StringBuilder combined = new StringBuilder();
        for (Variable variable : currentVariables) {
            if (variable == null || variable.getName() == null || variable.getValue() == null) {
                continue;
            }
            combined.append(variable.getName()).append("=").append(variable.getValue()).append(";")
                    .append(System.lineSeparator());
        }

        try {
            VariableFileWriter.writeJavaDictionaryFile(combined.toString(), outputPath);
        } catch (IOException ignored) {
        }
    }

    public static List<Variable> mergeVariableLists(List<Variable> existingVariables, List<Variable> newVariables) {
        List<Variable> merged = new ArrayList<>();
        if (existingVariables != null) {
            for (Variable variable : existingVariables) {
                if (variable != null && variable.getName() != null && !variable.getName().isBlank()) {
                    merged.add(variable);
                }
            }
        }

        if (newVariables == null || newVariables.isEmpty()) {
            return merged;
        }

        Set<String> sourcePathsToReplace = new HashSet<>();
        Set<String> namesToReplace = new HashSet<>();
        for (Variable variable : newVariables) {
            if (variable == null || variable.getName() == null || variable.getName().isBlank()) {
                continue;
            }
            namesToReplace.add(variable.getName());
            String sourcePath = variable.getSourcePath();
            if (sourcePath != null && !sourcePath.isBlank()) {
                sourcePathsToReplace.add(sourcePath);
            }
        }

        if (!sourcePathsToReplace.isEmpty()) {
            merged.removeIf(existing -> existing != null
                    && existing.getSourcePath() != null
                    && sourcePathsToReplace.contains(existing.getSourcePath()));
        }

        if (!namesToReplace.isEmpty()) {
            merged.removeIf(existing -> existing != null
                    && existing.getSourcePath() == null
                    && existing.getName() != null
                    && namesToReplace.contains(existing.getName()));
        }

        for (Variable variable : newVariables) {
            if (variable == null || variable.getName() == null || variable.getName().isBlank()) {
                continue;
            }

            if (variable.getSourcePath() == null || variable.getSourcePath().isBlank()) {
                boolean updated = false;
                for (int i = 0; i < merged.size(); i++) {
                    Variable existing = merged.get(i);
                    if (existing != null && variable.getName().equals(existing.getName())) {
                        merged.set(i, variable);
                        updated = true;
                        break;
                    }
                }
                if (!updated) {
                    merged.add(variable);
                }
            } else {
                merged.add(variable);
            }
        }

        return merged;
    }

    public static List<Variable> collectVariablesFromTabsAndConsole(List<Tab> upiTabs,
            List<Variable> consoleVariables) {
        List<Variable> collected = new ArrayList<>();
        if (upiTabs == null) {
            return collected;
        }

        for (Tab tab : upiTabs) {
            String text = EditorTextOperations.getEditorText(tab);
            if (text == null || text.isBlank()) {
                continue;
            }

            String preprocessed = LanguageDesignManager.preprocess(text);
            Path tempPath = null;
            try {
                tempPath = Files.createTempFile("upi-variables-", UUID.randomUUID().toString() + ".dict");
                VariableFileWriter.writeVariablesFile(preprocessed, tempPath);
                List<String> lines = Files.readAllLines(tempPath);
                String sourcePath = null;
                Object userData = tab.getUserData();
                if (userData instanceof ui.editor.EditorFileInfo info && info.path != null) {
                    sourcePath = info.path.toString();
                }
                collected.addAll(parseVariablesFromLines(lines, sourcePath));
            } catch (IOException ignored) {
            } finally {
                if (tempPath != null) {
                    try {
                        Files.deleteIfExists(tempPath);
                    } catch (IOException ignored) {
                    }
                }
            }
        }

        if (consoleVariables != null && !consoleVariables.isEmpty()) {
            for (Variable variable : consoleVariables) {
                if (variable == null || variable.getName() == null) {
                    continue;
                }
                collected.removeIf(
                        v -> CONSOLE_SOURCE.equals(v.getSourcePath()) && v.getName().equals(variable.getName()));
                collected.add(new Variable(variable.getName(), variable.getValue(), variable.getSize(),
                        variable.getDatatype(), CONSOLE_SOURCE));
            }
        }

        return collected;
    }

    public static List<Variable> parseConsoleVariables(String input) {
        if (input == null || input.isBlank()) {
            return List.of();
        }

        String cleanedInput = LanguageDesignManager.preprocess(input);
        Path tempPath = null;
        try {
            tempPath = Files.createTempFile("console-variables-", ".dict");
            VariableFileWriter.writeVariablesFile(cleanedInput, tempPath);
            List<String> lines = Files.readAllLines(tempPath);
            return parseVariablesFromLines(lines, CONSOLE_SOURCE);
        } catch (IOException ignored) {
            return List.of();
        } finally {
            if (tempPath != null) {
                try {
                    Files.deleteIfExists(tempPath);
                } catch (IOException ignored) {
                }
            }
        }
    }

    private static String buildVariableDictionary(List<Variable> variables) {
        StringBuilder dictionary = new StringBuilder();
        dictionary.append("Data = {").append(System.lineSeparator());

        for (int i = 0; i < variables.size(); i++) {
            Variable variable = variables.get(i);
            dictionary.append("    ").append(quote(variable.getName())).append(": {").append(System.lineSeparator());
            dictionary.append("        \"size\": ").append(quote(variable.getSize())).append(",")
                    .append(System.lineSeparator());
            dictionary.append("        \"type\": ").append(quote(variable.getDatatype())).append(",")
                    .append(System.lineSeparator());
            dictionary.append("        \"value\": ").append(formatLiteral(variable.getValue()))
                    .append(System.lineSeparator());
            dictionary.append("    }");
            if (i < variables.size() - 1) {
                dictionary.append(',');
            }
            dictionary.append(System.lineSeparator());
        }

        dictionary.append('}').append(System.lineSeparator());
        return dictionary.toString();
    }

    private static String quote(String text) {
        if (text == null) {
            return "\"\"";
        }
        return "\"" + text.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }

    private static String formatLiteral(String value) {
        if (value == null) {
            return quote("");
        }

        String trimmed = value.trim();
        if (trimmed.isEmpty()) {
            return quote("");
        }

        if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
            return trimmed;
        }

        if (trimmed.startsWith("{") && trimmed.endsWith("}")) {
            return trimmed;
        }

        if (trimmed.startsWith("(") && trimmed.endsWith(")")) {
            return trimmed;
        }

        if (trimmed.equalsIgnoreCase("true") || trimmed.equalsIgnoreCase("false")
                || NUMBER_TOKEN.matcher(trimmed).matches()) {
            return trimmed;
        }

        return quote(trimmed);
    }

    private static List<Variable> parseVariablesFromLines(List<String> lines, String sourcePath) {
        List<Variable> parsed = new ArrayList<>();
        if (lines == null || lines.isEmpty())
            return parsed;

        String currentName = null;
        String currentSize = null;
        String currentType = null;
        String currentValue = null;

        for (String raw : lines) {
            String line = raw == null ? "" : raw.trim();

            if (line.isEmpty() || line.equals("list_distionary = {") || line.equals("}")) {
                continue;
            }

            Matcher entryStart = ENTRY_START.matcher(line);
            if (entryStart.matches()) {
                currentName = entryStart.group(1);
                currentSize = null;
                currentType = null;
                currentValue = null;
                continue;
            }

            if (line.equals("},")) {
                if (currentName != null && currentSize != null && currentType != null && currentValue != null) {
                    parsed.add(new Variable(currentName, currentValue, currentSize,
                            inferDisplayDatatype(currentValue, currentType), sourcePath));
                }
                currentName = null;
                currentSize = null;
                currentType = null;
                currentValue = null;
                continue;
            }

            String normalized = line.endsWith(",") ? line.substring(0, line.length() - 1) : line;
            Matcher field = FIELD.matcher(normalized);
            if (!field.matches()) {
                continue;
            }

            String fieldName = field.group(1);
            String fieldValue = unquote(field.group(2).trim());
            switch (fieldName) {
                case "size":
                    currentSize = fieldValue;
                    break;
                case "type":
                    currentType = fieldValue;
                    break;
                case "value":
                    currentValue = fieldValue;
                    break;
                default:
                    break;
            }
        }

        if (currentName != null && currentSize != null && currentType != null && currentValue != null) {
            parsed.add(new Variable(currentName, currentValue, currentSize,
                    inferDisplayDatatype(currentValue, currentType), sourcePath));
        }
        return parsed;
    }

    private static String unquote(String value) {
        if (value == null) {
            return "";
        }

        String trimmed = value.trim();
        if (trimmed.length() >= 2 && trimmed.startsWith("\"") && trimmed.endsWith("\"")) {
            String inner = trimmed.substring(1, trimmed.length() - 1);
            return inner.replace("\\\"", "\"").replace("\\\\", "\\");
        }

        return trimmed;
    }

    private static List<Double> parseNumericValues(String value) {
        if (value == null || value.isBlank()) {
            return List.of();
        }

        String trimmed = value.trim();
        if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
            List<Double> parsed = new ArrayList<>();
            Matcher matcher = NUMBER_TOKEN.matcher(trimmed);
            while (matcher.find()) {
                try {
                    parsed.add(Double.parseDouble(matcher.group()));
                } catch (NumberFormatException ignored) {
                    // Skip malformed tokens and keep the rest of the list.
                }
            }
            return parsed;
        }

        try {
            return List.of(Double.parseDouble(trimmed));
        } catch (NumberFormatException e) {
            return List.of(0.0);
        }
    }

    private static String inferDisplayDatatype(String value, String fallbackType) {
        if (value == null || value.isBlank()) {
            return fallbackType == null ? "unknown" : fallbackType;
        }

        String trimmed = value.trim();
        if (isCollectionValue(trimmed)) {
            if (containsQuotedString(trimmed)) {
                return "string";
            }

            if (containsDecimalNumber(trimmed)) {
                return "float";
            }

            if (containsIntegerNumber(trimmed)) {
                return "int";
            }

            return fallbackType == null ? "list" : fallbackType;
        }

        if (isQuotedString(trimmed)) {
            return "string";
        }

        if (trimmed.equalsIgnoreCase("true") || trimmed.equalsIgnoreCase("false")) {
            return "boolean";
        }

        if (INTEGER_TOKEN.matcher(trimmed).matches()) {
            return "int";
        }

        if (NUMBER_TOKEN.matcher(trimmed).matches()) {
            return "float";
        }

        return fallbackType == null ? "unknown" : fallbackType;
    }

    private static boolean isCollectionValue(String value) {
        return (value.startsWith("[") && value.endsWith("]"))
                || (value.startsWith("(") && value.endsWith(")"))
                || (value.startsWith("{") && value.endsWith("}"));
    }

    private static boolean isQuotedString(String value) {
        return (value.startsWith("\"") && value.endsWith("\""))
                || (value.startsWith("'") && value.endsWith("'"));
    }

    private static boolean containsQuotedString(String value) {
        return value.contains("\"") || value.contains("'");
    }

    private static boolean containsIntegerNumber(String value) {
        Matcher matcher = NUMBER_TOKEN.matcher(value);
        while (matcher.find()) {
            String token = matcher.group();
            if (!token.contains(".") && !token.contains("e") && !token.contains("E")) {
                return true;
            }
        }

        return false;
    }

    private static boolean containsDecimalNumber(String value) {
        Matcher matcher = NUMBER_TOKEN.matcher(value);
        while (matcher.find()) {
            String token = matcher.group();
            if (token.contains(".") || token.contains("e") || token.contains("E")) {
                return true;
            }
        }

        return false;
    }

    /**
     * Creates a Variable for "ans" (answer/result output) from terminal or program
     * output.
     * Auto-detects the datatype and size based on the value.
     * 
     * @param ansValue the value of ans from output
     * @return a Variable object representing ans, or null if value is empty
     */
    public static Variable createAnsVariable(String ansValue) {
        if (ansValue == null || ansValue.isBlank()) {
            return null;
        }

        String trimmedValue = ansValue.trim();

        // Infer the datatype
        String datatype = inferAnsDatatype(trimmedValue);

        // Calculate size
        String size = calculateSize(trimmedValue);

        // Create and return the Variable
        return new Variable("ans", trimmedValue, size, datatype);
    }

    /**
     * Infers the datatype of an "ans" output value.
     */
    private static String inferAnsDatatype(String value) {
        if (value == null || value.isEmpty()) {
            return "unknown";
        }

        String trimmed = value.trim();

        // Check for collections (arrays, lists, matrices)
        if (isCollectionValue(trimmed)) {
            if (containsQuotedString(trimmed)) {
                return "string[]";
            }
            if (containsDecimalNumber(trimmed)) {
                return "float[]";
            }
            if (containsIntegerNumber(trimmed)) {
                return "int[]";
            }
            return "list";
        }

        // Check for strings
        if (isQuotedString(trimmed)) {
            return "string";
        }

        // Check for boolean
        if (trimmed.equalsIgnoreCase("true") || trimmed.equalsIgnoreCase("false")) {
            return "boolean";
        }

        // Check for numbers
        if (INTEGER_TOKEN.matcher(trimmed).matches()) {
            return "int";
        }

        if (NUMBER_TOKEN.matcher(trimmed).matches()) {
            return "float";
        }

        return "unknown";
    }

    /**
     * Calculates the size/shape of an "ans" value.
     */
    private static String calculateSize(String value) {
        if (value == null || value.isEmpty()) {
            return "1";
        }

        String trimmed = value.trim();

        // For collections, calculate dimensions
        if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
            // Count elements in array/list
            String content = trimmed.substring(1, trimmed.length() - 1);
            if (content.isEmpty()) {
                return "0";
            }

            // Count comma-separated values
            int count = 1;
            int depth = 0;
            for (char c : content.toCharArray()) {
                if (c == '[' || c == '(')
                    depth++;
                if (c == ']' || c == ')')
                    depth--;
                if (c == ',' && depth == 0)
                    count++;
            }
            return String.valueOf(count);
        }

        // For strings, return length
        if (isQuotedString(trimmed)) {
            return String.valueOf(trimmed.length() - 2); // Subtract quotes
        }

        // Default scalar size
        return "1";
    }
}
