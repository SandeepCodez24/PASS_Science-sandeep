package ui.ui_functions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * FunctionEvaluator - Evaluates function calls and returns their computed
 * values.
 * Supports all functions from FunctionProvider with actual result computation.
 * 
 * Examples:
 * - Diag(3) → [[3,0,0],[0,3,0],[0,0,3]]
 * - Mean([1,2,3]) → 2.0
 * - sqrt(16) → 4.0
 */
public class FunctionEvaluator {

    private static final Pattern FUNCTION_CALL_PATTERN = Pattern.compile(
            "^\\s*([a-zA-Z_][a-zA-Z0-9_]*)\\s*\\(([^)]*)\\)\\s*$");

    /**
     * Evaluate a function call and return its computed value as a string.
     * Returns the original expression if evaluation fails or function is not
     * recognized.
     * 
     * @param expression the function call expression (e.g., "Diag(3)",
     *                   "Mean([1,2,3])")
     * @return computed result as string, or original expression if not a function
     *         call
     */
    public static String evaluateFunction(String expression) {
        return evaluateFunction(expression, new HashMap<>());
    }

    /**
     * Evaluate a function call with variable substitution support.
     * Replaces variable references with their values before evaluation.
     * Also evaluates arithmetic expressions like a^2, a+b, etc.
     * 
     * @param expression the function call expression (e.g., "Unit_matrix(d)" or
     *                   "b^2")
     * @param variables  map of variable names to their values (e.g., {"d": "4"})
     * @return computed result as string, or original expression if not a function
     *         call
     */
    public static String evaluateFunction(String expression, Map<String, String> variables) {
        if (expression == null || expression.trim().isEmpty()) {
            return expression;
        }

        String trimmed = expression.trim();

        // First, substitute variable references with their values
        String substituted = substituteVariables(trimmed, variables);

        // Try to evaluate as a function call
        Matcher matcher = FUNCTION_CALL_PATTERN.matcher(substituted);
        if (matcher.matches()) {
            return evaluateFunctionCall(matcher.group(1), matcher.group(2).trim(), substituted, expression);
        }

        // If not a function call, try to evaluate as arithmetic expression
        // But only if it contains operators or looks like a number
        if (containsOperators(substituted)) {
            try {
                double result = evaluateArithmeticExpression(substituted);
                return String.valueOf(result);
            } catch (Exception e) {
                // Return original expression if arithmetic evaluation fails
                return expression;
            }
        }

        // Not a function call or arithmetic expression, return original
        if (!substituted.equals(trimmed)) {
            return substituted;
        }

        return expression;
    }

    /**
     * Check if expression contains arithmetic operators
     */
    private static boolean containsOperators(String expr) {
        return expr.matches(".*[+\\-*/%^].*");
    }

    /**
     * Evaluate arithmetic expression with support for +, -, *, /, ^
     * Example: "2.0^2" → 4.0, "3+5" → 8.0, "10/2" → 5.0
     */
    private static double evaluateArithmeticExpression(String expr) throws Exception {
        expr = expr.trim();

        // Tokenize and evaluate using standard operator precedence
        return evaluateExpression(expr);
    }

    /**
     * Simple recursive expression evaluator with operator precedence
     * Handles: +, -, *, /, ^ (power)
     */
    private static double evaluateExpression(String expr) throws Exception {
        expr = expr.trim();

        // Handle power operator (highest precedence)
        // Right associative: 2^3^2 = 2^(3^2) = 2^9 = 512
        int powIndex = expr.lastIndexOf('^');
        if (powIndex > 0 && powIndex < expr.length() - 1) {
            double left = evaluateExpression(expr.substring(0, powIndex));
            double right = evaluateExpression(expr.substring(powIndex + 1));
            return Math.pow(left, right);
        }

        // Handle multiplication and division
        for (int i = expr.length() - 1; i > 0; i--) {
            char c = expr.charAt(i);
            if (c == '*' || c == '/') {
                // Make sure it's not a negative number sign
                if (i > 0 && Character.isDigit(expr.charAt(i - 1))) {
                    double left = evaluateExpression(expr.substring(0, i));
                    double right = evaluateExpression(expr.substring(i + 1));
                    return c == '*' ? left * right : left / right;
                }
            }
        }

        // Handle addition and subtraction
        for (int i = expr.length() - 1; i > 0; i--) {
            char c = expr.charAt(i);
            if (c == '+' || c == '-') {
                // Make sure it's not a negative number sign at the start or after operator
                if (i > 0 && expr.charAt(i - 1) != '(' && Character.isDigit(expr.charAt(i - 1))) {
                    double left = evaluateExpression(expr.substring(0, i));
                    double right = evaluateExpression(expr.substring(i + 1));
                    return c == '+' ? left + right : left - right;
                }
            }
        }

        // Remove parentheses
        if (expr.startsWith("(") && expr.endsWith(")")) {
            return evaluateExpression(expr.substring(1, expr.length() - 1));
        }

        // Parse as number
        try {
            return Double.parseDouble(expr);
        } catch (NumberFormatException e) {
            throw new Exception("Cannot parse as number: " + expr);
        }
    }

    /**
     * Evaluate a function call
     */
    private static String evaluateFunctionCall(String functionName, String argsStr, String substituted,
            String expression) {
        try {
            // Matrix creation functions
            if (functionName.equalsIgnoreCase("Diag")) {
                return evaluateDiag(argsStr);
            }
            if (functionName.equalsIgnoreCase("Unit_matrix")) {
                return evaluateUnitMatrix(argsStr);
            }
            if (functionName.equalsIgnoreCase("Zero_matrix")) {
                return evaluateZeroMatrix(argsStr);
            }

            // Basic math functions
            if (functionName.equalsIgnoreCase("sqrt")) {
                return evaluateSqrt(argsStr);
            }
            if (functionName.equalsIgnoreCase("cbrt")) {
                return evaluateCbrt(argsStr);
            }
            if (functionName.equalsIgnoreCase("sqr")) {
                return evaluateSqr(argsStr);
            }
            if (functionName.equalsIgnoreCase("cube")) {
                return evaluateCube(argsStr);
            }
            if (functionName.equalsIgnoreCase("abs") || functionName.equals("|")) {
                return evaluateAbs(argsStr);
            }

            // Log and exponential functions
            if (functionName.equalsIgnoreCase("log")) {
                return evaluateLog(argsStr);
            }

            // Trigonometric functions
            if (functionName.equalsIgnoreCase("sin")) {
                return evaluateSin(argsStr);
            }
            if (functionName.equalsIgnoreCase("cos")) {
                return evaluateCos(argsStr);
            }
            if (functionName.equalsIgnoreCase("tan")) {
                return evaluateTan(argsStr);
            }
            if (functionName.equalsIgnoreCase("cosec")) {
                return evaluateCosec(argsStr);
            }
            if (functionName.equalsIgnoreCase("sec")) {
                return evaluateSec(argsStr);
            }
            if (functionName.equalsIgnoreCase("cot")) {
                return evaluateCot(argsStr);
            }

            // Inverse trigonometric functions
            if (functionName.equalsIgnoreCase("inv_sin")) {
                return evaluateInvSin(argsStr);
            }
            if (functionName.equalsIgnoreCase("inv_cos")) {
                return evaluateInvCos(argsStr);
            }
            if (functionName.equalsIgnoreCase("inv_tan")) {
                return evaluateInvTan(argsStr);
            }

            // Hyperbolic functions
            if (functionName.equalsIgnoreCase("sinh")) {
                return evaluateSinh(argsStr);
            }
            if (functionName.equalsIgnoreCase("cosh")) {
                return evaluateCosh(argsStr);
            }
            if (functionName.equalsIgnoreCase("tanh")) {
                return evaluateTanh(argsStr);
            }

            // Statistical functions
            if (functionName.equalsIgnoreCase("Mean")) {
                return evaluateMean(argsStr);
            }
            if (functionName.equalsIgnoreCase("Median")) {
                return evaluateMedian(argsStr);
            }
            if (functionName.equalsIgnoreCase("SD")) {
                return evaluateStandardDeviation(argsStr);
            }
            if (functionName.equalsIgnoreCase("VAR")) {
                return evaluateVariance(argsStr);
            }
            if (functionName.equalsIgnoreCase("Geo_Mean")) {
                return evaluateGeoMean(argsStr);
            }
            if (functionName.equalsIgnoreCase("Harmo_Mean")) {
                return evaluateHarmonicMean(argsStr);
            }

            // Not a recognized function, return original
            return expression;

        } catch (Exception e) {
            // Return original expression if evaluation fails
            return expression;
        }
    }

    /**
     * Substitute variable references with their values.
     * Example: "Unit_matrix(d)" with {"d": "4"} → "Unit_matrix(4)"
     * 
     * @param expression the expression with variable references
     * @param variables  map of variable names to values
     * @return expression with variables substituted
     */
    private static String substituteVariables(String expression, Map<String, String> variables) {
        if (variables == null || variables.isEmpty()) {
            return expression;
        }

        String result = expression;

        // Replace each variable with its value
        // Use word boundaries to avoid partial matches (e.g., "d" in "Diag")
        for (Map.Entry<String, String> entry : variables.entrySet()) {
            String varName = entry.getKey().trim();
            String varValue = entry.getValue().trim();

            // Match variable as a complete word (not part of function name)
            // Pattern: word boundary + variable name + word boundary (but not preceded by
            // letters)
            Pattern pattern = Pattern.compile("(?<!\\w)" + Pattern.quote(varName) + "(?!\\w)");
            result = pattern.matcher(result).replaceAll(varValue);
        }

        return result;
    }

    /**
     * Create a diagonal matrix: Diag(3) → [[3,0,0],[0,3,0],[0,0,3]]
     */
    private static String evaluateDiag(String args) throws Exception {
        double n = parseNumber(args.trim());
        int size = (int) n;

        List<List<Integer>> matrix = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            List<Integer> row = new ArrayList<>();
            for (int j = 0; j < size; j++) {
                row.add(i == j ? size : 0);
            }
            matrix.add(row);
        }

        return formatMatrix(matrix);
    }

    /**
     * Create a unit (identity) matrix: Unit_matrix(3) → [[1,0,0],[0,1,0],[0,0,1]]
     */
    private static String evaluateUnitMatrix(String args) throws Exception {
        double n = parseNumber(args.trim());
        int size = (int) n;

        List<List<Integer>> matrix = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            List<Integer> row = new ArrayList<>();
            for (int j = 0; j < size; j++) {
                row.add(i == j ? 1 : 0);
            }
            matrix.add(row);
        }

        return formatMatrix(matrix);
    }

    /**
     * Create a zero matrix: Zero_matrix(3) → [[0,0,0],[0,0,0],[0,0,0]]
     */
    private static String evaluateZeroMatrix(String args) throws Exception {
        double n = parseNumber(args.trim());
        int size = (int) n;

        List<List<Integer>> matrix = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            List<Integer> row = new ArrayList<>();
            for (int j = 0; j < size; j++) {
                row.add(0);
            }
            matrix.add(row);
        }

        return formatMatrix(matrix);
    }

    /**
     * Square root: sqrt(16) → 4.0
     */
    private static String evaluateSqrt(String args) throws Exception {
        double num = parseNumber(args.trim());
        return String.valueOf(Math.sqrt(num));
    }

    /**
     * Cube root: cbrt(8) → 2.0
     */
    private static String evaluateCbrt(String args) throws Exception {
        double num = parseNumber(args.trim());
        return String.valueOf(Math.cbrt(num));
    }

    /**
     * Square: sqr(3) → 9.0
     */
    private static String evaluateSqr(String args) throws Exception {
        double num = parseNumber(args.trim());
        return String.valueOf(num * num);
    }

    /**
     * Cube: cube(2) → 8.0
     */
    private static String evaluateCube(String args) throws Exception {
        double num = parseNumber(args.trim());
        return String.valueOf(num * num * num);
    }

    /**
     * Absolute value: abs(5) → 5.0, abs(-5) → 5.0
     */
    private static String evaluateAbs(String args) throws Exception {
        double num = parseNumber(args.trim());
        return String.valueOf(Math.abs(num));
    }

    /**
     * Natural logarithm: log(2.718) → 1.0
     */
    private static String evaluateLog(String args) throws Exception {
        double num = parseNumber(args.trim());
        return String.valueOf(Math.log(num));
    }

    /**
     * Sine: sin(0) → 0.0
     */
    private static String evaluateSin(String args) throws Exception {
        double num = parseNumber(args.trim());
        return String.valueOf(Math.sin(num));
    }

    /**
     * Cosine: cos(0) → 1.0
     */
    private static String evaluateCos(String args) throws Exception {
        double num = parseNumber(args.trim());
        return String.valueOf(Math.cos(num));
    }

    /**
     * Tangent: tan(0) → 0.0
     */
    private static String evaluateTan(String args) throws Exception {
        double num = parseNumber(args.trim());
        return String.valueOf(Math.tan(num));
    }

    /**
     * Mean/Average: Mean([1,2,3]) → 2.0
     */
    private static String evaluateMean(String args) throws Exception {
        List<Double> values = parseNumberArray(args.trim());
        if (values.isEmpty())
            throw new Exception("Empty array");
        double sum = values.stream().mapToDouble(Double::doubleValue).sum();
        return String.valueOf(sum / values.size());
    }

    /**
     * Median: Median([1,2,3]) → 2.0
     */
    private static String evaluateMedian(String args) throws Exception {
        List<Double> values = parseNumberArray(args.trim());
        if (values.isEmpty())
            throw new Exception("Empty array");

        values.sort(Double::compareTo);
        int size = values.size();
        if (size % 2 == 1) {
            return String.valueOf(values.get(size / 2));
        } else {
            return String.valueOf((values.get(size / 2 - 1) + values.get(size / 2)) / 2);
        }
    }

    /**
     * Standard Deviation: SD([1,2,3]) → 1.0
     */
    private static String evaluateStandardDeviation(String args) throws Exception {
        List<Double> values = parseNumberArray(args.trim());
        if (values.isEmpty())
            throw new Exception("Empty array");

        double mean = values.stream().mapToDouble(Double::doubleValue).average().orElse(0.0);
        double variance = values.stream()
                .mapToDouble(v -> Math.pow(v - mean, 2))
                .average()
                .orElse(0.0);

        return String.valueOf(Math.sqrt(variance));
    }

    /**
     * Variance: VAR([1,2,3]) → 1.0
     */
    private static String evaluateVariance(String args) throws Exception {
        List<Double> values = parseNumberArray(args.trim());
        if (values.isEmpty())
            throw new Exception("Empty array");

        double mean = values.stream().mapToDouble(Double::doubleValue).average().orElse(0.0);
        double variance = values.stream()
                .mapToDouble(v -> Math.pow(v - mean, 2))
                .average()
                .orElse(0.0);

        return String.valueOf(variance);
    }

    /**
     * Cosecant: cosec(x) → 1/sin(x)
     */
    private static String evaluateCosec(String args) throws Exception {
        double num = parseNumber(args.trim());
        double result = 1.0 / Math.sin(num);
        return String.valueOf(result);
    }

    /**
     * Secant: sec(x) → 1/cos(x)
     */
    private static String evaluateSec(String args) throws Exception {
        double num = parseNumber(args.trim());
        double result = 1.0 / Math.cos(num);
        return String.valueOf(result);
    }

    /**
     * Cotangent: cot(x) → 1/tan(x)
     */
    private static String evaluateCot(String args) throws Exception {
        double num = parseNumber(args.trim());
        double result = 1.0 / Math.tan(num);
        return String.valueOf(result);
    }

    /**
     * Inverse sine (arcsin): inv_sin(0.5) → 0.5236
     */
    private static String evaluateInvSin(String args) throws Exception {
        double num = parseNumber(args.trim());
        return String.valueOf(Math.asin(num));
    }

    /**
     * Inverse cosine (arccos): inv_cos(0.5) → 1.047
     */
    private static String evaluateInvCos(String args) throws Exception {
        double num = parseNumber(args.trim());
        return String.valueOf(Math.acos(num));
    }

    /**
     * Inverse tangent (arctan): inv_tan(1) → 0.785
     */
    private static String evaluateInvTan(String args) throws Exception {
        double num = parseNumber(args.trim());
        return String.valueOf(Math.atan(num));
    }

    /**
     * Hyperbolic sine: sinh(0) → 0.0
     */
    private static String evaluateSinh(String args) throws Exception {
        double num = parseNumber(args.trim());
        return String.valueOf(Math.sinh(num));
    }

    /**
     * Hyperbolic cosine: cosh(0) → 1.0
     */
    private static String evaluateCosh(String args) throws Exception {
        double num = parseNumber(args.trim());
        return String.valueOf(Math.cosh(num));
    }

    /**
     * Hyperbolic tangent: tanh(0) → 0.0
     */
    private static String evaluateTanh(String args) throws Exception {
        double num = parseNumber(args.trim());
        return String.valueOf(Math.tanh(num));
    }

    /**
     * Geometric Mean: Geo_Mean([2,8]) → 4.0
     */
    private static String evaluateGeoMean(String args) throws Exception {
        List<Double> values = parseNumberArray(args.trim());
        if (values.isEmpty())
            throw new Exception("Empty array");

        double product = values.stream().mapToDouble(Double::doubleValue).reduce(1, (a, b) -> a * b);
        double geoMean = Math.pow(product, 1.0 / values.size());
        return String.valueOf(geoMean);
    }

    /**
     * Harmonic Mean: Harmo_Mean([2,4]) → 2.667
     */
    private static String evaluateHarmonicMean(String args) throws Exception {
        List<Double> values = parseNumberArray(args.trim());
        if (values.isEmpty())
            throw new Exception("Empty array");

        double reciprocalSum = values.stream().mapToDouble(v -> 1.0 / v).sum();
        double harmonicMean = values.size() / reciprocalSum;
        return String.valueOf(harmonicMean);
    }

    /**
     * Parse a single number from string
     */
    private static double parseNumber(String str) throws Exception {
        str = str.trim();
        try {
            return Double.parseDouble(str);
        } catch (NumberFormatException e) {
            throw new Exception("Cannot parse number: " + str);
        }
    }

    /**
     * Parse an array of numbers: [1,2,3] or (1,2,3)
     */
    private static List<Double> parseNumberArray(String str) throws Exception {
        str = str.trim();

        // Remove brackets or parentheses
        if ((str.startsWith("[") && str.endsWith("]")) ||
                (str.startsWith("(") && str.endsWith(")"))) {
            str = str.substring(1, str.length() - 1);
        }

        List<Double> result = new ArrayList<>();
        String[] parts = str.split(",");

        for (String part : parts) {
            part = part.trim();
            try {
                result.add(Double.parseDouble(part));
            } catch (NumberFormatException e) {
                throw new Exception("Cannot parse array element: " + part);
            }
        }

        return result;
    }

    /**
     * Format a matrix as [[a,b],[c,d]]
     */
    @SuppressWarnings("unchecked")
    private static <T> String formatMatrix(List<List<T>> matrix) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < matrix.size(); i++) {
            sb.append("[");
            List<T> row = matrix.get(i);
            for (int j = 0; j < row.size(); j++) {
                sb.append(row.get(j));
                if (j < row.size() - 1)
                    sb.append(",");
            }
            sb.append("]");
            if (i < matrix.size() - 1)
                sb.append(",");
        }
        sb.append("]");
        return sb.toString();
    }

    /**
     * Check if a string looks like a function call
     */
    public static boolean isFunctionCall(String expression) {
        if (expression == null || expression.trim().isEmpty()) {
            return false;
        }
        return FUNCTION_CALL_PATTERN.matcher(expression.trim()).matches();
    }
}
