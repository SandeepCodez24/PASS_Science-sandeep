package ui.ui_functions;

import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

import javafx.application.Platform;
import ui.UI_Main;
import ui.cli.CLI_Main;

/**
 * Process-control helpers for the Command Window.
 *
 * <h3>What was removed and why</h3>
 * This class used to be a <b>second</b> variable pipeline: it parsed the user's
 * typed input for assignments, scraped {@code ans = ...} out of console output,
 * and pushed both into {@code ide.varTable} through
 * {@code IDEVariableService}. Meanwhile {@code CLI_Main} was filling the same
 * table from {@code variables.txt}. Two writers, two schemas, one table — that
 * is where the duplicate rows came from.
 *
 * <p>The interpreter is the only thing that actually knows what a statement
 * did, so all of that guessing is gone. {@link WorkspaceStore} is now the sole
 * owner of the Explorer's rows.
 *
 * <p>{@code handleTerminalReset} also used to clear the console for
 * {@code clear}. Screen and workspace are separate concerns now and live in
 * {@code CLI_Main}; the methods here remain only so older call sites compile.
 */
public final class UI_MainProgramControl {

    private UI_MainProgramControl() {
    }

    /**
     * Attaches a child process's stdin writer.
     *
     * @param ide     the IDE controller
     * @param process the running process
     */
    public static void setRunningProcess(UI_Main ide, Process process) {
        ide.runningProcess = process;
        ide.programRunning = true;
        try {
            ide.processWriter = new BufferedWriter(
                    new OutputStreamWriter(process.getOutputStream(), StandardCharsets.UTF_8));
        } catch (Exception e) {
            appendErrorText(ide, "Terminal writer error\n");
        }
    }

    /**
     * Appends process output to the console through the freeze guard.
     *
     * @param ide  the IDE controller
     * @param text the output
     */
    public static void appendProcessOutput(UI_Main ide, String text) {
        CLI_Main.appendOutput(text);
    }

    /**
     * @param ide the IDE controller
     * @deprecated ENTER is handled by {@code ConsoleInputGuard} ->
     *             {@code CLI_Main.handleEnter}. Kept so older call sites
     *             compile; delete the call.
     */
    @Deprecated
    public static void handleConsoleEnter(UI_Main ide) {
        CLI_Main.handleEnter(ide);
    }

    /**
     * @param ide   the IDE controller
     * @param input the typed line
     * @deprecated The local (backend-less) console path no longer parses
     *             variables. Kept for compilation only.
     */
    @Deprecated
    public static void handleLocalConsoleInput(UI_Main ide, String input) {
        CLI_Main.appendPrompt();
    }

    /**
     * @param input the typed line
     * @return true for {@code cls} / {@code clc} / {@code clear}
     */
    public static boolean isTerminalResetCommand(String input) {
        if (input == null) {
            return false;
        }
        String normalized = input.trim().toLowerCase(Locale.ROOT);
        return "cls".equals(normalized) || "clc".equals(normalized)
                || "clear".equals(normalized) || normalized.startsWith("clear ");
    }

    /**
     * @param ide   the IDE controller
     * @param input the reset command
     * @deprecated Reset semantics live in {@code CLI_Main}: {@code cls} clears
     *             the screen only, {@code clear} the workspace only.
     */
    @Deprecated
    public static void handleTerminalReset(UI_Main ide, String input) {
        // Intentionally a no-op: routing this here would clear the screen on
        // "clear", which is exactly the behaviour being fixed.
    }

    /**
     * @param ide the IDE controller
     * @deprecated Variables are read from the interpreter, never inferred from
     *             what the user typed.
     */
    @Deprecated
    public static void handleConsoleStatementTerminated(UI_Main ide) {
        // Intentionally a no-op.
    }

    /**
     * Clears process state after a child process ends.
     *
     * @param ide the IDE controller
     */
    public static void onProgramFinished(UI_Main ide) {
        ide.runningProcess = null;
        ide.processWriter = null;
        ide.programRunning = false;
    }

    /**
     * Force-stops a running child process.
     *
     * @param ide the IDE controller
     */
    public static void stopProgram(UI_Main ide) {
        if (ide.runningProcess != null && ide.programRunning) {
            ide.runningProcess.destroyForcibly();
            onProgramFinished(ide);
        }
    }

    /**
     * Paints a prompt if one is not already showing.
     *
     * @param ide the IDE controller
     */
    public static void appendNextPrompt(UI_Main ide) {
        CLI_Main.appendPrompt();
    }

    /**
     * Appends text in the error colour.
     *
     * @param ide  the IDE controller
     * @param text the message
     */
    public static void appendErrorText(UI_Main ide, String text) {
        if (ide == null || ide.console == null || text == null) {
            return;
        }
        Platform.runLater(() -> {
            String previousStyle = ide.console.getStyle();
            try {
                ide.console.setStyle((previousStyle == null ? "" : previousStyle + "; ")
                        + "-fx-text-fill: #c62828;");
                CLI_Main.appendOutput(text);
            } finally {
                ide.console.setStyle(previousStyle == null ? "" : previousStyle);
            }
        });
    }

    /**
     * @param ide      the IDE controller
     * @param filename the script being run
     * @deprecated The prompt line now shows the script name directly
     *             ({@code >> ssss.nc}); nothing is replaced.
     */
    @Deprecated
    public static void replaceInitialPromptWithRunLabel(UI_Main ide, String filename) {
        // Intentionally a no-op.
    }
}
