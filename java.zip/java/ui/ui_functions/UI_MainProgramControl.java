package ui.ui_functions;

import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

import javafx.application.Platform;
import ui.UI_Main;
import ui.cli.CLI_Main;

/**
 * Process-control helpers for the Command Window.
 *
 * <h3>What was removed and why</h3>
 * This class used to be a <b>second</b> variable pipeline: it parsed the user's
 * typed input for assignments, scraped {@code ans = ...} out of console output,
 * and pushed both into {@code ide.varTable} through
 * {@code IDEVariableService}. Meanwhile {@code CLI_Main} was filling the same
 * table from {@code variables.txt}. Two writers, two schemas, one table — that
 * is where the duplicate rows came from.
 *
 * <p>The interpreter is the only thing that actually knows what a statement
 * did, so all of that guessing is gone. {@link WorkspaceStore} is now the sole
 * owner of the Explorer's rows.
 *
 * <p>Screen and workspace resets ({@code cls} / {@code clear}) and ENTER
 * handling live in {@code CLI_Main}. The deprecated pass-throughs that used to
 * sit here for older call sites have all been removed.
 */
public final class UI_MainProgramControl {

    private UI_MainProgramControl() {
    }

    /**
     * Attaches a child process's stdin writer.
     *
     * @param ide     the IDE controller
     * @param process the running process
     */
    public static void setRunningProcess(UI_Main ide, Process process) {
        ide.runningProcess = process;
        ide.programRunning = true;
        try {
            ide.processWriter = new BufferedWriter(
                    new OutputStreamWriter(process.getOutputStream(), StandardCharsets.UTF_8));
        } catch (Exception e) {
            appendErrorText(ide, "Terminal writer error\n");
        }
    }

    /**
     * Appends process output to the console through the freeze guard.
     *
     * @param ide  the IDE controller
     * @param text the output
     */
    public static void appendProcessOutput(UI_Main ide, String text) {
        CLI_Main.appendOutput(text);
    }

    /**
     * @param input the typed line
     * @return true for {@code cls} / {@code clc} / {@code clear}
     */
    public static boolean isTerminalResetCommand(String input) {
        if (input == null) {
            return false;
        }
        String normalized = input.trim().toLowerCase(Locale.ROOT);
        return "cls".equals(normalized) || "clc".equals(normalized)
                || "clear".equals(normalized) || normalized.startsWith("clear ");
    }

    /**
     * Clears process state after a child process ends.
     *
     * @param ide the IDE controller
     */
    public static void onProgramFinished(UI_Main ide) {
        ide.runningProcess = null;
        ide.processWriter = null;
        ide.programRunning = false;
    }

    /**
     * Force-stops a running child process.
     *
     * @param ide the IDE controller
     */
    public static void stopProgram(UI_Main ide) {
        if (ide.runningProcess != null && ide.programRunning) {
            ide.runningProcess.destroyForcibly();
            onProgramFinished(ide);
        }
    }

    /**
     * Paints a prompt if one is not already showing.
     *
     * @param ide the IDE controller
     */
    public static void appendNextPrompt(UI_Main ide) {
        CLI_Main.appendPrompt();
    }

    /**
     * Appends text in the error colour.
     *
     * @param ide  the IDE controller
     * @param text the message
     */
    public static void appendErrorText(UI_Main ide, String text) {
        if (ide == null || ide.console == null || text == null) {
            return;
        }
        Platform.runLater(() -> {
            String previousStyle = ide.console.getStyle();
            try {
                ide.console.setStyle((previousStyle == null ? "" : previousStyle + "; ")
                        + "-fx-text-fill: #c62828;");
                CLI_Main.appendOutput(text);
            } finally {
                ide.console.setStyle(previousStyle == null ? "" : previousStyle);
            }
        });
    }
}
