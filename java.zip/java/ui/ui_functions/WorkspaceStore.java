package ui.ui_functions;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableView;

/**
 * The single active workspace behind the Variable Explorer.
 *
 * <h3>Why this exists</h3>
 * The Explorer is the central data-governing system, so exactly one component
 * may own its rows. Before, three different paths wrote into
 * {@code ide.varTable}: this store's ancestor in {@code CLI_Main}, the
 * {@code .dict} pipeline in {@code IDEVariableService}, and
 * {@code UI_Main.refreshVariablesForOpenTabs}. They disagreed about the schema
 * and about ownership, which is what produced the duplicate rows.
 *
 * <h3>Guarantees</h3>
 * <ul>
 *   <li><b>One variable, one row.</b> Rows are keyed by the cleaned name, so a
 *       duplicate is not merely avoided, it is unrepresentable.</li>
 *   <li><b>Redefining replaces.</b> A script sets {@code A=5}, the CLI then
 *       sets {@code A=7}; the same row updates in place.</li>
 *   <li><b>Nothing is dropped on a re-run.</b> {@link #sync(List)} takes the
 *       interpreter's full workspace, so re-running a script updates its
 *       variables and leaves everything else standing. Only
 *       {@link #clearAll()} and {@link #remove(String)} take rows away, and
 *       both are reached only from the {@code clear} command.</li>
 *   <li><b>Row identity is preserved</b> where content did not change, so the
 *       table keeps its scroll position and selection across refreshes.</li>
 * </ul>
 */
public final class WorkspaceStore {

    private static final WorkspaceStore INSTANCE = new WorkspaceStore();

    private final ObservableList<Variable> rows = FXCollections.observableArrayList();

    private WorkspaceStore() {
    }

    /** @return the process-wide workspace (one active workspace by design) */
    public static WorkspaceStore get() {
        return INSTANCE;
    }

    /**
     * Binds the Explorer table to this store. After this call nothing else may
     * call {@code setItems} on that table.
     *
     * @param table the Variable Explorer table
     */
    public void bind(TableView<Variable> table) {
        if (table != null) {
            table.setItems(rows);
        }
    }

    /** @return the live row list (read-only use only) */
    public ObservableList<Variable> rows() {
        return rows;
    }

    /**
     * Replaces the workspace with the interpreter's current state, updating
     * rows in place wherever possible.
     *
     * @param incoming every variable the interpreter currently holds, in its
     *                 own insertion order
     */
    public void sync(List<Variable> incoming) {
        if (incoming == null) {
            return;
        }
        runOnFxThread(() -> applySync(incoming));
    }

    /** Empties the workspace. Only the {@code clear} command may call this. */
    public void clearAll() {
        runOnFxThread(rows::clear);
    }

    /**
     * Removes one variable. Only {@code clear <name>} may call this.
     *
     * @param cleanedName the cleaned (internal) name
     */
    public void remove(String cleanedName) {
        if (cleanedName == null || cleanedName.isBlank()) {
            return;
        }
        runOnFxThread(() -> rows.removeIf(v -> cleanedName.equals(v.getName())));
    }

    /**
     * @param cleanedName the cleaned (internal) name
     * @return true when the workspace already holds that variable
     */
    public boolean contains(String cleanedName) {
        if (cleanedName == null) {
            return false;
        }
        for (Variable row : rows) {
            if (cleanedName.equals(row.getName())) {
                return true;
            }
        }
        return false;
    }

    // -----------------------------------------------------------------
    // Internals
    // -----------------------------------------------------------------

    private void applySync(List<Variable> incoming) {
        // Collapse the incoming list by name first. The interpreter should never
        // send the same name twice, but a hand-edited variables.txt can, and the
        // Explorer must not be the place where that becomes visible.
        Map<String, Variable> wanted = new LinkedHashMap<>();
        for (Variable variable : incoming) {
            if (variable != null && variable.getName() != null && !variable.getName().isBlank()) {
                wanted.put(variable.getName(), variable);
            }
        }

        // 1. Drop rows the interpreter no longer has.
        rows.removeIf(row -> !wanted.containsKey(row.getName()));

        // 2. Update or append, keeping the interpreter's ordering.
        int index = 0;
        for (Variable variable : wanted.values()) {
            int existing = indexOfName(variable.getName());
            if (existing < 0) {
                rows.add(Math.min(index, rows.size()), variable);
            } else {
                if (!rows.get(existing).sameContentAs(variable)) {
                    rows.set(existing, variable);
                }
                if (existing != index) {
                    Variable moved = rows.remove(existing);
                    rows.add(Math.min(index, rows.size()), moved);
                }
            }
            index++;
        }
    }

    private int indexOfName(String cleanedName) {
        for (int i = 0; i < rows.size(); i++) {
            if (cleanedName.equals(rows.get(i).getName())) {
                return i;
            }
        }
        return -1;
    }

    private static void runOnFxThread(Runnable action) {
        if (Platform.isFxApplicationThread()) {
            action.run();
        } else {
            Platform.runLater(action);
        }
    }

    /** @return a defensive copy of the current rows */
    public List<Variable> snapshot() {
        return new ArrayList<>(rows);
    }
}
