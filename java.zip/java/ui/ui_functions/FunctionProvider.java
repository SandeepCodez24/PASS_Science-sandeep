package ui.ui_functions;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

// Category function lists (each file lives in the suggestions_list sub-package)
import ui.ui_functions.suggestions_list.basic_math_list;
import ui.ui_functions.suggestions_list.log_number_list;
import ui.ui_functions.suggestions_list.logical_conditional_list;
import ui.ui_functions.suggestions_list.trigonometric_list;
import ui.ui_functions.suggestions_list.hyperbolic_list;
import ui.ui_functions.suggestions_list.geometric_list;
import ui.ui_functions.suggestions_list.statistical_list;
import ui.ui_functions.suggestions_list.matrix_list;
import ui.ui_functions.suggestions_list.numpy_list;
import ui.ui_functions.suggestions_list.calculus_list;
import ui.ui_functions.suggestions_list.vector_list;
import ui.ui_functions.suggestions_list.text_collections_list;

// Library function files (NumPy, SciPy, ...) kept beside the text colours
import language.syntax.textcolours.library.FunctionLibraries;
import language.syntax.syntax_checker.functions.BuiltinSignatures;

/**
 * FunctionProvider - Provides all available math, statistical, and geometric
 * functions
 * for the UPI language suggestion system.
 * 
 * Functions are organized by category and can be retrieved:
 * 1. First priority: Variables (discovered from code)
 * 2. Second priority: Functions (sorted alphabetically)
 *
 * NOTE: The actual list of addFunction(...) entries for each category now
 * lives in its own file inside the "suggestions_list" sub-package. To add a
 * new category in the future:
 * 1. Create a new *_list.java file in suggestions_list with a register() method.
 * 2. Add one line for it inside initializeFunctions() below.
 *
 * <h3>Library functions</h3>
 * The NumPy / SciPy style lists live in
 * {@code language/syntax/textcolours/library/}. Every file listed in
 * {@code FunctionLibraries.ALL} is registered here, so its names reach the
 * suggestion box, and are coloured as function calls, with no edit to this
 * class.
 *
 * <h3>Duplicates</h3>
 * {@link #addFunction(String, String, String)} ignores a signature that is
 * already registered, so a library may list a function a category file
 * also has ({@code sin}, {@code det}) without it appearing twice.
 *
 * <h3>Editor colouring</h3>
 * This class is also the single source of truth for which words the editor
 * paints as built-in functions (dark orchid). {@link #getDefaultFunctionNames()}
 * hands the bare names to {@code language.syntax.SyntaxPalette}, so the two
 * lines described above remain the ONLY edit needed when a category is added
 * or removed -- the highlighting follows automatically, with nothing to keep
 * in sync anywhere else.
 */
public class FunctionProvider {
    private static final Map<String, String> functionDescriptions = new HashMap<>();
    private static final Map<String, String> functionDisplayNames = new HashMap<>();
    private static final List<String> allFunctions = new ArrayList<>();

    /**
     * What a name has to look like before the editor will treat it as a
     * colourable built-in: a normal identifier.
     *
     * <p>
     * This is what keeps the operator entries registered by
     * {@code logical_conditional_list} ({@code &&}, {@code ||}, {@code ==},
     * {@code !=}) out of the highlighting set. They are registered as functions
     * for the suggestion popup's benefit, but they are not words and must not
     * end up inside a {@code \b(...)\b} alternation.
     */
    private static final Pattern IDENTIFIER_SHAPE = Pattern.compile("[A-Za-z_][A-Za-z0-9_]*");

    static {
        initializeFunctions();
    }

    /**
     * Initialize all available functions with descriptions.
     * Each category registers its own functions from its dedicated file.
     */
    private static void initializeFunctions() {
        basic_math_list.register();
        log_number_list.register();
        logical_conditional_list.register();
        trigonometric_list.register();
        hyperbolic_list.register();
        geometric_list.register();
        statistical_list.register();
        matrix_list.register();
        calculus_list.register();
        vector_list.register();
        numpy_list.register();
        text_collections_list.register();

        // NumPy, SciPy and any later library file.
        for (String[] entry : FunctionLibraries.entries()) {
            addFunction(entry[0], entry.length > 1 && entry[1] != null ? entry[1] : "Library function");
        }

        // Every function of the usage table (BuiltinSignatures) is offered,
        // even one no category file lists.
        Set<String> listed = getDefaultFunctionNames();
        for (BuiltinSignatures.Signature sig : BuiltinSignatures.all()) {
            if (!listed.contains(sig.name())) {
                String usage = sig.usage();
                int call = usage.indexOf(sig.name() + "(");
                addFunction(call >= 0 ? usage.substring(call) : sig.name() + "()", sig.description());
            }
        }

        // Sort all functions alphabetically
        Collections.sort(allFunctions);
    }

    /**
     * Add a function with description to the provider.
     * Uses default display name (same as function name).
     *
     * Made public so the category files in the "suggestions_list" sub-package
     * can register their functions here.
     */
    public static void addFunction(String functionName, String description) {
        addFunction(functionName, description, functionName);
    }

    /**
     * Add a function with description and custom display name.
     * The functionName is used for internal matching/filtering,
     * while displayName is shown to the user.
     *
     * Made public so the category files in the "suggestions_list" sub-package
     * can register their functions here. A signature that is already
     * registered is ignored, so the first description wins.
     */
    public static void addFunction(String functionName, String description, String displayName) {
        if (functionName == null || allFunctions.contains(functionName)) {
            return;
        }
        allFunctions.add(functionName);
        functionDescriptions.put(functionName, description);
        functionDisplayNames.put(functionName, displayName);
    }

    /**
     * Get description for a function. A function of the usage table
     * ({@link BuiltinSignatures}) is described by its usage, then what it
     * does - {@code allclose(A, B, atol=0.1, rtol=0) - true if ...} - in the
     * editor's popup and the Command Window's alike.
     */
    public static String getFunctionDescription(String functionName) {
        BuiltinSignatures.Signature sig = BuiltinSignatures.find(extractFunctionName(functionName));
        if (sig != null) {
            return sig.oneLine();
        }
        return functionDescriptions.getOrDefault(functionName, "User-defined function");
    }

    /**
     * Get display name for a function (what's shown to users).
     * Falls back to function name if no custom display name is set. A
     * function of the usage table shows its bare name; its usage is in the
     * description.
     */
    public static String getFunctionDisplayName(String functionName) {
        String bare = extractFunctionName(functionName);
        if (bare != null && BuiltinSignatures.find(bare) != null) {
            return bare;
        }
        return functionDisplayNames.getOrDefault(functionName, functionName);
    }

    /**
     * Get all available function keys (internal names used for matching).
     * Returns internal keys like "if_not", "while_not", "start_interval_end"
     */
    public static List<String> getAllFunctions() {
        return new ArrayList<>(allFunctions);
    }

    /**
     * Get all available function keys (internal names used for matching).
     * Same as getAllFunctions() - kept for compatibility.
     */
    public static List<String> getAllFunctionKeys() {
        return new ArrayList<>(allFunctions);
    }

    /**
     * Every registered built-in function, reduced to its bare name and stripped
     * of anything that is not a word.
     *
     * <p>
     * {@code "sqrt(x)"} becomes {@code "sqrt"}, {@code "pseudo_inverse(A)"}
     * becomes {@code "pseudo_inverse"}; {@code "&&"} and {@code "=="} are
     * dropped entirely. The result is fed straight into the tokenizer's
     * built-in-function pattern, so whatever the ten {@code *_list.java} files
     * register is exactly what the editor paints.
     *
     * <p>
     * Insertion order is preserved (the backing list is sorted alphabetically
     * at startup) and the returned set is a fresh copy, so a caller can neither
     * see nor cause a later change.
     *
     * @return bare, identifier-shaped names of all registered functions
     */
    public static Set<String> getDefaultFunctionNames() {
        Set<String> names = new LinkedHashSet<>();
        for (String signature : allFunctions) {
            if (signature == null) {
                continue;
            }
            String name = extractFunctionName(signature);
            if (name != null && IDENTIFIER_SHAPE.matcher(name).matches()) {
                names.add(name);
            }
        }
        return names;
    }

    /**
     * Get filtered functions by prefix (alphabetically sorted).
     * Returns internal keys for matching and insertion.
     * Display names are obtained separately via getFunctionDisplayName().
     * Handles both word prefixes (sin, mean, etc.) and operator patterns (&&, ||,
     * etc.)
     * 
     * @param input the prefix or operator pattern to match
     * @return matching function keys (internal names) sorted alphabetically
     */
    public static List<String> getFilteredFunctions(String input) {
        if (input == null || input.trim().isEmpty()) {
            return new ArrayList<>();
        }

        String lowerInput = input.toLowerCase();

        // For operator patterns (&&, ||, ==, !=, single &, |, =, !), find exact or
        // prefix matches
        if (input.length() <= 2) {
            return allFunctions.stream()
                    .filter(f -> f.equalsIgnoreCase(input) || f.toLowerCase().startsWith(lowerInput))
                    .limit(15)
                    .collect(Collectors.toList());
        }

        // For word patterns, use startsWith matching
        return allFunctions.stream()
                .filter(f -> f.toLowerCase().startsWith(lowerInput))
                .limit(15) // Limit to 15 suggestions
                .collect(Collectors.toList());
    }

    /**
     * Get suggestions with priority: Variables first, then Functions
     * (alphabetical).
     * Returns internal function keys (not display names).
     * 
     * @param input               the search prefix
     * @param discoveredVariables set of variable names discovered from code
     * @return sorted suggestions list with variables first
     */
    public static List<String> getSuggestionsWithPriority(String input, Set<String> discoveredVariables) {
        List<String> result = new ArrayList<>();

        if (input == null || input.trim().isEmpty()) {
            return result;
        }

        String lowerInput = input.toLowerCase();

        // Priority 1: Add matching variables first
        if (discoveredVariables != null) {
            discoveredVariables.stream()
                    .filter(v -> v.toLowerCase().startsWith(lowerInput))
                    .sorted()
                    .forEach(result::add);
        }

        // Priority 2: Add matching functions (alphabetically sorted by key)
        allFunctions.stream()
                .filter(f -> f.toLowerCase().startsWith(lowerInput))
                .forEach(result::add);

        // Limit total results to 15
        return result.stream().limit(15).collect(Collectors.toList());
    }

    /**
     * Check if a function exists.
     */
    public static boolean isFunctionExists(String functionName) {
        return allFunctions.contains(functionName);
    }

    /**
     * Get total number of available functions.
     */
    public static int getTotalFunctionCount() {
        return allFunctions.size();
    }

    /**
     * Get functions by category prefix (returns internal keys).
     * Examples: "char_", "sin", "std_dev"
     */
    public static List<String> getFunctionsByCategory(String categoryPrefix) {
        String lowerPrefix = categoryPrefix.toLowerCase();
        return allFunctions.stream()
                .filter(f -> f.toLowerCase().startsWith(lowerPrefix))
                .collect(Collectors.toList());
    }

    /**
     * Extract function name from function signature (internal key).
     * Examples: "sin(x)" → "sin", "add(a,b)" → "add", "char_circle(r)" →
     * "char_circle"
     */
    public static String extractFunctionName(String functionSignature) {
        int parenIdx = functionSignature.indexOf('(');
        if (parenIdx != -1) {
            return functionSignature.substring(0, parenIdx);
        }
        // Handle special cases with colons (e.g., "start:interval:end")
        int colonIdx = functionSignature.indexOf(':');
        if (colonIdx != -1) {
            return "start_interval_end"; // Return the internal key
        }
        return functionSignature;
    }

    /**
     * Check if a function name represents a notation/operator (not a function
     * call).
     * Notations like &&, ||, ==, !=, if, for, while, etc. are not called with
     * parentheses.
     */
    public static boolean isNotation(String functionName) {
        // Match internal keys that are operators/notations without parentheses
        return functionName != null && functionName.matches(
                "(&&|\\|\\||==|!=|not|if|for|while|in|not in|start_interval_end|is_empty|is_nan|if_not|while_not)");
    }

    /**
     * Get function template with empty parameters.
     * For notations: "if", "while", "&&" → no parentheses added
     */
    public static String getFunctionTemplate(String functionSignature) {
        String name = extractFunctionName(functionSignature);
        // Don't add parentheses for notations/operators
        if (isNotation(name)) {
            return name;
        }
        return name + "()";
    }
}
