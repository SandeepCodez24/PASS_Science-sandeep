package ui.ui_functions;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * FunctionProvider - Provides all available math, statistical, and geometric
 * functions
 * for the UPI language suggestion system.
 * 
 * Functions are organized by category and can be retrieved:
 * 1. First priority: Variables (discovered from code)
 * 2. Second priority: Functions (sorted alphabetically)
 */
public class FunctionProvider {

    private static final Map<String, String> functionDescriptions = new HashMap<>();
    private static final Map<String, String> functionDisplayNames = new HashMap<>();
    private static final List<String> allFunctions = new ArrayList<>();

    static {
        initializeFunctions();
    }

    /**
     * Initialize all available functions with descriptions.
     */
    private static void initializeFunctions() {
        // ========== BASIC MATH FUNCTIONS ==========
        addFunction("sqrt(x)", "Square root");
        addFunction("cbrt(x)", "Cube root");
        addFunction("sqr(x)", "Square a number");
        addFunction("cube(x)", "Cube a number");
        // ========== LOG & NUMBER FUNCTIONS ==========
        addFunction("log(x)", "Natural logarithm");
        addFunction("e^(x)", "Exponential - e^x");
        addFunction("|x|", "Absolute value");
        addFunction("frac2deci(x)", "Fraction to decimal");
        addFunction("deci2frac(x)", "Decimal to fraction");

        // ========== LOGICAL & CONDITIONAL FUNCTIONS ==========
        addFunction("&&", "Logical AND", "&&");
        addFunction("||", "Logical OR", "||");
        addFunction("not", "Logical NOT", "not");
        addFunction("if", "IF statement", "if");
        addFunction("if_not", "IF NOT statement", "if not");
        addFunction("for", "FOR loop", "for");
        addFunction("while", "while loop", "while");
        addFunction("while_not", "while not loop", "while not");
        addFunction("==", "Check equality", "==");
        addFunction("!=", "Check inequality", "!=");
        addFunction("is_empty", "Check if empty", "is empty");
        addFunction("is_nan", "Check if NaN", "is nan");
        addFunction("in", "Check if in list", "in");
        addFunction("not_in", "Check if not in list", "not in");
        addFunction("start_interval_end", "Create range", "start:interval:end");

        // ========== TRIGONOMETRIC FUNCTIONS ==========
        addFunction("sin(x)", "Sine function");
        addFunction("cos(x)", "Cosine function");
        addFunction("tan(x)", "Tangent function");
        addFunction("cosec(x)", "Cosecant function");
        addFunction("sec(x)", "Secant function");
        addFunction("cot(x)", "Cotangent function");
        addFunction("inv_sin(x)", "Inverse sine (arcsin)");
        addFunction("inv_cos(x)", "Inverse cosine (arccos)");
        addFunction("inv_tan(x)", "Inverse tangent (arctan)");
        addFunction("inv_cosec(x)", "Inverse cosecant");
        addFunction("inv_sec(x)", "Inverse secant");
        addFunction("inv_cot(x)", "Inverse cotangent");

        // ========== HYPERBOLIC FUNCTIONS ==========
        addFunction("sinh(x)", "Hyperbolic sine");
        addFunction("cosh(x)", "Hyperbolic cosine");
        addFunction("tanh(x)", "Hyperbolic tangent");
        addFunction("cosech(x)", "Hyperbolic cosecant");
        addFunction("sech(x)", "Hyperbolic secant");
        addFunction("coth(x)", "Hyperbolic cotangent");

        // ========== GEOMETRIC FUNCTIONS ==========
        addFunction("Char_Circle(r)", "Characteristics of circle");
        addFunction("Char_Square(a)", "Characteristics of square");
        addFunction("Char_Triangle(a)", "Characteristics of triangle");
        addFunction("Char_Pentagon(a)", "Characteristics of pentagon");
        addFunction("Char_Hexagon(a)", "Characteristics of hexagon");
        addFunction("Char_Heptagon(a)", "Characteristics of heptagon");
        addFunction("Char.Nonagon(a)", "Characteristics of nonagon");
        addFunction("Char_Rhombus(a,theta)", "Characteristics of rhombus");
        addFunction("Char_Semicircle(r)", "Characteristics of semicircle");
        addFunction("Char_Rtriangle(b,h)", "Characteristics of right triangle");
        addFunction("Char_Rectangle(b,h)", "Characteristics of rectangle");
        addFunction("Char_Polygon(a,n)", "Characteristics of n-sided polygon");
        addFunction("Char_Trapezoid(a,b,h)", "Characteristics of trapezoid");
        addFunction("Char_Cube(a)", "Characteristics of cube");
        addFunction("Char_Sphere(r)", "Characteristics of sphere");
        addFunction("Char_Cylinder(r,h)", "Characteristics of cylinder");
        addFunction("Char_Cone(r,h)", "Characteristics of cone");
        addFunction("Char_Ellipse(a,b)", "Characteristics of ellipse");

        // ========== STATISTICAL FUNCTIONS ==========
        addFunction("Mean(A)", "Mean/Average");
        addFunction("Median(A)", "Median");
        addFunction("Mode(A)", "Mode");
        addFunction("Geo_Mean(A)", "Geometric mean");
        addFunction("Harmo_Mean(A)", "Harmonic mean");
        addFunction("Trim_Mean(A)", "Trimmed mean");
        addFunction("VAR(A)", "Variance");
        addFunction("SD(A)", "Standard deviation");
        addFunction("Coeff_Var(A)", "Coefficient of variation");
        addFunction("Skew(A)", "Skewness");
        addFunction("Corr_Coeff(A)", "Correlation coefficient");
        addFunction("Co_Var(A)", "Covariance");
        addFunction("LSM(A)", "Least squares method");
        addFunction("Null_Hypo(A)", "Null hypothesis test");
        addFunction("P_val_cal(A)", "P-value");
        addFunction("Chi_Test(A)", "Chi-square test");
        addFunction("Norm(A)", "Normalize data");

        // ========== MATRIX FUNCTIONS ==========
        addFunction("Rank(A)", "Matrix rank");
        addFunction("Transpose(A)", "Transpose matrix");
        addFunction("Conjugate(A)", "Conjugate matrix");
        addFunction("Pseudo_inverse(A)", "Pseudo-inverse");
        addFunction("Det(A)", "Matrix determinant");
        addFunction("Adj(A)", "Adjoint matrix");
        addFunction("Had_prod(A)", "Hadamard product");
        addFunction("Inverse(A)", "Matrix inverse");
        addFunction("Norm(A)", "Matrix norm");
        addFunction("Diag(n)", "Diagonal matrix");
        addFunction("Upper_triangular(A)", "Upper triangular");
        addFunction("Zero_matrix(n)", "Zero matrix");
        addFunction("Full_rank_matrix(A)", "Check full rank");
        addFunction("Singular_matrix(A)", "Check singular");
        addFunction("Pd_matrix(A)", "Positive definite");
        addFunction("Nd_matrix(A)", "Negative definite");
        addFunction("Unit_matrix(n)", "Unit/Identity matrix");

        // ========== CALCULUS FUNCTIONS ==========
        addFunction("Ddt(f)", "Derivative");
        addFunction("Pddt(f)", "Partial derivative");
        addFunction("Continuity(f)", "Check continuity");
        addFunction("Grad(f)", "Gradient");
        addFunction("Curl(F)", "Curl of vector field");
        addFunction("divergence(F)", "Divergence of vector field");
        addFunction("Laplace(f)", "Laplacian operator");
        addFunction("Green_Integral(f)", "Green's theorem integral");
        addFunction("Stokes_Integral(f)", "Stokes' theorem integral");
        addFunction("Taylor_series(f)", "Taylor series expansion");
        addFunction("Rad_of_Con(f)", "Radius of convergence");

        // ========== VECTOR FUNCTIONS ==========
        addFunction("unit_vector(v)", "Unit vector");
        addFunction("Norm(v)", "Vector norm");
        addFunction("Dircos(v)", "Direction cosines");
        addFunction("Vector_TP(v)", "Vector triple product");
        addFunction("Proj(a,b)", "Vector projection");
        addFunction("Proj_Vec(a)", "Projection vector");
        addFunction("Orthogonal(v)", "Check orthogonal");
        addFunction("Orthonormal(v)", "Check orthonormal");
        addFunction("Eigen_Vector(A)", "Eigenvector");
        addFunction("Eigen_Value(A)", "Eigenvalue");

        // Sort all functions alphabetically
        Collections.sort(allFunctions);
    }

    /**
     * Add a function with description to the provider.
     * Uses default display name (same as function name).
     */
    private static void addFunction(String functionName, String description) {
        addFunction(functionName, description, functionName);
    }

    /**
     * Add a function with description and custom display name.
     * The functionName is used for internal matching/filtering,
     * while displayName is shown to the user.
     */
    private static void addFunction(String functionName, String description, String displayName) {
        allFunctions.add(functionName);
        functionDescriptions.put(functionName, description);
        functionDisplayNames.put(functionName, displayName);
    }

    /**
     * Get description for a function.
     */
    public static String getFunctionDescription(String functionName) {
        return functionDescriptions.getOrDefault(functionName, "User-defined function");
    }

    /**
     * Get display name for a function (what's shown to users).
     * Falls back to function name if no custom display name is set.
     */
    public static String getFunctionDisplayName(String functionName) {
        return functionDisplayNames.getOrDefault(functionName, functionName);
    }

    /**
     * Get all available function keys (internal names used for matching).
     * Returns internal keys like "if_not", "while_not", "start_interval_end"
     */
    public static List<String> getAllFunctions() {
        return new ArrayList<>(allFunctions);
    }

    /**
     * Get all available function keys (internal names used for matching).
     * Same as getAllFunctions() - kept for compatibility.
     */
    public static List<String> getAllFunctionKeys() {
        return new ArrayList<>(allFunctions);
    }

    /**
     * Get filtered functions by prefix (alphabetically sorted).
     * Returns internal keys for matching and insertion.
     * Display names are obtained separately via getFunctionDisplayName().
     * Handles both word prefixes (sin, mean, etc.) and operator patterns (&&, ||,
     * etc.)
     * 
     * @param input the prefix or operator pattern to match
     * @return matching function keys (internal names) sorted alphabetically
     */
    public static List<String> getFilteredFunctions(String input) {
        if (input == null || input.trim().isEmpty()) {
            return new ArrayList<>();
        }

        String lowerInput = input.toLowerCase();

        // For operator patterns (&&, ||, ==, !=, single &, |, =, !), find exact or
        // prefix matches
        if (input.length() <= 2) {
            return allFunctions.stream()
                    .filter(f -> f.equalsIgnoreCase(input) || f.toLowerCase().startsWith(lowerInput))
                    .limit(15)
                    .collect(Collectors.toList());
        }

        // For word patterns, use startsWith matching
        return allFunctions.stream()
                .filter(f -> f.toLowerCase().startsWith(lowerInput))
                .limit(15) // Limit to 15 suggestions
                .collect(Collectors.toList());
    }

    /**
     * Get suggestions with priority: Variables first, then Functions
     * (alphabetical).
     * Returns internal function keys (not display names).
     * 
     * @param input               the search prefix
     * @param discoveredVariables set of variable names discovered from code
     * @return sorted suggestions list with variables first
     */
    public static List<String> getSuggestionsWithPriority(String input, Set<String> discoveredVariables) {
        List<String> result = new ArrayList<>();

        if (input == null || input.trim().isEmpty()) {
            return result;
        }

        String lowerInput = input.toLowerCase();

        // Priority 1: Add matching variables first
        if (discoveredVariables != null) {
            discoveredVariables.stream()
                    .filter(v -> v.toLowerCase().startsWith(lowerInput))
                    .sorted()
                    .forEach(result::add);
        }

        // Priority 2: Add matching functions (alphabetically sorted by key)
        allFunctions.stream()
                .filter(f -> f.toLowerCase().startsWith(lowerInput))
                .forEach(result::add);

        // Limit total results to 15
        return result.stream().limit(15).collect(Collectors.toList());
    }

    /**
     * Check if a function exists.
     */
    public static boolean isFunctionExists(String functionName) {
        return allFunctions.contains(functionName);
    }

    /**
     * Get total number of available functions.
     */
    public static int getTotalFunctionCount() {
        return allFunctions.size();
    }

    /**
     * Get functions by category prefix (returns internal keys).
     * Examples: "char_", "sin", "std_dev"
     */
    public static List<String> getFunctionsByCategory(String categoryPrefix) {
        String lowerPrefix = categoryPrefix.toLowerCase();
        return allFunctions.stream()
                .filter(f -> f.toLowerCase().startsWith(lowerPrefix))
                .collect(Collectors.toList());
    }

    /**
     * Extract function name from function signature (internal key).
     * Examples: "sin(x)" → "sin", "add(a,b)" → "add", "char_circle(r)" →
     * "char_circle"
     */
    public static String extractFunctionName(String functionSignature) {
        int parenIdx = functionSignature.indexOf('(');
        if (parenIdx != -1) {
            return functionSignature.substring(0, parenIdx);
        }
        // Handle special cases with colons (e.g., "start:interval:end")
        int colonIdx = functionSignature.indexOf(':');
        if (colonIdx != -1) {
            return "start_interval_end"; // Return the internal key
        }
        return functionSignature;
    }

    /**
     * Check if a function name represents a notation/operator (not a function
     * call).
     * Notations like &&, ||, ==, !=, if, for, while, etc. are not called with
     * parentheses.
     */
    public static boolean isNotation(String functionName) {
        // Match internal keys that are operators/notations without parentheses
        return functionName != null && functionName.matches(
                "(&&|\\|\\||==|!=|not|if|for|while|in|not_in|start_interval_end|is_empty|is_nan|if_not|while_not)");
    }

    /**
     * Get function template with empty parameters.
     * For notations: "if", "while", "&&" → no parentheses added
     */
    public static String getFunctionTemplate(String functionSignature) {
        String name = extractFunctionName(functionSignature);
        // Don't add parentheses for notations/operators
        if (isNotation(name)) {
            return name;
        }
        return name + "()";
    }
}
