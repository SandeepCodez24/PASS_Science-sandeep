package ui.ui_functions.suggestions_list;

import ui.ui_functions.FunctionProvider;

/**
 * numpy_list - Registers all NUMPY and matrix/vector functions
 * into the FunctionProvider suggestion system.
 */
public class numpy_list {

    public static void register() {

    // ========== CREATING ARRAYS ==========
        FunctionProvider.addFunction("ones(size)", "matrix of ones: ones(n) is n x n, ones([m, n]) is m x n");
        FunctionProvider.addFunction("zeros(size)", "matrix of zeros: zeros(n) is n x n, zeros([m, n]) is m x n");

    // ========== MATRIX FUNCTIONS ==========
        FunctionProvider.addFunction("rank(A)", "linearly independent rows (or columns)");
        FunctionProvider.addFunction("det(A)", "determinant of a square matrix A");
        FunctionProvider.addFunction("transpose(A)", "rows and columns of A swapped");
        FunctionProvider.addFunction("inv(A)", "inverse of a square matrix A");
        FunctionProvider.addFunction("pinv(A)", "pseudo-inverse of any matrix A");
        FunctionProvider.addFunction("adj(A)", "transposed cofactor matrix");
        FunctionProvider.addFunction("had_prod(A, B)", "Hadamard (element-wise) product");
        FunctionProvider.addFunction("matrix_norm(A[, ord])", "matrix norm: Frobenius by default");
        FunctionProvider.addFunction("trace(A)", "sum of the main-diagonal elements");
        FunctionProvider.addFunction("diag(x)", "diagonal of A as a column");
        FunctionProvider.addFunction("upper_triangular(x)", " n x n upper triangle of ones");
        FunctionProvider.addFunction("lower_triangular(x)", " n x n lower triangle of ones");
        FunctionProvider.addFunction("zero_matrix(x)", "n x n zeros; zeros the size of A");
        FunctionProvider.addFunction("unit_matrix(n)", "n x n identity matrix");
        FunctionProvider.addFunction("full_rank_matrix(A)", "true if A has full rank");
        FunctionProvider.addFunction("singular_matrix(A)", "true if the square matrix A is singular");
        FunctionProvider.addFunction("pd_matrix(A)", "true if A is positive definite");
        FunctionProvider.addFunction("nd_matrix(A)", "true if A is negative definite");
        FunctionProvider.addFunction("onlyrows(A)", "the rows of A as a list");
        FunctionProvider.addFunction("onlycols(A)", "the columns of A as a list");
        FunctionProvider.addFunction("power(A, n)", "every element of A raised to n");

    // ========== ELEMENT-WISE MATH (NUMBER, VECTOR OR MATRIX; THE SHAPE IS KEPT) ==========
        FunctionProvider.addFunction("max(A[, B])", "largest element; max(A) & max(A, B)");
        FunctionProvider.addFunction("min(A[, B])", "smallest element; min(A, B) & min(A)");
        FunctionProvider.addFunction("fmax(A, B)", "element-wise larger value, ignoring NaN");
        FunctionProvider.addFunction("fmin(A, B)", "element-wise smaller value, ignoring NaN");
        FunctionProvider.addFunction("exp(x)", "e raised to each element");
        FunctionProvider.addFunction("exp2(x)", "2 raised to each element");
        FunctionProvider.addFunction("expN(x)", "N raised to each element");
        FunctionProvider.addFunction("log1p(x)", "log(1 + x) per element");
        FunctionProvider.addFunction("logaddexp(A, B)", "log(exp(A) + exp(B)) per element");
        FunctionProvider.addFunction("logaddexp2(A, B)", "log2(2^A + 2^B) per element");
        FunctionProvider.addFunction("logaddexpN(A, B)", "log base N of (N^A + N^B) per element");
        FunctionProvider.addFunction("inv_tan2(Y, X)", "four-quadrant inverse tangent of Y/X in radians, per element");
        FunctionProvider.addFunction("hypot(A, B)", "sqrt(A^2 + B^2) per element, without overflow");
        FunctionProvider.addFunction("anglewrap(theta)", "removes 2*pi jumps from a sequence of angles");
        FunctionProvider.addFunction("sinc(x)", "sin(pi*x)/(pi*x) per element, with sinc(0) = 1");
        FunctionProvider.addFunction("fabs(x)", "absolute value of each real element");
        FunctionProvider.addFunction("sign(x)", "-1, 0 or 1 by the sign of each element");
        FunctionProvider.addFunction("ceil(x)", "each element rounded up to a whole number");
        FunctionProvider.addFunction("floor(x)", "each element rounded down to a whole number");
        FunctionProvider.addFunction("round(x, n)", "each element rounded to n decimal places");
        FunctionProvider.addFunction("rint(x)", "each element rounded to the nearest whole number (ties to even)");
        FunctionProvider.addFunction("fix(x)", "each element rounded toward zero");
        FunctionProvider.addFunction("trunc(x)", "fractional part of each element dropped");
        FunctionProvider.addFunction("gcd(A[, B])", "greatest common divisor of all of A / element pairs of A & B");
        FunctionProvider.addFunction("lcm(A[, B])", "least common multiple of all of A / element pairs of A & B");
        FunctionProvider.addFunction("heaviside(x, h0)", "step function per element: 0 below 0, h0 at 0, 1 above");
        FunctionProvider.addFunction("copysign(x, s)", "magnitude of x with the sign of s, per element");
        FunctionProvider.addFunction("signbit(x)", "true where an element's sign bit is set (negative or -0)");
        FunctionProvider.addFunction("nextafter(x, y)", "next representable number after x towards y, per element");
        FunctionProvider.addFunction("spacing(x)", "distance from x to the next representable number, per element");
        FunctionProvider.addFunction("frexp(x)", "[m, e] = frexp(x): mantissa m (0.5 <= |m| < 1) and exponent e with x = m*2^e");
        FunctionProvider.addFunction("ldexp(m, e)", "m * 2^e per element");
        FunctionProvider.addFunction("modf(x)", "[frac, whole] = modf(x): fractional and whole parts of each element");
        FunctionProvider.addFunction("equal(A, B)", "true if A and B have the same size and the same elements");
        FunctionProvider.addFunction("equiv(A, B)", "true if A and B are equal once a single value, row or column is repeated to match");
        FunctionProvider.addFunction("isclose(A, B[, rtol, atol])", "element-wise true where |A-B| <= atol + rtol*|B| (defaults 1e-5, 1e-8)");
        FunctionProvider.addFunction("allclose(A, B[, rtol, atol])", "true if every element pair is close: |A-B| <= atol + rtol*|B|");

    // ========== COMPLEX NUMBERS ==========
        FunctionProvider.addFunction("conj(z)", "complex conjugate of each element");
        FunctionProvider.addFunction("real(z)", "real part of each element");
        FunctionProvider.addFunction("imag(z)", "imaginary part of each element");
        FunctionProvider.addFunction("img(z)", "imaginary part of each element (same as imag)");
        FunctionProvider.addFunction("angle(z)", "phase angle of each element in radians");

    // ========== PRODUCTS ==========
        FunctionProvider.addFunction("dot(A, B)", "dot product: sum of conj(A).*B as one number, or along dim (0 = per column, 1 = per row)");
        FunctionProvider.addFunction("inner(A, B)", "inner product: a number for two vectors, A*B' for matrices");
        FunctionProvider.addFunction("outer(a, b)", "outer product of the elements of a and b, as a matrix");
        FunctionProvider.addFunction("cross(a, b)", "cross product of 3-element vectors; for matrices per row (dim 1) or per column (dim 0)");
        FunctionProvider.addFunction("tensordot(A, B)", "axes 2 (default): sum of A.*B; axes 1: the matrix product A*B");
        FunctionProvider.addFunction("einsum(subscripts, A[, B, C])", "Einstein summation, e.g. einsum(\"ij,jk->ik\", A, B), einsum(\"ii\", A)");
        FunctionProvider.addFunction("kron(A, B)", "Kronecker product: every element of A times the whole of B");

    // ========== LINEAR ALGEBRA ==========
        FunctionProvider.addFunction("vector_norm(x[, ord])", "p-norm of all elements: ord 2 (default), 1, inf, -inf, 0 or any p");
        FunctionProvider.addFunction("slogdet(A)", "[sign, logdet] = slogdet(A): sign and log|det(A)|, safe from overflow");
        FunctionProvider.addFunction("solve(A, b)", "x with A*x = b, for a square invertible A");
        FunctionProvider.addFunction("lstsq(A, b)", "[x, residuals, rank, s] = lstsq(A, b): least-squares x minimising |A*x - b|");
        FunctionProvider.addFunction("eig(A)", "eigenvalues of A as a column; [V, D] = eig(A) gives eigenvectors V and diagonal D");
        FunctionProvider.addFunction("eigvr(A)", "right eigenvectors of A as columns (A*v = lambda*v), in the order of eig(A)");
        FunctionProvider.addFunction("eigvl(A)", "left eigenvectors of A as columns (w'*A = lambda*w'), in the order of eig(A)");
        FunctionProvider.addFunction("eig_ascend(A)", "eigenvalues of a symmetric (Hermitian) matrix, smallest first, as a column");
        FunctionProvider.addFunction("svd(A)", "singular values as a column; [U, S, V] = svd(A) gives A = U*S*V'");
        FunctionProvider.addFunction("svdvals(A)", "singular values of A, largest first, as a column");
        FunctionProvider.addFunction("qr(A)", "[Q, R] = qr(A): A = Q*R with Q orthogonal and R upper triangular; R = qr(A) gives R");
        FunctionProvider.addFunction("cholesky(A)", "lower-triangular L with A = L*L', for a symmetric positive definite A");
        FunctionProvider.addFunction("cond(A[, p])", "condition number of A: 2-norm by default, or p = 1, inf");
        FunctionProvider.addFunction("tensorinv(A)", "inverse of A (2-D form of the tensor inverse)");
        FunctionProvider.addFunction("tensorsolve(A, b)", "x with A*x = b (2-D form of the tensor solve)");
        FunctionProvider.addFunction("diagonal(A[, k])", "the k-th diagonal of A as a row (0 main, positive above, negative below)");

    // ========== POLYNOMIALS (COEFFICIENTS AS A ROW, HIGHEST POWER FIRST) ==========
        FunctionProvider.addFunction("convolve(a, v[, mode])", "convolution of two vectors; ");
        FunctionProvider.addFunction("polyfit(x, y, deg)", "least-squares polynomial of degree deg through the points (x, y)");
        FunctionProvider.addFunction("polyval(p, x)", "value of polynomial p at x (every element of x)");
        FunctionProvider.addFunction("poly1d(c)", "prints the polynomial with coefficients c and returns c");
        FunctionProvider.addFunction("roots(p)", "roots of polynomial p as a column (complex where needed)");
        FunctionProvider.addFunction("poly(r)", "polynomial with roots r, or the characteristic polynomial of a square matrix");
        FunctionProvider.addFunction("polyadd(p1, p2)", "sum of two polynomials");
        FunctionProvider.addFunction("polysub(p1, p2)", "difference p1 - p2 of two polynomials");
        FunctionProvider.addFunction("polymul(p1, p2)", "product of two polynomials");
        FunctionProvider.addFunction("polydiv(p1, p2)", "[q, r] = polydiv(p1, p2): quotient and remainder of polynomial division");
        FunctionProvider.addFunction("polyder(p[, m])", "m-th derivative of polynomial p (m = 1 by default)");

    }
}
