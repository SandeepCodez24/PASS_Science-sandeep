package ui.ui_functions.suggestions_list;

import ui.ui_functions.FunctionProvider;

/**
 * geometric_list - Registers all GEOMETRIC functions
 * into the FunctionProvider suggestion system.
 */
public class geometric_list {

    // ========== GEOMETRIC FUNCTIONS ==========
    public static void register() {
        FunctionProvider.addFunction("char_circle(r)", "Characteristics of circle");
        FunctionProvider.addFunction("char_square(a)", "Characteristics of square");
        FunctionProvider.addFunction("char_triangle(a)", "Characteristics of triangle");
        FunctionProvider.addFunction("char_pentagon(a)", "Characteristics of pentagon");
        FunctionProvider.addFunction("char_hexagon(a)", "Characteristics of hexagon");
        FunctionProvider.addFunction("char_heptagon(a)", "Characteristics of heptagon");
        FunctionProvider.addFunction("char_nonagon(a)", "Characteristics of nonagon");
        FunctionProvider.addFunction("char_rhombus(a,theta)", "Characteristics of rhombus");
        FunctionProvider.addFunction("char_semicircle(r)", "Characteristics of semicircle");
        FunctionProvider.addFunction("char_rtriangle(b,h)", "Characteristics of right triangle");
        FunctionProvider.addFunction("char_rectangle(b,h)", "Characteristics of rectangle");
        FunctionProvider.addFunction("char_polygon(a,n)", "Characteristics of n-sided polygon");
        FunctionProvider.addFunction("char_trapezoid(a,b,h)", "Characteristics of trapezoid");
        FunctionProvider.addFunction("char_cube(a)", "Characteristics of cube");
        FunctionProvider.addFunction("char_sphere(r)", "Characteristics of sphere");
        FunctionProvider.addFunction("char_cylinder(r,h)", "Characteristics of cylinder");
        FunctionProvider.addFunction("char_cone(r,h)", "Characteristics of cone");
        FunctionProvider.addFunction("char_ellipse(a,b)", "Characteristics of ellipse");
    }
}
