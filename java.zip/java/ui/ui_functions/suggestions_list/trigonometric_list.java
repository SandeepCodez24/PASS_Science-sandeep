package ui.ui_functions.suggestions_list;

import ui.ui_functions.FunctionProvider;

/**
 * trigonometric_list - Registers all TRIGONOMETRIC functions
 * into the FunctionProvider suggestion system.
 */
public class trigonometric_list {

    // ========== TRIGONOMETRIC FUNCTIONS ==========
    public static void register() {
        FunctionProvider.addFunction("sin(x)", "Sine function");
        FunctionProvider.addFunction("cos(x)", "Cosine function");
        FunctionProvider.addFunction("tan(x)", "Tangent function");
        FunctionProvider.addFunction("cosec(x)", "Cosecant function");
        FunctionProvider.addFunction("sec(x)", "Secant function");
        FunctionProvider.addFunction("cot(x)", "Cotangent function");
        FunctionProvider.addFunction("inv_sin(x)", "Inverse sine (arcsin)");
        FunctionProvider.addFunction("inv_cos(x)", "Inverse cosine (arccos)");
        FunctionProvider.addFunction("inv_tan(x)", "Inverse tangent (arctan)");
        FunctionProvider.addFunction("inv_cosec(x)", "Inverse cosecant");
        FunctionProvider.addFunction("inv_sec(x)", "Inverse secant");
        FunctionProvider.addFunction("inv_cot(x)", "Inverse cotangent");
    }
}
