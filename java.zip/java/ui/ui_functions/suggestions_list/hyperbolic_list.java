package ui.ui_functions.suggestions_list;

import ui.ui_functions.FunctionProvider;

/**
 * hyperbolic_list - Registers all HYPERBOLIC functions
 * into the FunctionProvider suggestion system.
 */
public class hyperbolic_list {

    // ========== HYPERBOLIC FUNCTIONS ==========
    public static void register() {
        FunctionProvider.addFunction("sinh(x)", "Hyperbolic sine");
        FunctionProvider.addFunction("cosh(x)", "Hyperbolic cosine");
        FunctionProvider.addFunction("tanh(x)", "Hyperbolic tangent");
        FunctionProvider.addFunction("cosech(x)", "Hyperbolic cosecant");
        FunctionProvider.addFunction("sech(x)", "Hyperbolic secant");
        FunctionProvider.addFunction("coth(x)", "Hyperbolic cotangent");
    }
}
