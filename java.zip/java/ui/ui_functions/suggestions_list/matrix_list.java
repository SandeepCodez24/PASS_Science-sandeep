package ui.ui_functions.suggestions_list;

import ui.ui_functions.FunctionProvider;

/**
 * matrix_list - Registers all MATRIX functions
 * into the FunctionProvider suggestion system.
 *
 * <p>
 * N-dimensional matrices: {@code reshape}, {@code shape}, {@code ndims} and
 * {@code deal} are new, and the {@code nexus*} family accepts an N-D size
 * ({@code nexus([2,3,4])}). Every other builtin works on 2-D matrices; apply
 * it to a 2-D slab such as {@code B[0]}. The descriptions are what the
 * suggestion popup and hover help show.
 */
public class matrix_list {

    // ========== MATRIX FUNCTIONS ==========
    public static void register() {
        FunctionProvider.addFunction("rank(A)", "Matrix rank");
        FunctionProvider.addFunction("transpose(A)", "Transpose matrix");
        FunctionProvider.addFunction("conjugate(A)", "Conjugate matrix");
        FunctionProvider.addFunction("det(A)", "Matrix determinant");
        FunctionProvider.addFunction("adj(A)", "Adjoint matrix");
        FunctionProvider.addFunction("had_prod(A, B)", "Hadamard product");
        FunctionProvider.addFunction("inv(A)", "Matrix inverse");
        FunctionProvider.addFunction("pseudo_inverse(A)", "Moore-Penrose pseudo-inverse, same as pinv");
        FunctionProvider.addFunction("norm(A)", "Matrix norm");
        FunctionProvider.addFunction("diag(n)", "Diagonal matrix");
        FunctionProvider.addFunction("upper_triangular(A)", "Upper triangular");
        FunctionProvider.addFunction("zero_matrix(n[, m])", "Zero matrix: n x n, or n x m");
        FunctionProvider.addFunction("full_rank_matrix(A)", "Check full rank");
        FunctionProvider.addFunction("singular_matrix(A)", "Check singular");
        FunctionProvider.addFunction("pd_matrix(A)", "Positive definite");
        FunctionProvider.addFunction("nd_matrix(A)", "Negative definite");
        FunctionProvider.addFunction("unit_matrix(n)", "Unit/Identity matrix");
        // ========== N-D Matrix Functions ==========
        FunctionProvider.addFunction("reshape(A, [d0, d1, ...])",
                "Same elements, new shape, row-major (last index fastest); one size may be -1."
                        + " reshape([1:6], [2,3]) is [1,2,3;4,5,6]");
        FunctionProvider.addFunction("shape(A)",
                "Row vector of the sizes of A, e.g. [2,3,4]; a single value is [1,1]");
        FunctionProvider.addFunction("ndims(A)",
                "Number of axes of A: 2 for a matrix or a single value, 3 for [1,2;3,4 ;; 5,6;7,8]");
        FunctionProvider.addFunction("zeros(d0, ..., m, n)",
                "Matrix of zeros; any number of sizes, or one size vector: zeros(3), zeros(2,3), zeros([2,3,4])");
        FunctionProvider.addFunction("ones(d0, ..., m, n)",
                "Matrix of ones; any number of sizes, or one size vector: ones(3), ones(2,3,4), ones([2,3,4])");
        FunctionProvider.addFunction("deal(v)",
                "Values for a list of variables: [a, b] = deal(v) gives every name v;"
                        + " [a, b] = deal(x, y) gives one each");
        // ========== Nexus Matrix Functions ==========
        FunctionProvider.addFunction("nexus(size[, range])",
                "random matrix of N*N; an N-D size works too: nexus([2,3,4])");
        FunctionProvider.addFunction("nexus_float(size[, range])", "random float matrix of N*N");
        FunctionProvider.addFunction("nexus_uniform(size[, range])", "random uniform matrix of N*N");
        FunctionProvider.addFunction("nexus_normal(size[, range])", "random normal distribution matrix of N*N");
        FunctionProvider.addFunction("nexus_UTM(size[, range])", "upper triangular matrix of N*N");
        FunctionProvider.addFunction("nexus_LTM(size[, range])", "lower triangular matrix of N*N");
        FunctionProvider.addFunction("nexus_UTM_float(size[, range])", "upper triangular matrix of N*N");
        FunctionProvider.addFunction("nexus_LTM_float(size[, range])", "lower triangular matrix of N*N");
        FunctionProvider.addFunction("nexus_UTM_uniform(size[, range])", "upper triangular matrix of N*N");
        FunctionProvider.addFunction("nexus_LTM_uniform(size[, range])", "lower triangular matrix of N*N");
        FunctionProvider.addFunction("nexus_UTM_normal(size[, range])", "upper triangular matrix of N*N");
        FunctionProvider.addFunction("nexus_LTM_normal(size[, range])", "lower triangular matrix of N*N");
        FunctionProvider.addFunction("nexus_seed(n)", "nexus matrices repeat");
    }
}
