package ui.ui_functions.suggestions_list;

import ui.ui_functions.FunctionProvider;

/**
 * matrix_list - Registers all MATRIX functions
 * into the FunctionProvider suggestion system.
 */
public class matrix_list {

    // ========== MATRIX FUNCTIONS ==========
    public static void register() {
        FunctionProvider.addFunction("rank(A)", "Matrix rank");
        FunctionProvider.addFunction("transpose(A)", "Transpose matrix");
        FunctionProvider.addFunction("conjugate(A)", "Conjugate matrix");
        FunctionProvider.addFunction("pseudo_inverse(A)", "Pseudo-inverse");
        FunctionProvider.addFunction("det(A)", "Matrix determinant");
        FunctionProvider.addFunction("adj(A)", "Adjoint matrix");
        FunctionProvider.addFunction("hadamard_prod(A)", "Hadamard product");
        FunctionProvider.addFunction("inverse(A)", "Matrix inverse");
        FunctionProvider.addFunction("norm(A)", "Matrix norm");
        FunctionProvider.addFunction("diag(n)", "Diagonal matrix");
        FunctionProvider.addFunction("upper_triangular(A)", "Upper triangular");
        FunctionProvider.addFunction("zero_matrix(n)", "Zero matrix");
        FunctionProvider.addFunction("full_rank_matrix(A)", "Check full rank");
        FunctionProvider.addFunction("singular_matrix(A)", "Check singular");
        FunctionProvider.addFunction("pd_matrix(A)", "Positive definite");
        FunctionProvider.addFunction("nd_matrix(A)", "Negative definite");
        FunctionProvider.addFunction("unit_matrix(n)", "Unit/Identity matrix");
    }
}
