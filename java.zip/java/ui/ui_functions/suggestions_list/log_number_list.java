package ui.ui_functions.suggestions_list;

import ui.ui_functions.FunctionProvider;

/**
 * log_number_list - Registers all LOG & NUMBER functions
 * into the FunctionProvider suggestion system.
 */
public class log_number_list {

    // ========== LOG & NUMBER FUNCTIONS ==========
    public static void register() {
        FunctionProvider.addFunction("log(x)", "Natural logarithm");
        FunctionProvider.addFunction("e^(x)", "Exponential - e^x");
        FunctionProvider.addFunction("|x|", "Absolute value");
        FunctionProvider.addFunction("frac2deci(x)", "Fraction to decimal");
        FunctionProvider.addFunction("deci2frac(x)", "Decimal to fraction");
    }
}
