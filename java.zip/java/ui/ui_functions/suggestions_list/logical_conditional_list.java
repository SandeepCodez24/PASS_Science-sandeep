package ui.ui_functions.suggestions_list;

import ui.ui_functions.FunctionProvider;

/**
 * logical_conditional_list - Registers all LOGICAL & CONDITIONAL functions
 * into the FunctionProvider suggestion system.
 */
public class logical_conditional_list {

    // ========== LOGICAL & CONDITIONAL FUNCTIONS ==========
    public static void register() {
        FunctionProvider.addFunction("&&", "Logical AND", "&&");
        FunctionProvider.addFunction("||", "Logical OR", "||");
        FunctionProvider.addFunction("not", "Logical NOT", "not");
        FunctionProvider.addFunction("if", "IF statement", "if");
        FunctionProvider.addFunction("if_not", "IF NOT statement", "if not");
        FunctionProvider.addFunction("for", "FOR loop", "for");
        FunctionProvider.addFunction("while", "while loop", "while");
        FunctionProvider.addFunction("while_not", "while not loop", "while not");
        FunctionProvider.addFunction("==", "Check equality", "==");
        FunctionProvider.addFunction("!=", "Check inequality", "!=");
        FunctionProvider.addFunction("is_empty", "Check if empty", "is empty");
        FunctionProvider.addFunction("is_nan", "Check if NaN", "is nan");
        FunctionProvider.addFunction("in", "Check if in list", "in");
        FunctionProvider.addFunction("not_in", "Check if not in list", "not in");
        FunctionProvider.addFunction("start_interval_end", "Create range", "start:interval:end");
    }
}
