package ui.ui_functions.suggestions_list;

import ui.ui_functions.FunctionProvider;

/**
 * basic_math_list - Registers all BASIC MATH functions
 * into the FunctionProvider suggestion system.
 *
 * To add a new basic-math function in the future, simply add a new
 * addFunction(...) line inside the register() method below.
 */
public class basic_math_list {

    // ========== BASIC MATH FUNCTIONS ==========
    public static void register() {
        FunctionProvider.addFunction("publish()", "Show in CLI");
        FunctionProvider.addFunction("sqrt(x)", "Square root");
        FunctionProvider.addFunction("cbrt(x)", "Cube root");
        FunctionProvider.addFunction("sqr(x)", "Square a number");
        FunctionProvider.addFunction("cube(x)", "Cube a number");
        FunctionProvider.addFunction("int8(x)", "Convert to 8-bit integer");
        FunctionProvider.addFunction("int16(x)", "Convert to 16-bit integer");
        FunctionProvider.addFunction("int32(x)", "Convert to 32-bit integer");
        FunctionProvider.addFunction("int64(x)", "Convert to 64-bit integer");
        FunctionProvider.addFunction("float8(x)", "Convert to 8-bit float");
        FunctionProvider.addFunction("float16(x)", "Convert to 16-bit float");
        FunctionProvider.addFunction("float32(x)", "Convert to 32-bit float");
        FunctionProvider.addFunction("float64(x)", "Convert to 64-bit float");
        FunctionProvider.addFunction("string(x)", "Convert to string");
        FunctionProvider.addFunction("save_workspace()", "Save the current workspace");
        FunctionProvider.addFunction("load_workspace(<workspace_name>)", "Load a saved workspace");
    }
}
