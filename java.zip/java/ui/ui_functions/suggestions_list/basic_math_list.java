package ui.ui_functions.suggestions_list;

import ui.ui_functions.FunctionProvider;

/**
 * basic_math_list - Registers all BASIC MATH functions
 * into the FunctionProvider suggestion system.
 *
 * To add a new basic-math function in the future, simply add a new
 * addFunction(...) line inside the register() method below.
 */
public class basic_math_list {

    // ========== BASIC MATH FUNCTIONS ==========
    public static void register() {
        FunctionProvider.addFunction("publish()", "Show in CLI");
        FunctionProvider.addFunction("sqrt(x)", "Square root");
        FunctionProvider.addFunction("cbrt(x)", "Cube root");
        FunctionProvider.addFunction("sqr(x)", "Square a number");
        FunctionProvider.addFunction("cube(x)", "Cube a number");
    }
}
