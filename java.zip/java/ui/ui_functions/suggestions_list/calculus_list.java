package ui.ui_functions.suggestions_list;

import ui.ui_functions.FunctionProvider;

/**
 * calculus_list - Registers all CALCULUS functions
 * into the FunctionProvider suggestion system.
 */
public class calculus_list {

    // ========== CALCULUS FUNCTIONS ==========
    public static void register() {
        FunctionProvider.addFunction("ddt(f)", "Derivative");
        FunctionProvider.addFunction("pddt(f)", "Partial derivative");
        FunctionProvider.addFunction("continuity(f)", "Check continuity");
        FunctionProvider.addFunction("grad(f)", "Gradient");
        FunctionProvider.addFunction("curl(F)", "Curl of vector field");
        FunctionProvider.addFunction("divergence(F)", "Divergence of vector field");
        FunctionProvider.addFunction("laplace(f)", "Laplacian operator");
        FunctionProvider.addFunction("green_integral(f)", "Green's theorem integral");
        FunctionProvider.addFunction("stokes_integral(f)", "Stokes' theorem integral");
        FunctionProvider.addFunction("taylor_series(f)", "Taylor series expansion");
        FunctionProvider.addFunction("rad_of_con(f)", "Radius of convergence");
    }
}
