package ui.ui_functions.suggestions_list;

import ui.ui_functions.FunctionProvider;

/**
 * text_collections_list - Registers the size, text and collection functions
 * (nc.exe: runtime/interpreter/ops/collections/collections_builtin.h) into
 * the FunctionProvider suggestion system, so they are suggested and coloured
 * as built-in functions.
 */
public class text_collections_list {

    // ========== SIZES, TEXT AND COLLECTIONS ==========
    public static void register() {
        FunctionProvider.addFunction("size(A[, dim])",
                "[rows, cols] of a matrix (dim 0 = rows, 1 = cols); entries of a dict");
        FunctionProvider.addFunction("numel(A)", "Number of elements (characters of text, entries of a dict)");
        FunctionProvider.addFunction("length(x)",
                "Characters of text, elements of a vector, the longer side of a matrix");
        FunctionProvider.addFunction("sort(v[, \"descend\"])", "A vector of numbers or text, sorted");
        FunctionProvider.addFunction("append(v, x, ...)", "The vector with the values added at the end");
        FunctionProvider.addFunction("remove(c, k)", "A dict without key k, or a vector without element k");
        FunctionProvider.addFunction("upper(s)", "Text in upper case");
        FunctionProvider.addFunction("lower(s)", "Text in lower case");
        FunctionProvider.addFunction("strcat(a, b, ...)", "The values joined as text");
        FunctionProvider.addFunction("substr(s, start[, count])", "Part of a text, from index start");
        FunctionProvider.addFunction("contains(s, part)", "True if part occurs in the text");
        FunctionProvider.addFunction("replace(s, old, new)", "Every old in the text replaced by new");
        FunctionProvider.addFunction("split(s, sep)", "The pieces of a text between each separator");
        FunctionProvider.addFunction("precision(n)", "Decimals shown for numbers (0 to 15, default 6)");
    }
}
