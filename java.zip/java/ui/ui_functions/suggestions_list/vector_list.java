package ui.ui_functions.suggestions_list;

import ui.ui_functions.FunctionProvider;

/**
 * vector_list - Registers all VECTOR functions
 * into the FunctionProvider suggestion system.
 */
public class vector_list {

    // ========== VECTOR FUNCTIONS ==========
    public static void register() {
        FunctionProvider.addFunction("unit_vector(v)", "Unit vector");
        FunctionProvider.addFunction("norm(v)", "Vector norm");
        FunctionProvider.addFunction("dircos(v)", "Direction cosines");
        FunctionProvider.addFunction("vector_tp(v)", "Vector triple product");
        FunctionProvider.addFunction("proj(a,b)", "Vector projection");
        FunctionProvider.addFunction("proj_vec(a)", "Projection vector");
        FunctionProvider.addFunction("orthogonal(v)", "Check orthogonal");
        FunctionProvider.addFunction("orthonormal(v)", "Check orthonormal");
        FunctionProvider.addFunction("eigen_vector(A)", "Eigenvector");
        FunctionProvider.addFunction("eigen_value(A)", "Eigenvalue");
    }
}
