package ui.ui_functions;

public class Variable {

    private final String name;
    private final String value;
    private final String size;
    private final String datatype;
    private final String sourcePath;

    public Variable(String n, String v, String s, String d) {
        this(n, v, s, d, null);
    }

    public Variable(String n, String v, String s, String d, String source) {
        name = n;
        value = v;
        size = s;
        datatype = d;
        sourcePath = source;
    }

    public String getName() {
        return name;
    }

    public String getValue() {
        return value;
    }

    public String getSize() {
        return size;
    }

    public String getDatatype() {
        return datatype;
    }

    public String getSourcePath() {
        return sourcePath;
    }
}
