package ui.ui_functions;

import java.util.List;
import java.util.Objects;

import language.semantic.VariableNameDecoder;

/**
 * One row of the Variable Explorer.
 *
 * <p><b>Two representations, one object.</b> This is requirement 6 of the
 * language design:
 * <ul>
 *   <li>{@link #getName()} is the <b>cleaned</b> name exactly as
 *       {@code nc.exe} reports it in {@code variables.txt}
 *       (for example {@code var_mu__sj}). It is the database key, it is what
 *       every lookup and every de-duplication check uses, and it is never
 *       shown to the user.</li>
 *   <li>{@link #getSegments()} is the <b>visual</b> form, decoded once here and
 *       drawn by {@code VariableNameRenderer} (&#956;<sub>j</sub>).</li>
 * </ul>
 *
 * <p>Decoding happens in the constructor so the table can redraw a cell without
 * paying for it, and so a row can never be half-decoded.
 *
 * <p>Instances are immutable; the workspace replaces a row rather than mutating
 * it, which keeps the "one variable, one entry" rule easy to enforce.
 */
public class Variable {

    private final String name;
    private final String value;
    private final String size;
    private final String datatype;
    private final String sourcePath;

    private final List<VariableNameDecoder.Segment> segments;
    private final String displayName;

    /**
     * @param n cleaned name (the workspace key)
     * @param v value, already formatted for display
     * @param s size, for example {@code 1x1} or {@code 3x4}
     * @param d datatype label
     */
    public Variable(String n, String v, String s, String d) {
        this(n, v, s, d, null);
    }

    /**
     * @param n      cleaned name (the workspace key)
     * @param v      value, already formatted for display
     * @param s      size, for example {@code 1x1} or {@code 3x4}
     * @param d      datatype label
     * @param source originating file, or null when it came from the CLI
     */
    public Variable(String n, String v, String s, String d, String source) {
        name = n;
        value = v;
        size = s;
        datatype = d;
        sourcePath = source;
        segments = VariableNameDecoder.decode(n);
        displayName = VariableNameDecoder.decodeToPlainText(n);
    }

    /** @return the cleaned name — the internal key, never displayed as-is */
    public String getName() {
        return name;
    }

    /** @return the visual name flattened to plain text (tooltips, sorting) */
    public String getDisplayName() {
        return displayName;
    }

    /** @return the visual name as script-aware segments, for rendering */
    public List<VariableNameDecoder.Segment> getSegments() {
        return segments;
    }

    public String getValue() {
        return value;
    }

    public String getSize() {
        return size;
    }

    public String getDatatype() {
        return datatype;
    }

    public String getSourcePath() {
        return sourcePath;
    }

    /**
     * Compares only the displayed content, so the workspace can tell whether a
     * refresh actually changed a row and skip a pointless table update.
     *
     * @param other the row to compare against
     * @return true when name, value, size and datatype all match
     */
    public boolean sameContentAs(Variable other) {
        return other != null
                && Objects.equals(name, other.name)
                && Objects.equals(value, other.value)
                && Objects.equals(size, other.size)
                && Objects.equals(datatype, other.datatype);
    }

    @Override
    public String toString() {
        return name + " = " + value + " (" + size + ", " + datatype + ")";
    }
}
