package ui.ui_functions;

import java.util.List;
import java.util.Objects;

import backend.workspace.WorkspaceProtocol;

import language.semantic.ComplexLiteral;
import language.semantic.VariableNameDecoder;

/**
 * One row of the Variable Explorer.
 *
 * <p><b>Two representations, one object.</b> This is requirement 6 of the
 * language design:
 * <ul>
 *   <li>{@link #getName()} is the <b>cleaned</b> name exactly as
 *       {@code nc.exe} reports it on the workspace channel
 *       (for example {@code var_mu__sj}). It is the database key, it is what
 *       every lookup and every de-duplication check uses, and it is never
 *       shown to the user.</li>
 *   <li>{@link #getSegments()} is the <b>visual</b> form, decoded once here and
 *       drawn by {@code VariableNameRenderer} (&#956;<sub>j</sub>).</li>
 * </ul>
 *
 * <p><b>Only the name is decoded.</b> The value is never run through
 * {@link VariableNameDecoder}, so a string that happens to contain
 * {@code var_tamil_a} is shown as written. A complex value's {@code j} is
 * shown as {@code i} ({@link #displayValue}).
 *
 * <p>Decoding happens in the constructor so the table can redraw a cell without
 * paying for it, and so a row can never be half-decoded.
 *
 * <p>A row that came from the interpreter also carries the value's physical
 * unit ({@link #getUnit()}, already part of the displayed value for numbers)
 * and its content fingerprint ({@link #getFingerprint()}), which changes
 * whenever the value does - also for a large array whose preview text stays
 * the same.
 *
 * <p>Instances are immutable; the workspace replaces a row rather than mutating
 * it, which keeps the "one variable, one entry" rule easy to enforce.
 */
public class Variable {

    private final String name;
    private final String value;
    private final String size;
    private final String datatype;
    private final String sourcePath;
    private final String unit;
    private final String fingerprint;

    private final List<VariableNameDecoder.Segment> segments;
    private final String displayName;

    /**
     * @param n cleaned name (the workspace key)
     * @param v value, already formatted for display
     * @param s size, for example {@code 1x1} or {@code 3x4}
     * @param d datatype label
     */
    public Variable(String n, String v, String s, String d) {
        this(n, v, s, d, null);
    }

    /**
     * @param n      cleaned name (the workspace key)
     * @param v      value, already formatted for display
     * @param s      size, for example {@code 1x1} or {@code 3x4}
     * @param d      datatype label
     * @param source originating file, or null when it came from the CLI
     */
    public Variable(String n, String v, String s, String d, String source) {
        this(n, v, s, d, source, "", "");
    }

    /**
     * @param n           cleaned name (the workspace key)
     * @param v           value, already formatted for display
     * @param s           size, for example {@code 1x1} or {@code 3x4}
     * @param d           datatype label
     * @param source      originating file, or null when it came from the CLI
     * @param unit        physical unit text such as {@code m/s}, or empty
     * @param fingerprint content fingerprint from the interpreter, or empty
     */
    public Variable(String n, String v, String s, String d, String source, String unit, String fingerprint) {
        name = n;
        value = v;
        size = s;
        datatype = d;
        sourcePath = source;
        this.unit = unit == null ? "" : unit;
        this.fingerprint = fingerprint == null ? "" : fingerprint;
        segments = VariableNameDecoder.decode(n);
        displayName = VariableNameDecoder.decodeToPlainText(n);
    }

    /**
     * Builds a Command Window row from one entry of the interpreter's
     * workspace summary.
     *
     * @param summary the entry
     * @param source  originating file, or null for the CLI
     * @return the row
     */
    public static Variable fromSummary(WorkspaceProtocol.VariableSummary summary, String source) {
        return new Variable(summary.name(), displayValue(summary.preview(), summary.cls()), summary.size(),
                summary.cls(), source, summary.unit(), summary.hash());
    }

    /**
     * The value as the user reads it. Only the <b>name</b> is ever decoded
     * from its cleaned form; the value is shown as the interpreter sent it,
     * except that a complex value's {@code j} is shown as the language's
     * {@code i}: {@code (1+5j)} reads {@code 1+5i}.
     *
     * @param preview the interpreter's preview text
     * @param cls     the interpreter's class name, e.g. {@code complex128}
     * @return the text for the Value column
     */
    static String displayValue(String preview, String cls) {
        if (preview == null || cls == null || !cls.toLowerCase(java.util.Locale.ROOT).contains("complex")) {
            return preview;
        }
        return ComplexLiteral.toDisplay(preview);
    }

    /** @return the cleaned name — the internal key, never displayed as-is */
    public String getName() {
        return name;
    }

    /** @return the visual name flattened to plain text (tooltips, sorting) */
    public String getDisplayName() {
        return displayName;
    }

    /** @return the visual name as script-aware segments, for rendering */
    public List<VariableNameDecoder.Segment> getSegments() {
        return segments;
    }

    public String getValue() {
        return value;
    }

    public String getSize() {
        return size;
    }

    public String getDatatype() {
        return datatype;
    }

    public String getSourcePath() {
        return sourcePath;
    }

    /** @return the physical unit, for example {@code m/s}; empty when unitless or unknown */
    public String getUnit() {
        return unit;
    }

    /** @return the interpreter's content fingerprint; empty when unknown */
    public String getFingerprint() {
        return fingerprint;
    }

    /**
     * Compares only the displayed content, so the workspace can tell whether a
     * refresh actually changed a row and skip a pointless table update.
     *
     * @param other the row to compare against
     * @return true when name, value, size, datatype, unit and fingerprint all match
     */
    public boolean sameContentAs(Variable other) {
        return other != null
                && Objects.equals(name, other.name)
                && Objects.equals(value, other.value)
                && Objects.equals(size, other.size)
                && Objects.equals(datatype, other.datatype)
                && Objects.equals(unit, other.unit)
                && Objects.equals(fingerprint, other.fingerprint);
    }

    @Override
    public String toString() {
        return name + " = " + value + " (" + size + ", " + datatype + ")";
    }
}
