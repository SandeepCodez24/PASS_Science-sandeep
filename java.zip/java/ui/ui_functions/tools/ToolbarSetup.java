package ui.ui_functions.tools;

import java.nio.file.Path;

import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.ButtonBase;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Separator;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.StackPane;
//////////////////////////////////////////////////////////////////
import ui.UI_Main;
import ui.design.Dim;
import ui.editor.navigation.DefaultFolders;
import ui.explorer.navigation.BreadcrumbBar;
import ui.explorer.navigation.NavigationBar;
import ui.managers.ProjectManager;
import ui.managers.TerminalManager;
import ui.ribbon_interface.tool_bar.HomeRibbon;
import ui.ribbon_interface.tool_bar.SignalRibbon;
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
public final class ToolbarSetup {

        // ============================================================
        // CSS style-class hooks (Tasks 2 & 3).
        //   Colours are NO LONGER hard-coded here. They live in the
        //   theme files (light.css / dark.css) so the panel follows
        //   whichever theme is active:
        //       .menu-panel        -> the Row-2 panel background
        //       .menu-toolbar      -> each Row-2 toolbar background
        //       .menu-item-button  -> the New/Open/Save/... buttons
        // ============================================================
        private static final String PANEL_CLASS = "menu-panel";
        private static final String TOOLBAR_CLASS = "menu-toolbar";
        private static final String ITEM_CLASS = "menu-item-button";

        // Height of the Row-2 band, owned by RibbonLayout so the Home
        // ribbon and the other five tabs -- which share one StackPane --
        // can never disagree. MENU_BTN_HEIGHT still applies to the tabs
        // that have not been converted to compartments yet.
        private static final double MENU_ROW_HEIGHT = Dim.ToolBand.ROW_HEIGHT;
        private static final double MENU_BTN_HEIGHT = Dim.ToolBand.FLAT_BUTTON_HEIGHT;

        private ToolbarSetup() {}

        public static void setupToolbars(UI_Main ide) {

                ToolbarState.quickPathOwner = ide;
                // Back / Forward history is FolderHistory now and survives
                // restarts on purpose, so nothing is cleared here.
                // Initialize the ribbon bar
                ToolbarState.ribbonBar = new ToolBar();
                ToolbarState.ribbonBar.getStyleClass().add("ribbon-tab-bar");
                // Height is pinned by ToolbarRibbon.buildRibbonTabs; padding by the design
                // sheet. Only the colour stays inline for now.
                ToolbarState.ribbonBar.setStyle(
                        "-fx-background-color: " + ToolbarState.BG + ";"
                                + "-fx-background-insets: 0;"
                                + "-fx-border-color: transparent;"
                                + "-fx-border-width: 0;");

                // ============================================================
                // Home tab: eight compartments (Files, Data, Visualisation,
                // Modelling, Graphical, Compute, Analysis, AI Help) laid out
                // across the full ribbon width in the ratio 2:2:1:1:1:2:2:1
                // of 16 units, with 4 units left free on the right.
                // Everything lives in ui.ribbon_interface now.
                // ============================================================
                ide.homeTB = HomeRibbon.build(ide);

                // ============================================================
                // Signals tab: five compartments (Sensors, Series, Domain,
                // Actuators, Environment) laid out across the band in the
                // ratio 3.5:2:1:3.5:1 of 14 units, with 3 units left free on
                // the right. Built by SignalRibbon, the same way the Home
                // band is built by HomeRibbon.
                //
                // The field is still called compileTB: ToolbarRibbon maps the
                // "Signals" tab onto it, and renaming the field would ripple
                // through UI_Main and every showToolbar call for no gain.
                // ============================================================
                ide.compileTB = SignalRibbon.build(ide);

                // Apply actions to all toolbars
                ide.jtagTB = new ToolBar(
                                ToolbarButtons.actionButton("Connect", "/icons/jtag/j_ic_01_connect.png",
                                                () -> TerminalManager.println(ide, "JTAG Connect")),
                                ToolbarButtons.actionButton("Debug", "/icons/jtag/j_ic_02_debug.png",
                                                () -> TerminalManager.println(ide, "Debug started")),
                                ToolbarButtons.actionButton("Flash", "/icons/jtag/j_ic_03_flash.png",
                                                () -> TerminalManager.println(ide, "Flashing device")),
                                ToolbarButtons.actionButton("Reset", "/icons/jtag/j_ic_04_reset.png",
                                                () -> TerminalManager.println(ide, "Target reset")));

                ide.commissionTB = new ToolBar(
                                ToolbarButtons.actionButton("Read", "/icons/commission/cn_ic_07_read.png",
                                                () -> TerminalManager.println(ide, "Read operation")),
                                ToolbarButtons.actionButton("Write", "/icons/commission/cn_ic_10_write.png",
                                                () -> TerminalManager.println(ide, "Write operation")),
                                ToolbarButtons.actionButton("Verify", "/icons/commission/cn_ic_09_verify.png",
                                                () -> TerminalManager.println(ide, "Verify operation")),
                                ToolbarButtons.actionButton("Checksum", "/icons/commission/cn_ic_01_checksum.png",
                                                () -> TerminalManager.println(ide, "Checksum")),
                                new Separator(),
                                ToolbarButtons.actionButton("Program", "/icons/commission/cn_ic_06_program.png",
                                                () -> TerminalManager.println(ide, "Programming")),
                                ToolbarButtons.actionButton("Erase", "/icons/commission/cn_ic_02_erase.png",
                                                () -> TerminalManager.println(ide, "Erase memory")),
                                ToolbarButtons.actionButton("Memory", "/icons/commission/cn_ic_04_memory.png",
                                                () -> TerminalManager.println(ide, "Memory view")),
                                new Separator(),
                                ToolbarButtons.actionButton("Lock", "/icons/commission/cn_ic_03_lock.png",
                                                () -> TerminalManager.println(ide, "Device locked")),
                                ToolbarButtons.actionButton("Unlock", "/icons/commission/cn_ic_08_unlock.png",
                                                () -> TerminalManager.println(ide, "Device unlocked")),
                                ToolbarButtons.actionButton("Power", "/icons/commission/cn_ic_05_power.png",
                                                () -> TerminalManager.println(ide, "Power toggle")));

                ide.preferencesTB = new ToolBar(
                                ToolbarButtons.actionButton("Editor", "/icons/preferences/p_ic_03_editor.png",
                                                () -> TerminalManager.println(ide, "Editor prefs")),
                                ToolbarButtons.actionButton("Fonts", "/icons/preferences/p_ic_04_fonts.png",
                                                () -> TerminalManager.println(ide, "Font prefs")),
                                ToolbarButtons.actionButton("Formatter", "/icons/preferences/p_ic_05_formatter.png",
                                                () -> TerminalManager.println(ide, "Formatter prefs")),
                                ToolbarButtons.actionButton("Keymap", "/icons/preferences/p_ic_06_keymap.png",
                                                () -> TerminalManager.println(ide, "Keymap prefs")),
                                ToolbarButtons.actionButton("Layout", "/icons/preferences/p_ic_07_layout.png",
                                                () -> TerminalManager.println(ide, "Layout prefs")),
                                ToolbarButtons.actionButton("Terminal", "/icons/preferences/p_ic_09_terminal.png",
                                                () -> TerminalManager.println(ide, "Terminal prefs")),
                                ToolbarButtons.actionButton("Theme", "/icons/preferences/p_ic_10_theme.png",
                                                () -> TerminalManager.println(ide, "Theme prefs")),
                                ToolbarButtons.actionButton("Reset", "/icons/preferences/p_ic_08_reset.png",
                                                () -> TerminalManager.println(ide, "Preferences reset")));

                ide.helpTB = new ToolBar(
                                ToolbarButtons.actionButton("Guide", "/icons/help/h_ic_03_guide.png",
                                                () -> TerminalManager.println(ide, "Guide opened")),
                                ToolbarButtons.actionButton("API", "/icons/help/h_ic_02_api.png",
                                                () -> TerminalManager.println(ide, "API opened")),
                                ToolbarButtons.actionButton("Tutorials", "/icons/help/h_ic_06_tutorials.png",
                                                () -> TerminalManager.println(ide, "Tutorials opened")),
                                ToolbarButtons.actionButton("Shortcuts", "/icons/help/h_ic_04_shortcuts.png",
                                                () -> TerminalManager.println(ide, "Shortcuts")),
                                ToolbarButtons.actionButton("Support", "/icons/help/h_ic_05_support.png",
                                                () -> TerminalManager.println(ide, "Support")),
                                ToolbarButtons.actionButton("About", "/icons/help/h_ic_01_about.png",
                                                () -> TerminalManager.println(ide, "About")),
                                ToolbarButtons.actionButton("Update", "/icons/help/h_ic_07_update.png",
                                                () -> TerminalManager.println(ide, "Update check")));

                ToolbarStyling.styleToolbar(
                                ide.homeTB, ide.compileTB, ide.jtagTB,
                                ide.commissionTB, ide.preferencesTB, ide.helpTB);

                // === UI CHANGES (Tasks 2 & 3) ================================
                // Applied AFTER ToolbarStyling.styleToolbar(...) so we can strip
                // the leftover inline (teal) styling and hand control to the
                // theme CSS via style classes.
                //  - Task 2: theme-aware panel background (no hard-coded colour).
                //  - Task 3: menu items stacked vertically (icon on top, text
                //            beneath) with enough height so labels aren't clipped.
                // homeTB and compileTB are deliberately excluded: they are
                // built by HomeRibbon and SignalRibbon, and already carry
                // their own style classes and geometry. The helper below walks
                // a toolbar's direct children looking for ButtonBase, which no
                // longer matches a ribbon's nested compartment layout.
                applyMenuPanelAndVerticalItems(
                                ide.jtagTB, ide.commissionTB,
                                ide.preferencesTB, ide.helpTB);
                // =============================================================

                ToolbarState.toolbarStack = new StackPane(
                                ide.homeTB, ide.compileTB, ide.jtagTB,
                                ide.commissionTB, ide.preferencesTB, ide.helpTB);

                // Taller row so the icon-on-top + text-below layout fits fully.
                // Dim.ToolBand.ROW_HEIGHT already includes the height the
                // quick-access row gave up (Dim.NavigationBar.SAVED_HEIGHT),
                // so the band grows exactly as much as that row shrank.
                ToolbarState.toolbarStack.setPrefHeight(MENU_ROW_HEIGHT);
                ToolbarState.toolbarStack.setMinHeight(MENU_ROW_HEIGHT);
                // Task 2: colour comes from the theme CSS (.menu-panel), NOT
                // from a hard-coded value, so dark/light both work correctly.
                ToolbarState.toolbarStack.setStyle("");
                if (!ToolbarState.toolbarStack.getStyleClass().contains(PANEL_CLASS)) {
                        ToolbarState.toolbarStack.getStyleClass().add(PANEL_CLASS);
                }

                ToolbarState.quickAccessBar = buildQuickAccessBar(ide);

                ToolbarStyling.showToolbar(ide, ide.homeTB);
                ToolbarRibbon.buildRibbonTabs(ide);

                // Start in Documents\NeuralCode, created if missing -- the same
                // folder the Home button goes to.
                if (ide.currentFolder == null) {
                        Path defaultDir = DefaultFolders.neuralCodeHome();
                        ide.currentFolder = defaultDir;

                        ProjectManager.loadProjectFromPath(ide, defaultDir);
                }

                ToolbarNavigation.updateQuickPath(ide.currentFolder);
        }

        // ================================================================
        // UI helper (Tasks 2 & 3)
        // For every Row-2 menu toolbar:
        //   * clears leftover inline (teal) styling so theme CSS wins,
        //   * tags it with a style class so light.css / dark.css control
        //     the panel colour (theme-aware, nothing hard-coded here),
        //   * lays each button's icon on TOP with the text centered
        //     BENEATH it, and reserves enough height so labels such as
        //     "New" are never half-cut.
        //   * Icons and text themselves are otherwise left unchanged.
        // ================================================================
        private static void applyMenuPanelAndVerticalItems(ToolBar... toolbars) {
                for (ToolBar tb : toolbars) {
                        // Drop inline colour so the theme's .menu-toolbar rule applies.
                        tb.setStyle("");
                        if (!tb.getStyleClass().contains(TOOLBAR_CLASS)) {
                                tb.getStyleClass().add(TOOLBAR_CLASS);
                        }
                        tb.setPrefHeight(MENU_ROW_HEIGHT);
                        tb.setMinHeight(MENU_ROW_HEIGHT);

                        for (Node node : tb.getItems()) {
                                // Covers both Button (Open, Save, Run, ...) and
                                // MenuButton (New) since both extend ButtonBase.
                                if (node instanceof ButtonBase btn) {
                                        // Task 3: icon on top, text centered beneath.
                                        btn.setContentDisplay(ContentDisplay.TOP);
                                        btn.setAlignment(Pos.CENTER);
                                        btn.setGraphicTextGap(3);
                                        // Fix: guarantee enough height so labels
                                        // (e.g. "New") are shown in full, not clipped.
                                        btn.setGraphicTextGap(Dim.ToolBand.FLAT_GRAPHIC_GAP);
                                        btn.setMinHeight(Dim.ToolBand.FLAT_BUTTON_HEIGHT);
                                        btn.setPrefHeight(Dim.ToolBand.FLAT_BUTTON_HEIGHT);
                                        // Drop inline colour so theme CSS
                                        // (.menu-item-button) controls text/background.
                                        btn.setStyle("");
                                        if (!btn.getStyleClass().contains(ITEM_CLASS)) {
                                                btn.getStyleClass().add(ITEM_CLASS);
                                        }
                                }
                                // Separators and other nodes are left untouched.
                        }
                }
        }

        // ================================================================
        // Row 3: the quick-access row
        //   [Home] [<-] [->] [Up] | [Cloud] [Root|v] | ( breadcrumb ) | [^]
        //
        // Two regions, each built by its own class:
        //   NavigationBar  -> the six buttons and their separators
        //   BreadcrumbBar  -> the path box (crumbs / editable path)
        // The collapse toggle [^] is appended afterwards by
        // RibbonCollapse.installQuickAccessToggle, which looks for the path
        // box through ToolbarState.quickPathLabel.
        //
        // The row is 20% shorter than it was (Dim.NavigationBar.HEIGHT); the
        // pixels it gave up went to the tool band above.
        // ================================================================
        private static ToolBar buildQuickAccessBar(UI_Main ide) {
                ToolBar bar = new ToolBar();
                bar.getItems().addAll(NavigationBar.build(ide));
                bar.getItems().add(BreadcrumbBar.build(ide));

                bar.getStyleClass().add("quick-access-bar");
                bar.setMinHeight(Dim.NavigationBar.HEIGHT);
                bar.setPrefHeight(Dim.NavigationBar.HEIGHT);
                bar.setMaxHeight(Dim.NavigationBar.HEIGHT);
                return bar;
        }
}
