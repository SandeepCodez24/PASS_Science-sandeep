package ui.ui_functions.tools;

import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import ui.explorer.support.IconLoader;

/**
 * Loads the Signals-tab icon set from
 * {@code /icons/SignalIcons/<theme>/<name>.png}.
 *
 * <p>
 * Deliberately a twin of {@link HomeFilesIcons}: same folder convention, same
 * weak registry, same 48px masters scaled down by the {@link ImageView}. The
 * two sets are kept apart rather than merged so the Home and Signals bands can
 * be re-drawn independently later without one dragging the other along.
 * </p>
 *
 * <p>
 * Wire {@link #setDarkTheme(boolean)} into {@code ThemeManager} right beside
 * the existing {@code HomeFilesIcons.setDarkTheme(...)} call, or the Signals
 * icons will keep the light ink after a theme switch.
 * </p>
 */
public final class SignalIcons {

    private static final String BASE = "/icons/SignalIcons/";
    private static final String NAME_KEY = "signalIconName";

    private static final List<WeakReference<ImageView>> LIVE = new CopyOnWriteArrayList<>();

    private static volatile boolean dark = false;

    private SignalIcons() {
    }

    /**
     * Builds an icon view for one of the Signals icons.
     *
     * @param name base file name, without theme folder or {@code .png}, e.g.
     *             {@code "feed_artificial"}
     * @param size edge length in pixels; the image is scaled to fit
     * @return the configured view, already registered for theme swaps
     */
    public static ImageView icon(String name, double size) {
        ImageView view = new ImageView();
        view.getProperties().put(NAME_KEY, name);
        view.setFitWidth(size);
        view.setFitHeight(size);
        view.setPreserveRatio(true);
        view.setSmooth(true);
        view.setMouseTransparent(true);
        apply(view);
        LIVE.add(new WeakReference<>(view));
        return view;
    }

    /**
     * Switches the whole set between the two inks and refreshes every icon
     * currently on screen. Safe to call when nothing has changed.
     *
     * @param useDark {@code true} for the dark-theme ink
     */
    public static void setDarkTheme(boolean useDark) {
        if (useDark == dark) {
            return;
        }
        dark = useDark;
        refresh();
    }

    /**
     * @return {@code true} if the dark-theme ink is currently selected
     */
    public static boolean isDarkTheme() {
        return dark;
    }

    /**
     * @param name base file name, without theme folder or extension
     * @return the classpath resource path for the active theme
     */
    public static String path(String name) {
        return BASE + (dark ? "dark/" : "light/") + name + ".png";
    }

    private static void refresh() {
        Iterator<WeakReference<ImageView>> it = LIVE.iterator();
        while (it.hasNext()) {
            WeakReference<ImageView> ref = it.next();
            ImageView view = ref.get();
            if (view == null) {
                LIVE.remove(ref);
            } else {
                apply(view);
            }
        }
    }

    private static void apply(ImageView view) {
        Object name = view.getProperties().get(NAME_KEY);
        if (name == null) {
            return;
        }
        Image image = IconLoader.load(SignalIcons.class, path(name.toString()));
        if (image != null) {
            view.setImage(image);
        }
    }
}
