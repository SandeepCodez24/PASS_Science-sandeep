package ui.ui_functions.tools;

import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import ui.explorer.support.IconLoader;

/**
 * Loads the Home-ribbon icon set from
 * {@code /icons/home_icons/<name>[_dark].png}.
 *
 * <p>
 * These are the ribbon's non-Files icons -- Run, Stop, Plot, Neural Link, the
 * six {@code ic_h_*} data/compute glyphs, and so on. The set ships twice: the
 * plain base name is the light asset, and the same base name with a
 * {@code _dark} suffix is the dark asset, both in the one {@code home_icons}
 * folder.
 * </p>
 *
 * <p>
 * This mirrors {@link HomeFilesIcons}: every {@link ImageView} handed out is
 * kept in a weak registry so {@link #setDarkTheme(boolean)} can re-point the
 * icons already on screen without the ribbon being rebuilt. Wire the swap in
 * from {@code ThemeManager} at the point the stylesheet changes.
 * </p>
 */
public final class HomeRibbonIcons {

    private static final String BASE = "/icons/home_icons/";
    private static final String NAME_KEY = "homeRibbonIconName";

    private static final List<WeakReference<ImageView>> LIVE = new CopyOnWriteArrayList<>();

    private static volatile boolean dark = false;

    private HomeRibbonIcons() {
    }

    /**
     * Builds an icon view for one of the Home-ribbon icons.
     *
     * @param name base file name, without the folder, the {@code _dark} suffix
     *             or the {@code .png} extension, e.g. {@code "ic_04_run"}
     * @param size edge length in pixels; the image is scaled to fit
     * @return the configured view, already registered for theme swaps
     */
    public static ImageView icon(String name, double size) {
        ImageView view = new ImageView();
        view.getProperties().put(NAME_KEY, name);
        view.setFitWidth(size);
        view.setFitHeight(size);
        view.setPreserveRatio(true);
        view.setSmooth(true);
        view.setMouseTransparent(true);
        apply(view);
        LIVE.add(new WeakReference<>(view));
        return view;
    }

    /**
     * Switches the whole set between the light and dark art and refreshes every
     * icon currently on screen. Safe to call when nothing has changed.
     *
     * <p>
     * Call this from {@code ThemeManager} at the point the stylesheet is
     * swapped, alongside {@code HomeFilesIcons.setDarkTheme(...)}.
     * </p>
     *
     * @param useDark {@code true} for the dark-theme art
     */
    public static void setDarkTheme(boolean useDark) {
        if (useDark == dark) {
            return;
        }
        dark = useDark;
        refresh();
    }

    /**
     * @return {@code true} if the dark-theme art is currently selected
     */
    public static boolean isDarkTheme() {
        return dark;
    }

    /**
     * @param name base file name, without the folder, suffix or extension
     * @return the classpath resource path for the active theme
     */
    public static String path(String name) {
        return BASE + name + (dark ? "_dark" : "") + ".png";
    }

    private static void refresh() {
        Iterator<WeakReference<ImageView>> it = LIVE.iterator();
        while (it.hasNext()) {
            WeakReference<ImageView> ref = it.next();
            ImageView view = ref.get();
            if (view == null) {
                LIVE.remove(ref);
            } else {
                apply(view);
            }
        }
    }

    private static void apply(ImageView view) {
        Object name = view.getProperties().get(NAME_KEY);
        if (name == null) {
            return;
        }
        Image image = IconLoader.load(HomeRibbonIcons.class, path(name.toString()));
        if (image != null) {
            view.setImage(image);
        }
    }
}
