package ui.ui_functions.tools;

import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;

public final class ToolbarButtons {

    private ToolbarButtons() {
    }

    // Row-2 action button. Layout + colours are handled centrally by
    // ToolbarStyling.styleToolbarButton (icon-on-top, theme-aware text).
    public static Button actionButton(String text, String iconPath, Runnable action) {
        Button b = new Button(text, ToolbarIcons.icon(iconPath));
        ToolbarStyling.styleToolbarButton(b);
        b.setOnAction(e -> action.run());
        return b;
    }

    // Small icon-only navigation button (quick-access bar arrows, etc.).
    public static Button navIconButton(String iconPath, Runnable action) {
        Button b = new Button("", ToolbarIcons.icon(iconPath));
        b.setPrefSize(28, 28);
        b.setMinSize(28, 28);
        b.setStyle("""
                        -fx-background-color: transparent;
                        -fx-border-color: transparent;
                        -fx-padding: 2;
                        """);
        b.setOnAction(e -> action.run());
        return b;
    }

    // Compact horizontal button used elsewhere. Colours come from the
    // theme CSS via the ".compact-action-button" style class so it also
    // follows light/dark instead of being locked to a light palette.
    public static Button compactActionButton(String text, String iconPath, Runnable action) {
        Button b = new Button(text, ToolbarIcons.icon(iconPath));
        b.setContentDisplay(ContentDisplay.LEFT);
        b.setGraphicTextGap(6);
        b.setPrefHeight(30);
        b.setMinHeight(30);
        b.setStyle("");
        if (!b.getStyleClass().contains("compact-action-button")) {
            b.getStyleClass().add("compact-action-button");
        }
        b.setOnAction(e -> action.run());
        return b;
    }
}
