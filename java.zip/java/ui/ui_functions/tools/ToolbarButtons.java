package ui.ui_functions.tools;

import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import ui.design.Dim;

/**
 * Factories for the toolbar buttons that are not part of a ribbon compartment.
 *
 * <p>
 * Sizes come from {@code ui.design.Dim}; colours come from the theme CSS. The
 * quick-access arrow button used to carry an inline transparent style, which
 * meant it could not be re-themed and could not be hovered differently in dark
 * mode. It now carries {@code .quick-nav-button} instead.
 * </p>
 */
public final class ToolbarButtons {

    /** Style class for the small icon-only quick-access arrow buttons. */
    public static final String NAV_BUTTON_CLASS = "quick-nav-button";

    /** Style class for the compact horizontal action button. */
    public static final String COMPACT_BUTTON_CLASS = "compact-action-button";

    private ToolbarButtons() {
    }

    /**
     * A Row-2 action button. Layout and colours are handled centrally by
     * {@link ToolbarStyling#styleToolbarButton}.
     *
     * @param text     label beneath the icon
     * @param iconPath classpath resource
     * @param action   what to run on click
     * @return the configured button
     */
    public static Button actionButton(String text, String iconPath, Runnable action) {
        Button b = new Button(text, ToolbarIcons.icon(iconPath));
        ToolbarStyling.styleToolbarButton(b);
        b.setOnAction(e -> action.run());
        return b;
    }

    /**
     * A small icon-only navigation button for the quick-access bar, loading its
     * icon from a plain classpath path.
     *
     * <p>
     * The six buttons on the navigation bar no longer use this: they are built
     * by {@code ui.explorer.navigation.NavigationBar} with the themed
     * {@code naviBread} set. It stays for any other icon button that wants the
     * same size and hover.
     * </p>
     *
     * @param iconPath classpath resource
     * @param action   what to run on click
     * @return the configured button
     */
    public static Button navIconButton(String iconPath, Runnable action) {
        Button b = new Button("", ToolbarIcons.icon(iconPath, Dim.NavigationBar.ICON_SIZE));
        b.setPrefSize(Dim.NavigationBar.BUTTON_SIZE, Dim.NavigationBar.BUTTON_SIZE);
        b.setMinSize(Dim.NavigationBar.BUTTON_SIZE, Dim.NavigationBar.BUTTON_SIZE);
        b.setFocusTraversable(false);
        b.setStyle("");
        if (!b.getStyleClass().contains(NAV_BUTTON_CLASS)) {
            b.getStyleClass().add(NAV_BUTTON_CLASS);
        }
        b.setOnAction(e -> action.run());
        return b;
    }

    /**
     * A compact horizontal button used outside the ribbon. Colours come from
     * the theme CSS via {@code .compact-action-button} so it follows
     * light/dark.
     *
     * @param text     button label
     * @param iconPath classpath resource
     * @param action   what to run on click
     * @return the configured button
     */
    public static Button compactActionButton(String text, String iconPath, Runnable action) {
        Button b = new Button(text, ToolbarIcons.icon(iconPath));
        b.setContentDisplay(ContentDisplay.LEFT);
        b.setGraphicTextGap(Dim.ToolBand.COMPACT_GRAPHIC_GAP);
        b.setPrefHeight(Dim.ToolBand.COMPACT_BUTTON_HEIGHT);
        b.setMinHeight(Dim.ToolBand.COMPACT_BUTTON_HEIGHT);
        b.setStyle("");
        if (!b.getStyleClass().contains(COMPACT_BUTTON_CLASS)) {
            b.getStyleClass().add(COMPACT_BUTTON_CLASS);
        }
        b.setOnAction(e -> action.run());
        return b;
    }
}
