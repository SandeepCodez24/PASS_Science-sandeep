package ui.ui_functions.tools;

import ui.UI_Main;

public final class PrintStudioWindow {

    private PrintStudioWindow() {
    }

    public static void open(UI_Main ide) {
        try {
            java.awt.print.PrinterJob pj = java.awt.print.PrinterJob.getPrinterJob();
            if (pj.printDialog()) {
                pj.print();
            }
        } catch (java.awt.print.PrinterException ex) {
            System.err.println("Print error: " + ex.getMessage());
        }
    }
}
