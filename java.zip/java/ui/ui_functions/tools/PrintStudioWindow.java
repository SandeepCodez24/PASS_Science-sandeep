package ui.ui_functions.tools;

import java.awt.print.PageFormat;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.standard.Chromaticity;
import javax.print.attribute.standard.Copies;
import javax.print.attribute.standard.JobName;
import javax.print.attribute.standard.PageRanges;
import javax.print.attribute.standard.Sides;

import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Labeled;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.ToggleGroup;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.SVGPath;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.StringConverter;
import ui.UI_Main;
import ui.cli.CLI_Main;
import ui.design.Typography;
import ui.design.section_dims.PrintWindow_dim;
import ui.layout.custom.CustomLayoutConfig;
import ui.managers.ThemeManager;
import ui.managers.ToolbarManager;
import ui.ui_functions.tools.print.CodePrintable;
import ui.ui_functions.tools.print.PdfExporter;
import ui.ui_functions.tools.print.PrintModel;
import ui.ui_functions.tools.print.PrintSettings;

/**
 * The Print entry point on the ribbon: the "Print Script" window.
 *
 * <pre>
 *   +--------------------------------------------------+
 *   | [NC] Print Script                            [X] |  base colour
 *   |--------------------------------------------------|
 *   | test_02.nc                                       |
 *   | C:\...\test_02.nc                                |
 *   | 22 lines - 2 pages                               |
 *   |--------------------------------------------------|
 *   | Printer    [ HP LaserJet (default)           v ] |
 *   | Copies     [ 1 ^v]                               |
 *   | Pages      (o) All  ( ) From [1] to [2]          |
 *   | Sides      [ One-sided                       v ] |  if supported
 *   | Colour     [ Colour                          v ] |  if supported
 *   |--------------------------------------------------|
 *   | PDF theme  (o) Light  ( ) Dark                   |
 *   |                 [Cancel] [Save as PDF...] [Print]|
 *   +--------------------------------------------------+
 * </pre>
 *
 * <h3>No operating-system print dialog</h3>
 * <p>
 * Every print option lives in this window, and Print sends the job straight
 * to the chosen printer with {@link PrinterJob#print(PrintRequestAttributeSet)}.
 * The Windows print dialog used before belongs to {@code java.exe} while the
 * IDE runs unpackaged, so it carried the Java coffee cup in its title bar and
 * nothing in Astra could change that. This window carries the Neural Code
 * mark, the base colour and the theme, the same on every operating system.
 * </p>
 * <ul>
 * <li><b>Printer</b> -- every installed printer, the system default chosen
 * first. The list is read on a background thread, so a slow network printer
 * cannot freeze the IDE.</li>
 * <li><b>Copies</b> -- 1 to 999.</li>
 * <li><b>Pages</b> -- all, or a range. The page count is worked out for the
 * chosen printer's own paper, so the range always matches what will print.</li>
 * <li><b>Sides</b> and <b>Colour</b> -- shown only when the chosen printer
 * reports that it can do them.</li>
 * </ul>
 * <p>
 * What is given up is the printer driver's own "Properties" page (paper tray
 * and other driver-specific settings). A printer's defaults for those still
 * apply. Some virtual printers -- Microsoft Print to PDF, say -- open a save
 * dialog of their own when the job reaches them; that is the driver's, not
 * Astra's.
 * </p>
 * <p>
 * Paper is always printed in the light palette: a dark listing would flood
 * the sheet with ink. The Light/Dark choice applies to Save as PDF only.
 * </p>
 *
 * <h3>Its own frame</h3>
 * <p>
 * The window draws its own title bar in the IDE's <b>base colour</b>, with the
 * Neural Code mark, the title "Print Script" and a close button. The
 * operating system's frame could do neither: its title bar cannot be
 * coloured, and Windows 11 rounds every decorated window by about 8 px. So
 * the stage is {@link StageStyle#TRANSPARENT} and the frame is a JavaFX node
 * with {@link PrintWindow_dim#CORNER_RADIUS} -- 0.1, effectively square -- and
 * a soft drop shadow in a transparent margin around it. The title bar drags
 * the window; Escape and the close button cancel.
 * </p>
 *
 * <h3>Where the base colour comes from</h3>
 * <p>
 * Nothing is hard-coded. The base colour is the one the user sees on the
 * ribbon's tab strip -- the navy by default, or whatever was chosen as Base
 * Color in Settings &gt; Layout &gt; Custom, including a colour only being
 * Previewed. {@code CustomLayoutTheme} paints exactly that strip with it, so
 * the strip's own background is read ({@link #baseColour()}), rather than
 * second-guessing which layout or preview is active. If the strip has no
 * readable fill (it always has one once the main window is up), the factory
 * navy {@link CustomLayoutConfig#FACTORY_BASE} is used.
 * </p>
 * <p>
 * The title and close glyph take {@link CustomLayoutConfig#ink}, so they turn
 * dark on a light base colour, the same rule the rest of the IDE uses.
 * </p>
 *
 * <h3>Light and dark</h3>
 * <p>
 * The body is white in the light theme and the IDE's dark panel colour in the
 * dark theme ({@link #surface()}), and its text, rules and buttons take the
 * matching ink. These are set inline from {@link ThemeManager#getActiveTheme()}
 * rather than left to the stylesheets, because the dark sheet recolours text
 * but not Modena's window background -- the mix that showed light-grey text on
 * a white body. {@code -fx-base} on the frame makes Modena derive the
 * drop-downs, spinners and radio buttons from the same surface. A theme or
 * base-colour change while the window is open repaints it.
 * </p>
 *
 * <h3>Other documents</h3>
 * <p>
 * {@link #open(UI_Main, PrintModel.Document, String, boolean)} prints any
 * document through the same window under a title of the caller's choosing,
 * with or without the line-number gutter. The Variable Explorer uses it for
 * "Print Workspace" (its table) and "Print Variable" (an open variable's
 * grid). {@link #open(UI_Main)} is unchanged: the active editor tab, titled
 * "Print Script", with line numbers.
 * </p>
 *
 * <h3>Threading</h3>
 * <p>
 * {@code PrinterJob} and the printer lookup are AWT and can block on a slow
 * or offline printer. They never run on the JavaFX application thread: the
 * lookup, the page count and the job itself run on daemon threads and come
 * back through {@link Platform#runLater}.
 * </p>
 */
public final class PrintStudioWindow {

    /** The Neural Code window icon. Case matters on a case-sensitive jar. */
    private static final String APP_ICON = "/icons/ic_18_nc.PNG";

    /** Window title for a script, in the title bar and on the taskbar. */
    private static final String TITLE = "Print Script";

    /** Body colour in the light theme. */
    private static final String BODY_LIGHT = "#FFFFFF";

    /**
     * Body colour in the dark theme: the dark panel colour the IDE's own
     * panels use ({@code CustomLayoutConfig} factory dark).
     */
    private static final String BODY_DARK = "#252526";

    /** Node property keys for the buttons' two inline styles. */
    private static final String BUTTON_STYLES = "astra.print.button.styles";
    private static final String BUTTON_HOVER_HOOK = "astra.print.button.hook";

    /** Close button under the pointer: the Windows close-button red. */
    private static final String CLOSE_HOVER = "#E81123";

    /** Most copies one job may ask for. */
    private static final int MAX_COPIES = 999;

    /** Width of the label column on the left of the option rows. */
    private static final double LABEL_COLUMN = 84;

    private PrintStudioWindow() {
    }

    /** A duplex choice: what the user reads, and the attribute it sends. */
    private record SideChoice(String label, Sides value) {
        @Override
        public String toString() {
            return label;
        }
    }

    /** A colour choice: what the user reads, and the attribute it sends. */
    private record ColourChoice(String label, Chromaticity value) {
        @Override
        public String toString() {
            return label;
        }
    }

    /**
     * Opens the Print Script window for the active editor tab.
     *
     * @param ide the IDE controller
     */
    public static void open(UI_Main ide) {
        PrintModel.Document doc = PrintModel.fromActiveTab(ide);
        if (doc == null) {
            warn(ide, "Nothing to print", "Open a file in the editor first.");
            return;
        }
        open(ide, doc, TITLE, true);
    }

    /**
     * Opens the Print window for any document.
     *
     * @param ide         the IDE controller
     * @param doc         what to print
     * @param title       the window's title, e.g. "Print Workspace"
     * @param lineNumbers true to draw the line-number gutter on paper and in
     *                    the PDF
     */
    public static void open(UI_Main ide, PrintModel.Document doc, String title, boolean lineNumbers) {
        if (doc == null) {
            warn(ide, "Nothing to print", "There is nothing to print yet.");
            return;
        }
        String windowTitle = title == null || title.isBlank() ? TITLE : title;
        PrintSettings paper = new PrintSettings(PrintSettings.Theme.LIGHT, PrintSettings.DEFAULT_FONT_SIZE,
                lineNumbers, true, true);

        Stage stage = new Stage(StageStyle.TRANSPARENT);
        stage.initOwner(ide.stage);
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle(windowTitle);
        applyIcon(stage);

        // ---- what is being printed ------------------------------------------

        Label what = new Label(doc.title());
        Label where = new Label(doc.headerText());
        Label count = new Label(doc.lines().size() + " lines");

        // ---- printer options ------------------------------------------------

        ComboBox<PrintService> printer = new ComboBox<>();
        printer.setMaxWidth(Double.MAX_VALUE);
        printer.setPromptText("Looking for printers\u2026");
        printer.setDisable(true);
        PrintService[] defaultService = { null };
        printer.setConverter(new StringConverter<>() {
            @Override
            public String toString(PrintService s) {
                if (s == null) {
                    return "";
                }
                return s.equals(defaultService[0]) ? s.getName() + "  (default)" : s.getName();
            }

            @Override
            public PrintService fromString(String text) {
                return null;
            }
        });

        Spinner<Integer> copies = intSpinner(1, MAX_COPIES, 1);

        ToggleGroup rangeGroup = new ToggleGroup();
        RadioButton allPages = new RadioButton("All");
        RadioButton somePages = new RadioButton("From");
        allPages.setToggleGroup(rangeGroup);
        somePages.setToggleGroup(rangeGroup);
        allPages.setSelected(true);
        Spinner<Integer> from = intSpinner(1, 1, 1);
        Spinner<Integer> to = intSpinner(1, 1, 1);
        Label toLabel = new Label("to");
        from.disableProperty().bind(allPages.selectedProperty());
        to.disableProperty().bind(allPages.selectedProperty());
        toLabel.disableProperty().bind(allPages.selectedProperty());
        HBox rangeBox = new HBox(8, allPages, somePages, from, toLabel, to);
        rangeBox.setAlignment(Pos.CENTER_LEFT);

        ComboBox<SideChoice> sides = new ComboBox<>();
        sides.setMaxWidth(Double.MAX_VALUE);
        ComboBox<ColourChoice> colour = new ComboBox<>();
        colour.setMaxWidth(Double.MAX_VALUE);

        Label printerLabel = new Label("Printer");
        Label copiesLabel = new Label("Copies");
        Label pagesLabel = new Label("Pages");
        Label sidesLabel = new Label("Sides");
        Label colourLabel = new Label("Colour");

        GridPane options = new GridPane();
        options.setHgap(10);
        options.setVgap(8);
        ColumnConstraints labels = new ColumnConstraints(LABEL_COLUMN);
        ColumnConstraints fields = new ColumnConstraints();
        fields.setHgrow(Priority.ALWAYS);
        fields.setFillWidth(true);
        options.getColumnConstraints().addAll(labels, fields);
        options.addRow(0, printerLabel, printer);
        options.addRow(1, copiesLabel, copies);
        options.addRow(2, pagesLabel, rangeBox);
        options.addRow(3, sidesLabel, sides);
        options.addRow(4, colourLabel, colour);
        showRow(false, sidesLabel, sides);
        showRow(false, colourLabel, colour);

        // ---- PDF ------------------------------------------------------------

        ToggleGroup themeGroup = new ToggleGroup();
        RadioButton light = new RadioButton("Light");
        RadioButton dark = new RadioButton("Dark");
        light.setToggleGroup(themeGroup);
        dark.setToggleGroup(themeGroup);
        light.setSelected(true);

        Label themeLabel = new Label("PDF theme");
        themeLabel.setMinWidth(LABEL_COLUMN);
        themeLabel.setPrefWidth(LABEL_COLUMN);
        HBox themeRow = new HBox(10, themeLabel, light, dark);
        themeRow.setAlignment(Pos.CENTER_LEFT);

        // ---- buttons --------------------------------------------------------

        Button print = new Button("Print");
        Button pdf = new Button("Save as PDF\u2026");
        Button cancel = new Button("Cancel");
        print.setDefaultButton(true);
        cancel.setCancelButton(true);
        print.setDisable(true); // until a printer and its page count are known

        Region grow = new Region();
        HBox.setHgrow(grow, Priority.ALWAYS);
        HBox buttons = new HBox(8, grow, cancel, pdf, print);
        buttons.setAlignment(Pos.CENTER_RIGHT);

        // A plain 1 px rule rather than a Separator: a Separator's line is
        // drawn by a child the inline style cannot reach, so it would keep
        // the light theme's colour on a dark body.
        Region rule1 = rule();
        Region rule2 = rule();

        VBox body = new VBox(12, what, where, count, rule1, options, rule2, themeRow, buttons);
        body.setPadding(new Insets(PrintWindow_dim.BODY_PADDING));
        body.setPrefWidth(PrintWindow_dim.BODY_WIDTH);

        // ---- behaviour ------------------------------------------------------

        int[] pageCount = { 0 };
        Runnable recount = () -> {
            PrintService chosen = printer.getValue();
            print.setDisable(true);
            if (chosen == null) {
                count.setText(doc.lines().size() + " lines");
                return;
            }
            count.setText(doc.lines().size() + " lines \u00B7 counting pages\u2026");
            countPagesInBackground(doc, paper, chosen, n -> {
                if (chosen != printer.getValue()) {
                    return; // the user has moved on to another printer
                }
                pageCount[0] = n;
                count.setText(doc.lines().size() + " lines \u00B7 " + n + (n == 1 ? " page" : " pages"));
                setRange(from, 1, n, 1);
                setRange(to, 1, n, n);
                print.setDisable(false);
            });
        };

        printer.valueProperty().addListener((obs, was, chosen) -> {
            fillCapabilities(chosen, sides, colour, sidesLabel, colourLabel);
            stage.sizeToScene();
            recount.run();
        });

        // Keep the range the right way round.
        from.valueProperty().addListener((obs, was, v) -> {
            if (v != null && to.getValue() != null && v > to.getValue()) {
                to.getValueFactory().setValue(v);
            }
        });
        to.valueProperty().addListener((obs, was, v) -> {
            if (v != null && from.getValue() != null && v < from.getValue()) {
                from.getValueFactory().setValue(v);
            }
        });

        lookUpPrintersInBackground((services, preferred) -> {
            defaultService[0] = preferred;
            if (services.isEmpty()) {
                printer.setPromptText("No printer installed");
                count.setText(doc.lines().size() + " lines");
                return;
            }
            printer.getItems().setAll(services);
            printer.setDisable(false);
            printer.setValue(preferred != null && services.contains(preferred) ? preferred : services.get(0));
        });

        print.setOnAction(e -> {
            PrintService chosen = printer.getValue();
            if (chosen == null) {
                return;
            }
            PrintRequestAttributeSet attrs = new HashPrintRequestAttributeSet();
            attrs.add(new JobName("Neural Code - " + doc.title(), null));
            commit(copies);
            attrs.add(new Copies(copies.getValue()));
            int first = 1;
            int last = pageCount[0];
            if (somePages.isSelected()) {
                commit(from);
                commit(to);
                first = from.getValue();
                last = to.getValue();
                attrs.add(new PageRanges(first, last));
            }
            if (sides.isVisible() && sides.getValue() != null) {
                attrs.add(sides.getValue().value());
            }
            if (colour.isVisible() && colour.getValue() != null) {
                attrs.add(colour.getValue().value());
            }
            int pagesSent = Math.max(0, last - first + 1);
            stage.close();
            // Paper is always light; see the class notes.
            printInBackground(ide, doc, paper, chosen, attrs,
                    pagesSent, copies.getValue());
        });

        pdf.setOnAction(e -> {
            PrintSettings.Theme theme = dark.isSelected()
                    ? PrintSettings.Theme.DARK
                    : PrintSettings.Theme.LIGHT;
            stage.close();
            exportPdf(ide, doc, new PrintSettings(theme, PrintSettings.DEFAULT_FONT_SIZE,
                    lineNumbers, true, true));
        });

        cancel.setOnAction(e -> stage.close());

        // ---- frame: title bar over body, squared, with a shadow -------------

        TitleBar bar = titleBar(stage, windowTitle);
        VBox frame = new VBox(bar.box(), body);

        Body parts = new Body(
                new Region[] { rule1, rule2 },
                new Labeled[] { what, printerLabel, copiesLabel, pagesLabel, sidesLabel, colourLabel,
                        allPages, somePages, toLabel, themeLabel, light, dark },
                new Labeled[] { where, count },
                new Button[] { cancel, pdf, print });

        // Paint now, and again whenever the ribbon strip (the base colour) or
        // the theme changes while this window is open.
        Runnable repaint = () -> {
            Color surface = surface();
            paint(frame, bar, baseColour(), surface);
            paintBody(parts, surface);
        };
        repaint.run();
        ChangeListener<Background> followBase = (obs, was, is) -> repaint.run();
        ChangeListener<Object> followTheme = (obs, was, is) -> {
            if (ide.scene != null && stage.getScene() != null) {
                stage.getScene().getStylesheets().setAll(ide.scene.getStylesheets());
            }
            repaint.run();
        };
        Region strip = ToolbarManager.ribbonBar instanceof Region r ? r : null;
        if (strip != null) {
            strip.backgroundProperty().addListener(followBase);
        }
        ThemeManager.themeProperty().addListener(followTheme);
        stage.setOnHidden(e -> {
            if (strip != null) {
                strip.backgroundProperty().removeListener(followBase);
            }
            ThemeManager.themeProperty().removeListener(followTheme);
        });

        DropShadow shadow = new DropShadow(PrintWindow_dim.SHADOW_RADIUS, Color.rgb(0, 0, 0, 0.30));
        shadow.setOffsetY(2);
        frame.setEffect(shadow);

        StackPane root = new StackPane(frame);
        root.setPadding(new Insets(PrintWindow_dim.SHADOW_MARGIN));
        // The theme sheets paint .root; this pane is only the shadow margin.
        root.setStyle("-fx-background-color: transparent;");

        Scene scene = new Scene(root);
        scene.setFill(Color.TRANSPARENT);
        // Inherit whatever the main window is wearing, so this does not flash
        // a white panel in front of a dark IDE.
        if (ide.scene != null) {
            scene.getStylesheets().setAll(ide.scene.getStylesheets());
        }
        scene.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.ESCAPE) {
                stage.close();
            }
        });
        stage.setScene(scene);
        stage.setResizable(false);
        stage.showAndWait();
    }

    /* =====================================================================
     * PRINTERS
     * ===================================================================== */

    /** Receives the printer list on the FX thread. */
    private interface PrintersFound {
        void accept(List<PrintService> services, PrintService preferred);
    }

    /** Receives a page count on the FX thread. */
    private interface PagesCounted {
        void accept(int pages);
    }

    /** Reads the installed printers and the default one off the FX thread. */
    private static void lookUpPrintersInBackground(PrintersFound done) {
        Thread worker = new Thread(() -> {
            List<PrintService> services = new ArrayList<>();
            PrintService preferred = null;
            try {
                services.addAll(Arrays.asList(PrintServiceLookup.lookupPrintServices(null, null)));
                preferred = PrintServiceLookup.lookupDefaultPrintService();
            } catch (RuntimeException ex) {
                // No print system available: the window says so.
            }
            PrintService def = preferred;
            Platform.runLater(() -> done.accept(services, def));
        }, "astra-print-lookup");
        worker.setDaemon(true);
        worker.start();
    }

    /**
     * Lays the document out for one printer's default paper and reports how
     * many pages it takes.
     */
    private static void countPagesInBackground(PrintModel.Document doc, PrintSettings settings,
            PrintService service, PagesCounted done) {
        Thread worker = new Thread(() -> {
            int pages;
            try {
                PrinterJob job = PrinterJob.getPrinterJob();
                job.setPrintService(service);
                PageFormat format = job.getPageFormat(new HashPrintRequestAttributeSet());
                pages = new CodePrintable(doc, settings, format).getNumberOfPages();
            } catch (PrinterException | RuntimeException ex) {
                pages = 1;
            }
            int n = Math.max(1, pages);
            Platform.runLater(() -> done.accept(n));
        }, "astra-print-count");
        worker.setDaemon(true);
        worker.start();
    }

    /**
     * Offers Sides and Colour only when the printer reports it can do them,
     * and hides each row otherwise.
     */
    private static void fillCapabilities(PrintService service,
            ComboBox<SideChoice> sides, ComboBox<ColourChoice> colour,
            Label sidesLabel, Label colourLabel) {
        sides.getItems().clear();
        colour.getItems().clear();
        if (service != null) {
            for (Sides s : supported(service, Sides.class, Sides.class)) {
                if (s == Sides.ONE_SIDED) {
                    sides.getItems().add(new SideChoice("One-sided", s));
                } else if (s == Sides.TWO_SIDED_LONG_EDGE) {
                    sides.getItems().add(new SideChoice("Two-sided, flip on long edge", s));
                } else if (s == Sides.TWO_SIDED_SHORT_EDGE) {
                    sides.getItems().add(new SideChoice("Two-sided, flip on short edge", s));
                }
            }
            for (Chromaticity c : supported(service, Chromaticity.class, Chromaticity.class)) {
                if (c == Chromaticity.COLOR) {
                    colour.getItems().add(new ColourChoice("Colour", c));
                } else if (c == Chromaticity.MONOCHROME) {
                    colour.getItems().add(new ColourChoice("Black and white", c));
                }
            }
        }
        boolean twoSides = sides.getItems().size() > 1;
        boolean twoColours = colour.getItems().size() > 1;
        if (twoSides) {
            sides.getSelectionModel().selectFirst();
        }
        if (twoColours) {
            colour.getSelectionModel().selectFirst();
        }
        showRow(twoSides, sidesLabel, sides);
        showRow(twoColours, colourLabel, colour);
    }

    /** The values a printer supports for one attribute, as a typed list. */
    private static <T> List<T> supported(PrintService service, Class<?> category, Class<T> type) {
        List<T> out = new ArrayList<>();
        try {
            @SuppressWarnings("unchecked")
            Class<? extends javax.print.attribute.Attribute> cat =
                    (Class<? extends javax.print.attribute.Attribute>) category;
            if (!service.isAttributeCategorySupported(cat)) {
                return out;
            }
            Object values = service.getSupportedAttributeValues(cat, null, null);
            if (values instanceof Object[] array) {
                for (Object v : array) {
                    if (type.isInstance(v)) {
                        out.add(type.cast(v));
                    }
                }
            }
        } catch (RuntimeException ex) {
            // A driver that cannot answer simply gets no extra options.
        }
        return out;
    }

    /* =====================================================================
     * PAPER
     * ===================================================================== */

    private static void printInBackground(UI_Main ide,
            PrintModel.Document doc,
            PrintSettings settings,
            PrintService service,
            PrintRequestAttributeSet attrs,
            int pages,
            int copies) {

        Thread worker = new Thread(() -> {
            try {
                PrinterJob job = PrinterJob.getPrinterJob();
                job.setPrintService(service);
                job.setJobName("Neural Code - " + doc.title());

                // The printer's own paper and margins for these options.
                PageFormat format = job.getPageFormat(attrs);
                job.setPageable(new CodePrintable(doc, settings, format));
                job.print(attrs);

                String what = pages + (pages == 1 ? " page" : " pages")
                        + (copies > 1 ? ", " + copies + " copies" : "");
                CLI_Main.printNotice("Sent to printer: " + service.getName() + " (" + what + ")");
            } catch (PrinterException | RuntimeException ex) {
                Platform.runLater(() -> warn(ide, "Print failed",
                        ex.getMessage() == null ? ex.toString() : ex.getMessage()));
            }
        }, "astra-print");

        worker.setDaemon(true);
        worker.start();
    }

    /* =====================================================================
     * PDF
     * ===================================================================== */

    private static void exportPdf(UI_Main ide,
            PrintModel.Document doc,
            PrintSettings settings) {

        FileChooser fc = new FileChooser();
        fc.setTitle("Save as PDF");
        fc.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("PDF document (*.pdf)", "*.pdf"));
        fc.setInitialFileName(stem(doc.title()) + ".pdf");

        if (doc.path() != null && doc.path().getParent() != null) {
            fc.setInitialDirectory(doc.path().getParent().toFile());
        } else if (ide.currentFolder != null && Files.isDirectory(ide.currentFolder)) {
            fc.setInitialDirectory(ide.currentFolder.toFile());
        }

        File target = fc.showSaveDialog(ide.stage);
        if (target == null) {
            return;
        }
        if (!target.getName().toLowerCase().endsWith(".pdf")) {
            target = new File(target.getParentFile(), target.getName() + ".pdf");
        }

        final File file = target;
        Thread worker = new Thread(() -> {
            try {
                PdfExporter.export(doc, settings, file);
                // Through CLI_Main, not console.appendText: written straight
                // after ">> " the message landed in the editable input and
                // the next Enter sent it to the interpreter as a command.
                CLI_Main.printNotice("Exported PDF: " + file);
            } catch (Exception ex) {
                Platform.runLater(() -> warn(ide, "PDF export failed", ex.getMessage()));
            }
        }, "astra-pdf-export");

        worker.setDaemon(true);
        worker.start();
    }

    /* =====================================================================
     * SMALL CONTROLS
     * ===================================================================== */

    /** An editable whole-number spinner that keeps typed values. */
    private static Spinner<Integer> intSpinner(int min, int max, int initial) {
        Spinner<Integer> s = new Spinner<>(
                new SpinnerValueFactory.IntegerSpinnerValueFactory(min, max, initial));
        s.setEditable(true);
        s.setPrefWidth(76);
        // A value typed and then left (Tab, a click elsewhere) is kept, not
        // silently thrown away.
        s.getEditor().focusedProperty().addListener((obs, had, has) -> {
            if (!has) {
                commit(s);
            }
        });
        return s;
    }

    /** Takes whatever is typed in a spinner's field as its value, if valid. */
    private static void commit(Spinner<Integer> s) {
        if (!s.isEditable()) {
            return;
        }
        SpinnerValueFactory<Integer> f = s.getValueFactory();
        String text = s.getEditor().getText();
        try {
            int v = Integer.parseInt(text.trim());
            if (f instanceof SpinnerValueFactory.IntegerSpinnerValueFactory r) {
                v = Math.max(r.getMin(), Math.min(r.getMax(), v));
            }
            f.setValue(v);
        } catch (NumberFormatException | NullPointerException ex) {
            // put the last good value back in the field
        }
        s.getEditor().setText(String.valueOf(f.getValue()));
    }

    private static void setRange(Spinner<Integer> s, int min, int max, int value) {
        if (s.getValueFactory() instanceof SpinnerValueFactory.IntegerSpinnerValueFactory r) {
            r.setMin(min);
            r.setMax(max);
            r.setValue(Math.max(min, Math.min(max, value)));
        }
    }

    private static void showRow(boolean show, Node... nodes) {
        for (Node n : nodes) {
            n.setVisible(show);
            n.setManaged(show);
        }
    }

    private static Region rule() {
        Region r = new Region();
        r.setMinHeight(1);
        r.setPrefHeight(1);
        r.setMaxHeight(1);
        return r;
    }

    /* =====================================================================
     * THEME AND BASE COLOUR
     * ===================================================================== */

    /** The body controls whose colours follow the theme. */
    private record Body(Region[] rules, Labeled[] primary, Labeled[] secondary, Button[] buttons) {
    }

    /**
     * The body colour for the active theme. Chosen here rather than taken
     * from the stylesheets: the dark theme sets light text but leaves
     * Modena's light {@code -fx-background} in place, which is what made the
     * body white under light-grey text.
     *
     * @return the body colour
     */
    static Color surface() {
        boolean dark = CustomLayoutConfig.DARK.equals(ThemeManager.getActiveTheme());
        return Color.web(dark ? BODY_DARK : BODY_LIGHT);
    }

    /**
     * Colours the body's text, rules and buttons for its surface. Inline, so
     * no theme rule can leave light text on a light body or the reverse.
     */
    private static void paintBody(Body parts, Color surface) {
        Color ink = CustomLayoutConfig.ink(surface);
        String text = CustomLayoutConfig.hex(ink);
        String muted = CustomLayoutConfig.hex(CustomLayoutConfig.mix(surface, ink, 0.70));

        for (Labeled l : parts.primary()) {
            l.setStyle("-fx-text-fill: " + text + ";");
        }
        parts.primary()[0].setStyle("-fx-text-fill: " + text + "; -fx-font-weight: bold;");
        for (Labeled l : parts.secondary()) {
            l.setStyle("-fx-text-fill: " + muted + ";");
        }
        String line = CustomLayoutConfig.hex(CustomLayoutConfig.mix(surface, ink, 0.18));
        for (Region r : parts.rules()) {
            r.setStyle("-fx-background-color: " + line + ";");
        }

        String face = CustomLayoutConfig.hex(CustomLayoutConfig.mix(surface, ink, 0.10));
        String hover = CustomLayoutConfig.hex(CustomLayoutConfig.mix(surface, ink, 0.18));
        String edge = CustomLayoutConfig.hex(CustomLayoutConfig.mix(surface, ink, 0.28));
        for (Button b : parts.buttons()) {
            String common = " -fx-text-fill: " + text + ";"
                    + " -fx-border-color: " + edge + "; -fx-border-width: 1;"
                    + " -fx-background-radius: " + PrintWindow_dim.CORNER_RADIUS + ";"
                    + " -fx-border-radius: " + PrintWindow_dim.CORNER_RADIUS + ";"
                    + " -fx-background-insets: 0; -fx-padding: 4 12 4 12;";
            String idle = "-fx-background-color: " + face + ";" + common;
            String hot = "-fx-background-color: " + hover + ";" + common;
            b.setStyle(b.isHover() ? hot : idle);
            b.getProperties().put(BUTTON_STYLES, new String[] { idle, hot });
            if (!b.getProperties().containsKey(BUTTON_HOVER_HOOK)) {
                b.getProperties().put(BUTTON_HOVER_HOOK, Boolean.TRUE);
                b.hoverProperty().addListener((obs, was, is) -> {
                    if (b.getProperties().get(BUTTON_STYLES) instanceof String[] st) {
                        b.setStyle(is ? st[1] : st[0]);
                    }
                });
            }
        }
    }

    /**
     * Puts a base colour on the frame outline, the title strip, the title and
     * the close glyph, and the theme's surface on the frame body.
     */
    private static void paint(VBox frame, TitleBar bar, Color base, Color surface) {
        String fill = CustomLayoutConfig.hex(base);
        Color ink = CustomLayoutConfig.ink(base);
        String radius = String.valueOf(PrintWindow_dim.CORNER_RADIUS);
        String body = CustomLayoutConfig.hex(surface);
        // Inline, so no stylesheet can recolour the body or round the
        // corners. -fx-base and friends make Modena derive the drop-downs,
        // spinners and radio buttons from the same surface.
        frame.setStyle("-fx-background-color: " + body + ";"
                + " -fx-base: " + body + "; -fx-background: " + body + ";"
                + " -fx-control-inner-background: " + body + ";"
                + " -fx-background-radius: " + radius + ";"
                + " -fx-border-color: " + fill + ";"
                + " -fx-border-width: " + PrintWindow_dim.FRAME_BORDER + ";"
                + " -fx-border-radius: " + radius + ";");
        bar.box().setStyle("-fx-background-color: " + fill + ";"
                + " -fx-background-radius: " + radius + " " + radius + " 0 0;");
        bar.title().setStyle(Typography.inline(Typography.Role.DIALOG_TITLE)
                + " -fx-text-fill: " + CustomLayoutConfig.hex(ink) + ";");
        bar.cross().setStroke(ink);
    }

    /**
     * The IDE's base colour as it is on screen right now: the fill of the
     * ribbon's tab strip, which the Base Color paints. See the class notes.
     *
     * @return the base colour, never null
     */
    static Color baseColour() {
        Node strip = ToolbarManager.ribbonBar;
        if (strip instanceof Region region) {
            Background bg = region.getBackground();
            if (bg != null) {
                // The last opaque colour layer is the one on top.
                Color found = null;
                for (BackgroundFill f : bg.getFills()) {
                    if (f.getFill() instanceof Color c && c.getOpacity() > 0.99) {
                        found = c;
                    }
                }
                if (found != null) {
                    return found;
                }
            }
        }
        return CustomLayoutConfig.FACTORY_BASE;
    }

    /* =====================================================================
     * TITLE BAR
     * ===================================================================== */

    /** The title strip and the parts of it that take the base colour. */
    private record TitleBar(HBox box, Label title, SVGPath cross) {
    }

    /**
     * The strip across the top: icon, title, close button. Dragging it moves
     * the window. Colours are put on by {@link #paint}.
     *
     * @param stage the window
     * @param text  the title
     */
    private static TitleBar titleBar(Stage stage, String text) {
        HBox bar = new HBox(PrintWindow_dim.TITLE_BAR_SPACING);
        bar.setAlignment(Pos.CENTER_LEFT);
        bar.setMinHeight(PrintWindow_dim.TITLE_BAR_HEIGHT);
        bar.setPrefHeight(PrintWindow_dim.TITLE_BAR_HEIGHT);
        bar.setMaxHeight(PrintWindow_dim.TITLE_BAR_HEIGHT);
        bar.setPadding(new Insets(0, 0, 0, PrintWindow_dim.TITLE_BAR_PAD_LEFT));

        Image icon = loadIcon();
        if (icon != null) {
            ImageView view = new ImageView(icon);
            view.setFitWidth(PrintWindow_dim.TITLE_ICON_SIZE);
            view.setFitHeight(PrintWindow_dim.TITLE_ICON_SIZE);
            view.setPreserveRatio(true);
            view.setSmooth(true);
            bar.getChildren().add(view);
        }

        Label title = new Label(text);

        Region grow = new Region();
        HBox.setHgrow(grow, Priority.ALWAYS);

        SVGPath cross = new SVGPath();
        bar.getChildren().addAll(title, grow, closeButton(stage, cross));

        // Drag the window by its title bar.
        double[] grab = new double[2];
        bar.setOnMousePressed(e -> {
            grab[0] = stage.getX() - e.getScreenX();
            grab[1] = stage.getY() - e.getScreenY();
        });
        bar.setOnMouseDragged(e -> {
            stage.setX(e.getScreenX() + grab[0]);
            stage.setY(e.getScreenY() + grab[1]);
        });
        return new TitleBar(bar, title, cross);
    }

    /**
     * A flat, full-height close button that turns red under the pointer. The
     * cross takes the base colour's ink, and white over the red.
     */
    private static Button closeButton(Stage stage, SVGPath cross) {
        cross.setContent("M0,0 L10,10 M10,0 L0,10");
        cross.setStrokeWidth(1.2);
        Paint[] resting = { null };

        Button close = new Button();
        close.setGraphic(cross);
        close.setFocusTraversable(false);
        close.setMinSize(PrintWindow_dim.CLOSE_BUTTON_WIDTH, PrintWindow_dim.TITLE_BAR_HEIGHT);
        close.setPrefSize(PrintWindow_dim.CLOSE_BUTTON_WIDTH, PrintWindow_dim.TITLE_BAR_HEIGHT);
        close.setMaxSize(PrintWindow_dim.CLOSE_BUTTON_WIDTH, PrintWindow_dim.TITLE_BAR_HEIGHT);
        String idle = "-fx-background-color: transparent; -fx-background-radius: 0;"
                + " -fx-background-insets: 0; -fx-padding: 0; -fx-cursor: default;";
        String hot = "-fx-background-color: " + CLOSE_HOVER + "; -fx-background-radius: 0;"
                + " -fx-background-insets: 0; -fx-padding: 0; -fx-cursor: default;";
        close.setStyle(idle);
        close.hoverProperty().addListener((obs, was, is) -> {
            close.setStyle(is ? hot : idle);
            if (is) {
                resting[0] = cross.getStroke();
                cross.setStroke(Color.WHITE);
            } else if (resting[0] != null) {
                cross.setStroke(resting[0]);
            }
        });
        close.setOnAction(e -> stage.close());
        return close;
    }

    /* =====================================================================
     * HELPERS
     * ===================================================================== */

    /**
     * Puts the Neural Code mark on a stage's title bar and taskbar entry.
     *
     * @param stage the window to brand
     */
    public static void applyIcon(Stage stage) {
        Image icon = loadIcon();
        if (icon != null) {
            stage.getIcons().add(icon);
        }
    }

    private static Image loadIcon() {
        try (InputStream in = PrintStudioWindow.class.getResourceAsStream(APP_ICON)) {
            if (in != null) {
                return new Image(in);
            }
            System.err.println("Missing window icon: " + APP_ICON);
        } catch (Exception ex) {
            System.err.println("Window icon failed: " + ex.getMessage());
        }
        return null;
    }

    private static String stem(String name) {
        int dot = name.lastIndexOf('.');
        return dot > 0 ? name.substring(0, dot) : name;
    }

    private static void warn(UI_Main ide, String header, String detail) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.initOwner(ide == null ? null : ide.stage);
        alert.setTitle(TITLE);
        alert.setHeaderText(header);
        alert.setContentText(detail == null ? "" : detail);
        if (alert.getDialogPane().getScene() != null
                && alert.getDialogPane().getScene().getWindow() instanceof Stage s) {
            applyIcon(s);
        }
        if (ide != null && ide.scene != null) {
            alert.getDialogPane().getStylesheets().setAll(ide.scene.getStylesheets());
        }
        alert.showAndWait();
    }
}
