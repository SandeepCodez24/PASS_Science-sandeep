package ui.ui_functions.tools;

import java.awt.print.PageFormat;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;

import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.standard.DialogTypeSelection;
import javax.print.attribute.standard.JobName;

import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import ui.UI_Main;
import ui.managers.ThemeManager;
import ui.ui_functions.tools.print.CodePrintable;
import ui.ui_functions.tools.print.PdfExporter;
import ui.ui_functions.tools.print.PrintModel;
import ui.ui_functions.tools.print.PrintSettings;

/**
 * The Print entry point on the ribbon.
 *
 * <h3>What replaced what</h3>
 * <p>
 * The previous version called {@code PrinterJob.printDialog()} -- the no-arg
 * overload -- and then {@code print()} without ever setting a
 * {@code Printable}. That produced the cross-platform Swing dialog, which is
 * where the Java coffee-cup icon in the title bar came from, and submitted an
 * empty job to whichever printer was chosen.
 * </p>
 * <p>
 * Two things change. The dialog is now opened through
 * {@code printDialog(PrintRequestAttributeSet)} with
 * {@link DialogTypeSelection#NATIVE}, which is the documented way to get the
 * real Windows print dialog -- proper chrome, printer properties, copies and
 * page ranges, and no Java icon to replace. And the job is handed a
 * {@link CodePrintable}, so something actually prints.
 * </p>
 *
 * <h3>Why there is a small window in front of the native dialog</h3>
 * <p>
 * The native dialog is the operating system's and cannot host a light/dark
 * choice. That choice only matters for PDF anyway -- printing a dark listing
 * onto paper floods the sheet with ink -- so it lives here, alongside the two
 * destinations. Print opens the native dialog; Save as PDF opens an ordinary
 * save dialog. This window is a JavaFX {@link Stage}, so unlike an AWT dialog
 * it can and does carry the Neural Code icon.
 * </p>
 *
 * <h3>Threading</h3>
 * <p>
 * {@code PrinterJob} is AWT. Calling it on the JavaFX application thread means
 * a modal native dialog pumping its own message loop while the FX thread is
 * blocked inside it, which on Windows ranges from a frozen UI to a deadlock.
 * The whole print leg therefore runs on a daemon thread and comes back through
 * {@link Platform#runLater}.
 * </p>
 */
public final class PrintStudioWindow {

    /** The Neural Code window icon. Case matters on a case-sensitive jar. */
    private static final String APP_ICON = "/icons/ic_18_nc.PNG";

    private PrintStudioWindow() {
    }

    /**
     * Opens the print chooser for the active editor tab.
     *
     * @param ide the IDE controller
     */
    public static void open(UI_Main ide) {
        PrintModel.Document doc = PrintModel.fromActiveTab(ide);
        if (doc == null) {
            warn(ide, "Nothing to print", "Open a file in the editor first.");
            return;
        }

        Stage stage = new Stage();
        stage.initOwner(ide.stage);
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Print");
        applyIcon(stage);

        Label what = new Label(doc.title());
        what.setStyle("-fx-font-weight: bold;");
        Label where = new Label(doc.headerText());
        where.setStyle("-fx-opacity: 0.75;");
        Label count = new Label(doc.lines().size() + " lines");
        count.setStyle("-fx-opacity: 0.75;");

        ToggleGroup themeGroup = new ToggleGroup();
        RadioButton light = new RadioButton("Light");
        RadioButton dark = new RadioButton("Dark");
        light.setToggleGroup(themeGroup);
        dark.setToggleGroup(themeGroup);
        light.setSelected(true);

        Label themeLabel = new Label("PDF theme");
        HBox themeRow = new HBox(10, themeLabel, light, dark);
        themeRow.setAlignment(Pos.CENTER_LEFT);

        Button print = new Button("Print\u2026");
        Button pdf = new Button("Save as PDF\u2026");
        Button cancel = new Button("Cancel");
        print.setDefaultButton(true);
        cancel.setCancelButton(true);

        Region grow = new Region();
        HBox.setHgrow(grow, javafx.scene.layout.Priority.ALWAYS);
        HBox buttons = new HBox(8, grow, cancel, pdf, print);
        buttons.setAlignment(Pos.CENTER_RIGHT);

        print.setOnAction(e -> {
            stage.close();
            // Paper is always light; see the class notes.
            printOnBackgroundThread(ide, doc, PrintSettings.forPaper());
        });

        pdf.setOnAction(e -> {
            PrintSettings.Theme theme = dark.isSelected()
                    ? PrintSettings.Theme.DARK
                    : PrintSettings.Theme.LIGHT;
            stage.close();
            exportPdf(ide, doc, PrintSettings.forPdf(theme));
        });

        cancel.setOnAction(e -> stage.close());

        VBox root = new VBox(12, what, where, count, new javafx.scene.control.Separator(),
                themeRow, buttons);
        root.setPadding(new Insets(16));
        root.setPrefWidth(420);

        Scene scene = new Scene(root);
        // Inherit whatever the main window is wearing, so this does not flash
        // a white panel in front of a dark IDE.
        if (ide.scene != null) {
            scene.getStylesheets().setAll(ide.scene.getStylesheets());
        }
        stage.setScene(scene);
        stage.setResizable(false);
        stage.showAndWait();
    }

    /* =====================================================================
     * PAPER
     * ===================================================================== */

    private static void printOnBackgroundThread(UI_Main ide,
            PrintModel.Document doc,
            PrintSettings settings) {

        Thread worker = new Thread(() -> {
            try {
                PrinterJob job = PrinterJob.getPrinterJob();
                job.setJobName("Neural Code - " + doc.title());

                PageFormat format = job.defaultPage();
                CodePrintable printable = new CodePrintable(doc, settings, format);
                job.setPageable(printable);

                PrintRequestAttributeSet attrs = new HashPrintRequestAttributeSet();
                // THE line that replaces the Swing dialog with the Windows one.
                attrs.add(DialogTypeSelection.NATIVE);
                attrs.add(new JobName("Neural Code - " + doc.title(), null));

                if (job.printDialog(attrs)) {
                    job.print(attrs);
                }
            } catch (PrinterException ex) {
                Platform.runLater(() -> warn(ide, "Print failed", ex.getMessage()));
            }
        }, "astra-print");

        worker.setDaemon(true);
        worker.start();
    }

    /* =====================================================================
     * PDF
     * ===================================================================== */

    private static void exportPdf(UI_Main ide,
            PrintModel.Document doc,
            PrintSettings settings) {

        FileChooser fc = new FileChooser();
        fc.setTitle("Save as PDF");
        fc.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("PDF document (*.pdf)", "*.pdf"));
        fc.setInitialFileName(stem(doc.title()) + ".pdf");

        if (doc.path() != null && doc.path().getParent() != null) {
            fc.setInitialDirectory(doc.path().getParent().toFile());
        } else if (ide.currentFolder != null && Files.isDirectory(ide.currentFolder)) {
            fc.setInitialDirectory(ide.currentFolder.toFile());
        }

        File target = fc.showSaveDialog(ide.stage);
        if (target == null) {
            return;
        }
        if (!target.getName().toLowerCase().endsWith(".pdf")) {
            target = new File(target.getParentFile(), target.getName() + ".pdf");
        }

        final File file = target;
        Thread worker = new Thread(() -> {
            try {
                PdfExporter.export(doc, settings, file);
                Platform.runLater(() -> {
                    if (ide.console != null) {
                        ide.console.appendText("Exported PDF: " + file + "\n");
                    }
                });
            } catch (Exception ex) {
                Platform.runLater(() -> warn(ide, "PDF export failed", ex.getMessage()));
            }
        }, "astra-pdf-export");

        worker.setDaemon(true);
        worker.start();
    }

    /* =====================================================================
     * HELPERS
     * ===================================================================== */

    /**
     * Puts the Neural Code mark on a stage's title bar.
     *
     * @param stage the window to brand
     */
    public static void applyIcon(Stage stage) {
        try (InputStream in = PrintStudioWindow.class.getResourceAsStream(APP_ICON)) {
            if (in != null) {
                stage.getIcons().add(new Image(in));
            } else {
                System.err.println("Missing window icon: " + APP_ICON);
            }
        } catch (Exception ex) {
            System.err.println("Window icon failed: " + ex.getMessage());
        }
    }

    private static String stem(String name) {
        int dot = name.lastIndexOf('.');
        return dot > 0 ? name.substring(0, dot) : name;
    }

    private static void warn(UI_Main ide, String header, String detail) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.initOwner(ide == null ? null : ide.stage);
        alert.setTitle("Print");
        alert.setHeaderText(header);
        alert.setContentText(detail == null ? "" : detail);
        if (alert.getDialogPane().getScene() != null
                && alert.getDialogPane().getScene().getWindow() instanceof Stage s) {
            applyIcon(s);
        }
        if (ide != null && ide.scene != null) {
            alert.getDialogPane().getStylesheets().setAll(ide.scene.getStylesheets());
        }
        // Referenced so a future dark-aware alert has the hook already here.
        ThemeManager.getActiveTheme();
        alert.showAndWait();
    }
}
