package ui.ui_functions.tools;

import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import ui.explorer.support.IconLoader;

/**
 * Loads the Settings &gt; Layout icon set from
 * {@code /icons/layout/<theme>/<name>.png}.
 *
 * <p>
 * A twin of {@link SettingsIcons}: same folder convention, same weak registry,
 * same 48px masters scaled by the {@link ImageView}. {@code ThemeManager}
 * calls {@link #setDarkTheme(boolean)}, so every icon on screen switches ink
 * with the theme.
 * </p>
 *
 * <p>
 * One addition: {@link #setName(ImageView, String)} re-points a live view at
 * another icon, which is how the Full Screen button swaps between its enter
 * and exit glyphs without being rebuilt.
 * </p>
 */
public final class LayoutIcons {

    // ---- Layouts ---------------------------------------------------------
    public static final String LAYOUT_DEFAULT = "layout_default";
    public static final String LAYOUT_BOT_CENTERED = "layout_bot_centered";
    public static final String LAYOUT_EDITOR_CLI = "layout_editor_cli";
    public static final String LAYOUT_DIRECTORY_CENTERED = "layout_directory_centered";
    public static final String LAYOUT_EDITOR_BOT_CLI = "layout_editor_bot_cli";
    public static final String LAYOUT_CUSTOM = "layout_custom";

    // ---- View ------------------------------------------------------------
    public static final String FULLSCREEN_ENTER = "fullscreen_enter";
    public static final String FULLSCREEN_EXIT = "fullscreen_exit";

    // ---- Gutter ----------------------------------------------------------
    public static final String LINE_NUMBERS = "line_numbers";
    public static final String LINE_FOLDERS = "line_folders";

    // ---- Zoom ------------------------------------------------------------
    public static final String ZOOM_RESET = "zoom_reset";
    public static final String ZOOM_IN = "zoom_in";
    public static final String ZOOM_OUT = "zoom_out";

    private static final String BASE = "/icons/layout/";
    private static final String NAME_KEY = "layoutIconName";

    private static final List<WeakReference<ImageView>> LIVE = new CopyOnWriteArrayList<>();

    private static volatile boolean dark = false;

    private LayoutIcons() {
    }

    /**
     * Builds an icon view.
     *
     * @param name one of the constants above
     * @param size edge length in pixels; the image is scaled to fit
     * @return the configured view, already registered for theme swaps
     */
    public static ImageView icon(String name, double size) {
        ImageView view = new ImageView();
        view.getProperties().put(NAME_KEY, name);
        view.setFitWidth(size);
        view.setFitHeight(size);
        view.setPreserveRatio(true);
        view.setSmooth(true);
        view.setMouseTransparent(true);
        apply(view);
        LIVE.add(new WeakReference<>(view));
        return view;
    }

    /**
     * Points a view built by {@link #icon} at another icon of this set.
     *
     * @param view the view
     * @param name the new icon name
     */
    public static void setName(ImageView view, String name) {
        if (view == null || name == null) {
            return;
        }
        view.getProperties().put(NAME_KEY, name);
        apply(view);
    }

    /**
     * Switches the whole set between the two inks and refreshes every icon on
     * screen. Safe to call when nothing has changed.
     *
     * @param useDark {@code true} for the dark-theme ink
     */
    public static void setDarkTheme(boolean useDark) {
        if (useDark == dark) {
            return;
        }
        dark = useDark;
        Iterator<WeakReference<ImageView>> it = LIVE.iterator();
        while (it.hasNext()) {
            WeakReference<ImageView> ref = it.next();
            ImageView view = ref.get();
            if (view == null) {
                LIVE.remove(ref);
            } else {
                apply(view);
            }
        }
    }

    /** @return {@code true} if the dark-theme ink is selected */
    public static boolean isDarkTheme() {
        return dark;
    }

    /**
     * @param name base file name, without theme folder or extension
     * @return the classpath resource path for the active theme
     */
    public static String path(String name) {
        return BASE + (dark ? "dark/" : "light/") + name + ".png";
    }

    private static void apply(ImageView view) {
        Object name = view.getProperties().get(NAME_KEY);
        if (name == null) {
            return;
        }
        Image image = IconLoader.load(LayoutIcons.class, path(name.toString()));
        if (image != null) {
            view.setImage(image);
        }
    }
}
