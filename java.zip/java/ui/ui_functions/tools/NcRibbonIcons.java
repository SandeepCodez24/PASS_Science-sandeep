package ui.ui_functions.tools;

import java.lang.ref.WeakReference;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import ui.explorer.support.IconLoader;

/**
 * Loads the {@code /icons/NC_ribbon} set, choosing the light or dark art for
 * the active theme and the raster bucket closest to the size being asked for.
 *
 * <h3>Why this class exists</h3>
 * The other raster sets in this project ship as two files side by side -- the
 * plain base name and a {@code _dark} twin -- and {@link HomeRibbonIcons}
 * handles them by appending a suffix. The NC_ribbon set does not follow that
 * shape. It ships as a size ladder under two theme folders:
 *
 * <pre>
 *   /icons/NC_ribbon/light/png/{16,24,32,48,64,128,256}/ic_undo.png
 *   /icons/NC_ribbon/dark/png/{16,24,32,48,64,128,256}/ic_undo.png
 * </pre>
 *
 * so the theme lives in a path segment rather than a suffix, and there is a
 * size decision to make on top of it. Appending {@code "_dark"} would resolve
 * nothing. Hence a resolver of its own.
 *
 * <h3>Picking a bucket</h3>
 * The caller asks for a logical size -- {@code Dim.Icons.TOOLBAR_DEFAULT} is
 * {@code pxi(22)}, so on a 125% display it arrives as 27.5. Scaling a 256px
 * bitmap down to 27 is soft and scaling a 16px one up is worse, so
 * {@link #bucketFor(double)} picks the smallest ladder rung that is at least
 * the requested size. 22 takes the 24 rung; 27.5 takes 32. The ImageView is
 * still fitted to the exact requested size, so layout is unaffected -- this
 * only decides which file gets decoded.
 *
 * <h3>Live theme swaps</h3>
 * Same contract as {@link HomeRibbonIcons}: every view handed out is held in a
 * weak registry, and {@link #setDarkTheme(boolean)} re-points the icons already
 * on screen. Nothing needs rebuilding, and a view that has been dropped from
 * the scene graph is collected normally.
 *
 * <h3>Icons without a themed variant</h3>
 * {@code ic_account}, {@code ic_search}, {@code ic_signin} and
 * {@code ic_signout} have no light/dark art yet. For those,
 * {@link #resolve(String)} falls through to the flat file at the folder root,
 * which is exactly where they sit today. They keep working untouched, and when
 * their themed variants are dropped into the two folders later they start
 * resolving with no code change at all.
 */
public final class NcRibbonIcons {

    /** Folder root. The flat, un-themed assets still live directly here. */
    private static final String BASE = "/icons/NC_ribbon/";

    /** Raster ladder shipped for each theme, ascending. */
    private static final int[] BUCKETS = { 16, 24, 32, 48, 64, 128, 256 };

    /** Property keys used to remember what a registered view was asked for. */
    private static final String NAME_KEY = "ncRibbonIconName";
    private static final String SIZE_KEY = "ncRibbonIconSize";

    private static final List<WeakReference<ImageView>> LIVE = new CopyOnWriteArrayList<>();

    private static volatile boolean dark = false;

    private NcRibbonIcons() {
    }

    // =====================================================================
    // Public API
    // =====================================================================

    /**
     * Builds a theme-aware icon view.
     *
     * @param name base file name -- no folder, no extension, e.g.
     *             {@code "ic_undo"}. A full classpath path is also accepted and
     *             reduced to its base name, so existing call sites that pass
     *             {@code "/icons/NC_ribbon/ic_undo.png"} keep working.
     * @param size edge length in pixels; the view is fitted to exactly this
     * @return the configured view, already registered for theme swaps
     */
    public static ImageView icon(String name, double size) {
        String base = baseName(name);
        ImageView view = new ImageView();
        view.getProperties().put(NAME_KEY, base);
        view.getProperties().put(SIZE_KEY, size);
        view.setFitWidth(size);
        view.setFitHeight(size);
        view.setPreserveRatio(true);
        view.setSmooth(true);
        apply(view);
        LIVE.add(new WeakReference<>(view));
        return view;
    }

    /**
     * Switches the set between the light and dark art and refreshes every icon
     * currently on screen. Safe to call when nothing has changed.
     *
     * <p>
     * Call this from {@code ThemeManager.applyIconInk}, alongside
     * {@code HomeRibbonIcons.setDarkTheme(...)}.
     * </p>
     *
     * @param useDark {@code true} for the dark-theme art
     */
    public static void setDarkTheme(boolean useDark) {
        if (useDark == dark) {
            return;
        }
        dark = useDark;
        refresh();
    }

    /**
     * @return {@code true} if the dark-theme art is currently selected
     */
    public static boolean isDarkTheme() {
        return dark;
    }

    /**
     * @param name base file name or full path
     * @param size requested edge length in pixels
     * @return the classpath resource path that will actually be loaded
     */
    public static String path(String name, double size) {
        return resolve(baseName(name), size);
    }

    /**
     * @param path a classpath resource path
     * @return {@code true} if this path belongs to the NC_ribbon set, and so
     *         should be routed through this resolver rather than loaded flat
     */
    public static boolean owns(String path) {
        return path != null && path.startsWith(BASE);
    }

    /**
     * Re-points every registered icon without changing the theme. Useful after
     * a DPI change, where the size buckets may need re-picking.
     */
    public static void refreshAll() {
        refresh();
    }

    // =====================================================================
    // Resolution
    // =====================================================================

    /**
     * Strips folder and extension so both {@code "ic_undo"} and
     * {@code "/icons/NC_ribbon/ic_undo.png"} land on the same key.
     *
     * @param name base name or full path
     * @return the bare base name
     */
    private static String baseName(String name) {
        if (name == null || name.isBlank()) {
            return "";
        }
        String s = name;
        int slash = s.lastIndexOf('/');
        if (slash >= 0) {
            s = s.substring(slash + 1);
        }
        int dot = s.lastIndexOf('.');
        if (dot > 0) {
            s = s.substring(0, dot);
        }
        return s;
    }

    /**
     * Smallest ladder rung that is at least {@code size}, so an icon is scaled
     * down rather than up. Anything above the top rung takes the top rung.
     *
     * @param size requested edge length in pixels
     * @return the bucket folder number
     */
    private static int bucketFor(double size) {
        for (int bucket : BUCKETS) {
            if (bucket >= size) {
                return bucket;
            }
        }
        return BUCKETS[BUCKETS.length - 1];
    }

    /**
     * Themed path first, flat root path second.
     *
     * <p>
     * The existence check is what lets the un-themed four
     * ({@code ic_account}, {@code ic_search}, {@code ic_signin},
     * {@code ic_signout}) coexist with the themed five in one folder. It costs
     * a {@code getResource} call on a cache miss only -- once
     * {@link IconLoader} has the image, neither branch runs again.
     * </p>
     *
     * @param base bare base name
     * @param size requested edge length in pixels
     * @return a resolvable classpath path
     */
    private static String resolve(String base, double size) {
        String themed = BASE
                + (dark ? "dark" : "light")
                + "/png/" + bucketFor(size) + "/"
                + base + ".png";

        URL url = NcRibbonIcons.class.getResource(themed);
        if (url != null) {
            return themed;
        }
        return BASE + base + ".png";
    }

    // =====================================================================
    // Registry
    // =====================================================================

    private static void refresh() {
        Iterator<WeakReference<ImageView>> it = LIVE.iterator();
        while (it.hasNext()) {
            WeakReference<ImageView> ref = it.next();
            ImageView view = ref.get();
            if (view == null) {
                LIVE.remove(ref);
            } else {
                apply(view);
            }
        }
    }

    private static void apply(ImageView view) {
        Object name = view.getProperties().get(NAME_KEY);
        Object size = view.getProperties().get(SIZE_KEY);
        if (name == null) {
            return;
        }
        double px = (size instanceof Number n)
                ? n.doubleValue()
                : view.getFitWidth();

        Image image = IconLoader.load(NcRibbonIcons.class, resolve(name.toString(), px));
        if (image != null) {
            view.setImage(image);
        }
    }
}
