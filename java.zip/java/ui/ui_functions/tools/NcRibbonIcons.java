package ui.ui_functions.tools;

import java.lang.ref.WeakReference;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import ui.explorer.support.IconLoader;

/**
 * Loads the {@code /icons/NC_ribbon} set, choosing the light or dark art for
 * the active theme.
 *
 * <h3>Layout</h3>
 *
 * <pre>
 *   /icons/NC_ribbon/light/ic_undo.png
 *   /icons/NC_ribbon/dark/ic_undo.png
 * </pre>
 *
 * One 256px master per theme. JavaFX downsamples it to whatever
 * {@code fitWidth} asks for, and with {@code setSmooth(true)} that resample is
 * a good one -- an earlier revision of this class shipped a
 * {16,24,32,48,64,128,256} ladder and picked a rung per call site, which cost
 * seventy files to maintain and bought nothing a single master does not already
 * give. The ladder would only earn its keep if the icons were pixel-hinted per
 * size, which these are not: they are flat vector art with no 1px detail to
 * preserve.
 *
 * <h3>Theme, not suffix</h3>
 * The other raster sets in this project ship as {@code name.png} /
 * {@code name_dark.png} twins in one folder, and {@link HomeRibbonIcons}
 * resolves them by appending a suffix. This set puts the theme in a path
 * segment instead, so appending {@code "_dark"} would resolve nothing -- hence
 * a resolver of its own rather than a tweak to that one.
 *
 * <h3>Live theme swaps</h3>
 * Same contract as {@link HomeRibbonIcons}: every view handed out is held in a
 * weak registry, and {@link #setDarkTheme(boolean)} re-points the icons already
 * on screen. Nothing needs rebuilding, and a view dropped from the scene graph
 * is collected normally.
 *
 * <h3>Icons without a themed variant</h3>
 * {@code ic_account}, {@code ic_search}, {@code ic_signin} and
 * {@code ic_signout} have no light/dark art yet. For those,
 * {@link #resolve(String)} falls through to the flat file at the folder root,
 * which is where they sit today. They keep working untouched, and when their
 * themed variants are added later they start resolving with no code change.
 */
public final class NcRibbonIcons {

    /** Folder root. The flat, un-themed assets still live directly here. */
    private static final String BASE = "/icons/NC_ribbon/";

    /** Remembers what a registered view was asked for, so it can be re-pointed. */
    private static final String NAME_KEY = "ncRibbonIconName";

    private static final List<WeakReference<ImageView>> LIVE = new CopyOnWriteArrayList<>();

    private static volatile boolean dark = false;

    private NcRibbonIcons() {
    }

    // =====================================================================
    // Public API
    // =====================================================================

    /**
     * Builds a theme-aware icon view.
     *
     * @param name base file name -- no folder, no extension, e.g.
     *             {@code "ic_undo"}. A full classpath path is also accepted and
     *             reduced to its base name, so call sites that pass
     *             {@code "/icons/NC_ribbon/ic_undo.png"} keep working.
     * @param size edge length in pixels; the view is fitted to exactly this
     * @return the configured view, already registered for theme swaps
     */
    public static ImageView icon(String name, double size) {
        ImageView view = new ImageView();
        view.getProperties().put(NAME_KEY, baseName(name));
        view.setFitWidth(size);
        view.setFitHeight(size);
        view.setPreserveRatio(true);
        view.setSmooth(true);
        apply(view);
        LIVE.add(new WeakReference<>(view));
        return view;
    }

    /**
     * Switches the set between the light and dark art and refreshes every icon
     * currently on screen. Safe to call when nothing has changed.
     *
     * <p>
     * Call this from {@code ThemeManager.applyIconInk}, alongside
     * {@code HomeRibbonIcons.setDarkTheme(...)}.
     * </p>
     *
     * @param useDark {@code true} for the dark-theme art
     */
    public static void setDarkTheme(boolean useDark) {
        if (useDark == dark) {
            return;
        }
        dark = useDark;
        refresh();
    }

    /**
     * @return {@code true} if the dark-theme art is currently selected
     */
    public static boolean isDarkTheme() {
        return dark;
    }

    /**
     * @param name base file name or full path
     * @return the classpath resource path that will actually be loaded
     */
    public static String path(String name) {
        return resolve(baseName(name));
    }

    /**
     * @param path a classpath resource path
     * @return {@code true} if this path belongs to the NC_ribbon set, and so
     *         should be routed through this resolver rather than loaded flat
     */
    public static boolean owns(String path) {
        return path != null && path.startsWith(BASE);
    }

    // =====================================================================
    // Resolution
    // =====================================================================

    /**
     * Strips folder and extension so both {@code "ic_undo"} and
     * {@code "/icons/NC_ribbon/ic_undo.png"} land on the same key.
     *
     * @param name base name or full path
     * @return the bare base name
     */
    private static String baseName(String name) {
        if (name == null || name.isBlank()) {
            return "";
        }
        String s = name;
        int slash = s.lastIndexOf('/');
        if (slash >= 0) {
            s = s.substring(slash + 1);
        }
        int dot = s.lastIndexOf('.');
        if (dot > 0) {
            s = s.substring(0, dot);
        }
        return s;
    }

    /**
     * Themed path first, flat root path second.
     *
     * <p>
     * The existence check is what lets the un-themed four ({@code ic_account},
     * {@code ic_search}, {@code ic_signin}, {@code ic_signout}) coexist with
     * the themed five in one folder. It costs a {@code getResource} call on a
     * cache miss only -- once {@link IconLoader} holds the image, neither
     * branch runs again.
     * </p>
     *
     * @param base bare base name
     * @return a resolvable classpath path
     */
    private static String resolve(String base) {
        String themed = BASE + (dark ? "dark" : "light") + "/" + base + ".png";
        URL url = NcRibbonIcons.class.getResource(themed);
        return (url != null) ? themed : BASE + base + ".png";
    }

    // =====================================================================
    // Registry
    // =====================================================================

    private static void refresh() {
        Iterator<WeakReference<ImageView>> it = LIVE.iterator();
        while (it.hasNext()) {
            WeakReference<ImageView> ref = it.next();
            ImageView view = ref.get();
            if (view == null) {
                LIVE.remove(ref);
            } else {
                apply(view);
            }
        }
    }

    private static void apply(ImageView view) {
        Object name = view.getProperties().get(NAME_KEY);
        if (name == null) {
            return;
        }
        Image image = IconLoader.load(NcRibbonIcons.class, resolve(name.toString()));
        if (image != null) {
            view.setImage(image);
        }
    }
}
