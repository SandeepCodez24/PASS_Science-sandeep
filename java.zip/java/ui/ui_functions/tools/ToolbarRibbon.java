package ui.ui_functions.tools;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToolBar;
import javafx.scene.control.Tooltip;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import ui.UI_Main;
import ui.account.AccountMenu;
import ui.design.Dim;
import ui.managers.EditorManager;
import ui.ribbon_interface.tool_bar.RibbonCollapse;

/**
 * Builds the Row-1 tab strip: the six tabs, the search box and the trailing
 * action cluster.
 *
 * <h3>Layout</h3>
 * <p>
 * The tabs occupy {@code TABS_FRACTION} of the width; a fixed gap then places
 * the search box so its midpoint sits at roughly 75%; a growing spacer pushes
 * the action cluster to the far right edge. Those three fractions, and every
 * height and padding below, come from {@code ui.design.Dim.RibbonBar}.
 * </p>
 *
 * <h3>Two things this rewrite fixed</h3>
 * <ol>
 * <li>The content row's width was bound to {@code bar.width - 20}. Twenty is
 * the Row-2 band's horizontal inset; this bar's padding is 8 on each side, so
 * the row was 4px narrower than the space available. It now subtracts
 * {@code Dim.RibbonBar.H_INSET}, which is derived from the same padding
 * constant {@code DesignStylesheet} writes into the CSS.</li>
 * <li>The search box was styled inline with light-theme colours -- white
 * background, {@code #34495e} border, dark text -- so it stayed white in dark
 * mode. Its geometry now comes from the design layer and its colours from
 * {@code .ribbon-search-box} / {@code .ribbon-search-field} in the theme
 * files.</li>
 * </ol>
 */
public final class ToolbarRibbon {

    /** Style class for the rounded search box. */
    private static final String SEARCH_BOX_CLASS = "ribbon-search-box";

    /** Style class for the text field inside the search box. */
    private static final String SEARCH_FIELD_CLASS = "ribbon-search-field";

    private ToolbarRibbon() {
    }

    /**
     * Builds the tab strip and installs it on {@code ToolbarState.ribbonBar}.
     *
     * @param ide the IDE controller
     */
    public static void buildRibbonTabs(UI_Main ide) {

        // min == pref == max locks the height. See Dim.RibbonBar.HEIGHT for
        // why it cannot go much below its current value.
        ToolbarState.ribbonBar.setMinHeight(Dim.RibbonBar.HEIGHT);
        ToolbarState.ribbonBar.setPrefHeight(Dim.RibbonBar.HEIGHT);
        ToolbarState.ribbonBar.setMaxHeight(Dim.RibbonBar.HEIGHT);

        ToggleButton home = ribbonTab("Home", ide);
        ToggleButton signals = ribbonTab("Signals", ide);
        ToggleButton jtag = ribbonTab("JTAG", ide);
        ToggleButton commission = ribbonTab("Commission", ide);
        ToggleButton settings = ribbonTab("Settings", ide);
        ToggleButton help = ribbonTab("Help", ide);

        home.setOnAction(e -> activateTab(home, ide.homeTB, ide));
        signals.setOnAction(e -> activateTab(signals, ide.compileTB, ide));
        jtag.setOnAction(e -> activateTab(jtag, ide.jtagTB, ide));
        commission.setOnAction(e -> activateTab(commission, ide.commissionTB, ide));
        settings.setOnAction(e -> activateTab(settings, ide.preferencesTB, ide));
        help.setOnAction(e -> activateTab(help, ide.helpTB, ide));

        // Tabs spread evenly so together they cover TABS_FRACTION of the width.
        HBox tabsBox = new HBox(home, signals, jtag, commission, settings, help);
        tabsBox.setAlignment(Pos.CENTER_LEFT);
        tabsBox.setSpacing(0);
        for (ToggleButton t : new ToggleButton[] { home, signals, jtag, commission, settings, help }) {
            t.setMaxWidth(Double.MAX_VALUE);
            HBox.setHgrow(t, Priority.ALWAYS);
        }
        tabsBox.prefWidthProperty().bind(
                ToolbarState.ribbonBar.widthProperty().multiply(Dim.RibbonBar.TABS_FRACTION));
        tabsBox.minWidthProperty().bind(tabsBox.prefWidthProperty());

        HBox searchBox = buildSearchBox(ide);
        searchBox.prefWidthProperty().bind(
                ToolbarState.ribbonBar.widthProperty().multiply(Dim.RibbonBar.SEARCH_FRACTION));
        searchBox.minWidthProperty().bind(searchBox.prefWidthProperty());

        // Fixed gap between tabs and search so the search centre lands ~75%.
        Region gap = new Region();
        gap.prefWidthProperty().bind(
                ToolbarState.ribbonBar.widthProperty().multiply(Dim.RibbonBar.GAP_FRACTION));
        gap.minWidthProperty().bind(gap.prefWidthProperty());

        HBox rightCluster = buildRightCluster(ide);

        // Growing spacer pushes the right cluster to the far right edge.
        Region grow = new Region();
        HBox.setHgrow(grow, Priority.ALWAYS);

        // Single root row so the ToolBar never shows an overflow button.
        HBox root = new HBox(tabsBox, gap, searchBox, grow, rightCluster);
        root.setAlignment(Pos.CENTER_LEFT);
        root.setSpacing(Dim.RibbonBar.ROOT_SPACING);
        root.prefWidthProperty().bind(
                ToolbarState.ribbonBar.widthProperty().subtract(Dim.RibbonBar.H_INSET));

        ToolbarState.ribbonBar.getItems().setAll(root);

        home.setSelected(true);
        activateTab(home, ide.homeTB, ide);
    }

    /**
     * A text-only tab. Every visual -- unselected, hover and the selected
     * "attached" look -- comes from {@code .ribbon-tab} and its
     * {@code :selected} pseudo-class, so the tab stays theme-aware and the
     * active tab can share the exact colour of the band below it.
     *
     * @param text tab label
     * @param ide  the IDE controller, for the shared toggle group
     * @return the configured tab
     */
    private static ToggleButton ribbonTab(String text, UI_Main ide) {
        ToggleButton b = new ToggleButton(text);
        b.setToggleGroup(ide.ribbonGroup);
        b.setFocusTraversable(false);
        b.setAlignment(Pos.CENTER);
        // Deliberately NOT stretched to the full strip height: keeping the tab
        // at its padding-driven height lets the row centre it, so the selected
        // tab's four-sided border is fully visible with a margin above and
        // below rather than clipped at the strip edges.
        if (!b.getStyleClass().contains("ribbon-tab")) {
            b.getStyleClass().add("ribbon-tab");
        }
        // Second way to collapse the band: double-click the active tab. Guarded
        // on isSelected so a double-click that is really "switch tab, then
        // change your mind" does not collapse the band underneath you.
        b.setOnMouseClicked(e -> {
            if (e.getClickCount() == 2 && b.isSelected()) {
                RibbonCollapse.toggle();
                e.consume();
            }
        });
        return b;
    }

    /**
     * Swaps in the Row-2 toolbar belonging to the clicked tab. Selection
     * visuals are handled entirely by CSS.
     *
     * @param tab the clicked tab
     * @param tb  its Row-2 toolbar
     * @param ide the IDE controller
     */
    private static void activateTab(ToggleButton tab, ToolBar tb, UI_Main ide) {
        // A ToggleButton in a ToggleGroup deselects itself when clicked a
        // second time. Forcing it back on keeps exactly one tab highlighted,
        // which matters now that a double-click is a meaningful gesture.
        tab.setSelected(true);
        ToolbarStyling.showToolbar(ide, tb);
    }

    /**
     * The rounded search box: a text field with a magnifier glyph at its right
     * end. The search covers Neural Code extension methods and work-bench
     * guidance, not code. Shortcut: Alt+Space.
     *
     * @param ide the IDE controller
     * @return the search box
     */
    private static HBox buildSearchBox(UI_Main ide) {
        TextField field = new TextField();
        field.setPromptText("Search (Alt+Space)");
        field.setFocusTraversable(false);
        field.setStyle("");
        if (!field.getStyleClass().contains(SEARCH_FIELD_CLASS)) {
            field.getStyleClass().add(SEARCH_FIELD_CLASS);
        }
        HBox.setHgrow(field, Priority.ALWAYS);
        // Exposed for the Alt+Space shortcut wired in Main_Window.
        ToolbarState.searchField = field;

        ImageView lens = safeIcon("/icons/NC_ribbon/ic_search.png",
                Dim.RibbonBar.SEARCH_ICON_SIZE);

        HBox box = new HBox(field);
        if (lens != null) {
            box.getChildren().add(lens);
        }
        box.setAlignment(Pos.CENTER_LEFT);
        box.setStyle("");
        if (!box.getStyleClass().contains(SEARCH_BOX_CLASS)) {
            box.getStyleClass().add(SEARCH_BOX_CLASS);
        }
        Tooltip.install(box, new Tooltip("Search extension methods & work-bench help (Alt+Space)"));
        return box;
    }

    /**
     * The trailing action cluster: undo, redo, save, print, then the
     * notification bell, then the account control.
     *
     * @param ide the IDE controller
     * @return the cluster
     */
    private static HBox buildRightCluster(UI_Main ide) {
        Button undo = iconButton("/icons/NC_ribbon/ic_undo.png", "Undo",
                () -> System.out.println("[Ribbon] Undo (todo: wire to editor)"));
        Button redo = iconButton("/icons/NC_ribbon/ic_redo.png", "Redo",
                () -> System.out.println("[Ribbon] Redo (todo: wire to editor)"));
        Button save = iconButton("/icons/NC_ribbon/ic_save.png", "Save",
                () -> EditorManager.saveCurrentFile(ide));
        Button print = iconButton("/icons/NC_ribbon/ic_print.png", "Print",
                () -> ui.ui_functions.tools.PrintStudioWindow.open(ide));

        HBox actions = new HBox(undo, redo, save, print);
        actions.setAlignment(Pos.CENTER);
        actions.getStyleClass().add("ribbon-actions");

        Button bell = iconButton("/icons/NC_ribbon/ic_notification.png", "Notifications",
                () -> System.out.println("[Ribbon] Notifications (todo)"));

        AccountMenu account = new AccountMenu();

        HBox cluster = new HBox(Dim.RibbonBar.CLUSTER_SPACING, actions, bell, account.getNode());
        cluster.setAlignment(Pos.CENTER_RIGHT);
        return cluster;
    }

    private static Button iconButton(String iconPath, String tip, Runnable action) {
        ImageView iv = safeIcon(iconPath, Dim.RibbonBar.ACTION_ICON_SIZE);
        Button b = (iv != null) ? new Button("", iv) : new Button(tip);
        b.setFocusTraversable(false);
        b.getStyleClass().add("ribbon-icon-button");
        b.setStyle("");
        b.setTooltip(new Tooltip(tip));
        b.setOnAction(e -> action.run());
        return b;
    }

    private static ImageView safeIcon(String path, double size) {
        try {
            ImageView iv = ToolbarIcons.icon(path, size);
            iv.setPreserveRatio(true);
            return iv;
        } catch (Exception ex) {
            System.err.println("Ribbon icon missing: " + path);
            return null;
        }
    }
}
