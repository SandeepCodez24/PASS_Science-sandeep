package ui.ui_functions.tools;

import java.util.ArrayList;
import java.util.List;

import javafx.geometry.Bounds;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToolBar;
import javafx.scene.control.Tooltip;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import ui.UI_Main;
import ui.account.AccountMenu;
import ui.design.Dim;
import ui.managers.EditorManager;
import ui.ribbon_interface.tool_bar.RibbonCollapse;

/**
 * Builds the Row-1 tab strip: the six tabs, the search box and the trailing
 * action cluster.
 *
 * <h3>Layout</h3>
 * <p>
 * The tabs occupy {@code TABS_FRACTION} of the width; a fixed gap then places
 * the search box so its midpoint sits at roughly 75%; a growing spacer pushes
 * the action cluster to the far right edge. Those three fractions, and every
 * height and padding below, come from {@code ui.design.Dim.RibbonBar}.
 * </p>
 *
 * <h3>The selected tab joins the band below it, and only at the bottom</h3>
 * <p>
 * The tab used to sit at its padding-driven height and be centred in the strip,
 * which left navy above <em>and below</em> it: the active tab read as a chip
 * floating on the ribbon rather than as the front edge of the panel it opens.
 * MATLAB does the opposite -- its HOME tab is open at the bottom and shares the
 * toolstrip's colour -- but it still keeps a clear margin at the top, against
 * the title bar.
 * </p>
 * <p>
 * The gap is an {@code HBox} <b>margin</b> on each tab, set here in Java and
 * nowhere else:
 * </p>
 * <pre>
 *   HBox.setMargin(tab, new Insets(TAB_INSET_TOP, 0, 0, 0));
 * </pre>
 * <p>
 * {@code HBox} subtracts a child's margin from the area it lays that child
 * into, and with {@code fillHeight} the child then fills exactly what is left.
 * So the tab spans {@code TAB_INSET_TOP}..{@code HEIGHT}: navy above, flush
 * with the band below.
 * </p>
 *
 * <h3>Why a margin and not a padding -- this is the important part</h3>
 * <p>
 * {@code -fx-padding} is a <i>styleable</i> property. Whatever this class sets
 * programmatically is origin {@code USER}, and any author stylesheet rule that
 * matches the node overrides it. That makes a padding-based gap only as
 * reliable as our knowledge of the whole resolved cascade -- Modena's rules,
 * both theme files, the ribbon sheets and the generated sheet -- and it is
 * exactly where the previous three attempts died, in three different ways.
 * </p>
 * <p>
 * Layout margins are <b>not styleable</b>. There is no {@code -fx-margin} in
 * JavaFX CSS; a margin is a constraint stored by the parent in the child's
 * property map. No stylesheet, no skin, no theme swap and no DPI snapping rule
 * can reach it. The gap is now the one thing in this design that the cascade
 * cannot participate in, which is the property it needed all along.
 * </p>
 *
 * <h3>The row must be pinned to the strip height</h3>
 * <p>
 * {@code ToolBarSkin} sizes its internal container to that container's
 * <em>preferred</em> height and centres it in the bar, rather than handing it
 * the bar's content box. The root row's preferred height is its tallest child
 * -- the right-hand cluster, about 38 -- so an unpinned row is 38 tall inside a
 * 30-tall strip and is centred at {@code y = -4}.
 * </p>
 * <p>
 * That negative offset is the reason this design failed five times. Every gap
 * was measured from the row, so 4 pixels of margin put the tab's top edge at
 * absolute 0 and its bottom 4 pixels inside the band -- invisible, because the
 * tab and the band are the same colour by design. The row is now pinned to
 * {@code Dim.RibbonBar.HEIGHT}, the offset is zero, and the margin means what
 * it says. It also explains the original layout: the old tab was about 21 tall
 * in that same 38-tall row, so centring landed it near 4 and it looked right by
 * accident.
 * </p>
 *
 * <h3>What is still done by CSS, and what is not</h3>
 * <ul>
 * <li>Gap above the tab: <b>margin, here.</b></li>
 * <li>Tab flush with the band: fill, here -- the tab's max height is unbounded
 * and the block fills the strip.</li>
 * <li>Label on the strip's centre line: the tab's own asymmetric padding, from
 * the generated sheet. This part has worked correctly throughout.</li>
 * <li>Rounded top corners, three-sided border, colours: the ribbon sheets.</li>
 * </ul>
 * <p>
 * Do not pin a tab height and do not put a padding on the tab block. Both have
 * been tried; the notes in {@code RibbonBar_dim} say how each one failed.
 * </p>
 * <p>
 * The search box and the action cluster are left alone: both pin their own
 * heights in CSS, so the root row centres them instead of stretching them.
 * </p>
 */
public final class ToolbarRibbon {

    /** Style class for the rounded search box. */
    private static final String SEARCH_BOX_CLASS = "ribbon-search-box";

    /** Style class for the text field inside the search box. */
    private static final String SEARCH_FIELD_CLASS = "ribbon-search-field";

    /**
     * The six tabs, in strip order.
     *
     * <p>
     * Kept so {@link #setBandCollapsed(boolean)} can re-apply their margins
     * when the band is hidden or shown. Rebuilt from scratch by
     * {@link #buildRibbonTabs(UI_Main)}, so a second build does not accumulate.
     * </p>
     */
    private static final List<ToggleButton> TABS = new ArrayList<>(6);

    /** Launch with {@code -Dastra.ribbon.debug=true} to print the tab's real bounds. */
    private static final String DEBUG_PROPERTY = "astra.ribbon.debug";

    private ToolbarRibbon() {
    }

    /**
     * Re-applies the tab margins for the band's current state.
     *
     * <p>
     * Open: margin on the top only, so the tab runs down to the strip's bottom
     * edge and meets the band. Collapsed: the same margin at the bottom as
     * well, because there is no band underneath to meet -- the tab becomes a
     * closed box floating on the navy.
     * </p>
     *
     * <p>
     * Called by {@code RibbonCollapse}. Safe before the tabs exist.
     * </p>
     *
     * @param collapsed true if the Row-2 band is hidden
     */
    public static void setBandCollapsed(boolean collapsed) {
        applyTabMargins(collapsed);
    }

    private static void applyTabMargins(boolean collapsed) {
        double gap = Dim.RibbonBar.TAB_INSET_TOP;
        Insets margin = new Insets(gap, 0, collapsed ? gap : 0, 0);
        for (ToggleButton t : TABS) {
            HBox.setMargin(t, margin);
        }
    }

    /**
     * Prints the strip's and the first tab's real laid-out bounds once the
     * scene has measured them, when {@code -Dastra.ribbon.debug=true} is set.
     *
     * <p>
     * This exists because the gap above the tab has been wrong three times for
     * three different reasons, and every diagnosis so far has come from
     * counting pixels in a screenshot. The numbers below say directly what the
     * strip height is, where the tab starts and where it ends; the gap is the
     * tab's minY, and it should equal {@code Dim.RibbonBar.TAB_INSET_TOP}.
     * </p>
     */
    private static void dumpTabBoundsIfRequested(ToggleButton tab) {
        if (!Boolean.getBoolean(DEBUG_PROPERTY)) {
            return;
        }
        tab.boundsInParentProperty().addListener((obs, was, now) -> {
            ToolBar strip = ToolbarState.ribbonBar;
            if (strip == null || tab.getScene() == null) {
                return;
            }
            // Converted into the STRIP's coordinates, not the parent's. The
            // parent-relative figure is what made the last diagnosis hard: the
            // tab read y=4 while actually sitting at absolute 0, because its
            // parent was offset by -4. Relative to the strip there is nowhere
            // for an offset to hide -- minY IS the gap.
            Bounds inStrip = strip.sceneToLocal(tab.localToScene(tab.getBoundsInLocal()));
            System.out.printf(
                    "[Ribbon] strip h=%.1f | tab in strip y=%.1f..%.1f h=%.1f "
                            + "| gap=%.1f (expected %.1f) | overhang=%.1f (expected 0.0)%n",
                    strip.getHeight(),
                    inStrip.getMinY(), inStrip.getMaxY(), inStrip.getHeight(),
                    inStrip.getMinY(), Dim.RibbonBar.TAB_INSET_TOP,
                    inStrip.getMaxY() - strip.getHeight());
        });
    }


    /**
     * Builds the tab strip and installs it on {@code ToolbarState.ribbonBar}.
     *
     * @param ide the IDE controller
     */
    public static void buildRibbonTabs(UI_Main ide) {

        // min == pref == max locks the height. See Dim.RibbonBar.HEIGHT for
        // why it cannot go much below its current value.
        ToolbarState.ribbonBar.setMinHeight(Dim.RibbonBar.HEIGHT);
        ToolbarState.ribbonBar.setPrefHeight(Dim.RibbonBar.HEIGHT);
        ToolbarState.ribbonBar.setMaxHeight(Dim.RibbonBar.HEIGHT);

        ToggleButton home = ribbonTab("Home", ide);
        ToggleButton signals = ribbonTab("Signals", ide);
        ToggleButton jtag = ribbonTab("JTAG", ide);
        ToggleButton commission = ribbonTab("Commission", ide);
        ToggleButton settings = ribbonTab("Settings", ide);
        ToggleButton help = ribbonTab("Help", ide);

        home.setOnAction(e -> activateTab(home, ide.homeTB, ide));
        signals.setOnAction(e -> activateTab(signals, ide.compileTB, ide));
        jtag.setOnAction(e -> activateTab(jtag, ide.jtagTB, ide));
        commission.setOnAction(e -> activateTab(commission, ide.commissionTB, ide));
        settings.setOnAction(e -> activateTab(settings, ide.preferencesTB, ide));
        help.setOnAction(e -> activateTab(help, ide.helpTB, ide));

        // Tabs spread evenly so together they cover TABS_FRACTION of the width.
        HBox tabsBox = new HBox(home, signals, jtag, commission, settings, help);
        tabsBox.setSpacing(0);
        // The block fills the strip's full height and has NO padding of its
        // own -- deliberately, and the generated sheet zeroes it too. The gap
        // above the tabs is a margin, applied below; a padding here would be
        // a second gap, and a styleable one at that.
        tabsBox.setAlignment(Pos.CENTER_LEFT);
        tabsBox.setFillHeight(true);
        tabsBox.setMaxHeight(Double.MAX_VALUE);
        tabsBox.setPadding(Insets.EMPTY);
        if (!tabsBox.getStyleClass().contains(Dim.RibbonBar.TAB_BOX_CLASS)) {
            tabsBox.getStyleClass().add(Dim.RibbonBar.TAB_BOX_CLASS);
        }

        TABS.clear();
        for (ToggleButton t : new ToggleButton[] { home, signals, jtag, commission, settings, help }) {
            t.setMaxWidth(Double.MAX_VALUE);
            HBox.setHgrow(t, Priority.ALWAYS);
            TABS.add(t);
        }
        // THE gap. See the class notes: a margin is the only vertical offset
        // in this strip that no stylesheet can override.
        applyTabMargins(RibbonCollapse.isCollapsed());
        dumpTabBoundsIfRequested(home);
        tabsBox.prefWidthProperty().bind(
                ToolbarState.ribbonBar.widthProperty().multiply(Dim.RibbonBar.TABS_FRACTION));
        tabsBox.minWidthProperty().bind(tabsBox.prefWidthProperty());

        HBox searchBox = buildSearchBox(ide);
        searchBox.prefWidthProperty().bind(
                ToolbarState.ribbonBar.widthProperty().multiply(Dim.RibbonBar.SEARCH_FRACTION));
        searchBox.minWidthProperty().bind(searchBox.prefWidthProperty());

        // Fixed gap between tabs and search so the search centre lands ~75%.
        Region gap = new Region();
        gap.prefWidthProperty().bind(
                ToolbarState.ribbonBar.widthProperty().multiply(Dim.RibbonBar.GAP_FRACTION));
        gap.minWidthProperty().bind(gap.prefWidthProperty());

        HBox rightCluster = buildRightCluster(ide);

        // Growing spacer pushes the right cluster to the far right edge.
        Region grow = new Region();
        HBox.setHgrow(grow, Priority.ALWAYS);

        // Single root row so the ToolBar never shows an overflow button.
        HBox root = new HBox(tabsBox, gap, searchBox, grow, rightCluster);
        root.setAlignment(Pos.CENTER_LEFT);
        root.setSpacing(Dim.RibbonBar.ROOT_SPACING);
        // PINNED TO THE STRIP HEIGHT, and this is load-bearing.
        //
        // ToolBarSkin sizes its internal container to that container's
        // PREFERRED height and then centres it in the bar -- it does not hand
        // it the bar's content box. This row's preferred height is the tallest
        // of its children, and the right-hand cluster prefers about 38. So an
        // unpinned row is 38 tall inside a 30-tall strip and gets centred at
        // y = (30 - 38) / 2 = -4.
        //
        // Everything below is measured from this row, so that -4 was silently
        // subtracted from every gap this design has ever tried to create. It is
        // why the tab's top edge sat against the title bar no matter what the
        // gap was set to, and why raising TAB_INSET_TOP from 2 to 4 changed
        // nothing on screen. Pin the row and the offset is zero.
        root.setFillHeight(true);
        root.setMinHeight(Dim.RibbonBar.HEIGHT);
        root.setPrefHeight(Dim.RibbonBar.HEIGHT);
        root.setMaxHeight(Dim.RibbonBar.HEIGHT);
        root.prefWidthProperty().bind(
                ToolbarState.ribbonBar.widthProperty().subtract(Dim.RibbonBar.H_INSET));

        ToolbarState.ribbonBar.getItems().setAll(root);

        home.setSelected(true);
        activateTab(home, ide.homeTB, ide);
    }

    /**
     * A text-only tab. Every visual -- unselected, hover and the selected
     * "attached" look -- comes from {@code .ribbon-tab} and its
     * {@code :selected} pseudo-class, so the tab stays theme-aware and the
     * active tab can share the exact colour of the band below it.
     *
     * @param text tab label
     * @param ide  the IDE controller, for the shared toggle group
     * @return the configured tab
     */
    private static ToggleButton ribbonTab(String text, UI_Main ide) {
        ToggleButton b = new ToggleButton(text);
        b.setToggleGroup(ide.ribbonGroup);
        b.setFocusTraversable(false);
        b.setAlignment(Pos.CENTER);
        // Unbounded so the tab fills whatever its margin leaves it. Do NOT pin
        // a height here: a pinned height was tried and did not hold -- the tab
        // reverted to its natural content height and dumped the shortfall on
        // top of the intended gap. Filling inside a margin has no such failure
        // mode; HBox hands the child exactly (contentHeight - margins).
        b.setMaxHeight(Double.MAX_VALUE);
        if (!b.getStyleClass().contains("ribbon-tab")) {
            b.getStyleClass().add("ribbon-tab");
        }
        // Second way to collapse the band: double-click the active tab. Guarded
        // on isSelected so a double-click that is really "switch tab, then
        // change your mind" does not collapse the band underneath you.
        b.setOnMouseClicked(e -> {
            if (e.getClickCount() == 2 && b.isSelected()) {
                RibbonCollapse.toggle();
                e.consume();
            }
        });
        return b;
    }

    /**
     * Swaps in the Row-2 toolbar belonging to the clicked tab. Selection
     * visuals are handled entirely by CSS.
     *
     * @param tab the clicked tab
     * @param tb  its Row-2 toolbar
     * @param ide the IDE controller
     */
    private static void activateTab(ToggleButton tab, ToolBar tb, UI_Main ide) {
        // A ToggleButton in a ToggleGroup deselects itself when clicked a
        // second time. Forcing it back on keeps exactly one tab highlighted,
        // which matters now that a double-click is a meaningful gesture.
        tab.setSelected(true);
        ToolbarStyling.showToolbar(ide, tb);
    }

    /**
     * The rounded search box: a text field with a magnifier glyph at its right
     * end. The search covers Neural Code extension methods and work-bench
     * guidance, not code. Shortcut: Alt+Space.
     *
     * @param ide the IDE controller
     * @return the search box
     */
    private static HBox buildSearchBox(UI_Main ide) {
        TextField field = new TextField();
        field.setPromptText("Search (Alt+Space)");
        field.setFocusTraversable(false);
        field.setStyle("");
        if (!field.getStyleClass().contains(SEARCH_FIELD_CLASS)) {
            field.getStyleClass().add(SEARCH_FIELD_CLASS);
        }
        HBox.setHgrow(field, Priority.ALWAYS);
        // Exposed for the Alt+Space shortcut wired in Main_Window.
        ToolbarState.searchField = field;

        ImageView lens = safeIcon("/icons/NC_ribbon/ic_search.png",
                Dim.RibbonBar.SEARCH_ICON_SIZE);

        HBox box = new HBox(field);
        if (lens != null) {
            box.getChildren().add(lens);
        }
        box.setAlignment(Pos.CENTER_LEFT);
        box.setStyle("");
        if (!box.getStyleClass().contains(SEARCH_BOX_CLASS)) {
            box.getStyleClass().add(SEARCH_BOX_CLASS);
        }
        Tooltip.install(box, new Tooltip("Search extension methods & work-bench help (Alt+Space)"));
        return box;
    }

    /**
     * The trailing action cluster: undo, redo, save, print, then the
     * notification bell, then the account control.
     *
     * @param ide the IDE controller
     * @return the cluster
     */
    private static HBox buildRightCluster(UI_Main ide) {
        Button undo = iconButton("/icons/NC_ribbon/ic_undo.png", "Undo",
                () -> System.out.println("[Ribbon] Undo (todo: wire to editor)"));
        Button redo = iconButton("/icons/NC_ribbon/ic_redo.png", "Redo",
                () -> System.out.println("[Ribbon] Redo (todo: wire to editor)"));
        Button save = iconButton("/icons/NC_ribbon/ic_save.png", "Save",
                () -> EditorManager.saveCurrentFile(ide));
        Button print = iconButton("/icons/NC_ribbon/ic_print.png", "Print",
                () -> ui.ui_functions.tools.PrintStudioWindow.open(ide));

        HBox actions = new HBox(undo, redo, save, print);
        actions.setAlignment(Pos.CENTER);
        actions.getStyleClass().add("ribbon-actions");

        Button bell = iconButton("/icons/NC_ribbon/ic_notification.png", "Notifications",
                () -> System.out.println("[Ribbon] Notifications (todo)"));

        AccountMenu account = new AccountMenu();

        HBox cluster = new HBox(Dim.RibbonBar.CLUSTER_SPACING, actions, bell, account.getNode());
        cluster.setAlignment(Pos.CENTER_RIGHT);
        return cluster;
    }

    private static Button iconButton(String iconPath, String tip, Runnable action) {
        ImageView iv = safeIcon(iconPath, Dim.RibbonBar.ACTION_ICON_SIZE);
        Button b = (iv != null) ? new Button("", iv) : new Button(tip);
        b.setFocusTraversable(false);
        b.getStyleClass().add("ribbon-icon-button");
        b.setStyle("");
        b.setTooltip(new Tooltip(tip));
        b.setOnAction(e -> action.run());
        return b;
    }

    private static ImageView safeIcon(String path, double size) {
        try {
            ImageView iv = ToolbarIcons.icon(path, size);
            iv.setPreserveRatio(true);
            return iv;
        } catch (Exception ex) {
            System.err.println("Ribbon icon missing: " + path);
            return null;
        }
    }
}
