package ui.ui_functions.tools;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToolBar;
import javafx.scene.control.Tooltip;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import ui.UI_Main;
import ui.account.AccountMenu;
import ui.managers.EditorManager;
import ui.ribbon_interface.tool_bar.RibbonCollapse;

public final class ToolbarRibbon {

    private ToolbarRibbon() {
    }

    // Layout proportions across the ribbon width (0.0 - 1.0):
    //   tabs occupy ~40%; a fixed gap then places the search box so its
    //   MID sits at ~75% (search is ~15% wide => 67.5%..82.5%); the right
    //   action cluster (undo/redo/save/print, bell, account) is pushed to
    //   the far right by a growing spacer.
    private static final double TABS_FRACTION = 0.40;
    private static final double GAP_FRACTION = 0.275; // 0.675 - 0.40
    private static final double SEARCH_FRACTION = 0.15;

    public static void buildRibbonTabs(UI_Main ide) {

        // Compact ribbon: 28px (down from the original 40px). 24px was too
        // short -> it clipped the top/bottom borders of the search box and the
        // selected tab, because a JavaFX TextField at font-size 12 is ~27px
        // tall. 28px keeps the bar slim while leaving room for fully-boxed
        // (4-side border) elements. min == pref == max locks the height.
        ToolbarState.ribbonBar.setMinHeight(28);
        ToolbarState.ribbonBar.setPrefHeight(28);
        ToolbarState.ribbonBar.setMaxHeight(28);

        // ---- Task 1: renamed, text-only tabs -----------------------------
        // Compile -> Signals, Preferences -> Settings (labels only; the
        // underlying toolbar fields keep their existing names).
        ToggleButton home = ribbonTab("Home", ide);
        ToggleButton signals = ribbonTab("Signals", ide);
        ToggleButton jtag = ribbonTab("JTAG", ide);
        ToggleButton commission = ribbonTab("Commission", ide);
        ToggleButton settings = ribbonTab("Settings", ide);
        ToggleButton help = ribbonTab("Help", ide);

        home.setOnAction(e -> activateTab(home, ide.homeTB, ide));
        signals.setOnAction(e -> activateTab(signals, ide.compileTB, ide));
        jtag.setOnAction(e -> activateTab(jtag, ide.jtagTB, ide));
        commission.setOnAction(e -> activateTab(commission, ide.commissionTB, ide));
        settings.setOnAction(e -> activateTab(settings, ide.preferencesTB, ide));
        help.setOnAction(e -> activateTab(help, ide.helpTB, ide));

        // Task 2: tabs spread evenly so together they cover ~40% width.
        HBox tabsBox = new HBox(home, signals, jtag, commission, settings, help);
        tabsBox.setAlignment(Pos.CENTER_LEFT);
        tabsBox.setSpacing(0);
        for (ToggleButton t : new ToggleButton[] { home, signals, jtag, commission, settings, help }) {
            t.setMaxWidth(Double.MAX_VALUE);
            HBox.setHgrow(t, Priority.ALWAYS);
        }
        tabsBox.prefWidthProperty().bind(ToolbarState.ribbonBar.widthProperty().multiply(TABS_FRACTION));
        tabsBox.minWidthProperty().bind(tabsBox.prefWidthProperty());

        // ---- Task 4: search box (mid ~75%, lens on the right) ------------
        HBox searchBox = buildSearchBox(ide);
        searchBox.prefWidthProperty().bind(ToolbarState.ribbonBar.widthProperty().multiply(SEARCH_FRACTION));
        searchBox.minWidthProperty().bind(searchBox.prefWidthProperty());

        // Fixed gap between tabs and search so the search centre lands ~75%.
        Region gap = new Region();
        gap.prefWidthProperty().bind(ToolbarState.ribbonBar.widthProperty().multiply(GAP_FRACTION));
        gap.minWidthProperty().bind(gap.prefWidthProperty());

        // ---- Task 5 & 6: right action cluster ----------------------------
        HBox rightCluster = buildRightCluster(ide);

        // Growing spacer pushes the right cluster to the far right edge.
        Region grow = new Region();
        HBox.setHgrow(grow, Priority.ALWAYS);

        // Single root row so the ToolBar never shows an overflow button.
        HBox root = new HBox(tabsBox, gap, searchBox, grow, rightCluster);
        root.setAlignment(Pos.CENTER_LEFT);
        root.setSpacing(6);
        root.prefWidthProperty().bind(ToolbarState.ribbonBar.widthProperty().subtract(20));

        ToolbarState.ribbonBar.getItems().setAll(root);

        // Default selection: Home.
        home.setSelected(true);
        activateTab(home, ide.homeTB, ide);
    }

    // Text-only tab. All visuals (unselected, hover and the selected
    // "attached" look) now come from the theme CSS via the ".ribbon-tab"
    // style class and the ":selected" pseudo-class. This keeps the tab
    // theme-aware (light/dark) and lets the active tab share the exact
    // colour of the Row-2 panel below it so the two merge seamlessly.
    private static ToggleButton ribbonTab(String text, UI_Main ide) {
        ToggleButton b = new ToggleButton(text);
        b.setToggleGroup(ide.ribbonGroup);
        b.setFocusTraversable(false);
        b.setAlignment(Pos.CENTER);
        // Do NOT stretch the tab to the full ribbon height. Keeping the tab at
        // its natural (padding-driven) height and letting the row's vertical
        // alignment centre it means the SELECTED tab's 4-side border is fully
        // visible with a small margin above and below -> a clean box, not a
        // strip that gets clipped at the ribbon edges.
        if (!b.getStyleClass().contains("ribbon-tab")) {
            b.getStyleClass().add("ribbon-tab");
        }
        // Second way to collapse the band: double-click the active tab. Guarded
        // on isSelected so a double-click that is really "switch tab, then
        // change your mind" does not collapse the band underneath you.
        b.setOnMouseClicked(e -> {
            if (e.getClickCount() == 2 && b.isSelected()) {
                RibbonCollapse.toggle();
                e.consume();
            }
        });
        return b;
    }

    // Selection visuals are handled entirely by CSS (:selected on the
    // .ribbon-tab class), so activation only needs to swap in the Row-2
    // toolbar that belongs to the clicked tab. The ToggleGroup guarantees
    // exactly one tab carries the :selected state at a time.
    private static void activateTab(ToggleButton tab, ToolBar tb, UI_Main ide) {
        // A ToggleButton in a ToggleGroup deselects itself when clicked a
        // second time. Forcing it back on keeps exactly one tab highlighted,
        // which matters now that a double-click is a meaningful gesture.
        tab.setSelected(true);
        ToolbarStyling.showToolbar(ide, tb);
    }

    // ---- Search box --------------------------------------------------------
    // A rounded white field with a magnifier lens on the right end. The
    // search is for Neural Code extension methods / external work-bench
    // guidance (NOT code search). Shortcut hint: Alt+Space.
    private static HBox buildSearchBox(UI_Main ide) {
        TextField field = new TextField();
        field.setPromptText("Search (Alt+Space)");
        field.setFocusTraversable(false);
        // Transparent field so the white rounded box shows through.
        // Zero vertical padding on the field so its intrinsic height stays
        // small enough to sit inside the compact ribbon without the enclosing
        // box getting clipped.
        field.setStyle(
                "-fx-background-color: transparent;"
                        + "-fx-background-insets: 0;"
                        + "-fx-padding: 0 6 0 8;"
                        + "-fx-prompt-text-fill: #8a8a8a;"
                        + "-fx-text-fill: #202020;"
                        + "-fx-font-size: 12;");
        // Cap the field height so it can't force the box taller than the row.
        field.setMinHeight(20);
        field.setPrefHeight(20);
        field.setMaxHeight(20);
        HBox.setHgrow(field, Priority.ALWAYS);
        // Expose for the Alt+Space shortcut wired in Main_Window.
        ToolbarState.searchField = field;

        // Dark lens (it sits inside the white field, so it must be dark).
        ImageView lens = safeIcon("/icons/NC_ribbon/ic_search.png", 16);

        HBox box = new HBox(6, field);
        if (lens != null) {
            box.getChildren().add(lens);
        }
        box.setAlignment(Pos.CENTER_LEFT);
        // Fixed, compact box height (22px) that is STRICTLY smaller than the
        // 28px ribbon row, so the ToolBar never clips it and all FOUR borders
        // (top, bottom, left, right) render as a clean rectangle.
        box.setMinHeight(22);
        box.setPrefHeight(22);
        box.setMaxHeight(22);
        // White rounded search box with a visible border on all four sides.
        box.setStyle(
                "-fx-background-color: #ffffff;"
                        + "-fx-background-radius: 3;"
                        + "-fx-border-color: #34495e;"
                        + "-fx-border-radius: 3;"
                        + "-fx-border-width: 1;"
                        + "-fx-padding: 0 8 0 4;");
        Tooltip.install(box, new Tooltip("Search extension methods & work-bench help (Alt+Space)"));
        return box;
    }

    // ---- Right action cluster ---------------------------------------------
    // Order: [undo][redo][save][print]  [notification]  [account/sign-in]
    private static HBox buildRightCluster(UI_Main ide) {
        Button undo = iconButton("/icons/NC_ribbon/ic_undo.png", "Undo",
                () -> System.out.println("[Ribbon] Undo (todo: wire to editor)"));
        Button redo = iconButton("/icons/NC_ribbon/ic_redo.png", "Redo",
                () -> System.out.println("[Ribbon] Redo (todo: wire to editor)"));
        Button save = iconButton("/icons/NC_ribbon/ic_save.png", "Save",
                () -> EditorManager.saveCurrentFile(ide));
        Button print = iconButton("/icons/NC_ribbon/ic_print.png", "Print",
                () -> ui.ui_functions.tools.PrintStudioWindow.open(ide));

        // The four small action icons kept tight together (~8% total width).
        HBox actions = new HBox(2, undo, redo, save, print);
        actions.setAlignment(Pos.CENTER);
        actions.getStyleClass().add("ribbon-actions");

        // Notification bell between the action icons and the account menu.
        Button bell = iconButton("/icons/NC_ribbon/ic_notification.png", "Notifications",
                () -> System.out.println("[Ribbon] Notifications (todo)"));

        // Single sign-in / account control (see AccountMenu).
        AccountMenu account = new AccountMenu();

        HBox cluster = new HBox(10, actions, bell, account.getNode());
        cluster.setAlignment(Pos.CENTER_RIGHT);
        return cluster;
    }

    private static Button iconButton(String iconPath, String tip, Runnable action) {
        ImageView iv = safeIcon(iconPath, 18);
        Button b = (iv != null) ? new Button("", iv) : new Button(tip);
        b.setFocusTraversable(false);
        b.getStyleClass().add("ribbon-icon-button");
        b.setStyle("-fx-background-color: transparent; -fx-padding: 2;");
        b.setTooltip(new Tooltip(tip));
        b.setOnAction(e -> action.run());
        return b;
    }

    private static ImageView safeIcon(String path, int size) {
        try {
            ImageView iv = ToolbarIcons.icon(path);
            iv.setFitWidth(size);
            iv.setFitHeight(size);
            iv.setPreserveRatio(true);
            return iv;
        } catch (Exception ex) {
            System.err.println("Ribbon icon missing: " + path);
            return null;
        }
    }
}
