package ui.ui_functions.tools;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

import javafx.scene.control.Button;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SplitMenuButton;
import ui.UI_Main;
import ui.editor.navigation.CloudFolders;
import ui.editor.navigation.DefaultFolders;
import ui.editor.navigation.FolderPaths;
import ui.editor.navigation.NavigationActions;
import ui.explorer.navigation.BreadcrumbBar;

/**
 * Compatibility front for the quick-access row.
 *
 * <p>
 * This class used to build and drive the whole row: the breadcrumb, the
 * back / forward history, the folder-up menu and the OneDrive lookup. That
 * work now lives in two packages:
 * </p>
 * <ul>
 * <li>{@code ui.explorer.navigation} -- the controls:
 * {@code NavigationBar}, {@code BreadcrumbBar}, {@code BreadcrumbPathEditor},
 * {@code PathErrorDialog}, {@code NaviBreadIcons},
 * {@code PopupMenuToggle};</li>
 * <li>{@code ui.editor.navigation} -- the behaviour:
 * {@code NavigationActions}, {@code FolderHistory}, {@code RootFolderStore},
 * {@code CloudFolders}, {@code DefaultFolders}, {@code FolderPaths}.</li>
 * </ul>
 * <p>
 * What is left here are the entry points other classes already call --
 * {@code ToolbarManager.updateQuickPath}, {@code ThemeManager} -- plus the
 * old public methods as thin delegates, so nothing outside the files in this
 * change needs editing. New code should call the classes above directly.
 * </p>
 *
 * <h3>Styling</h3>
 * <p>
 * This class builds no breadcrumb controls and uses none of the breadcrumb's
 * style classes. The two deprecated menu fillers below create their entries
 * through {@link BreadcrumbBar#menuEntry}, so a folder or OneDrive name with an
 * underscore keeps it. Their pop-ups belong to the caller's
 * {@code MenuButton}, so they do not get the quick-access row's menu font; the
 * live Cloud button and breadcrumb chevrons do.
 * </p>
 */
public final class ToolbarNavigation {

    private ToolbarNavigation() {
    }

    // =================================================================
    // Live entry points
    // =================================================================

    /**
     * Redraws the breadcrumb for a folder. Called by
     * {@code ToolbarManager.updateQuickPath}, which {@code ProjectManager}
     * calls on every project load.
     *
     * @param path the folder now in view, or null for "no project"
     */
    public static void updateQuickPath(Path path) {
        BreadcrumbBar.show(path);
    }

    /**
     * Kept for {@code ThemeManager}. The breadcrumb's icons now re-point
     * themselves through {@code NaviBreadIcons}, so this only redraws.
     */
    public static void refreshThemeIcons() {
        BreadcrumbBar.refresh();
    }

    /**
     * The Home folder, {@code Documents\NeuralCode}, created if missing.
     *
     * @return the folder
     */
    public static Path ensureDefaultUPIDirectory() {
        return DefaultFolders.neuralCodeHome();
    }

    // =================================================================
    // Old public API, delegated
    // =================================================================

    /**
     * @param ide the IDE controller
     * @deprecated use {@code NavigationActions.goBack}; Back now steps through
     *             run folders, not every folder visited
     */
    @Deprecated
    public static void navigateBack(UI_Main ide) {
        NavigationActions.goBack(ide);
    }

    /**
     * @param ide the IDE controller
     * @deprecated use {@code NavigationActions.goForward}
     */
    @Deprecated
    public static void navigateForward(UI_Main ide) {
        NavigationActions.goForward(ide);
    }

    /**
     * @param owner ignored
     * @param ide   the IDE controller
     * @deprecated Up now goes one level up directly; use
     *             {@code NavigationActions.goUp}
     */
    @Deprecated
    public static void showFolderUpMenu(Button owner, UI_Main ide) {
        NavigationActions.goUp(ide);
    }

    /**
     * @param owner the control the menu hangs from
     * @param ide   ignored
     * @deprecated use {@code BreadcrumbBar.showRootsMenu}
     */
    @Deprecated
    public static void showRootsMenu(Button owner, UI_Main ide) {
        BreadcrumbBar.showRootsMenu(owner);
    }

    /**
     * @param ide the IDE controller
     * @deprecated use the Cloud button, or {@code CloudFolders.folders()}
     */
    @Deprecated
    public static void navigateOneDrive(UI_Main ide) {
        List<Path> folders = CloudFolders.folders();
        if (!folders.isEmpty()) {
            NavigationActions.goTo(ide, folders.get(0));
        }
    }

    /**
     * Fills a menu button with the OneDrive folders.
     *
     * @param btn the button to fill
     * @param ide the IDE controller
     * @deprecated the Cloud button builds its own menu
     */
    @Deprecated
    public static void loadOneDriveMenu(SplitMenuButton btn, UI_Main ide) {
        btn.getItems().clear();
        List<Path> folders = CloudFolders.folders();
        if (folders.isEmpty()) {
            MenuItem empty = BreadcrumbBar.menuEntry("OneDrive not found", null);
            empty.setDisable(true);
            btn.getItems().add(empty);
            return;
        }
        for (Path folder : folders) {
            MenuItem item = BreadcrumbBar.menuEntry(CloudFolders.label(folder), null);
            item.setOnAction(e -> NavigationActions.goTo(ide, folder));
            btn.getItems().add(item);
        }
    }

    /**
     * Fills a menu button with the subfolders of the folder being shown.
     *
     * @param btn the button to fill
     * @param ide the IDE controller
     * @deprecated the breadcrumb chevrons do this
     */
    @Deprecated
    public static void loadFolderDownMenu(MenuButton btn, UI_Main ide) {
        btn.getItems().clear();
        Path current = NavigationActions.shownFolder(ide);
        if (!FolderPaths.isFolder(current)) {
            MenuItem error = BreadcrumbBar.menuEntry("Invalid folder", null);
            error.setDisable(true);
            btn.getItems().add(error);
            return;
        }
        try (Stream<Path> stream = Files.list(current)) {
            List<Path> children = stream
                    .filter(Files::isDirectory)
                    .sorted(Comparator.comparing(p -> p.getFileName().toString().toLowerCase(Locale.ROOT)))
                    .limit(50)
                    .toList();
            if (children.isEmpty()) {
                MenuItem empty = BreadcrumbBar.menuEntry("No subfolders", null);
                empty.setDisable(true);
                btn.getItems().add(empty);
                return;
            }
            for (Path child : children) {
                MenuItem item = BreadcrumbBar.menuEntry(FolderPaths.label(child), null);
                item.setOnAction(e -> NavigationActions.goTo(ide, child));
                btn.getItems().add(item);
            }
        } catch (Exception e) {
            MenuItem error = BreadcrumbBar.menuEntry("Unable to list folders", null);
            error.setDisable(true);
            btn.getItems().add(error);
        }
    }
}
