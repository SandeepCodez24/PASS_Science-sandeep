package ui.ui_functions.tools;

import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Supplier;

import javafx.application.Platform;
import javafx.geometry.Bounds;
import javafx.geometry.Side;
import javafx.scene.control.Button;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.SplitMenuButton;
import javafx.scene.image.ImageView;
import javafx.stage.WindowEvent;
import ui.UI_Main;
import ui.design.Dim;
import ui.managers.ProjectManager;

/**
 * Drives the quick-access bar: the back/forward/up buttons and the breadcrumb
 * ("quick path") strip that shows where the project tree currently is.
 */
public final class ToolbarNavigation {

    // Chevron assets. Only the light-theme path is named here; ToolbarIcons
    // rewrites "/icons/..." to "/icons/dark/..." when the dark theme is on and
    // falls back to this one if the dark asset is missing.
    private static final String CHEVRON_RIGHT = "/icons/quickpath/chevron_right.png";
    private static final String CHEVRON_DOWN = "/icons/quickpath/chevron_down.png";

    /** On-screen size of a chevron. The PNGs ship at 32px and scale down. */
    private static final double CHEVRON_SIZE = Dim.QuickBar.CHEVRON_SIZE;

    /**
     * How long after a menu closes a click on its own button is ignored.
     *
     * <p>
     * A ContextMenu auto-hides on any mouse press outside itself, and the
     * button that owns it is outside itself. So a second click on the same
     * button fires two things in quick succession: the auto-hide, then the
     * button's action. Without this guard the action immediately re-opens the
     * menu that the same click just closed, which is why the strip used to
     * look stuck open and only closed when clicking elsewhere.
     * </p>
     */
    private static final long REOPEN_GUARD_MS = 250;

    /** Key under which each button stores its own menu state. */
    private static final String TOGGLE_KEY = "astra.quickPathMenuToggle";

    /** Last path drawn, so the strip can be redrawn when the theme changes. */
    private static volatile Path lastRenderedPath;

    private ToolbarNavigation() {
    }

    // =================================================================
    // Breadcrumb
    // =================================================================

    /**
     * Redraws the breadcrumb for a folder.
     *
     * @param path the folder now in view, or null for "no project"
     */
    public static void updateQuickPath(Path path) {
        if (ToolbarState.quickPathSegments == null) {
            return;
        }

        Platform.runLater(() -> {
            if (path == null) {
                lastRenderedPath = null;
                Label empty = new Label(ToolbarState.NO_PROJECT_TEXT);
                empty.getStyleClass().add("quick-path-empty");
                ToolbarState.quickPathSegments.getChildren().setAll(empty);
                return;
            }

            Path resolved = normalizeDir(path);
            lastRenderedPath = resolved;
            renderBreadcrumb(resolved);
        });
    }

    /**
     * Redraws the strip so the chevrons pick up the other theme's ink.
     *
     * <p>
     * The chevrons are raster PNGs, so unlike the text they cannot follow the
     * stylesheet. ThemeManager calls this straight after flipping
     * {@code ToolbarIcons.setDarkMode}.
     * </p>
     */
    public static void refreshThemeIcons() {
        if (ToolbarState.quickPathSegments == null) {
            return;
        }
        Path path = lastRenderedPath;
        if (path == null) {
            return;
        }
        Platform.runLater(() -> renderBreadcrumb(path));
    }

    private static void renderBreadcrumb(Path targetPath) {
        List<Path> chain = new ArrayList<>();
        Path cursor = targetPath;
        while (cursor != null) {
            chain.add(0, cursor);
            cursor = cursor.getParent();
        }

        ToolbarState.quickPathSegments.getChildren().clear();

        // A chevron follows every crumb, including the last one, so the folder
        // currently in view can be drilled into without first going up.
        for (Path segmentPath : chain) {
            ToolbarState.quickPathSegments.getChildren().add(createSegmentButton(segmentPath));
            ToolbarState.quickPathSegments.getChildren().add(createSeparatorButton(segmentPath));
        }
    }

    private static Button createSegmentButton(Path segmentPath) {
        Button segment = new Button(labelForPath(segmentPath));
        segment.setFocusTraversable(false);
        segment.getStyleClass().add("quick-path-segment");

        MenuToggle toggle = toggleFor(segment);
        segment.setOnAction(e -> handleToggleClick(
                segment,
                toggle,
                () -> buildSegmentMenu(segmentPath),
                null,
                null));

        return segment;
    }

    private static Button createSeparatorButton(Path sourcePath) {
        Button sep = new Button();
        sep.setFocusTraversable(false);
        sep.getStyleClass().add("quick-path-separator");
        sep.setGraphic(chevron(false));

        MenuToggle toggle = toggleFor(sep);
        sep.setOnAction(e -> handleToggleClick(
                sep,
                toggle,
                () -> buildSegmentMenu(sourcePath),
                () -> sep.setGraphic(chevron(true)),
                () -> sep.setGraphic(chevron(false))));

        return sep;
    }

    private static ImageView chevron(boolean pointingDown) {
        return ToolbarIcons.icon(pointingDown ? CHEVRON_DOWN : CHEVRON_RIGHT, CHEVRON_SIZE);
    }

    private static ContextMenu buildSegmentMenu(Path segmentPath) {
        ContextMenu menu = new ContextMenu();

        if (ToolbarState.quickPathOwner != null) {
            MenuItem openCurrent = new MenuItem("Open " + labelForPath(segmentPath));
            openCurrent.setOnAction(e -> navigateTo(ToolbarState.quickPathOwner, segmentPath, true));
            menu.getItems().add(openCurrent);
        }

        try {
            if (Files.isDirectory(segmentPath)) {
                try (java.util.stream.Stream<Path> stream = Files.list(segmentPath)) {
                    List<Path> children = stream
                            .filter(Files::isDirectory)
                            .sorted(Comparator.comparing(
                                    p -> p.getFileName().toString().toLowerCase()))
                            .limit(40)
                            .toList();

                    if (!menu.getItems().isEmpty()) {
                        menu.getItems().add(new SeparatorMenuItem());
                    }

                    if (children.isEmpty()) {
                        MenuItem empty = new MenuItem("No subfolders");
                        empty.setDisable(true);
                        menu.getItems().add(empty);
                    } else {
                        for (Path child : children) {
                            MenuItem item = new MenuItem(labelForPath(child));
                            item.setOnAction(e -> {
                                if (ToolbarState.quickPathOwner != null) {
                                    navigateTo(ToolbarState.quickPathOwner, child, true);
                                }
                            });
                            menu.getItems().add(item);
                        }
                    }
                }
            }
        } catch (Exception ignored) {
            if (menu.getItems().isEmpty()) {
                MenuItem error = new MenuItem("Unable to list folders");
                error.setDisable(true);
                menu.getItems().add(error);
            }
        }

        return menu;
    }

    // =================================================================
    // Drives and shortcuts
    // =================================================================

    /**
     * Drops the "This PC" menu below the folder button at the left of the
     * breadcrumb: every mounted drive, then the usual home shortcuts.
     *
     * <p>
     * Without this there is no route off the drive the breadcrumb happens to
     * be on, because a crumb's menu only ever lists that crumb's own children.
     * </p>
     *
     * @param owner the folder button the menu hangs from
     * @param ide   the IDE controller
     */
    public static void showRootsMenu(Button owner, UI_Main ide) {
        MenuToggle toggle = toggleFor(owner);
        handleToggleClick(owner, toggle, () -> buildRootsMenu(ide), null, null);
    }

    private static ContextMenu buildRootsMenu(UI_Main ide) {
        ContextMenu menu = new ContextMenu();

        for (Path root : FileSystems.getDefault().getRootDirectories()) {
            boolean reachable;
            try {
                // An empty card reader or disconnected mapped drive shows up as
                // a root but cannot be listed; skip it rather than offering a
                // menu entry that does nothing.
                reachable = Files.isDirectory(root);
            } catch (Exception e) {
                reachable = false;
            }
            if (!reachable) {
                continue;
            }

            MenuItem item = new MenuItem(labelForPath(root));
            item.setOnAction(e -> navigateTo(ide, root, true));
            menu.getItems().add(item);
        }

        List<Path> shortcuts = new ArrayList<>();
        String home = System.getProperty("user.home");
        if (home != null && !home.isBlank()) {
            shortcuts.add(Path.of(home));
            shortcuts.add(Path.of(home, "Desktop"));
            shortcuts.add(Path.of(home, "Documents"));
            shortcuts.add(Path.of(home, "Downloads"));
        }

        boolean addedSeparator = false;
        for (Path shortcut : shortcuts) {
            if (!Files.isDirectory(shortcut)) {
                continue;
            }
            if (!addedSeparator && !menu.getItems().isEmpty()) {
                menu.getItems().add(new SeparatorMenuItem());
                addedSeparator = true;
            }
            MenuItem item = new MenuItem(labelForPath(shortcut));
            item.setOnAction(e -> navigateTo(ide, shortcut, true));
            menu.getItems().add(item);
        }

        if (menu.getItems().isEmpty()) {
            MenuItem empty = new MenuItem("No drives found");
            empty.setDisable(true);
            menu.getItems().add(empty);
        }

        return menu;
    }

    // =================================================================
    // History and the other nav buttons
    // =================================================================

    public static void navigateBack(UI_Main ide) {
        if (ToolbarState.backHistory.isEmpty()) {
            return;
        }

        Path current = normalizeDir(ide.currentFolder);
        if (current != null) {
            ToolbarState.forwardHistory.push(current);
        }

        Path previous = ToolbarState.backHistory.pop();
        navigateTo(ide, previous, false);
    }

    public static void navigateForward(UI_Main ide) {
        if (ToolbarState.forwardHistory.isEmpty()) {
            return;
        }

        Path current = normalizeDir(ide.currentFolder);
        if (current != null) {
            ToolbarState.backHistory.push(current);
        }

        Path next = ToolbarState.forwardHistory.pop();
        navigateTo(ide, next, false);
    }

    public static void showFolderUpMenu(Button owner, UI_Main ide) {
        MenuToggle toggle = toggleFor(owner);
        handleToggleClick(owner, toggle, () -> buildFolderUpMenu(ide), null, null);
    }

    private static ContextMenu buildFolderUpMenu(UI_Main ide) {
        ContextMenu menu = new ContextMenu();

        Path current = normalizeDir(ide.currentFolder);
        if (current == null) {
            MenuItem empty = new MenuItem("No folder open");
            empty.setDisable(true);
            menu.getItems().add(empty);
            return menu;
        }

        List<Path> parents = new ArrayList<>();
        Path cursor = current.getParent();
        while (cursor != null) {
            parents.add(cursor);
            cursor = cursor.getParent();
        }

        if (parents.isEmpty()) {
            MenuItem empty = new MenuItem("No parent folder");
            empty.setDisable(true);
            menu.getItems().add(empty);
            return menu;
        }

        for (Path parent : parents) {
            MenuItem item = new MenuItem(labelForPath(parent));
            item.setOnAction(e -> navigateTo(ide, parent, true));
            menu.getItems().add(item);
        }

        return menu;
    }

    public static void loadFolderDownMenu(MenuButton btn, UI_Main ide) {
        btn.getItems().clear();

        Path current = normalizeDir(ide.currentFolder);
        if (current == null || !Files.isDirectory(current)) {
            MenuItem error = new MenuItem("Invalid folder");
            error.setDisable(true);
            btn.getItems().add(error);
            return;
        }

        try (java.util.stream.Stream<Path> stream = Files.list(current)) {
            List<Path> children = stream
                    .filter(Files::isDirectory)
                    .sorted(Comparator.comparing(p -> p.getFileName().toString().toLowerCase()))
                    .limit(50)
                    .toList();

            if (children.isEmpty()) {
                MenuItem empty = new MenuItem("No subfolders");
                empty.setDisable(true);
                btn.getItems().add(empty);
            } else {
                for (Path child : children) {
                    MenuItem item = new MenuItem(labelForPath(child));
                    item.setOnAction(e -> navigateTo(ide, child, true));
                    btn.getItems().add(item);
                }
            }
        } catch (Exception ignored) {
            MenuItem error = new MenuItem("Unable to list folders");
            error.setDisable(true);
            btn.getItems().add(error);
        }
    }

    public static void navigateOneDrive(UI_Main ide) {
        for (Path oneDrive : resolveOneDrivePaths()) {
            if (Files.isDirectory(oneDrive)) {
                navigateTo(ide, oneDrive, true);
                return;
            }
        }
    }

    public static void loadOneDriveMenu(SplitMenuButton btn, UI_Main ide) {
        btn.getItems().clear();

        List<Path> available = resolveOneDrivePaths().stream()
                .filter(Files::isDirectory)
                .toList();

        if (available.isEmpty()) {
            MenuItem empty = new MenuItem("OneDrive not found");
            empty.setDisable(true);
            btn.getItems().add(empty);
            return;
        }

        for (Path oneDrive : available) {
            MenuItem item = new MenuItem(labelForPath(oneDrive));
            item.setOnAction(e -> navigateTo(ide, oneDrive, true));
            btn.getItems().add(item);
        }
    }

    public static Path ensureDefaultUPIDirectory() {
        Path defaultDir = Path.of(System.getProperty("user.home"), "Documents", "NeuralCode");

        try {
            if (Files.notExists(defaultDir)) {
                Files.createDirectories(defaultDir);
                System.out.println("Created NeuralCode directory: " + defaultDir);
            } else {
                System.out.println("Using existing NeuralCode directory: " + defaultDir);
            }
        } catch (Exception e) {
            e.printStackTrace();
            defaultDir = Path.of(System.getProperty("user.home"), "Documents");
        }

        return defaultDir;
    }

    // =================================================================
    // Menu toggling
    // =================================================================

    /**
     * Per-button menu state. Held in the button's property map rather than a
     * static field so every crumb, and the folder buttons, track their own
     * menu independently.
     */
    private static final class MenuToggle {
        private ContextMenu menu;
        private long closedAt;

        boolean isOpen() {
            return menu != null && menu.isShowing();
        }

        boolean justClosed() {
            return System.currentTimeMillis() - closedAt < REOPEN_GUARD_MS;
        }
    }

    private static MenuToggle toggleFor(Button button) {
        Object existing = button.getProperties().get(TOGGLE_KEY);
        if (existing instanceof MenuToggle found) {
            return found;
        }
        MenuToggle created = new MenuToggle();
        button.getProperties().put(TOGGLE_KEY, created);
        return created;
    }

    /**
     * Opens the button's menu, or closes it if it is already open.
     *
     * @param owner   the button clicked
     * @param toggle  that button's menu state
     * @param factory builds the menu, called only when one is about to show
     * @param onOpen  optional, run once the menu is showing
     * @param onClose optional, run once the menu has hidden
     */
    private static void handleToggleClick(
            Button owner,
            MenuToggle toggle,
            Supplier<ContextMenu> factory,
            Runnable onOpen,
            Runnable onClose) {

        if (toggle.isOpen()) {
            toggle.menu.hide();
            return;
        }

        // The click that auto-hid the menu also reaches the button on some
        // platforms. Swallow it so the menu stays shut.
        if (toggle.justClosed()) {
            return;
        }

        ContextMenu menu = factory.get();
        if (menu == null) {
            return;
        }

        if (ToolbarState.activeNavMenu != null
                && ToolbarState.activeNavMenu != menu
                && ToolbarState.activeNavMenu.isShowing()) {
            ToolbarState.activeNavMenu.hide();
        }

        menu.setAutoHide(true);
        menu.setHideOnEscape(true);
        menu.setOnHidden((WindowEvent e) -> {
            toggle.menu = null;
            toggle.closedAt = System.currentTimeMillis();
            if (ToolbarState.activeNavMenu == menu) {
                ToolbarState.activeNavMenu = null;
            }
            if (onClose != null) {
                onClose.run();
            }
        });

        toggle.menu = menu;
        ToolbarState.activeNavMenu = menu;

        if (onOpen != null) {
            onOpen.run();
        }

        owner.applyCss();
        owner.layout();

        Bounds onScreen = owner.localToScreen(owner.getBoundsInLocal());
        if (onScreen == null) {
            // Not attached to a window yet; let JavaFX place it.
            menu.show(owner, Side.BOTTOM, 0, 0);
            return;
        }
        menu.show(owner, onScreen.getMinX(), onScreen.getMaxY());
    }

    // =================================================================
    // Path helpers
    // =================================================================

    private static void navigateTo(UI_Main ide, Path targetPath, boolean recordHistory) {
        Path target = normalizeDir(targetPath);
        if (target == null || !Files.isDirectory(target)) {
            return;
        }

        Path current = normalizeDir(ide.currentFolder);
        if (recordHistory && current != null && !current.equals(target)) {
            ToolbarState.backHistory.push(current);
            ToolbarState.forwardHistory.clear();
        }

        ProjectManager.loadProjectFromPath(ide, target);
    }

    /**
     * Absolute, normalised, and expressed with the drive letter the user knows
     * the folder by.
     *
     * <p>
     * Two steps, and the order matters. {@code toRealPath} first, which
     * collapses junctions, symbolic links and casing differences so that every
     * route to a folder produces one identical physical path. Then
     * {@link DriveAliases#preferred} maps that physical path back onto its
     * drive letter, if it has one.
     * </p>
     *
     * <p>
     * The second step is what keeps {@code D:\My Research Works\MARL} reading
     * as itself. Windows hands the IDE the physical
     * {@code C:\D-Drive\D\My Research Works\MARL} from the folder picker, and
     * without the reverse mapping the breadcrumb draws exactly that. Both forms
     * open the same folder on disk, so the aliased one is purely the friendlier
     * of two correct answers.
     * </p>
     *
     * <p>
     * If the folder cannot be resolved -- deleted, or on a disconnected share
     * -- the plain absolute path is used, which is the old behaviour.
     * </p>
     *
     * @param path the path to clean up; may be null
     * @return the resolved path, or null if the input was null
     */
    private static Path normalizeDir(Path path) {
        if (path == null) {
            return null;
        }

        Path absolute;
        try {
            absolute = path.toAbsolutePath().normalize();
        } catch (RuntimeException e) {
            return path;
        }

        Path physical;
        try {
            physical = absolute.toRealPath();
        } catch (IOException | RuntimeException e) {
            physical = absolute;
        }

        return DriveAliases.preferred(physical);
    }

    /**
     * The text shown on a crumb: the folder's own name, or for a filesystem
     * root the root itself with its trailing separator removed, so
     * {@code D:\} reads as {@code D:}.
     *
     * @param path the folder
     * @return the label
     */
    private static String labelForPath(Path path) {
        Path name = path.getFileName();
        if (name != null) {
            return name.toString();
        }

        String raw = path.toString();
        if (raw.length() > 1 && (raw.endsWith("\\") || raw.endsWith("/"))) {
            raw = raw.substring(0, raw.length() - 1);
        }
        return raw;
    }

    private static List<Path> resolveOneDrivePaths() {
        Set<Path> candidates = new LinkedHashSet<>();

        String[] envKeys = { "OneDrive", "OneDriveCommercial", "OneDriveConsumer" };
        for (String key : envKeys) {
            String value = System.getenv(key);
            if (value != null && !value.isBlank()) {
                candidates.add(Path.of(value).toAbsolutePath().normalize());
            }
        }

        Path homeDefault = Path.of(System.getProperty("user.home"), "OneDrive").toAbsolutePath().normalize();
        candidates.add(homeDefault);

        return new ArrayList<>(candidates);
    }
}
