package ui.ui_functions.tools;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import javafx.scene.control.Button;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SplitMenuButton;
import javafx.stage.WindowEvent;
import ui.UI_Main;
import ui.managers.ProjectManager;

public final class ToolbarNavigation {

    private ToolbarNavigation() {
    }

    public static void updateQuickPath(Path path) {
        if (ToolbarState.quickPathSegments == null) {
            return;
        }

        javafx.application.Platform.runLater(() -> {
            if (path == null) {
                Label empty = new Label(ToolbarState.NO_PROJECT_TEXT);
                empty.getStyleClass().add("quick-path-empty");
                ToolbarState.quickPathSegments.getChildren().setAll(empty);
                return;
            }

            renderBreadcrumb(path.toAbsolutePath());
        });
    }

    public static void navigateBack(UI_Main ide) {
        if (ToolbarState.backHistory.isEmpty()) {
            return;
        }

        Path current = normalizeDir(ide.currentFolder);
        if (current != null) {
            ToolbarState.forwardHistory.push(current);
        }

        Path previous = ToolbarState.backHistory.pop();
        navigateTo(ide, previous, false);
    }

    public static void navigateForward(UI_Main ide) {
        if (ToolbarState.forwardHistory.isEmpty()) {
            return;
        }

        Path current = normalizeDir(ide.currentFolder);
        if (current != null) {
            ToolbarState.backHistory.push(current);
        }

        Path next = ToolbarState.forwardHistory.pop();
        navigateTo(ide, next, false);
    }

    public static void showFolderUpMenu(Button owner, UI_Main ide) {
        Path current = normalizeDir(ide.currentFolder);
        if (current == null) {
            return;
        }

        List<Path> parents = new ArrayList<>();
        Path cursor = current.getParent();
        while (cursor != null) {
            parents.add(cursor);
            cursor = cursor.getParent();
        }

        ContextMenu menu = new ContextMenu();
        if (parents.isEmpty()) {
            MenuItem empty = new MenuItem("No parent folder");
            empty.setDisable(true);
            menu.getItems().add(empty);
        } else {
            for (Path parent : parents) {
                MenuItem item = new MenuItem(labelForPath(parent));
                item.setOnAction(e -> navigateTo(ide, parent, true));
                menu.getItems().add(item);
            }
        }

        showNavMenu(owner, menu);
    }

    public static void loadFolderDownMenu(MenuButton btn, UI_Main ide) {
        btn.getItems().clear();

        Path current = normalizeDir(ide.currentFolder);
        if (current == null || !Files.isDirectory(current)) {
            MenuItem error = new MenuItem("Invalid folder");
            error.setDisable(true);
            btn.getItems().add(error);
            return;
        }

        try (java.util.stream.Stream<Path> stream = Files.list(current)) {
            List<Path> children = stream
                    .filter(Files::isDirectory)
                    .sorted(Comparator.comparing(p -> p.getFileName().toString().toLowerCase()))
                    .limit(50)
                    .toList();

            if (children.isEmpty()) {
                MenuItem empty = new MenuItem("No subfolders");
                empty.setDisable(true);
                btn.getItems().add(empty);
            } else {
                for (Path child : children) {
                    MenuItem item = new MenuItem(labelForPath(child));
                    item.setOnAction(e -> navigateTo(ide, child, true));
                    btn.getItems().add(item);
                }
            }
        } catch (Exception ignored) {
            MenuItem error = new MenuItem("Unable to list folders");
            error.setDisable(true);
            btn.getItems().add(error);
        }
    }

    public static void navigateOneDrive(UI_Main ide) {
        for (Path oneDrive : resolveOneDrivePaths()) {
            if (Files.isDirectory(oneDrive)) {
                navigateTo(ide, oneDrive, true);
                return;
            }
        }
    }

    public static void loadOneDriveMenu(SplitMenuButton btn, UI_Main ide) {
        btn.getItems().clear();

        List<Path> available = resolveOneDrivePaths().stream()
                .filter(Files::isDirectory)
                .toList();

        if (available.isEmpty()) {
            MenuItem empty = new MenuItem("OneDrive not found");
            empty.setDisable(true);
            btn.getItems().add(empty);
            return;
        }

        for (Path oneDrive : available) {
            MenuItem item = new MenuItem(labelForPath(oneDrive));
            item.setOnAction(e -> navigateTo(ide, oneDrive, true));
            btn.getItems().add(item);
        }
    }

    public static Path ensureDefaultUPIDirectory() {
        Path defaultDir = Path.of(System.getProperty("user.home"), "Documents", "UPI");

        try {
            if (Files.notExists(defaultDir)) {
                Files.createDirectories(defaultDir);
                System.out.println("Created UPI directory: " + defaultDir);
            } else {
                System.out.println("Using existing UPI directory: " + defaultDir);
            }
        } catch (Exception e) {
            e.printStackTrace();
            defaultDir = Path.of(System.getProperty("user.home"), "Documents");
        }

        return defaultDir;
    }

    private static void renderBreadcrumb(Path targetPath) {
        List<Path> chain = new ArrayList<>();
        Path cursor = targetPath;
        while (cursor != null) {
            chain.add(0, cursor);
            cursor = cursor.getParent();
        }

        ToolbarState.quickPathSegments.getChildren().clear();

        for (int i = 0; i < chain.size(); i++) {
            Path segmentPath = chain.get(i);
            Button segment = createSegmentButton(segmentPath);
            ToolbarState.quickPathSegments.getChildren().add(segment);

            if (i < chain.size() - 1) {
                Button sep = createSeparatorButton(segmentPath);
                ToolbarState.quickPathSegments.getChildren().add(sep);
            }
        }
    }

    private static Button createSegmentButton(Path segmentPath) {
        Button segment = new Button(labelForPath(segmentPath));
        segment.setFocusTraversable(false);
        segment.getStyleClass().add("quick-path-segment");

        segment.setOnAction(e -> {
            ContextMenu menu = buildSegmentMenu(segmentPath);
            showNavMenu(segment, menu);
        });

        return segment;
    }

    private static Button createSeparatorButton(Path sourcePath) {
        Button sep = new Button(">");
        sep.setFocusTraversable(false);
        sep.getStyleClass().add("quick-path-separator");

        sep.setOnAction(e -> {
            ContextMenu menu = buildSegmentMenu(sourcePath);
            sep.setText("v");
            menu.setOnHidden((WindowEvent hidden) -> sep.setText(">"));
            showNavMenu(sep, menu);
        });

        return sep;
    }

    private static ContextMenu buildSegmentMenu(Path segmentPath) {
        ContextMenu menu = new ContextMenu();

        if (ToolbarState.quickPathOwner != null) {
            MenuItem openCurrent = new MenuItem("Open " + labelForPath(segmentPath));
            openCurrent.setOnAction(e -> navigateTo(ToolbarState.quickPathOwner, segmentPath, true));
            menu.getItems().add(openCurrent);
        }

        try {
            if (Files.isDirectory(segmentPath)) {
                try (java.util.stream.Stream<Path> stream = Files.list(segmentPath)) {
                    List<Path> children = stream
                            .filter(Files::isDirectory)
                            .sorted(Comparator.comparing(
                                    p -> p.getFileName().toString().toLowerCase()))
                            .limit(40)
                            .toList();

                    if (children.isEmpty()) {
                        if (!menu.getItems().isEmpty()) {
                            menu.getItems().add(new javafx.scene.control.SeparatorMenuItem());
                        }
                        MenuItem empty = new MenuItem("No subfolders");
                        empty.setDisable(true);
                        menu.getItems().add(empty);
                    } else {
                        if (!menu.getItems().isEmpty()) {
                            menu.getItems().add(new javafx.scene.control.SeparatorMenuItem());
                        }
                        for (Path child : children) {
                            MenuItem item = new MenuItem(labelForPath(child));
                            item.setOnAction(e -> {
                                if (ToolbarState.quickPathOwner != null) {
                                    navigateTo(ToolbarState.quickPathOwner, child, true);
                                }
                            });
                            menu.getItems().add(item);
                        }
                    }
                }
            }
        } catch (Exception ignored) {
            if (menu.getItems().isEmpty()) {
                MenuItem error = new MenuItem("Unable to list folders");
                error.setDisable(true);
                menu.getItems().add(error);
            }
        }

        return menu;
    }

    private static String labelForPath(Path path) {
        Path name = path.getFileName();
        if (name != null) {
            return name.toString();
        }

        String raw = path.toString();
        if (raw.endsWith("\\") || raw.endsWith("/")) {
            raw = raw.substring(0, raw.length() - 1);
        }
        return raw;
    }

    private static List<Path> resolveOneDrivePaths() {
        Set<Path> candidates = new LinkedHashSet<>();

        String[] envKeys = { "OneDrive", "OneDriveCommercial", "OneDriveConsumer" };
        for (String key : envKeys) {
            String value = System.getenv(key);
            if (value != null && !value.isBlank()) {
                candidates.add(Path.of(value).toAbsolutePath().normalize());
            }
        }

        Path homeDefault = Path.of(System.getProperty("user.home"), "OneDrive").toAbsolutePath().normalize();
        candidates.add(homeDefault);

        return new ArrayList<>(candidates);
    }

    private static void showNavMenu(Button owner, ContextMenu menu) {
        if (ToolbarState.activeNavMenu != null && ToolbarState.activeNavMenu.isShowing()) {
            ToolbarState.activeNavMenu.hide();
        }

        ToolbarState.activeNavMenu = menu;
        javafx.event.EventHandler<WindowEvent> existingOnHidden = menu.getOnHidden();
        menu.setOnHidden(e -> {
            if (existingOnHidden != null) {
                existingOnHidden.handle(e);
            }
            if (ToolbarState.activeNavMenu == menu) {
                ToolbarState.activeNavMenu = null;
            }
        });

        owner.applyCss();
        owner.layout();
        double x = owner.localToScreen(owner.getBoundsInLocal()).getMinX();
        double y = owner.localToScreen(owner.getBoundsInLocal()).getMaxY();
        menu.show(owner, x, y);
    }

    private static void navigateTo(UI_Main ide, Path targetPath, boolean recordHistory) {
        Path target = normalizeDir(targetPath);
        if (target == null || !Files.isDirectory(target)) {
            return;
        }

        Path current = normalizeDir(ide.currentFolder);
        if (recordHistory && current != null && !current.equals(target)) {
            ToolbarState.backHistory.push(current);
            ToolbarState.forwardHistory.clear();
        }

        ProjectManager.loadProjectFromPath(ide, target);
    }

    private static Path normalizeDir(Path path) {
        if (path == null) {
            return null;
        }
        return path.toAbsolutePath().normalize();
    }
}
