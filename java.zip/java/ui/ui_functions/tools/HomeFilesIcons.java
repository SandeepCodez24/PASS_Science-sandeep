package ui.ui_functions.tools;

import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import ui.explorer.support.IconLoader;

/**
 * Loads the Files-group icon set from
 * {@code /icons/HomeFiles/<theme>/<name>.png}.
 *
 * <p>
 * The set ships twice, once in a near-black ink for the light theme and once
 * in a near-white ink for the dark one, because a single mid-tone that reads
 * on both a {@code #f4f4f5} and a {@code #2d2d2d} panel does not exist. Every
 * {@link ImageView} this class hands out is kept in a weak registry, so
 * {@link #setDarkTheme(boolean)} can re-point the icons already on screen
 * without the ribbon having to be rebuilt.
 * </p>
 *
 * <p>
 * The PNGs are 48px masters and are scaled down by the {@code ImageView}
 * with smoothing on, which keeps one file per icon per theme instead of one
 * per icon per theme per size.
 * </p>
 */
public final class HomeFilesIcons {

    private static final String BASE = "/icons/HomeFiles/";
    private static final String NAME_KEY = "homeFilesIconName";

    private static final List<WeakReference<ImageView>> LIVE = new CopyOnWriteArrayList<>();

    private static volatile boolean dark = false;

    private HomeFilesIcons() {
    }

    /**
     * Builds an icon view for one of the Files icons.
     *
     * @param name base file name, without theme folder or {@code .png}, e.g.
     *             {@code "new_script"}
     * @param size edge length in pixels; the image is scaled to fit
     * @return the configured view, already registered for theme swaps
     */
    public static ImageView icon(String name, double size) {
        ImageView view = new ImageView();
        view.getProperties().put(NAME_KEY, name);
        view.setFitWidth(size);
        view.setFitHeight(size);
        view.setPreserveRatio(true);
        view.setSmooth(true);
        view.setMouseTransparent(true);
        apply(view);
        LIVE.add(new WeakReference<>(view));
        return view;
    }

    /**
     * Switches the whole set between the two inks and refreshes every icon
     * currently on screen. Safe to call when nothing has changed.
     *
     * <p>
     * Call this from {@code ThemeManager} at the point the stylesheet is
     * swapped.
     * </p>
     *
     * @param useDark {@code true} for the dark-theme ink
     */
    public static void setDarkTheme(boolean useDark) {
        if (useDark == dark) {
            return;
        }
        dark = useDark;
        refresh();
    }

    /**
     * @return {@code true} if the dark-theme ink is currently selected
     */
    public static boolean isDarkTheme() {
        return dark;
    }

    /**
     * @param name base file name, without theme folder or extension
     * @return the classpath resource path for the active theme
     */
    public static String path(String name) {
        return BASE + (dark ? "dark/" : "light/") + name + ".png";
    }

    private static void refresh() {
        Iterator<WeakReference<ImageView>> it = LIVE.iterator();
        while (it.hasNext()) {
            WeakReference<ImageView> ref = it.next();
            ImageView view = ref.get();
            if (view == null) {
                LIVE.remove(ref);
            } else {
                apply(view);
            }
        }
    }

    private static void apply(ImageView view) {
        Object name = view.getProperties().get(NAME_KEY);
        if (name == null) {
            return;
        }
        Image image = IconLoader.load(HomeFilesIcons.class, path(name.toString()));
        if (image != null) {
            view.setImage(image);
        }
    }
}
