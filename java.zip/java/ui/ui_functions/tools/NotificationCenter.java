package ui.ui_functions.tools;

import java.net.URL;

import javafx.geometry.Bounds;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Popup;
import ui.UI_Main;
import ui.managers.ThemeManager;

/**
 * The drop-down behind the ribbon's notification bell.
 *
 * <p>
 * Placeholder content for now -- one line saying the server connection is
 * required. The shape is what matters: when the real notification feed
 * arrives, {@link #setMessage(String)} and the panel below are the only things
 * that change, and nothing in {@code ToolbarRibbon} has to move.
 * </p>
 *
 * <h3>The second-click problem</h3>
 * <p>
 * An auto-hiding {@link Popup} closes on any click outside itself -- including
 * the click on the button that opened it. The button's action then fires, sees
 * a closed popup, and reopens it, so the panel appears never to close. This is
 * the same bug the breadcrumb separator menus have.
 * </p>
 * <p>
 * The fix here is a short dead time: {@link #hide()} records when the panel
 * went away, and a toggle arriving within {@link #REOPEN_GUARD_MS} of that is
 * treated as the tail of the same click and ignored.
 * </p>
 *
 * <h3>Why the panel no longer trusts its stylesheet</h3>
 * <p>
 * A {@link Popup} owns a private scene that does <b>not</b> inherit the main
 * scene's stylesheets, so this panel has to be handed its own. The first
 * version loaded {@code /themes/ribbon/notification.css} and, if the resource
 * was missing, simply logged and carried on -- which produced a panel with a
 * transparent background on a scene whose fill is null. In other words: a
 * bell that opened an invisible popup, indistinguishable from a bell that does
 * nothing at all.
 * </p>
 * <p>
 * {@link #FALLBACK_LIGHT} and {@link #FALLBACK_DARK} below are now applied
 * inline whenever the stylesheet cannot be found, so the panel is always
 * visible. Copy the CSS file in and it takes over; the inline styles are only
 * ever the safety net, never both at once -- inline rules would outrank the
 * sheet if they were.
 * </p>
 */
public final class NotificationCenter {

    /** Stylesheet carrying both the light and dark panel rules. */
    private static final String CSS = "/themes/ribbon/notification.css";

    /** Style class on the panel root; gains {@code dark} under the dark theme. */
    private static final String PANEL_CLASS = "notification-panel";

    /** Width of the drop-down, in logical px. */
    private static final double PANEL_WIDTH = 260;

    /** Gap between the bell's bottom edge and the panel's top edge. */
    private static final double DROP_GAP = 6;

    /**
     * A toggle arriving within this many milliseconds of a hide is the same
     * click that caused the hide, and is ignored. See the class notes.
     */
    private static final long REOPEN_GUARD_MS = 250;

    /** Used only when {@link #CSS} cannot be resolved. See the class notes. */
    private static final String FALLBACK_LIGHT =
            "-fx-background-color: #ffffff;"
                    + "-fx-background-radius: 6;"
                    + "-fx-border-color: #c9d2db;"
                    + "-fx-border-radius: 6;"
                    + "-fx-border-width: 1;"
                    + "-fx-padding: 12 14 14 14;"
                    + "-fx-spacing: 6;"
                    + "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.22), 12, 0.0, 0, 4);";

    private static final String FALLBACK_DARK =
            "-fx-background-color: #2b3138;"
                    + "-fx-background-radius: 6;"
                    + "-fx-border-color: #454d56;"
                    + "-fx-border-radius: 6;"
                    + "-fx-border-width: 1;"
                    + "-fx-padding: 12 14 14 14;"
                    + "-fx-spacing: 6;"
                    + "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.45), 12, 0.0, 0, 4);";

    private static String message = "Server connection is required";

    private static Popup popup;
    private static Button owner;
    private static long hiddenAt;

    private NotificationCenter() {
    }

    /**
     * Makes a button open and close the notification panel.
     *
     * @param ide  the IDE controller, for the owning window and active theme
     * @param bell the notification button
     */
    public static void install(UI_Main ide, Button bell) {
        if (bell == null) {
            return;
        }
        bell.setOnAction(e -> toggle(ide, bell));
    }

    /**
     * Replaces the panel's text. Takes effect the next time it is opened.
     *
     * @param text the message to show
     */
    public static void setMessage(String text) {
        if (text != null && !text.isBlank()) {
            message = text;
        }
    }

    /** Closes the panel if it is open. */
    public static void hide() {
        if (popup != null && popup.isShowing()) {
            popup.hide();
        }
        popup = null;
        owner = null;
        hiddenAt = System.currentTimeMillis();
    }

    /* =====================================================================
     * INTERNALS
     * ===================================================================== */

    private static void toggle(UI_Main ide, Button bell) {
        // Auto-hide has already closed the panel by the time this runs, so an
        // "is it showing" test alone cannot tell a close from an open.
        if (System.currentTimeMillis() - hiddenAt < REOPEN_GUARD_MS) {
            return;
        }
        if (popup != null && popup.isShowing() && owner == bell) {
            hide();
            return;
        }
        hide();
        show(bell);
    }

    private static void show(Button bell) {
        Bounds anchor = bell.localToScreen(bell.getBoundsInLocal());
        if (anchor == null) {
            System.err.println("NotificationCenter: bell is not on a screen yet.");
            return;
        }

        boolean dark = "dark".equals(ThemeManager.getActiveTheme());

        Popup p = new Popup();
        p.setAutoHide(true);
        p.setHideOnEscape(true);
        p.setOnAutoHide(e -> hiddenAt = System.currentTimeMillis());

        boolean styled = applyStylesheet(p);
        p.getContent().add(buildPanel(dark, styled));

        popup = p;
        owner = bell;

        // Right edge of the panel aligned with the right edge of the bell, so
        // a panel wider than its button grows inwards and never off-screen.
        double x = anchor.getMaxX() - PANEL_WIDTH;
        double y = anchor.getMaxY() + DROP_GAP;
        p.show(bell, x, y);
    }

    /**
     * @param dark   true when the dark theme is in force
     * @param styled true when the stylesheet loaded, so inline rules must not
     *               be applied -- they would outrank it
     * @return the panel root
     */
    private static Region buildPanel(boolean dark, boolean styled) {
        Label heading = new Label("Notifications");
        heading.getStyleClass().add("notification-heading");

        Label text = new Label(message);
        text.getStyleClass().add("notification-message");
        text.setWrapText(true);

        VBox panel = new VBox(heading, text);
        panel.getStyleClass().add(PANEL_CLASS);
        if (dark) {
            panel.getStyleClass().add("dark");
        }
        panel.setAlignment(Pos.TOP_LEFT);
        panel.setPrefWidth(PANEL_WIDTH);
        panel.setMinWidth(PANEL_WIDTH);
        panel.setMaxWidth(PANEL_WIDTH);

        if (!styled) {
            panel.setStyle(dark ? FALLBACK_DARK : FALLBACK_LIGHT);
            heading.setStyle("-fx-font-size: 12px; -fx-font-weight: bold; -fx-text-fill: "
                    + (dark ? "#7fc4ff;" : "#004073;"));
            text.setStyle("-fx-font-size: 12px; -fx-text-fill: "
                    + (dark ? "#d6dce2;" : "#3a3a3a;"));
        }
        return panel;
    }

    /**
     * @param p the popup being prepared
     * @return true if the stylesheet was found and attached
     */
    private static boolean applyStylesheet(Popup p) {
        URL url = NotificationCenter.class.getResource(CSS);
        if (url == null) {
            System.err.println("NotificationCenter: stylesheet missing (" + CSS
                    + "); using inline fallback styling.");
            return false;
        }
        if (p.getScene() == null) {
            return false;
        }
        p.getScene().getStylesheets().add(url.toExternalForm());
        return true;
    }
}
