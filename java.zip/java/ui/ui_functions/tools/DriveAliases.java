package ui.ui_functions.tools;

import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;

/**
 * Translates a physical folder path into the drive letter the user thinks of
 * it as living on.
 *
 * <p>
 * Windows lets a drive letter stand for a folder. {@code subst D: C:\D-Drive\D}
 * and {@code net use Z: \\server\share} both do it. Explorer shows the letter,
 * but the native folder picker hands back the physical path underneath, so a
 * folder the user opened as {@code D:\My Research Works\MARL} arrives in the
 * IDE as {@code C:\D-Drive\D\My Research Works\MARL} and the breadcrumb
 * faithfully draws five crumbs starting at {@code C:}.
 * </p>
 *
 * <p>
 * This class holds the reverse mapping so the breadcrumb can put the letter
 * back. Both directions of the path still work on disk -- Windows resolves the
 * alias transparently -- so nothing else in the IDE has to care which form it
 * is handed.
 * </p>
 *
 * <h2>Where the mapping comes from</h2>
 *
 * <p>
 * Each drive root is asked for its real path. A plain volume answers with
 * itself; an alias answers with the folder it stands for, and that pair is the
 * mapping. If a particular Windows or JDK combination does not resolve it that
 * way, {@link #setAlias(String, String)} records the pair by hand, once, and it
 * persists across restarts.
 * </p>
 */
public final class DriveAliases {

    private static final Preferences PREFS = Preferences.userRoot().node("astra/drive_aliases");

    /** Physical folder -> the drive root that stands for it. */
    private static final Map<Path, Path> ALIAS_BY_TARGET = new LinkedHashMap<>();

    private static volatile boolean loaded;

    private DriveAliases() {
    }

    /**
     * Rewrites a path to use its alias drive letter, when it has one.
     *
     * <p>
     * {@code C:\D-Drive\D\My Research Works\MARL} becomes
     * {@code D:\My Research Works\MARL} once {@code D:} is known to stand for
     * {@code C:\D-Drive\D}. A path with no alias is returned untouched, so this
     * is safe to call on everything.
     * </p>
     *
     * @param path the physical path; may be null
     * @return the aliased path, or the original if nothing maps
     */
    public static Path preferred(Path path) {
        if (path == null) {
            return null;
        }
        ensureLoaded();

        Path bestTarget = null;
        Path bestAlias = null;

        synchronized (ALIAS_BY_TARGET) {
            for (Map.Entry<Path, Path> entry : ALIAS_BY_TARGET.entrySet()) {
                Path target = entry.getKey();
                if (!path.startsWith(target)) {
                    continue;
                }
                // Deepest match wins, so nested aliases resolve to the most
                // specific letter rather than whichever was found first.
                if (bestTarget == null || target.getNameCount() > bestTarget.getNameCount()) {
                    bestTarget = target;
                    bestAlias = entry.getValue();
                }
            }
        }

        if (bestTarget == null) {
            return path;
        }

        try {
            Path relative = bestTarget.relativize(path);
            return relative.toString().isEmpty() ? bestAlias : bestAlias.resolve(relative);
        } catch (IllegalArgumentException e) {
            return path;
        }
    }

    /**
     * Records that a drive letter stands for a folder, and remembers it across
     * restarts.
     *
     * <p>
     * Only needed if automatic detection misses. Call it once from anywhere --
     * {@code application.Main}, for instance -- and the line can be deleted
     * afterwards, because the pair is stored in {@link Preferences}:
     * </p>
     *
     * <pre>
     *   DriveAliases.setAlias("D:\\", "C:\\D-Drive\\D");
     * </pre>
     *
     * @param aliasRoot  the drive root, such as {@code D:\}
     * @param targetPath the folder it stands for
     */
    public static void setAlias(String aliasRoot, String targetPath) {
        if (aliasRoot == null || aliasRoot.isBlank() || targetPath == null || targetPath.isBlank()) {
            return;
        }
        PREFS.put(aliasRoot, targetPath);
        flush();
        refresh();
    }

    /**
     * Forgets a hand-recorded alias. Has no effect on detected ones, which are
     * rebuilt on the next {@link #refresh()}.
     *
     * @param aliasRoot the drive root, such as {@code D:\}
     */
    public static void removeAlias(String aliasRoot) {
        if (aliasRoot == null || aliasRoot.isBlank()) {
            return;
        }
        PREFS.remove(aliasRoot);
        flush();
        refresh();
    }

    /**
     * Rebuilds the mapping: detection first, then any hand-recorded pairs on
     * top. Call after plugging in a drive or running {@code subst}.
     */
    public static void refresh() {
        Map<Path, Path> rebuilt = new LinkedHashMap<>();
        detectAliases(rebuilt);
        loadStoredAliases(rebuilt);

        synchronized (ALIAS_BY_TARGET) {
            ALIAS_BY_TARGET.clear();
            ALIAS_BY_TARGET.putAll(rebuilt);
        }
        loaded = true;
    }

    /**
     * The mapping in force, one pair per line, for printing to the Command
     * Window when a path is not coming out as expected.
     *
     * @return a human-readable dump, never null
     */
    public static String describe() {
        ensureLoaded();

        StringBuilder out = new StringBuilder();
        synchronized (ALIAS_BY_TARGET) {
            if (ALIAS_BY_TARGET.isEmpty()) {
                return "No drive aliases detected.";
            }
            for (Map.Entry<Path, Path> entry : ALIAS_BY_TARGET.entrySet()) {
                out.append(entry.getValue())
                        .append("  stands for  ")
                        .append(entry.getKey())
                        .append(System.lineSeparator());
            }
        }
        return out.toString();
    }

    // -----------------------------------------------------------------
    // internals
    // -----------------------------------------------------------------

    private static void ensureLoaded() {
        if (!loaded) {
            synchronized (DriveAliases.class) {
                if (!loaded) {
                    refresh();
                }
            }
        }
    }

    /**
     * Asks every drive root for its real path. A plain volume answers with
     * itself and is skipped; anything that answers with a different path is an
     * alias for that path.
     */
    private static void detectAliases(Map<Path, Path> into) {
        for (Path root : FileSystems.getDefault().getRootDirectories()) {
            try {
                if (!Files.isDirectory(root)) {
                    continue;
                }
                Path real = root.toRealPath();
                if (real.equals(root)) {
                    continue;
                }
                into.put(real, root);
            } catch (Exception ignored) {
                // Empty card reader, disconnected share, permission denied:
                // that root simply contributes no mapping.
            }
        }
    }

    private static void loadStoredAliases(Map<Path, Path> into) {
        String[] keys;
        try {
            keys = PREFS.keys();
        } catch (BackingStoreException e) {
            return;
        }

        for (String aliasRoot : keys) {
            String targetPath = PREFS.get(aliasRoot, null);
            if (targetPath == null || targetPath.isBlank()) {
                continue;
            }
            try {
                Path alias = Path.of(aliasRoot);
                Path target = Path.of(targetPath).toAbsolutePath().normalize();
                if (alias.equals(target)) {
                    continue;
                }
                into.put(target, alias);
            } catch (InvalidPathException ignored) {
                // A malformed stored pair is skipped rather than fatal.
            }
        }
    }

    private static void flush() {
        try {
            PREFS.flush();
        } catch (BackingStoreException ignored) {
            // The value still holds for this session.
        }
    }
}
