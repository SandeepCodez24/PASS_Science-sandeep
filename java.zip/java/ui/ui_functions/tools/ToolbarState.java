package ui.ui_functions.tools;

import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.Deque;

import javafx.scene.control.ContextMenu;
import javafx.scene.control.TextField;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import ui.UI_Main;

public final class ToolbarState {

    public static ToolBar ribbonBar;
    public static StackPane toolbarStack;
    public static ToolBar quickAccessBar;
    public static Region quickPathLabel;
    public static HBox quickPathSegments;
    public static UI_Main quickPathOwner;
    public static ContextMenu activeNavMenu;

    // Reference to the ribbon search field so the Alt+Space shortcut
    // (wired in Main_Window) can focus it from anywhere.
    public static TextField searchField;

    public static final Deque<Path> backHistory = new ArrayDeque<>();
    public static final Deque<Path> forwardHistory = new ArrayDeque<>();

    // ===== Ribbon / Tab bar colours =====
    // Task 3: ribbon background changed from teal to navy blue.
    public static final String BG = "#004073";
    // Kept for the quick-access nav arrow mark colour (unchanged).
    public static final String ACTIVE = "#00cccc";
    // Task 7: the SELECTED tab is light grey with black text.
    public static final String TAB_ACTIVE_BG = "#e0e0e0";
    public static final String TAB_ACTIVE_TEXT = "#000000";
    // Unselected tabs: white text on the navy ribbon.
    public static final String TAB_TEXT = "#ffffff";

    public static final String NO_PROJECT_TEXT = "No project selected";

    private ToolbarState() {
    }
}
