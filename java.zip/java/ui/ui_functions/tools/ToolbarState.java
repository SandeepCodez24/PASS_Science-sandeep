package ui.ui_functions.tools;

import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.Deque;

import javafx.scene.control.ContextMenu;
import javafx.scene.control.TextField;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import ui.UI_Main;

public final class ToolbarState {

    public static ToolBar ribbonBar;
    public static StackPane toolbarStack;
    public static ToolBar quickAccessBar;
    public static Region quickPathLabel;
    public static HBox quickPathSegments;
    public static UI_Main quickPathOwner;
    public static ContextMenu activeNavMenu;

    // Reference to the ribbon search field so the Alt+Space shortcut
    // (wired in Main_Window) can focus it from anywhere.
    public static TextField searchField;

    public static final Deque<Path> backHistory = new ArrayDeque<>();
    public static final Deque<Path> forwardHistory = new ArrayDeque<>();

    // ===== Ribbon / Tab bar colours =====
    // The navy of the Row-1 strip. Still applied inline in ToolbarSetup, so
    // this constant is live.
    public static final String BG = "#004073";

    // Kept for the quick-access nav arrow mark colour (unchanged).
    public static final String ACTIVE = "#00cccc";

    // The three constants below are documentation only. The selected tab is
    // drawn entirely from themes/ribbon/ribbon_light.css and ribbon_dark.css
    // now, because it has to match the Row-2 band exactly -- the tab and the
    // band are one surface, and a value duplicated in Java would be a second
    // place for that match to drift. Values here mirror the light sheet.
    /** @deprecated see .ribbon-tab:selected in themes/ribbon/ribbon_light.css */
    @Deprecated
    public static final String TAB_ACTIVE_BG = "#fafbfc";

    /** @deprecated see .ribbon-tab:selected in themes/ribbon/ribbon_light.css */
    @Deprecated
    public static final String TAB_ACTIVE_TEXT = "#1f1f1f";

    /** @deprecated see .ribbon-tab in themes/ribbon/ribbon_light.css */
    @Deprecated
    public static final String TAB_TEXT = "#ffffff";

    public static final String NO_PROJECT_TEXT = "No project selected";

    private ToolbarState() {
    }
}
