package ui.ui_functions.tools;

import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.Deque;

import javafx.scene.control.ContextMenu;
import javafx.scene.control.TextField;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import ui.UI_Main;

/**
 * Shared references to the toolbar rows, so classes that did not build a row
 * can still find it.
 */
public final class ToolbarState {

    /** Row 1: the navy tab strip. */
    public static ToolBar ribbonBar;

    /** Row 2: the tool band, one ToolBar per tab stacked in one pane. */
    public static StackPane toolbarStack;

    /** Row 3: the quick-access row (navigation bar + breadcrumb bar). */
    public static ToolBar quickAccessBar;

    /**
     * The breadcrumb path box. {@code RibbonCollapse} inserts the collapse
     * toggle right after it. Set by {@code BreadcrumbBar.build}.
     */
    public static Region quickPathLabel;

    /** The HBox holding the crumbs. Set by {@code BreadcrumbBar.build}. */
    public static HBox quickPathSegments;

    /** The IDE the quick-access row belongs to. */
    public static UI_Main quickPathOwner;

    /**
     * The one quick-access drop-down on screen, if any. Opening another closes
     * it; see {@code PopupMenuToggle}.
     */
    public static ContextMenu activeNavMenu;

    // Reference to the ribbon search field so the Alt+Space shortcut
    // (wired in Main_Window) can focus it from anywhere.
    public static TextField searchField;

    /**
     * @deprecated Back / Forward history is {@code FolderHistory} now, and it
     *             records run folders, not every folder visited. Nothing reads
     *             or writes this deque any more; it is kept only so older call
     *             sites compile.
     */
    @Deprecated
    public static final Deque<Path> backHistory = new ArrayDeque<>();

    /** @deprecated see {@link #backHistory} */
    @Deprecated
    public static final Deque<Path> forwardHistory = new ArrayDeque<>();

    // ===== Ribbon / Tab bar colours =====
    // The navy of the Row-1 strip. Still applied inline in ToolbarSetup, so
    // this constant is live.
    public static final String BG = "#004073";

    /**
     * @deprecated was the mark colour of the old forward MenuButton, which is
     *             gone; the navigation buttons carry no inline colour now.
     */
    @Deprecated
    public static final String ACTIVE = "#00cccc";

    // The three constants below are documentation only. The selected tab is
    // drawn entirely from themes/ribbon/ribbon_light.css and ribbon_dark.css
    // now, because it has to match the Row-2 band exactly -- the tab and the
    // band are one surface, and a value duplicated in Java would be a second
    // place for that match to drift. Values here mirror the light sheet.
    /** @deprecated see .ribbon-tab:selected in themes/ribbon/ribbon_light.css */
    @Deprecated
    public static final String TAB_ACTIVE_BG = "#fafbfc";

    /** @deprecated see .ribbon-tab:selected in themes/ribbon/ribbon_light.css */
    @Deprecated
    public static final String TAB_ACTIVE_TEXT = "#1f1f1f";

    /** @deprecated see .ribbon-tab in themes/ribbon/ribbon_light.css */
    @Deprecated
    public static final String TAB_TEXT = "#ffffff";

    public static final String NO_PROJECT_TEXT = "No project selected";

    private ToolbarState() {
    }
}
