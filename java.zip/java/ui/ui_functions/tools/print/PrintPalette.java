package ui.ui_functions.tools.print;

import java.awt.Color;
import java.util.Collection;

/**
 * The style class to ink table -- the print side's counterpart to
 * {@code editor_light.css} and {@code editor_dark.css}.
 *
 * <h3>Why the colours are restated here at all</h3>
 * <p>
 * A printout is drawn by AWT and PDFBox, neither of which can read a JavaFX
 * stylesheet. Parsing the CSS at runtime was the alternative and was rejected:
 * it would make printing depend on a file format JavaFX is free to interpret
 * its own way, for seven colours that change about once a year.
 * </p>
 * <p>
 * <b>So this file must be kept in step by hand.</b> The class names below are
 * exactly the ones {@code UPITokenMaker} emits, and the hex values are exactly
 * the ones in the two editor stylesheets. If you retune a token colour there,
 * retune it here.
 * </p>
 *
 * <h3>Two deliberate departures from the screen palette</h3>
 * <ul>
 * <li><b>Comment opacity is dropped.</b> The editor sets {@code opacity: 0.55}
 * on light comments. Composited onto white that is roughly #cbcbcb, which is
 * legible on a backlit screen and close to invisible on paper. Print uses the
 * flat colour instead.</li>
 * <li><b>Sub- and superscript runs keep the full character cell.</b> They are
 * drawn smaller and shifted off the baseline, but the layout still advances a
 * whole cell, so the monospace grid -- and therefore the wrap column and every
 * page boundary -- stays exact. See {@code PrintPaginator}.</li>
 * </ul>
 */
public final class PrintPalette {

    /* ---- light theme (editor_light.css) ---- */
    private static final Color L_BASE = new Color(0x00, 0x00, 0x00);
    private static final Color L_COMMENT = new Color(0xA0, 0xA0, 0xA0);
    private static final Color L_IDENTIFIER = new Color(0x00, 0x00, 0x00);
    private static final Color L_BUILTIN = new Color(0x99, 0x32, 0xCC);
    private static final Color L_PRIMITIVE = new Color(0xDC, 0x14, 0x3C);
    private static final Color L_CONDITIONAL = new Color(0x0C, 0x7C, 0xBA);
    private static final Color L_STRING = new Color(0x00, 0x8B, 0x8B);
    private static final Color L_NUMBER = new Color(0x8C, 0x2A, 0x2A);
    private static final Color L_PAGE = new Color(0xFF, 0xFF, 0xFF);
    private static final Color L_GUTTER = new Color(0xE8, 0xE8, 0xE8);
    private static final Color L_LINENO = new Color(0x85, 0x85, 0x85);
    private static final Color L_FURNITURE = new Color(0x60, 0x60, 0x60);
    private static final Color L_RULE = new Color(0xC0, 0xC0, 0xC0);

    /* ---- dark theme (editor_dark.css) ---- */
    private static final Color D_BASE = new Color(0xD4, 0xD4, 0xD4);
    private static final Color D_COMMENT = new Color(0x9A, 0xA0, 0xA6);
    private static final Color D_IDENTIFIER = new Color(0xE6, 0xE6, 0xE6);
    private static final Color D_BUILTIN = new Color(0xC7, 0x92, 0xEA);
    private static final Color D_PRIMITIVE = new Color(0xFF, 0x6B, 0x81);
    private static final Color D_CONDITIONAL = new Color(0x4F, 0xB0, 0xE6);
    private static final Color D_STRING = new Color(0x2E, 0xC4, 0xC4);
    private static final Color D_NUMBER = new Color(0xD1, 0x9A, 0x66);
    private static final Color D_PAGE = new Color(0x1E, 0x1E, 0x1E);
    private static final Color D_GUTTER = new Color(0x51, 0x58, 0x61);
    private static final Color D_LINENO = new Color(0x85, 0x85, 0x85);
    private static final Color D_FURNITURE = new Color(0xA9, 0xB4, 0xBF);
    private static final Color D_RULE = new Color(0x4D, 0x54, 0x5B);

    private PrintPalette() {
    }

    /**
     * Ink for a run.
     *
     * @param styleClasses the classes RichTextFX carries on the span; may be
     *                     empty, in which case the base fill is used
     * @param theme        the palette
     * @return the colour to draw the run in
     */
    public static Color ink(Collection<String> styleClasses, PrintSettings.Theme theme) {
        boolean dark = theme == PrintSettings.Theme.DARK;
        if (styleClasses != null) {
            for (String c : styleClasses) {
                switch (c) {
                    case "comment":
                        return dark ? D_COMMENT : L_COMMENT;
                    case "string":
                        return dark ? D_STRING : L_STRING;
                    case "number":
                        return dark ? D_NUMBER : L_NUMBER;
                    case "builtin-function":
                        return dark ? D_BUILTIN : L_BUILTIN;
                    case "primitive":
                        return dark ? D_PRIMITIVE : L_PRIMITIVE;
                    // "keyword" is the legacy twin of "conditional"; the
                    // stylesheets keep both in sync, so this does too.
                    case "conditional":
                    case "keyword":
                        return dark ? D_CONDITIONAL : L_CONDITIONAL;
                    case "identifier":
                    case "operator":
                        return dark ? D_IDENTIFIER : L_IDENTIFIER;
                    default:
                        // A sub/superscript class carries no colour of its own
                        // -- it rides on whatever token it sits inside. Keep
                        // looking rather than falling through to the base.
                        break;
                }
            }
        }
        return dark ? D_BASE : L_BASE;
    }

    /**
     * @param styleClasses the classes on the span
     * @return true if the stylesheets draw this token bold
     */
    public static boolean bold(Collection<String> styleClasses) {
        return has(styleClasses, "primitive")
                || has(styleClasses, "conditional")
                || has(styleClasses, "keyword");
    }

    /**
     * @param styleClasses the classes on the span
     * @return true if the stylesheets draw this token italic
     */
    public static boolean italic(Collection<String> styleClasses) {
        return has(styleClasses, "comment");
    }

    /**
     * @param styleClasses the classes on the span
     * @return the vertical shift as a fraction of the font size -- negative
     *         raises (superscript), positive lowers (subscript), zero for
     *         ordinary text
     */
    public static double baselineShift(Collection<String> styleClasses) {
        if (styleClasses == null) {
            return 0;
        }
        for (String c : styleClasses) {
            if (c.startsWith("superscript")) {
                return -0.33;
            }
            if (c.startsWith("subscript")) {
                return 0.20;
            }
        }
        return 0;
    }

    /**
     * @param styleClasses the classes on the span
     * @return the size multiplier for the run, matching the editor's 55% and
     *         65%
     */
    public static double sizeScale(Collection<String> styleClasses) {
        if (styleClasses == null) {
            return 1.0;
        }
        for (String c : styleClasses) {
            if (c.startsWith("superscript")) {
                return 0.55;
            }
            if (c.startsWith("subscript")) {
                return 0.65;
            }
        }
        return 1.0;
    }

    /** @param theme the palette @return the page background */
    public static Color page(PrintSettings.Theme theme) {
        return theme == PrintSettings.Theme.DARK ? D_PAGE : L_PAGE;
    }

    /** @param theme the palette @return the line-number gutter band */
    public static Color gutter(PrintSettings.Theme theme) {
        return theme == PrintSettings.Theme.DARK ? D_GUTTER : L_GUTTER;
    }

    /** @param theme the palette @return the line-number ink */
    public static Color lineNumber(PrintSettings.Theme theme) {
        return theme == PrintSettings.Theme.DARK ? D_LINENO : L_LINENO;
    }

    /** @param theme the palette @return the header and footer ink */
    public static Color furniture(PrintSettings.Theme theme) {
        return theme == PrintSettings.Theme.DARK ? D_FURNITURE : L_FURNITURE;
    }

    /** @param theme the palette @return the hairline under the header */
    public static Color rule(PrintSettings.Theme theme) {
        return theme == PrintSettings.Theme.DARK ? D_RULE : L_RULE;
    }

    private static boolean has(Collection<String> classes, String name) {
        return classes != null && classes.contains(name);
    }
}
