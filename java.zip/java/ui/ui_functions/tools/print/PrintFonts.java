package ui.ui_functions.tools.print;

import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.geom.AffineTransform;
import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The fonts every printout is drawn in, and the one layout both renderers
 * share.
 *
 * <h3>Everything is bundled</h3>
 * <p>
 * Astra is standalone, so nothing here reads the operating system's font
 * folder. Every face is a Noto font under {@code /fonts} on the classpath
 * (SIL Open Font License 1.1, see {@code /fonts/OFL.txt}), so a printout looks
 * the same on every machine:
 * </p>
 * <ul>
 * <li>{@link Face#MONO} -- Noto Sans Mono: Latin, Greek, Cyrillic, digits and
 * punctuation. Code is laid out on its fixed cell.</li>
 * <li>{@link Face#TAMIL}, {@link Face#DEVANAGARI} (Sanskrit),
 * {@link Face#TELUGU}, {@link Face#MALAYALAM}, {@link Face#KANNADA} -- the
 * Indic identifiers.</li>
 * <li>{@link Face#MATH} -- Noto Sans Math, for the bold-italic constants
 * ({@code 𝝅}, {@code 𝒈}, {@code ℏ} ...) and any other symbol the mono face
 * lacks.</li>
 * </ul>
 *
 * <h3>Clusters, not characters</h3>
 * <p>
 * A Tamil {@code கொ} is two code points, {@code க} and {@code ொ}, but one
 * thing on the page -- and the vowel sign is drawn partly <i>before</i> the
 * consonant. Laying text out one {@code char} at a time, as the old renderers
 * did, cannot draw that. So a line is first cut into <b>clusters</b>: a base
 * character with every mark that belongs to it, and, across a virama
 * ({@code ்}, {@code ्}, {@code ్}, {@code ്}, {@code ್}), the consonant that
 * follows, so a conjunct such as {@code क्ष} stays whole.
 * </p>
 * <p>
 * Each cluster is drawn in the first face that can show all of it, and is
 * <b>shaped</b> by Java2D ({@link Font#layoutGlyphVector}), which applies the
 * font's OpenType rules: vowel signs reordered, conjuncts formed, marks
 * stacked. The result is the letter as a reader expects it, the same as the
 * editor shows.
 * </p>
 *
 * <h3>Widths</h3>
 * <ul>
 * <li>A cluster in the mono face takes one cell, whatever it is, so ordinary
 * code keeps its exact column grid. Sub- and superscripts, drawn smaller,
 * still take the whole cell.</li>
 * <li>Every other cluster takes its natural, shaped width, so Indic letters
 * are neither squeezed nor spaced out.</li>
 * </ul>
 * <p>
 * Widths come from the bundled fonts through one fixed
 * {@link FontRenderContext}, so the PDF and the paper copy wrap at the same
 * places and have the same page count.
 * </p>
 *
 * <h3>Bold and italic</h3>
 * <p>
 * Every face has a bundled bold except Math, which is drawn regular. None has
 * a bundled italic; italic is drawn as an oblique by slanting the regular
 * glyphs by {@link #ITALIC_SLANT}. Slanting leaves advances unchanged, so
 * italic never moves a line break.
 * </p>
 */
public final class PrintFonts {

    /** Horizontal shear for a synthetic italic: about 12 degrees. */
    public static final double ITALIC_SLANT = 0.21;

    /** Drawn when no bundled face has a character. */
    private static final String MISSING = "?";

    /** One context for every measurement, so paper and PDF agree. */
    private static final FontRenderContext FRC = new FontRenderContext(null, true, true);

    /** A bundled typeface. Earlier entries win when several can draw a cluster. */
    public enum Face {
        /** Latin, Greek, Cyrillic, digits, punctuation. */
        MONO("NotoSansMono-Regular.ttf", "NotoSansMono-Bold.ttf"),
        /** Tamil. */
        TAMIL("NotoSansTamil-Regular.ttf", "NotoSansTamil-Bold.ttf"),
        /** Devanagari: Sanskrit, Hindi, Marathi. */
        DEVANAGARI("NotoSansDevanagari-Regular.ttf", "NotoSansDevanagari-Bold.ttf"),
        /** Telugu. */
        TELUGU("NotoSansTelugu-Regular.ttf", "NotoSansTelugu-Bold.ttf"),
        /** Malayalam. */
        MALAYALAM("NotoSansMalayalam-Regular.ttf", "NotoSansMalayalam-Bold.ttf"),
        /** Kannada. */
        KANNADA("NotoSansKannada-Regular.ttf", "NotoSansKannada-Bold.ttf"),
        /** Mathematical alphanumerics and symbols. No bold is bundled. */
        MATH("NotoSansMath-Regular.ttf", null);

        private final String regularFile;
        private final String boldFile;

        Face(String regularFile, String boldFile) {
            this.regularFile = regularFile;
            this.boldFile = boldFile;
        }

        /**
         * @param bold true for the bold weight
         * @return the classpath resource; bold falls back to regular when the
         *         face has no bold
         */
        public String resource(boolean bold) {
            return "/fonts/" + (bold && boldFile != null ? boldFile : regularFile);
        }

        /** @return true when this face ships a real bold */
        public boolean hasBold() {
            return boldFile != null;
        }
    }

    /**
     * One cluster placed on a row.
     *
     * @param text    the cluster's characters, or {@code "?"} when no face has
     *                them
     * @param classes the style classes of the run it came from
     * @param face    the face it is drawn in
     * @param x       its left edge, in points from the start of the code area
     * @param width   the space it takes, in points
     */
    public record Cell(String text, Collection<String> classes, Face face, double x, double width) {

        /** @return true when the cell is drawn from a shaped glyph run */
        public boolean shaped() {
            return face != Face.MONO;
        }
    }

    /* =====================================================================
     * BUNDLED FONT FILES (loaded once per run of the application)
     * ===================================================================== */

    private static final class Bundle {
        static final Map<String, byte[]> BYTES = new HashMap<>();
        static final Map<String, Font> BASE = new HashMap<>();

        static synchronized byte[] bytes(String resource) {
            return BYTES.computeIfAbsent(resource, r -> {
                try (InputStream in = PrintFonts.class.getResourceAsStream(r)) {
                    if (in == null) {
                        throw new IllegalStateException("Bundled font missing: " + r
                                + " (expected under src/main/resources" + r + ")");
                    }
                    return in.readAllBytes();
                } catch (IOException e) {
                    throw new UncheckedIOException(e);
                }
            });
        }

        static synchronized Font base(String resource) {
            return BASE.computeIfAbsent(resource, r -> {
                try {
                    return Font.createFont(Font.TRUETYPE_FONT,
                            new java.io.ByteArrayInputStream(bytes(r)));
                } catch (FontFormatException | IOException e) {
                    throw new IllegalStateException("Bundled font unreadable: " + r, e);
                }
            });
        }
    }

    /**
     * The raw font file, for the PDF writer to embed.
     *
     * @param face the face
     * @param bold the weight
     * @return the TTF bytes
     */
    public static byte[] fontFile(Face face, boolean bold) {
        return Bundle.bytes(face.resource(bold));
    }

    /* =====================================================================
     * INSTANCE: one point size, cached derived fonts and widths
     * ===================================================================== */

    private final float size;
    private final double cell;
    private final Map<String, Font> derived = new HashMap<>();
    private final Map<String, Double> widths = new HashMap<>();
    private final Map<Face, Font> probe = new EnumMap<>(Face.class);

    /**
     * @param size the code point size, in points
     */
    public PrintFonts(float size) {
        this.size = size;
        for (Face f : Face.values()) {
            probe.put(f, Bundle.base(f.resource(false)));
        }
        Font mono = font(Face.MONO, false, false, size);
        this.cell = mono.createGlyphVector(FRC, "M").getGlyphMetrics(0).getAdvanceX();
    }

    /** @return the code point size */
    public float size() {
        return size;
    }

    /** @return the width of one mono cell at the code size, in points */
    public double cell() {
        return cell;
    }

    /**
     * A derived AWT font.
     *
     * @param face   the face
     * @param bold   bold weight (regular if the face has none)
     * @param italic slanted
     * @param pt     point size
     * @return the font
     */
    public Font font(Face face, boolean bold, boolean italic, double pt) {
        String key = face + ":" + bold + ":" + italic + ":" + pt;
        Font f = derived.get(key);
        if (f == null) {
            f = Bundle.base(face.resource(bold)).deriveFont((float) pt);
            if (italic) {
                f = f.deriveFont(AffineTransform.getShearInstance(-ITALIC_SLANT, 0));
            }
            derived.put(key, f);
        }
        return f;
    }

    /**
     * Shapes a cluster: the font's OpenType rules applied, so the glyphs are
     * the ones a reader expects.
     *
     * @param face   the face
     * @param bold   bold weight
     * @param italic slanted
     * @param pt     point size
     * @param text   the cluster
     * @return the shaped glyphs, origin at the left of the baseline
     */
    public GlyphVector shape(Face face, boolean bold, boolean italic, double pt, String text) {
        char[] chars = text.toCharArray();
        return font(face, bold, italic, pt).layoutGlyphVector(
                FRC, chars, 0, chars.length, Font.LAYOUT_LEFT_TO_RIGHT);
    }

    /* =====================================================================
     * LAYOUT
     * ===================================================================== */

    /**
     * Places the clusters of some styled text along a row.
     *
     * @param runs the text, in styled pieces
     * @return the cells, left to right, starting at x = 0
     */
    public List<Cell> layout(List<PrintModel.Run> runs) {
        List<Cell> cells = new ArrayList<>();
        double x = 0;
        for (PrintModel.Run run : runs) {
            double scale = PrintPalette.sizeScale(run.classes());
            boolean bold = PrintPalette.bold(run.classes());
            for (String cluster : clusters(run.text())) {
                Face face = faceFor(cluster);
                String text = face == null ? MISSING : cluster;
                Face drawn = face == null ? Face.MONO : face;
                double w = drawn == Face.MONO
                        ? cell
                        : advance(drawn, bold, size * scale, text);
                cells.add(new Cell(text, run.classes(), drawn, x, w));
                x += w;
            }
        }
        return cells;
    }

    /**
     * Places plain, unstyled text -- a header, a footer, a line number.
     *
     * @param text the text
     * @return the cells
     */
    public List<Cell> layoutPlain(String text) {
        return layout(List.of(new PrintModel.Run(text, Collections.emptyList())));
    }

    /**
     * @param cells laid-out cells
     * @return the total width they take
     */
    public static double width(List<Cell> cells) {
        if (cells.isEmpty()) {
            return 0;
        }
        Cell last = cells.get(cells.size() - 1);
        return last.x() + last.width();
    }

    private double advance(Face face, boolean bold, double pt, String text) {
        String key = face + ":" + bold + ":" + pt + ":" + text;
        Double w = widths.get(key);
        if (w == null) {
            GlyphVector gv = shape(face, bold, false, pt, text);
            w = gv.getGlyphPosition(gv.getNumGlyphs()).getX();
            widths.put(key, w);
        }
        return w;
    }

    /**
     * The first face that can draw every visible character of a cluster.
     *
     * @param cluster the cluster
     * @return the face, or null when no bundled face can draw it
     */
    Face faceFor(String cluster) {
        for (Face f : Face.values()) {
            if (canDraw(probe.get(f), cluster)) {
                return f;
            }
        }
        return null;
    }

    private static boolean canDraw(Font font, String text) {
        for (int i = 0; i < text.length();) {
            int cp = text.codePointAt(i);
            i += Character.charCount(cp);
            if (isInvisibleJoiner(cp)) {
                continue; // shaping consumes them; no glyph is needed
            }
            if (!font.canDisplay(cp)) {
                return false;
            }
        }
        return true;
    }

    /* =====================================================================
     * CLUSTERS
     * ===================================================================== */

    /**
     * Cuts text into clusters: a base character, every combining mark after
     * it, and -- across a virama -- the consonant it joins.
     *
     * @param text the text
     * @return the clusters, in order; together they are exactly {@code text}
     */
    static List<String> clusters(String text) {
        List<String> out = new ArrayList<>();
        int i = 0;
        int n = text.length();
        while (i < n) {
            int start = i;
            int cp = text.codePointAt(i);
            i += Character.charCount(cp);
            boolean joinNext = false;
            while (i < n) {
                int next = text.codePointAt(i);
                if (isMark(next) || isInvisibleJoiner(next)) {
                    joinNext = isVirama(next) || (joinNext && isInvisibleJoiner(next));
                    i += Character.charCount(next);
                } else if (joinNext && Character.isLetter(next)) {
                    // the consonant after a virama belongs to the conjunct
                    joinNext = false;
                    i += Character.charCount(next);
                } else {
                    break;
                }
            }
            out.add(text.substring(start, i));
        }
        return out;
    }

    private static boolean isMark(int cp) {
        int t = Character.getType(cp);
        return t == Character.NON_SPACING_MARK
                || t == Character.COMBINING_SPACING_MARK
                || t == Character.ENCLOSING_MARK;
    }

    private static boolean isInvisibleJoiner(int cp) {
        return cp == 0x200C || cp == 0x200D;
    }

    /** The virama (pulli, halant) of each Indic script Astra uses. */
    private static boolean isVirama(int cp) {
        return cp == 0x094D // Devanagari
                || cp == 0x0BCD // Tamil
                || cp == 0x0C4D // Telugu
                || cp == 0x0CCD // Kannada
                || cp == 0x0D4D; // Malayalam
    }
}
