package ui.ui_functions.tools.print;

import java.util.ArrayList;
import java.util.List;

/**
 * Turns logical lines into pages of visual rows.
 *
 * <h3>Why this is shared between paper and PDF</h3>
 * <p>
 * If each backend did its own wrapping, the paper copy and the PDF would
 * break lines in different places and eventually differ by a page. Pagination
 * is therefore done once, here, from the widths {@link PrintFonts} measures in
 * the bundled fonts, and both renderers draw the result as it stands.
 * </p>
 *
 * <h3>Widths, not character counts</h3>
 * <p>
 * Ordinary code still sits on a fixed cell grid: a mono cluster always takes
 * one cell. Indic clusters take their natural shaped width, so a row is
 * filled by width and wrapped when the next cluster would cross the right
 * margin. A cluster is never split: {@code கொ} or {@code क्ष} moves to the next
 * row whole.
 * </p>
 *
 * <h3>Continuation rows</h3>
 * <p>
 * A wrapped row carries {@code number == CONTINUATION} so the renderer knows
 * to leave the gutter blank, the way an editor does. The alternative -- a
 * repeated line number -- makes a printout impossible to cite from.
 * </p>
 */
public final class PrintPaginator {

    /** Line number on a wrapped continuation row. */
    public static final int CONTINUATION = -1;

    private PrintPaginator() {
    }

    /**
     * One visual row on a page.
     *
     * @param number the source line number, or {@link #CONTINUATION}
     * @param cells  the row's clusters, x measured from the row's left edge
     */
    public record Row(int number, List<PrintFonts.Cell> cells) {
    }

    /**
     * One page.
     *
     * @param index zero-based page index
     * @param rows  the rows to draw, top to bottom
     */
    public record Page(int index, List<Row> rows) {
    }

    /**
     * Splits a document into pages.
     *
     * @param doc         the document
     * @param fonts       the fonts at the code size
     * @param rowWidth    points available between the gutter and the right
     *                    margin; at least one cluster is placed per row
     *                    whatever this is
     * @param rowsPerPage how many rows fit between the header and footer;
     *                    values below 1 are clamped
     * @return the pages, never empty -- an empty document yields one blank
     *         page, because a printer job with zero pages is an error
     */
    public static List<Page> paginate(PrintModel.Document doc, PrintFonts fonts,
            double rowWidth, int rowsPerPage) {
        int rowsMax = Math.max(1, rowsPerPage);

        List<Row> all = new ArrayList<>();
        for (PrintModel.Line line : doc.lines()) {
            all.addAll(wrap(line, fonts, rowWidth));
        }

        List<Page> pages = new ArrayList<>();
        for (int i = 0; i < all.size(); i += rowsMax) {
            pages.add(new Page(pages.size(),
                    new ArrayList<>(all.subList(i, Math.min(i + rowsMax, all.size())))));
        }
        if (pages.isEmpty()) {
            pages.add(new Page(0, List.of()));
        }
        return pages;
    }

    /**
     * Breaks one logical line into as many rows as it needs.
     *
     * <p>
     * The break is hard, at the margin, with no attempt to find a word
     * boundary. That is deliberate for code: breaking
     * {@code publish("a long string")} at a space would silently change where
     * the reader thinks the string ends.
     * </p>
     *
     * @param line     the logical line
     * @param fonts    the fonts
     * @param rowWidth the width available
     * @return one or more rows
     */
    private static List<Row> wrap(PrintModel.Line line, PrintFonts fonts, double rowWidth) {
        List<Row> rows = new ArrayList<>();
        List<PrintFonts.Cell> pending = new ArrayList<>();
        double used = 0;
        boolean first = true;
        // A hair of slack so a row of exactly N cells is not wrapped by rounding.
        double limit = rowWidth + 1e-6;

        for (PrintFonts.Cell c : fonts.layout(line.runs())) {
            if (!pending.isEmpty() && used + c.width() > limit) {
                rows.add(new Row(first ? line.number() : CONTINUATION, pending));
                first = false;
                pending = new ArrayList<>();
                used = 0;
            }
            pending.add(new PrintFonts.Cell(c.text(), c.classes(), c.face(), used, c.width()));
            used += c.width();
        }

        // Always emit the last row, including for a genuinely empty line --
        // a blank line in the source is a blank line in the printout.
        rows.add(new Row(first ? line.number() : CONTINUATION, pending));
        return rows;
    }
}
