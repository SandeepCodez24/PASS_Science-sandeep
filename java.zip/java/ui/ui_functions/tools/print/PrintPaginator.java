package ui.ui_functions.tools.print;

import java.util.ArrayList;
import java.util.List;

/**
 * Turns logical lines into pages of visual rows.
 *
 * <h3>Why this is shared between paper and PDF</h3>
 * <p>
 * AWT measures text with {@code FontMetrics} and PDFBox with
 * {@code PDFont.getStringWidth}. The two disagree in the last decimal, and if
 * each backend did its own wrapping the paper copy and the PDF would break
 * lines in different places and eventually differ by a page. Pagination is
 * therefore done once, here, and both renderers consume the result.
 * </p>
 *
 * <h3>The monospace assumption</h3>
 * <p>
 * Wrapping is counted in <b>characters</b>, not measured widths: the code font
 * is monospaced, so a column is a column. Every renderer advances a fixed cell
 * per character, which is also why a sub- or superscript run -- drawn smaller
 * -- still occupies a whole cell. The one place this is an approximation is a
 * script whose glyphs are not one cell wide; such a line may overhang its
 * right margin slightly rather than wrapping early, which is the failure
 * everyone prefers in a code listing.
 * </p>
 *
 * <h3>Continuation rows</h3>
 * <p>
 * A wrapped row carries {@code number == CONTINUATION} so the renderer knows
 * to leave the gutter blank, the way an editor does. The alternative -- a
 * repeated line number -- makes a printout impossible to cite from.
 * </p>
 */
public final class PrintPaginator {

    /** Line number on a wrapped continuation row. */
    public static final int CONTINUATION = -1;

    private PrintPaginator() {
    }

    /**
     * One visual row on a page.
     *
     * @param number the source line number, or {@link #CONTINUATION}
     * @param runs   the row's styled pieces
     */
    public record Row(int number, List<PrintModel.Run> runs) {
    }

    /**
     * One page.
     *
     * @param index zero-based page index
     * @param rows  the rows to draw, top to bottom
     */
    public record Page(int index, List<Row> rows) {
    }

    /**
     * Splits a document into pages.
     *
     * @param doc          the document
     * @param charsPerRow  how many characters fit between the gutter and the
     *                     right margin; values below 1 are clamped
     * @param rowsPerPage  how many rows fit between the header and footer;
     *                     values below 1 are clamped
     * @return the pages, never empty -- an empty document yields one blank
     *         page, because a printer job with zero pages is an error
     */
    public static List<Page> paginate(PrintModel.Document doc, int charsPerRow, int rowsPerPage) {
        int cols = Math.max(1, charsPerRow);
        int rowsMax = Math.max(1, rowsPerPage);

        List<Row> all = new ArrayList<>();
        for (PrintModel.Line line : doc.lines()) {
            all.addAll(wrap(line, cols));
        }

        List<Page> pages = new ArrayList<>();
        for (int i = 0; i < all.size(); i += rowsMax) {
            pages.add(new Page(pages.size(),
                    new ArrayList<>(all.subList(i, Math.min(i + rowsMax, all.size())))));
        }
        if (pages.isEmpty()) {
            pages.add(new Page(0, List.of()));
        }
        return pages;
    }

    /**
     * Breaks one logical line into as many rows as it needs.
     *
     * <p>
     * The break is hard, at the column, with no attempt to find a word
     * boundary. That is deliberate for code: breaking
     * {@code publish("a long string")} at a space would silently change where
     * the reader thinks the string ends.
     * </p>
     *
     * @param line the logical line
     * @param cols the wrap column
     * @return one or more rows
     */
    private static List<Row> wrap(PrintModel.Line line, int cols) {
        List<Row> rows = new ArrayList<>();

        List<PrintModel.Run> pending = new ArrayList<>();
        int used = 0;
        boolean first = true;

        for (PrintModel.Run run : line.runs()) {
            String text = run.text();
            int from = 0;
            while (from < text.length()) {
                int room = cols - used;
                if (room <= 0) {
                    rows.add(new Row(first ? line.number() : CONTINUATION, pending));
                    first = false;
                    pending = new ArrayList<>();
                    used = 0;
                    room = cols;
                }
                int take = Math.min(room, text.length() - from);
                pending.add(new PrintModel.Run(text.substring(from, from + take), run.classes()));
                used += take;
                from += take;
            }
        }

        // Always emit the last row, including for a genuinely empty line --
        // a blank line in the source is a blank line in the printout.
        rows.add(new Row(first ? line.number() : CONTINUATION, pending));
        return rows;
    }
}
