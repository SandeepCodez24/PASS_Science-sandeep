package ui.ui_functions.tools.print;

import java.awt.Color;
import java.awt.Shape;
import java.awt.font.GlyphVector;
import java.awt.geom.AffineTransform;
import java.awt.geom.PathIterator;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType0Font;
import org.apache.pdfbox.pdmodel.graphics.state.RenderingMode;
import org.apache.pdfbox.util.Matrix;

/**
 * Writes a {@link PrintModel.Document} out as a PDF.
 *
 * <h3>Why a PDF library rather than the OS "Print to PDF" printer</h3>
 * <p>
 * Routing through the printer would give a raster-free PDF too, but the save
 * dialog would belong to the printer driver, there would be nowhere to offer a
 * dark variant, and the result would carry the printer's page setup rather
 * than ours. Writing the file directly keeps all three decisions on our side.
 * </p>
 *
 * <h3>Fonts</h3>
 * <p>
 * Only the Noto fonts bundled in the jar are used (see {@link PrintFonts});
 * nothing is read from the operating system, so the PDF is the same on every
 * machine. Each face is embedded as a subset, so the file carries only the
 * glyphs it uses.
 * </p>
 *
 * <h3>Two ways a cluster reaches the page</h3>
 * <ul>
 * <li><b>Mono clusters</b> (Latin, Greek, digits, punctuation) are written as
 * ordinary PDF text, one cell per character, so they stay selectable and
 * searchable exactly as before.</li>
 * <li><b>Shaped clusters</b> (Tamil, Sanskrit, Telugu, Malayalam, Kannada,
 * maths symbols) are shaped by Java2D and drawn as their glyph outlines.
 * PDFBox writes text glyph by glyph in character order and does no OpenType
 * shaping, so written as text a Tamil {@code சோ} would come out as
 * {@code ச} with two detached vowel strokes in the wrong place. Outlines are
 * the shaped glyphs themselves, vector and sharp at any zoom. Under each one
 * the same cluster is also written as <i>invisible</i> text, so selecting,
 * copying and searching the PDF still find {@code சோழ}.</li>
 * </ul>
 * <p>
 * Nothing is ever replaced by a question mark unless no bundled font has the
 * character at all.
 * </p>
 */
public final class PdfExporter {

    /** Row pitch as a multiple of the point size; matches CodePrintable. */
    private static final double LINE_FACTOR = 1.35;

    /** Header, footer and line numbers, relative to the code size. */
    private static final float FURNITURE_SCALE = 0.85f;

    /**
     * FontBox warns on every load of Noto Sans Mono that it ignores the
     * font's format-14 cmap (variation selectors). Nothing printed uses them,
     * so the warning is noise. A strong reference keeps the level from being
     * garbage-collected along with the logger.
     */
    private static final java.util.logging.Logger CMAP_LOG =
            java.util.logging.Logger.getLogger("org.apache.fontbox.ttf.CmapSubtable");

    static {
        CMAP_LOG.setLevel(java.util.logging.Level.SEVERE);
    }

    private static final double MARGIN = 40;
    private static final double GUTTER_GAP = 6;
    private static final double HEADER_GAP = 6;

    private PdfExporter() {
    }

    /**
     * Writes the document to a file.
     *
     * @param doc      the document
     * @param settings the chosen options
     * @param target   the file to create or overwrite
     * @throws IOException if the file cannot be written
     */
    public static void export(PrintModel.Document doc, PrintSettings settings, File target)
            throws IOException {

        try (PDDocument pdf = new PDDocument()) {
            pdf.getDocumentInformation().setTitle(doc.title());
            pdf.getDocumentInformation().setCreator("Neural Code");

            float size = settings.fontSize();
            PrintFonts code = new PrintFonts(size);
            PrintFonts furniture = new PrintFonts(size * FURNITURE_SCALE);
            Embedded embedded = new Embedded(pdf);

            double cell = code.cell();
            double rowHeight = size * LINE_FACTOR;
            double headerHeight = settings.header() ? size * 2.0 : 0;
            double footerHeight = settings.footer() ? size * 2.0 : 0;

            PDRectangle paper = PDRectangle.A4;
            double usableWidth = paper.getWidth() - MARGIN * 2;
            double usableHeight = paper.getHeight() - MARGIN * 2;

            int digits = Math.max(3, String.valueOf(Math.max(1, doc.lines().size())).length());
            double gutterWidth = settings.lineNumbers() ? digits * cell + GUTTER_GAP * 2 : 0;

            double rowWidth = usableWidth - gutterWidth;
            int rows = (int) Math.floor(
                    (usableHeight - headerHeight - footerHeight - HEADER_GAP) / rowHeight);

            List<PrintPaginator.Page> pages = PrintPaginator.paginate(doc, code, rowWidth, rows);

            Layout layout = new Layout(code, furniture, embedded, settings, paper,
                    rowHeight, gutterWidth, headerHeight);

            for (PrintPaginator.Page page : pages) {
                PDPage pdPage = new PDPage(paper);
                pdf.addPage(pdPage);
                try (PDPageContentStream cs = new PDPageContentStream(pdf, pdPage)) {
                    drawPage(cs, doc, layout, page, pages.size());
                }
            }

            pdf.save(target);
        }
    }

    /** What every page needs, gathered once. */
    private record Layout(PrintFonts code, PrintFonts furniture, Embedded embedded,
            PrintSettings settings, PDRectangle paper, double rowHeight,
            double gutterWidth, double headerHeight) {
    }

    /* =====================================================================
     * PAGE DRAWING
     * ===================================================================== */

    private static void drawPage(PDPageContentStream cs,
            PrintModel.Document doc,
            Layout l,
            PrintPaginator.Page page,
            int pageCount) throws IOException {

        PrintSettings settings = l.settings();
        PrintSettings.Theme theme = settings.theme();
        float size = settings.fontSize();
        PDRectangle paper = l.paper();
        // PDF's origin is bottom-left, so every y below is measured down from
        // the top and then subtracted.
        double top = paper.getHeight() - MARGIN;

        if (settings.paintsPageBackground()) {
            setFill(cs, PrintPalette.page(theme));
            cs.addRect(0, 0, paper.getWidth(), paper.getHeight());
            cs.fill();
        }

        double y = top;

        if (settings.header()) {
            drawCells(cs, l.furniture(), l.embedded(), l.furniture().layoutPlain(doc.headerText()),
                    MARGIN, y - size, PrintPalette.furniture(theme), theme);
            setStroke(cs, PrintPalette.rule(theme));
            cs.setLineWidth(0.5f);
            float ruleY = (float) (y - l.headerHeight() + size * 0.4);
            cs.moveTo((float) MARGIN, ruleY);
            cs.lineTo((float) (paper.getWidth() - MARGIN), ruleY);
            cs.stroke();
            y -= l.headerHeight();
        }
        y -= HEADER_GAP;

        if (settings.lineNumbers() && l.gutterWidth() > 0) {
            setFill(cs, PrintPalette.gutter(theme));
            cs.addRect((float) MARGIN,
                    (float) (y - page.rows().size() * l.rowHeight()),
                    (float) l.gutterWidth(),
                    (float) (page.rows().size() * l.rowHeight()));
            cs.fill();
        }

        double codeX = MARGIN + l.gutterWidth();
        double rowTop = y;

        for (PrintPaginator.Row row : page.rows()) {
            double baseline = rowTop - size;

            if (settings.lineNumbers() && row.number() != PrintPaginator.CONTINUATION) {
                List<PrintFonts.Cell> label = l.furniture().layoutPlain(String.valueOf(row.number()));
                // Right-aligned inside the gutter, as a gutter should be.
                double lx = MARGIN + l.gutterWidth() - GUTTER_GAP - PrintFonts.width(label);
                drawCells(cs, l.furniture(), l.embedded(), label, lx, baseline,
                        PrintPalette.lineNumber(theme), theme);
            }

            drawCells(cs, l.code(), l.embedded(), row.cells(), codeX, baseline, null, theme);
            rowTop -= l.rowHeight();
        }

        if (settings.footer()) {
            List<PrintFonts.Cell> label = l.furniture()
                    .layoutPlain("Page " + (page.index() + 1) + " of " + pageCount);
            drawCells(cs, l.furniture(), l.embedded(), label,
                    paper.getWidth() - MARGIN - PrintFonts.width(label), MARGIN * 0.5,
                    PrintPalette.furniture(theme), theme);
        }
    }

    /**
     * Draws a row of laid-out cells.
     *
     * @param plainInk null to colour each cell from its syntax classes; a
     *                 colour to draw everything plain in that colour (header,
     *                 footer, line numbers)
     */
    private static void drawCells(PDPageContentStream cs, PrintFonts fonts, Embedded embedded,
            List<PrintFonts.Cell> cells, double originX, double baseline,
            Color plainInk, PrintSettings.Theme theme) throws IOException {

        float size = fonts.size();
        Color current = null;

        int i = 0;
        while (i < cells.size()) {
            PrintFonts.Cell c = cells.get(i);
            Collection<String> classes = c.classes();
            boolean plain = plainInk != null;
            boolean bold = !plain && PrintPalette.bold(classes);
            boolean italic = !plain && PrintPalette.italic(classes);
            double scale = PrintPalette.sizeScale(classes);
            // Subscripts move DOWN the page, which is negative in PDF space.
            double y = baseline - PrintPalette.baselineShift(classes) * size;

            Color ink = plain ? plainInk : PrintPalette.ink(classes, theme);
            if (!ink.equals(current)) {
                setFill(cs, ink);
                current = ink;
            }

            if (!c.shaped()) {
                // Gather the mono cells that share this style and sit side by
                // side; at full size each advances exactly one cell, so they
                // go out as one string, which also reads better when the PDF
                // is searched or copied.
                StringBuilder text = new StringBuilder(c.text());
                int j = i + 1;
                if (scale == 1.0) {
                    while (j < cells.size()) {
                        PrintFonts.Cell n = cells.get(j);
                        if (n.shaped() || !n.classes().equals(classes)) {
                            break;
                        }
                        text.append(n.text());
                        j++;
                    }
                }
                showText(cs, embedded.font(PrintFonts.Face.MONO, bold), (float) (size * scale),
                        originX + c.x(), y, italic, text.toString(), RenderingMode.FILL);
                i = j;
                continue;
            }

            double pt = size * scale;
            GlyphVector gv = fonts.shape(c.face(), bold, italic, pt, c.text());
            fillOutline(cs, gv.getOutline(), originX + c.x(), y);
            // The same cluster as invisible text, for search and copy.
            showText(cs, embedded.font(c.face(), bold), (float) pt,
                    originX + c.x(), y, false, c.text(), RenderingMode.NEITHER);
            i++;
        }
    }

    /* =====================================================================
     * LOW LEVEL
     * ===================================================================== */

    /**
     * Writes text. Invisible text that the font cannot encode (a joiner with
     * no glyph, say) is simply left out: it only serves search and copy.
     */
    private static void showText(PDPageContentStream cs, PDFont font, float size,
            double x, double y, boolean italic, String s, RenderingMode mode) throws IOException {
        if (s.isEmpty()) {
            return;
        }
        String safe = mode == RenderingMode.NEITHER ? encodable(font, s) : s;
        if (safe.isEmpty()) {
            return;
        }
        cs.beginText();
        if (mode != RenderingMode.FILL) {
            cs.setRenderingMode(mode);
        }
        cs.setFont(font, size);
        if (italic) {
            cs.setTextMatrix(new Matrix(1, 0, (float) PrintFonts.ITALIC_SLANT, 1, (float) x, (float) y));
        } else {
            cs.newLineAtOffset((float) x, (float) y);
        }
        try {
            cs.showText(safe);
        } catch (IllegalArgumentException e) {
            // A character the embedded font cannot encode; PrintFonts chose
            // this face because it can, so this is a last-ditch guard only.
        }
        if (mode != RenderingMode.FILL) {
            cs.setRenderingMode(RenderingMode.FILL);
        }
        cs.endText();
    }

    private static String encodable(PDFont font, String s) {
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length();) {
            int cp = s.codePointAt(i);
            String one = new String(Character.toChars(cp));
            i += Character.charCount(cp);
            try {
                font.encode(one);
                sb.append(one);
            } catch (IOException | IllegalArgumentException e) {
                // left out of the invisible layer
            }
        }
        return sb.toString();
    }

    /**
     * Fills a glyph outline. Java2D's y axis points down and PDF's up, so the
     * outline is flipped about the baseline on the way.
     */
    private static void fillOutline(PDPageContentStream cs, Shape outline, double x, double y)
            throws IOException {
        AffineTransform toPage = new AffineTransform(1, 0, 0, -1, x, y);
        PathIterator it = outline.getPathIterator(toPage);
        float[] p = new float[6];
        float cx = 0;
        float cy = 0;
        boolean any = false;
        while (!it.isDone()) {
            switch (it.currentSegment(p)) {
                case PathIterator.SEG_MOVETO -> {
                    cs.moveTo(p[0], p[1]);
                    cx = p[0];
                    cy = p[1];
                    any = true;
                }
                case PathIterator.SEG_LINETO -> {
                    cs.lineTo(p[0], p[1]);
                    cx = p[0];
                    cy = p[1];
                }
                case PathIterator.SEG_QUADTO -> {
                    // PDF has cubic curves only; a quadratic is an exact cubic.
                    float c1x = cx + 2f / 3f * (p[0] - cx);
                    float c1y = cy + 2f / 3f * (p[1] - cy);
                    float c2x = p[2] + 2f / 3f * (p[0] - p[2]);
                    float c2y = p[3] + 2f / 3f * (p[1] - p[3]);
                    cs.curveTo(c1x, c1y, c2x, c2y, p[2], p[3]);
                    cx = p[2];
                    cy = p[3];
                }
                case PathIterator.SEG_CUBICTO -> {
                    cs.curveTo(p[0], p[1], p[2], p[3], p[4], p[5]);
                    cx = p[4];
                    cy = p[5];
                }
                case PathIterator.SEG_CLOSE -> cs.closePath();
                default -> {
                    // no other segment types exist
                }
            }
            it.next();
        }
        if (any) {
            if (it.getWindingRule() == PathIterator.WIND_EVEN_ODD) {
                cs.fillEvenOdd();
            } else {
                cs.fill();
            }
        }
    }

    /**
     * The float overload is used rather than the {@code java.awt.Color} one:
     * that overload was removed in PDFBox 3, and the float form works on both
     * 2.x and 3.x.
     */
    private static void setFill(PDPageContentStream cs, Color c) throws IOException {
        cs.setNonStrokingColor(c.getRed() / 255f, c.getGreen() / 255f, c.getBlue() / 255f);
    }

    private static void setStroke(PDPageContentStream cs, Color c) throws IOException {
        cs.setStrokingColor(c.getRed() / 255f, c.getGreen() / 255f, c.getBlue() / 255f);
    }

    /* =====================================================================
     * EMBEDDED FONTS
     * ===================================================================== */

    /** The bundled faces as PDF fonts, embedded on first use only. */
    private static final class Embedded {
        private final PDDocument pdf;
        private final Map<PrintFonts.Face, PDFont> regular = new EnumMap<>(PrintFonts.Face.class);
        private final Map<PrintFonts.Face, PDFont> bold = new EnumMap<>(PrintFonts.Face.class);

        Embedded(PDDocument pdf) {
            this.pdf = pdf;
        }

        PDFont font(PrintFonts.Face face, boolean wantBold) throws IOException {
            boolean b = wantBold && face.hasBold();
            Map<PrintFonts.Face, PDFont> cache = b ? bold : regular;
            PDFont f = cache.get(face);
            if (f == null) {
                f = PDType0Font.load(pdf,
                        new ByteArrayInputStream(PrintFonts.fontFile(face, b)), true);
                cache.put(face, f);
            }
            return f;
        }
    }
}
