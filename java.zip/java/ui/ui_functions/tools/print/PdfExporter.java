package ui.ui_functions.tools.print;

import java.awt.Color;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType0Font;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;

/**
 * Writes a {@link PrintModel.Document} out as a PDF.
 *
 * <h3>Why a PDF library rather than the OS "Print to PDF" printer</h3>
 * <p>
 * Routing through the printer would give a raster-free PDF too, but the save
 * dialog would belong to the printer driver, there would be nowhere to offer a
 * dark variant, and the result would carry the printer's page setup rather
 * than ours. Writing the file directly keeps all three decisions on our side,
 * and the text stays selectable and searchable.
 * </p>
 *
 * <h3>Fonts, and the one thing that can still go wrong</h3>
 * <p>
 * The project bundles no font, so this class embeds Consolas from the Windows
 * font directory when it is there -- which matches the editor exactly -- and
 * falls back to the PDF standard Courier when it is not.
 * </p>
 * <p>
 * <b>Neither covers Indic scripts.</b> Consolas has Latin, Greek and Cyrillic;
 * standard Courier is WinAnsi and has barely more than Latin-1. A Neural Code
 * file using Tamil, Devanagari, Kannada or Telugu identifiers would make
 * PDFBox throw the moment it met one. Rather than lose the whole export to a
 * single character, {@link #encodable} tests each one and substitutes a
 * question mark for anything the font cannot represent. Bundle a wide font --
 * Noto Sans Mono is the obvious candidate -- and point
 * {@link #EMBEDDED_FONT_RESOURCE} at it to make the substitution stop
 * happening.
 * </p>
 */
public final class PdfExporter {

    /**
     * Classpath location of a bundled monospace TTF, checked before the system
     * font. Nothing lives here yet; drop a font in and it is picked up.
     */
    private static final String EMBEDDED_FONT_RESOURCE = "/fonts/NotoSansMono-Regular.ttf";

    private static final String WINDOWS_FONTS = "C:\\Windows\\Fonts\\";

    /** Row pitch as a multiple of the point size; matches CodePrintable. */
    private static final double LINE_FACTOR = 1.35;

    private static final double MARGIN = 40;
    private static final double GUTTER_GAP = 6;
    private static final double HEADER_GAP = 6;

    private PdfExporter() {
    }

    /**
     * Writes the document to a file.
     *
     * @param doc      the document
     * @param settings the chosen options
     * @param target   the file to create or overwrite
     * @throws IOException if the file cannot be written
     */
    public static void export(PrintModel.Document doc, PrintSettings settings, File target)
            throws IOException {

        try (PDDocument pdf = new PDDocument()) {
            pdf.getDocumentInformation().setTitle(doc.title());
            pdf.getDocumentInformation().setCreator("Neural Code");

            Fonts fonts = Fonts.load(pdf);
            float size = settings.fontSize();

            double cell = fonts.regular.getStringWidth("M") / 1000f * size;
            double rowHeight = size * LINE_FACTOR;
            double headerHeight = settings.header() ? size * 2.0 : 0;
            double footerHeight = settings.footer() ? size * 2.0 : 0;

            PDRectangle paper = PDRectangle.A4;
            double usableWidth = paper.getWidth() - MARGIN * 2;
            double usableHeight = paper.getHeight() - MARGIN * 2;

            int digits = Math.max(3, String.valueOf(Math.max(1, doc.lines().size())).length());
            double gutterWidth = settings.lineNumbers() ? digits * cell + GUTTER_GAP * 2 : 0;

            int cols = (int) Math.floor((usableWidth - gutterWidth) / cell);
            int rows = (int) Math.floor(
                    (usableHeight - headerHeight - footerHeight - HEADER_GAP) / rowHeight);

            List<PrintPaginator.Page> pages = PrintPaginator.paginate(doc, cols, rows);

            for (PrintPaginator.Page page : pages) {
                PDPage pdPage = new PDPage(paper);
                pdf.addPage(pdPage);
                try (PDPageContentStream cs = new PDPageContentStream(pdf, pdPage)) {
                    drawPage(cs, doc, settings, fonts, page, pages.size(), paper,
                            cell, rowHeight, gutterWidth, headerHeight, footerHeight);
                }
            }

            pdf.save(target);
        }
    }

    /* =====================================================================
     * PAGE DRAWING
     * ===================================================================== */

    private static void drawPage(PDPageContentStream cs,
            PrintModel.Document doc,
            PrintSettings settings,
            Fonts fonts,
            PrintPaginator.Page page,
            int pageCount,
            PDRectangle paper,
            double cell,
            double rowHeight,
            double gutterWidth,
            double headerHeight,
            double footerHeight) throws IOException {

        float size = settings.fontSize();
        // PDF's origin is bottom-left, so every y below is measured down from
        // the top and then subtracted. Getting this backwards is the classic
        // first-PDF bug: the listing renders upside down the page.
        double top = paper.getHeight() - MARGIN;

        if (settings.paintsPageBackground()) {
            setFill(cs, PrintPalette.page(settings.theme()));
            cs.addRect(0, 0, paper.getWidth(), paper.getHeight());
            cs.fill();
        }

        double y = top;

        if (settings.header()) {
            setFill(cs, PrintPalette.furniture(settings.theme()));
            text(cs, fonts.regular, size * 0.85f, MARGIN, y - size, doc.headerText(), fonts);
            setStroke(cs, PrintPalette.rule(settings.theme()));
            cs.setLineWidth(0.5f);
            cs.moveTo((float) MARGIN, (float) (y - headerHeight + size * 0.4));
            cs.lineTo((float) (paper.getWidth() - MARGIN), (float) (y - headerHeight + size * 0.4));
            cs.stroke();
            y -= headerHeight;
        }
        y -= HEADER_GAP;

        if (settings.lineNumbers() && gutterWidth > 0) {
            setFill(cs, PrintPalette.gutter(settings.theme()));
            cs.addRect((float) MARGIN,
                    (float) (y - page.rows().size() * rowHeight),
                    (float) gutterWidth,
                    (float) (page.rows().size() * rowHeight));
            cs.fill();
        }

        double codeX = MARGIN + gutterWidth;
        double rowTop = y;

        for (PrintPaginator.Row row : page.rows()) {
            double baseline = rowTop - size;

            if (settings.lineNumbers() && row.number() != PrintPaginator.CONTINUATION) {
                String label = String.valueOf(row.number());
                setFill(cs, PrintPalette.lineNumber(settings.theme()));
                double lx = MARGIN + gutterWidth - GUTTER_GAP - label.length() * cell * 0.85;
                text(cs, fonts.regular, size * 0.85f, lx, baseline, label, fonts);
            }

            double x = codeX;
            for (PrintModel.Run run : row.runs()) {
                double scale = PrintPalette.sizeScale(run.classes());
                // Subscripts move DOWN the page, which is negative in PDF space.
                double shift = -PrintPalette.baselineShift(run.classes()) * size;

                PDFont font = fonts.pick(
                        PrintPalette.bold(run.classes()), PrintPalette.italic(run.classes()));
                setFill(cs, PrintPalette.ink(run.classes(), settings.theme()));

                String txt = run.text();
                for (int i = 0; i < txt.length(); i++) {
                    text(cs, font, (float) (size * scale),
                            x + i * cell, baseline + shift,
                            String.valueOf(txt.charAt(i)), fonts);
                }
                x += txt.length() * cell;
            }
            rowTop -= rowHeight;
        }

        if (settings.footer()) {
            String label = "Page " + (page.index() + 1) + " of " + pageCount;
            double w = fonts.regular.getStringWidth(label) / 1000f * (size * 0.85f);
            setFill(cs, PrintPalette.furniture(settings.theme()));
            text(cs, fonts.regular, size * 0.85f,
                    paper.getWidth() - MARGIN - w, MARGIN * 0.5, label, fonts);
        }
    }

    /* =====================================================================
     * LOW LEVEL
     * ===================================================================== */

    /**
     * Shows one piece of text, substituting anything the font cannot encode.
     */
    private static void text(PDPageContentStream cs, PDFont font, float size,
            double x, double y, String s, Fonts fonts) throws IOException {
        String safe = fonts.sanitize(font, s);
        if (safe.isEmpty()) {
            return;
        }
        cs.beginText();
        cs.setFont(font, size);
        cs.newLineAtOffset((float) x, (float) y);
        cs.showText(safe);
        cs.endText();
    }

    /**
     * The float overload is used rather than the {@code java.awt.Color} one:
     * that overload was removed in PDFBox 3, and the float form works on both
     * 2.x and 3.x.
     */
    private static void setFill(PDPageContentStream cs, Color c) throws IOException {
        cs.setNonStrokingColor(c.getRed() / 255f, c.getGreen() / 255f, c.getBlue() / 255f);
    }

    private static void setStroke(PDPageContentStream cs, Color c) throws IOException {
        cs.setStrokingColor(c.getRed() / 255f, c.getGreen() / 255f, c.getBlue() / 255f);
    }

    /* =====================================================================
     * FONTS
     * ===================================================================== */

    /** The four faces, plus the encodability cache. */
    private static final class Fonts {

        private final PDFont regular;
        private final PDFont bold;
        private final PDFont italic;
        private final PDFont boldItalic;
        private final Map<String, Boolean> encodable = new HashMap<>();

        private Fonts(PDFont regular, PDFont bold, PDFont italic, PDFont boldItalic) {
            this.regular = regular;
            this.bold = bold;
            this.italic = italic;
            this.boldItalic = boldItalic;
        }

        static Fonts load(PDDocument pdf) {
            PDFont r = tryLoad(pdf, EMBEDDED_FONT_RESOURCE, "consola.ttf");
            PDFont b = tryLoad(pdf, null, "consolab.ttf");
            PDFont i = tryLoad(pdf, null, "consolai.ttf");
            PDFont bi = tryLoad(pdf, null, "consolaz.ttf");

            if (r == null) {
                r = new PDType1Font(Standard14Fonts.FontName.COURIER);
            }
            if (b == null) {
                b = new PDType1Font(Standard14Fonts.FontName.COURIER_BOLD);
            }
            if (i == null) {
                i = new PDType1Font(Standard14Fonts.FontName.COURIER_OBLIQUE);
            }
            if (bi == null) {
                bi = new PDType1Font(Standard14Fonts.FontName.COURIER_BOLD_OBLIQUE);
            }
            return new Fonts(r, b, i, bi);
        }

        /**
         * Tries a bundled resource first, then a file in the Windows font
         * directory. Returns null rather than throwing, so a missing font
         * downgrades the output instead of failing the export.
         */
        private static PDFont tryLoad(PDDocument pdf, String resource, String windowsFile) {
            if (resource != null) {
                try (var in = PdfExporter.class.getResourceAsStream(resource)) {
                    if (in != null) {
                        return PDType0Font.load(pdf, in, true);
                    }
                } catch (IOException ignored) {
                    // fall through to the system font
                }
            }
            try {
                File f = new File(WINDOWS_FONTS + windowsFile);
                if (f.isFile()) {
                    return PDType0Font.load(pdf, f);
                }
            } catch (IOException ignored) {
                // fall through to Courier
            }
            return null;
        }

        PDFont pick(boolean b, boolean i) {
            if (b && i) {
                return boldItalic;
            }
            if (b) {
                return bold;
            }
            if (i) {
                return italic;
            }
            return regular;
        }

        /**
         * Replaces every character the font cannot encode with a question
         * mark. Results are cached per font-and-character, because a long
         * source file asks the same question thousands of times.
         */
        String sanitize(PDFont font, String s) {
            StringBuilder sb = new StringBuilder(s.length());
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                sb.append(canEncode(font, c) ? c : '?');
            }
            return sb.toString();
        }

        private boolean canEncode(PDFont font, char c) {
            String key = System.identityHashCode(font) + ":" + (int) c;
            Boolean cached = encodable.get(key);
            if (cached != null) {
                return cached;
            }
            boolean ok;
            try {
                font.getStringWidth(String.valueOf(c));
                ok = true;
            } catch (IOException | IllegalArgumentException e) {
                ok = false;
            }
            encodable.put(key, ok);
            return ok;
        }
    }
}
