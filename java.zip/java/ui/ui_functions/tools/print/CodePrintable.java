package ui.ui_functions.tools.print;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.font.FontRenderContext;
import java.awt.print.PageFormat;
import java.awt.print.Pageable;
import java.awt.print.Printable;
import java.util.List;

/**
 * Draws a {@link PrintModel.Document} onto paper.
 *
 * <h3>Printable and Pageable both</h3>
 * <p>
 * Implementing {@link Pageable} as well as {@link Printable} is what makes the
 * Windows print dialog's "Pages from / to" box work: without a page count the
 * dialog can only offer "All", and the job is asked for pages until it says
 * {@code NO_SUCH_PAGE}. Pagination has to happen before the dialog opens
 * anyway, so the count is free.
 * </p>
 *
 * <h3>Metrics without a Graphics</h3>
 * <p>
 * {@link Pageable#getNumberOfPages()} is called before any {@code Graphics}
 * exists, so the layout cannot measure through one. A standalone
 * {@link FontRenderContext} is used instead -- fine here, because the only
 * measurement that matters is the advance of a monospaced cell.
 * </p>
 */
public final class CodePrintable implements Printable, Pageable {

    /** Row pitch as a multiple of the point size. */
    private static final double LINE_FACTOR = 1.35;

    /** Gap in points between the gutter and the first code column. */
    private static final double GUTTER_GAP = 6;

    /** Gap in points between the header rule and the first row. */
    private static final double HEADER_GAP = 6;

    private final PrintModel.Document doc;
    private final PrintSettings settings;
    private final PageFormat format;

    private final Font regular;
    private final Font boldFont;
    private final Font italicFont;
    private final Font boldItalicFont;
    private final Font furnitureFont;

    private final double cellWidth;
    private final double rowHeight;
    private final double gutterWidth;
    private final double headerHeight;
    private final double footerHeight;

    private final List<PrintPaginator.Page> pages;

    /**
     * @param doc      the document to print
     * @param settings the chosen options
     * @param format   the page format the printer job handed us
     */
    public CodePrintable(PrintModel.Document doc, PrintSettings settings, PageFormat format) {
        this.doc = doc;
        this.settings = settings;
        this.format = format;

        float size = settings.fontSize();
        Font consolas = new Font("Consolas", Font.PLAIN, Math.round(size));
        // getFamily() comes back as "Dialog" when the name did not resolve, so
        // this is how we tell a real Consolas from a silent substitution.
        Font base = "Consolas".equalsIgnoreCase(consolas.getFamily())
                ? consolas
                : new Font(Font.MONOSPACED, Font.PLAIN, Math.round(size));

        this.regular = base;
        this.boldFont = base.deriveFont(Font.BOLD);
        this.italicFont = base.deriveFont(Font.ITALIC);
        this.boldItalicFont = base.deriveFont(Font.BOLD | Font.ITALIC);
        this.furnitureFont = base.deriveFont(size * 0.85f);

        FontRenderContext frc = new FontRenderContext(null, true, true);
        this.cellWidth = base.getStringBounds("M", frc).getWidth();
        this.rowHeight = Math.ceil(size * LINE_FACTOR);
        this.headerHeight = settings.header() ? size * 2.0 : 0;
        this.footerHeight = settings.footer() ? size * 2.0 : 0;

        int digits = Math.max(3, String.valueOf(Math.max(1, doc.lines().size())).length());
        this.gutterWidth = settings.lineNumbers() ? digits * cellWidth + GUTTER_GAP * 2 : 0;

        int cols = (int) Math.floor((format.getImageableWidth() - gutterWidth) / cellWidth);
        int rows = (int) Math.floor(
                (format.getImageableHeight() - headerHeight - footerHeight - HEADER_GAP) / rowHeight);

        this.pages = PrintPaginator.paginate(doc, cols, rows);
    }

    /* =====================================================================
     * Pageable
     * ===================================================================== */

    @Override
    public int getNumberOfPages() {
        return pages.size();
    }

    @Override
    public PageFormat getPageFormat(int pageIndex) {
        return format;
    }

    @Override
    public Printable getPrintable(int pageIndex) {
        return this;
    }

    /* =====================================================================
     * Printable
     * ===================================================================== */

    @Override
    public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) {
        if (pageIndex < 0 || pageIndex >= pages.size()) {
            return NO_SUCH_PAGE;
        }

        Graphics2D g = (Graphics2D) graphics;
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        double originX = pageFormat.getImageableX();
        double originY = pageFormat.getImageableY();
        double width = pageFormat.getImageableWidth();
        double height = pageFormat.getImageableHeight();

        if (settings.paintsPageBackground()) {
            // Only the imageable area: a printer will not put ink in the
            // hardware margin however hard we ask.
            g.setColor(PrintPalette.page(settings.theme()));
            g.fillRect((int) originX, (int) originY, (int) Math.ceil(width), (int) Math.ceil(height));
        }

        double y = originY;

        if (settings.header()) {
            g.setFont(furnitureFont);
            g.setColor(PrintPalette.furniture(settings.theme()));
            g.drawString(doc.headerText(), (float) originX, (float) (y + settings.fontSize()));
            g.setColor(PrintPalette.rule(settings.theme()));
            int ruleY = (int) (y + headerHeight - settings.fontSize() * 0.4);
            g.drawLine((int) originX, ruleY, (int) (originX + width), ruleY);
            y += headerHeight;
        }
        y += HEADER_GAP;

        PrintPaginator.Page page = pages.get(pageIndex);

        if (settings.lineNumbers() && gutterWidth > 0) {
            g.setColor(PrintPalette.gutter(settings.theme()));
            g.fillRect((int) originX, (int) y,
                    (int) Math.ceil(gutterWidth),
                    (int) Math.ceil(page.rows().size() * rowHeight));
        }

        double codeX = originX + gutterWidth;
        double rowY = y;

        for (PrintPaginator.Row row : page.rows()) {
            double baseline = rowY + settings.fontSize();

            if (settings.lineNumbers() && row.number() != PrintPaginator.CONTINUATION) {
                g.setFont(furnitureFont);
                g.setColor(PrintPalette.lineNumber(settings.theme()));
                String label = String.valueOf(row.number());
                // Right-aligned inside the gutter, as a gutter should be.
                double lx = originX + gutterWidth - GUTTER_GAP - label.length() * cellWidth * 0.85;
                g.drawString(label, (float) lx, (float) baseline);
            }

            double x = codeX;
            for (PrintModel.Run run : row.runs()) {
                double scale = PrintPalette.sizeScale(run.classes());
                double shift = PrintPalette.baselineShift(run.classes()) * settings.fontSize();

                Font f = fontFor(run);
                if (scale != 1.0) {
                    f = f.deriveFont((float) (settings.fontSize() * scale));
                }
                g.setFont(f);
                g.setColor(PrintPalette.ink(run.classes(), settings.theme()));

                // Drawn character by character so every glyph lands on its own
                // cell. Handing the whole run to drawString would let a glyph
                // that is not exactly one cell wide drag the rest of the line
                // out of the column grid.
                String text = run.text();
                for (int i = 0; i < text.length(); i++) {
                    g.drawString(String.valueOf(text.charAt(i)),
                            (float) (x + i * cellWidth), (float) (baseline + shift));
                }
                x += text.length() * cellWidth;
            }
            rowY += rowHeight;
        }

        if (settings.footer()) {
            g.setFont(furnitureFont);
            g.setColor(PrintPalette.furniture(settings.theme()));
            String label = "Page " + (pageIndex + 1) + " of " + pages.size();
            FontRenderContext frc = g.getFontRenderContext();
            double w = furnitureFont.getStringBounds(label, frc).getWidth();
            g.drawString(label,
                    (float) (originX + width - w),
                    (float) (originY + height - settings.fontSize() * 0.5));
        }

        return PAGE_EXISTS;
    }

    private Font fontFor(PrintModel.Run run) {
        boolean b = PrintPalette.bold(run.classes());
        boolean i = PrintPalette.italic(run.classes());
        if (b && i) {
            return boldItalicFont;
        }
        if (b) {
            return boldFont;
        }
        if (i) {
            return italicFont;
        }
        return regular;
    }

    /** @return the page count, for callers that want it without a cast */
    public int pageCount() {
        return pages.size();
    }
}
