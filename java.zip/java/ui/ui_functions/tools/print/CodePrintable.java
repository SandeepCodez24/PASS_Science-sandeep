package ui.ui_functions.tools.print;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.font.GlyphVector;
import java.awt.print.PageFormat;
import java.awt.print.Pageable;
import java.awt.print.Printable;
import java.util.Collection;
import java.util.List;

/**
 * Draws a {@link PrintModel.Document} onto paper.
 *
 * <h3>Printable and Pageable both</h3>
 * <p>
 * Implementing {@link Pageable} as well as {@link Printable} is what makes the
 * Windows print dialog's "Pages from / to" box work: without a page count the
 * dialog can only offer "All", and the job is asked for pages until it says
 * {@code NO_SUCH_PAGE}. Pagination has to happen before the dialog opens
 * anyway, so the count is free.
 * </p>
 *
 * <h3>Fonts and layout</h3>
 * <p>
 * The same bundled Noto fonts and the same layout as the PDF export
 * ({@link PrintFonts}, {@link PrintPaginator}), so paper and PDF wrap at the
 * same places and have the same page count. Nothing is taken from the
 * operating system's fonts. Every cluster -- Latin, Greek, Tamil, Sanskrit,
 * Telugu, Malayalam -- is drawn as a shaped glyph run, so Indic vowel signs
 * and conjuncts come out as the reader expects. Measurement uses
 * {@link PrintFonts}' own render context, which is why it works before the
 * printer has supplied a {@code Graphics}.
 * </p>
 */
public final class CodePrintable implements Printable, Pageable {

    /** Row pitch as a multiple of the point size. */
    private static final double LINE_FACTOR = 1.35;

    /** Header, footer and line numbers, relative to the code size. */
    private static final float FURNITURE_SCALE = 0.85f;

    /** Gap in points between the gutter and the first code column. */
    private static final double GUTTER_GAP = 6;

    /** Gap in points between the header rule and the first row. */
    private static final double HEADER_GAP = 6;

    private final PrintModel.Document doc;
    private final PrintSettings settings;
    private final PageFormat format;

    private final PrintFonts code;
    private final PrintFonts furniture;

    private final double rowHeight;
    private final double gutterWidth;
    private final double headerHeight;
    private final double footerHeight;

    private final List<PrintPaginator.Page> pages;

    /**
     * @param doc      the document to print
     * @param settings the chosen options
     * @param format   the page format the printer job handed us
     */
    public CodePrintable(PrintModel.Document doc, PrintSettings settings, PageFormat format) {
        this.doc = doc;
        this.settings = settings;
        this.format = format;

        float size = settings.fontSize();
        this.code = new PrintFonts(size);
        this.furniture = new PrintFonts(size * FURNITURE_SCALE);

        double cell = code.cell();
        this.rowHeight = Math.ceil(size * LINE_FACTOR);
        this.headerHeight = settings.header() ? size * 2.0 : 0;
        this.footerHeight = settings.footer() ? size * 2.0 : 0;

        int digits = Math.max(3, String.valueOf(Math.max(1, doc.lines().size())).length());
        this.gutterWidth = settings.lineNumbers() ? digits * cell + GUTTER_GAP * 2 : 0;

        double rowWidth = format.getImageableWidth() - gutterWidth;
        int rows = (int) Math.floor(
                (format.getImageableHeight() - headerHeight - footerHeight - HEADER_GAP) / rowHeight);

        this.pages = PrintPaginator.paginate(doc, code, rowWidth, rows);
    }

    /* =====================================================================
     * Pageable
     * ===================================================================== */

    @Override
    public int getNumberOfPages() {
        return pages.size();
    }

    @Override
    public PageFormat getPageFormat(int pageIndex) {
        return format;
    }

    @Override
    public Printable getPrintable(int pageIndex) {
        return this;
    }

    /* =====================================================================
     * Printable
     * ===================================================================== */

    @Override
    public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) {
        if (pageIndex < 0 || pageIndex >= pages.size()) {
            return NO_SUCH_PAGE;
        }

        Graphics2D g = (Graphics2D) graphics;
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS,
                RenderingHints.VALUE_FRACTIONALMETRICS_ON);

        PrintSettings.Theme theme = settings.theme();
        float size = settings.fontSize();
        double originX = pageFormat.getImageableX();
        double originY = pageFormat.getImageableY();
        double width = pageFormat.getImageableWidth();
        double height = pageFormat.getImageableHeight();

        if (settings.paintsPageBackground()) {
            // Only the imageable area: a printer will not put ink in the
            // hardware margin however hard we ask.
            g.setColor(PrintPalette.page(theme));
            g.fillRect((int) originX, (int) originY, (int) Math.ceil(width), (int) Math.ceil(height));
        }

        double y = originY;

        if (settings.header()) {
            drawCells(g, furniture, furniture.layoutPlain(doc.headerText()),
                    originX, y + size, PrintPalette.furniture(theme));
            g.setColor(PrintPalette.rule(theme));
            int ruleY = (int) (y + headerHeight - size * 0.4);
            g.drawLine((int) originX, ruleY, (int) (originX + width), ruleY);
            y += headerHeight;
        }
        y += HEADER_GAP;

        PrintPaginator.Page page = pages.get(pageIndex);

        if (settings.lineNumbers() && gutterWidth > 0) {
            g.setColor(PrintPalette.gutter(theme));
            g.fillRect((int) originX, (int) y,
                    (int) Math.ceil(gutterWidth),
                    (int) Math.ceil(page.rows().size() * rowHeight));
        }

        double codeX = originX + gutterWidth;
        double rowY = y;

        for (PrintPaginator.Row row : page.rows()) {
            double baseline = rowY + size;

            if (settings.lineNumbers() && row.number() != PrintPaginator.CONTINUATION) {
                List<PrintFonts.Cell> label = furniture.layoutPlain(String.valueOf(row.number()));
                // Right-aligned inside the gutter, as a gutter should be.
                double lx = originX + gutterWidth - GUTTER_GAP - PrintFonts.width(label);
                drawCells(g, furniture, label, lx, baseline, PrintPalette.lineNumber(theme));
            }

            drawCells(g, code, row.cells(), codeX, baseline, null);
            rowY += rowHeight;
        }

        if (settings.footer()) {
            List<PrintFonts.Cell> label = furniture
                    .layoutPlain("Page " + (pageIndex + 1) + " of " + pages.size());
            drawCells(g, furniture, label,
                    originX + width - PrintFonts.width(label),
                    originY + height - size * 0.5,
                    PrintPalette.furniture(theme));
        }

        return PAGE_EXISTS;
    }

    /**
     * Draws a row of laid-out cells, each as a shaped glyph run placed at its
     * own x, so the mono grid holds and Indic clusters keep their natural
     * width.
     *
     * @param plainInk null to colour each cell from its syntax classes; a
     *                 colour to draw everything plain in that colour
     */
    private void drawCells(Graphics2D g, PrintFonts fonts, List<PrintFonts.Cell> cells,
            double originX, double baseline, Color plainInk) {
        float size = fonts.size();
        for (PrintFonts.Cell c : cells) {
            Collection<String> classes = c.classes();
            boolean plain = plainInk != null;
            boolean bold = !plain && PrintPalette.bold(classes);
            boolean italic = !plain && PrintPalette.italic(classes);
            double scale = PrintPalette.sizeScale(classes);
            // Java2D's y axis points down, so a subscript's positive shift
            // lowers it, as wanted.
            double y = baseline + PrintPalette.baselineShift(classes) * size;

            g.setColor(plain ? plainInk : PrintPalette.ink(classes, settings.theme()));
            GlyphVector gv = fonts.shape(c.face(), bold, italic, size * scale, c.text());
            g.drawGlyphVector(gv, (float) (originX + c.x()), (float) y);
        }
    }

    /** @return the page count, for callers that want it without a cast */
    public int pageCount() {
        return pages.size();
    }
}
