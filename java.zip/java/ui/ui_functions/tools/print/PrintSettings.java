package ui.ui_functions.tools.print;

/**
 * Everything the user can choose about a printout, in one place.
 *
 * <p>
 * Paper and PDF share this type, but not the same defaults: {@link #forPaper()}
 * is always light, because a dark theme on paper means flooding an A4 sheet
 * with #1e1e1e ink and no printer will thank you for it. The dark option
 * exists for PDF, where it costs nothing and is what people actually want when
 * the file is going into a dark-themed document or a slide.
 * </p>
 *
 * @param theme       which palette to print in
 * @param fontSize    point size of the code, in PostScript points
 * @param lineNumbers draw the line-number gutter
 * @param header      draw the file path across the top of every page
 * @param footer      draw "Page n of m" across the bottom of every page
 */
public record PrintSettings(
        Theme theme,
        float fontSize,
        boolean lineNumbers,
        boolean header,
        boolean footer) {

    /** Which palette a printout uses. */
    public enum Theme {
        /** White page, dark ink -- the editor's light palette. */
        LIGHT,
        /** Dark page, light ink -- the editor's dark palette. */
        DARK
    }

    /** Code point size that keeps ~95 monospace columns inside A4 margins. */
    public static final float DEFAULT_FONT_SIZE = 9f;

    /**
     * @return the paper default: light, with all three furniture items on
     */
    public static PrintSettings forPaper() {
        return new PrintSettings(Theme.LIGHT, DEFAULT_FONT_SIZE, true, true, true);
    }

    /**
     * @param theme the palette chosen in the export window
     * @return the PDF default for that palette
     */
    public static PrintSettings forPdf(Theme theme) {
        return new PrintSettings(theme, DEFAULT_FONT_SIZE, true, true, true);
    }

    /**
     * @return true if the page itself has to be painted before the text
     */
    public boolean paintsPageBackground() {
        return theme == Theme.DARK;
    }
}
