package ui.ui_functions.tools.print;

/**
 * Everything the user can choose about a printout, in one place.
 *
 * <p>
 * Paper and PDF share this type. The default for both is light, because a
 * dark theme on paper means flooding an A4 sheet with #1e1e1e ink. Dark is
 * still available for paper when the user picks it explicitly: it is the
 * right choice for a virtual printer such as "Microsoft Print to PDF", and a
 * user who asks for it on a real printer has made that trade knowingly.
 * </p>
 *
 * @param theme       which palette to print in
 * @param fontSize    point size of the code, in PostScript points
 * @param lineNumbers draw the line-number gutter
 * @param header      draw the file path across the top of every page
 * @param footer      draw "Page n of m" across the bottom of every page
 */
public record PrintSettings(
        Theme theme,
        float fontSize,
        boolean lineNumbers,
        boolean header,
        boolean footer) {

    /** Which palette a printout uses. */
    public enum Theme {
        /** White page, dark ink -- the editor's light palette. */
        LIGHT,
        /** Dark page, light ink -- the editor's dark palette. */
        DARK
    }

    /** Code point size that keeps ~95 monospace columns inside A4 margins. */
    public static final float DEFAULT_FONT_SIZE = 9f;

    /**
     * @return the paper default: light, with all three furniture items on
     */
    public static PrintSettings forPaper() {
        return forPaper(Theme.LIGHT);
    }

    /**
     * @param theme the palette chosen in the print window
     * @return the paper settings for that palette
     */
    public static PrintSettings forPaper(Theme theme) {
        return new PrintSettings(theme == null ? Theme.LIGHT : theme,
                DEFAULT_FONT_SIZE, true, true, true);
    }

    /**
     * @param theme the palette chosen in the export window
     * @return the PDF default for that palette
     */
    public static PrintSettings forPdf(Theme theme) {
        return new PrintSettings(theme == null ? Theme.LIGHT : theme,
                DEFAULT_FONT_SIZE, true, true, true);
    }

    /**
     * @return true if the page itself has to be painted before the text
     */
    public boolean paintsPageBackground() {
        return theme == Theme.DARK;
    }
}
