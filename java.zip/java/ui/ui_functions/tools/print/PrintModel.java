package ui.ui_functions.tools.print;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.fxmisc.richtext.CodeArea;
import org.fxmisc.richtext.model.StyleSpan;
import org.fxmisc.richtext.model.StyleSpans;

import javafx.scene.Node;
import javafx.scene.control.Tab;
import javafx.scene.control.TextArea;
import language.syntax.UPITokenMaker;
import ui.UI_Main;
import ui.editor.EditorFileInfo;
import ui.editor.EditorTextOperations;

/**
 * The active tab's contents, turned into something a renderer can draw.
 *
 * <h3>Why the highlighting is recomputed rather than read back</h3>
 * <p>
 * {@code CodeArea.getStyleSpans(0, length)} would return what is on screen --
 * including RichTextFX's own fold style on every collapsed paragraph. A
 * printout of a file with three blocks collapsed would then carry three
 * invisible regions. Calling {@link UPITokenMaker#computeHighlighting(String)}
 * on the full text instead means the printout is always the whole file,
 * coloured from scratch, and fold state cannot reach it.
 * </p>
 *
 * <h3>Marker characters</h3>
 * <p>
 * Sub- and superscripts are delimited in the document by ZWJ ({@code U+200D})
 * and ZWNJ ({@code U+200C}). They are zero-width on screen because the editor
 * font has no glyph for them; a PDF font may not be so forgiving, and they
 * would count toward the wrap column either way. They are stripped here, and
 * the run keeps its {@code subscript-*} / {@code superscript-*} class so the
 * renderer can still draw it small and off the baseline.
 * </p>
 */
public final class PrintModel {

    /** Spaces a tab expands to. Matches IndentationSyntaxAnalyzer.INDENT_SIZE. */
    private static final int TAB_WIDTH = 3;

    private PrintModel() {
    }

    /**
     * A contiguous piece of one line sharing a single set of style classes.
     *
     * @param text    the run's characters, markers already stripped
     * @param classes the style classes RichTextFX carried on it
     */
    public record Run(String text, Collection<String> classes) {
    }

    /**
     * One logical line of the source -- that is, one line as the file has it,
     * before any wrapping.
     *
     * @param number 1-based line number as it appears in the editor gutter
     * @param runs   the line's styled pieces, in order
     */
    public record Line(int number, List<Run> runs) {

        /** @return the line's plain text, for width measurement */
        public String plain() {
            StringBuilder sb = new StringBuilder();
            for (Run r : runs) {
                sb.append(r.text());
            }
            return sb.toString();
        }
    }

    /**
     * A whole printable document.
     *
     * @param title display name, used in the header and as the PDF file stem
     * @param path  the file on disk, or null for a tab that was never saved
     * @param lines the source, one entry per logical line
     */
    public record Document(String title, Path path, List<Line> lines) {

        /** @return the header string: full path when saved, title otherwise */
        public String headerText() {
            return path != null ? path.toString() : title + "  (unsaved)";
        }

        /** @return true when there is nothing worth sending to a printer */
        public boolean isEmpty() {
            return lines.isEmpty();
        }
    }

    /* =====================================================================
     * BUILD
     * ===================================================================== */

    /**
     * Builds the document for whichever tab is active.
     *
     * @param ide the IDE controller
     * @return the document, or null if no tab is open
     */
    public static Document fromActiveTab(UI_Main ide) {
        if (ide == null || ide.editorTabs == null) {
            return null;
        }
        Tab tab = ide.editorTabs.getSelectionModel().getSelectedItem();
        if (tab == null) {
            return null;
        }

        Node editor = EditorTextOperations.findEditor(tab);
        String text = EditorTextOperations.getEditorText(tab);

        String title = tab.getText() == null ? "untitled" : tab.getText().replace("*", "").trim();
        Path path = (tab.getUserData() instanceof EditorFileInfo info) ? info.path : null;

        List<Line> lines = (editor instanceof CodeArea)
                ? highlightedLines(text)
                : plainLines(text);

        return new Document(title, path, lines);
    }

    /* =====================================================================
     * INTERNALS
     * ===================================================================== */

    /**
     * Splits the text into lines of styled runs using a freshly computed
     * highlighting pass.
     *
     * @param text the whole document
     * @return one {@link Line} per source line
     */
    private static List<Line> highlightedLines(String text) {
        List<Line> lines = new ArrayList<>();
        List<Run> current = new ArrayList<>();
        int lineNumber = 1;

        StyleSpans<Collection<String>> spans = UPITokenMaker.computeHighlighting(text);

        int offset = 0;
        for (StyleSpan<Collection<String>> span : spans) {
            int length = span.getLength();
            if (length <= 0) {
                continue;
            }
            int end = Math.min(offset + length, text.length());
            String chunk = text.substring(offset, end);
            offset = end;

            Collection<String> classes = span.getStyle() == null
                    ? Collections.<String>emptyList()
                    : span.getStyle();

            // A span may straddle line breaks, so it is split here rather
            // than assumed to sit inside one line.
            int from = 0;
            while (true) {
                int nl = chunk.indexOf('\n', from);
                if (nl < 0) {
                    addRun(current, chunk.substring(from), classes);
                    break;
                }
                addRun(current, chunk.substring(from, nl), classes);
                lines.add(new Line(lineNumber++, current));
                current = new ArrayList<>();
                from = nl + 1;
            }
        }

        // Any text past the last span (the builder appends an unstyled tail).
        if (offset < text.length()) {
            String tail = text.substring(offset);
            int from = 0;
            while (true) {
                int nl = tail.indexOf('\n', from);
                if (nl < 0) {
                    addRun(current, tail.substring(from), Collections.emptyList());
                    break;
                }
                addRun(current, tail.substring(from, nl), Collections.emptyList());
                lines.add(new Line(lineNumber++, current));
                current = new ArrayList<>();
                from = nl + 1;
            }
        }

        lines.add(new Line(lineNumber, current));
        return lines;
    }

    /**
     * Plain-text tabs have no tokenizer, so every line is one unstyled run.
     *
     * @param text the whole document
     * @return one {@link Line} per source line
     */
    private static List<Line> plainLines(String text) {
        List<Line> lines = new ArrayList<>();
        String[] raw = text.split("\n", -1);
        for (int i = 0; i < raw.length; i++) {
            List<Run> runs = new ArrayList<>();
            addRun(runs, raw[i], Collections.emptyList());
            lines.add(new Line(i + 1, runs));
        }
        return lines;
    }

    /**
     * Cleans a chunk and appends it, dropping empty results.
     *
     * @param into    the line being built
     * @param chunk   raw text
     * @param classes the span's style classes
     */
    private static void addRun(List<Run> into, String chunk, Collection<String> classes) {
        if (chunk.isEmpty()) {
            return;
        }
        String cleaned = clean(chunk);
        if (!cleaned.isEmpty()) {
            into.add(new Run(cleaned, classes));
        }
    }

    /**
     * Strips sub/superscript markers and carriage returns, and expands tabs.
     *
     * @param s raw text
     * @return text safe to lay out on a fixed character grid
     */
    private static String clean(String s) {
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\u200C' || c == '\u200D' || c == '\r') {
                continue;
            }
            if (c == '\t') {
                sb.append(" ".repeat(TAB_WIDTH));
                continue;
            }
            sb.append(c);
        }
        return sb.toString();
    }
}
