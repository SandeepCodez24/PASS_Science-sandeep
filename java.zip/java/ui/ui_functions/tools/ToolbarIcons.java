package ui.ui_functions.tools;

import java.io.InputStream;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import ui.design.Dim;

public final class ToolbarIcons {

    // Theme flag. When the app switches to the dark theme, call
    // ToolbarIcons.setDarkMode(true) BEFORE building the toolbars.
    // In dark mode we first try a dark icon variant located under
    // "/icons/dark/..."; if that resource does not exist we safely
    // fall back to the original icon, so nothing breaks if you have
    // not added dark assets yet.
    private static volatile boolean darkMode = false;

    private ToolbarIcons() {
    }

    public static void setDarkMode(boolean dark) {
        darkMode = dark;
    }

    public static boolean isDarkMode() {
        return darkMode;
    }

    // Maps "/icons/foo/bar.png" -> "/icons/dark/foo/bar.png".
    private static String toDarkPath(String path) {
        if (path == null || !path.startsWith("/icons/")) {
            return path;
        }
        return "/icons/dark/" + path.substring("/icons/".length());
    }

    public static Image loadIconPublic(String path) {
        // In dark mode, prefer a dark variant when one is available.
        if (darkMode) {
            String darkPath = toDarkPath(path);
            InputStream darkStream = ToolbarIcons.class.getResourceAsStream(darkPath);
            if (darkStream != null) {
                return new Image(darkStream);
            }
            // else: fall through to the standard icon below.
        }

        InputStream stream = ToolbarIcons.class.getResourceAsStream(path);
        if (stream == null) {
            System.err.println("Missing icon: " + path);
            return new Image("https://via.placeholder.com/22");
        }
        return new Image(stream);
    }

    public static ImageView icon(String path) {
        return icon(path, Dim.Icons.TOOLBAR_DEFAULT);
    }

    // Size-aware variant. The ribbon compartments render their icons a
    // little larger than the old 22px default, and the quick-access bar
    // renders them smaller, so the size is a parameter rather than a
    // constant baked into the loader.
    public static ImageView icon(String path, double size) {
        ImageView iv = new ImageView(loadIconPublic(path));
        iv.setFitWidth(size);
        iv.setFitHeight(size);
        iv.setPreserveRatio(true);
        iv.setSmooth(true);
        return iv;
    }
}
