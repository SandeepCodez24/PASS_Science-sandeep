package ui.ui_functions.tools;

import java.io.InputStream;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import ui.design.Dim;

/**
 * Generic classpath icon loader for the toolbars.
 *
 * <p>
 * Two resolution strategies live behind {@link #icon(String, double)}:
 * </p>
 *
 * <ol>
 * <li><b>NC_ribbon paths</b> are handed to {@link NcRibbonIcons}, which knows
 * about the {@code light/dark} folders and the weak registry that lets an icon
 * already on screen re-point itself when the theme is toggled.</li>
 * <li><b>Everything else</b> keeps the original behaviour: in dark mode try a
 * {@code /icons/dark/...} mirror of the path, and fall back to the plain asset
 * when no dark variant has been added.</li>
 * </ol>
 *
 * <p>
 * The delegation is the point of this edit. Call sites such as the quick access
 * bar pass a literal path string; routing inside the loader means every one of
 * them picks up the themed art and the live swap without being touched. The
 * alternative -- rewriting each call site to name {@code NcRibbonIcons}
 * directly -- would have meant hunting down every reference to
 * {@code /icons/NC_ribbon/} in the tree, and would have left the next
 * NC_ribbon call site written after this change silently un-themed.
 * </p>
 */
public final class ToolbarIcons {

    // Theme flag. ThemeManager calls setDarkMode(true) when the dark theme is
    // applied. For the generic branch below we first try a dark icon variant
    // under "/icons/dark/..."; if that resource does not exist we fall back to
    // the original icon, so nothing breaks where dark assets are missing.
    private static volatile boolean darkMode = false;

    private ToolbarIcons() {
    }

    /**
     * Switches the toolbar icon ink.
     *
     * <p>
     * Also forwards to {@link NcRibbonIcons} so the NC_ribbon set -- undo,
     * redo, save, print, notification -- re-points in place. Without this
     * forward the flag would flip but those five would keep the art they were
     * built with, which is the failure the {@code home_icons} set had before
     * {@code HomeRibbonIcons.setDarkTheme} was wired in.
     * </p>
     *
     * @param dark {@code true} for the dark-theme art
     */
    public static void setDarkMode(boolean dark) {
        darkMode = dark;
        NcRibbonIcons.setDarkTheme(dark);
    }

    public static boolean isDarkMode() {
        return darkMode;
    }

    // Maps "/icons/foo/bar.png" -> "/icons/dark/foo/bar.png".
    private static String toDarkPath(String path) {
        if (path == null || !path.startsWith("/icons/")) {
            return path;
        }
        return "/icons/dark/" + path.substring("/icons/".length());
    }

    /**
     * Loads a raw image for a path.
     *
     * <p>
     * Kept for callers that want an {@link Image} rather than a view. Note that
     * an image obtained this way is a snapshot of the current theme: it is not
     * registered anywhere, so it will not follow a later toggle. Prefer
     * {@link #icon(String, double)} for anything that stays on screen.
     * </p>
     *
     * @param path classpath resource
     * @return the image, or a placeholder if the resource is missing
     */
    public static Image loadIconPublic(String path) {
        if (darkMode) {
            String darkPath = toDarkPath(path);
            InputStream darkStream = ToolbarIcons.class.getResourceAsStream(darkPath);
            if (darkStream != null) {
                return new Image(darkStream);
            }
            // else: fall through to the standard icon below.
        }

        InputStream stream = ToolbarIcons.class.getResourceAsStream(path);
        if (stream == null) {
            System.err.println("Missing icon: " + path);
            return new Image("https://via.placeholder.com/22");
        }
        return new Image(stream);
    }

    public static ImageView icon(String path) {
        return icon(path, Dim.Icons.TOOLBAR_DEFAULT);
    }

    /**
     * Size-aware variant. The ribbon compartments render their icons a little
     * larger than the old 22px default and the quick-access bar renders them
     * smaller, so the size is a parameter rather than a constant baked into the
     * loader.
     *
     * <p>
     * NC_ribbon paths are delegated. That set ships one 256px master per theme
     * and lets JavaFX do the downsample, so the size here only fits the view.
     * </p>
     *
     * @param path classpath resource
     * @param size edge length in pixels
     * @return the configured view
     */
    public static ImageView icon(String path, double size) {
        if (NcRibbonIcons.owns(path)) {
            return NcRibbonIcons.icon(path, size);
        }

        ImageView iv = new ImageView(loadIconPublic(path));
        iv.setFitWidth(size);
        iv.setFitHeight(size);
        iv.setPreserveRatio(true);
        iv.setSmooth(true);
        return iv;
    }
}
