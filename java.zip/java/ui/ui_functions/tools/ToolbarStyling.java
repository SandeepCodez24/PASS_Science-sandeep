package ui.ui_functions.tools;

import javafx.geometry.Pos;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Labeled;
import javafx.scene.control.ToolBar;
import ui.UI_Main;
import ui.ribbon_interface.tool_bar.RibbonLayout;

public final class ToolbarStyling {

    // Height of the Row-2 band. Owned by RibbonLayout so the Home
    // ribbon (icon + icon label + compartment caption) and the other
    // tabs, which share one StackPane, can never disagree on the height.
    private static final double MENU_ROW_HEIGHT = RibbonLayout.ROW_HEIGHT;
    private static final double MENU_BTN_HEIGHT = 58;
    private static final double MENU_BTN_WIDTH = 110;

    private ToolbarStyling() {
    }

    // Row-2 menu button (New, Open, Save, Run, ...).
    //  * Task 3: icon on TOP, text centered BENEATH it.
    //  * Task 2: colours come from the theme CSS via the
    //            ".menu-item-button" style class (NOT hard-coded here),
    //            so light/dark themes both render correctly.
    public static void styleToolbarButton(Labeled b) {
        b.setContentDisplay(ContentDisplay.TOP);
        b.setGraphicTextGap(3);
        b.setAlignment(Pos.CENTER);
        // Taller so the stacked icon + label fits without clipping.
        b.setPrefSize(MENU_BTN_WIDTH, MENU_BTN_HEIGHT);
        b.setMinSize(MENU_BTN_WIDTH, MENU_BTN_HEIGHT);

        // No inline colours -> theme CSS wins. Keep the background
        // transparent so the themed panel shows through.
        b.setStyle("-fx-background-color: transparent;");
        if (!b.getStyleClass().contains("menu-item-button")) {
            b.getStyleClass().add("menu-item-button");
        }
    }

    // Row-2 toolbars. Colours come from the theme CSS via the
    // ".menu-toolbar" style class instead of a hard-coded teal value,
    // so the panel background follows whichever theme is active.
    public static void styleToolbar(ToolBar... tbs) {
        for (ToolBar tb : tbs) {
            tb.setStyle("");
            if (!tb.getStyleClass().contains("menu-toolbar")) {
                tb.getStyleClass().add("menu-toolbar");
            }
            tb.setPrefHeight(MENU_ROW_HEIGHT);
            tb.setMinHeight(MENU_ROW_HEIGHT);
        }
    }

    public static void showToolbar(UI_Main ide, ToolBar tb) {
        ide.homeTB.setVisible(false);
        ide.compileTB.setVisible(false);
        ide.jtagTB.setVisible(false);
        ide.commissionTB.setVisible(false);
        ide.preferencesTB.setVisible(false);
        ide.helpTB.setVisible(false);
        tb.setVisible(true);
    }
}
