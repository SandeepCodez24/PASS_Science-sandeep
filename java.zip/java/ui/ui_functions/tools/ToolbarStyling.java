package ui.ui_functions.tools;

import javafx.geometry.Pos;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Labeled;
import javafx.scene.control.ToolBar;
import ui.UI_Main;
import ui.design.Dim;

/**
 * Shared styling for the Row-2 band and the flat button rows still used by the
 * JTAG, Commission, Settings and Help tabs.
 *
 * <p>
 * All three numbers this class used to declare -- the band height and the flat
 * button's width and height -- now come from {@code ui.design.Dim.ToolBand}.
 * The band height in particular was declared here <em>and</em> in
 * {@code ToolbarSetup}, each with its own comment explaining why; there is now
 * one owner.
 * </p>
 */
public final class ToolbarStyling {

    private ToolbarStyling() {
    }

    /**
     * Styles a flat Row-2 menu button: icon on top, text centred beneath.
     *
     * <p>
     * Colours come from the theme CSS via {@code .menu-item-button}, never from
     * here, so light and dark both render correctly.
     * </p>
     *
     * @param b the button or menu button to style
     */
    public static void styleToolbarButton(Labeled b) {
        b.setContentDisplay(ContentDisplay.TOP);
        b.setGraphicTextGap(Dim.ToolBand.FLAT_GRAPHIC_GAP);
        b.setAlignment(Pos.CENTER);
        // Tall enough that the stacked icon and label fit without clipping.
        b.setPrefSize(Dim.ToolBand.FLAT_BUTTON_WIDTH, Dim.ToolBand.FLAT_BUTTON_HEIGHT);
        b.setMinSize(Dim.ToolBand.FLAT_BUTTON_WIDTH, Dim.ToolBand.FLAT_BUTTON_HEIGHT);

        // No inline colours -> theme CSS wins. Keep the background transparent
        // so the themed panel shows through.
        b.setStyle("-fx-background-color: transparent;");
        if (!b.getStyleClass().contains("menu-item-button")) {
            b.getStyleClass().add("menu-item-button");
        }
    }

    /**
     * Tags each Row-2 toolbar with {@code .menu-toolbar} and pins its height to
     * the shared band height.
     *
     * @param tbs the toolbars to style
     */
    public static void styleToolbar(ToolBar... tbs) {
        for (ToolBar tb : tbs) {
            tb.setStyle("");
            if (!tb.getStyleClass().contains("menu-toolbar")) {
                tb.getStyleClass().add("menu-toolbar");
            }
            tb.setPrefHeight(Dim.ToolBand.ROW_HEIGHT);
            tb.setMinHeight(Dim.ToolBand.ROW_HEIGHT);
        }
    }

    /**
     * Shows one Row-2 toolbar and hides the other five.
     *
     * @param ide the IDE controller
     * @param tb  the toolbar to show
     */
    public static void showToolbar(UI_Main ide, ToolBar tb) {
        ide.homeTB.setVisible(false);
        ide.compileTB.setVisible(false);
        ide.jtagTB.setVisible(false);
        ide.commissionTB.setVisible(false);
        ide.preferencesTB.setVisible(false);
        ide.helpTB.setVisible(false);
        tb.setVisible(true);
    }
}
