package ui.ui_functions.tools;

import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import ui.explorer.support.IconLoader;

/**
 * Loads the Settings-tab icon set from
 * {@code /icons/SettingsIcons/<theme>/<name>.png}.
 *
 * <p>
 * A twin of {@link SignalIcons}: same folder convention, same weak registry,
 * same 48px masters scaled down by the {@link ImageView}. Kept as its own set
 * so the Settings band can be redrawn without touching Home or Signals.
 * </p>
 *
 * <p>
 * {@code ThemeManager.applyIconInk} calls {@link #setDarkTheme(boolean)}, so
 * every icon on screen -- including the gear in the suggestion popup's menu --
 * switches ink with the theme.
 * </p>
 */
public final class SettingsIcons {

    /** Visuals group: Layout. */
    public static final String LAYOUT = "layout";
    /** Visuals group: Theme. */
    public static final String THEME = "theme";
    /** Visuals group: Syntax (also the suggestion popup's "Settings..." entry). */
    public static final String SYNTAX = "syntax";
    /** Plots group. */
    public static final String PLOTS = "plots";
    /** Networks group. */
    public static final String NETWORKS = "networks";

    private static final String BASE = "/icons/SettingsIcons/";
    private static final String NAME_KEY = "settingsIconName";

    private static final List<WeakReference<ImageView>> LIVE = new CopyOnWriteArrayList<>();

    private static volatile boolean dark = false;

    private SettingsIcons() {
    }

    /**
     * Builds an icon view for one of the Settings icons.
     *
     * @param name one of the constants above, e.g. {@link #SYNTAX}
     * @param size edge length in pixels; the image is scaled to fit
     * @return the configured view, already registered for theme swaps
     */
    public static ImageView icon(String name, double size) {
        ImageView view = new ImageView();
        view.getProperties().put(NAME_KEY, name);
        view.setFitWidth(size);
        view.setFitHeight(size);
        view.setPreserveRatio(true);
        view.setSmooth(true);
        view.setMouseTransparent(true);
        apply(view);
        LIVE.add(new WeakReference<>(view));
        return view;
    }

    /**
     * Switches the whole set between the two inks and refreshes every icon
     * currently on screen. Safe to call when nothing has changed.
     *
     * @param useDark {@code true} for the dark-theme ink
     */
    public static void setDarkTheme(boolean useDark) {
        if (useDark == dark) {
            return;
        }
        dark = useDark;
        refresh();
    }

    /**
     * @return {@code true} if the dark-theme ink is currently selected
     */
    public static boolean isDarkTheme() {
        return dark;
    }

    /**
     * @param name base file name, without theme folder or extension
     * @return the classpath resource path for the active theme
     */
    public static String path(String name) {
        return BASE + (dark ? "dark/" : "light/") + name + ".png";
    }

    private static void refresh() {
        Iterator<WeakReference<ImageView>> it = LIVE.iterator();
        while (it.hasNext()) {
            WeakReference<ImageView> ref = it.next();
            ImageView view = ref.get();
            if (view == null) {
                LIVE.remove(ref);
            } else {
                apply(view);
            }
        }
    }

    private static void apply(ImageView view) {
        Object name = view.getProperties().get(NAME_KEY);
        if (name == null) {
            return;
        }
        Image image = IconLoader.load(SettingsIcons.class, path(name.toString()));
        if (image != null) {
            view.setImage(image);
        }
    }
}
