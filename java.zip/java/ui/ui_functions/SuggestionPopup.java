package ui.ui_functions;

import java.util.List;

import org.fxmisc.richtext.CodeArea;

import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.stage.Popup;
import javafx.stage.Window;
import ui.ui_functions.SuggestionProvider.Suggestion;
import ui.ui_functions.suggestion_functions.PopupPositioner;
import ui.ui_functions.suggestion_functions.PopupThemeManager;
import ui.ui_functions.suggestion_functions.SuggestionCellRenderer;

/**
 * VS Code-like suggestion popup for autocomplete.
 * Always follows the typing cursor and auto-filters as you type.
 *
 * <p>
 * This class is now a <b>thin facade</b>. Styling, caret positioning and cell
 * rendering are delegated to the {@code suggestion_functions} package:
 * <ul>
 * <li>{@link PopupThemeManager} – palette + list CSS</li>
 * <li>{@link PopupPositioner} – caret coordinates + height sizing</li>
 * <li>{@link SuggestionCellRenderer} – per-row rendering</li>
 * </ul>
 */
public class SuggestionPopup extends Popup {

    private final ListView<Suggestion> suggestionList;
    private boolean darkTheme;

    // ── Screen-coordinate offset so the popup sits just below the caret ──
    private static final double X_OFFSET = 0;
    private static final double Y_OFFSET = 6;

    public SuggestionPopup() {
        setAutoHide(true);
        setHideOnEscape(true);

        suggestionList = new ListView<>();
        // Don't set fixed size - will auto-size based on content
        suggestionList.setPrefWidth(420);
        suggestionList.setMaxHeight(400); // Max height limit
        suggestionList.setCellFactory(lv -> SuggestionCellRenderer.createCell(() -> darkTheme));
        applyThemeStyles();

        suggestionList.setOnKeyPressed(e -> {
            switch (e.getCode()) {
                case ENTER, TAB -> selectCurrent();
                case ESCAPE -> hide();
                default -> {
                }
            }
        });
        suggestionList.setOnMouseClicked(e -> {
            if (e.getClickCount() == 1)
                selectCurrent();
        });

        getContent().add(suggestionList);
    }

    public void setTheme(String theme) {
        this.darkTheme = "dark".equalsIgnoreCase(theme);
        applyThemeStyles();
        suggestionList.refresh(); // repaint cells with the new theme
    }

    private void applyThemeStyles() {
        suggestionList.setStyle(PopupThemeManager.listStyle(darkTheme));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PUBLIC API – called from EditorManager on every text change
    // ─────────────────────────────────────────────────────────────────────────

    /** Show/update suggestions for a CodeArea with context-aware filtering. */
    public void showSuggestions(CodeArea editor, String pattern, String fullText, Window owner) {
        List<Suggestion> items = SuggestionProvider.getSuggestionsFiltered(pattern, fullText);

        if (items.isEmpty()) {
            hide();
            return;
        }

        applyThemeStyles();
        refreshItems(items);
        PopupPositioner.updatePopupHeight(suggestionList, items.size());

        double[] xy = PopupPositioner.getCaretScreenXY(editor);
        if (xy == null) {
            hide();
            return;
        }

        placeOrMove(xy, owner);
    }

    /** Show/update suggestions for a CodeArea (legacy method - calls new version). */
    public void showSuggestions(CodeArea editor, String pattern, Window owner) {
        showSuggestions(editor, pattern, editor.getText(), owner);
    }

    /** Show/update suggestions for a TextArea with context-aware filtering. */
    public void showSuggestions(TextArea editor, String pattern, String fullText, Window owner) {
        List<Suggestion> items = SuggestionProvider.getSuggestionsFiltered(pattern, fullText);

        if (items.isEmpty()) {
            hide();
            return;
        }

        applyThemeStyles();
        refreshItems(items);
        PopupPositioner.updatePopupHeight(suggestionList, items.size());

        double[] xy = PopupPositioner.getCaretScreenXY(editor);
        if (xy == null) {
            hide();
            return;
        }

        placeOrMove(xy, owner);
    }

    /** Show/update suggestions for a TextArea (legacy method - calls new version). */
    public void showSuggestions(TextArea editor, String pattern, Window owner) {
        showSuggestions(editor, pattern, editor.getText(), owner);
    }

    // ── Shared show/position helpers ──────────────────────────────────────────

    /** Replace items while preserving the current selection row when possible. */
    private void refreshItems(List<Suggestion> items) {
        int prevIndex = suggestionList.getSelectionModel().getSelectedIndex();
        suggestionList.getItems().setAll(items);
        if (prevIndex >= 0 && prevIndex < items.size()) {
            suggestionList.getSelectionModel().select(prevIndex);
        } else {
            suggestionList.getSelectionModel().selectFirst();
        }
    }

    /** Clamp to the visible screen and either move or first-show the popup. */
    private void placeOrMove(double[] xy, Window owner) {
        double popupX = xy[0] + X_OFFSET;
        double popupY = xy[1] + Y_OFFSET;

        if (owner != null) {
            javafx.geometry.Rectangle2D screen = javafx.stage.Screen.getPrimary().getVisualBounds();
            if (popupX + suggestionList.getPrefWidth() > screen.getMaxX())
                popupX = screen.getMaxX() - suggestionList.getPrefWidth() - 10;
            if (popupY + suggestionList.getPrefHeight() > screen.getMaxY())
                popupY = xy[1] - suggestionList.getPrefHeight() - Y_OFFSET; // flip above
        }

        if (isShowing()) {
            setX(popupX);
            setY(popupY);
        } else {
            show(owner, popupX, popupY);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // SELECTION HELPERS
    // ─────────────────────────────────────────────────────────────────────────

    public void selectCurrent() {
        Suggestion selected = suggestionList.getSelectionModel().getSelectedItem();
        if (selected != null) {
            fireInsertSuggestion(selected);
            hide();
        }
    }

    public Suggestion getSelected() {
        return suggestionList.getSelectionModel().getSelectedItem();
    }

    public void selectPrevious() {
        int i = suggestionList.getSelectionModel().getSelectedIndex();
        if (i > 0) {
            suggestionList.getSelectionModel().selectPrevious();
            suggestionList.scrollTo(i - 1);
        }
    }

    public void selectNext() {
        int i = suggestionList.getSelectionModel().getSelectedIndex();
        int size = suggestionList.getItems().size();
        if (i < size - 1) {
            suggestionList.getSelectionModel().selectNext();
            suggestionList.scrollTo(i + 1);
        }
    }

    public boolean isSuggestionShowing() {
        return isShowing();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // INSERT CALLBACK
    // ─────────────────────────────────────────────────────────────────────────

    private Runnable onInsertSuggestion = null;
    private Suggestion lastSuggestion = null;

    public void setOnInsertSuggestion(Runnable callback) {
        this.onInsertSuggestion = callback;
    }

    private void fireInsertSuggestion(Suggestion suggestion) {
        this.lastSuggestion = suggestion;
        if (onInsertSuggestion != null)
            onInsertSuggestion.run();
    }

    public Suggestion getLastSuggestion() {
        return lastSuggestion;
    }
}
