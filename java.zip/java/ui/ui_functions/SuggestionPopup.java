package ui.ui_functions;

import java.util.List;
import java.util.function.Supplier;

import org.fxmisc.richtext.CodeArea;

import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Popup;
import javafx.stage.Window;

import ui.editor.settingsTab.UI_Settings_Syntax_Main;
import ui.ui_functions.SuggestionProvider.Suggestion;
import ui.ui_functions.suggestion_functions.PopupPositioner;
import ui.ui_functions.suggestion_functions.PopupThemeManager;
import ui.ui_functions.suggestion_functions.SuggestionCellRenderer;
import ui.ui_functions.suggestion_functions.SuggestionFooterBar;

/**
 * VS Code-like suggestion popup for autocomplete.
 * Always follows the typing cursor and auto-filters as you type.
 *
 * <h3>What changed</h3>
 * <ol>
 * <li><b>The popup is 15% shorter.</b> Rows are pinned to
 * {@link SuggestionCellRenderer#ROW_HEIGHT} via {@code setFixedCellSize}, which
 * also lets the list virtualise properly instead of measuring every cell.</li>
 * <li><b>A footer bar states the accept keys.</b> The popup content is now a
 * {@link VBox} of list + {@link SuggestionFooterBar}, so the hint sits outside
 * the scroll pane and never scrolls away with the rows.</li>
 * <li><b>Height is computed from the real row height.</b> Sizing used to be
 * delegated wholesale; it now accounts for the footer, so the last row can
 * neither be clipped nor leave a dead strip below it.</li>
 * <li><b>The three dots open the suggestion settings.</b> Ticking a group in
 * that menu re-runs the last query at once, so the rows change while the menu
 * is still open; "Settings..." closes the popup and opens the Syntax settings
 * window.</li>
 * <li><b>The footer is rebuilt only when the theme changes.</b> It used to be
 * rebuilt on every keystroke, which would have detached the settings menu from
 * its button mid-click.</li>
 * <li><b>It knows which file it is typing in.</b>
 * {@link #setExcludedFileSupplier(Supplier)} names the script being edited, so
 * the {@code .nc} file suggestions never offer {@code AAAA} while the user is
 * typing inside {@code AAAA.nc}. The Command Window sets nothing and so sees
 * every script.</li>
 * </ol>
 */
public class SuggestionPopup extends Popup {

    private final ListView<Suggestion> suggestionList;
    private final VBox container;
    private Region footerBar;
    private boolean darkTheme;

    /** Theme the current footer was built for; null before the first build. */
    private Boolean footerBuiltDark;

    /** Re-runs the most recent showSuggestions call; used after a setting changes. */
    private Runnable lastQuery;

    /** Names the script being edited; returns null when nothing is excluded. */
    private Supplier<String> excludedFileSupplier = () -> null;

    // ── Screen-coordinate offset so the popup sits just below the caret ──
    private static final double X_OFFSET = 0;
    private static final double Y_OFFSET = 6;

    /** Popup width. */
    private static final double POPUP_WIDTH = 420;

    /**
     * Most rows shown before the list scrolls.
     *
     * <p>
     * The old cap was a flat 400px of list. At the new 22px row that would be
     * 18 rows — taller in row count than before, which is the opposite of what
     * a shorter popup should feel like. Capping by rows keeps the popup's
     * on-screen footprint genuinely smaller.
     */
    private static final int MAX_VISIBLE_ROWS = 12;

    public SuggestionPopup() {
        setAutoHide(true);
        setHideOnEscape(true);

        suggestionList = new ListView<>();
        suggestionList.setPrefWidth(POPUP_WIDTH);
        // Pin the row height so the list virtualises and so popup sizing and
        // cell sizing can never disagree.
        suggestionList.setFixedCellSize(SuggestionCellRenderer.ROW_HEIGHT);
        suggestionList.setCellFactory(lv -> SuggestionCellRenderer.createCell(() -> darkTheme));

        footerBar = buildFooter();
        footerBuiltDark = darkTheme;

        container = new VBox(suggestionList, footerBar);
        container.setPrefWidth(POPUP_WIDTH);
        container.setFillWidth(true);
        // The list takes all the vertical slack; the footer keeps its fixed height.
        VBox.setVgrow(suggestionList, javafx.scene.layout.Priority.ALWAYS);

        applyThemeStyles();

        suggestionList.setOnKeyPressed(e -> {
            switch (e.getCode()) {
                case ENTER, TAB -> selectCurrent();
                // Left / Right dismiss the popup without accepting anything,
                // mirroring the editor-side handler.
                case LEFT, RIGHT, ESCAPE -> hide();
                default -> {
                }
            }
        });

        suggestionList.setOnMouseClicked(e -> {
            if (e.getClickCount() == 1) {
                selectCurrent();
            }
        });

        getContent().add(container);
    }

    /**
     * Names the file this popup is typing in, so its own name is never
     * offered as a script suggestion.
     *
     * @param supplier returns the file name ({@code AAAA} or {@code AAAA.nc}),
     *                 or null to exclude nothing; null resets to "nothing"
     */
    public void setExcludedFileSupplier(Supplier<String> supplier) {
        this.excludedFileSupplier = supplier == null ? () -> null : supplier;
    }

    private List<Suggestion> query(String pattern, String fullText) {
        String excluded;
        try {
            excluded = excludedFileSupplier.get();
        } catch (RuntimeException e) {
            excluded = null;
        }
        return SuggestionProvider.getSuggestionsFiltered(pattern, fullText, excluded);
    }

    public void setTheme(String theme) {
        this.darkTheme = "dark".equalsIgnoreCase(theme);
        applyThemeStyles();
        suggestionList.refresh(); // repaint cells with the new theme
    }

    private void applyThemeStyles() {
        suggestionList.setStyle(PopupThemeManager.listStyle(darkTheme));
        if (container == null || (footerBuiltDark != null && footerBuiltDark == darkTheme)) {
            return;
        }
        // Rebuild the footer so its colours follow the theme -- only when the
        // theme actually changed.
        Region rebuilt = buildFooter();
        int index = container.getChildren().indexOf(footerBar);
        if (index >= 0) {
            container.getChildren().set(index, rebuilt);
        }
        footerBar = rebuilt;
        footerBuiltDark = darkTheme;
    }

    private Region buildFooter() {
        return SuggestionFooterBar.create(darkTheme, this::requery, this::openSettings);
    }

    /** Re-filters the visible rows after a suggestion setting changed. */
    private void requery() {
        if (isShowing() && lastQuery != null) {
            lastQuery.run();
        }
    }

    /** Closes the popup and opens the Syntax settings window. */
    private void openSettings() {
        Window owner = getOwnerWindow();
        hide();
        UI_Settings_Syntax_Main.open(owner);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PUBLIC API – called from EditorManager on every text change
    // ─────────────────────────────────────────────────────────────────────────

    /** Show/update suggestions for a CodeArea with context-aware filtering. */
    public void showSuggestions(CodeArea editor, String pattern, String fullText, Window owner) {
        lastQuery = () -> showSuggestions(editor, pattern, fullText, owner);
        List<Suggestion> items = query(pattern, fullText);
        if (items.isEmpty()) {
            hide();
            return;
        }

        applyThemeStyles();
        refreshItems(items);
        resizeToContent(items.size());

        double[] xy = PopupPositioner.getCaretScreenXY(editor);
        if (xy == null) {
            hide();
            return;
        }
        placeOrMove(xy, owner);
    }

    /** Show/update suggestions for a CodeArea (legacy method - calls new version). */
    public void showSuggestions(CodeArea editor, String pattern, Window owner) {
        showSuggestions(editor, pattern, editor.getText(), owner);
    }

    /** Show/update suggestions for a TextArea with context-aware filtering. */
    public void showSuggestions(TextArea editor, String pattern, String fullText, Window owner) {
        lastQuery = () -> showSuggestions(editor, pattern, fullText, owner);
        List<Suggestion> items = query(pattern, fullText);
        if (items.isEmpty()) {
            hide();
            return;
        }

        applyThemeStyles();
        refreshItems(items);
        resizeToContent(items.size());

        double[] xy = PopupPositioner.getCaretScreenXY(editor);
        if (xy == null) {
            hide();
            return;
        }
        placeOrMove(xy, owner);
    }

    /** Show/update suggestions for a TextArea (legacy method - calls new version). */
    public void showSuggestions(TextArea editor, String pattern, Window owner) {
        showSuggestions(editor, pattern, editor.getText(), owner);
    }

    // ── Shared show/position helpers ──────────────────────────────────────────

    /**
     * Size the popup to its content.
     *
     * <p>
     * List height is an exact multiple of the fixed row height plus the list's
     * own 2px border, and the container adds the footer on top. Computing it
     * here — rather than letting the list guess from its cells — is what keeps
     * a partial row from appearing at the bottom edge.
     *
     * @param itemCount how many rows the list is about to show
     */
    private void resizeToContent(int itemCount) {
        int visibleRows = Math.min(itemCount, MAX_VISIBLE_ROWS);
        double listHeight = visibleRows * SuggestionCellRenderer.ROW_HEIGHT + 2;

        suggestionList.setPrefHeight(listHeight);
        suggestionList.setMinHeight(listHeight);
        suggestionList.setMaxHeight(listHeight);

        double totalHeight = listHeight + SuggestionFooterBar.FOOTER_HEIGHT;
        container.setPrefHeight(totalHeight);
        container.setMaxHeight(totalHeight);
    }

    /** The popup's full on-screen height, list plus footer. */
    private double currentHeight() {
        return suggestionList.getPrefHeight() + SuggestionFooterBar.FOOTER_HEIGHT;
    }

    /** Replace items while preserving the current selection row when possible. */
    private void refreshItems(List<Suggestion> items) {
        int prevIndex = suggestionList.getSelectionModel().getSelectedIndex();
        suggestionList.getItems().setAll(items);
        if (prevIndex >= 0 && prevIndex < items.size()) {
            suggestionList.getSelectionModel().select(prevIndex);
        } else {
            suggestionList.getSelectionModel().selectFirst();
        }
    }

    /** Clamp to the visible screen and either move or first-show the popup. */
    private void placeOrMove(double[] xy, Window owner) {
        double popupX = xy[0] + X_OFFSET;
        double popupY = xy[1] + Y_OFFSET;

        if (owner != null) {
            javafx.geometry.Rectangle2D screen = javafx.stage.Screen.getPrimary().getVisualBounds();
            if (popupX + POPUP_WIDTH > screen.getMaxX()) {
                popupX = screen.getMaxX() - POPUP_WIDTH - 10;
            }
            // Flip above the caret using the true height, footer included.
            if (popupY + currentHeight() > screen.getMaxY()) {
                popupY = xy[1] - currentHeight() - Y_OFFSET;
            }
        }

        if (isShowing()) {
            setX(popupX);
            setY(popupY);
        } else {
            show(owner, popupX, popupY);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // SELECTION HELPERS
    // ─────────────────────────────────────────────────────────────────────────

    public void selectCurrent() {
        Suggestion selected = suggestionList.getSelectionModel().getSelectedItem();
        if (selected != null) {
            fireInsertSuggestion(selected);
            hide();
        }
    }

    public Suggestion getSelected() {
        return suggestionList.getSelectionModel().getSelectedItem();
    }

    public void selectPrevious() {
        int i = suggestionList.getSelectionModel().getSelectedIndex();
        if (i > 0) {
            suggestionList.getSelectionModel().selectPrevious();
            suggestionList.scrollTo(i - 1);
        }
    }

    public void selectNext() {
        int i = suggestionList.getSelectionModel().getSelectedIndex();
        int size = suggestionList.getItems().size();
        if (i < size - 1) {
            suggestionList.getSelectionModel().selectNext();
            suggestionList.scrollTo(i + 1);
        }
    }

    public boolean isSuggestionShowing() {
        return isShowing();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // INSERT CALLBACK
    // ─────────────────────────────────────────────────────────────────────────

    private Runnable onInsertSuggestion = null;
    private Suggestion lastSuggestion = null;

    public void setOnInsertSuggestion(Runnable callback) {
        this.onInsertSuggestion = callback;
    }

    private void fireInsertSuggestion(Suggestion suggestion) {
        this.lastSuggestion = suggestion;
        if (onInsertSuggestion != null) {
            onInsertSuggestion.run();
        }
    }

    public Suggestion getLastSuggestion() {
        return lastSuggestion;
    }
}
