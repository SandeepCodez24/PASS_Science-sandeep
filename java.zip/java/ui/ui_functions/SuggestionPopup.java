package ui.ui_functions;

import java.util.List;

import org.fxmisc.richtext.CodeArea;

import javafx.geometry.Bounds;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.stage.Popup;
import javafx.stage.Window;

/**
 * VS Code-like suggestion popup for autocomplete.
 * Always follows the typing cursor and auto-filters as you type.
 */
public class SuggestionPopup extends Popup {

    private final ListView<SuggestionProvider.Suggestion> suggestionList;
    private boolean darkTheme;

    private static final String LIGHT_POPUP_BG = "#ffffff";
    private static final String LIGHT_POPUP_TEXT = "#000000";
    private static final String LIGHT_POPUP_BORDER = "#444444";
    private static final String LIGHT_SELECTION_BG = "#0aa6a6";
    private static final String LIGHT_DESCRIPTION_TEXT = "#555555";
    private static final String LIGHT_MARKER_SUB = "#7ec8e3";
    private static final String LIGHT_MARKER_SUP = "#b5cea8";

    private static final String DARK_POPUP_BG = "#252526";
    private static final String DARK_POPUP_TEXT = "#e6e6e6";
    private static final String DARK_POPUP_BORDER = "#3a3a3a";
    private static final String DARK_SELECTION_BG = "#264f78";
    private static final String DARK_DESCRIPTION_TEXT = "#cfcfcf";
    private static final String DARK_MARKER_SUB = "#9ed8ea";
    private static final String DARK_MARKER_SUP = "#cbdc9a";

    // ── Screen-coordinate offset so the popup sits just below the caret ──
    private static final double X_OFFSET = 0;
    private static final double Y_OFFSET = 6;

    public SuggestionPopup() {
        setAutoHide(true);
        setHideOnEscape(true);

        suggestionList = new ListView<>();
        suggestionList.setStyle("""
                -fx-font-family: 'Consolas';
                -fx-font-size: 13;
                -fx-control-inner-background: #ffffff;
                -fx-text-fill: #000000;
                -fx-border-color: #444444;
                -fx-border-width: 1;
                -fx-padding: 0;
                -fx-spacing: 0;
                """);
        // Don't set fixed size - will auto-size based on content
        suggestionList.setPrefWidth(420);
        suggestionList.setMaxHeight(400); // Max height limit
        suggestionList.setCellFactory(lv -> new SuggestionCell());
        applyThemeStyles();

        suggestionList.setOnKeyPressed(e -> {
            switch (e.getCode()) {
                case ENTER,TAB -> selectCurrent();
                case ESCAPE -> hide();
                default -> {
                }
            }
        });
        suggestionList.setOnMouseClicked(e -> {
            if (e.getClickCount() == 1)
                selectCurrent();
        });

        getContent().add(suggestionList);
    }

    public void setTheme(String theme) {
        this.darkTheme = "dark".equalsIgnoreCase(theme);
        applyThemeStyles();
    }

    private void applyThemeStyles() {
        String background = darkTheme ? DARK_POPUP_BG : LIGHT_POPUP_BG;
        String text = darkTheme ? DARK_POPUP_TEXT : LIGHT_POPUP_TEXT;
        String border = darkTheme ? DARK_POPUP_BORDER : LIGHT_POPUP_BORDER;

        suggestionList.setStyle("""
                -fx-font-family: 'Consolas';
                -fx-font-size: 13;
                -fx-control-inner-background: %s;
                -fx-background-color: %s;
                -fx-text-fill: %s;
                -fx-border-color: %s;
                -fx-border-width: 1;
                -fx-padding: 0;
                -fx-spacing: 0;
                """.formatted(background, background, text, border));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PUBLIC API – called from EditorManager on every text change
    // ─────────────────────────────────────────────────────────────────────────

    /** Show/update suggestions for a CodeArea with context-aware filtering. */
    public void showSuggestions(CodeArea editor, String pattern, String fullText, Window owner) {
        List<SuggestionProvider.Suggestion> items = SuggestionProvider.getSuggestionsFiltered(pattern, fullText);

        if (items.isEmpty()) {
            hide();
            return;
        }

        applyThemeStyles();

        // Update list while remembering the current selection index
        int prevIndex = suggestionList.getSelectionModel().getSelectedIndex();
        suggestionList.getItems().setAll(items);
        // Keep selection at the same row if still valid, else select first
        if (prevIndex >= 0 && prevIndex < items.size()) {
            suggestionList.getSelectionModel().select(prevIndex);
        } else {
            suggestionList.getSelectionModel().selectFirst();
        }

        // ── Auto-size height based on number of suggestions ──────────────────
        updatePopupHeight(items.size());

        // ── Always compute fresh caret screen coords ──────────────────────────
        double[] xy = getCaretScreenXY(editor);

        if (xy == null) {
            hide();
            return;
        }

        double popupX = xy[0] + X_OFFSET;
        double popupY = xy[1] + Y_OFFSET;

        // Clamp so the popup stays on screen
        if (owner != null) {
            javafx.geometry.Rectangle2D screen = javafx.stage.Screen.getPrimary().getVisualBounds();
            if (popupX + suggestionList.getPrefWidth() > screen.getMaxX())
                popupX = screen.getMaxX() - suggestionList.getPrefWidth() - 10;
            if (popupY + suggestionList.getPrefHeight() > screen.getMaxY())
                popupY = xy[1] - suggestionList.getPrefHeight() - Y_OFFSET; // flip above
        }

        if (isShowing()) {
            // Already visible – just move it to follow the caret
            setX(popupX);
            setY(popupY);
        } else {
            show(owner, popupX, popupY);
        }
    }

    /** Show/update suggestions for a CodeArea (legacy method - calls new version). */
    public void showSuggestions(CodeArea editor, String pattern, Window owner) {
        String fullText = editor.getText();
        showSuggestions(editor, pattern, fullText, owner);
    }

    /** Show/update suggestions for a TextArea with context-aware filtering. */
    public void showSuggestions(TextArea editor, String pattern, String fullText, Window owner) {
        List<SuggestionProvider.Suggestion> items = SuggestionProvider.getSuggestionsFiltered(pattern, fullText);

        if (items.isEmpty()) {
            hide();
            return;
        }

        applyThemeStyles();

        int prevIndex = suggestionList.getSelectionModel().getSelectedIndex();
        suggestionList.getItems().setAll(items);
        if (prevIndex >= 0 && prevIndex < items.size()) {
            suggestionList.getSelectionModel().select(prevIndex);
        } else {
            suggestionList.getSelectionModel().selectFirst();
        }

        // ── Auto-size height based on number of suggestions ──────────────────
        updatePopupHeight(items.size());

        double[] xy = getCaretScreenXY(editor);

        if (xy == null) {
            hide();
            return;
        }

        double popupX = xy[0] + X_OFFSET;
        double popupY = xy[1] + Y_OFFSET;

        if (owner != null) {
            javafx.geometry.Rectangle2D screen = javafx.stage.Screen.getPrimary().getVisualBounds();
            if (popupX + suggestionList.getPrefWidth() > screen.getMaxX())
                popupX = screen.getMaxX() - suggestionList.getPrefWidth() - 10;
            if (popupY + suggestionList.getPrefHeight() > screen.getMaxY())
                popupY = xy[1] - suggestionList.getPrefHeight() - Y_OFFSET;
        }

        if (isShowing()) {
            setX(popupX);
            setY(popupY);
        } else {
            show(owner, popupX, popupY);
        }
    }

    /** Show/update suggestions for a TextArea (legacy method - calls new version). */
    public void showSuggestions(TextArea editor, String pattern, Window owner) {
        String fullText = editor.getText();
        showSuggestions(editor, pattern, fullText, owner);
    }

    // ── Helper to auto-size popup height based on number of suggestions ─────
    /**
     * Update popup height dynamically based on item count.
     * - Less than 5 suggestions: auto-shrink to fit content
     * - 5+ suggestions: show ~8 items then scroll
     * Each suggestion cell is approximately 30px (single line).
     */
    private void updatePopupHeight(int itemCount) {
        double cellHeight = 32.0; // Height per suggestion cell (single-line with right-side description)

        if (itemCount <= 4) {
            // For 1-4 suggestions: show all, no scrolling needed
            double calculatedHeight = itemCount * cellHeight;
            suggestionList.setPrefHeight(calculatedHeight);
        } else {
            // For 5+ suggestions: show ~8 items then enable scrolling
            double maxVisibleHeight = 8 * cellHeight; // ~240px for 8 suggestions to scroll
            suggestionList.setPrefHeight(maxVisibleHeight);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CARET POSITION HELPERS
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Returns [screenX, screenY] of the bottom-left of the current caret
     * for a CodeArea, or null if it cannot be determined.
     */
    private static double[] getCaretScreenXY(CodeArea editor) {
        try {
            // RichTextFX exposes optional caret bounds in scene coordinates
            java.util.Optional<Bounds> opt = editor.getCaretBounds();
            if (opt.isPresent()) {
                Bounds b = opt.get(); // these are already in screen coords for RichTextFX
                return new double[] { b.getMinX(), b.getMaxY() };
            }

            // Fallback: use the editor's own screen bounds + a rough estimate
            Bounds editorScreen = editor.localToScreen(editor.getBoundsInLocal());
            if (editorScreen != null) {
                return new double[] { editorScreen.getMinX() + 20,
                        editorScreen.getMinY() + 60 };
            }
        } catch (Exception ex) {
            System.err.println("[SuggestionPopup] CodeArea caret bounds error: " + ex.getMessage());
        }
        return null;
    }

    /**
     * Returns [screenX, screenY] for a TextArea by counting lines.
     * JavaFX doesn't expose the caret pixel location for TextArea directly,
     * so we estimate it from line number × line height.
     */
    private static double[] getCaretScreenXY(TextArea editor) {
        try {
            int caretPos = editor.getCaretPosition();
            String text = editor.getText();
            String before = text.substring(0, Math.min(caretPos, text.length()));

            // Count which line the caret is on (0-based)
            int lineNum = before.split("\n", -1).length - 1;

            // Estimate column (chars from last newline)
            int lastNL = before.lastIndexOf('\n');
            int colNum = (lastNL == -1) ? caretPos : caretPos - lastNL - 1;

            Bounds b = editor.localToScreen(editor.getBoundsInLocal());
            if (b == null)
                return null;

            // Typical metrics for Consolas 16px
            double lineHeight = 22.0;
            double charWidth = 9.6;
            double topPad = 8.0;
            double leftPad = 8.0;

            double x = b.getMinX() + leftPad + colNum * charWidth;
            double y = b.getMinY() + topPad + (lineNum + 1) * lineHeight;

            return new double[] { x, y };
        } catch (Exception ex) {
            System.err.println("[SuggestionPopup] TextArea caret bounds error: " + ex.getMessage());
        }
        return null;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // SELECTION HELPERS
    // ─────────────────────────────────────────────────────────────────────────

    public void selectCurrent() {
        SuggestionProvider.Suggestion selected = suggestionList.getSelectionModel().getSelectedItem();
        if (selected != null) {
            fireInsertSuggestion(selected);
            hide();
        }
    }

    public SuggestionProvider.Suggestion getSelected() {
        return suggestionList.getSelectionModel().getSelectedItem();
    }

    public void selectPrevious() {
        int i = suggestionList.getSelectionModel().getSelectedIndex();
        if (i > 0) {
            suggestionList.getSelectionModel().selectPrevious();
            suggestionList.scrollTo(i - 1);
        }
    }

    public void selectNext() {
        int i = suggestionList.getSelectionModel().getSelectedIndex();
        int size = suggestionList.getItems().size();
        if (i < size - 1) {
            suggestionList.getSelectionModel().selectNext();
            suggestionList.scrollTo(i + 1);
        }
    }

    public boolean isSuggestionShowing() {
        return isShowing();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // INSERT CALLBACK
    // ─────────────────────────────────────────────────────────────────────────

    private Runnable onInsertSuggestion = null;
    private SuggestionProvider.Suggestion lastSuggestion = null;

    public void setOnInsertSuggestion(Runnable callback) {
        this.onInsertSuggestion = callback;
    }

    private void fireInsertSuggestion(SuggestionProvider.Suggestion suggestion) {
        this.lastSuggestion = suggestion;
        if (onInsertSuggestion != null)
            onInsertSuggestion.run();
    }

    public SuggestionProvider.Suggestion getLastSuggestion() {
        return lastSuggestion;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CELL RENDERER
    // ─────────────────────────────────────────────────────────────────────────

    private class SuggestionCell extends ListCell<SuggestionProvider.Suggestion> {

        public SuggestionCell() {
        }

        @Override
        protected void updateItem(SuggestionProvider.Suggestion item, boolean empty) {
            super.updateItem(item, empty);

            if (empty || item == null) {
                setGraphic(null);
                setText(null);
                setStyle("");
                return;
            }

            // Get display text and build styled node
            String displayText = item.getDisplay();
            
            // For functions: show template with empty parameters (use code/key for detection)
            if ("Function".equals(item.getCategory())) {
                displayText = FunctionProvider.getFunctionTemplate(item.getCode());
            }

            // Build styled node that renders [SUB:...] and [SUP:...] markers
            javafx.scene.Node graphic = buildStyledNode(displayText, isSelected(), darkTheme);

            // Right-side readable description
            javafx.scene.control.Label descriptionLabel = new javafx.scene.control.Label(item.getDescription());
            descriptionLabel.setWrapText(false);
            descriptionLabel.setStyle("-fx-font-family: 'Consolas'; -fx-font-size: 11;");
                descriptionLabel.setTextFill(javafx.scene.paint.Color.web(
                    isSelected()
                        ? (darkTheme ? "#dbeaf8" : "#e7f8f8")
                        : (darkTheme ? DARK_DESCRIPTION_TEXT : LIGHT_DESCRIPTION_TEXT)));
            descriptionLabel.setMaxWidth(220);
            descriptionLabel.setTextOverrun(javafx.scene.control.OverrunStyle.ELLIPSIS);
            descriptionLabel.setAlignment(javafx.geometry.Pos.CENTER_RIGHT);

            javafx.scene.layout.Region spacer = new javafx.scene.layout.Region();
            javafx.scene.layout.HBox.setHgrow(spacer, javafx.scene.layout.Priority.ALWAYS);

            // Build complete cell with icon + text
            javafx.scene.layout.HBox cellContent = new javafx.scene.layout.HBox();
            cellContent.setAlignment(javafx.geometry.Pos.CENTER_LEFT);
            cellContent.setSpacing(8);

            // Add category icon
            javafx.scene.image.ImageView icon = getCategoryIcon(item.getCategory());
            cellContent.getChildren().add(icon);

            // Add styled text content and push description to the right
            cellContent.getChildren().add(graphic);
            cellContent.getChildren().add(spacer);
            cellContent.getChildren().add(descriptionLabel);

            setPadding(new javafx.geometry.Insets(6, 8, 6, 8));
            setGraphic(cellContent);

            if (isSelected()) {
                setStyle("-fx-background-color: " + (darkTheme ? DARK_SELECTION_BG : LIGHT_SELECTION_BG)
                        + "; -fx-text-fill: #ffffff;");
            } else {
                setStyle("-fx-background-color: " + (darkTheme ? DARK_POPUP_BG : LIGHT_POPUP_BG)
                        + "; -fx-text-fill: " + (darkTheme ? DARK_POPUP_TEXT : LIGHT_POPUP_TEXT) + ";");
            }
        }
    }
    
    /**
     * Build a styled JavaFX node from display text containing [SUB:...] and [SUP:...] markers.
     * - [SUB:content] → 9px font, cyan (#7ec8e3), translateY +5 (shifts down)
     * - [SUP:content] → 9px font, yellow-green (#b5cea8), translateY -5 (shifts up)
     * - Plain text → 13px font, normal color (#d4d4d4 or selected variant)
     */
    private static javafx.scene.Node buildStyledNode(String displayText, boolean isSelected, boolean darkTheme) {
        javafx.scene.layout.HBox hbox = new javafx.scene.layout.HBox();
        hbox.setAlignment(javafx.geometry.Pos.CENTER_LEFT);
        hbox.setSpacing(0);
        
        if (displayText == null || displayText.isEmpty()) {
            return hbox;
        }
        
        int idx = 0;
        while (idx < displayText.length()) {
            // Check for [SUB: marker
            if (displayText.startsWith("[SUB:", idx)) {
                int endIdx = displayText.indexOf("]", idx);
                if (endIdx != -1) {
                    String subContent = displayText.substring(idx + 5, endIdx);
                    javafx.scene.text.Text subText = new javafx.scene.text.Text(subContent);
                    subText.setFont(javafx.scene.text.Font.font("Consolas", 9));
                        subText.setFill(javafx.scene.paint.Color.web(isSelected
                            ? (darkTheme ? "#d4ebf5" : "#a8d8ea")
                            : (darkTheme ? DARK_MARKER_SUB : LIGHT_MARKER_SUB)));
                    subText.setTranslateY(5); // Shift down
                    hbox.getChildren().add(subText);
                    idx = endIdx + 1;
                    continue;
                }
            }
            
            // Check for [SUP: marker
            if (displayText.startsWith("[SUP:", idx)) {
                int endIdx = displayText.indexOf("]", idx);
                if (endIdx != -1) {
                    String supContent = displayText.substring(idx + 5, endIdx);
                    javafx.scene.text.Text supText = new javafx.scene.text.Text(supContent);
                    supText.setFont(javafx.scene.text.Font.font("Consolas", 9));
                        supText.setFill(javafx.scene.paint.Color.web(isSelected
                            ? (darkTheme ? "#e4efbe" : "#d4e6b5")
                            : (darkTheme ? DARK_MARKER_SUP : LIGHT_MARKER_SUP)));
                    supText.setTranslateY(-5); // Shift up
                    hbox.getChildren().add(supText);
                    idx = endIdx + 1;
                    continue;
                }
            }
            
            // Find next marker
            int nextMarker = displayText.length();
            int subMarker = displayText.indexOf("[SUB:", idx);
            int supMarker = displayText.indexOf("[SUP:", idx);
            if (subMarker != -1) nextMarker = Math.min(nextMarker, subMarker);
            if (supMarker != -1) nextMarker = Math.min(nextMarker, supMarker);
            
            // Add plain text segment
            if (nextMarker > idx) {
                String plainSegment = displayText.substring(idx, nextMarker);
                javafx.scene.text.Text plainText = new javafx.scene.text.Text(plainSegment);
                plainText.setFont(javafx.scene.text.Font.font("Consolas", 13));
                plainText.setFill(javafx.scene.paint.Color.web(isSelected ? "#ffffff"
                    : (darkTheme ? DARK_POPUP_TEXT : LIGHT_POPUP_TEXT)));
                hbox.getChildren().add(plainText);
                idx = nextMarker;
            } else {
                // Skip this character if it doesn't match any marker
                idx++;
            }
        }
        
        return hbox.getChildren().isEmpty() ? new javafx.scene.text.Text(displayText) : hbox;
    }

    /**
     * Get a category icon ImageView for the suggestion type.
     * - StyledVariable: variable icon
     * - Function: function icon
     * - Variable: variable icon
     * - Keyword: variable icon
     * - Others: variable icon (fallback)
     */
    private static javafx.scene.image.ImageView getCategoryIcon(String category) {
        String iconPath;

        if ("StyledVariable".equals(category) || "Variable".equals(category)) {
            iconPath = "/icons/icons8-variable-50.png";
        } else if ("Function".equals(category)) {
            iconPath = "/icons/icons8-function-49.png";
        } else {
            iconPath = "/icons/icons8-variable-50.png";  // Fallback
        }

        try {
            javafx.scene.image.Image img = new javafx.scene.image.Image(
                SuggestionPopup.class.getResourceAsStream(iconPath)
            );
            javafx.scene.image.ImageView imgView = new javafx.scene.image.ImageView(img);
            imgView.setFitWidth(16);
            imgView.setFitHeight(16);
            imgView.setPreserveRatio(true);
            return imgView;
        } catch (Exception e) {
            // Fallback: return empty image view if icon fails to load
            javafx.scene.image.ImageView fallback = new javafx.scene.image.ImageView();
            fallback.setFitWidth(16);
            fallback.setFitHeight(16);
            return fallback;
        }
    }
} 