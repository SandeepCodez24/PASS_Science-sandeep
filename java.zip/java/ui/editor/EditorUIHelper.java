package ui.editor;

import java.awt.Desktop;
import java.io.IOException;
import java.nio.file.Path;
import java.util.Set;

import javafx.scene.control.Alert;
import ui.UI_Main;
import ui.managers.ToolbarManager;

/**
 * UI utility functions for the editor.
 * Handles common UI operations like error dialogs and file extensions.
 */
public class EditorUIHelper {

    private static final Set<String> EXTERNAL_FILE_EXTENSIONS = Set.of(
            ".pdf", ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".ico", ".svg",
            ".doc", ".docx", ".ppt", ".pptx", ".xls", ".xlsx",
            ".zip", ".rar", ".7z", ".class", ".jar", ".exe");

    /**
     * Updates the footer with current file path and name.
     * @param ide the IDE controller
     * @param path the file path (can be null for unsaved files)
     * @param name the file name or label
     */
    public static void updateFooter(UI_Main ide, Path path, String name) {
        ToolbarManager.updateQuickPath(path != null ? path.getParent() : ide.currentFolder);
        ide.footerFileLabel.setText(path != null ? path.toAbsolutePath().toString() : "");
    }

    /**
     * Shows an error alert dialog.
     * @param title the error title
     * @param e the exception
     */
    public static void showError(String title, Exception e) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(title);
        alert.setContentText(e.getMessage());
        alert.showAndWait();
    }

    /**
     * Checks if a file should be opened in the system application.
     * Returns true for PDFs, images, Office docs, archives, etc.
     * @param path the file path
     * @return true if file should open externally
     */
    public static boolean shouldOpenExternally(Path path) {
        String name = path.getFileName() != null ? path.getFileName().toString().toLowerCase() : "";
        int idx = name.lastIndexOf('.');
        if (idx < 0) {
            return false;
        }
        String ext = name.substring(idx);
        return EXTERNAL_FILE_EXTENSIONS.contains(ext);
    }

    /**
     * Opens a file in the system's default application.
     * @param ide the IDE controller
     * @param path the file path
     * @throws IOException if Desktop is not supported or open fails
     */
    public static void openInSystemApp(UI_Main ide, Path path) throws IOException {
        if (!Desktop.isDesktopSupported()) {
            throw new IOException("Desktop integration is not supported on this system.");
        }
        Desktop.getDesktop().open(path.toFile());
        ide.console.appendText("Opened in default app: " + path + "\n");
    }

    /**
     * Determines the file extension from a path.
     * Supports .upi, .cpp, .c, .py, .java, defaults to .txt
     * @param path the file path
     * @return the file extension
     */
    public static String determineFileExtension(Path path) {
        String pathStr = path.toString();
        if (pathStr.endsWith(".nc")) return ".nc";
        return ".txt";
    }
}
