package ui.editor.homeTab;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import javafx.scene.control.Tab;
import ui.UI_Main;
import ui.editor.EditorTabFactory;
import ui.editor.EditorUIHelper;
/**
 * Handles creation of new files with templates.
 * Creates plain text, UPI, Java class, and function files.
 */
public class EditorFileCreator {

    private static final String CPP_DEMO_TEMPLATE = "#include <iostream>\n"
            + "\n"
            + "int main() {\n"
            + "    int i = 1;\n"
            + "    while (i <= 5) {\n"
            + "        std::cout << \"Count: \" << i << std::endl;\n"
            + "        ++i;\n"
            + "    }\n"
            + "    return 0;\n"
            + "}\n";

    /**
     * Creates a new plain text file in a new tab.
     * @param ide the IDE controller
     */
    public static void newPlainTextFile(UI_Main ide) {
        ide.currentFolder = ide.currentFolder != null ? ide.currentFolder 
                : Path.of(System.getProperty("user.home"));

        String name = getNextUntitledName(ide.editorTabs, ".txt");
        Tab tab = EditorTabFactory.createEditorTab(ide, name, "", ".txt");
        ide.editorTabs.getTabs().add(tab);
        ide.editorTabs.getSelectionModel().select(tab);

        EditorUIHelper.updateFooter(ide, null, name);
    }

    /**
     * Creates a new UPI file in a new tab.
     * @param ide the IDE controller
     */
    public static void newUPIFile(UI_Main ide) {
        ide.currentFolder = ide.currentFolder != null ? ide.currentFolder 
                : Path.of(System.getProperty("user.home"));

        String name = getNextUntitledName(ide.editorTabs, ".nc");
        Tab tab = EditorTabFactory.createEditorTab(ide, name, "", ".nc");
        ide.editorTabs.getTabs().add(tab);
        ide.editorTabs.getSelectionModel().select(tab);

        EditorUIHelper.updateFooter(ide, null, name);
    }

    /**
     * Creates a new Java class file with template in a new tab.
     * @param ide the IDE controller
     */
    public static void newClassFile(UI_Main ide) {
        ide.currentFolder = ide.currentFolder != null ? ide.currentFolder 
                : Path.of(System.getProperty("user.home"));

        String name = getNextUntitledName(ide.editorTabs, ".java");

        String template = "public class UntitledClass {\n"
                + "\n"
                + "    private int property1;\n"
                + "\n"
                + "    public UntitledClass(int inputArg1, int inputArg2) {\n"
                + "        this.property1 = inputArg1 + inputArg2;\n"
                + "    }\n"
                + "\n"
                + "    public int method1(int inputArg) {\n"
                + "        return property1 + inputArg;\n"
                + "    }\n"
                + "\n"
                + "}\n";

        Tab tab = EditorTabFactory.createEditorTab(ide, name, template, ".java");
        ide.editorTabs.getTabs().add(tab);
        ide.editorTabs.getSelectionModel().select(tab);

        EditorUIHelper.updateFooter(ide, null, name);
    }

    /**
     * Creates a new Java function file with template in a new tab.
     * @param ide the IDE controller
     */
    public static void newFunctionFile(UI_Main ide) {
        ide.currentFolder = ide.currentFolder != null ? ide.currentFolder 
                : Path.of(System.getProperty("user.home"));

        String name = getNextUntitledName(ide.editorTabs, ".java");

        String template = "public class UntitledFunction {\n"
                + "\n"
                + "    public static int myFunction(int inputArg) {\n"
                + "        return inputArg;\n"
                + "    }\n"
                + "\n"
                + "}\n";

        Tab tab = EditorTabFactory.createEditorTab(ide, name, template, ".java");
        ide.editorTabs.getTabs().add(tab);
        ide.editorTabs.getSelectionModel().select(tab);

        EditorUIHelper.updateFooter(ide, null, name);
    }

    /**
     * Creates and opens a C++ demo file.
     * Uses existing file if it already exists.
     * @param ide the IDE controller
     */
    public static void integrateDemoCpp(UI_Main ide) {
        Path baseFolder = ide.currentFolder != null ? ide.currentFolder 
                : Path.of(System.getProperty("user.home"));
        Path demoFile = baseFolder.resolve("demo.cpp");

        try {
            if (!Files.exists(demoFile)) {
                Files.writeString(demoFile, CPP_DEMO_TEMPLATE, StandardCharsets.UTF_8);
                ide.console.appendText("Created C++ demo: " + demoFile + "\n");
            } else {
                ide.console.appendText("Using existing C++ demo: " + demoFile + "\n");
            }

            EditorFileOpener.openFileDirectly(ide, demoFile);
        } catch (IOException e) {
            EditorUIHelper.showError("demo.cpp integration failed", e);
        }
    }

    /**
     * Gets the next untitled file name based on existing tabs.
     * Increments count if multiple untitled files exist.
     * @param tabPane the editor tab pane
     * @param ext the file extension
     * @return a unique untitled file name
     */
    private static String getNextUntitledName(javafx.scene.control.TabPane tabPane, String ext) {
        int count = 0;

        for (javafx.scene.control.Tab t : tabPane.getTabs()) {
            String name = t.getText().replace("*", "");
            if (name.startsWith("Untitled") && name.endsWith(ext)) {
                count++;
            }
        }

        if (count == 0)
            return "Untitled" + ext;
        else
            return "Untitled" + count + ext;
    }
}
