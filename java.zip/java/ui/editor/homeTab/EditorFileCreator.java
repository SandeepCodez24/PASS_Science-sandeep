package ui.editor.homeTab;

import java.nio.file.Path;

import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import ui.UI_Main;
import ui.editor.EditorTabFactory;
import ui.editor.EditorUIHelper;

/**
 * Handles creation of new files with templates.
 *
 * <p>Four operations are supported:
 * <ul>
 *   <li>plain text file ({@code .txt})</li>
 *   <li>empty Neural Code file ({@code .nc})</li>
 *   <li>Neural Code function skeleton ({@code .nc})</li>
 *   <li>Neural Code class skeleton ({@code .nc})</li>
 * </ul>
 */
public class EditorFileCreator {

    private static final String TXT_EXT = ".txt";
    private static final String NC_EXT = ".nc";

    private static final String UNTITLED = "Untitled";

    /** Skeleton inserted when a new Neural Code function is created. */
    private static final String FUNCTION_TEMPLATE = """
            function (output arg) = FunctionName(input args)
                "operation for mapping input and output args;"
            fnend
            """;

    /** Skeleton inserted when a new Neural Code class is created. */
    private static final String CLASS_TEMPLATE = """
            class ClassName1()

                function base(input args)
                    "operation for defining the default values;"
                fnend

                function (output args) = FunctionName1(input args)
                    "operation for mapping input and output args;"
                fnend

                function (output args) = FunctionName2(input args)
                    "operation for mapping input and output args;"
                fnend

            csend
            """;

    private EditorFileCreator() {
        // utility class
    }

    /**
     * Creates a new plain text file in a new tab.
     * @param ide the IDE controller
     */
    public static void newPlainTextFile(UI_Main ide) {
        createTab(ide, TXT_EXT, "");
    }

    /**
     * Creates a new empty Neural Code file in a new tab.
     * @param ide the IDE controller
     */
    public static void newNeuralCodeFile(UI_Main ide) {
        createTab(ide, NC_EXT, "");
    }

    /**
     * Creates a new Neural Code function file with template in a new tab.
     * @param ide the IDE controller
     */
    public static void newFunctionFile(UI_Main ide) {
        createTab(ide, NC_EXT, FUNCTION_TEMPLATE);
    }

    /**
     * Creates a new Neural Code class file with template in a new tab.
     * @param ide the IDE controller
     */
    public static void newClassFile(UI_Main ide) {
        createTab(ide, NC_EXT, CLASS_TEMPLATE);
    }

    /**
     * Legacy entry point kept so existing call sites keep compiling.
     * @param ide the IDE controller
     * @deprecated use {@link #newNeuralCodeFile(UI_Main)} instead
     */
    @Deprecated
    public static void newUPIFile(UI_Main ide) {
        newNeuralCodeFile(ide);
    }

    /**
     * Opens a new editor tab holding the given template.
     * Falls back to the user home folder when no project folder is active.
     * @param ide the IDE controller
     * @param ext the file extension, including the leading dot
     * @param template the initial editor content, may be empty
     */
    private static void createTab(UI_Main ide, String ext, String template) {
        ide.currentFolder = ide.currentFolder != null ? ide.currentFolder
                : Path.of(System.getProperty("user.home"));

        String name = getNextUntitledName(ide.editorTabs, ext);

        Tab tab = EditorTabFactory.createEditorTab(ide, name, template, ext);
        ide.editorTabs.getTabs().add(tab);
        ide.editorTabs.getSelectionModel().select(tab);

        EditorUIHelper.updateFooter(ide, null, name);
    }

    /**
     * Gets the next untitled file name that is not already open.
     * Probes Untitled.ext, Untitled1.ext, Untitled2.ext and so on, so closing a
     * middle tab cannot produce a duplicate name.
     * @param tabPane the editor tab pane
     * @param ext the file extension
     * @return a unique untitled file name
     */
    private static String getNextUntitledName(TabPane tabPane, String ext) {
        String candidate = UNTITLED + ext;

        for (int i = 1; isNameTaken(tabPane, candidate); i++) {
            candidate = UNTITLED + i + ext;
        }

        return candidate;
    }

    /**
     * Checks whether a tab with the given title is already open.
     * The dirty marker is stripped before comparing.
     * @param tabPane the editor tab pane
     * @param name the candidate file name
     * @return true when the name is in use
     */
    private static boolean isNameTaken(TabPane tabPane, String name) {
        for (Tab t : tabPane.getTabs()) {
            String text = t.getText();
            if (text != null && text.replace("*", "").equals(name)) {
                return true;
            }
        }
        return false;
    }
}
