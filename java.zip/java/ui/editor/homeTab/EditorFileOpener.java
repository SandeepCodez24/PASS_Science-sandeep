package ui.editor.homeTab;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import javafx.scene.control.Tab;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import ui.UI_Main;
import ui.editor.EditorFileInfo;
import ui.editor.EditorTabFactory;
import ui.editor.EditorUIHelper;
import ui.editor.navigation.NavigationActions;
import ui.editor.navigation.RootFolderStore;
import ui.managers.ProjectManager;

/**
 * Handles opening files and folders in the editor.
 * Supports both file dialog and direct file opening.
 */
public class EditorFileOpener {

    /** Extension filter used by the ribbon's default Open click. */
    private static final FileChooser.ExtensionFilter NC_FILTER =
            new FileChooser.ExtensionFilter("Neural Code (*.nc)", "*.nc");

    /**
     * Opens a Neural Code file, and nothing else. This is what a click on the
     * Open icon does; the drop-down's "Open File" entry uses
     * {@link #openFile(UI_Main)} when any extension is wanted.
     *
     * @param ide the IDE controller
     */
    public static void openNcFile(UI_Main ide) {
        FileChooser fc = new FileChooser();
        fc.setTitle("");
        fc.getExtensionFilters().add(NC_FILTER);
        fc.setSelectedExtensionFilter(NC_FILTER);
        applyInitialDirectory(ide, fc);

        var file = fc.showOpenDialog(ide.stage);
        if (file != null) {
            openFileDirectly(ide, file.toPath());
        }
    }

    /**
     * Opens a file via file chooser dialog, any extension.
     *
     * @param ide the IDE controller
     */
    public static void openFile(UI_Main ide) {
        FileChooser fc = new FileChooser();
        fc.setTitle("Open File");
        applyInitialDirectory(ide, fc);

        var file = fc.showOpenDialog(ide.stage);
        if (file != null) {
            openFileDirectly(ide, file.toPath());
        }
    }

    /**
     * Asks for a folder and loads it as the project, then records it as the
     * project root so "Open Last Project" and "Save Root" have something to
     * point at.
     *
     * @param ide the IDE controller
     */
    public static void openProjectFolder(UI_Main ide) {
        DirectoryChooser dc = new DirectoryChooser();
        dc.setTitle("Open Folder");

        Path start = HomeFilesProject.root(ide);
        if (Files.isDirectory(start)) {
            dc.setInitialDirectory(start.toFile());
        }

        var folder = dc.showDialog(ide.stage);
        if (folder == null) {
            return;
        }
        loadFolderAsProject(ide, folder.toPath());
    }

    /**
     * Re-opens the folder that was last loaded as a project, across restarts.
     *
     * @param ide the IDE controller
     */
    public static void openLastProject(UI_Main ide) {
        Path last = HomeFilesProject.lastProject();
        if (last == null) {
            NavigationActions.say("No previous project to open.");
            return;
        }
        loadFolderAsProject(ide, last);
    }

    /**
     * Points the project tree at the root folder. Used by Open &gt; Open Root
     * Folder and by the Root button on the navigation bar, so the two always
     * agree.
     *
     * <p>
     * Resolution order:
     * </p>
     * <ol>
     * <li>the root the user declared with the Root button's
     * "Set current folder as root" ({@link RootFolderStore});</li>
     * <li>failing that, the project folder that was active the last time a
     * file was run -- the old sole meaning of "root";</li>
     * <li>failing that, the folder opened as a project this session, with a
     * note in the Command Window saying why.</li>
     * </ol>
     *
     * <p>
     * A declared root that is on record but cannot be reached right now (a
     * disconnected drive, say) is reported by name before falling back, so the
     * user is not left wondering why the root did not open.
     * </p>
     *
     * @param ide the IDE controller
     */
    public static void openRootFolder(UI_Main ide) {
        Path declared = RootFolderStore.declared();
        if (declared != null) {
            loadFolderAsProject(ide, declared);
            return;
        }

        Path unreachable = RootFolderStore.stored();
        String prefix = (unreachable != null)
                ? "Root folder is not reachable: " + unreachable + ". "
                : "No root folder set. ";

        Path runRoot = HomeFilesProject.runRoot();
        if (runRoot != null) {
            NavigationActions.say(prefix + "Showing the last run folder.");
            loadFolderAsProject(ide, runRoot);
            return;
        }

        Path fallback = HomeFilesProject.sessionRoot();
        if (fallback != null) {
            NavigationActions.say(prefix + "No file has been run yet; showing the current project folder.");
            loadFolderAsProject(ide, fallback);
            return;
        }

        NavigationActions.say(prefix
                + "Use the Root button's menu to set the current folder as root.");
    }

    /**
     * Loads a folder into the project tree, updates the breadcrumb bar, and
     * remembers it as the last project.
     *
     * <p>
     * Note the delegation to {@link ProjectManager#loadProjectFromPath}. The
     * earlier version called {@code refreshProjectTree}, which rebuilds from
     * the tree's <em>existing</em> root and therefore ignored the folder just
     * chosen &ndash; that is why Open Folder printed its message without
     * moving anything. {@code loadProjectFromPath} installs a new root and
     * calls {@code ToolbarManager.updateQuickPath}, so the tree and the
     * breadcrumb move together.
     * </p>
     *
     * @param ide    the IDE controller
     * @param folder the folder to load
     */
    public static void loadFolderAsProject(UI_Main ide, Path folder) {
        if (folder == null || !Files.isDirectory(folder)) {
            NavigationActions.say("Not a folder: " + folder);
            return;
        }

        Path normalised = folder.toAbsolutePath().normalize();

        ProjectManager.loadProjectFromPath(ide, normalised);
        HomeFilesProject.remember(normalised);
    }

    /**
     * Opens a file directly by path.
     * Handles external files, checks for already-open files, and creates the
     * appropriate tab.
     *
     * @param ide  the IDE controller
     * @param path the file path
     */
    public static void openFileDirectly(UI_Main ide, Path path) {
        try {
            // Check if should open externally
            if (EditorUIHelper.shouldOpenExternally(path)) {
                EditorUIHelper.openInSystemApp(ide, path);
                return;
            }

            // Check if file is already open
            for (Tab t : ide.editorTabs.getTabs()) {
                EditorFileInfo info = (EditorFileInfo) t.getUserData();
                if (info != null && path.equals(info.path)) {
                    ide.editorTabs.getSelectionModel().select(t);
                    EditorUIHelper.updateFooter(ide, path, t.getText());
                    return;
                }
            }

            // Read file content
            String content = Files.readString(path);
            String ext = EditorUIHelper.determineFileExtension(path);

            // Create and add tab
            Tab tab = EditorTabFactory.createEditorTab(ide, path.getFileName().toString(), content, ext);
            tab.setUserData(new EditorFileInfo(path, ext));

            ide.editorTabs.getTabs().add(tab);
            ide.editorTabs.getSelectionModel().select(tab);

            // Update IDE state. This moves the file-chooser's start directory
            // only; it is not a project load, so the tree and the remembered
            // root are left alone.
            ide.currentFolder = path.getParent();
            EditorUIHelper.updateFooter(ide, path, path.getFileName().toString());

        } catch (IOException e) {
            EditorUIHelper.showError("Open failed", e);
        }
    }

    /**
     * Points a FileChooser at the folder the editor is currently on, when that
     * is still a real directory.
     *
     * @param ide the IDE controller
     * @param fc  the chooser to configure
     */
    private static void applyInitialDirectory(UI_Main ide, FileChooser fc) {
        if (ide.currentFolder != null && Files.isDirectory(ide.currentFolder)) {
            fc.setInitialDirectory(ide.currentFolder.toFile());
        }
    }
}
