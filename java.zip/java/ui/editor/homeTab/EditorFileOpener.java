package ui.editor.homeTab;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import javafx.scene.control.Tab;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import ui.UI_Main;
import ui.editor.EditorFileInfo;
import ui.editor.EditorTabFactory;
import ui.editor.EditorUIHelper;
import ui.managers.ProjectManager;

/**
 * Handles opening files in the editor.
 * Supports both file dialog and direct file opening.
 */
public class EditorFileOpener {

    /** Extension filter used by the ribbon's default Open click. */
    private static final FileChooser.ExtensionFilter NC_FILTER =
            new FileChooser.ExtensionFilter("Neural Code (*.nc)", "*.nc");

    /**
     * Opens a Neural Code file, and nothing else. This is what a click on the
     * Open icon does; the drop-down's "Open File" entry uses
     * {@link #openFile(UI_Main)} when any extension is wanted.
     *
     * @param ide the IDE controller
     */
    public static void openNcFile(UI_Main ide) {
        FileChooser fc = new FileChooser();
        fc.setTitle("Open Neural Code File");
        fc.getExtensionFilters().add(NC_FILTER);
        fc.setSelectedExtensionFilter(NC_FILTER);

        if (ide.currentFolder != null && Files.isDirectory(ide.currentFolder)) {
            fc.setInitialDirectory(ide.currentFolder.toFile());
        }

        var file = fc.showOpenDialog(ide.stage);
        if (file != null) {
            openFileDirectly(ide, file.toPath());
        }
    }

    /**
     * Asks for a folder and loads it as the project, then records it as the
     * project root so "Open Last Project", "Open Root Folder" and
     * "Save Root" have something to point at.
     *
     * @param ide the IDE controller
     */
    public static void openProjectFolder(UI_Main ide) {
        DirectoryChooser dc = new DirectoryChooser();
        dc.setTitle("Open Folder");

        Path start = HomeFilesProject.root(ide);
        if (Files.isDirectory(start)) {
            dc.setInitialDirectory(start.toFile());
        }

        var folder = dc.showDialog(ide.stage);
        if (folder == null) {
            return;
        }
        loadFolderAsProject(ide, folder.toPath());
    }

    /**
     * Re-opens the folder that was last loaded as a project, across restarts.
     *
     * @param ide the IDE controller
     */
    public static void openLastProject(UI_Main ide) {
        Path last = HomeFilesProject.lastProject();
        if (last == null) {
            ide.console.appendText("No previous project to open.\n");
            return;
        }
        loadFolderAsProject(ide, last);
    }

    /**
     * Points the project tree back at the current project's root folder,
     * undoing any drilling down that has happened since it was opened.
     *
     * @param ide the IDE controller
     */
    public static void openRootFolder(UI_Main ide) {
        loadFolderAsProject(ide, HomeFilesProject.root(ide));
    }

    /**
     * Loads a folder into the project tree and remembers it as the root.
     *
     * NOTE: this sets {@code ide.currentFolder} and refreshes the tree, which
     * is enough if ProjectManager derives the tree from that field. If
     * ProjectManager holds a separate root of its own, call its setter here
     * instead -- that is the one line in this file that depends on internals
     * not visible from the ribbon.
     *
     * @param ide    the IDE controller
     * @param folder the folder to load
     */
    public static void loadFolderAsProject(UI_Main ide, Path folder) {
        if (folder == null || !Files.isDirectory(folder)) {
            ide.console.appendText("Not a folder: " + folder + "\n");
            return;
        }
        ide.currentFolder = folder;
        HomeFilesProject.remember(folder);
        ProjectManager.refreshProjectTree(ide);
        ide.console.appendText("Opened folder: " + folder + "\n");
    }

    /**
     * Opens a file via file chooser dialog.
     * @param ide the IDE controller
     */
    public static void openFile(UI_Main ide) {
        FileChooser fc = new FileChooser();
        fc.setTitle("Open File");

        if (ide.currentFolder != null && Files.isDirectory(ide.currentFolder)) {
            fc.setInitialDirectory(ide.currentFolder.toFile());
        }

        var file = fc.showOpenDialog(ide.stage);
        if (file != null) {
            openFileDirectly(ide, file.toPath());
        }
    }

    /**
     * Opens a file directly by path.
     * Handles external files, checks for already-open files, and creates appropriate tab.
     * @param ide the IDE controller
     * @param path the file path
     */
    public static void openFileDirectly(UI_Main ide, Path path) {
        try {
            // Check if should open externally
            if (EditorUIHelper.shouldOpenExternally(path)) {
                EditorUIHelper.openInSystemApp(ide, path);
                return;
            }

            // Check if file is already open
            for (Tab t : ide.editorTabs.getTabs()) {
                EditorFileInfo info = (EditorFileInfo) t.getUserData();
                if (info != null && path.equals(info.path)) {
                    ide.editorTabs.getSelectionModel().select(t);
                    EditorUIHelper.updateFooter(ide, path, t.getText());
                    return;
                }
            }

            // Read file content
            String content = Files.readString(path);
            String ext = EditorUIHelper.determineFileExtension(path);

            // Create and add tab
            Tab tab = EditorTabFactory.createEditorTab(ide, path.getFileName().toString(), content, ext);
            tab.setUserData(new EditorFileInfo(path, ext));

            ide.editorTabs.getTabs().add(tab);
            ide.editorTabs.getSelectionModel().select(tab);

            // Update IDE state
            ide.currentFolder = path.getParent();
            EditorUIHelper.updateFooter(ide, path, path.getFileName().toString());

        } catch (IOException e) {
            EditorUIHelper.showError("Open failed", e);
        }
    }
}
