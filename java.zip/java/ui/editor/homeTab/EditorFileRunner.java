package ui.editor.homeTab;

import java.util.Locale;

import javafx.application.Platform;
import javafx.scene.control.Tab;

import language.syntax.syntax_checker.ErrorChecker;
import ui.UI_Main;
import ui.cli.CLI_Main;
import ui.editor.EditorFileInfo;
import ui.editor.EditorTextOperations;
import ui.managers.EditorManager;

/**
 * Runs the file in the active Editor tab.
 *
 * <p><b>New model.</b> There is exactly ONE persistent {@code nc.exe} backend,
 * owned by {@link CLI_Main}. Running a script no longer spawns a separate
 * process and no longer feeds the file line-by-line (which is what produced the
 * burst of {@code >>} prompts). Instead we save the file and ask the shared
 * backend to execute it <b>by name</b> — exactly like typing
 * {@code script_01.nc} in the Command Window — so the editor and the CLI keep
 * one global workspace.</p>
 *
 * <p>All the old demo/compile machinery (g++, gcc, javac, main.cpp demo,
 * {@code UPIEngine}, {@code VariableFileWriter}) has been removed.</p>
 */
public final class EditorFileRunner {

    private EditorFileRunner() {
    }

    /**
     * Saves the active tab, aborts on editor-detected errors, and runs a
     * {@code .nc} file on the shared persistent backend.
     *
     * @param ide the IDE controller
     */
    public static void runCurrentFile(UI_Main ide) {
        if (ide == null || ide.editorTabs == null) {
            return;
        }
        Tab tab = ide.editorTabs.getSelectionModel().getSelectedItem();
        if (tab == null) {
            return;
        }
        EditorFileInfo info = (EditorFileInfo) tab.getUserData();
        if (info == null || info.path == null) {
            appendConsole(ide, "Cannot run: the active tab has no saved file yet.\n");
            return;
        }

        // 1) Editor-detected errors abort the run before anything is sent.
        String editorText = EditorTextOperations.getEditorText(tab);
        var report = ErrorChecker.analyzeErrors(editorText);
        if (report.getErrorCount() > 0) {
            appendConsole(ide, "Run aborted: " + report.getErrorCount()
                    + " error(s) in " + info.path.getFileName() + ".\n");
            return;
        }

        // 2) Only .nc files run on the shared interpreter.
        String ext = info.ext == null ? "" : info.ext.toLowerCase(Locale.ROOT);
        if (!".nc".equals(ext)) {
            appendConsole(ide, "Run supports .nc files only (got '"
                    + (ext.isEmpty() ? "?" : ext) + "').\n");
            return;
        }

        // 3) Persist to disk so the backend can resolve it by name.
        EditorManager.saveCurrentFile(ide);

        // 4) Execute on the SAME persistent backend by calling its name.
        CLI_Main.runScriptByName(ide, info.path.getFileName().toString());
    }

    /** Small helper so run-time messages land in the Command Window cleanly. */
    private static void appendConsole(UI_Main ide, String message) {
        if (ide == null || ide.console == null || message == null) {
            return;
        }
        Platform.runLater(() -> {
            ide.console.appendText(message);
            ide.inputStart = ide.console.getLength();
            ide.console.positionCaret(ide.console.getLength());
        });
    }

    /**
     * @deprecated The demo C++ integration has been removed. This no-op remains
     *             only so any lingering caller still compiles; delete the call.
     */
    @Deprecated
    public static void integrateDemoCpp(UI_Main ide) {
        // Intentionally does nothing.
    }
}
