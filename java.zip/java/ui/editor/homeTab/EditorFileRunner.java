package ui.editor.homeTab;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;

import javafx.scene.control.Tab;
import language.syntax.syntax_checker.ErrorChecker;
import ui.UI_Main;
import ui.cli.CLI_Main;
import ui.editor.EditorFileInfo;
import ui.editor.EditorTextOperations;
import ui.editor.navigation.NavigationActions;
import ui.managers.EditorManager;
import ui.managers.LanguageDesignManager;

/**
 * Executes the file in the <b>currently selected</b> editor tab.
 *
 * <h3>What changed</h3>
 * <ul>
 *   <li><b>The cleaned file is what runs.</b> The previous version generated
 *       {@code cleaned_Runfile.nc} and then handed the interpreter the
 *       <em>original</em> source file name, so the cleaned file was written and
 *       thrown away.</li>
 *   <li><b>The full pipeline is used.</b> It also called
 *       {@code SemanticEncoder.encode} directly, skipping
 *       {@code applySymbolReplacements}, so it encoded a different string than
 *       {@code LanguageDesignManager} does. Both now go through
 *       {@link LanguageDesignManager#writeSemanticFileFromUiCode}.</li>
 *   <li><b>Only the active tab runs.</b> The tab is resolved once, up front,
 *       and nothing here iterates over open tabs.</li>
 *   <li><b>The interpreter's working directory follows the file</b>, so a
 *       script run from temp still resolves sibling functions in the project
 *       folder.</li>
 *   <li><b>A run is recorded.</b> The project folder in force goes into the
 *       navigation bar's Back / Forward history and becomes the fallback root
 *       for Open Root Folder. {@code HomeFilesProject}'s comments always said
 *       the runner did this; until now it did not, so the fallback root was
 *       never set.</li>
 * </ul>
 */
public final class EditorFileRunner {

    private EditorFileRunner() {
    }

    /**
     * Saves and runs the file in the currently selected editor tab.
     *
     * @param ide the IDE controller
     */
    public static void runCurrentFile(UI_Main ide) {
        if (ide == null || ide.editorTabs == null) {
            return;
        }
        Tab tab = ide.editorTabs.getSelectionModel().getSelectedItem();
        if (tab == null) {
            return;
        }

        EditorFileInfo info = (EditorFileInfo) tab.getUserData();
        if (info == null || info.path == null) {
            CLI_Main.appendOutput("Cannot run: the active tab has no saved file yet.\n");
            CLI_Main.appendPrompt();
            return;
        }

        String editorText = EditorTextOperations.getEditorText(tab);
        var report = ErrorChecker.analyzeErrors(editorText);
        if (report.getErrorCount() > 0) {
            CLI_Main.appendOutput("Run aborted: " + report.getErrorCount()
                    + " error(s) in " + info.path.getFileName() + ".\n");
            CLI_Main.appendPrompt();
            return;
        }

        EditorManager.saveCurrentFile(ide);

        String extension = getExtension(info);
        if (".nc".equals(extension) || ".upi".equals(extension)) {
            executeUpiFile(ide, info);
        } else {
            CLI_Main.appendOutput("Run is not configured for file type '"
                    + (extension.isEmpty() ? "unknown" : extension) + "'.\n");
            CLI_Main.appendPrompt();
        }
    }

    /**
     * Compatibility entry point retained for existing callers.
     *
     * @param ide the IDE controller
     */
    public static void integrateDemoCpp(UI_Main ide) {
        // The old demo integration is intentionally no longer required.
    }

    // -----------------------------------------------------------------
    // Internals
    // -----------------------------------------------------------------

    private static void executeUpiFile(UI_Main ide, EditorFileInfo info) {
        try {
            String text = Files.readString(info.path, StandardCharsets.UTF_8);
            Path cleaned = LanguageDesignManager.buildSemanticPath(info);
            LanguageDesignManager.writeSemanticFileFromUiCode(text, cleaned);

            // Sibling functions and addpath entries are resolved against the
            // interpreter's working directory, which must follow the source
            // file rather than the temp folder the cleaned file lives in.
            Path parent = info.path.toAbsolutePath().getParent();
            if (parent != null) {
                CLI_Main.setWorkspaceDirectory(parent);
            }

            // The run is going ahead: record the project folder for Back /
            // Forward and as the fallback root. Guarded so a bookkeeping
            // failure can never stop the script from running.
            try {
                NavigationActions.recordRun(ide, parent);
            } catch (RuntimeException bookkeeping) {
                bookkeeping.printStackTrace();
            }

            // Echo the friendly name, execute the cleaned file.
            CLI_Main.runScript(ide, info.path.getFileName().toString(), cleaned);
        } catch (Exception e) {
            CLI_Main.appendOutput("NC execution failed: " + safeMessage(e) + "\n");
            CLI_Main.appendPrompt();
        }
    }

    private static String getExtension(EditorFileInfo info) {
        if (info.ext != null && !info.ext.isBlank()) {
            String extension = info.ext.toLowerCase(Locale.ROOT);
            return extension.startsWith(".") ? extension : "." + extension;
        }
        String name = info.path.getFileName().toString();
        int dot = name.lastIndexOf('.');
        return dot >= 0 ? name.substring(dot).toLowerCase(Locale.ROOT) : "";
    }

    private static String safeMessage(Exception exception) {
        String message = exception.getMessage();
        return message == null || message.isBlank()
                ? exception.getClass().getSimpleName()
                : message;
    }
}
