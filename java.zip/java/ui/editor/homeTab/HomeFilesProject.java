package ui.editor.homeTab;

import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;

import ui.UI_Main;
import ui.editor.navigation.RootFolderStore;

/**
 * Remembers which folders the Files menu needs to come back to.
 *
 * <p>
 * Two independent things are tracked, because the Open menu asks for two
 * different answers:
 * </p>
 *
 * <ul>
 *   <li><b>last project</b> &ndash; the folder most recently loaded into the
 *       project tree, whether that was through Open Folder, Open Last Project,
 *       Open Root Folder or the navigation bar and breadcrumb. Recorded by
 *       {@link #remember(Path)}.</li>
 *   <li><b>run root</b> &ndash; the project folder that was active the last
 *       time a file was executed. Recorded by {@link #rememberRunRoot(Path)}
 *       from the runner (through {@code NavigationActions.recordRun}), never
 *       from an Open action.</li>
 * </ul>
 *
 * <p>
 * The run root is no longer "the root" on its own. The root is whatever the
 * user declares with the Root button, held by {@link RootFolderStore}; the run
 * root is only its fallback. {@link #root(UI_Main)} puts the declared root
 * first for the same reason.
 * </p>
 *
 * <p>
 * Both are held in memory for the running session and mirrored into
 * {@link Preferences} so they survive a restart. Nothing is stored unless the
 * path is an existing directory, and nothing is returned unless it still is,
 * so a folder deleted between runs degrades to "no value" instead of throwing.
 * </p>
 */
public final class HomeFilesProject {

    private static final Preferences PREFS = Preferences.userRoot().node("astra/home_files");

    private static final String KEY_LAST_PROJECT = "lastProjectFolder";
    private static final String KEY_RUN_ROOT = "lastRunRootFolder";

    private static volatile Path sessionRoot;
    private static volatile Path sessionRunRoot;

    private HomeFilesProject() {
    }

    /**
     * Records a folder as the current project root and as the last project.
     *
     * @param folder the folder that was loaded; ignored if null or not a
     *               directory
     */
    public static void remember(Path folder) {
        Path normalised = normaliseDirectory(folder);
        if (normalised == null) {
            return;
        }
        sessionRoot = normalised;
        store(KEY_LAST_PROJECT, normalised);
    }

    /**
     * Records the project folder that was active for a run. Called (through
     * {@code NavigationActions.recordRun}) by {@link EditorFileRunner} once a
     * run is actually going ahead, so a file that fails its error check does
     * not move the fallback root.
     *
     * @param folder the project folder in force at run time; ignored if null
     *               or not a directory
     */
    public static void rememberRunRoot(Path folder) {
        Path normalised = normaliseDirectory(folder);
        if (normalised == null) {
            return;
        }
        sessionRunRoot = normalised;
        store(KEY_RUN_ROOT, normalised);
    }

    /**
     * @return the folder loaded as a project most recently, in this session or
     *         a previous one, or null if there is none or it no longer exists
     */
    public static Path lastProject() {
        if (sessionRoot != null && Files.isDirectory(sessionRoot)) {
            return sessionRoot;
        }
        return read(KEY_LAST_PROJECT);
    }

    /**
     * @return the project folder that was active the last time a file was run,
     *         in this session or a previous one, or null if no run has been
     *         recorded or that folder no longer exists
     */
    public static Path runRoot() {
        if (sessionRunRoot != null && Files.isDirectory(sessionRunRoot)) {
            return sessionRunRoot;
        }
        return read(KEY_RUN_ROOT);
    }

    /**
     * @return the folder opened as a project in this session, or null if none
     *         has been opened yet
     */
    public static Path sessionRoot() {
        return (sessionRoot != null && Files.isDirectory(sessionRoot)) ? sessionRoot : null;
    }

    /**
     * Resolves a sensible project root, falling back progressively: the root
     * the user declared, then the folder opened this session, then the last
     * project, then the last run root, then the folder the editor is pointed
     * at, then the user's home directory.
     *
     * <p>
     * Used for dialog start directories and for Save &gt; Save Root, so Save
     * Root writes into the declared root when there is one. Open &gt; Open Root
     * Folder deliberately does <em>not</em> use this &ndash; it wants the
     * declared root or the run root specifically, and says so when there is
     * neither.
     * </p>
     *
     * @param ide the IDE controller; may be null
     * @return a directory that exists, never null
     */
    public static Path root(UI_Main ide) {
        Path declared = RootFolderStore.declared();
        if (declared != null) {
            return declared;
        }
        Path session = sessionRoot();
        if (session != null) {
            return session;
        }
        Path last = read(KEY_LAST_PROJECT);
        if (last != null) {
            return last;
        }
        Path run = runRoot();
        if (run != null) {
            return run;
        }
        if (ide != null && ide.currentFolder != null && Files.isDirectory(ide.currentFolder)) {
            return ide.currentFolder;
        }
        return Path.of(System.getProperty("user.home"));
    }

    /**
     * Clears both remembered folders, in memory and on disk. Not wired to any
     * menu entry yet; handy from a settings screen or a test. The declared root
     * is separate and is cleared through {@link RootFolderStore#clear()}.
     */
    public static void forget() {
        sessionRoot = null;
        sessionRunRoot = null;
        PREFS.remove(KEY_LAST_PROJECT);
        PREFS.remove(KEY_RUN_ROOT);
        flush();
    }

    // -----------------------------------------------------------------
    // internals
    // -----------------------------------------------------------------

    private static Path normaliseDirectory(Path folder) {
        if (folder == null) {
            return null;
        }
        try {
            Path absolute = folder.toAbsolutePath().normalize();
            return Files.isDirectory(absolute) ? absolute : null;
        } catch (RuntimeException e) {
            return null;
        }
    }

    private static void store(String key, Path folder) {
        PREFS.put(key, folder.toString());
        flush();
    }

    private static Path read(String key) {
        String stored = PREFS.get(key, null);
        if (stored == null || stored.isBlank()) {
            return null;
        }
        try {
            Path path = Path.of(stored);
            return Files.isDirectory(path) ? path : null;
        } catch (InvalidPathException e) {
            return null;
        }
    }

    /**
     * Pushes the preference node to the backing store immediately. Without
     * this the value is only guaranteed to land at JVM shutdown, which is lost
     * if the IDE is killed rather than closed.
     */
    private static void flush() {
        try {
            PREFS.flush();
        } catch (BackingStoreException ignored) {
            // Nothing useful to do: the value still holds for this session.
        }
    }
}
