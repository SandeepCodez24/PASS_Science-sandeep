package ui.editor.homeTab;

import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.util.prefs.Preferences;

import ui.UI_Main;

/**
 * Remembers which folder is the project root, for the Files menu entries that
 * need one: Open &gt; Last Project, Open &gt; Root Folder, Save &gt; Save Root.
 *
 * <p>
 * The root for the running session is held in memory; the last project is
 * additionally written to {@link Preferences} so it survives a restart. Both
 * are recorded through {@link #remember(Path)}, which the Open actions call
 * once a folder has actually been loaded.
 * </p>
 */
public final class HomeFilesProject {

    private static final Preferences PREFS = Preferences.userRoot().node("astra/home_files");
    private static final String KEY_LAST_PROJECT = "lastProjectFolder";

    private static volatile Path sessionRoot;

    private HomeFilesProject() {
    }

    /**
     * Records a folder as the current project root and as the last project.
     *
     * @param folder the folder that was opened; ignored if null or not a
     *               directory
     */
    public static void remember(Path folder) {
        if (folder == null || !Files.isDirectory(folder)) {
            return;
        }
        sessionRoot = folder.toAbsolutePath().normalize();
        PREFS.put(KEY_LAST_PROJECT, sessionRoot.toString());
    }

    /**
     * @return the folder opened as a project in a previous run, or null if
     *         there is none or it no longer exists
     */
    public static Path lastProject() {
        String stored = PREFS.get(KEY_LAST_PROJECT, null);
        if (stored == null || stored.isBlank()) {
            return null;
        }
        try {
            Path path = Path.of(stored);
            return Files.isDirectory(path) ? path : null;
        } catch (InvalidPathException e) {
            return null;
        }
    }

    /**
     * Resolves the project root, falling back progressively: the folder
     * opened this session, then the last project, then the folder the editor
     * is currently pointed at, then the user's home directory.
     *
     * @param ide the IDE controller
     * @return a directory that exists, never null
     */
    public static Path root(UI_Main ide) {
        if (sessionRoot != null && Files.isDirectory(sessionRoot)) {
            return sessionRoot;
        }
        Path last = lastProject();
        if (last != null) {
            return last;
        }
        if (ide != null && ide.currentFolder != null && Files.isDirectory(ide.currentFolder)) {
            return ide.currentFolder;
        }
        return Path.of(System.getProperty("user.home"));
    }

    /**
     * @return the session root, or null if no folder has been opened as a
     *         project yet
     */
    public static Path sessionRoot() {
        return sessionRoot;
    }
}
