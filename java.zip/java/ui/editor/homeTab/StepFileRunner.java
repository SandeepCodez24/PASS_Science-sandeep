package ui.editor.homeTab;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.WeakHashMap;

import org.fxmisc.flowless.VirtualizedScrollPane;
import org.fxmisc.richtext.CodeArea;

import javafx.application.Platform;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.WeakChangeListener;
import javafx.scene.Node;
import javafx.scene.control.Tab;
import javafx.scene.layout.Region;
import language.syntax.syntax_checker.ErrorChecker;
import ui.UI_Main;
import ui.cli.CLI_Main;
import ui.editor.EditorFileInfo;
import ui.editor.EditorGutter;
import ui.editor.EditorTextOperations;
import ui.managers.EditorManager;

/**
 * The <b>Step Runner</b> (Phase 2a): block-aware, step-<em>over</em> stepping of
 * the active {@code .nc} script.
 *
 * <h3>What changed from Phase 1</h3>
 * <ul>
 *   <li><b>Block awareness.</b> A header that ends with {@code :} ({@code for},
 *       {@code while}, {@code if}/{@code elif}/{@code else}, function and class
 *       defs) is grouped with its indented body into a single execution
 *       <em>unit</em>. The header is never fed to the checker or backend on its
 *       own, so the "orphan {@code if (X==Y):}" errors are gone.</li>
 *   <li><b>Clean CLI.</b> The runner no longer echoes each line. It forwards
 *       the unit to the persistent {@code nc.exe} and lets the backend's own
 *       rule speak: a {@code ;}-terminated statement stays silent, a statement
 *       without {@code ;} prints its value (MATLAB-style). Only step errors are
 *       announced by the runner.</li>
 *   <li><b>Backend fix.</b> The backend is started once at arm-time
 *       ({@link EditorManager#startUPITerminal}) and a "not running" notice is
 *       shown at most once per session instead of on every click.</li>
 * </ul>
 *
 * <h3>Step-over vs step-into</h3>
 * This class steps <b>over</b> compound blocks: a loop or a call executes as one
 * unit and the arrow advances past it. Stepping <b>into</b> a body line-by-line
 * (and following call order into a function defined elsewhere) is Phase 2b and
 * requires the engine's stepping protocol — see {@link #dispatch}, the single
 * seam where that protocol plugs in.
 *
 * <h3>Gutter and highlight</h3>
 * The runner does NOT install a paragraph graphic factory of its own. It used
 * to, and that replacement had none of the editor gutter's fixed widths, so the
 * code slid left into the grey band as soon as a step run started (and the
 * fold column disappeared). The arrow is now an overlay in the gutter's error
 * column, registered through {@link EditorGutter#setErrorColumnOverlay}, so the
 * gutter keeps its exact geometry and the arrow survives fold / unfold.
 *
 * <p>The line highlight adds and removes its one style class and leaves every
 * other class on the paragraph alone. Overwriting the whole style used to wipe
 * the fold style (springing collapsed blocks open) and the error-line class.
 */
public final class StepFileRunner {

    // =====================================================================
    // Language configuration  --  CONFIRM THESE MATCH YOUR .nc GRAMMAR
    // =====================================================================
    /**
     * A trimmed line ending with this opens an indented block. The screenshot's
     * {@code if (X==Y):} shows Neural Code uses a trailing colon like Python; if
     * your grammar also uses word terminators (e.g. {@code end}), extend
     * {@link Program#isBlockOpener} and {@link Program#bodyEnds}.
     */
    private static final String BLOCK_OPENER_SUFFIX = ":";

    /** Line-continuation marker: folds the next physical line into this one. */
    private static final String CONTINUATION = "~~";

    /** Comment prefixes that make a line non-executable. */
    private static final String[] COMMENT_PREFIXES = {"#", "\\"};

    /** Paragraph style class for the lines of the current unit. */
    private static final String STEP_LINE_CLASS = "step-current-line";

    /**
     * Arrow property holding its state listener. The session only keeps a weak
     * reference, so the arrow has to hold the strong one -- and when RichTextFX
     * discards the arrow, the listener goes with it.
     */
    private static final String ARROW_LISTENER_KEY = "step.arrow.stateListener";

    /** Per-tab stepping state. Weak so closed tabs are collected. */
    private static final WeakHashMap<Tab, StepSession> SESSIONS = new WeakHashMap<>();

    private StepFileRunner() {
    }

    // =====================================================================
    // Public entry points (wired from HomeRibbon)
    // =====================================================================

    /**
     * Executes the next unit of the active editor tab.
     *
     * @param ide the IDE controller
     */
    public static void step(UI_Main ide) {
        if (ide == null || ide.editorTabs == null) {
            return;
        }
        Tab tab = ide.editorTabs.getSelectionModel().getSelectedItem();
        if (tab == null) {
            CLI_Main.appendOutput("Step: no editor tab is open.\n");
            CLI_Main.appendPrompt();
            return;
        }
        CodeArea editor = codeAreaOf(tab);
        if (editor == null) {
            CLI_Main.appendOutput("Step runner works on Neural Code (.nc) tabs only.\n");
            CLI_Main.appendPrompt();
            return;
        }

        String text = EditorTextOperations.getEditorText(tab);
        StepSession session = SESSIONS.get(tab);

        // (Re)build when there is no session yet, or the text changed under us.
        if (session == null || !text.equals(session.sourceSnapshot)) {
            // A whole-script syntax gate, exactly like Run does before it hands
            // the file to the interpreter. If the script is broken, refuse to
            // arm and say why, rather than stepping into a guaranteed error.
            var whole = ErrorChecker.analyzeErrors(text);
            if (whole.getErrorCount() > 0) {
                CLI_Main.appendOutput("Step aborted: " + whole.getErrorCount()
                        + " error(s) in the script. Fix them, then step.\n");
                CLI_Main.appendPrompt();
                return;
            }
            session = new StepSession(editor, text);
            SESSIONS.put(tab, session);
            installGutter(editor, session);
            clearHighlight(editor, session);
            pointWorkspaceAtFile(tab);
            // Idempotent: never starts a second interpreter, but guarantees the
            // one backend is up before the first line is dispatched.
            EditorManager.startUPITerminal(ide);
            CLI_Main.appendOutput("Step runner armed: " + session.units.size()
                    + " unit(s).\n");
        }

        session.pointer++;

        // Ran off the end -> finish and rewind so a further click restarts.
        if (session.pointer >= session.units.size()) {
            CLI_Main.appendOutput("Step run complete.\n");
            CLI_Main.appendPrompt();
            clearHighlight(editor, session);
            session.currentPara.set(-1);
            session.state.set("none");
            session.pointer = -1;
            return;
        }

        Unit unit = session.units.get(session.pointer);
        showAt(editor, session, unit);

        // Cumulative check THROUGH the current unit. Because compound blocks are
        // grouped, the cumulative text is always syntactically complete (no
        // half-open "if:"), so the Phase-1 false positives cannot recur.
        String cumulative = session.cumulativeThrough(session.pointer);
        var report = ErrorChecker.analyzeErrors(cumulative);
        if (report.getErrorCount() > 0) {
            session.state.set("error");
            CLI_Main.appendOutput("\u2716 Step error at line " + unit.humanLine()
                    + ": " + unit.firstLine() + "\n");
            CLI_Main.appendPrompt();
            return;
        }

        // Clean unit: forward it to the backend. No manual echo -- the backend
        // prints a value only when the statement omits ';'.
        session.state.set("ok");
        dispatch(ide, session, unit);
    }

    /**
     * Stops the current step run: clears the highlight and gutter arrow and
     * rewinds the program counter. Wire this into the Stop button.
     *
     * @param ide the IDE controller
     */
    public static void reset(UI_Main ide) {
        if (ide == null || ide.editorTabs == null) {
            return;
        }
        Tab tab = ide.editorTabs.getSelectionModel().getSelectedItem();
        if (tab == null) {
            return;
        }
        StepSession session = SESSIONS.get(tab);
        CodeArea editor = codeAreaOf(tab);
        if (session == null || editor == null) {
            return;
        }
        clearHighlight(editor, session);
        session.currentPara.set(-1);
        session.state.set("none");
        session.pointer = -1;
    }

    // =====================================================================
    // Execution  --  THE PHASE 2b SEAM
    // =====================================================================

    /**
     * Sends one unit to the execution backend.
     *
     * <p><b>Phase 2a (today).</b> The unit's source lines are written to the
     * persistent {@code nc.exe} over stdin. A simple statement is one line; a
     * compound block is its full header+body, so the loop/def executes
     * atomically (step-over). The backend's prompt-return refreshes the
     * Variable Explorer on its own, exactly as typing at the console does.
     *
     * <p><b>Phase 2b (your engine work).</b> Replace this body with calls to the
     * stepping protocol: {@code engine.stepInto(unit)} / {@code engine.next()},
     * then read back {@code {currentLine, workspace, error}} and drive
     * {@link #showAt}/{@link #applyArrowState} from the ENGINE's program
     * counter instead of the editor's. Nothing else in this class needs to
     * change.
     */
    private static void dispatch(UI_Main ide, StepSession session, Unit unit) {
        if (!ide.programRunning) {
            if (!session.backendWarned) {
                CLI_Main.appendOutput("NC backend is not running; line not executed. "
                        + "Variables will not update until it starts.\n");
                CLI_Main.appendPrompt();
                session.backendWarned = true;
            }
            return;
        }
        for (String physical : unit.code.split("\n", -1)) {
            if (physical.strip().isEmpty()) {
                continue;
            }
            // Line-oriented forward. If your REPL needs an explicit
            // block-submit for indented bodies, this is where a
            // "@block begin/end" wrapper (or the Phase-2b protocol) goes.
            EditorManager.sendCommandToTerminal(ide, physical);
        }
    }

    // =====================================================================
    // View: highlight + gutter arrow
    // =====================================================================

    private static void showAt(CodeArea editor, StepSession session, Unit unit) {
        clearHighlight(editor, session);
        for (int p = unit.startPara; p <= unit.endPara && p < editor.getParagraphs().size(); p++) {
            setStepLineStyle(editor, p, true);
            session.highlighted.add(p);
        }
        session.currentPara.set(unit.startPara);   // arrow rides the header row
        Platform.runLater(() -> {
            try {
                editor.showParagraphInViewport(unit.startPara);
                editor.moveTo(unit.startPara, 0);
            } catch (RuntimeException ignored) {
                // Paragraph index can race an edit; the next click recovers.
            }
        });
    }

    private static void clearHighlight(CodeArea editor, StepSession session) {
        for (int p : session.highlighted) {
            if (p < editor.getParagraphs().size()) {
                setStepLineStyle(editor, p, false);
            }
        }
        session.highlighted.clear();
    }

    /**
     * Adds or removes {@link #STEP_LINE_CLASS} on one paragraph, keeping every
     * other class it carries -- RichTextFX's fold style and ErrorStatusManager's
     * {@code error-line} in particular. No-op when nothing would change.
     */
    private static void setStepLineStyle(CodeArea editor, int paragraph, boolean on) {
        Collection<String> current;
        try {
            current = editor.getParagraph(paragraph).getParagraphStyle();
        } catch (RuntimeException e) {
            return;
        }
        boolean has = current != null && current.contains(STEP_LINE_CLASS);
        if (has == on) {
            return;
        }
        List<String> updated = new ArrayList<>();
        if (current != null) {
            for (String styleClass : current) {
                if (!STEP_LINE_CLASS.equals(styleClass)) {
                    updated.add(styleClass);
                }
            }
        }
        if (on) {
            updated.add(STEP_LINE_CLASS);
        }
        editor.setParagraphStyle(paragraph, updated);
    }

    /**
     * Puts this session's arrow into the editor gutter's error column.
     *
     * <p>The gutter itself is left exactly as {@code EditorGutter} built it, so
     * the band, the number slot, the fold column and the blank strip before the
     * code keep their widths and nothing moves. On the arrow's line the error
     * dot is hidden while the arrow shows (the column holds one or the other);
     * the line's error tooltip stays on the number.
     */
    private static void installGutter(CodeArea editor, StepSession session) {
        if (!EditorGutter.setErrorColumnOverlay(editor, index -> createArrow(session, index))) {
            // Not an editor built by EditorTabFactory: step without an arrow
            // rather than replace a gutter we know nothing about.
            System.err.println("Step runner: editor has no standard gutter; arrow not shown.");
        }
    }

    /**
     * The arrow for one line. Its size comes from {@code .step-arrow} in the
     * editor CSS (10px), which fits the 12px error column.
     */
    private static Node createArrow(StepSession session, int index) {
        Region arrow = new Region();
        arrow.getStyleClass().add("step-arrow");
        arrow.setMouseTransparent(true);
        arrow.setFocusTraversable(false);
        // Bindings.equal observes currentPara weakly, so discarded arrows are
        // collected normally.
        arrow.visibleProperty().bind(session.currentPara.isEqualTo(index));

        applyArrowState(arrow, session.state.get());
        ChangeListener<String> onState = (obs, was, now) -> applyArrowState(arrow, now);
        // Strong reference on the arrow, weak one on the session: rows are
        // rebuilt on every scroll and fold, and a strong listener per row used
        // to accumulate on the session for as long as the tab stayed open.
        arrow.getProperties().put(ARROW_LISTENER_KEY, onState);
        session.state.addListener(new WeakChangeListener<>(onState));
        return arrow;
    }

    private static void applyArrowState(Region arrow, String state) {
        arrow.getStyleClass().removeAll("step-arrow-ok", "step-arrow-error",
                "step-arrow-active", "step-arrow-none");
        arrow.getStyleClass().add("step-arrow-" + (state == null || state.isBlank() ? "none" : state));
    }

    // =====================================================================
    // Helpers
    // =====================================================================

    private static void pointWorkspaceAtFile(Tab tab) {
        Object data = tab.getUserData();
        if (data instanceof EditorFileInfo info && info.path != null) {
            Path parent = info.path.toAbsolutePath().getParent();
            if (parent != null) {
                CLI_Main.setWorkspaceDirectory(parent);
            }
        }
    }

    private static CodeArea codeAreaOf(Tab tab) {
        Node content = tab.getContent();
        if (content instanceof VirtualizedScrollPane<?> scroll
                && scroll.getContent() instanceof CodeArea code) {
            return code;
        }
        if (content instanceof CodeArea code) {
            return code;
        }
        return null;
    }

    // =====================================================================
    // Model
    // =====================================================================

    /**
     * One execution unit: a simple statement (one logical line) or a compound
     * block (header + indented body). {@code code} preserves the raw source
     * lines so a block is dispatched exactly as written.
     */
    private static final class Unit {
        final int startPara;
        final int endPara;
        final String code;
        final boolean block;

        Unit(int startPara, int endPara, String code, boolean block) {
            this.startPara = startPara;
            this.endPara = endPara;
            this.code = code;
            this.block = block;
        }

        int humanLine() {
            return startPara + 1;
        }

        /** The header line, for messages. */
        String firstLine() {
            int nl = code.indexOf('\n');
            return (nl < 0 ? code : code.substring(0, nl)).strip();
        }
    }

    /** Per-tab stepping state: the parsed program plus its live view bindings. */
    private static final class StepSession {
        final String sourceSnapshot;
        final List<Unit> units;
        final List<Integer> highlighted = new ArrayList<>();
        final IntegerProperty currentPara = new SimpleIntegerProperty(-1);
        final StringProperty state = new SimpleStringProperty("none");
        int pointer = -1;
        boolean backendWarned = false;

        StepSession(CodeArea editor, String source) {
            this.sourceSnapshot = source;
            this.units = new Program(source).parse();
        }

        /** Joins units 0..index, for a cumulative, syntactically complete check. */
        String cumulativeThrough(int index) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i <= index && i < units.size(); i++) {
                sb.append(units.get(i).code).append('\n');
            }
            return sb.toString();
        }
    }

    /**
     * Splits raw source into {@link Unit}s: skips blanks/comments, folds
     * {@code ~~} continuations, and groups indented bodies under their headers.
     */
    private static final class Program {
        private final String[] lines;

        Program(String source) {
            this.lines = source.split("\n", -1);
        }

        List<Unit> parse() {
            List<Unit> out = new ArrayList<>();
            int i = 0;
            while (i < lines.length) {
                if (isSkippable(lines[i])) {
                    i++;
                    continue;
                }
                // Fold ~~ continuations into a single logical header first.
                int headerEnd = i;
                StringBuilder header = new StringBuilder(strip(lines[i]));
                while (endsWithContinuation(lines[headerEnd]) && headerEnd + 1 < lines.length) {
                    headerEnd++;
                    header.append(' ').append(dropContinuation(strip(lines[headerEnd])));
                }
                String headerText = dropContinuation(header.toString()).strip();

                if (isBlockOpener(headerText)) {
                    int baseIndent = indentOf(lines[i]);
                    int bodyEnd = headerEnd;
                    int j = headerEnd + 1;
                    // The body is every following line more indented than the
                    // header. Deeper nested blocks are naturally swallowed here,
                    // so a top-level compound (with all its nesting) is one unit.
                    while (j < lines.length) {
                        if (strip(lines[j]).isEmpty()) {   // blanks don't close it
                            j++;
                            continue;
                        }
                        if (indentOf(lines[j]) > baseIndent) {
                            bodyEnd = j;
                            j++;
                        } else {
                            break;
                        }
                    }
                    out.add(new Unit(i, bodyEnd, rawSpan(i, bodyEnd), true));
                    i = bodyEnd + 1;
                } else {
                    out.add(new Unit(i, headerEnd, headerText, false));
                    i = headerEnd + 1;
                }
            }
            return out;
        }

        /** Raw source lines a..b inclusive, indentation preserved. */
        private String rawSpan(int a, int b) {
            StringBuilder sb = new StringBuilder();
            for (int k = a; k <= b && k < lines.length; k++) {
                sb.append(lines[k]);
                if (k < b) {
                    sb.append('\n');
                }
            }
            return sb.toString();
        }

        private static boolean isBlockOpener(String headerText) {
            return headerText.endsWith(BLOCK_OPENER_SUFFIX);
        }

        /** Reserved for word-terminated grammars ({@code end}); unused for now. */
        @SuppressWarnings("unused")
        private static boolean bodyEnds(String trimmed) {
            return trimmed.equals("end");
        }

        private static boolean isSkippable(String line) {
            String t = strip(line);
            if (t.isEmpty()) {
                return true;
            }
            for (String c : COMMENT_PREFIXES) {
                if (t.startsWith(c)) {
                    return true;
                }
            }
            return false;
        }

        private static boolean endsWithContinuation(String line) {
            return strip(line).endsWith(CONTINUATION);
        }

        private static String dropContinuation(String s) {
            String t = s.strip();
            return t.endsWith(CONTINUATION) ? t.substring(0, t.length() - CONTINUATION.length()).strip() : t;
        }

        private static int indentOf(String line) {
            int n = 0;
            for (int k = 0; k < line.length(); k++) {
                char c = line.charAt(k);
                if (c == ' ') {
                    n++;
                } else if (c == '\t') {
                    n += 4;
                } else {
                    break;
                }
            }
            return n;
        }

        private static String strip(String s) {
            return s == null ? "" : s.strip();
        }
    }
}
