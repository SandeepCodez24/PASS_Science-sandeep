package ui.editor;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import org.fxmisc.richtext.CodeArea;

import javafx.scene.control.Tab;
import language.syntax.syntax_checker.ErrorChecker;
import ui.UI_Main;
import ui.managers.IDEErrorStatusManager;

/**
 * Handles error checking and visual error feedback.
 * Manages error highlighting and status updates for editors.
 *
 * <h3>What changed</h3>
 * The set of lines painted with {@code error-line} is now taken from
 * {@link ErrorChecker#lineIssues(String)} rather than assembled by hand from
 * six separate calls. Two things follow:
 * <ul>
 * <li>Subscript/superscript errors are included. They were counted in the
 * status bar and drawn in the gutter, but this method left them out of the
 * paragraph styling, so those lines showed a red dot and no red line.</li>
 * <li>The analysis runs once per keystroke instead of six times.</li>
 * </ul>
 */
public class EditorErrorHandler {

    /** The one paragraph style class this class owns. */
    private static final String ERROR_LINE = "error-line";

    /**
     * Attaches real-time error checking to a CodeArea editor.
     * Updates error indicators and line styles as text changes.
     *
     * @param ide    the IDE controller
     * @param editor the CodeArea to monitor
     * @param tab    the tab containing the editor
     */
    public static void attachErrorListener(UI_Main ide, CodeArea editor, Tab tab) {
        editor.textProperty().addListener((obs, oldText, newText) -> {
            ErrorChecker.ErrorReport report = ErrorChecker.analyzeErrors(newText);
            IDEErrorStatusManager.updateErrorStatusIndicator(ide, report);
            updateErrorLineStyles(editor, newText);
        });

        String initialText = editor.getText();
        IDEErrorStatusManager.updateErrorStatusIndicator(ide, ErrorChecker.analyzeErrors(initialText));
        updateErrorLineStyles(editor, initialText);
    }

    /**
     * Attaches real-time error checking to a TextArea editor.
     * Updates error indicators as text changes.
     *
     * @param ide    the IDE controller
     * @param editor the TextArea to monitor
     * @param tab    the tab containing the editor
     */
    public static void attachErrorListenerTextArea(UI_Main ide, javafx.scene.control.TextArea editor, Tab tab) {
        editor.textProperty().addListener((obs, oldText, newText) -> {
            ErrorChecker.ErrorReport report = ErrorChecker.analyzeErrors(newText);
            IDEErrorStatusManager.updateErrorStatusIndicator(ide, report);
        });
        IDEErrorStatusManager.updateErrorStatusIndicator(ide, ErrorChecker.analyzeErrors(editor.getText()));
    }

    /**
     * Updates visual styling for error lines in a CodeArea.
     * Applies error-line style to lines containing errors.
     *
     * <h3>Folding note</h3>
     * This runs on EVERY keystroke. It used to blank the paragraph style of
     * every non-error line, which would also have wiped the style RichTextFX
     * uses to mark a paragraph as folded -- collapsing a block and then typing
     * a single character would have sprung every fold open again.
     *
     * <p>So instead of replacing the style set, this now edits it: whatever
     * classes a paragraph already carries are kept, and only
     * {@code error-line} is added or removed. Paragraphs whose style is already
     * correct are skipped entirely, which also cuts a good deal of churn out of
     * the hot path.
     *
     * @param editor the CodeArea to update
     * @param text   the current text content
     */
    private static void updateErrorLineStyles(CodeArea editor, String text) {
        Set<Integer> errorLines = ErrorChecker.lineIssues(text).allErrorLines();

        int paragraphCount = editor.getParagraphs().size();
        for (int i = 0; i < paragraphCount; i++) {
            applyErrorLineStyle(editor, i, errorLines.contains(i));
        }
    }

    /**
     * Adds or removes {@code error-line} on one paragraph while preserving
     * every other style class on it (notably RichTextFX's fold marker).
     *
     * @param editor    the CodeArea
     * @param paragraph zero-based paragraph index
     * @param isError   whether the line should carry the error style
     */
    private static void applyErrorLineStyle(CodeArea editor, int paragraph, boolean isError) {
        Collection<String> current;
        try {
            current = editor.getParagraph(paragraph).getParagraphStyle();
        } catch (Exception e) {
            return;
        }

        boolean hasError = current != null && current.contains(ERROR_LINE);
        if (hasError == isError) {
            // Already correct: leave the paragraph -- and its fold state -- alone.
            return;
        }

        List<String> updated = new ArrayList<>();
        if (current != null) {
            for (String styleClass : current) {
                if (!ERROR_LINE.equals(styleClass)) {
                    updated.add(styleClass);
                }
            }
        }
        if (isError) {
            updated.add(ERROR_LINE);
        }
        editor.setParagraphStyle(paragraph, updated);
    }

    /**
     * Performs error checking on the current editor and updates status.
     *
     * @param ide the IDE controller
     * @param tab the tab to check
     * @return the total number of errors found
     */
    public static int checkErrors(UI_Main ide, Tab tab) {
        if (tab == null) {
            return 0;
        }
        String text = EditorTextOperations.getEditorText(tab);
        ErrorChecker.ErrorReport report = ErrorChecker.analyzeErrors(text);
        IDEErrorStatusManager.updateErrorStatusIndicator(ide, report);
        ide.console.appendText("\u2714 Error check: " + report.getTotalErrors() + " issue(s) found\n");
        return report.getTotalErrors();
    }

    /**
     * Refreshes the error status for a specific tab's editor.
     *
     * @param ide the IDE controller
     * @param tab the tab to refresh
     */
    public static void refreshErrorStatus(UI_Main ide, Tab tab) {
        if (ide == null || tab == null) {
            return;
        }
        String text = EditorTextOperations.getEditorText(tab);
        IDEErrorStatusManager.updateErrorStatusIndicator(ide, ErrorChecker.analyzeErrors(text));
    }
}
