package ui.editor;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import org.fxmisc.richtext.CodeArea;

import javafx.scene.control.Tab;
import language.syntax.syntax_checker.ErrorChecker;
import ui.UI_Main;
import ui.managers.IDEErrorStatusManager;

/**
 * Handles error checking and visual error feedback.
 * Manages error highlighting and status updates for editors.
 */
public class EditorErrorHandler {

    /**
     * Attaches real-time error checking to a CodeArea editor.
     * Updates error indicators and line styles as text changes.
     * @param ide the IDE controller
     * @param editor the CodeArea to monitor
     * @param tab the tab containing the editor
     */
    public static void attachErrorListener(UI_Main ide, CodeArea editor, Tab tab) {
        editor.textProperty().addListener((obs, oldText, newText) -> {
            ErrorChecker.ErrorReport report = ErrorChecker.analyzeErrors(newText);
            IDEErrorStatusManager.updateErrorStatusIndicator(ide, report);
            updateErrorLineStyles(editor, newText);
        });

        String initialText = editor.getText();
        IDEErrorStatusManager.updateErrorStatusIndicator(ide, ErrorChecker.analyzeErrors(initialText));
        updateErrorLineStyles(editor, initialText);
    }

    /**
     * Attaches real-time error checking to a TextArea editor.
     * Updates error indicators as text changes.
     * @param ide the IDE controller
     * @param editor the TextArea to monitor
     * @param tab the tab containing the editor
     */
    public static void attachErrorListenerTextArea(UI_Main ide, javafx.scene.control.TextArea editor, Tab tab) {
        editor.textProperty().addListener((obs, oldText, newText) -> {
            ErrorChecker.ErrorReport report = ErrorChecker.analyzeErrors(newText);
            IDEErrorStatusManager.updateErrorStatusIndicator(ide, report);
        });

        IDEErrorStatusManager.updateErrorStatusIndicator(ide, ErrorChecker.analyzeErrors(editor.getText()));
    }

    /**
     * Updates visual styling for error lines in a CodeArea.
     * Applies error-line style to lines containing errors.
     * @param editor the CodeArea to update
     * @param text the current text content
     */
    private static void updateErrorLineStyles(CodeArea editor, String text) {
        Set<Integer> errorLines = new HashSet<>(ErrorChecker.findErrorLinesAfterSemicolon(text));
        errorLines.addAll(ErrorChecker.findIncompleteLineSyntaxErrorLines(text));
        errorLines.addAll(ErrorChecker.findDocstringErrorLines(text));
        errorLines.addAll(ErrorChecker.findUndefinedVariableErrorLines(text));
        errorLines.addAll(ErrorChecker.findInvalidExponentErrorLines(text));

        int paragraphCount = editor.getParagraphs().size();
        for (int i = 0; i < paragraphCount; i++) {
            if (errorLines.contains(i)) {
                editor.setParagraphStyle(i, Collections.singleton("error-line"));
            } else {
                editor.setParagraphStyle(i, Collections.emptyList());
            }
        }
    }

    /**
     * Performs error checking on the current editor and updates status.
     * @param ide the IDE controller
     * @param tab the tab to check
     * @return the total number of errors found
     */
    public static int checkErrors(UI_Main ide, Tab tab) {
        if (tab == null) {
            return 0;
        }

        String text = EditorTextOperations.getEditorText(tab);
        ErrorChecker.ErrorReport report = ErrorChecker.analyzeErrors(text);
        IDEErrorStatusManager.updateErrorStatusIndicator(ide, report);
        ide.console.appendText("✔ Error check: " + report.getTotalErrors() + " issue(s) found\n");
        return report.getTotalErrors();
    }

    /**
     * Refreshes the error status for a specific tab's editor.
     * @param ide the IDE controller
     * @param tab the tab to refresh
     */
    public static void refreshErrorStatus(UI_Main ide, Tab tab) {
        if (ide == null || tab == null) {
            return;
        }

        String text = EditorTextOperations.getEditorText(tab);
        IDEErrorStatusManager.updateErrorStatusIndicator(ide, ErrorChecker.analyzeErrors(text));
    }
}
