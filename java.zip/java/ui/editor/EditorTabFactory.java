package ui.editor;

import java.util.ArrayList;
import java.util.List;
import java.util.function.IntFunction;

import org.fxmisc.flowless.VirtualizedScrollPane;
import org.fxmisc.richtext.CodeArea;

import javafx.beans.binding.Bindings;
import javafx.beans.binding.DoubleBinding;
import javafx.beans.binding.IntegerBinding;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Tab;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

import language.language_ui.ErrorStatusManager;
import language.language_ui.handler.EditorActions;
import language.language_ui.handler.EditorContextMenuManager;
import language.language_ui.handler.EditorIndentationHandler;
import language.syntax.UPITokenMaker;
import ui.UI_Main;
import ui.editor.folding.FoldableCodeArea;
import ui.editor.folding.FoldingManager;

/**
 * Factory for creating editor tabs with proper UI setup and listeners.
 * Handles both CodeArea (for UPI files) and TextArea (for plain text).
 */
public class EditorTabFactory {

    /**
     * Gap kept between the gutter and the first character of code.
     *
     * <p>Was 20px before folding. The fold column is inserted into the space
     * that frees up, and the gutter width binding below adds the column back,
     * so the code does not shift.
     */
    private static final double GUTTER_TEXT_GAP = 10;

    /**
     * Width of the error column, in px. Fixed for the same reason the fold
     * column is fixed: a column that sizes itself to its contents moves
     * everything to its right.
     *
     * <p>The error indicator is present on error lines and absent (or a
     * narrower placeholder) on clean ones, and the two differ by about 3px.
     * Because the gutter is an HBox, those 3px pushed the line number, the fold
     * marker, the vertical guide AND the right edge of the coloured band across
     * on every error line -- which also nudged the code itself, since the
     * graphic's width is what the text is laid out after. Pinning the column
     * removes the whole chain.
     *
     * <p>Raise this if the indicator ever grows; it only needs to be at least
     * as wide as the widest thing that can appear in the column.
     */
    private static final double ERROR_COLUMN_WIDTH = 12;

    /**
     * Style class carried by the whole gutter strip -- error column, line
     * number and fold column together, as one unbroken band.
     *
     * <p>The three columns are children of this single HBox, so colouring the
     * HBox colours all three at once with no seam between them. Nothing inside
     * it paints a background of its own, which is what keeps the band flat and
     * free of dividing lines. The colour itself is in
     * {@code themes/folding/folding-light.css} and its dark twin, so it follows
     * the theme like everything else.
     */
    private static final String GUTTER_STYLE_CLASS = "editor-gutter";

    /**
     * Creates an editor tab appropriate for the file type.
     * Routes to CodeArea for UPI files, TextArea for others.
     *
     * @param ide     the IDE controller
     * @param name    the tab name
     * @param content the initial content
     * @param ext     the file extension
     * @return a configured Tab
     */
    public static Tab createEditorTab(UI_Main ide, String name, String content, String ext) {
        if (".nc".equals(ext)) {
            return createCodeAreaTab(ide, name, content, ext);
        }
        return createTextAreaTab(ide, name, content, ext);
    }

    /**
     * Creates a CodeArea tab with syntax highlighting and advanced features.
     * Sets up line numbers, the fold column, error tracking and keyboard
     * shortcuts.
     *
     * <p>The editor is a {@link FoldableCodeArea}, which IS a
     * {@link CodeArea} -- the tab content is still
     * {@code VirtualizedScrollPane<CodeArea>}, so every existing reader of
     * {@code tab.getContent()} keeps working unchanged.
     *
     * @param ide     the IDE controller
     * @param name    the tab name
     * @param content the initial content
     * @param ext     the file extension
     * @return a configured Tab with CodeArea
     */
    public static Tab createCodeAreaTab(UI_Main ide, String name, String content, String ext) {
        FoldableCodeArea editor = new FoldableCodeArea(content);
        if (!editor.getStyleClass().contains("code-area")) {
            editor.getStyleClass().add("code-area");
        }
        editor.setStyle("-fx-font-family: Consolas; -fx-font-size: 16px;");
        // Left and top padding dropped to zero so the coloured gutter band
        // reaches the editor's own edge instead of floating 8px inside it. The
        // code keeps its breathing room from the gutter's right padding
        // (GUTTER_TEXT_GAP). Put 8,8,8,8 back if the inset look is preferred --
        // the band then simply starts 8px in.
        editor.setPadding(new Insets(0, 8, 8, 0));

        // Folding has to be installed BEFORE the gutter factory, because the
        // factory asks it which lines start a foldable block -- and, now, which
        // lines are hidden and must draw nothing at all.
        FoldingManager.install(editor);

        // Gutter: error column + line number (from ErrorStatusManager, unchanged
        // two-argument call), then the fold column appended here.
        //
        // Every column is a fixed width and the strip as a whole is pinned to
        // the same width on every line, so a line's appearance never depends on
        // whether it happens to carry an error.
        IntFunction<Node> gutterFactory = index -> {
            // A folded paragraph still gets a graphic from RichTextFX, and its
            // ParagraphBox has zero height but does not clip. Handing it a
            // number label is exactly what stacked the line numbers on top of
            // each other. Give it nothing instead: the next number drawn is
            // then the one after the collapsed region, with no arithmetic.
            if (FoldingManager.isLineHidden(editor, index)) {
                return FoldingManager.createHiddenGutterGraphic();
            }

            HBox graphic = ErrorStatusManager.createLineNumberGraphic(editor, index);
            if (!graphic.getStyleClass().contains(GUTTER_STYLE_CLASS)) {
                graphic.getStyleClass().add(GUTTER_STYLE_CLASS);
            }
            graphic.setPadding(new Insets(0, GUTTER_TEXT_GAP, 0, 0));
            graphic.setAlignment(Pos.CENTER_LEFT);

            // Error indicator into a fixed-width cell, so its presence cannot
            // move anything to its right.
            pinErrorColumn(graphic);

            // Absorbs any slack between the number and the fold column, which
            // keeps the fold markers and the vertical guides in one straight
            // line down the page whatever the number column is doing.
            Region slack = new Region();
            slack.setMinWidth(0);
            HBox.setHgrow(slack, Priority.ALWAYS);
            graphic.getChildren().add(slack);

            graphic.getChildren().add(FoldingManager.createFoldMarker(editor, index));

            IntegerBinding paragraphCount = Bindings.createIntegerBinding(
                    () -> editor.getParagraphs().size(), editor.getParagraphs());
            DoubleBinding gutterWidth = Bindings.createDoubleBinding(() -> {
                int digits = Math.max(1, String.valueOf(paragraphCount.get()).length());
                Text measurer = new Text("0".repeat(digits));
                measurer.setFont(Font.font("Consolas", 5));
                // 36 = the original allowance for the error dot and spacing.
                // The fold column and the 10px shaved off the padding are added
                // back so the code sits where it did before folding.
                return measurer.getLayoutBounds().getWidth() + 36
                        + FoldingManager.COLUMN_WIDTH + GUTTER_TEXT_GAP;
            }, paragraphCount);

            // All three pinned, not just the minimum. The minimum alone let an
            // error line grow past it, and ParagraphBox lays the text out after
            // the graphic's width -- which is how three pixels of gutter became
            // three pixels of indent on the code as well.
            graphic.minWidthProperty().bind(gutterWidth);
            graphic.prefWidthProperty().bind(gutterWidth);
            graphic.maxWidthProperty().bind(gutterWidth);
            return graphic;
        };
        FoldingManager.setGutterFactory(editor, gutterFactory);

        // Setup syntax highlighting. Folding replaces paragraphs to apply the
        // fold style, which fires a rich change even though not one character
        // moved -- skip those, the highlighting cannot have changed.
        editor.richChanges()
                .filter(ch -> !ch.getInserted().equals(ch.getRemoved()))
                .filter(ch -> !FoldingManager.isApplying(editor))
                .subscribe(change -> editor.setStyleSpans(0, UPITokenMaker.computeHighlighting(editor.getText())));
        editor.setStyleSpans(0, UPITokenMaker.computeHighlighting(content));

        // Create tab
        VirtualizedScrollPane<CodeArea> scrollPane = new VirtualizedScrollPane<>(editor);
        Tab tab = new Tab(name, scrollPane);
        tab.setUserData(new EditorFileInfo(null, ext));

        // Setup text change listener. Collapsing a block goes through a
        // document replace, so without the folding guard the file would be
        // marked modified by nothing more than a click in the gutter.
        editor.textProperty().addListener((obs, oldText, newText) -> {
            if (FoldingManager.isApplying(editor)) {
                return;
            }
            if (!tab.getText().endsWith("*")) {
                tab.setText(tab.getText() + "*");
            }
        });

        // Use an event filter so this shortcut still works even if other code sets
        // onKeyPressed.
        editor.addEventFilter(KeyEvent.KEY_PRESSED, e -> {
            if (isCommandCommentShortcut(e)) {
                EditorTextOperations.commentSelectedLinesCodeArea(editor);
                e.consume();
            }
        });

        editor.setOnKeyReleased(e -> EditorActions.handleReplacement(editor, e));

        // Setup context menu and suggestions
        EditorContextMenuManager.install(editor);
        EditorIndentationHandler.install(editor);
        EditorSuggestionHandler.wireCodeAreaSuggestions(ide, editor, tab);

        // Setup error handling
        EditorErrorHandler.attachErrorListener(ide, editor, tab);

        return tab;
    }

    /**
     * Moves whatever {@code ErrorStatusManager} put in front of the line number
     * into a fixed-width cell.
     *
     * <p>The line number is the LAST child of the graphic; everything before it
     * is error indication -- a dot on an error line, a narrower placeholder (or
     * nothing) on a clean one. Wrapping that prefix rather than naming the dot
     * means this keeps working whatever the indicator is built from, and the
     * nodes themselves are re-parented untouched, so their colour, tooltip and
     * click behaviour all survive.
     *
     * <p>The cell is centred, so the indicator may sit a pixel or two from
     * where it used to -- consistently, on every line. Adjust
     * {@link #ERROR_COLUMN_WIDTH} to taste.
     *
     * @param graphic the gutter row, before the fold column is appended
     */
    private static void pinErrorColumn(HBox graphic) {
        int count = graphic.getChildren().size();
        if (count == 0) {
            return;
        }

        List<Node> indicator = new ArrayList<>(graphic.getChildren().subList(0, count - 1));
        graphic.getChildren().removeAll(indicator);

        StackPane cell = new StackPane();
        cell.getStyleClass().add("gutter-error-cell");
        cell.setAlignment(Pos.CENTER);
        cell.setMinWidth(ERROR_COLUMN_WIDTH);
        cell.setPrefWidth(ERROR_COLUMN_WIDTH);
        cell.setMaxWidth(ERROR_COLUMN_WIDTH);
        cell.getChildren().addAll(indicator);

        graphic.getChildren().add(0, cell);
    }

    /**
     * Creates a TextArea tab for plain text files.
     * Simpler than CodeArea but without syntax highlighting.
     *
     * <p>Plain-text tabs get no fold column: folding is a {@code .nc} language
     * feature and a TextArea has no paragraph gutter to hang it on.
     *
     * @param ide     the IDE controller
     * @param name    the tab name
     * @param content the initial content
     * @param ext     the file extension
     * @return a configured Tab with TextArea
     */
    public static Tab createTextAreaTab(UI_Main ide, String name, String content, String ext) {
        TextArea area = new TextArea(content);
        area.setStyle("-fx-font-family: Consolas; -fx-font-size: 16px;");

        Tab tab = new Tab(name, area);
        tab.setUserData(new EditorFileInfo(null, ext));

        // Setup text change listener
        area.textProperty().addListener((obs, oldText, newText) -> {
            if (!tab.getText().endsWith("*")) {
                tab.setText(tab.getText() + "*");
            }
        });

        // Keep the same shortcut behavior for plain TextArea tabs as well.
        area.addEventFilter(KeyEvent.KEY_PRESSED, e -> {
            if (isCommandCommentShortcut(e)) {
                EditorTextOperations.commentSelectedLinesTextArea(area);
                e.consume();
            }
        });

        // Setup suggestions and context menu
        EditorSuggestionHandler.wireTextAreaSuggestions(ide, area, tab);
        EditorErrorHandler.attachErrorListenerTextArea(ide, area, tab);
        EditorContextMenuManager.install(area);

        return tab;
    }

    /**
     * Checks if a key event is the comment shortcut (Ctrl + /).
     *
     * @param event the key event
     * @return true if this is the comment shortcut
     */
    private static boolean isCommandCommentShortcut(KeyEvent event) {
        return event.isControlDown()
                && (event.getCode() == KeyCode.SLASH
                        || event.getCode() == KeyCode.DIVIDE
                        || event.getCode() == KeyCode.BACK_SLASH);
    }
}
