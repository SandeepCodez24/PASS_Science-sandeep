package ui.editor;

import org.fxmisc.flowless.VirtualizedScrollPane;
import org.fxmisc.richtext.CodeArea;

import javafx.geometry.Insets;
import javafx.scene.control.Tab;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import language.language_ui.handler.EditorActions;
import language.language_ui.handler.EditorContextMenuManager;
import language.language_ui.handler.EditorIndentationHandler;
import language.syntax.UPITokenMaker;
import ui.UI_Main;
import ui.design.Dim;
import ui.editor.folding.FoldableCodeArea;
import ui.editor.folding.FoldingManager;

/**
 * Factory for creating editor tabs with proper UI setup and listeners.
 * Handles both CodeArea (for UPI files) and TextArea (for plain text).
 *
 * <p>
 * The gutter (error column, line numbers, fold column, and the blank strip
 * before the code) is built by {@link EditorGutter}. Its geometry lives in
 * {@code Dim.Editor}, and the editor font sizes in {@code Typography}.
 * </p>
 *
 * <p>
 * Zoom and the two gutter toggles come from {@link EditorViewSettings}: every
 * new tab opens at the current zoom and with the current gutter columns, and
 * Ctrl + mouse wheel over any editor zooms all of them. Zoom magnifies the
 * whole editor as one picture from its top-left corner
 * ({@link FoldableCodeArea#setZoom}); the font written here is always the
 * design size.
 * </p>
 *
 * <p>
 * Ctrl+/ toggles the {@code \\ } comment prefix on the selected lines (see
 * {@link EditorTextOperations#commentSelectedLinesCodeArea}); the right-click
 * menu's Comment Out and Uncomment Out show the same key.
 * </p>
 */
public class EditorTabFactory {

    /**
     * Creates an editor tab appropriate for the file type.
     * Routes to CodeArea for UPI files, TextArea for others.
     *
     * @param ide     the IDE controller
     * @param name    the tab name
     * @param content the initial content
     * @param ext     the file extension
     * @return a configured Tab
     */
    public static Tab createEditorTab(UI_Main ide, String name, String content, String ext) {
        if (".nc".equals(ext)) {
            return createCodeAreaTab(ide, name, content, ext);
        }
        return createTextAreaTab(ide, name, content, ext);
    }

    /**
     * Creates a CodeArea tab with syntax highlighting and advanced features.
     * Sets up the gutter, folding, error tracking and keyboard shortcuts.
     *
     * <p>The editor is a {@link FoldableCodeArea}, which IS a
     * {@link CodeArea} -- the tab content is still
     * {@code VirtualizedScrollPane<CodeArea>}, so every existing reader of
     * {@code tab.getContent()} keeps working unchanged.
     *
     * @param ide     the IDE controller
     * @param name    the tab name
     * @param content the initial content
     * @param ext     the file extension
     * @return a configured Tab with CodeArea
     */
    public static Tab createCodeAreaTab(UI_Main ide, String name, String content, String ext) {
        FoldableCodeArea editor = new FoldableCodeArea(content);
        if (!editor.getStyleClass().contains("code-area")) {
            editor.getStyleClass().add("code-area");
        }
        editor.setStyle(editorFontStyle());
        // Left and top padding stay at zero so the coloured gutter band reaches
        // the editor's own edge. The code's breathing room from the band is the
        // blank strip EditorGutter puts after it.
        editor.setPadding(new Insets(0, Dim.Editor.CODE_PAD_RIGHT, Dim.Editor.CODE_PAD_BOTTOM, 0));

        // Folding has to be installed BEFORE the gutter, because each gutter
        // row asks it which lines start a foldable block and which are hidden.
        FoldingManager.install(editor);
        EditorGutter.install(editor);
        EditorViewSettings.installWheelZoom(editor);
        editor.setZoom(EditorViewSettings.zoom());

        // Setup syntax highlighting. Folding replaces paragraphs to apply the
        // fold style, which fires a rich change even though not one character
        // moved -- skip those, the highlighting cannot have changed.
        editor.richChanges()
                .filter(ch -> !ch.getInserted().equals(ch.getRemoved()))
                .filter(ch -> !FoldingManager.isApplying(editor))
                .subscribe(change -> editor.setStyleSpans(0, UPITokenMaker.computeHighlighting(editor.getText())));
        editor.setStyleSpans(0, UPITokenMaker.computeHighlighting(content));

        // Create tab
        // EditorScrollPane IS a VirtualizedScrollPane<CodeArea>; it only adds
        // the zoom-aware scroll-bar decision (see its class notes).
        VirtualizedScrollPane<CodeArea> scrollPane = new EditorScrollPane(editor);
        Tab tab = new Tab(name, scrollPane);
        tab.setUserData(new EditorFileInfo(null, ext));

        // Setup text change listener. Collapsing a block goes through a
        // document replace, so without the folding guard the file would be
        // marked modified by nothing more than a click in the gutter.
        editor.textProperty().addListener((obs, oldText, newText) -> {
            if (FoldingManager.isApplying(editor)) {
                return;
            }
            if (!tab.getText().endsWith("*")) {
                tab.setText(tab.getText() + "*");
            }
        });

        // Use an event filter so this shortcut still works even if other code sets
        // onKeyPressed.
        editor.addEventFilter(KeyEvent.KEY_PRESSED, e -> {
            if (isCommandCommentShortcut(e)) {
                EditorTextOperations.commentSelectedLinesCodeArea(editor);
                e.consume();
            }
        });

        // The symbol replacer reads the caret's line on every key release. The
        // release of Ctrl+/ comes after the comment toggle has re-selected its
        // lines, and a replacement there could move the caret and lose that
        // selection -- the next Ctrl+/ would then act on the wrong lines. The
        // comment shortcut is not text input, so it is skipped.
        editor.setOnKeyReleased(e -> {
            if (isCommandCommentShortcut(e)) {
                return;
            }
            EditorActions.handleReplacement(editor, e);
        });

        // Setup context menu and suggestions
        EditorContextMenuManager.install(editor);
        EditorIndentationHandler.install(editor);
        EditorSuggestionHandler.wireCodeAreaSuggestions(ide, editor, tab);

        // Setup error handling
        EditorErrorHandler.attachErrorListener(ide, editor, tab);

        return tab;
    }

    /**
     * Creates a TextArea tab for plain text files.
     * Simpler than CodeArea but without syntax highlighting.
     *
     * <p>Plain-text tabs get no gutter: folding and line checking are
     * {@code .nc} language features, and a TextArea has no paragraph graphic
     * to hang them on.
     *
     * @param ide     the IDE controller
     * @param name    the tab name
     * @param content the initial content
     * @param ext     the file extension
     * @return a configured Tab with TextArea
     */
    public static Tab createTextAreaTab(UI_Main ide, String name, String content, String ext) {
        TextArea area = new TextArea(content);
        area.setStyle(EditorViewSettings.textAreaFontStyle());
        EditorViewSettings.installWheelZoom(area);

        Tab tab = new Tab(name, area);
        tab.setUserData(new EditorFileInfo(null, ext));

        // Setup text change listener
        area.textProperty().addListener((obs, oldText, newText) -> {
            if (!tab.getText().endsWith("*")) {
                tab.setText(tab.getText() + "*");
            }
        });

        // Keep the same shortcut behavior for plain TextArea tabs as well.
        area.addEventFilter(KeyEvent.KEY_PRESSED, e -> {
            if (isCommandCommentShortcut(e)) {
                EditorTextOperations.commentSelectedLinesTextArea(area);
                e.consume();
            }
        });

        // Setup suggestions and context menu
        EditorSuggestionHandler.wireTextAreaSuggestions(ide, area, tab);
        EditorErrorHandler.attachErrorListenerTextArea(ide, area, tab);
        EditorContextMenuManager.install(area);

        return tab;
    }

    /**
     * The editor's inline font: family and size only, at the design size (zoom
     * is a transform, not a font change). A plain-text tab carries the zoom in
     * its size instead; see {@code EditorViewSettings.textAreaFontStyle}.
     *
     * @return the inline style for an editor node
     */
    private static String editorFontStyle() {
        return EditorViewSettings.editorFontStyle();
    }

    /**
     * Checks if a key event is the comment shortcut (Ctrl + /), the one key
     * for both Comment Out and Uncomment Out: it comments the lines when they
     * are not all commented and uncomments them when they are. Ctrl+Alt is
     * left alone, because on many keyboard layouts that is AltGr typing a
     * character.
     *
     * @param event the key event
     * @return true if this is the comment shortcut
     */
    private static boolean isCommandCommentShortcut(KeyEvent event) {
        return event.isShortcutDown()
                && !event.isAltDown()
                && (event.getCode() == KeyCode.SLASH
                        || event.getCode() == KeyCode.DIVIDE
                        || event.getCode() == KeyCode.BACK_SLASH);
    }
}
