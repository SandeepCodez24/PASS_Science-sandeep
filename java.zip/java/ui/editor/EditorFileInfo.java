package ui.editor;

import java.nio.file.Path;

/**
 * Data class representing information about an open editor file.
 * Stores the file path and its extension for quick identification.
 */
public class EditorFileInfo {
    public Path path;
    public String ext;
    // Compatibility alias used by alternate EditorManager implementations.
    public String defaultExtension;

    public EditorFileInfo(Path path, String ext) {
        this.path = path;
        this.ext = ext;
        this.defaultExtension = ext;
    }

    /**
     * Checks if this represents an unsaved file.
     * @return true if the file path is null
     */
    public boolean isUnsaved() {
        return path == null;
    }

    /**
     * Gets the file name from the path.
     * @return file name or empty string if path is null
     */
    public String getFileName() {
        return path != null ? path.getFileName().toString() : "";
    }
}
