package ui.editor;

import java.util.Locale;
import java.util.prefs.Preferences;

import org.fxmisc.richtext.CodeArea;

import javafx.application.Platform;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.beans.property.ReadOnlyDoubleProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.scene.Node;
import javafx.scene.control.Tab;
import javafx.scene.control.TextArea;
import javafx.scene.input.ScrollEvent;
import ui.UI_Main;
import ui.design.Dim;
import ui.design.Typography;
import ui.design.UIScale;
import ui.editor.folding.FoldableCodeArea;
import ui.editor.folding.FoldingManager;

/**
 * The editor's view settings: zoom, and whether the gutter shows line numbers
 * and the fold column. Driven by the Settings &gt; Layout band and the zoom
 * shortcuts; read by {@link EditorTabFactory} for every new tab and by
 * {@link EditorGutter} for every gutter row.
 *
 * <h3>Scope</h3>
 * <p>
 * All three apply to every editor tab at once, open or opened later, like
 * MATLAB. The Command Window is not zoomed.
 * </p>
 *
 * <h3>How zoom works</h3>
 * <p>
 * Zoom is a magnification of the whole editor -- error column, line numbers,
 * fold column and code together -- anchored at its top-left corner
 * ({@link FoldableCodeArea#setZoom}). At 110% the area that used to fill 1/1.1
 * of the editor fills all of it; at 90% the editor shows 1/0.9 of what it
 * showed. Fonts and gutter widths keep their design values, so they always
 * stay in proportion. The scroll bars stay at their normal size.
 * </p>
 * <p>
 * A plain-text tab ({@code TextArea}) has no gutter, so there the zoom is
 * applied as its font size, which gives the same proportional result.
 * </p>
 *
 * <h3>Persistence</h3>
 * <p>
 * All three are kept in the IDE's {@code Preferences} node and restored at the
 * next launch.
 * </p>
 *
 * <h3>Turning Line Folders off</h3>
 * <p>
 * Every collapsed block is expanded first, in every tab. With the fold column
 * gone there would be no marker left to reopen a block with, and code hidden
 * without a visible handle is code the user can lose track of.
 * </p>
 */
public final class EditorViewSettings {

    private static final String KEY_ZOOM = "editor.zoom";
    private static final String KEY_LINE_NUMBERS = "editor.lineNumbers";
    private static final String KEY_LINE_FOLDERS = "editor.lineFolders";

    private static final DoubleProperty ZOOM = new SimpleDoubleProperty(Dim.Layout.ZOOM_DEFAULT);
    private static final BooleanProperty LINE_NUMBERS = new SimpleBooleanProperty(true);
    private static final BooleanProperty LINE_FOLDERS = new SimpleBooleanProperty(true);

    private static UI_Main ide;
    private static Preferences prefs;

    private EditorViewSettings() {
    }

    /**
     * Loads the saved values. Call once, from {@code Main_Window}, before the
     * first editor tab is built.
     *
     * @param ideRef the IDE controller
     */
    public static void init(UI_Main ideRef) {
        ide = ideRef;
        prefs = ideRef == null ? null : ideRef.prefs;
        if (prefs != null) {
            ZOOM.set(normalise(prefs.getDouble(KEY_ZOOM, Dim.Layout.ZOOM_DEFAULT)));
            LINE_NUMBERS.set(prefs.getBoolean(KEY_LINE_NUMBERS, true));
            LINE_FOLDERS.set(prefs.getBoolean(KEY_LINE_FOLDERS, true));
        }
    }

    // =====================================================================
    // Zoom
    // =====================================================================

    /** @return the zoom level, 1.0 = 100% */
    public static double zoom() {
        return ZOOM.get();
    }

    /** @return the zoom level, observable, for the band's tooltip */
    public static ReadOnlyDoubleProperty zoomProperty() {
        return ZOOM;
    }

    /** @return the zoom level as a percentage string, e.g. "120%" */
    public static String zoomPercent() {
        return String.format(Locale.ROOT, "%d%%", Math.round(zoom() * 100));
    }

    /** {@code Dim.Layout.ZOOM_IN_STEP} larger, up to {@code ZOOM_MAX} (500%). */
    public static void zoomIn() {
        setZoom(zoom() + Dim.Layout.ZOOM_IN_STEP);
    }

    /** {@code Dim.Layout.ZOOM_OUT_STEP} smaller, down to {@code ZOOM_MIN} (10%). */
    public static void zoomOut() {
        setZoom(zoom() - Dim.Layout.ZOOM_OUT_STEP);
    }

    /** @return true at the default view (100%), where Reset Zoom does nothing */
    public static boolean isDefaultZoom() {
        return Math.abs(zoom() - Dim.Layout.ZOOM_DEFAULT) < 1e-9;
    }

    /** @return true at the 500% cap, where Zoom In does nothing */
    public static boolean isMaxZoom() {
        return zoom() >= Dim.Layout.ZOOM_MAX - 1e-9;
    }

    /** @return true at the 10% cap, where Zoom Out does nothing */
    public static boolean isMinZoom() {
        return zoom() <= Dim.Layout.ZOOM_MIN + 1e-9;
    }

    /** Back to {@code Dim.Layout.ZOOM_DEFAULT}. */
    public static void resetZoom() {
        setZoom(Dim.Layout.ZOOM_DEFAULT);
    }

    /**
     * @param value the new zoom level; clamped to 10%..500% and rounded to a
     *              whole percent, so step arithmetic never drifts (115%, not
     *              114.99999%)
     */
    public static void setZoom(double value) {
        double next = normalise(value);
        if (next == ZOOM.get()) {
            return;
        }
        ZOOM.set(next);
        if (prefs != null) {
            prefs.putDouble(KEY_ZOOM, next);
        }
        applyToAll();
    }

    private static double normalise(double value) {
        if (!Double.isFinite(value)) {
            return Dim.Layout.ZOOM_DEFAULT;
        }
        double clamped = Math.max(Dim.Layout.ZOOM_MIN, Math.min(Dim.Layout.ZOOM_MAX, value));
        return Math.round(clamped * 100.0) / 100.0;
    }

    // =====================================================================
    // Gutter columns
    // =====================================================================

    /** @return true when the gutter shows line numbers */
    public static boolean showLineNumbers() {
        return LINE_NUMBERS.get();
    }

    /** @return true when the gutter shows the fold column */
    public static boolean showLineFolders() {
        return LINE_FOLDERS.get();
    }

    /** @return the line-number flag, observable, for the band's toggle */
    public static ReadOnlyBooleanProperty lineNumbersProperty() {
        return LINE_NUMBERS;
    }

    /** @return the fold-column flag, observable, for the band's toggle */
    public static ReadOnlyBooleanProperty lineFoldersProperty() {
        return LINE_FOLDERS;
    }

    /**
     * @param show true to show line numbers in every editor
     */
    public static void setLineNumbers(boolean show) {
        if (show == LINE_NUMBERS.get()) {
            return;
        }
        LINE_NUMBERS.set(show);
        if (prefs != null) {
            prefs.putBoolean(KEY_LINE_NUMBERS, show);
        }
        applyToAll();
    }

    /**
     * @param show true to show the fold column in every editor; false also
     *             expands every collapsed block (see the class notes)
     */
    public static void setLineFolders(boolean show) {
        if (show == LINE_FOLDERS.get()) {
            return;
        }
        if (!show) {
            forEachEditor(node -> {
                if (node instanceof CodeArea area) {
                    FoldingManager.expandAll(area);
                }
            });
        }
        LINE_FOLDERS.set(show);
        if (prefs != null) {
            prefs.putBoolean(KEY_LINE_FOLDERS, show);
        }
        applyToAll();
    }

    // =====================================================================
    // Applying
    // =====================================================================

    /**
     * The inline font style for a code editor: family and size only, at the
     * design size -- the zoom is a transform, not a font change. The weight is
     * left out so the bold keyword classes in the editor CSS keep working.
     *
     * @return the inline style
     */
    public static String editorFontStyle() {
        return "-fx-font-family: " + Typography.codeFamily() + ";"
                + " -fx-font-size: " + UIScale.fmt(codeFontSize()) + "px;";
    }

    /**
     * The inline font style for a plain-text tab, which carries the zoom in
     * its font size (it has no gutter to keep in proportion).
     *
     * @return the inline style
     */
    public static String textAreaFontStyle() {
        return "-fx-font-family: " + Typography.codeFamily() + ";"
                + " -fx-font-size: " + UIScale.fmt(round2(codeFontSize() * zoom())) + "px;";
    }

    /** @return the code font size, at the design size */
    public static double codeFontSize() {
        return Typography.size(Typography.Role.EDITOR_CODE);
    }

    /** @return the line-number font size, at the design size */
    public static double lineNumberFontSize() {
        return Typography.size(Typography.Role.EDITOR_LINE_NUMBER);
    }

    /**
     * Brings one editor in line with the current settings: font, gutter
     * widths and columns, fold badges.
     *
     * @param editor a {@code CodeArea} or {@code TextArea}
     */
    public static void applyTo(Node editor) {
        if (editor instanceof CodeArea area) {
            if (area instanceof FoldableCodeArea foldable) {
                foldable.setZoom(zoom());
                EditorGutter.reconfigure(foldable);
            }
            // Flowless decides scroll-bar visibility in mixed units once the
            // view is zoomed; the editor's scroll pane corrects for that.
            for (Node n = area.getParent(); n != null; n = n.getParent()) {
                if (n instanceof EditorScrollPane pane) {
                    pane.updateBars();
                    break;
                }
            }
            // The badges follow the new layout on the next pulse.
            Platform.runLater(() -> FoldingManager.refreshOverlay(area));
        } else if (editor instanceof TextArea text) {
            text.setStyle(textAreaFontStyle());
        }
    }

    /** Applies the current settings to every open editor tab. */
    public static void applyToAll() {
        forEachEditor(EditorViewSettings::applyTo);
    }

    /**
     * Ctrl + mouse wheel zooms, one step per notch, instead of scrolling.
     *
     * @param editor the editor node
     */
    public static void installWheelZoom(Node editor) {
        if (editor == null) {
            return;
        }
        editor.addEventFilter(ScrollEvent.SCROLL, e -> {
            if (!e.isControlDown() || e.getDeltaY() == 0) {
                return;
            }
            if (e.getDeltaY() > 0) {
                zoomIn();
            } else {
                zoomOut();
            }
            e.consume();
        });
    }

    private static void forEachEditor(java.util.function.Consumer<Node> action) {
        if (ide == null || ide.editorTabs == null) {
            return;
        }
        for (Tab tab : ide.editorTabs.getTabs()) {
            Node editor = EditorTextOperations.findEditor(tab);
            if (editor != null) {
                action.accept(editor);
            }
        }
    }

    private static double round2(double value) {
        return Math.floor(value * 100.0) / 100.0;
    }
}
