package ui.editor;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.IntFunction;

import org.fxmisc.richtext.CodeArea;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.OverrunStyle;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import language.language_ui.ErrorStatusManager;
import ui.design.Dim;
import ui.design.Typography;
import ui.design.UIScale;
import ui.editor.folding.FoldableCodeArea;
import ui.editor.folding.FoldingManager;

/**
 * Builds the gutter of a {@code .nc} editor: the coloured band (error column,
 * line number, fold column) and the blank strip between the band and the code.
 *
 * <h3>Row layout</h3>
 *
 * <pre>
 *   row (transparent, fixed width)
 *    |- band  .editor-gutter  (coloured, fixed width)
 *    |    |- error cell    fixed width, the dot or its placeholder
 *    |    |- number slot   fixed width, 4 digits, right-aligned   (Line Numbers)
 *    |    '- fold cell     fixed width, from FoldingManager       (Line Folders)
 *    '- gap   .editor-gutter-gap  (transparent, TEXT_GAP_CHARS code characters)
 * </pre>
 *
 * <p>
 * RichTextFX starts the code after the graphic's width, so pinning the row
 * pins where the code starts. None of these widths depends on the line count,
 * which is why the code does not move when a file passes 99 or 999 lines.
 * </p>
 *
 * <h3>The two gutter toggles</h3>
 * <p>
 * The metrics depend on two settings from {@link EditorViewSettings}: whether
 * the number slot and the fold column are shown. Each combination is measured
 * once and cached.
 * </p>
 * <ul>
 * <li><b>Line Numbers off</b> drops the number slot and the gap before it.
 * The error column stays, and so does its tooltip.</li>
 * <li><b>Line Folders off</b> drops the fold column and the gap before it.</li>
 * </ul>
 * <p>
 * Any change calls {@link #reconfigure}, which resizes the full-height band
 * behind the editor and rebuilds every visible row, so the band, the rows and
 * the code offset always agree.
 * </p>
 *
 * <h3>Zoom is not handled here</h3>
 * <p>
 * Zoom magnifies the whole editor as one picture
 * ({@code FoldableCodeArea.setZoom}), gutter included. Every width in this
 * class is therefore always the design width, and the gutter can never grow
 * out of proportion with the code.
 * </p>
 *
 * <h3>The three fixes this class carries</h3>
 * <ol>
 * <li><b>Full-height band.</b> A line graphic only exists for a line that
 * exists, so the per-line band stopped at the last line.
 * {@link FoldableCodeArea#setGutterBandWidth} paints one extra strip, the same
 * width and colour, behind the whole editor.</li>
 * <li><b>Numbers past 99.</b> The number slot is measured at the real font for
 * four digits. Longer numbers shrink to fit it (see
 * {@link Metrics#fontSizeFor}) and carry the full value in their tooltip.</li>
 * <li><b>Blank strip before the code.</b> A separate transparent region after
 * the band. It is part of the gutter graphic and not the text, so it cannot
 * be typed into and selection never paints it.</li>
 * </ol>
 *
 * <h3>Error-column overlay (step runner)</h3>
 * <p>
 * Other features must not replace this factory. A feature registers an
 * overlay with {@link #setErrorColumnOverlay}: one node per line, placed in
 * the error column on top of the dot. While the overlay node is visible, the
 * dot on that line is hidden. The overlay and the factory are both kept in the
 * editor's properties, so a fold, an unfold or a gutter toggle keeps
 * the overlay.
 * </p>
 */
public final class EditorGutter {

    /** Style class of the whole row, band plus gap. Paints nothing. */
    public static final String ROW_STYLE_CLASS = "editor-gutter-row";

    /**
     * Style class of the coloured band. The same class is on the full-height
     * strip behind the editor, so both take their colour from one CSS rule.
     */
    public static final String BAND_STYLE_CLASS = "editor-gutter";

    /** Style class of the blank strip between band and code. */
    public static final String GAP_STYLE_CLASS = "editor-gutter-gap";

    private static final String ERROR_CELL_STYLE_CLASS = "gutter-error-cell";

    /** Editor property holding this editor's {@link RowFactory}. */
    private static final String FACTORY_KEY = "ui.editor.gutter.factory";

    /** Editor property holding the error-column overlay, if any. */
    private static final String OVERLAY_KEY = "ui.editor.gutter.errorOverlay";
    private static final String NUMBER_SLOT_STYLE_CLASS = "gutter-number-slot";

    private EditorGutter() {
        // Utility class.
    }

    /**
     * Installs the gutter on an editor. Call after
     * {@link FoldingManager#install}, because each row asks folding what to
     * draw.
     *
     * @param editor the editor
     */
    public static void install(FoldableCodeArea editor) {
        editor.setGutterBandWidth(Metrics.current().bandWidth);

        RowFactory factory = new RowFactory(editor);
        editor.getProperties().put(FACTORY_KEY, factory);
        FoldingManager.setGutterFactory(editor, factory);
    }

    /**
     * Re-measures the gutter for the current column settings and rebuilds
     * it. Called by {@link EditorViewSettings} whenever one of them
     * changes.
     *
     * @param editor the editor
     */
    public static void reconfigure(FoldableCodeArea editor) {
        if (editor == null || !(editor.getProperties().get(FACTORY_KEY) instanceof RowFactory)) {
            return;
        }
        editor.setGutterBandWidth(Metrics.current().bandWidth);
        refresh(editor);
    }

    /**
     * Places one node per line in the error column, above the error dot, and
     * rebuilds the gutter so it shows at once. Used by the step runner for its
     * arrow.
     *
     * @param editor  the editor
     * @param overlay node for a zero-based line index, or null for none on
     *                that line; pass null here to remove the overlay
     * @return false if the editor has no gutter from {@link #install}, in
     *         which case nothing was changed
     */
    public static boolean setErrorColumnOverlay(CodeArea editor, IntFunction<? extends Node> overlay) {
        if (editor == null || !(editor.getProperties().get(FACTORY_KEY) instanceof RowFactory)) {
            return false;
        }
        if (overlay == null) {
            editor.getProperties().remove(OVERLAY_KEY);
        } else {
            editor.getProperties().put(OVERLAY_KEY, overlay);
        }
        refresh(editor);
        return true;
    }

    /**
     * Rebuilds every visible gutter row from the installed factory.
     *
     * @param editor the editor
     */
    public static void refresh(CodeArea editor) {
        if (editor == null
                || !(editor.getProperties().get(FACTORY_KEY) instanceof RowFactory factory)) {
            return;
        }
        // Detach and re-attach: the supported way to make RichTextFX ask for
        // every graphic again. Re-registered through FoldingManager so its
        // own refresh keeps using the same factory.
        editor.setParagraphGraphicFactory(null);
        FoldingManager.setGutterFactory(editor, factory);
    }

    /**
     * @return the width from the editor's left edge to the first character of
     *         code at the current gutter settings, in the editor's own
     *         (unzoomed) units, for any caller that needs to line something
     *         up with it
     */
    public static double codeOffset() {
        return Metrics.current().rowWidth;
    }

    /* =====================================================================
     * ROW
     * ===================================================================== */

    private static Node createRow(FoldableCodeArea editor, int index, Metrics metrics) {
        // A folded paragraph still gets a graphic but has zero height and no
        // clip. Give it nothing, or its number is drawn over its neighbours.
        if (FoldingManager.isLineHidden(editor, index)) {
            return FoldingManager.createHiddenGutterGraphic();
        }

        // ErrorStatusManager builds the dot and the number (and their
        // tooltips); this class only arranges them.
        HBox band = ErrorStatusManager.createLineNumberGraphic(editor, index);
        Label number = ErrorStatusManager.lineNumberOf(band);

        List<Node> indicator = new ArrayList<>(band.getChildren());
        if (number != null) {
            indicator.remove(number);
        }
        band.getChildren().clear();

        StackPane errorCell = fixedCell(ERROR_CELL_STYLE_CLASS, Dim.Editor.ERROR_COLUMN_WIDTH, Pos.CENTER);
        errorCell.getChildren().addAll(indicator);

        // With the numbers hidden the error tooltip would be reachable only
        // from the dot, which is where ErrorStatusManager already put it.
        Node overlay = overlayFor(editor, index);
        if (overlay != null) {
            // The dot and the overlay share the column: show one at a time.
            for (Node node : indicator) {
                node.visibleProperty().bind(overlay.visibleProperty().not());
            }
            errorCell.getChildren().add(overlay);
        }
        band.getChildren().add(errorCell);

        if (metrics.showNumbers) {
            StackPane numberSlot = fixedCell(NUMBER_SLOT_STYLE_CLASS,
                    metrics.numberSlotWidth, Pos.CENTER_RIGHT);
            if (number != null) {
                styleNumber(number, index + 1, metrics);
                numberSlot.getChildren().add(number);
            }
            band.getChildren().add(numberSlot);
        }

        if (metrics.showFolds) {
            band.getChildren().add(FoldingManager.createFoldMarker(editor, index));
        }

        band.setSpacing(Dim.Editor.GUTTER_COLUMN_SPACING);
        band.setAlignment(Pos.CENTER_LEFT);
        band.setPadding(new Insets(0, metrics.bandPadRight, 0, Dim.Editor.GUTTER_PAD_LEFT));
        if (!band.getStyleClass().contains(BAND_STYLE_CLASS)) {
            band.getStyleClass().add(BAND_STYLE_CLASS);
        }
        pinWidth(band, metrics.bandWidth);

        // Transparent and outside the band: this is the blank strip before
        // the code.
        Region gap = new Region();
        gap.getStyleClass().add(GAP_STYLE_CLASS);
        pinWidth(gap, metrics.textGap);

        HBox row = new HBox(band, gap);
        row.getStyleClass().add(ROW_STYLE_CLASS);
        row.setAlignment(Pos.CENTER_LEFT);
        row.setFillHeight(true);
        // All three pinned. ParagraphBox lays the text out after the graphic's
        // width, so a row that could grow would push the code with it.
        pinWidth(row, metrics.rowWidth);
        return row;
    }

    /**
     * Sets the number's font for its digit count and makes sure it can never
     * be turned into "..." by the label.
     *
     * <p>
     * The font is an inline style on purpose. The editor itself carries an
     * inline font size, and inline styles are inherited ahead of stylesheet
     * rules, so only an inline style on the label reliably wins. The colour is
     * not inline; it comes from {@code .gutter-line-number} in the theme CSS.
     * </p>
     */
    private static void styleNumber(Label number, int lineNumber, Metrics metrics) {
        int digits = String.valueOf(lineNumber).length();
        double size = metrics.fontSizeFor(digits);

        number.setStyle("-fx-font-family: " + Typography.familyCss(Typography.codeFamily()) + ";"
                + " -fx-font-size: " + UIScale.fmt(size) + "px;");
        number.setPadding(Insets.EMPTY);
        number.setMinWidth(0);
        number.setMaxWidth(metrics.numberSlotWidth);
        number.setTextOverrun(OverrunStyle.CLIP);
        number.setEllipsisString("");

        if (digits > Dim.Editor.LINE_NUMBER_DIGITS) {
            addFullNumberTooltip(number, lineNumber);
        }
    }

    /**
     * A shrunk number is harder to read at a glance, so its full value is
     * always in the tooltip. If the line already has an error tooltip, the
     * number goes on top of it.
     */
    private static void addFullNumberTooltip(Label number, int lineNumber) {
        String heading = "Line " + lineNumber;
        Tooltip existing = number.getTooltip();
        if (existing == null) {
            Tooltip tooltip = new Tooltip(heading);
            tooltip.setStyle("-fx-font-size: 10px;");
            number.setTooltip(tooltip);
        } else {
            existing.setText(heading + "\n" + existing.getText());
        }
    }

    private static Node overlayFor(CodeArea editor, int index) {
        if (!(editor.getProperties().get(OVERLAY_KEY) instanceof IntFunction<?> overlay)) {
            return null;
        }
        try {
            return overlay.apply(index) instanceof Node node ? node : null;
        } catch (RuntimeException e) {
            // A broken overlay must never cost the line its number.
            return null;
        }
    }

    private static StackPane fixedCell(String styleClass, double width, Pos alignment) {
        StackPane cell = new StackPane();
        cell.getStyleClass().add(styleClass);
        cell.setAlignment(alignment);
        pinWidth(cell, width);
        return cell;
    }

    private static void pinWidth(Region region, double width) {
        region.setMinWidth(width);
        region.setPrefWidth(width);
        region.setMaxWidth(width);
    }

    /**
     * The paragraph graphic factory. A named class rather than a lambda, so
     * {@link #refresh} can find it in the editor's properties without an
     * unchecked cast. It reads the metrics on every row, so a rebuild after a
     * gutter toggle picks up the new ones without being replaced.
     */
    private static final class RowFactory implements IntFunction<Node> {

        private final FoldableCodeArea editor;

        RowFactory(FoldableCodeArea editor) {
            this.editor = editor;
        }

        @Override
        public Node apply(int index) {
            return createRow(editor, index, Metrics.current());
        }
    }

    /* =====================================================================
     * METRICS
     * ===================================================================== */

    /**
     * Widths measured from the real fonts for one combination of number slot
     * and fold column. Each combination is measured once and cached.
     *
     * <p>
     * FX thread only, like the rest of the gutter.
     * </p>
     */
    private static final class Metrics {

        private static final Map<String, Metrics> CACHE = new ConcurrentHashMap<>();

        final boolean showNumbers;
        final boolean showFolds;

        /** Full line-number font size. */
        final double numberFontSize;

        /** Width of {@code LINE_NUMBER_DIGITS} digits at that size, rounded up. */
        final double numberSlotWidth;

        /** Right padding of the band, including the whole-pixel rounding. */
        final double bandPadRight;

        /** Width of the coloured band, a whole number of pixels. */
        final double bandWidth;

        /** Width of {@code TEXT_GAP_CHARS} characters at the code font. */
        final double textGap;

        /** Band plus gap: where the code starts. */
        final double rowWidth;

        /** Font size per digit count, filled on first use. Index = digits. */
        private final double[] sizeByDigits = new double[20];

        private Metrics(boolean showNumbers, boolean showFolds) {
            this.showNumbers = showNumbers;
            this.showFolds = showFolds;

            double padRight = Dim.Editor.GUTTER_PAD_RIGHT;

            numberFontSize = EditorViewSettings.lineNumberFontSize();
            numberSlotWidth = Math.ceil(digitsWidth(Dim.Editor.LINE_NUMBER_DIGITS, numberFontSize));

            double content = Dim.Editor.GUTTER_PAD_LEFT + Dim.Editor.ERROR_COLUMN_WIDTH + padRight;
            if (showNumbers) {
                content += Dim.Editor.GUTTER_COLUMN_SPACING + numberSlotWidth;
            }
            if (showFolds) {
                content += Dim.Editor.GUTTER_COLUMN_SPACING + FoldingManager.COLUMN_WIDTH;
            }
            // Whole pixels, so the per-line bands and the full-height strip
            // behind them snap to the same edge.
            bandWidth = Math.ceil(content);
            bandPadRight = padRight + (bandWidth - content);

            textGap = digitsWidth(Dim.Editor.TEXT_GAP_CHARS, EditorViewSettings.codeFontSize());
            rowWidth = bandWidth + textGap;
        }

        /** @return the metrics for the settings in force right now */
        static Metrics current() {
            boolean numbers = EditorViewSettings.showLineNumbers();
            boolean folds = EditorViewSettings.showLineFolders();
            String key = numbers + "|" + folds;
            return CACHE.computeIfAbsent(key, k -> new Metrics(numbers, folds));
        }

        /**
         * Font size for a number with this many digits.
         *
         * <p>
         * Up to {@code LINE_NUMBER_DIGITS} digits: the full size. Above that:
         * scaled down so the number is exactly as wide as the slot, never
         * below {@code LINE_NUMBER_MIN_FONT_RATIO} of the full size. Rounded
         * down to two decimals, so the value written into the style can never
         * be a hair larger than the one measured.
         * </p>
         */
        double fontSizeFor(int digits) {
            int slot = Math.max(1, Math.min(digits, sizeByDigits.length - 1));
            if (sizeByDigits[slot] > 0) {
                return sizeByDigits[slot];
            }

            double size = numberFontSize;
            if (slot > Dim.Editor.LINE_NUMBER_DIGITS) {
                double natural = digitsWidth(slot, numberFontSize);
                if (natural > numberSlotWidth) {
                    size = numberFontSize * (numberSlotWidth / natural);
                }
                size = Math.max(size, numberFontSize * Dim.Editor.LINE_NUMBER_MIN_FONT_RATIO);
                size = Math.floor(size * 100.0) / 100.0;
            }
            sizeByDigits[slot] = size;
            return size;
        }

        /**
         * Width of a run of zeros in the editor family. Consolas is
         * monospaced, so this is also the width of any digits, or of any
         * characters in the code font.
         */
        private static double digitsWidth(int count, double fontSize) {
            Text measurer = new Text("0".repeat(Math.max(1, count)));
            measurer.setFont(Font.font(Typography.codeFamily(), fontSize));
            return measurer.getLayoutBounds().getWidth();
        }
    }
}
