package ui.editor.folding;

import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 * Loads and re-inks the four fold PNGs.
 *
 * <pre>
 *   /icons/fold/fold_plus_light.png    collapsed, light theme   ("+" -&gt; expand)
 *   /icons/fold/fold_plus_dark.png     collapsed, dark theme
 *   /icons/fold/fold_minus_light.png   expanded,  light theme   ("-" -&gt; collapse)
 *   /icons/fold/fold_minus_dark.png    expanded,  dark theme
 * </pre>
 *
 * <p>These are raster assets, so unlike the rest of the palette they cannot
 * follow the stylesheet on their own. This class mirrors the pattern already
 * used by {@code HomeFilesIcons} / {@code HomeRibbonIcons} / {@code ToolbarIcons}:
 * it keeps a weak registry of every marker currently on screen and re-points
 * them all when {@link #setDarkTheme(boolean)} is called from
 * {@code ThemeManager.applyIconInk}. Weak references mean closed tabs are
 * collected normally.
 *
 * <p><b>Public API.</b> This class exposes exactly {@link #createMarker(boolean)},
 * {@link #setCollapsed(ImageView, boolean)}, {@link #setDarkTheme(boolean)},
 * {@link #isDarkTheme()} and the {@link #ICON_SIZE} constant. There is no
 * {@code createMarkerView} and no {@code COLUMN_WIDTH} here -- the column width
 * belongs to {@link FoldingManager}, which owns the layout.
 */
public final class FoldIcons {

    private static final String BASE = "/icons/fold/";

    private static final String PLUS_LIGHT = BASE + "fold_plus_light.png";
    private static final String PLUS_DARK = BASE + "fold_plus_dark.png";
    private static final String MINUS_LIGHT = BASE + "fold_minus_light.png";
    private static final String MINUS_DARK = BASE + "fold_minus_dark.png";

    /** Rendered size of a marker, in px. Kept small and mild on purpose. */
    public static final double ICON_SIZE = 11;

    /** Property key marking an ImageView as "shows the collapsed glyph". */
    private static final String COLLAPSED_KEY = "fold-icon-collapsed";

    private static boolean darkTheme = false;

    private static Image plusLight;
    private static Image plusDark;
    private static Image minusLight;
    private static Image minusDark;

    private static final List<WeakReference<ImageView>> REGISTRY = new ArrayList<>();

    private FoldIcons() {
        // Utility class.
    }

    /**
     * Builds a marker image view for the current theme.
     *
     * @param collapsed true for the "+" glyph (block is folded), false for "-"
     * @return an ImageView, already registered for theme repainting
     */
    public static ImageView createMarker(boolean collapsed) {
        ImageView view = new ImageView();
        view.setFitWidth(ICON_SIZE);
        view.setFitHeight(ICON_SIZE);
        view.setPreserveRatio(true);
        view.setSmooth(true);
        view.getProperties().put(COLLAPSED_KEY, collapsed);
        view.setImage(imageFor(collapsed, darkTheme));
        register(view);
        return view;
    }

    /**
     * Flips an existing marker between the "+" and "-" glyphs without
     * rebuilding the node.
     *
     * @param view      a view created by {@link #createMarker(boolean)}
     * @param collapsed the new state
     */
    public static void setCollapsed(ImageView view, boolean collapsed) {
        if (view == null) {
            return;
        }
        view.getProperties().put(COLLAPSED_KEY, collapsed);
        view.setImage(imageFor(collapsed, darkTheme));
    }

    /**
     * Points every marker at the matching ink. Called by
     * {@code ThemeManager.applyIconInk}.
     *
     * @param dark true when the dark theme has just been applied
     */
    public static void setDarkTheme(boolean dark) {
        darkTheme = dark;
        synchronized (REGISTRY) {
            Iterator<WeakReference<ImageView>> it = REGISTRY.iterator();
            while (it.hasNext()) {
                ImageView view = it.next().get();
                if (view == null) {
                    it.remove();
                    continue;
                }
                Object flag = view.getProperties().get(COLLAPSED_KEY);
                boolean collapsed = Boolean.TRUE.equals(flag);
                view.setImage(imageFor(collapsed, darkTheme));
            }
        }
    }

    /** @return true when the dark ink is currently in force */
    public static boolean isDarkTheme() {
        return darkTheme;
    }

    /* =====================================================================
     * INTERNALS
     * ===================================================================== */

    private static void register(ImageView view) {
        synchronized (REGISTRY) {
            REGISTRY.add(new WeakReference<>(view));
        }
    }

    private static Image imageFor(boolean collapsed, boolean dark) {
        if (collapsed) {
            if (dark) {
                if (plusDark == null) {
                    plusDark = load(PLUS_DARK);
                }
                return plusDark;
            }
            if (plusLight == null) {
                plusLight = load(PLUS_LIGHT);
            }
            return plusLight;
        }
        if (dark) {
            if (minusDark == null) {
                minusDark = load(MINUS_DARK);
            }
            return minusDark;
        }
        if (minusLight == null) {
            minusLight = load(MINUS_LIGHT);
        }
        return minusLight;
    }

    /**
     * Loads a PNG off the classpath. A missing asset is never fatal: the marker
     * simply renders empty and folding still works by click.
     */
    private static Image load(String resource) {
        try (InputStream in = FoldIcons.class.getResourceAsStream(resource)) {
            if (in == null) {
                System.err.println("Fold icon missing: " + resource);
                return null;
            }
            return new Image(in);
        } catch (Exception e) {
            System.err.println("Fold icon failed to load: " + resource + " -- " + e.getMessage());
            return null;
        }
    }
}
