package ui.editor.folding;

import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 * Loads and re-inks the twelve fold marker PNGs.
 *
 * <pre>
 *   /icons/fold/fold_{plus|minus}_{loop|fn|class}_{light|dark}.png
 * </pre>
 *
 * <p>Twelve, not four: the marker is now coloured by the kind of block it
 * opens, matching the guide line below it -- black for loops and conditions,
 * teal for functions, steel blue for classes -- and each of those ships in a
 * light and a dark ink. The file name is built from
 * {@link FoldRegion.Family#token()}, so the assets and the colour families
 * cannot drift apart: adding a family to the enum names its icons for you.
 *
 * <p>These are raster assets, so unlike the rest of the palette they cannot
 * follow the stylesheet on their own. This class mirrors the pattern already
 * used by {@code HomeFilesIcons} / {@code HomeRibbonIcons} / {@code ToolbarIcons}:
 * it keeps a weak registry of every marker currently on screen and re-points
 * them all when {@link #setDarkTheme(boolean)} is called from
 * {@code ThemeManager.applyIconInk}. Weak references mean closed tabs are
 * collected normally.
 *
 * <p><b>Public API.</b> {@link #createMarker(boolean, FoldRegion.Family)},
 * {@link #setCollapsed(ImageView, boolean)}, {@link #setDarkTheme(boolean)},
 * {@link #isDarkTheme()} and the {@link #ICON_SIZE} constant. The single
 * argument {@link #createMarker(boolean)} is kept so any older caller still
 * compiles; it draws the neutral loop marker.
 */
public final class FoldIcons {

    private static final String BASE = "/icons/fold/";

    /** Rendered size of a marker, in px. Kept small and mild on purpose. */
    public static final double ICON_SIZE = 11;

    /** Property key marking an ImageView as "shows the collapsed glyph". */
    private static final String COLLAPSED_KEY = "fold-icon-collapsed";

    /** Property key carrying the block family the marker was built for. */
    private static final String FAMILY_KEY = "fold-icon-family";

    private static boolean darkTheme = false;

    /** Resource path -&gt; loaded image. A failed load caches nothing and is retried. */
    private static final Map<String, Image> CACHE = new HashMap<>();

    private static final List<WeakReference<ImageView>> REGISTRY = new ArrayList<>();

    private FoldIcons() {
        // Utility class.
    }

    /**
     * Builds a marker image view for the current theme, in the colour of the
     * block it opens.
     *
     * @param collapsed true for the "+" glyph (block is folded), false for "-"
     * @param family    the block family, deciding the marker's ink
     * @return an ImageView, already registered for theme repainting
     */
    public static ImageView createMarker(boolean collapsed, FoldRegion.Family family) {
        FoldRegion.Family safe = family == null ? FoldRegion.Family.LOOP : family;

        ImageView view = new ImageView();
        view.setFitWidth(ICON_SIZE);
        view.setFitHeight(ICON_SIZE);
        view.setPreserveRatio(true);
        view.setSmooth(true);
        view.getProperties().put(COLLAPSED_KEY, collapsed);
        view.getProperties().put(FAMILY_KEY, safe);
        view.setImage(imageFor(collapsed, safe, darkTheme));
        register(view);
        return view;
    }

    /**
     * Builds a neutral (loop-coloured) marker.
     *
     * @param collapsed true for the "+" glyph, false for "-"
     * @return an ImageView, already registered for theme repainting
     */
    public static ImageView createMarker(boolean collapsed) {
        return createMarker(collapsed, FoldRegion.Family.LOOP);
    }

    /**
     * Flips an existing marker between the "+" and "-" glyphs without
     * rebuilding the node. The family it was created with is kept.
     *
     * @param view      a view created by {@link #createMarker(boolean, FoldRegion.Family)}
     * @param collapsed the new state
     */
    public static void setCollapsed(ImageView view, boolean collapsed) {
        if (view == null) {
            return;
        }
        view.getProperties().put(COLLAPSED_KEY, collapsed);
        view.setImage(imageFor(collapsed, familyOf(view), darkTheme));
    }

    /**
     * Points every marker at the matching ink. Called by
     * {@code ThemeManager.applyIconInk}.
     *
     * @param dark true when the dark theme has just been applied
     */
    public static void setDarkTheme(boolean dark) {
        darkTheme = dark;
        synchronized (REGISTRY) {
            Iterator<WeakReference<ImageView>> it = REGISTRY.iterator();
            while (it.hasNext()) {
                ImageView view = it.next().get();
                if (view == null) {
                    it.remove();
                    continue;
                }
                boolean collapsed = Boolean.TRUE.equals(view.getProperties().get(COLLAPSED_KEY));
                view.setImage(imageFor(collapsed, familyOf(view), darkTheme));
            }
        }
    }

    /** @return true when the dark ink is currently in force */
    public static boolean isDarkTheme() {
        return darkTheme;
    }

    /* =====================================================================
     * INTERNALS
     * ===================================================================== */

    private static FoldRegion.Family familyOf(ImageView view) {
        Object stored = view.getProperties().get(FAMILY_KEY);
        return stored instanceof FoldRegion.Family family ? family : FoldRegion.Family.LOOP;
    }

    private static void register(ImageView view) {
        synchronized (REGISTRY) {
            REGISTRY.add(new WeakReference<>(view));
        }
    }

    /**
     * Builds the resource path. Kept as one expression on purpose -- there is
     * no twelve-way branch to get wrong, and a renamed family token changes the
     * file name in exactly one place.
     */
    private static String resourceFor(boolean collapsed, FoldRegion.Family family, boolean dark) {
        return BASE + "fold_"
                + (collapsed ? "plus" : "minus") + "_"
                + family.token().toLowerCase(Locale.ROOT) + "_"
                + (dark ? "dark" : "light") + ".png";
    }

    private static Image imageFor(boolean collapsed, FoldRegion.Family family, boolean dark) {
        String resource = resourceFor(collapsed, family, dark);
        synchronized (CACHE) {
            Image cached = CACHE.get(resource);
            if (cached != null) {
                return cached;
            }
            Image loaded = load(resource);
            if (loaded != null) {
                CACHE.put(resource, loaded);
            }
            return loaded;
        }
    }

    /**
     * Loads a PNG off the classpath. A missing asset is never fatal: the marker
     * simply renders empty and folding still works by click.
     */
    private static Image load(String resource) {
        try (InputStream in = FoldIcons.class.getResourceAsStream(resource)) {
            if (in == null) {
                System.err.println("Fold icon missing: " + resource);
                return null;
            }
            return new Image(in);
        } catch (Exception e) {
            System.err.println("Fold icon failed to load: " + resource + " -- " + e.getMessage());
            return null;
        }
    }
}
