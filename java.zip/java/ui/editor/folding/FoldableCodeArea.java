package ui.editor.folding;

import org.fxmisc.richtext.CodeArea;

import javafx.scene.layout.Pane;

/**
 * A {@link CodeArea} that adds the one thing the fold feature needs from the
 * node itself: a mouse-transparent overlay layer for the {@code ...} badges,
 * plus public entry points to the fold calls.
 *
 * <h3>The anchor rule (this is where the old code was wrong)</h3>
 * {@code StyleClassedTextArea.foldParagraphs(int startPar, int endPar)} folds
 * the range <b>"into", i.e. EXCLUDING, the first paragraph of the range</b>.
 * Internally {@code GenericStyledArea.fold} takes the sub-document and applies
 * the fold style from index {@code 1} onwards:
 *
 * <pre>
 *     for ( int p = 1; p &lt; subDoc.getParagraphCount(); p++ ) ...
 * </pre>
 *
 * So {@code foldParagraphs(a, b)} hides {@code a+1 .. b} and leaves {@code a}
 * on screen. The previous version passed the FIRST HIDDEN line as {@code a},
 * which therefore left that line visible -- the "header plus one body line
 * showing" bug. The correct call passes the HEADER line as {@code a}.
 *
 * <p>The two methods below are named for that rule: {@link #foldBelow} and
 * {@link #unfoldBelow} both take the anchor -- the line that stays visible --
 * so the off-by-one cannot be reintroduced by a caller that reads the name and
 * assumes "first line to hide".
 *
 * <p>{@code unfoldParagraphs(int startingFromPar)} works the same way round: it
 * scans forward from {@code startingFromPar + 1} for as long as paragraphs
 * carry the fold style, and clears it on that run. It must therefore be handed
 * the anchor too, not the first hidden line.
 *
 * <p>Both inherited overloads supply RichTextFX's own fold style, which is what
 * actually collapses the paragraph (the library's {@code styled-text-area.css}
 * carries {@code .collapse { visibility: collapse; }}). This class never names
 * that style class itself, so nothing here breaks if the library renames it.
 *
 * <h3>Why a subclass and not a wrapper</h3>
 * {@code Tab.getContent()} is read across this code base as a
 * {@code VirtualizedScrollPane<CodeArea>} ({@code EditorTextOperations}, and
 * through it {@code EditorFileSaver} and the runner). Wrapping the editor in a
 * StackPane to get an overlay would quietly break saving and running.
 * Subclassing keeps the node graph EXACTLY as it was --
 * {@code Tab -> VirtualizedScrollPane -> CodeArea} -- because a
 * {@code FoldableCodeArea} IS a {@code CodeArea}, so every existing
 * {@code instanceof CodeArea} check still passes unchanged.
 */
public class FoldableCodeArea extends CodeArea {

    private final Pane foldOverlay = new Pane();

    public FoldableCodeArea(String text) {
        super(text);
        foldOverlay.getStyleClass().add("fold-overlay");
        // Never steal a click: everything under it must stay reachable.
        foldOverlay.setMouseTransparent(true);
        foldOverlay.setManaged(false);
        // Added after the virtual flow (which the superclass constructor has
        // already installed), so the badges paint on top of the code.
        getChildren().add(foldOverlay);
    }

    /**
     * @return the layer the {@code ...} badges are placed on, in CodeArea-local
     *         coordinates
     */
    public Pane getFoldOverlay() {
        return foldOverlay;
    }

    /* =====================================================================
     * FOLD / UNFOLD
     * ===================================================================== */

    /**
     * Hides every paragraph from {@code anchor + 1} through {@code lastHidden}
     * inclusive, leaving {@code anchor} itself visible.
     *
     * <p>The text is untouched, so {@code getText()} keeps returning the full
     * source and save, run and semantic-file generation are unaffected.
     *
     * @param anchor     the line that stays visible -- the block header
     * @param lastHidden last paragraph to hide, inclusive
     */
    public void foldBelow(int anchor, int lastHidden) {
        if (anchor < 0 || lastHidden <= anchor || lastHidden >= getParagraphs().size()) {
            return;
        }
        foldParagraphs(anchor, lastHidden);
    }

    /**
     * Reveals the run of folded paragraphs sitting directly below
     * {@code anchor}.
     *
     * <p>Pass the same anchor that was given to {@link #foldBelow}. The library
     * walks forward from {@code anchor + 1} until it meets a paragraph that is
     * not folded, so a run folded as one call is unfolded as one call.
     *
     * @param anchor the visible line the run hangs off
     */
    public void unfoldBelow(int anchor) {
        if (anchor < 0 || anchor >= getParagraphs().size()) {
            return;
        }
        unfoldParagraphs(anchor);
    }

    @Override
    protected void layoutChildren() {
        super.layoutChildren();
        // Unmanaged, so it must be sized by hand. Covering the whole area lets
        // the badges be positioned from character bounds without any further
        // coordinate maths.
        foldOverlay.resizeRelocate(0, 0, getWidth(), getHeight());
    }
}
