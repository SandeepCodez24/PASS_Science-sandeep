package ui.editor.folding;

import org.fxmisc.richtext.CodeArea;

import javafx.scene.layout.Pane;
import javafx.scene.layout.Region;
import javafx.scene.transform.Scale;

/**
 * A {@link CodeArea} that adds what the fold feature and the gutter need from
 * the node itself: a mouse-transparent overlay layer for the {@code ...}
 * badges, a full-height gutter band underneath the code, and public entry
 * points to the fold calls.
 *
 * <h3>The gutter band</h3>
 * Each line's gutter graphic paints its own slice of the coloured band, but a
 * graphic only exists for a line that exists, so below the last line of a
 * short file the band simply stopped. {@link #setGutterBandWidth} adds one
 * plain strip, the same width and the same {@code .editor-gutter} colour,
 * behind the whole editor, from top to bottom. The per-line slices lie exactly
 * on top of it, so the band reads as one column whatever the line count.
 *
 * <p>The strip is the first child, so it paints under the text. It follows
 * horizontal scrolling: the line graphics scroll sideways with the code, so the
 * strip narrows by the same amount and the two edges always meet.
 *
 * <h3>The anchor rule (this is where the old code was wrong)</h3>
 * {@code StyleClassedTextArea.foldParagraphs(int startPar, int endPar)} folds
 * the range <b>"into", i.e. EXCLUDING, the first paragraph of the range</b>.
 * Internally {@code GenericStyledArea.fold} takes the sub-document and applies
 * the fold style from index {@code 1} onwards:
 *
 * <pre>
 *     for ( int p = 1; p &lt; subDoc.getParagraphCount(); p++ ) ...
 * </pre>
 *
 * So {@code foldParagraphs(a, b)} hides {@code a+1 .. b} and leaves {@code a}
 * on screen. The previous version passed the FIRST HIDDEN line as {@code a},
 * which therefore left that line visible -- the "header plus one body line
 * showing" bug. The correct call passes the HEADER line as {@code a}.
 *
 * <p>The two methods below are named for that rule: {@link #foldBelow} and
 * {@link #unfoldBelow} both take the anchor -- the line that stays visible --
 * so the off-by-one cannot be reintroduced by a caller that reads the name and
 * assumes "first line to hide".
 *
 * <p>{@code unfoldParagraphs(int startingFromPar)} works the same way round: it
 * scans forward from {@code startingFromPar + 1} for as long as paragraphs
 * carry the fold style, and clears it on that run. It must therefore be handed
 * the anchor too, not the first hidden line.
 *
 * <p>Both inherited overloads supply RichTextFX's own fold style, which is what
 * actually collapses the paragraph (the library's {@code styled-text-area.css}
 * carries {@code .collapse { visibility: collapse; }}). This class never names
 * that style class itself, so nothing here breaks if the library renames it.
 *
 * <h3>Zoom: one magnification, anchored top-left</h3>
 * {@link #setZoom} scales the whole editor -- error column, line numbers, fold
 * column, the full-height gutter band, the code and the {@code ...} badges --
 * as one picture, with the top-left corner fixed. The scroll pane still hands
 * this node its on-screen size; {@link #resize} lays the editor out at that
 * size divided by the zoom and a {@link Scale} brings it back up, so at 110%
 * the part that used to fill 1/1.1 of the editor now fills all of it.
 *
 * <p>Nothing inside needs to know about the zoom: fonts, gutter widths and
 * paddings keep their design values, which is why they can never grow out of
 * step with one another. Mouse hits, the caret, selection and the popups'
 * screen positions all go through the transform, so they stay exact.
 *
 * <p>The scroll bars belong to the enclosing {@code EditorScrollPane}, outside
 * this node, so they keep their normal size at every zoom.
 *
 * <h3>Why a subclass and not a wrapper</h3>
 * {@code Tab.getContent()} is read across this code base as a
 * {@code VirtualizedScrollPane<CodeArea>} ({@code EditorTextOperations}, and
 * through it {@code EditorFileSaver} and the runner). Wrapping the editor in a
 * StackPane to get an overlay would quietly break saving and running.
 * Subclassing keeps the node graph EXACTLY as it was --
 * {@code Tab -> VirtualizedScrollPane -> CodeArea} -- because a
 * {@code FoldableCodeArea} IS a {@code CodeArea}, so every existing
 * {@code instanceof CodeArea} check still passes unchanged.
 */
public class FoldableCodeArea extends CodeArea {

    private final Pane foldOverlay = new Pane();

    /** Full-height gutter strip painted under the text. */
    private final Region gutterBand = new Region();

    /** Band width at zero horizontal scroll; 0 means no band. */
    private double gutterBandWidth = 0;

    /** The magnification, pivoting on the top-left corner. */
    private final Scale zoomScale = new Scale(1, 1, 0, 0);

    /** Current zoom factor; 1 = 100%. */
    private double zoom = 1.0;

    public FoldableCodeArea(String text) {
        super(text);

        // Same class as the per-line band, so both take their colour from the
        // one .editor-gutter rule and switch with the theme together.
        gutterBand.getStyleClass().addAll("editor-gutter", "editor-gutter-band");
        gutterBand.setManaged(false);
        gutterBand.setMouseTransparent(true);
        gutterBand.setVisible(false);
        // Index 0: painted before the virtual flow, so under the code.
        getChildren().add(0, gutterBand);
        estimatedScrollXProperty().addListener((obs, oldX, newX) -> layoutGutterBand());

        getTransforms().add(zoomScale);

        foldOverlay.getStyleClass().add("fold-overlay");
        // Never steal a click: everything under it must stay reachable.
        foldOverlay.setMouseTransparent(true);
        foldOverlay.setManaged(false);
        // Added after the virtual flow (which the superclass constructor has
        // already installed), so the badges paint on top of the code.
        getChildren().add(foldOverlay);
    }

    /**
     * @return the layer the {@code ...} badges are placed on, in CodeArea-local
     *         coordinates
     */
    public Pane getFoldOverlay() {
        return foldOverlay;
    }

    /**
     * Sets the width of the full-height gutter strip. Must equal the width of
     * the coloured band in each line's gutter graphic; {@code EditorGutter}
     * passes the same number to both.
     *
     * @param width band width in px; 0 removes the strip
     */
    public void setGutterBandWidth(double width) {
        gutterBandWidth = Double.isFinite(width) ? Math.max(0, width) : 0;
        layoutGutterBand();
    }

    /**
     * @return the width last given to {@link #setGutterBandWidth}
     */
    public double getGutterBandWidth() {
        return gutterBandWidth;
    }

    /* =====================================================================
     * ZOOM
     * ===================================================================== */

    /**
     * Magnifies the whole editor, keeping the top-left corner fixed.
     *
     * @param factor the zoom factor, 1 = 100%; values at or below zero are
     *               ignored
     */
    public void setZoom(double factor) {
        if (!Double.isFinite(factor) || factor <= 0 || factor == zoom) {
            return;
        }
        zoom = factor;
        zoomScale.setX(factor);
        zoomScale.setY(factor);
        // The scroll pane must hand us our on-screen size again, so resize()
        // can turn it into the new layout size.
        requestParentLayout();
        requestLayout();
    }

    /**
     * @return the zoom factor, 1 = 100%
     */
    public double getZoom() {
        return zoom;
    }

    /**
     * The scroll pane gives this node its on-screen width and height. Laying
     * out at that size divided by the zoom, then scaling by the zoom, fills
     * exactly the same screen area with a magnified (or reduced) view.
     */
    @Override
    public void resize(double width, double height) {
        super.resize(width / zoom, height / zoom);
    }

    /* =====================================================================
     * FOLD / UNFOLD
     * ===================================================================== */

    /**
     * Hides every paragraph from {@code anchor + 1} through {@code lastHidden}
     * inclusive, leaving {@code anchor} itself visible.
     *
     * <p>The text is untouched, so {@code getText()} keeps returning the full
     * source and save, run and semantic-file generation are unaffected.
     *
     * @param anchor     the line that stays visible -- the block header
     * @param lastHidden last paragraph to hide, inclusive
     */
    public void foldBelow(int anchor, int lastHidden) {
        if (anchor < 0 || lastHidden <= anchor || lastHidden >= getParagraphs().size()) {
            return;
        }
        foldParagraphs(anchor, lastHidden);
    }

    /**
     * Reveals the run of folded paragraphs sitting directly below
     * {@code anchor}.
     *
     * <p>Pass the same anchor that was given to {@link #foldBelow}. The library
     * walks forward from {@code anchor + 1} until it meets a paragraph that is
     * not folded, so a run folded as one call is unfolded as one call.
     *
     * @param anchor the visible line the run hangs off
     */
    public void unfoldBelow(int anchor) {
        if (anchor < 0 || anchor >= getParagraphs().size()) {
            return;
        }
        unfoldParagraphs(anchor);
    }

    @Override
    protected void layoutChildren() {
        super.layoutChildren();
        layoutGutterBand();
        // Unmanaged, so it must be sized by hand. Covering the whole area lets
        // the badges be positioned from character bounds without any further
        // coordinate maths.
        foldOverlay.resizeRelocate(0, 0, getWidth(), getHeight());
    }

    /**
     * Sizes the strip to the part of the band still on screen. Called on
     * layout and on every horizontal scroll; unmanaged, so it costs no layout
     * pass of its own.
     *
     * <p>The strip is shortened rather than moved left, so it never paints
     * outside the editor's own bounds.
     */
    private void layoutGutterBand() {
        double scrollX = getEstimatedScrollX();
        if (!Double.isFinite(scrollX) || scrollX < 0) {
            scrollX = 0;
        }
        double visibleWidth = Math.max(0, gutterBandWidth - scrollX);
        gutterBand.setVisible(visibleWidth > 0);
        gutterBand.resizeRelocate(getInsets().getLeft(), 0, visibleWidth, getHeight());
    }
}
