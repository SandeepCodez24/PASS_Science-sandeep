package ui.editor.folding;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.IntFunction;

import org.fxmisc.richtext.CodeArea;

import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.DoubleBinding;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.control.Tooltip;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.util.Duration;

/**
 * The fold column: the clickable {@code +} / {@code -} markers, the mild
 * vertical guide beside an open block, and the logic that actually collapses
 * lines.
 *
 * <h3>How collapsing works</h3>
 * The fold calls live on {@link FoldableCodeArea}, which delegates to the
 * inherited {@code foldParagraphs} / {@code unfoldParagraphs}. Those apply
 * RichTextFX's own fold style, which is what hides the lines. Folded paragraphs
 * leave the view but stay in the document, so:
 *
 * <ul>
 *   <li>{@code editor.getText()} is unchanged -- save, run and semantic-file
 *       generation all see the full source;</li>
 *   <li>the graphic factory is still called with the REAL paragraph index, so
 *       numbering needs no arithmetic on our side;</li>
 *   <li>syntax highlighting, error checking and the suggestion popup are
 *       untouched.</li>
 * </ul>
 *
 * <h3>The three things this file had to be taught</h3>
 * <ol>
 *   <li><b>The anchor.</b> {@code foldParagraphs(a, b)} hides {@code a+1..b}
 *       and keeps {@code a}. The old code passed the first hidden line as
 *       {@code a}, so one body line always stayed on screen. Every run is now
 *       folded from its anchor -- the line above the run -- via
 *       {@link FoldableCodeArea#foldBelow}.</li>
 *   <li><b>The gutter of a hidden line.</b> A folded {@code ParagraphBox}
 *       reports a preferred height of zero but STILL lays out its graphic, and
 *       an HBox does not clip: that is why the line numbers of hidden lines
 *       piled on top of each other. {@link #isLineHidden} lets the factory
 *       return {@link #createHiddenGutterGraphic()} instead of a number, so a
 *       hidden line draws nothing at all and the next number on screen is the
 *       region's end line plus one, by construction.</li>
 *   <li><b>Nesting.</b> Visibility is decided by
 *       {@code FoldState.hiddenLines}, the union of every collapsed region's
 *       span. An inner block inside a collapsed outer block is in that union
 *       like any other line, so its marker, guide and badge vanish with the
 *       body -- while its own collapsed flag survives in
 *       {@code collapsedStarts} and is honoured again when the parent
 *       reopens.</li>
 * </ol>
 *
 * <h3>Editing while folded</h3>
 * Fold state is keyed on line numbers, and a structural edit (a line added or
 * removed) moves every line below it. Rather than silently mis-folding, an edit
 * that changes the line count expands everything; an edit within a line keeps
 * the folds. Fold state is deliberately not persisted across save or reopen.
 */
public final class FoldingManager {

    /** Property key for the per-editor {@link FoldState}. */
    private static final String STATE_KEY = "ui.editor.folding.state";

    /**
     * Width of the fold column, in px. Fixed so line numbers never jitter.
     *
     * <p>Public because {@code EditorTabFactory} adds it to the gutter width
     * binding -- the column and the space reserved for it must agree, and one
     * constant is the only way to guarantee that.
     */
    public static final double COLUMN_WIDTH = 14;

    /**
     * Clearance between the +/- marker and the guide line passing a header row.
     * Zero: the line runs right up to the box edge on both sides, so the span
     * reads as one stroke entering and leaving the marker rather than as two
     * stubs floating near it. The line still never crosses the box, because the
     * stub length is derived from the icon's own bounds.
     */
    private static final double MARKER_CLEARANCE = 0;

    /**
     * Thickness of the guide line and of the foot on a closing line, in px.
     * THIS IS THE DIAL: lower it to thin the line, raise it to thicken it.
     *
     * <p>0.5 is the original 1px reduced by 30% twice over. Note that a value
     * below about 0.25 stops rendering at all on a 100% display -- there is
     * not enough coverage left for the antialiaser to paint.
     *
     * <p>A fractional width only survives if the cell does not snap its
     * children to whole pixels, which is why
     * {@code cell.setSnapToPixel(false)} is set in {@link #createFoldMarker}.
     * Without that line JavaFX rounds 0.7 up to 1 and the guide looks exactly
     * as thick as before, whatever number is written here.
     */
    private static final double GUIDE_THICKNESS = 0.5;

    private FoldingManager() {
        // Utility class.
    }

    /* =====================================================================
     * INSTALL
     * ===================================================================== */

    /**
     * Attaches folding to an editor. Safe to call once per editor; a second
     * call is a no-op.
     *
     * @param editor the editor, normally a {@link FoldableCodeArea}
     */
    public static void install(CodeArea editor) {
        if (editor == null || editor.getProperties().containsKey(STATE_KEY)) {
            return;
        }
        FoldState state = new FoldState();
        editor.getProperties().put(STATE_KEY, state);

        state.reparseIfNeeded(editor.getText());
        state.lastParagraphCount = editor.getParagraphs().size();

        editor.textProperty().addListener((obs, oldText, newText) -> onTextChanged(editor, newText));

        // The ... badges are drawn from live character bounds, so they have to
        // be re-placed whenever the view moves or resizes.
        editor.estimatedScrollYProperty().addListener((obs, o, n) -> refreshEllipsis(editor));
        editor.widthProperty().addListener((obs, o, n) -> refreshEllipsis(editor));
        editor.heightProperty().addListener((obs, o, n) -> refreshEllipsis(editor));
    }

    /**
     * Registers the gutter factory so folding can force the markers to redraw
     * after a collapse or expand. Call this INSTEAD of
     * {@code editor.setParagraphGraphicFactory(...)}.
     *
     * @param editor  the editor
     * @param factory the gutter factory (error dot + line number + fold marker)
     */
    public static void setGutterFactory(CodeArea editor, IntFunction<Node> factory) {
        FoldState state = stateOf(editor);
        if (state != null) {
            state.gutterFactory = factory;
        }
        editor.setParagraphGraphicFactory(factory);
    }

    /* =====================================================================
     * QUERIES USED BY THE GUTTER FACTORY
     * ===================================================================== */

    /**
     * @param editor the editor
     * @param line   zero-based paragraph index
     * @return true when this paragraph is inside a collapsed block and must
     *         therefore draw NOTHING in the gutter
     */
    public static boolean isLineHidden(CodeArea editor, int line) {
        FoldState state = stateOf(editor);
        return state != null && state.isHidden(line);
    }

    /**
     * True while a fold is being applied to the document.
     *
     * <p>Folding goes through {@code replace(...)} on the document, so the
     * text property can fire even though not one character changed. Listeners
     * that react to real edits -- the tab's modified marker, the highlighter --
     * check this and step aside, which is what stops a collapse from marking a
     * clean file dirty.
     *
     * @param editor the editor
     * @return true if a fold or unfold is in progress
     */
    public static boolean isApplying(CodeArea editor) {
        FoldState state = stateOf(editor);
        return state != null && state.applying;
    }

    /**
     * The gutter graphic for a hidden line: a node that occupies nothing and
     * paints nothing.
     *
     * <p>A folded {@code ParagraphBox} has zero height but still lays its
     * graphic out and does not clip it, so returning a normal number label here
     * is what produced the stack of overlapping line numbers. Unmanaged keeps
     * it out of the width calculation; invisible keeps it off the screen.
     *
     * <p>A fresh instance every call: a Node has exactly one parent, so a
     * shared constant would be yanked from one paragraph to the next.
     *
     * @return a blank, unmanaged, invisible node
     */
    public static Node createHiddenGutterGraphic() {
        Region blank = new Region();
        blank.setVisible(false);
        blank.setManaged(false);
        blank.setMouseTransparent(true);
        blank.setMinSize(0, 0);
        blank.setPrefSize(0, 0);
        blank.setMaxSize(0, 0);
        return blank;
    }

    /* =====================================================================
     * GUTTER MARKER
     * ===================================================================== */

    /**
     * Builds the fold-column cell for one line.
     *
     * <p>Every visible line gets a cell of the same width, so the line numbers
     * stay in a straight column and the column is a permanent part of the
     * gutter rather than something that appears on hover. What goes in the cell
     * depends on the line:
     *
     * <ul>
     *   <li><b>block header</b> -- the clickable {@code +} / {@code -} icon;</li>
     *   <li><b>inside an open block</b> -- a mild 1px vertical guide, the
     *       MATLAB cue that these lines belong to the block above;</li>
     *   <li><b>last line of an open block</b> -- the guide stopping at
     *       mid-height with a short foot, closing the bracket;</li>
     *   <li><b>anything else</b> -- an invisible spacer.</li>
     * </ul>
     *
     * @param editor the editor
     * @param line   zero-based paragraph index
     * @return a node of fixed width, never null
     */
    public static Node createFoldMarker(CodeArea editor, int line) {
        StackPane cell = new StackPane();
        cell.getStyleClass().add("fold-marker-cell");
        // Regions are snapped to whole pixels by default, which silently
        // rounded GUIDE_THICKNESS back up to 1px. Turning snapping off for
        // this one cell is what lets a sub-pixel guide actually render thin.
        cell.setSnapToPixel(false);
        cell.setMinWidth(COLUMN_WIDTH);
        cell.setPrefWidth(COLUMN_WIDTH);
        cell.setMaxWidth(COLUMN_WIDTH);
        cell.setAlignment(Pos.CENTER);

        FoldState state = stateOf(editor);
        if (state == null || !(editor instanceof FoldableCodeArea)) {
            return cell;
        }
        state.reparseIfNeeded(editor.getText());

        // Belt and braces: the factory should not have been called for a hidden
        // line at all, but if it was, draw nothing rather than a stray marker
        // in a zero-height row.
        if (state.isHidden(line)) {
            return cell;
        }

        FoldRegion region = state.regionStartingAt(line);
        if (region != null && region.isFoldable()) {
            addToggleIcon(cell, editor, state, region, line);
            return cell;
        }

        // Not a header: draw the guide if this line sits inside an open block.
        List<FoldRegion> stack = state.expandedSpanning(line);
        if (!stack.isEmpty()) {
            FoldRegion innermost = stack.get(stack.size() - 1);
            if (line > innermost.getStartLine()) {
                boolean closing = line == innermost.getEndLine();
                // On the closing line the block below this one keeps going, so
                // the lower half is painted in the OUTER stack's colour instead
                // of stopping dead.
                String below = closing
                        ? FoldState.guideStyleClass(state.enclosingExcluding(line, innermost))
                        : null;
                addGuide(cell, closing, FoldState.guideStyleClass(stack), below);
                return cell;
            }
        }

        // Keeps the column width without drawing anything.
        Region spacer = new Region();
        spacer.setMinWidth(COLUMN_WIDTH);
        cell.getChildren().add(spacer);
        return cell;
    }

    /**
     * The clickable + / - icon on a block header, and the guide segments that
     * pass it above and below.
     *
     * <p>A header sits in the middle of its parent's span, so the parent's
     * guide has to continue through this row -- otherwise every nested function
     * punches a hole in the class's line, which is the discontinuity seen in
     * the gutter. The line is drawn as two segments that stop short of the
     * icon rather than running behind it, so the tick box stays clean.
     *
     * <p>The segment BELOW the icon belongs to this block's own body and is
     * therefore coloured with this block included -- which is exactly the
     * colour the next line down will use, so the two meet seamlessly. When the
     * block is collapsed there is no body to introduce, so the lower segment
     * reverts to the parent's colour.
     */
    private static void addToggleIcon(StackPane cell, CodeArea editor, FoldState state,
            FoldRegion region, int line) {
        boolean collapsed = state.collapsedStarts.contains(line);
        ImageView icon = FoldIcons.createMarker(collapsed, region.getFamily());
        icon.getStyleClass().add("fold-marker");

        List<FoldRegion> outer = state.enclosingExcluding(line, region);
        String aboveClass = FoldState.guideStyleClass(outer);
        String belowClass = aboveClass;
        if (!collapsed && region.isFoldable()) {
            List<FoldRegion> withSelf = new ArrayList<>(outer);
            withSelf.add(region);
            belowClass = FoldState.guideStyleClass(withSelf);
        }
        addHeaderSegments(cell, icon, aboveClass, belowClass);

        Tooltip tip = new Tooltip(collapsed
                ? "Expand " + region.getKind().opener() + " block ("
                        + region.getHiddenLineCount() + " lines hidden)"
                : "Collapse " + region.getKind().opener() + " block");
        tip.setShowDelay(Duration.millis(400));
        Tooltip.install(cell, tip);

        cell.setCursor(Cursor.DEFAULT);
        cell.getChildren().add(icon);
        cell.addEventFilter(MouseEvent.MOUSE_CLICKED, e -> {
            if (e.getButton() == MouseButton.PRIMARY) {
                toggle(editor, line);
                e.consume();
            }
        });
    }

    /**
     * The two guide stubs on a header line: one from the top of the row down to
     * the icon, one from the icon down to the bottom.
     *
     * <p>Their length is derived from the icon's own bounds rather than a
     * hardcoded gap, so changing the marker art in {@code FoldIcons} cannot
     * leave the line overlapping it or floating away from it.
     *
     * @param cell       the fold cell
     * @param icon       the marker already added to the cell
     * @param aboveClass colour class for the upper stub, or null to omit it
     * @param belowClass colour class for the lower stub, or null to omit it
     */
    private static void addHeaderSegments(StackPane cell, ImageView icon,
            String aboveClass, String belowClass) {
        DoubleBinding stubHeight = Bindings.createDoubleBinding(
                () -> Math.max(0, (cell.getHeight() - icon.getBoundsInLocal().getHeight() - MARKER_CLEARANCE) / 2),
                cell.heightProperty(), icon.boundsInLocalProperty());

        if (aboveClass != null) {
            Region above = guideBar(aboveClass);
            above.maxHeightProperty().bind(stubHeight);
            cell.getChildren().add(above);
            StackPane.setAlignment(above, Pos.TOP_CENTER);
        }
        if (belowClass != null) {
            Region below = guideBar(belowClass);
            below.maxHeightProperty().bind(stubHeight);
            cell.getChildren().add(below);
            StackPane.setAlignment(below, Pos.BOTTOM_CENTER);
        }
    }

    /** A 1px vertical bar carrying the base guide class plus a colour class. */
    private static Region guideBar(String familyClass) {
        Region bar = new Region();
        bar.getStyleClass().add("fold-guide");
        if (familyClass != null) {
            bar.getStyleClass().add(familyClass);
        }
        bar.setMinWidth(GUIDE_THICKNESS);
        bar.setPrefWidth(GUIDE_THICKNESS);
        bar.setMaxWidth(GUIDE_THICKNESS);
        bar.setMaxHeight(Double.MAX_VALUE);
        bar.setMouseTransparent(true);
        return bar;
    }

    /**
     * The vertical guide. A 1px line, coloured entirely from the CSS so it can
     * stay mild on both themes.
     *
     * <p>On the closing line the guide runs only to mid-height and gains a
     * short horizontal foot, so the block reads as a bracket rather than a rule
     * that overshoots into the next statement.
     *
     * <h3>Colour</h3>
     * Beyond the base {@code .fold-guide} class the guide carries a second
     * class naming the block families that enclose the line -- {@code
     * .fold-guide-loop}, {@code .fold-guide-fn-class}, {@code
     * .fold-guide-loop-fn-class} and so on. Each has its own value in
     * editor_light.css / editor_dark.css, pre-blended so a loop nested in a
     * function shows grey tinted with the function's dark orange, and a
     * function nested in a class shows dark orange tinted with the class's
     * cadet blue.
     *
     * <p>No colour is computed in Java on purpose: the project's convention is
     * that colours live in the theme stylesheets and numbers live in code, and
     * a {@code setStyle} call here would silently beat the stylesheet and kill
     * the dial.
     *
     * @param cell        the fold cell
     * @param closing     true on the block's last line
     * @param familyClass the blended-colour style class, or null for the base grey
     * @param belowClass  on a closing line, the colour of whatever block
     *                    continues below; null when nothing does
     */
    private static void addGuide(StackPane cell, boolean closing, String familyClass,
            String belowClass) {
        Region guide = guideBar(familyClass);

        if (!closing) {
            cell.getChildren().add(guide);
            StackPane.setAlignment(guide, Pos.CENTER);
            return;
        }

        // Half-height stem, anchored to the top, plus the foot.
        guide.maxHeightProperty().bind(cell.heightProperty().divide(2));
        cell.getChildren().add(guide);
        StackPane.setAlignment(guide, Pos.TOP_CENTER);

        Region foot = new Region();
        foot.getStyleClass().add("fold-guide");
        if (familyClass != null) {
            foot.getStyleClass().add(familyClass);
        }
        foot.setMinHeight(GUIDE_THICKNESS);
        foot.setPrefHeight(GUIDE_THICKNESS);
        foot.setMaxHeight(GUIDE_THICKNESS);
        foot.maxWidthProperty().bind(cell.widthProperty().divide(2));
        foot.setMouseTransparent(true);
        cell.getChildren().add(foot);
        StackPane.setAlignment(foot, Pos.CENTER_RIGHT);

        // An enclosing block does not end here, so its line carries straight on
        // below the foot. This is what makes a class span read as one unbroken
        // line even though several functions close inside it.
        if (belowClass != null) {
            Region below = guideBar(belowClass);
            below.maxHeightProperty().bind(cell.heightProperty().divide(2));
            cell.getChildren().add(below);
            StackPane.setAlignment(below, Pos.BOTTOM_CENTER);
        }
    }

    /* =====================================================================
     * FOLD / UNFOLD
     * ===================================================================== */

    /**
     * Collapses the block starting on {@code line}, or expands it if it is
     * already collapsed.
     *
     * @param editor the editor
     * @param line   zero-based header line
     */
    public static void toggle(CodeArea editor, int line) {
        FoldState state = stateOf(editor);
        if (state == null || state.applying) {
            return;
        }
        state.reparseIfNeeded(editor.getText());

        FoldRegion region = state.regionStartingAt(line);
        if (region == null || !region.isFoldable()) {
            return;
        }
        if (state.collapsedStarts.contains(line)) {
            state.collapsedStarts.remove(line);
        } else {
            state.collapsedStarts.add(line);
        }
        applyFolds(editor);
    }

    /**
     * Collapses every foldable block in the editor.
     *
     * @param editor the editor
     */
    public static void collapseAll(CodeArea editor) {
        FoldState state = stateOf(editor);
        if (state == null || state.applying) {
            return;
        }
        state.reparseIfNeeded(editor.getText());
        for (FoldRegion region : state.regions) {
            if (region.isFoldable()) {
                state.collapsedStarts.add(region.getStartLine());
            }
        }
        applyFolds(editor);
    }

    /**
     * Expands every block in the editor.
     *
     * @param editor the editor
     */
    public static void expandAll(CodeArea editor) {
        FoldState state = stateOf(editor);
        if (state == null || state.collapsedStarts.isEmpty()) {
            return;
        }
        state.collapsedStarts.clear();
        applyFolds(editor);
    }

    /**
     * @param editor the editor
     * @param line   zero-based header line
     * @return true when the block starting on this line is collapsed
     */
    public static boolean isCollapsed(CodeArea editor, int line) {
        FoldState state = stateOf(editor);
        return state != null && state.collapsedStarts.contains(line);
    }

    /* =====================================================================
     * INTERNALS
     * ===================================================================== */

    private static FoldState stateOf(CodeArea editor) {
        if (editor == null) {
            return null;
        }
        Object value = editor.getProperties().get(STATE_KEY);
        return value instanceof FoldState state ? state : null;
    }

    /**
     * Re-parses on every edit, keeps or drops the folds accordingly, and only
     * redraws the gutter when the set of foldable blocks has actually changed
     * -- so ordinary typing costs one parse and nothing else.
     */
    private static void onTextChanged(CodeArea editor, String newText) {
        FoldState state = stateOf(editor);
        if (state == null || state.applying) {
            return;
        }

        Set<Integer> markersBefore = new HashSet<>(state.regionsByStart.keySet());
        state.reparseIfNeeded(newText);
        boolean markersChanged = !markersBefore.equals(state.regionsByStart.keySet());

        int paragraphCount = editor.getParagraphs().size();
        boolean structuralEdit = paragraphCount != state.lastParagraphCount;
        state.lastParagraphCount = paragraphCount;

        if (!state.collapsedStarts.isEmpty()) {
            if (structuralEdit) {
                // Line numbers below the edit have all moved: expand rather
                // than risk hiding the wrong lines.
                state.collapsedStarts.clear();
                applyFoldsLater(editor);
                return;
            }
            boolean pruned = state.pruneStaleCollapsedStarts();
            if (pruned || markersChanged) {
                // A region's extent may have moved even though the line count
                // did not -- re-derive the hidden set rather than trust it.
                applyFoldsLater(editor);
                return;
            }
            refreshEllipsis(editor);
        }

        if (markersChanged) {
            refreshGutter(editor);
        }
    }

    /**
     * Applies folds on the next pulse.
     *
     * <p>Folding mutates the document, and doing that from inside a text-change
     * listener means re-entering the very notification that is still running.
     * Deferring by one pulse keeps every document edit outside that window.
     */
    private static void applyFoldsLater(CodeArea editor) {
        Platform.runLater(() -> applyFolds(editor));
    }

    /**
     * Brings the view in line with {@link FoldState#collapsedStarts}.
     *
     * <p>Everything is unfolded first and then re-folded from scratch. That
     * sounds wasteful but it is what makes nesting correct: overlapping inner
     * and outer blocks are merged into maximal runs of hidden lines, so no
     * paragraph is ever folded twice and expanding an outer block cannot
     * accidentally expand an inner one that the user had collapsed.
     *
     * <p>Each run is folded from its ANCHOR -- the visible line immediately
     * above it. A maximal run never starts at line 0 and its predecessor is by
     * definition not hidden, so the anchor always exists and is always on
     * screen.
     */
    private static void applyFolds(CodeArea editor) {
        FoldState state = stateOf(editor);
        if (state == null || state.applying || !(editor instanceof FoldableCodeArea foldable)) {
            return;
        }

        int caretParagraph = -1;
        int caretColumn = 0;
        try {
            caretParagraph = editor.getCurrentParagraph();
            caretColumn = editor.getCaretColumn();
        } catch (Exception e) {
            // Caret position is a convenience here, not a requirement.
        }

        state.applying = true;
        try {
            // Undo exactly what we folded last time, deepest run first. We
            // never ask RichTextFX which paragraphs it thinks are folded --
            // that would tie us to an internal style class name.
            for (int i = state.appliedRuns.size() - 1; i >= 0; i--) {
                int anchor = state.appliedRuns.get(i)[0];
                try {
                    foldable.unfoldBelow(anchor);
                } catch (Exception e) {
                    System.err.println("Unfold failed below line " + (anchor + 1) + ": " + e.getMessage());
                }
            }
            state.appliedRuns.clear();

            state.recomputeHiddenLines();

            int paragraphCount = editor.getParagraphs().size();
            for (int[] run : maximalRuns(state.hiddenLines, paragraphCount)) {
                int anchor = run[0] - 1;
                if (anchor < 0) {
                    continue;
                }
                try {
                    foldable.foldBelow(anchor, run[1]);
                    state.appliedRuns.add(new int[] { anchor, run[1] });
                } catch (Exception e) {
                    System.err.println("Fold failed for lines "
                            + (run[0] + 1) + ".." + (run[1] + 1) + ": " + e.getMessage());
                }
            }
        } finally {
            state.applying = false;
        }

        restoreCaret(editor, state, caretParagraph, caretColumn);
        refreshGutter(editor);
        refreshEllipsis(editor);
    }

    /**
     * Puts the caret back where it was. RichTextFX moves it to the start of the
     * folded range on every fold call, so without this a collapse anywhere in
     * the file would drag the caret -- and the typing position -- with it. A
     * caret that ends up inside a newly hidden block is parked on the nearest
     * visible line above instead.
     */
    private static void restoreCaret(CodeArea editor, FoldState state, int paragraph, int column) {
        if (paragraph < 0) {
            return;
        }
        try {
            int paragraphCount = editor.getParagraphs().size();
            int target = Math.min(paragraph, paragraphCount - 1);
            if (state.isHidden(target)) {
                target = state.nearestVisibleAtOrAbove(target);
                editor.moveTo(target, 0);
                return;
            }
            editor.moveTo(target, Math.min(column, editor.getParagraphLength(target)));
        } catch (Exception e) {
            // Never let a cosmetic caret move break a fold.
        }
    }

    /**
     * Collapses a sorted set of line indices into contiguous [first, last]
     * runs, clamped to the document.
     */
    private static List<int[]> maximalRuns(Set<Integer> lines, int paragraphCount) {
        List<int[]> runs = new ArrayList<>();
        int first = -1;
        int previous = -2;
        for (Integer value : lines) {
            int line = value;
            if (line < 0 || line >= paragraphCount) {
                continue;
            }
            if (line != previous + 1) {
                if (first >= 0) {
                    runs.add(new int[] { first, previous });
                }
                first = line;
            }
            previous = line;
        }
        if (first >= 0) {
            runs.add(new int[] { first, previous });
        }
        return runs;
    }

    /**
     * Forces RichTextFX to rebuild the paragraph graphics so the {@code +} /
     * {@code -} glyphs, the guides and the suppressed gutters of hidden lines
     * all match the new state. Detaching and re-attaching the factory is the
     * supported way to do that.
     */
    private static void refreshGutter(CodeArea editor) {
        FoldState state = stateOf(editor);
        if (state == null || state.gutterFactory == null) {
            return;
        }
        IntFunction<Node> factory = state.gutterFactory;
        editor.setParagraphGraphicFactory(null);
        editor.setParagraphGraphicFactory(factory);
    }

    /**
     * Redraws the badges. Only collapsed headers that are themselves on screen
     * get one -- a collapsed block nested inside another collapsed block must
     * not leave a badge floating in the hidden region.
     */
    private static void refreshEllipsis(CodeArea editor) {
        FoldState state = stateOf(editor);
        if (state == null) {
            return;
        }
        FoldEllipsisOverlay.updateLater(editor, state.visibleCollapsedStarts());
    }
}
