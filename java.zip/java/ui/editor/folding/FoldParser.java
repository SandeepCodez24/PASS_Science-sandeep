package ui.editor.folding;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Turns editor text into the list of foldable regions.
 *
 * <h3>The block table (as specified)</h3>
 *
 * <pre>
 *   if        -&gt; iend        if not     -&gt; iend
 *   while     -&gt; wend        while not  -&gt; wend
 *   for       -&gt; fend
 *   function  -&gt; fnend
 *   class     -&gt; csend
 * </pre>

 * <p><b>Corrected terminators.</b> This table previously read
 * {@code function -> fend} and {@code class -> cend}. Neither token is what
 * Neural Code actually writes, so {@code fnend} and {@code csend} lines were
 * treated as ordinary text, every function and class stayed on the open stack
 * to EOF, and both were then discarded as unclosed -- which is exactly why
 * functions and classes produced no fold marker while loops and comment runs
 * did.
 *
 * The {@code not} variant changes nothing: detection keys off the FIRST word of
 * the line, so {@code if not D == 51:} is still an {@code if} and still closes
 * on {@code iend}.
 *
 * <p>Every kind now has its own terminator, so no token is shared. Matching is
 * still done with a stack keyed on the EXPECTED TERMINATOR rather than on the
 * opener word: that is what lets a stray terminator be recognised as orphaned
 * instead of silently closing the wrong block, and it costs nothing to keep.
 *
 * <h3>Comment blocks</h3>
 * Lines whose first non-blank characters are {@code \\} fold together as one
 * region, starting at the first comment line and ending at the last one.
 * <b>Blank lines between them do not break the run</b>: a commented-out
 * section with empty lines in it is still one section, exactly as it reads.
 * Only a line of real code ends a run, and blank lines after the last comment
 * line are not part of it.
 *
 * <h3>Minimum size</h3>
 * A region folds only when it spans at least {@link #MIN_REGION_LINES} lines,
 * header and closing line included. A two- or three-line block gains nothing
 * from a fold marker, so it gets none -- the same rule for if / for / while /
 * function / class blocks and for comment runs.
 *
 * <h3>Unclosed blocks</h3>
 * A block with no matching terminator produces NO region, so a half-typed
 * {@code for} never shows a fold marker.
 *
 * <p>This class is pure and side-effect free -- it never touches the editor,
 * which makes it trivially unit-testable.
 */
public final class FoldParser {

    /** Line comment token. In UPI source this is a pair of backslashes. */
    public static final String COMMENT_TOKEN = "\\\\";

    /**
     * Fewest lines, header and closer included, a region must span to become
     * foldable. Applies to every kind of region. 4 means a 4-line block folds
     * and a 3-line block does not.
     */
    public static final int MIN_REGION_LINES = 4;

    /** First word of a line, ignoring leading whitespace. */
    private static final Pattern FIRST_WORD = Pattern.compile("^([A-Za-z_][A-Za-z0-9_]*)");

    /** opener keyword -&gt; kind */
    private static final Map<String, FoldRegion.Kind> OPENERS = new HashMap<>();

    /** terminator keyword -&gt; true (fast membership test) */
    private static final Map<String, Boolean> TERMINATORS = new HashMap<>();

    static {
        OPENERS.put("if", FoldRegion.Kind.IF);
        OPENERS.put("for", FoldRegion.Kind.FOR);
        OPENERS.put("while", FoldRegion.Kind.WHILE);
        OPENERS.put("function", FoldRegion.Kind.FUNCTION);
        OPENERS.put("class", FoldRegion.Kind.CLASS);

        // Sourced from FoldRegion.Kind so the two can never drift apart again.
        for (FoldRegion.Kind kind : FoldRegion.Kind.values()) {
            if (!kind.terminator().isEmpty()) {
                TERMINATORS.put(kind.terminator(), Boolean.TRUE);
            }
        }
    }

    private FoldParser() {
        // Utility class.
    }

    /** One entry of the open-block stack. */
    private static final class Open {
        final int line;
        final FoldRegion.Kind kind;

        Open(int line, FoldRegion.Kind kind) {
            this.line = line;
            this.kind = kind;
        }
    }

    /**
     * Parses the whole document.
     *
     * @param text the editor text (may be null)
     * @return regions sorted by start line, each guaranteed foldable
     */
    public static List<FoldRegion> parse(String text) {
        List<FoldRegion> regions = new ArrayList<>();
        if (text == null || text.isEmpty()) {
            return regions;
        }

        String[] lines = text.split("\n", -1);
        Deque<Open> stack = new ArrayDeque<>();

        int commentRunStart = -1;
        int commentRunEnd = -1;

        for (int i = 0; i < lines.length; i++) {
            String trimmed = stripLine(lines[i]);

            // ---- comment runs -------------------------------------------------
            if (isCommentLine(trimmed)) {
                if (commentRunStart < 0) {
                    commentRunStart = i;
                }
                commentRunEnd = i;
                // A commented-out keyword must never open or close a block.
                continue;
            }
            if (trimmed.isEmpty()) {
                // A blank line neither ends a comment run nor opens anything;
                // the run's end stays on its last comment line.
                continue;
            }
            if (commentRunStart >= 0) {
                addRegion(regions, commentRunStart, commentRunEnd, FoldRegion.Kind.COMMENT);
                commentRunStart = -1;
                commentRunEnd = -1;
            }

            // ---- keywords -----------------------------------------------------
            String word = firstWord(trimmed);
            if (word == null) {
                continue;
            }

            if (TERMINATORS.containsKey(word)) {
                closeBlock(regions, stack, word, i);
            } else {
                FoldRegion.Kind kind = OPENERS.get(word);
                if (kind != null) {
                    stack.push(new Open(i, kind));
                }
            }
        }

        // A comment run that reaches the end of the file.
        if (commentRunStart >= 0) {
            addRegion(regions, commentRunStart, commentRunEnd, FoldRegion.Kind.COMMENT);
        }

        // Anything still on the stack is unclosed -> deliberately dropped.
        regions.sort((a, b) -> Integer.compare(a.getStartLine(), b.getStartLine()));
        return regions;
    }

    /**
     * Convenience index for the gutter factory, which asks "does a region start
     * on line N?" once per rendered line.
     *
     * @param regions parsed regions
     * @return map of start line -&gt; region
     */
    public static Map<Integer, FoldRegion> indexByStartLine(List<FoldRegion> regions) {
        Map<Integer, FoldRegion> byStart = new HashMap<>();
        for (FoldRegion region : regions) {
            // If two regions somehow start on the same line, the outer (longer)
            // one wins, because that is the one the marker should toggle.
            FoldRegion existing = byStart.get(region.getStartLine());
            if (existing == null || region.getEndLine() > existing.getEndLine()) {
                byStart.put(region.getStartLine(), region);
            }
        }
        return byStart;
    }

    /* =====================================================================
     * INTERNALS
     * ===================================================================== */

    /**
     * Pops the stack down to the newest block expecting {@code terminator} and
     * emits its region. Blocks skipped over on the way down were never closed,
     * so they are discarded rather than guessed at.
     */
    private static void closeBlock(List<FoldRegion> regions, Deque<Open> stack,
            String terminator, int line) {
        List<Open> skipped = new ArrayList<>();
        while (!stack.isEmpty()) {
            Open open = stack.pop();
            if (open.kind.terminator().equals(terminator)) {
                addRegion(regions, open.line, line, open.kind);
                return;
            }
            skipped.add(open);
        }
        // No match at all: the terminator is orphaned. Put back what we popped
        // so a later, correct terminator can still close those blocks.
        for (int i = skipped.size() - 1; i >= 0; i--) {
            stack.push(skipped.get(i));
        }
    }

    /** Adds a region only when it spans at least {@link #MIN_REGION_LINES} lines. */
    private static void addRegion(List<FoldRegion> regions, int start, int end, FoldRegion.Kind kind) {
        if (end - start + 1 >= MIN_REGION_LINES) {
            regions.add(new FoldRegion(start, end, kind));
        }
    }

    private static boolean isCommentLine(String trimmed) {
        return trimmed.startsWith(COMMENT_TOKEN);
    }

    private static String stripLine(String raw) {
        String line = raw;
        if (line.endsWith("\r")) {
            line = line.substring(0, line.length() - 1);
        }
        return line.strip();
    }

    private static String firstWord(String trimmed) {
        if (trimmed.isEmpty()) {
            return null;
        }
        Matcher matcher = FIRST_WORD.matcher(trimmed);
        if (!matcher.find()) {
            return null;
        }
        return matcher.group(1).toLowerCase(Locale.ROOT);
    }
}
