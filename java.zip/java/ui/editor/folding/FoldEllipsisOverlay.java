package ui.editor.folding;

import java.util.Collection;
import java.util.Optional;

import org.fxmisc.richtext.CodeArea;

import javafx.application.Platform;
import javafx.geometry.Bounds;
import javafx.geometry.Pos;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;

/**
 * Draws the {@code ...} badge at the end of every collapsed header line.
 *
 * <h3>Why the dots are shapes and not a string</h3>
 * The badge is deliberately shorter than a line of code, and the previous
 * version put a three-character string in a Label forced to that height. A
 * Label sizes and positions its text from the font's ascent and descent, not
 * from the box: force the box below the font's line height and the glyphs keep
 * their baseline, so they sit low in the badge and the bottom of each dot is
 * clipped away. Changing the font size only moves the problem, because the
 * relationship between baseline and box depends on the font.
 *
 * <p>Three {@link Circle}s in a centred {@link HBox} have no baseline to fight:
 * an HBox with {@code Pos.CENTER} puts them on the exact vertical middle of
 * whatever height the badge is given, at any font size and on any platform.
 * That is the whole fix for the clipped dots.
 *
 * <h3>Why an overlay rather than inserted text</h3>
 * The whole point of the fold API is that the document is never modified, so
 * what {@code getText()} returns -- and therefore what gets saved, run and
 * turned into semantic files -- is byte-for-byte what the user typed. Inserting
 * a literal "..." would poison all of that. The badge is painted on a
 * transparent layer above the text and is completely non-editable: it is not
 * part of the document, cannot be selected, cannot be copied and cannot be
 * typed over.
 *
 * <p>Badges are positioned from live character bounds, so they track scrolling,
 * font changes and window resizing -- {@link FoldingManager} re-runs this on
 * scroll and on resize. A collapsed block scrolled out of view simply has no
 * badge, because RichTextFX reports no bounds for it.
 *
 * <p>Package-private: only {@link FoldingManager} calls it.
 */
final class FoldEllipsisOverlay {

    /** Horizontal gap between the end of the line and the badge. */
    private static final double GAP = 8;

    /**
     * Badge height as a fraction of the line height.
     *
     * <p>A full-height badge reads as a second, competing line of text beside
     * the code. Around two thirds it is a marker sitting on the line rather
     * than an object occupying it -- which is the VS Code look.
     */
    private static final double HEIGHT_FRACTION = 0.62;

    /** Floor, so the badge never collapses to nothing at small font sizes. */
    private static final double MIN_HEIGHT = 10;

    /** Radius of each dot, in px. */
    private static final double DOT_RADIUS = 1.4;

    /** Gap between dots, in px. */
    private static final double DOT_SPACING = 3;

    private FoldEllipsisOverlay() {
        // Utility class.
    }

    /**
     * Rebuilds every badge. Cheap: there is one node per collapsed block, and
     * collapsed blocks are counted in the handful.
     *
     * @param editor          the editor
     * @param collapsedStarts header lines currently collapsed AND on screen --
     *                        {@link FoldingManager} filters out headers buried
     *                        inside another collapsed block before calling
     */
    static void update(CodeArea editor, Collection<Integer> collapsedStarts) {
        if (!(editor instanceof FoldableCodeArea foldable)) {
            return;
        }
        Pane overlay = foldable.getFoldOverlay();
        overlay.getChildren().clear();
        if (collapsedStarts == null || collapsedStarts.isEmpty()) {
            return;
        }

        int paragraphCount = editor.getParagraphs().size();
        for (Integer start : collapsedStarts) {
            if (start == null || start < 0 || start >= paragraphCount) {
                continue;
            }
            addBadge(editor, overlay, start);
        }
    }

    /**
     * Schedules an {@link #update} on the next pulse. Character bounds are only
     * meaningful once layout has run, so every trigger (scroll, resize, fold)
     * goes through here.
     *
     * @param editor          the editor
     * @param collapsedStarts visible collapsed header lines
     */
    static void updateLater(CodeArea editor, Collection<Integer> collapsedStarts) {
        Platform.runLater(() -> update(editor, collapsedStarts));
    }

    /* =====================================================================
     * INTERNALS
     * ===================================================================== */

    private static void addBadge(CodeArea editor, Pane overlay, int paragraph) {
        Bounds local;
        try {
            int length = editor.getParagraphLength(paragraph);
            if (length <= 0) {
                // A fold header always has text on it, so an empty paragraph
                // here means the document changed under us. Skip, don't guess.
                return;
            }
            int end = editor.getAbsolutePosition(paragraph, length);
            Optional<Bounds> onScreen = editor.getCharacterBoundsOnScreen(end - 1, end);
            if (onScreen.isEmpty()) {
                // Scrolled out of view -- nothing to draw.
                return;
            }
            local = overlay.screenToLocal(onScreen.get());
        } catch (Exception e) {
            // Index maths can race a concurrent edit; a missing badge is a far
            // better outcome than an exception on the FX thread.
            return;
        }
        if (local == null) {
            return;
        }

        double lineHeight = Math.max(MIN_HEIGHT, local.getHeight());
        double height = Math.max(MIN_HEIGHT, lineHeight * HEIGHT_FRACTION);

        HBox badge = buildBadge(height);
        badge.setLayoutX(local.getMaxX() + GAP);
        // Centre the badge on the line, so it keeps the line's optical middle
        // instead of riding high or low.
        badge.setLayoutY(local.getMinY() + (lineHeight - height) / 2);
        overlay.getChildren().add(badge);
    }

    /**
     * Builds the badge itself: a fixed-height pill with three dots centred both
     * ways inside it.
     *
     * <p>The height is pinned (min = pref = max) because the badge is on an
     * unmanaged overlay and must not resize itself to its content. The width is
     * left to the content plus the CSS padding.
     */
    private static HBox buildBadge(double height) {
        HBox badge = new HBox(DOT_SPACING);
        badge.getStyleClass().add("fold-ellipsis");
        badge.setAlignment(Pos.CENTER);
        badge.setMouseTransparent(true);
        badge.setFocusTraversable(false);
        badge.setFillHeight(false);

        badge.setPrefHeight(height);
        badge.setMinHeight(height);
        badge.setMaxHeight(height);

        for (int i = 0; i < 3; i++) {
            Circle dot = new Circle(DOT_RADIUS);
            dot.getStyleClass().add("fold-ellipsis-dot");
            dot.setSmooth(true);
            badge.getChildren().add(dot);
        }
        return badge;
    }
}
