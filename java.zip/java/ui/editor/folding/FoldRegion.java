package ui.editor.folding;

/**
 * One foldable block of the document.
 *
 * <p>Line indices are ZERO-BASED paragraph indices, exactly as RichTextFX and
 * the existing gutter factory use them. The user-visible line number is
 * {@code getStartLine() + 1}.
 *
 * <p>{@link #getStartLine()} is the header line and always stays visible.
 * Everything from {@code startLine + 1} through {@link #getEndLine()} inclusive
 * is hidden when the region is collapsed -- so the terminator line
 * ({@code fend}, {@code iend} ...) disappears with the body, which is the
 * MATLAB behaviour asked for: fold 5..100 and the next visible number is 101.
 *
 * <p><b>Accessor naming.</b> Every getter on this class uses the JavaBean
 * {@code getXxx()} form. There is no {@code startLine()}, {@code endLine()} or
 * {@code describe()} -- if the compiler reports those as undefined, the caller
 * is from a different version of the folding package and needs replacing.
 */
public final class FoldRegion {

    /**
     * The colour family a kind belongs to in the gutter guide. Several kinds
     * share one family, which is what keeps the palette to three hues instead
     * of six.
     */
    public enum Family {
        /** if / for / while, and comment runs: the neutral grey guide. */
        LOOP("loop"),
        /** function blocks: dark orange. */
        FUNCTION("fn"),
        /** class blocks: cadet blue. */
        CLASS("class");

        private final String token;

        Family(String token) {
            this.token = token;
        }

        /**
         * @return the fragment used to build the guide's CSS style class, e.g.
         *         {@code fold-guide-loop-fn-class}
         */
        public String token() {
            return token;
        }
    }

    /**
     * What opened the block. Used for tooltips, guide colour and re-validation.
     *
     * <p><b>Terminators are the Neural Code ones, not guesses.</b> Verified
     * against real .nc sources: a function closes on {@code fnend} and a class
     * on {@code csend}. An earlier version of this enum had {@code fend} and
     * {@code cend} here, which is why functions and classes never folded --
     * neither token ever appeared in a document, so both block kinds sat on the
     * parser's open stack until EOF and were discarded as unclosed.
     */
    public enum Kind {
        IF("if", "iend", Family.LOOP),
        FOR("for", "fend", Family.LOOP),
        WHILE("while", "wend", Family.LOOP),
        FUNCTION("function", "fnend", Family.FUNCTION),
        CLASS("class", "csend", Family.CLASS),
        /** A run of consecutive {@code \\} comment lines. Has no terminator. */
        COMMENT("comment", "", Family.LOOP);

        private final String opener;
        private final String terminator;
        private final Family family;

        Kind(String opener, String terminator, Family family) {
            this.opener = opener;
            this.terminator = terminator;
            this.family = family;
        }

        /** @return the keyword that opens this kind of block */
        public String opener() {
            return opener;
        }

        /** @return the keyword that closes it, or "" for comment runs */
        public String terminator() {
            return terminator;
        }

        /** @return the colour family this kind's guide line belongs to */
        public Family family() {
            return family;
        }
    }

    private final int startLine;
    private final int endLine;
    private final Kind kind;

    public FoldRegion(int startLine, int endLine, Kind kind) {
        this.startLine = startLine;
        this.endLine = endLine;
        this.kind = kind;
    }

    /** @return zero-based header line; always stays visible */
    public int getStartLine() {
        return startLine;
    }

    /** @return zero-based terminator line; hidden when collapsed */
    public int getEndLine() {
        return endLine;
    }

    /** @return what opened this block */
    public Kind getKind() {
        return kind;
    }

    /** @return the colour family this region's guide line belongs to */
    public Family getFamily() {
        return kind.family();
    }

    /** @return first line hidden when this region collapses */
    public int getFirstHiddenLine() {
        return startLine + 1;
    }

    /** @return last line hidden when this region collapses (inclusive) */
    public int getLastHiddenLine() {
        return endLine;
    }

    /** @return number of lines that disappear when collapsed */
    public int getHiddenLineCount() {
        return endLine - startLine;
    }

    /** @return true when this region actually hides at least one line */
    public boolean isFoldable() {
        return endLine > startLine;
    }

    /**
     * @param line zero-based paragraph index
     * @return true when {@code line} is inside the hidden span
     */
    public boolean hides(int line) {
        return line >= getFirstHiddenLine() && line <= getLastHiddenLine();
    }

    /**
     * @param line zero-based paragraph index
     * @return true when {@code line} is anywhere in the block, header included
     */
    public boolean spans(int line) {
        return line >= startLine && line <= endLine;
    }

    @Override
    public String toString() {
        return kind + "[" + (startLine + 1) + ".." + (endLine + 1) + "]";
    }
}
