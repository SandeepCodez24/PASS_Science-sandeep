package ui.editor;

import java.util.function.BooleanSupplier;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.fxmisc.richtext.CodeArea;

import javafx.application.Platform;
import javafx.scene.control.Tab;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyEvent;
import language.language_ui.handler.EditorActions;
import language.language_ui.handler.EditorIndentationHandler;
import language.replace.Greek;
import language.replace.Subscript;
import language.replace.Superscript;
import language.replace.Tamil;
import ui.UI_Main;
import ui.ui_functions.FunctionProvider;
import ui.ui_functions.SuggestionPopup;
import ui.ui_functions.SuggestionProvider;
import ui.ui_functions.suggestion_functions.NcFileIndex;
import ui.ui_functions.suggestion_functions.SuggestionScope;
import ui.ui_functions.suggestion_functions.SuggestionSettings;

/**
 * Wires the suggestion popup to an editor: when it opens, what it is given to
 * match, and what accepting a row writes.
 *
 * <h3>What changed</h3>
 * <ol>
 * <li><b>Suggestions work after {@code ^}.</b> The word scan in
 * {@code extractSuggestionPattern} walked straight through a single caret, so
 * typing {@code A^sq} asked the popup for {@code A^sq}, which matches nothing.
 * A lone {@code ^} is the power operator and now ends the word like any other
 * operator; only the {@code ^^} superscript-mode pair is still walked through.
 * Accepting a row uses the same scan, so it replaces {@code sq} and leaves
 * {@code A^} alone.</li>
 * <li><b>Enter accepts again.</b> {@code EditorIndentationHandler} listens for
 * Enter as an event <i>filter</i>, which runs before this class's key handler,
 * so Enter always inserted a newline even with the popup open. The popup now
 * publishes "am I showing?" and "accept the highlighted row" on the editor's
 * properties, and the indentation filter defers to them.</li>
 * <li><b>{@code Owner.} is passed through whole.</b> Typing {@code A.ag} used
 * to send only {@code ag}, so the popup listed every name containing
 * {@code ag}. The pattern now carries the owner ({@code A.ag}) and the filter
 * completes that class's members only.</li>
 * <li><b>User functions insert like built-ins.</b> Accepting {@code f(x)}
 * writes {@code f(} + {@code )} with the caret between the brackets, and does
 * not add a second bracket when one already follows the caret.</li>
 * <li><b>Accepting a row edits only the typed word.</b> The CodeArea path used
 * to replace the entire document to insert one word, which reset the undo
 * granularity and every paragraph style on the way.</li>
 * <li><b>No suggestions in strings or comments.</b> The popup stays closed
 * while the caret is inside a {@code "..."} or {@code '...'} literal (including
 * one continued with {@code ~~}), or after a {@code #} or {@code \\} comment
 * marker. The test is {@link SuggestionScope}, which reuses the editor's own
 * string/comment rules rather than a copy of them.</li>
 * <li><b>The popup follows the user's settings.</b> With every suggestion
 * group unticked it never opens; the groups themselves are filtered in
 * {@code SuggestionFilterService}.</li>
 * <li><b>Indentation edits never open it.</b> Tab, Shift+Tab, Enter and the
 * closer dedent run under {@link EditorIndentationHandler}'s guard, and the
 * trigger ignores text changes made under it.</li>
 * <li><b>Script names are offered, except this one.</b> {@code .nc} scripts in
 * the working folder appear below variables and functions ({@link NcFileIndex}).
 * The popup is told this tab's own file name, read live from the tab title, so
 * typing in {@code AAAA.nc} never offers {@code AAAA} -- even after the file
 * is renamed or saved under a new name. Accepting a script row inserts its bare
 * name, like a variable.</li>
 * </ol>
 */
public final class EditorSuggestionHandler {

    private static final String SUBSCRIPT_MODE_KEY = "subscriptMode";
    private static final String SUBSCRIPT_MODE_START_KEY = "subscriptModeStart";
    private static final String SUBSCRIPT_MODE_MARKER_START_KEY = "subscriptModeMarkerStart";
    private static final String SUBSCRIPT_MODE_STARTED_KEY = "subscriptModeStarted";
    private static final String SUBSCRIPT_MODE_RAW_KEY = "subscriptModeRaw";
    private static final String SUBSCRIPT_MODE_RENDERED_LEN_KEY = "subscriptModeRenderedLen";
    private static final String SUPERSCRIPT_MODE_KEY = "superscriptMode";
    private static final String SUPERSCRIPT_MODE_START_KEY = "superscriptModeStart";
    private static final String SUPERSCRIPT_MODE_MARKER_START_KEY = "superscriptModeMarkerStart";
    private static final String SUPERSCRIPT_MODE_STARTED_KEY = "superscriptModeStarted";
    private static final String SUPERSCRIPT_MODE_RAW_KEY = "superscriptModeRaw";

    private EditorSuggestionHandler() {
    }

    public static void wireCodeAreaSuggestions(UI_Main ide, CodeArea editor, Tab tab) {
        SuggestionPopup suggestionPopup = new SuggestionPopup();
        suggestionPopup.setTheme(ide.currentTheme);
        wireScriptFiles(ide, suggestionPopup, tab);

        // Let the indentation handler's Enter filter defer to the popup.
        editor.getProperties().put(EditorIndentationHandler.POPUP_SHOWING_KEY,
                (BooleanSupplier) suggestionPopup::isSuggestionShowing);
        editor.getProperties().put(EditorIndentationHandler.POPUP_ACCEPT_KEY,
                (Runnable) () -> insertSelectedSuggestion(editor, suggestionPopup));
        editor.getProperties().put(EditorIndentationHandler.POPUP_HIDE_KEY,
                (Runnable) suggestionPopup::hide);

        editor.textProperty().addListener((obs, oldText, newText) -> {
            if (!tab.getText().endsWith("*")) {
                tab.setText(tab.getText() + "*");
            }

            if (ide.stage != null && ide.stage.getScene() != null) {
                String text = editor.getText();
                int caretPos = editor.getCaretPosition();
                String contextText = text.substring(0, Math.min(caretPos, text.length()));

                SuggestionProvider.updateVariablesFromText(text);

                // Re-indenting is not typing; strings and comments are not code;
                // and with every group unticked there is nothing to offer.
                if (EditorIndentationHandler.isApplyingEdit(editor)
                        || !SuggestionSettings.anyPopupGroupEnabled()
                        || SuggestionScope.isSuppressed(text, caretPos)) {
                    suggestionPopup.hide();
                    return;
                }

                String pattern = extractSuggestionPattern(text, caretPos);

                if (Boolean.TRUE.equals(editor.getProperties().get(SUBSCRIPT_MODE_KEY))) {
                    Object rawObj = editor.getProperties().get(SUBSCRIPT_MODE_RAW_KEY);
                    if (rawObj instanceof String raw && !raw.isBlank()) {
                        pattern = extractModeSuggestionPattern(raw);
                        contextText = contextText + "__" + raw;
                    }
                } else if (Boolean.TRUE.equals(editor.getProperties().get(SUPERSCRIPT_MODE_KEY))) {
                    Object rawObj = editor.getProperties().get(SUPERSCRIPT_MODE_RAW_KEY);
                    if (rawObj instanceof String raw && !raw.isBlank()) {
                        pattern = extractModeSuggestionPattern(raw);
                        contextText = contextText + "^^" + raw;
                    }
                }

                if (pattern != null && !pattern.trim().isEmpty()) {
                    suggestionPopup.setTheme(ide.currentTheme);
                    suggestionPopup.showSuggestions(editor, pattern, contextText, ide.stage);
                } else {
                    suggestionPopup.hide();
                }
            }
        });

        editor.setOnKeyReleased(e -> {
            EditorActions.handleReplacement(editor, e);

            boolean justEnteredSubMode = Boolean.TRUE.equals(editor.getProperties().get(SUBSCRIPT_MODE_KEY))
                    && Boolean.FALSE.equals(editor.getProperties().get(SUBSCRIPT_MODE_STARTED_KEY))
                    && editor.getProperties().get(SUBSCRIPT_MODE_MARKER_START_KEY) != null;
            boolean justEnteredSupMode = Boolean.TRUE.equals(editor.getProperties().get(SUPERSCRIPT_MODE_KEY))
                    && Boolean.FALSE.equals(editor.getProperties().get(SUPERSCRIPT_MODE_STARTED_KEY))
                    && editor.getProperties().get(SUPERSCRIPT_MODE_MARKER_START_KEY) != null;

            // FAST-TYPING FIX (S__ -> S_ collapse):
            // Do NOT trust e.getText() here. On KEY_RELEASED, and especially
            // when typing fast, getText() is frequently empty or coalesced, so
            // the old guard failed to notice that a '_' or '^' had just been
            // typed. A stale deferred handleReplacement then fired AFTER the
            // second '_' had entered subscript mode and ate one underscore.
            // Instead we read the always-up-to-date document state: if a lone
            // pair-marker ('_' or '^') is sitting just before the caret, a
            // '__'/'^^' pair may still be forming, so we must not schedule the
            // generic deferred replacement.
            if (!isPendingPairMarker(editor) && !justEnteredSubMode && !justEnteredSupMode) {
                Platform.runLater(() -> {
                    // Re-check at execution time: the schedule->run gap is
                    // exactly where the fast-typing race lived. Bail if a pair
                    // marker is now pending or a styled mode is active, so a
                    // stale runnable can never corrupt a forming/started group.
                    if (isPendingPairMarker(editor)
                            || Boolean.TRUE.equals(editor.getProperties().get(SUBSCRIPT_MODE_KEY))
                            || Boolean.TRUE.equals(editor.getProperties().get(SUPERSCRIPT_MODE_KEY))) {
                        return;
                    }
                    EditorActions.handleReplacement(editor);
                });
            }
        });

        // Atomic single-press caret / delete over a finished sub/superscript
        // group. Registered as a KEY_PRESSED *event filter* (capturing
        // phase) so it runs BEFORE the CodeArea's built-in caret move /
        // delete behaviour; consuming the event there suppresses the default
        // per-character step. Skipped while the suggestion popup is open so
        // popup key handling stays intact.
        editor.addEventFilter(KeyEvent.KEY_PRESSED, e -> {
            if (!suggestionPopup.isSuggestionShowing()) {
                EditorActions.handleStyledGroupNavigation(editor, e);
            }
        });

        editor.setOnKeyPressed(e -> {
            if (suggestionPopup.isSuggestionShowing()) {
                switch (e.getCode()) {
                    case UP -> {
                        suggestionPopup.selectPrevious();
                        e.consume();
                    }
                    case DOWN -> {
                        suggestionPopup.selectNext();
                        e.consume();
                    }
                    case ENTER, TAB -> {
                        // Tab and Enter both accept the highlighted row.
                        // TAB was previously unhandled here, so the editor's
                        // default tab-insert fired instead of the completion.
                        insertSelectedSuggestion(editor, suggestionPopup);
                        e.consume();
                    }
                    case LEFT, RIGHT -> {
                        // Dismiss without accepting. The event is deliberately
                        // NOT consumed, so the caret still moves one character
                        // exactly as it would with the popup closed. This is
                        // the non-destructive escape hatch the space bar never
                        // was: space inserted a character to get out, an arrow
                        // key simply steps away.
                        suggestionPopup.hide();
                    }
                    case ESCAPE -> {
                        suggestionPopup.hide();
                        e.consume();
                    }
                    default -> {
                    }
                }
            }
        });

        suggestionPopup.setOnInsertSuggestion(() -> insertSelectedSuggestion(editor, suggestionPopup));
    }

    /**
     * Points the script-file suggestions at the working folder and tells this
     * tab's popup which file it is typing in. The name is read from the tab
     * title every time, so a rename or Save As is picked up without rewiring.
     */
    private static void wireScriptFiles(UI_Main ide, SuggestionPopup popup, Tab tab) {
        NcFileIndex.setWorkingFolderSupplier(ide::getCurrentFolder);
        popup.setExcludedFileSupplier(() -> NcFileIndex.nameFromTabTitle(tab.getText()));
    }

    /**
     * Reliable, document-based detection of a pair-marker that may still be
     * forming. Reads the actual editor text (never the flaky KEY_RELEASED
     * event text), so it is correct regardless of typing speed.
     *
     * <p>Returns {@code true} when the character(s) immediately before the caret
     * are one or two '_' or '^' markers, i.e. the user is in the middle of
     * typing {@code __} or {@code ^^}. While that is true we must not run the
     * generic deferred replacement, because it could consume one of the
     * underscores/carets and collapse {@code S__} into {@code S_}.
     */
    private static boolean isPendingPairMarker(CodeArea editor) {
        int caret = editor.getCaretPosition();
        if (caret <= 0) {
            return false;
        }
        String text = editor.getText();
        if (text == null || caret > text.length()) {
            return false;
        }
        char last = text.charAt(caret - 1);
        if (last != '_' && last != '^') {
            return false;
        }
        // Count the run of identical trailing markers (cap at 2 -- that is all
        // we need to know a pair is forming/just formed).
        int count = 0;
        int i = caret;
        while (i > 0 && text.charAt(i - 1) == last && count < 2) {
            count++;
            i--;
        }
        return count == 1 || count == 2;
    }

    public static void wireTextAreaSuggestions(UI_Main ide, TextArea area, Tab tab) {
        SuggestionPopup suggestionPopup = new SuggestionPopup();
        suggestionPopup.setTheme(ide.currentTheme);
        wireScriptFiles(ide, suggestionPopup, tab);

        area.textProperty().addListener((obs, oldText, newText) -> {
            if (!tab.getText().endsWith("*")) {
                tab.setText(tab.getText() + "*");
            }

            if (ide.stage != null && ide.stage.getScene() != null) {
                String text = area.getText();
                int caretPos = area.getCaretPosition();
                String contextText = text.substring(0, Math.min(caretPos, text.length()));

                SuggestionProvider.updateVariablesFromText(text);
                String pattern = extractSuggestionPattern(text, caretPos);

                if (pattern != null && !pattern.trim().isEmpty()) {
                    suggestionPopup.setTheme(ide.currentTheme);
                    suggestionPopup.showSuggestions(area, pattern, contextText, ide.stage);
                } else {
                    suggestionPopup.hide();
                }
            }
        });

        area.setOnKeyPressed(e -> {
            if (suggestionPopup.isSuggestionShowing()) {
                switch (e.getCode()) {
                    case UP -> {
                        suggestionPopup.selectPrevious();
                        e.consume();
                    }
                    case DOWN -> {
                        suggestionPopup.selectNext();
                        e.consume();
                    }
                    case ENTER, TAB -> {
                        insertSelectedSuggestion(area, suggestionPopup);
                        e.consume();
                    }
                    case LEFT, RIGHT -> {
                        suggestionPopup.hide();
                    }
                    case ESCAPE -> {
                        suggestionPopup.hide();
                        e.consume();
                    }
                    default -> {
                    }
                }
            }
        });

        suggestionPopup.setOnInsertSuggestion(() -> insertSelectedSuggestion(area, suggestionPopup));
    }

    private static void handleLiveReplacement(TextArea area) {
        String text = area.getText();
        int caret = area.getCaretPosition();
        if (caret == 0) {
            return;
        }

        int lineStart = text.lastIndexOf('\n', caret - 1) + 1;
        String lineText = text.substring(lineStart, caret);
        boolean subscriptMode = Boolean.TRUE.equals(area.getProperties().get(SUBSCRIPT_MODE_KEY));

        if (!subscriptMode && lineText.endsWith("__")) {
            int markerStart = caret - 2;
            int modeStart = caret;
            area.getProperties().put(SUBSCRIPT_MODE_KEY, Boolean.TRUE);
            area.getProperties().put(SUBSCRIPT_MODE_START_KEY, modeStart);
            area.getProperties().put(SUBSCRIPT_MODE_MARKER_START_KEY, markerStart);
            area.getProperties().put(SUBSCRIPT_MODE_STARTED_KEY, Boolean.FALSE);
            return;
        }

        if (subscriptMode) {
            Integer modeStart = (Integer) area.getProperties().get(SUBSCRIPT_MODE_START_KEY);
            Integer markerStart = (Integer) area.getProperties().get(SUBSCRIPT_MODE_MARKER_START_KEY);
            Boolean started = (Boolean) area.getProperties().get(SUBSCRIPT_MODE_STARTED_KEY);
            if (modeStart == null) {
                modeStart = caret;
                area.getProperties().put(SUBSCRIPT_MODE_START_KEY, modeStart);
            }
            if (started == null) {
                started = Boolean.FALSE;
                area.getProperties().put(SUBSCRIPT_MODE_STARTED_KEY, Boolean.FALSE);
            }

            if (lineText.isEmpty()) {
                area.getProperties().put(SUBSCRIPT_MODE_KEY, Boolean.FALSE);
                area.getProperties().remove(SUBSCRIPT_MODE_START_KEY);
                area.getProperties().remove(SUBSCRIPT_MODE_MARKER_START_KEY);
                area.getProperties().remove(SUBSCRIPT_MODE_STARTED_KEY);
                return;
            }

            int typedCharIndex = caret - 1;
            if (typedCharIndex < modeStart) {
                return;
            }

            char ch = lineText.charAt(lineText.length() - 1);

            if (ch == ' ') {
                if (!started && markerStart != null && markerStart >= 0 && markerStart + 2 <= area.getLength()) {
                    replaceInArea(area, markerStart, markerStart + 2, "");
                }
                replaceInArea(area, area.getCaretPosition() - 1, area.getCaretPosition(), "");
                area.getProperties().put(SUBSCRIPT_MODE_KEY, Boolean.FALSE);
                area.getProperties().remove(SUBSCRIPT_MODE_START_KEY);
                area.getProperties().remove(SUBSCRIPT_MODE_MARKER_START_KEY);
                area.getProperties().remove(SUBSCRIPT_MODE_STARTED_KEY);
                return;
            }

            if (ch == '\u200D' || ch == '\u200C' || ch == '{' || ch == '}') {
                return;
            }

            String styled = Subscript.hasNumericSubscript(ch)
                    ? Subscript.numericSubscript(ch)
                    : Subscript.styledSubscript(ch);

            if (!started && markerStart != null) {
                replaceInArea(area, markerStart, caret, styled);
                area.getProperties().put(SUBSCRIPT_MODE_STARTED_KEY, Boolean.TRUE);
                area.getProperties().remove(SUBSCRIPT_MODE_MARKER_START_KEY);
                area.getProperties().put(SUBSCRIPT_MODE_START_KEY, markerStart + styled.length());
            } else {
                replaceInArea(area, caret - 1, caret, styled);
            }
            return;
        }

        for (var e : Greek.SYMBOL_MAP.entrySet()) {
            String pattern = "^" + e.getKey();
            if (lineText.endsWith(pattern)) {
                char ch = e.getValue().charAt(0);
                String styled = Superscript.styledSuperscript(ch);
                replaceInArea(area, lineStart + lineText.length() - pattern.length(), caret, styled);
                return;
            }
        }

        for (var e : Greek.SYMBOL_MAP.entrySet()) {
            if (lineText.endsWith(e.getKey())) {
                replaceInArea(area, lineStart + lineText.length() - e.getKey().length(), caret, e.getValue());
                return;
            }
        }

        int openBraceSup = lineText.lastIndexOf("^{");
        if (openBraceSup != -1 && lineText.endsWith("}") && openBraceSup < lineText.length() - 2) {
            String content = lineText.substring(openBraceSup + 2, lineText.length() - 1);
            if (!content.isBlank()) {
                String replaced = replaceGreekInText(content);
                String styled = Superscript.styledSuperscriptText(replaced);
                replaceInArea(area, lineStart + openBraceSup, caret, styled);
                return;
            }
        }

        if (lineText.length() >= 2) {
            char prev = lineText.charAt(lineText.length() - 2);
            char ch = lineText.charAt(lineText.length() - 1);
            if (prev == '^' && (Character.isLetterOrDigit(ch) || isGreekChar(ch))) {
                String value;
                if (Superscript.hasUnicode(ch)) {
                    value = Superscript.unicode(ch);
                } else {
                    value = Superscript.styledSuperscript(ch);
                }
                replaceInArea(area, lineStart + lineText.length() - 2, caret, value);
                return;
            }
        }

        int openBraceSub = lineText.lastIndexOf("__{");
        if (openBraceSub != -1 && lineText.endsWith("}") && openBraceSub < lineText.length() - 2) {
            String content = lineText.substring(openBraceSub + 3, lineText.length() - 1);
            if (!content.isBlank()) {
                String replaced = replaceGreekInText(content);
                String styled = Subscript.styledSubscriptText(replaced);
                replaceInArea(area, lineStart + openBraceSub, caret, styled);
                return;
            }
        }

        for (var e : Tamil.TAMIL_VOWEL_MAP.entrySet()) {
            if (lineText.endsWith(e.getKey())) {
                replaceInArea(area, lineStart + lineText.length() - e.getKey().length(), caret, e.getValue());
                return;
            }
        }

        for (var e : Tamil.TAMIL_CONSONANT_MAP.entrySet()) {
            if (lineText.endsWith(e.getKey())) {
                replaceInArea(area, lineStart + lineText.length() - e.getKey().length(), caret, e.getValue());
                return;
            }
        }
    }

    private static void replaceInArea(TextArea area, int start, int end, String replacement) {
        String text = area.getText();
        String newText = text.substring(0, start) + replacement + text.substring(end);
        area.setText(newText);
        area.positionCaret(start + replacement.length());
    }

    private static String replaceGreekInText(String text) {
        String result = text;
        for (var e : Greek.SYMBOL_MAP.entrySet()) {
            result = result.replace(e.getKey(), e.getValue());
        }
        return result;
    }

    private static String replaceSymbolsForSuggestion(String text) {
        if (text == null || text.isEmpty()) {
            return "";
        }

        String result = replaceGreekInText(text);
        for (var e : Tamil.TAMIL_VOWEL_MAP.entrySet()) {
            result = result.replace(e.getKey(), e.getValue());
        }
        for (var e : Tamil.TAMIL_CONSONANT_MAP.entrySet()) {
            result = result.replace(e.getKey(), e.getValue());
        }
        return result;
    }

    private static boolean insertSuggestionInStyledMode(CodeArea editor, SuggestionProvider.Suggestion suggestion) {
        boolean subscriptMode = Boolean.TRUE.equals(editor.getProperties().get(SUBSCRIPT_MODE_KEY));
        boolean superscriptMode = Boolean.TRUE.equals(editor.getProperties().get(SUPERSCRIPT_MODE_KEY));
        if (!subscriptMode && !superscriptMode) {
            return false;
        }

        String category = suggestion.getCategory();
        String code = suggestion.getCode();

        boolean supportedInStyledMode = "Function".equals(category)
                || "Greek".equals(category)
                || "GreekSimple".equals(category)
                || "Tamil".equals(category)
                || "TamilSimple".equals(category)
                || "Math".equals(category)
                || ("Variable".equals(category) && code.startsWith("\\var("));
        if (!supportedInStyledMode) {
            return false;
        }

        String modeRaw = code;

        if ("Function".equals(category)) {
            String functionName = FunctionProvider.extractFunctionName(code);
            if (FunctionProvider.isNotation(functionName)) {
                modeRaw = functionName;
            } else {
                modeRaw = functionName + "()";
            }
        } else if ("GreekSimple".equals(category)) {
            String fullGreekCode = "\\var(\\" + code + ")";
            modeRaw = Greek.SYMBOL_MAP.getOrDefault(fullGreekCode, code);
        } else if ("TamilSimple".equals(category)) {
            String fullTamilCode = "\\var(\\tamil(\\" + code + "))";
            String tamil = Tamil.TAMIL_VOWEL_MAP.get(fullTamilCode);
            if (tamil == null) {
                tamil = Tamil.TAMIL_CONSONANT_MAP.get(fullTamilCode);
            }
            modeRaw = tamil != null ? tamil : code;
        } else if (code.startsWith("_") || code.startsWith("^")) {
            modeRaw = code.substring(1);
        }

        modeRaw = replaceSymbolsForSuggestion(modeRaw);
        if (modeRaw.isBlank()) {
            return false;
        }

        int caretPos = editor.getCaretPosition();
        int modeStart;
        if (subscriptMode) {
            Integer start = (Integer) editor.getProperties().get(SUBSCRIPT_MODE_START_KEY);
            if (start == null) {
                return false;
            }
            modeStart = Math.max(0, Math.min(start, caretPos));

            String existingRaw = (String) editor.getProperties().get(SUBSCRIPT_MODE_RAW_KEY);
            String mergedRaw = mergeStyledModeSuggestionRaw(existingRaw, modeRaw);
            String styled = Subscript.styledSubscriptText(mergedRaw);
            editor.replaceText(modeStart, caretPos, styled);
            editor.moveTo(modeStart + styled.length());
            editor.getProperties().put(SUBSCRIPT_MODE_RAW_KEY, mergedRaw);
            editor.getProperties().put(SUBSCRIPT_MODE_STARTED_KEY, Boolean.TRUE);
            editor.getProperties().put(SUBSCRIPT_MODE_RENDERED_LEN_KEY, styled.length());
            editor.getProperties().remove(SUBSCRIPT_MODE_MARKER_START_KEY);
        } else {
            Integer start = (Integer) editor.getProperties().get(SUPERSCRIPT_MODE_START_KEY);
            if (start == null) {
                return false;
            }
            modeStart = Math.max(0, Math.min(start, caretPos));

            String existingRaw = (String) editor.getProperties().get(SUPERSCRIPT_MODE_RAW_KEY);
            String mergedRaw = mergeStyledModeSuggestionRaw(existingRaw, modeRaw);
            String styled = Superscript.styledSuperscriptText(mergedRaw);
            editor.replaceText(modeStart, caretPos, styled);
            editor.moveTo(modeStart + styled.length());
            editor.getProperties().put(SUPERSCRIPT_MODE_RAW_KEY, mergedRaw);
            editor.getProperties().put(SUPERSCRIPT_MODE_STARTED_KEY, Boolean.TRUE);
            editor.getProperties().remove(SUPERSCRIPT_MODE_MARKER_START_KEY);
        }

        editor.requestFollowCaret();
        return true;
    }

    private static boolean isGreekChar(char ch) {
        return (ch >= 'α' && ch <= 'ω') || (ch >= 'Α' && ch <= 'Ω');
    }

    private static String extractSuggestionPattern(String text, int caretPos) {
        if (text == null || text.isEmpty()) {
            return null;
        }

        int safeCaretPos = Math.max(0, Math.min(caretPos, text.length()));
        if (safeCaretPos <= 0) {
            return null;
        }

        int varIdx = text.lastIndexOf("\\var(", safeCaretPos);
        if (varIdx != -1) {
            int closeVarIdx = text.indexOf(")", varIdx);
            if (closeVarIdx == -1 || closeVarIdx > safeCaretPos) {
                int openParenIdx = varIdx + 5;
                String pattern = text.substring(openParenIdx, safeCaretPos);

                if (pattern.matches("[a-zA-Z0-9\\\\()_]*")) {
                    return pattern;
                }
            }
        }

        // Handle \con(\ pattern for physics constants
        int conIdx = text.lastIndexOf("\\con(", safeCaretPos);
        if (conIdx != -1) {
            int closeConIdx = text.indexOf(")", conIdx);
            if (closeConIdx == -1 || closeConIdx > safeCaretPos) {
                int openParenIdx = conIdx + 5;
                String pattern = text.substring(openParenIdx, safeCaretPos);
                if (pattern.matches("[a-zA-Z0-9\\\\()_]*")) {
                    return pattern;
                }
            }
        }

        int lastBackslash = text.lastIndexOf("\\", safeCaretPos - 1);
        if (lastBackslash != -1) {
            String backslashToken = text.substring(lastBackslash, safeCaretPos);
            if (backslashToken.matches("\\\\[a-zA-Z0-9_]*")) {
                return backslashToken;
            }
        }

        int wordStart = safeCaretPos;
        while (wordStart > 0) {
            char prev = text.charAt(wordStart - 1);

            if (Character.isLetterOrDigit(prev)) {
                wordStart--;
                continue;
            }

            if (prev == '_') {
                if (wordStart < text.length() && text.charAt(wordStart) == '{') {
                    break;
                }
                wordStart--;
                continue;
            }

            if (prev == '^') {
                if (wordStart < text.length() && text.charAt(wordStart) == '{') {
                    break;
                }
                // A lone '^' is the power operator, so the word being typed
                // starts after it: in `A^sq` the pattern is `sq`, not `A^sq`
                // (which matched nothing, so no popup ever opened after a
                // caret). Only a '^^' pair -- the superscript-mode marker -- is
                // walked through, because the mode handling below needs it.
                boolean pairedAfter = wordStart < text.length() && text.charAt(wordStart) == '^';
                boolean pairedBefore = wordStart >= 2 && text.charAt(wordStart - 2) == '^';
                if (!pairedAfter && !pairedBefore) {
                    break;
                }
                wordStart--;
                continue;
            }

            break;
        }

        String word = text.substring(wordStart, safeCaretPos);

        int subModeIdx = word.lastIndexOf("__");
        int supModeIdx = word.lastIndexOf("^^");
        int modeIdx = Math.max(subModeIdx, supModeIdx);
        if (modeIdx != -1) {
            String modeToken = word.substring(modeIdx + 2);
            if (!modeToken.isEmpty() && modeToken.matches("[a-zA-Z_][a-zA-Z0-9_]*")) {
                return modeToken;
            }

            if (!modeToken.isEmpty()
                    && modeToken.matches("[a-zA-Z0-9\\\\()_]*")
                    && modeToken.matches(".*[a-zA-Z0-9_()].*")) {
                return modeToken;
            }
        }

        String memberAccess = extractMemberAccessPattern(text, wordStart, word);
        if (memberAccess != null) {
            return memberAccess;
        }

        if (word.length() >= 1 && word.matches("[a-zA-Z_][a-zA-Z0-9_^]*")) {
            return word;
        }

        if (safeCaretPos >= 1) {
            char lastChar = text.charAt(safeCaretPos - 1);
            if ((lastChar == '|' || lastChar == '&' || lastChar == '=' || lastChar == '!') && safeCaretPos >= 2) {
                char prevChar = text.charAt(safeCaretPos - 2);
                if (lastChar == prevChar || (lastChar == '=' && prevChar == '!')) {
                    return text.substring(safeCaretPos - 2, safeCaretPos);
                }
            }
            if ("&|=!".indexOf(lastChar) != -1) {
                return String.valueOf(lastChar);
            }
        }

        return null;
    }

    /**
     * {@code Owner.prefix} when the word being typed follows a dot that itself
     * follows an identifier. Only one level is supported: in {@code a.b.c} the
     * pattern is not formed, and the popup stays closed.
     *
     * @param text      the whole document
     * @param wordStart start offset of the word before the caret
     * @param word      that word, possibly empty (the dot was just typed)
     * @return {@code Owner.prefix}, or null when the context is not a member access
     */
    private static String extractMemberAccessPattern(String text, int wordStart, String word) {
        if (wordStart <= 0 || text.charAt(wordStart - 1) != '.') {
            return null;
        }
        if (!word.isEmpty() && !word.matches("[\\p{L}_][\\p{L}\\p{M}\\p{N}_]*")) {
            return null;
        }
        int ownerEnd = wordStart - 1;
        int ownerStart = ownerEnd;
        while (ownerStart > 0 && isIdentifierChar(text.charAt(ownerStart - 1))) {
            ownerStart--;
        }
        if (ownerStart == ownerEnd) {
            return null;
        }
        if (ownerStart > 0 && text.charAt(ownerStart - 1) == '.') {
            return null;
        }
        String owner = text.substring(ownerStart, ownerEnd);
        // A number before the dot (3.5) is not an owner.
        if (!owner.matches("[\\p{L}_][\\p{L}\\p{M}\\p{N}_]*")) {
            return null;
        }
        return owner + "." + word;
    }

    private static boolean isIdentifierChar(char ch) {
        if (Character.isLetterOrDigit(ch) || ch == '_') {
            return true;
        }
        int type = Character.getType(ch);
        return type == Character.NON_SPACING_MARK
                || type == Character.COMBINING_SPACING_MARK
                || type == Character.ENCLOSING_MARK;
    }

    private static String extractModeSuggestionPattern(String raw) {
        if (raw == null) {
            return null;
        }

        String value = raw.trim();
        if (value.isEmpty()) {
            return null;
        }

        int varIdx = value.lastIndexOf("\\var(");
        if (varIdx != -1) {
            String fragment = value.substring(varIdx);
            if (fragment.indexOf(')') == -1
                    && fragment.matches("[\\p{L}\\p{N}_\\\\()]*")) {
                return fragment;
            }
        }

        Matcher trailingToken = Pattern.compile("([\\p{L}\\p{N}_]+)$").matcher(value);
        if (trailingToken.find()) {
            return trailingToken.group(1);
        }

        return null;
    }

    private static String mergeStyledModeSuggestionRaw(String existingRaw, String selectedRaw) {
        if (selectedRaw == null || selectedRaw.isBlank()) {
            return existingRaw == null ? "" : existingRaw;
        }

        String current = existingRaw == null ? "" : existingRaw;
        if (current.isBlank()) {
            return selectedRaw;
        }

        int varIdx = current.lastIndexOf("\\var(");
        if (varIdx != -1 && current.indexOf(')', varIdx) == -1) {
            return current.substring(0, varIdx) + selectedRaw;
        }

        Matcher trailingToken = Pattern.compile("([\\p{L}\\p{N}_]+)$").matcher(current);
        if (trailingToken.find()) {
            return current.substring(0, trailingToken.start(1)) + selectedRaw;
        }

        return current + selectedRaw;
    }

    private static void insertSelectedSuggestion(CodeArea editor, SuggestionPopup popup) {
        SuggestionProvider.Suggestion suggestion = popup.getSelected();
        if (suggestion == null) {
            return;
        }

        if (insertSuggestionInStyledMode(editor, suggestion)) {
            SuggestionProvider.addRecentlyUsedSymbol(suggestion.getCode());
            popup.hide();
            editor.requestFocus();
            return;
        }

        String text = editor.getText();
        int caretPos = editor.getCaretPosition();
        String pattern = extractSuggestionPattern(text, caretPos);

        if (pattern != null) {
            int patternStart = caretPos - pattern.length();

            String codeToInsert = suggestion.getCode();
            String closingSuffix = "";
            boolean runStyledReplacement = false;

            if ("Function".equals(suggestion.getCategory())) {
                String funcName = FunctionProvider.extractFunctionName(codeToInsert);
                if (FunctionProvider.isNotation(funcName)) {
                    codeToInsert = funcName;
                    closingSuffix = "";
                } else {
                    codeToInsert = funcName + "(";
                    closingSuffix = ")";
                }
            } else if ("UserFunction".equals(suggestion.getCategory())) {
                // Do not double the bracket when one already follows the caret.
                if (!bracketFollows(text, caretPos)) {
                    codeToInsert = codeToInsert + "(";
                    closingSuffix = ")";
                }
            } else if ("StyledVariable".equals(suggestion.getCategory())) {
                closingSuffix = "";
                runStyledReplacement = true;
            } else if ("Variable".equals(suggestion.getCategory()) && codeToInsert.startsWith("\\var(")) {
                closingSuffix = "";
            } else if (codeToInsert.startsWith("\\var(\\") && codeToInsert.endsWith(")")) {
                codeToInsert = codeToInsert.substring(5);
                if (codeToInsert.endsWith(")")) {
                    codeToInsert = codeToInsert.substring(0, codeToInsert.length() - 1);
                }

                int varIdx = text.lastIndexOf("\\var(", patternStart);
                if (varIdx != -1) {
                    int closeIdx = text.indexOf(")", varIdx);
                    if (closeIdx == -1 || closeIdx > caretPos) {
                        closingSuffix = ")";
                    }
                }
            } else if (codeToInsert.startsWith("\\var(\\tamil(") && codeToInsert.endsWith("))")) {
                codeToInsert = codeToInsert.substring(12);
                if (codeToInsert.endsWith("))")) {
                    codeToInsert = codeToInsert.substring(0, codeToInsert.length() - 2);
                } else if (codeToInsert.endsWith(")")) {
                    codeToInsert = codeToInsert.substring(0, codeToInsert.length() - 1);
                }

                closingSuffix = ")";
            } else if (codeToInsert.startsWith("\\con(\\") && codeToInsert.endsWith(")")) {
                codeToInsert = codeToInsert.substring(5);
                if (codeToInsert.endsWith(")")) {
                    codeToInsert = codeToInsert.substring(0, codeToInsert.length() - 1);
                }

                int conIdx = text.lastIndexOf("\\con(", patternStart);
                if (conIdx != -1) {
                    int closeIdx = text.indexOf(")", conIdx);
                    if (closeIdx == -1 || closeIdx > caretPos) {
                        closingSuffix = ")";
                    }
                }
            }

            if (codeToInsert.startsWith("\\") && patternStart > 0 && text.charAt(patternStart - 1) == '\\') {
                patternStart--;
            }

            // Only the typed word is replaced; the rest of the document, its
            // undo history and its paragraph styles are left alone.
            editor.replaceText(patternStart, caretPos, codeToInsert + closingSuffix);
            editor.moveTo(caretAfterInsert(suggestion, text, caretPos, patternStart,
                    codeToInsert, closingSuffix));

            SuggestionProvider.addRecentlyUsedSymbol(suggestion.getCode());

            if (runStyledReplacement) {
                Platform.runLater(() -> EditorActions.handleReplacement(editor));
            }

            popup.hide();
            editor.requestFocus();
        }
    }

    private static void insertSelectedSuggestion(TextArea editor, SuggestionPopup popup) {
        SuggestionProvider.Suggestion suggestion = popup.getSelected();
        if (suggestion == null) {
            return;
        }

        String text = editor.getText();
        int caretPos = editor.getCaretPosition();
        String pattern = extractSuggestionPattern(text, caretPos);

        if (pattern != null) {
            int patternStart = caretPos - pattern.length();

            String codeToInsert = suggestion.getCode();
            String closingSuffix = "";
            boolean runStyledReplacement = false;

            if ("Function".equals(suggestion.getCategory())) {
                String funcName = FunctionProvider.extractFunctionName(codeToInsert);
                if (FunctionProvider.isNotation(funcName)) {
                    codeToInsert = funcName;
                    closingSuffix = "";
                } else {
                    codeToInsert = funcName + "(";
                    closingSuffix = ")";
                }
            } else if ("UserFunction".equals(suggestion.getCategory())) {
                if (!bracketFollows(text, caretPos)) {
                    codeToInsert = codeToInsert + "(";
                    closingSuffix = ")";
                }
            } else if ("StyledVariable".equals(suggestion.getCategory())) {
                closingSuffix = "";
                runStyledReplacement = true;
            } else if (codeToInsert.startsWith("\\var(\\") && codeToInsert.endsWith(")")) {
                codeToInsert = codeToInsert.substring(5);
                if (codeToInsert.endsWith(")")) {
                    codeToInsert = codeToInsert.substring(0, codeToInsert.length() - 1);
                }

                int varIdx = text.lastIndexOf("\\var(", patternStart);
                if (varIdx != -1) {
                    int closeIdx = text.indexOf(")", varIdx);
                    if (closeIdx == -1 || closeIdx > caretPos) {
                        int tamilIdx = text.indexOf("\\tamil(", varIdx);
                        if (tamilIdx != -1 && tamilIdx < caretPos) {
                            closingSuffix = "))";
                        } else {
                            closingSuffix = ")";
                        }
                    }
                }
            } else if (codeToInsert.startsWith("\\var(\\tamil(") && codeToInsert.endsWith("))")) {
                codeToInsert = codeToInsert.substring(12);
                if (codeToInsert.endsWith("))")) {
                    codeToInsert = codeToInsert.substring(0, codeToInsert.length() - 2);
                } else if (codeToInsert.endsWith(")")) {
                    codeToInsert = codeToInsert.substring(0, codeToInsert.length() - 1);
                }

                closingSuffix = ")";
            } else if (codeToInsert.startsWith("\\con(\\") && codeToInsert.endsWith(")")) {
                codeToInsert = codeToInsert.substring(5);
                if (codeToInsert.endsWith(")")) {
                    codeToInsert = codeToInsert.substring(0, codeToInsert.length() - 1);
                }

                int conIdx = text.lastIndexOf("\\con(", patternStart);
                if (conIdx != -1) {
                    int closeIdx = text.indexOf(")", conIdx);
                    if (closeIdx == -1 || closeIdx > caretPos) {
                        closingSuffix = ")";
                    }
                }
            }
            if (codeToInsert.startsWith("\\") && patternStart > 0 && text.charAt(patternStart - 1) == '\\') {
                patternStart--;
            }

            String newText = text.substring(0, patternStart)
                    + codeToInsert
                    + closingSuffix
                    + text.substring(caretPos);

            editor.setText(newText);
            editor.positionCaret(caretAfterInsert(suggestion, text, caretPos, patternStart,
                    codeToInsert, closingSuffix));

            SuggestionProvider.addRecentlyUsedSymbol(suggestion.getCode());

            if (runStyledReplacement) {
                Platform.runLater(() -> handleLiveReplacement(editor));
            }

            popup.hide();
            editor.requestFocus();
        }
    }

    /** True when the character at the caret is an opening bracket. */
    private static boolean bracketFollows(String text, int caretPos) {
        return caretPos >= 0 && caretPos < text.length() && text.charAt(caretPos) == '(';
    }

    /**
     * Where the caret goes after a row is accepted: inside the brackets for any
     * function (built-in or user), after the inserted text otherwise.
     */
    private static int caretAfterInsert(SuggestionProvider.Suggestion suggestion, String text, int caretPos,
            int patternStart, String codeToInsert, String closingSuffix) {
        String category = suggestion.getCategory();
        if ("Function".equals(category)) {
            return patternStart + codeToInsert.length();
        }
        if ("UserFunction".equals(category)) {
            // With an existing bracket, step over it so the caret lands inside.
            return closingSuffix.isEmpty() && bracketFollows(text, caretPos)
                    ? patternStart + codeToInsert.length() + 1
                    : patternStart + codeToInsert.length();
        }
        return patternStart + codeToInsert.length() + closingSuffix.length();
    }
}
