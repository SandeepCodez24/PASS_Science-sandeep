package ui.editor;

import org.fxmisc.flowless.VirtualizedScrollPane;

import javafx.beans.value.ChangeListener;
import javafx.geometry.Bounds;
import javafx.geometry.Point2D;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.SplitPane;
import javafx.scene.control.Tab;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Region;
import ui.UI_Main;
import ui.design.Dim;
import ui.editor.folding.FoldableCodeArea;

/**
 * Carries the editor's gutter band down through the divider between the
 * editor and the Command Window, so the grey line-number column runs all the
 * way to the divider line, as in MATLAB.
 *
 * <h3>The white strip this removes</h3>
 * <p>
 * The divider between two stacked panels is a 1 px line at the bottom of a
 * small drag area ({@code Dim.Split.DIVIDER_GRAB_STACKED}). The drag area is
 * painted in the editor's background colour, so it blends with the code -- but
 * under the gutter it showed as a white notch: the band stopped at the
 * editor's bottom edge and the drag area below it was white.
 * </p>
 *
 * <h3>How</h3>
 * <p>
 * One plain region, carrying the gutter's own style classes
 * ({@code .editor-gutter}), is placed inside that one divider, above its line,
 * exactly under the gutter band of the editor tab on screen. Because it uses
 * the same CSS class it takes the same colour, in both themes and with a
 * Custom layout's editor ink.
 * </p>
 * <p>
 * Its position is read from the editor itself after every layout pass, so it
 * follows everything that moves the band: the File Explorer's width, the
 * Line Numbers and Line Folders toggles, the editor zoom, a switch of tab, a
 * drag of the divider. It is hidden when there is nothing to continue: a
 * plain-text tab or no tab at all, or a horizontal scroll bar sitting between
 * the editor and the divider (the band ends at the scroll bar then).
 * </p>
 *
 * <h3>Cost</h3>
 * <p>
 * The check runs after each layout pulse: two coordinate conversions and a
 * comparison. When nothing changed, nothing is set, so it never asks for
 * another layout. The region is mouse-transparent, so the divider drags
 * exactly as before.
 * </p>
 */
public final class EditorGutterSeam {

    /** Style class of the seam; the colour comes from {@code .editor-gutter}. */
    public static final String SEAM_CLASS = "editor-gutter-seam";

    /** A gap wider than this between editor and divider means a scroll bar sits there. */
    private static final double MAX_GAP = 1.5;

    private static final Region SEAM = new Region();

    private static final Runnable AFTER_LAYOUT = EditorGutterSeam::update;

    private static UI_Main ide;
    private static SplitPane split;
    private static Scene listeningScene;

    /** The split whose scene is watched; only ever one. */
    private static SplitPane watchedSplit;

    private static final ChangeListener<Scene> SCENE_CHANGED = (obs, was, isNow) -> listenTo(isNow);

    static {
        SEAM.getStyleClass().addAll("editor-gutter", "editor-gutter-band", SEAM_CLASS);
        SEAM.setManaged(false);
        SEAM.setMouseTransparent(true);
        SEAM.setVisible(false);
    }

    private EditorGutterSeam() {
    }

    /**
     * Follows the divider of the split that holds the editor over the Command
     * Window. Called by {@code EditorCommandWindow.attachTo}; {@code null}
     * (the Command Window is not directly under the editor) removes the seam.
     *
     * @param ideRef    the IDE controller, for the editor tabs
     * @param splitPane the editor-over-console split, or null
     */
    public static void attach(UI_Main ideRef, SplitPane splitPane) {
        ide = ideRef;
        split = splitPane;
        if (split == null) {
            if (watchedSplit != null) {
                watchedSplit.sceneProperty().removeListener(SCENE_CHANGED);
                watchedSplit = null;
            }
            detach();
            listenTo(null);
            return;
        }
        if (watchedSplit != null) {
            watchedSplit.sceneProperty().removeListener(SCENE_CHANGED);
        }
        watchedSplit = split;
        split.sceneProperty().addListener(SCENE_CHANGED);
        listenTo(split.getScene());
        update();
    }

    private static void listenTo(Scene scene) {
        if (listeningScene == scene) {
            return;
        }
        if (listeningScene != null) {
            listeningScene.removePostLayoutPulseListener(AFTER_LAYOUT);
        }
        listeningScene = scene;
        if (scene != null) {
            scene.addPostLayoutPulseListener(AFTER_LAYOUT);
        }
    }

    private static void detach() {
        if (SEAM.getParent() instanceof Pane parent) {
            parent.getChildren().remove(SEAM);
        }
    }

    // =====================================================================
    // After every layout pass
    // =====================================================================

    private static void update() {
        if (split == null || split.getScene() == null) {
            detach();
            return;
        }
        Pane divider = divider();
        if (divider == null) {
            detach();
            return;
        }
        if (SEAM.getParent() != divider) {
            detach();
            divider.getChildren().add(SEAM);
        }

        FoldableCodeArea area = selectedEditor();
        if (area == null || area.getGutterBandWidth() <= 0 || area.getScene() == null
                || !area.isVisible()) {
            show(false);
            return;
        }

        // Everything in scene coordinates, so the zoom transform, the tab
        // pane's insets and the explorer's width are all accounted for.
        double left = area.getInsets().getLeft();
        Point2D bandStart = area.localToScene(left, 0);
        Point2D bandEnd = area.localToScene(left + area.getGutterBandWidth(), 0);
        Bounds areaBounds = area.localToScene(area.getLayoutBounds());
        Point2D dividerTop = divider.localToScene(0, 0);
        if (bandStart == null || bandEnd == null || areaBounds == null || dividerTop == null) {
            show(false);
            return;
        }
        if (dividerTop.getY() - areaBounds.getMaxY() > MAX_GAP) {
            // A horizontal scroll bar sits between the editor and the divider.
            show(false);
            return;
        }

        Point2D from = divider.sceneToLocal(bandStart.getX(), dividerTop.getY());
        Point2D to = divider.sceneToLocal(bandEnd.getX(), dividerTop.getY());
        double x = Math.max(0, divider.snapPositionX(from.getX()));
        double width = Math.max(0, divider.snapSizeX(to.getX()) - x);
        // The drag area above the line; the line itself stays visible.
        double height = 2 * Dim.Split.DIVIDER_SIDE_STACKED;

        if (SEAM.getLayoutX() != x || SEAM.getLayoutY() != 0
                || SEAM.getWidth() != width || SEAM.getHeight() != height) {
            SEAM.resizeRelocate(x, 0, width, height);
        }
        show(width > 0);
    }

    private static void show(boolean visible) {
        if (SEAM.isVisible() != visible) {
            SEAM.setVisible(visible);
        }
    }

    /** The split's own divider (not one of a nested split's), or null. */
    private static Pane divider() {
        for (Node node : split.lookupAll(".split-pane-divider")) {
            if (node.getParent() == split && node instanceof Pane pane) {
                return pane;
            }
        }
        return null;
    }

    /** The {@code .nc} editor in the selected tab, or null. */
    private static FoldableCodeArea selectedEditor() {
        if (ide == null || ide.editorTabs == null) {
            return null;
        }
        Tab tab = ide.editorTabs.getSelectionModel().getSelectedItem();
        if (tab == null || !(tab.getContent() instanceof VirtualizedScrollPane<?> pane)) {
            return null;
        }
        return pane.getContent() instanceof FoldableCodeArea area ? area : null;
    }
}
