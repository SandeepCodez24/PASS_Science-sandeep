package ui.editor.settingsTab;

import java.io.InputStream;
import java.util.EnumMap;
import java.util.Map;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.Window;
import ui.UI_Main;
import ui.managers.ThemeManager;
import ui.ui_functions.suggestion_functions.SuggestionSettings;
import ui.ui_functions.suggestion_functions.SuggestionSettings.Group;

/**
 * Syntax settings window: what the suggestion box offers, and whether block
 * closers are auto-filled.
 *
 * <p>
 * Opened from two places that must always agree, so both call {@link #open}:
 * the Settings ribbon's Syntax button (Visuals group) and the "Settings..."
 * entry of the suggestion popup's three-dot menu.
 * </p>
 *
 * <pre>
 *   +--------------------------------------------------------+
 *   | Syntax                                     (navy bar)  |
 *   +--------------------------------------------------------+
 *   |  Suggestion box                                        |
 *   |  [x] Variable suggestions                              |
 *   |      Variables declared in this file ...               |
 *   |  [x] Function suggestions                              |
 *   |  [x] Script file suggestions                           |
 *   |  [x] UniCode Constants                                 |
 *   |  (warning when all four are off)                       |
 *   |  -------------------------------------------------     |
 *   |  Block closers                                         |
 *   |  [ ] End auto fill suggestions                         |
 *   +--------------------------------------------------------+
 *   | Restore defaults     Changes apply immediately  Close  |
 *   +--------------------------------------------------------+
 * </pre>
 *
 * <p>
 * There is no OK / Cancel: every box writes straight to
 * {@link SuggestionSettings}, which is persisted and which the popup reads on
 * every keystroke, so a change is visible the moment it is made. The boxes
 * also follow changes made from the popup's menu while this window is open.
 * </p>
 */
public final class UI_Settings_Syntax_Main {

    private static final String NAVY_BLUE = "#004073";
    private static final String ICON_PATH = "/icons/ic_18_nc.PNG";
    private static final String WINDOW_TITLE = "Syntax";

    /** Fixed width; the height follows the content, so wrapped text is never clipped. */
    private static final double WIDTH = 470;

    private static Stage window;

    /** Held strongly for the life of the window; SuggestionSettings keeps it weakly. */
    private static Runnable settingsListener;

    private UI_Settings_Syntax_Main() {
    }

    /**
     * Opens the window from the ribbon.
     *
     * @param ide the IDE controller; may be null
     */
    public static void open(UI_Main ide) {
        open(ide == null ? null : ide.stage);
    }

    /**
     * Opens the window, or brings the open one to the front.
     *
     * @param owner the owning window; may be null
     */
    public static void open(Window owner) {
        if (window != null && window.isShowing()) {
            window.toFront();
            window.requestFocus();
            return;
        }

        boolean dark = "dark".equalsIgnoreCase(ThemeManager.getActiveTheme());
        Palette p = dark ? Palette.DARK : Palette.LIGHT;

        window = new Stage();
        window.setTitle(WINDOW_TITLE);
        window.setResizable(false);
        window.initModality(Modality.NONE);
        applyWindowIcon(window);
        if (owner != null) {
            window.initOwner(owner);
        }

        // ── Title bar ──────────────────────────────────────────────────────
        Label title = new Label(WINDOW_TITLE);
        title.setStyle("-fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: bold;");
        Label subtitle = new Label("Suggestion box and block closers");
        subtitle.setStyle("-fx-text-fill: #B9CCE0; -fx-font-size: 11px;");
        Region titleGap = new Region();
        HBox.setHgrow(titleGap, Priority.ALWAYS);
        HBox titleBar = new HBox(10, title, titleGap, subtitle);
        titleBar.setAlignment(Pos.CENTER_LEFT);
        titleBar.setPadding(new Insets(9, 14, 9, 14));
        titleBar.setStyle("-fx-background-color: " + NAVY_BLUE + ";");

        // ── Suggestion box section ─────────────────────────────────────────
        Map<Group, CheckBox> boxes = new EnumMap<>(Group.class);

        VBox suggestionSection = section(p, "Suggestion box",
                "Choose what the suggestion box offers while you type. "
                        + "Only ticked groups are suggested.");
        for (Group group : new Group[] { Group.VARIABLES, Group.FUNCTIONS, Group.FILES, Group.UNICODE }) {
            suggestionSection.getChildren().add(option(p, group, boxes));
        }

        Label allOff = new Label("All groups are off: the suggestion box will not open.");
        allOff.setWrapText(true);
        allOff.setStyle("-fx-font-size: 11px; -fx-text-fill: " + p.warning + ";");
        allOff.setPadding(new Insets(2, 0, 0, 26));
        suggestionSection.getChildren().add(allOff);

        Region rule = new Region();
        rule.setMinHeight(1);
        rule.setPrefHeight(1);
        rule.setMaxHeight(1);
        rule.setStyle("-fx-background-color: " + p.rule + ";");
        VBox.setMargin(rule, new Insets(14, 0, 12, 0));

        // ── Block closers section ──────────────────────────────────────────
        VBox closerSection = section(p, "Block closers",
                "Enter always indents after a ':' header. This only decides whether the closer is written for you.");
        closerSection.getChildren().add(option(p, Group.END_AUTOFILL, boxes));

        VBox body = new VBox(suggestionSection, rule, closerSection);
        body.setPadding(new Insets(16, 20, 16, 20));
        body.setStyle("-fx-background-color: " + p.background + ";");

        // ── Footer ─────────────────────────────────────────────────────────
        Button restore = new Button("Restore defaults");
        restore.setStyle(p.linkButton);
        restore.setOnAction(e -> SuggestionSettings.restoreDefaults());

        Label note = new Label("Changes apply immediately");
        note.setStyle("-fx-font-size: 11px; -fx-text-fill: " + p.muted + ";");

        Button close = new Button("Close");
        close.setDefaultButton(true);
        close.setPrefWidth(76);
        close.setOnAction(e -> window.close());

        Region footerGap = new Region();
        HBox.setHgrow(footerGap, Priority.ALWAYS);
        HBox footerBar = new HBox(10, restore, footerGap, note, close);
        footerBar.setAlignment(Pos.CENTER_LEFT);
        footerBar.setPadding(new Insets(7, 12, 7, 10));
        footerBar.setStyle(
                "-fx-background-color: " + p.footer + ";"
                        + "-fx-border-color: " + p.footerRule + " transparent transparent transparent;"
                        + "-fx-border-width: 1 0 0 0;");

        BorderPane root = new BorderPane();
        root.setTop(titleBar);
        root.setCenter(body);
        root.setBottom(footerBar);
        root.setStyle("-fx-background-color: " + p.background + ";");

        // ── Keep the boxes and the warning in step with the store ──────────
        Runnable sync = () -> {
            boxes.forEach((group, box) -> {
                boolean stored = SuggestionSettings.isEnabled(group);
                if (box.isSelected() != stored) {
                    box.setSelected(stored);
                }
            });
            boolean none = !SuggestionSettings.anyPopupGroupEnabled();
            allOff.setVisible(none);
            allOff.setManaged(none);
        };
        sync.run();
        settingsListener = sync;
        SuggestionSettings.addListener(settingsListener);

        root.setPrefWidth(WIDTH);
        root.setMinWidth(WIDTH);
        root.setMaxWidth(WIDTH);
        Scene scene = new Scene(root);
        if (owner != null && owner.getScene() != null) {
            scene.getStylesheets().addAll(owner.getScene().getStylesheets());
        }
        scene.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.ESCAPE) {
                window.close();
            }
        });

        window.setScene(scene);
        window.setOnHidden(event -> {
            SuggestionSettings.removeListener(settingsListener);
            settingsListener = null;
            window = null;
        });
        window.sizeToScene();
        window.show();
        if (owner == null) {
            window.centerOnScreen();
        } else {
            window.setX(owner.getX() + (owner.getWidth() - window.getWidth()) / 2);
            window.setY(owner.getY() + (owner.getHeight() - window.getHeight()) / 2);
        }
        close.requestFocus();
    }

    // =====================================================================
    // Building blocks
    // =====================================================================

    private static VBox section(Palette p, String heading, String explanation) {
        Label head = new Label(heading);
        head.setStyle("-fx-font-size: 13px; -fx-font-weight: bold; -fx-text-fill: " + p.ink + ";");
        Label text = new Label(explanation);
        text.setWrapText(true);
        text.setStyle("-fx-font-size: 11px; -fx-text-fill: " + p.muted + ";");
        VBox box = new VBox(3, head, text);
        box.setPadding(new Insets(0, 0, 4, 0));
        VBox section = new VBox(8, box);
        return section;
    }

    /** One tick box with its explanation indented beneath it. */
    private static VBox option(Palette p, Group group, Map<Group, CheckBox> boxes) {
        CheckBox box = new CheckBox(group.label());
        box.setSelected(SuggestionSettings.isEnabled(group));
        box.setStyle("-fx-font-size: 12px; -fx-text-fill: " + p.ink + ";");
        box.selectedProperty().addListener((obs, was, now) -> SuggestionSettings.setEnabled(group, now));
        boxes.put(group, box);

        Label description = new Label(group.description()
                + (group.defaultOn() ? "" : "  (off by default)"));
        description.setWrapText(true);
        description.setStyle("-fx-font-size: 11px; -fx-text-fill: " + p.muted + ";");
        description.setPadding(new Insets(0, 0, 0, 26));

        return new VBox(2, box, description);
    }

    /** Colours for one theme, kept together so the two can be compared. */
    private enum Palette {
        LIGHT("#FFFFFF", "#1E2A36", "#5B6672", "#DDE2E8", "#D9DCDF", "#C2C7CC", "#B3261E",
                "-fx-background-color: transparent; -fx-text-fill: #004073; -fx-underline: true; -fx-cursor: hand;"),
        DARK("#2B2D30", "#E4E7EB", "#A4ACB5", "#3E4247", "#232427", "#3A3D41", "#F28B82",
                "-fx-background-color: transparent; -fx-text-fill: #8CB8E8; -fx-underline: true; -fx-cursor: hand;");

        final String background;
        final String ink;
        final String muted;
        final String rule;
        final String footer;
        final String footerRule;
        final String warning;
        final String linkButton;

        Palette(String background, String ink, String muted, String rule, String footer,
                String footerRule, String warning, String linkButton) {
            this.background = background;
            this.ink = ink;
            this.muted = muted;
            this.rule = rule;
            this.footer = footer;
            this.footerRule = footerRule;
            this.warning = warning;
            this.linkButton = linkButton;
        }
    }

    private static void applyWindowIcon(Stage stage) {
        try (InputStream in = UI_Settings_Syntax_Main.class.getResourceAsStream(ICON_PATH)) {
            if (in == null) {
                System.err.println("Window icon not found on classpath: " + ICON_PATH);
                return;
            }
            Image icon = new Image(in);
            if (!icon.isError()) {
                stage.getIcons().add(icon);
            }
        } catch (Exception ex) {
            System.err.println("Failed to load window icon: " + ex.getMessage());
        }
    }
}
