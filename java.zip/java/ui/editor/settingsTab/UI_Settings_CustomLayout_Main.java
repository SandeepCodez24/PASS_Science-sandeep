package ui.editor.settingsTab;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;

import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.stage.WindowEvent;
import ui.UI_Main;
import ui.design.AstraFrame;
import ui.design.Dim;
import ui.design.Typography;
import ui.layout.LayoutManager;
import ui.layout.WindowLayout;
import ui.layout.custom.CustomLayoutConfig;
import ui.layout.custom.CustomLayoutConfig.Panel;
import ui.layout.custom.CustomLayoutTheme;
import ui.managers.ThemeManager;
import ui.ribbon_interface.tool_bar.LayoutRibbon;

/**
 * Custom Layout window, opened from the Custom tile on the Settings &gt;
 * Layout band.
 *
 * <pre>
 *   [NC] Custom Layout                                                  [x]
 *   +------------------------------------------------------------------------+
 *   | Layout               Panels          Light  Dark   Base Color [##]      |
 *   | (o) Custom           [x] Editor Tab  [##]   [##]                         |
 *   | ( ) Default          [x] Directory   [##]   [##]   Default Theme         |
 *   | ( ) Bot Centered     [x] CLI         [##]   [##]    (o) Light            |
 *   | ( ) Editor-CLI       [x] Variables   [##]   [##]    ( ) Dark             |
 *   | ( ) Directory Cent.  [x] Chat Bot    [##]   [##]   Panel Order           |
 *   | ( ) Editor-Bot-CLI                                 [<-> Swap sides]     |
 *   |                                                    Font Size [ 12 ^v]  |
 *   |                                     Reset to factory                   |
 *   |                                             [Apply] [Cancel]           |
 *   +------------------------------------------------------------------------+
 * </pre>
 *
 * <h3>The window</h3>
 * <p>
 * Built on {@link AstraFrame}, like every other IDE window: square corners,
 * the title strip in the active base colour (it follows the live preview),
 * the IDE's palette and sheets, Esc closes, centred over the IDE. It is a
 * modal dialog, so the gallery cannot change the layout underneath a live
 * preview. The frame's title bar is the only header; the "Panels" column
 * header names the layout being edited.
 * </p>
 *
 * <h3>Live preview</h3>
 * <p>
 * There is no Preview button. Every change shows in the main window at
 * once: the layout radio, ticks, colours (while the colour dialog is open,
 * as the sliders move), Base Color, Default Theme, Swap sides, Font Size and
 * Reset to factory. Colour, theme and font changes repaint only; ticks,
 * Swap sides, the layout radio and Reset rebuild the layout.
 * </p>
 *
 * <h3>Opens on what you saved</h3>
 * <p>
 * The window starts from the saved values and selects the layout it last
 * applied ({@link CustomLayoutConfig#lastApplied()}) -- or the layout on
 * screen when that is already a custom look -- so reopening it never jumps
 * back to factory.
 * </p>
 *
 * <h3>Buttons</h3>
 * <ul>
 * <li><b>Reset to factory</b> -- factory values into this window, shown
 * live on the Default layout. Nothing is saved until Apply; Cancel undoes
 * it like any other change.</li>
 * <li><b>Apply</b> -- saves, remembers the layout being edited as the one
 * the Custom tile brings back, closes.</li>
 * <li><b>Cancel</b> (or the close mark, Esc, Alt+F4) -- undoes every live
 * change: the layout, theme, font size and colours that were on screen when
 * the window opened come back.</li>
 * </ul>
 * <p>
 * Apply is greyed while no Custom panel is ticked.
 * </p>
 */
public final class UI_Settings_CustomLayout_Main {

    private static final String HEADER_BLUE = "#1a4f8b";
    private static final String HEADER_BLUE_DARK = "#8fb5de";
    private static final String WINDOW_TITLE = "Custom Layout";

    /** The panels each standard layout has, shown greyed while it is edited. */
    private static final Map<WindowLayout, Set<Panel>> LAYOUT_PANELS = new EnumMap<>(WindowLayout.class);

    static {
        LAYOUT_PANELS.put(WindowLayout.DEFAULT, EnumSet.allOf(Panel.class));
        LAYOUT_PANELS.put(WindowLayout.BOT_CENTERED, EnumSet.of(Panel.EDITOR, Panel.VARIABLES, Panel.CHAT_BOT));
        LAYOUT_PANELS.put(WindowLayout.EDITOR_CLI, EnumSet.of(Panel.EDITOR, Panel.CLI));
        LAYOUT_PANELS.put(WindowLayout.DIRECTORY_CENTERED, EnumSet.of(Panel.DIRECTORY, Panel.EDITOR, Panel.CLI));
        LAYOUT_PANELS.put(WindowLayout.EDITOR_BOT_CLI, EnumSet.of(Panel.EDITOR, Panel.CHAT_BOT, Panel.CLI));
    }

    private static Stage window;

    private final UI_Main ide;
    private final AstraFrame frame;
    private final Stage stage;

    /** The values on screen in this window (and, live, in the main window). */
    private CustomLayoutConfig working;
    /** The layout whose colours the grid edits; also the layout shown live. */
    private WindowLayout editing;

    /** What was on screen when the window opened, for Cancel. */
    private final String themeAtOpen;
    private final WindowLayout layoutAtOpen;
    private final double fontSizeAtOpen;
    private final boolean plainStandardAtOpen;

    /** Something was shown live since the window opened. */
    private boolean previewed;
    private boolean applied;
    /** True while controls are being filled from {@link #working}. */
    private boolean updating;
    /** False while the window is being built: no live preview yet. */
    private boolean ready;
    /** A colour repaint is queued for the next pulse. */
    private boolean paintPending;

    private final Map<Panel, CheckBox> ticks = new EnumMap<>(Panel.class);
    private final Map<Panel, Button> lightBoxes = new EnumMap<>(Panel.class);
    private final Map<Panel, Button> darkBoxes = new EnumMap<>(Panel.class);
    private final Map<WindowLayout, RadioButton> editRadios = new EnumMap<>(WindowLayout.class);
    private final List<Label> headers = new ArrayList<>();

    private Button baseBox;
    private RadioButton lightTheme;
    private RadioButton darkTheme;
    private ToggleButton swap;
    private Spinner<Integer> fontSize;
    private Label panelsHeader;
    private Label hint;
    private Button applyButton;

    private final ChangeListener<String> onTheme = (obs, was, isNow) -> paintThemed();

    private UI_Settings_CustomLayout_Main(UI_Main ide, AstraFrame frame) {
        this.ide = ide;
        this.frame = frame;
        this.stage = frame.stage();
        this.working = CustomLayoutConfig.saved().copy();
        WindowLayout current = LayoutManager.current();
        this.layoutAtOpen = current == null ? WindowLayout.CUSTOM : current;
        this.themeAtOpen = ThemeManager.getActiveTheme();
        this.fontSizeAtOpen = Typography.uiFontSize();
        this.plainStandardAtOpen = CustomLayoutConfig.isPlainStandard();
        this.editing = initialLayout(current);
    }

    /**
     * The layout the window opens on: the one on screen when it already shows
     * a custom look (Custom, or a standard layout in its saved colours),
     * otherwise the one the window last applied.
     */
    private static WindowLayout initialLayout(WindowLayout current) {
        if (current != null && !CustomLayoutConfig.isPlainStandard()
                && (current.isCustom() || CustomLayoutConfig.saved().usesColours(current))) {
            return current;
        }
        return CustomLayoutConfig.lastApplied();
    }

    /**
     * Opens the Custom Layout window. If it is already open, the existing
     * window is brought to the front instead.
     *
     * @param ide the IDE controller
     */
    public static void open(UI_Main ide) {
        if (window != null && window.isShowing()) {
            window.toFront();
            window.requestFocus();
            return;
        }
        Window owner = ide == null ? null : ide.stage;
        AstraFrame frame = new AstraFrame(owner, WINDOW_TITLE, AstraFrame.Kind.DIALOG);
        UI_Settings_CustomLayout_Main view = new UI_Settings_CustomLayout_Main(ide, frame);
        frame.setContent(view.build());
        Stage stage = frame.stage();
        // Every way out -- Cancel, the close mark, Esc, Alt+F4 -- ends here.
        // revert() does nothing after Apply.
        stage.addEventHandler(WindowEvent.WINDOW_HIDDEN, e -> {
            view.revert();
            ThemeManager.themeProperty().removeListener(view.onTheme);
            window = null;
        });
        ThemeManager.themeProperty().addListener(view.onTheme);
        window = stage;
        stage.sizeToScene();
        view.ready = true;
        frame.show();
    }

    // =====================================================================
    // Layout of the window
    // =====================================================================

    private VBox build() {
        HBox columns = new HBox(Dim.CustomLayout.COLUMN_GAP, layoutList(), panelGrid(), rightColumn());
        columns.setPadding(new Insets(Dim.CustomLayout.BODY_PADDING));
        columns.setStyle("-fx-background-color: transparent;");

        VBox content = new VBox(columns);
        content.setStyle("-fx-background-color: transparent;");
        paintThemed();
        refreshControls();
        return content;
    }

    /** One radio per layout, Custom first: which layout to edit and show. */
    private GridPane layoutList() {
        GridPane grid = new GridPane();
        grid.setHgap(Dim.CustomLayout.GRID_HGAP);
        grid.setVgap(Dim.CustomLayout.GRID_VGAP);
        grid.add(columnHeader("Layout", Pos.CENTER_LEFT), 0, 0);

        List<WindowLayout> order = new ArrayList<>();
        order.add(WindowLayout.CUSTOM);
        for (WindowLayout l : WindowLayout.values()) {
            if (!l.isCustom()) {
                order.add(l);
            }
        }
        ToggleGroup edit = new ToggleGroup();
        int row = 1;
        for (WindowLayout layout : order) {
            RadioButton pick = new RadioButton(layout.label());
            pick.setToggleGroup(edit);
            pick.setUserData(layout);
            pick.setTooltip(new Tooltip("Show and edit the " + layout.label() + " layout"));
            editRadios.put(layout, pick);
            setMinRowHeight(pick);
            grid.add(pick, 0, row);
            row++;
        }
        edit.selectedToggleProperty().addListener((obs, was, isNow) -> {
            if (isNow != null && isNow.getUserData() instanceof WindowLayout layout) {
                editing = layout;
                if (updating) {
                    return;
                }
                refreshControls();
                live(true);
            }
        });
        selectRadio(editing);
        return grid;
    }

    /** Selects a layout radio without triggering a live preview. */
    private void selectRadio(WindowLayout layout) {
        RadioButton radio = editRadios.get(layout);
        if (radio == null) {
            return;
        }
        boolean was = updating;
        updating = true;
        try {
            radio.setSelected(true);
        } finally {
            updating = was;
        }
        editing = layout;
    }

    /** Tick + label, then the Light and Dark boxes, one row per panel. */
    private GridPane panelGrid() {
        GridPane grid = new GridPane();
        grid.setHgap(Dim.CustomLayout.GRID_HGAP);
        grid.setVgap(Dim.CustomLayout.GRID_VGAP);
        panelsHeader = columnHeader("Panels", Pos.CENTER_LEFT);
        grid.add(panelsHeader, 0, 0);
        grid.add(columnHeader("Light", Pos.CENTER), 1, 0);
        grid.add(columnHeader("Dark", Pos.CENTER), 2, 0);

        int row = 1;
        for (Panel panel : Panel.values()) {
            CheckBox tick = new CheckBox(panel.label());
            tick.setTooltip(new Tooltip("Ticked: " + panel.label() + " is part of the Custom layout.\n"
                    + "Unticked: it is left out."));
            tick.selectedProperty().addListener((obs, was, isNow) -> {
                if (!updating && editing.isCustom()) {
                    working.setShown(panel, isNow);
                    refreshButtons();
                    live(true);
                }
            });
            setMinRowHeight(tick);
            ticks.put(panel, tick);

            Button light = colourBox(Dim.CustomLayout.SWATCH_WIDTH);
            light.setOnAction(e -> pickPanel(panel, false));
            lightBoxes.put(panel, light);

            Button dark = colourBox(Dim.CustomLayout.SWATCH_WIDTH);
            dark.setOnAction(e -> pickPanel(panel, true));
            darkBoxes.put(panel, dark);

            grid.add(tick, 0, row);
            grid.add(light, 1, row);
            grid.add(dark, 2, row);
            row++;
        }

        hint = new Label("Tick at least one panel.");
        hint.setStyle("-fx-text-fill: #c62828;");
        hint.setManaged(false);
        hint.setVisible(false);
        grid.add(hint, 0, row, 3, 1);
        return grid;
    }

    /** Base Color, Default Theme, Swap, Font Size, then the buttons. */
    private VBox rightColumn() {
        baseBox = colourBox(Dim.CustomLayout.BASE_SWATCH_WIDTH);
        baseBox.setOnAction(e -> pickColour(editing.label() + " - Base Color",
                working.base(editing), c -> working.setBase(editing, c)));
        HBox baseRow = new HBox(Dim.CustomLayout.GRID_HGAP, boxedLabel("Base Color"), baseBox);
        baseRow.setAlignment(Pos.CENTER_LEFT);

        ToggleGroup themes = new ToggleGroup();
        lightTheme = new RadioButton("Light Theme");
        darkTheme = new RadioButton("Dark Theme");
        lightTheme.setToggleGroup(themes);
        darkTheme.setToggleGroup(themes);
        themes.selectedToggleProperty().addListener((obs, was, isNow) -> {
            if (!updating && isNow != null) {
                working.setTheme(isNow == darkTheme ? CustomLayoutConfig.DARK : CustomLayoutConfig.LIGHT);
                live(false);
            }
        });
        VBox themeChoices = new VBox(4, lightTheme, darkTheme);
        HBox themeRow = new HBox(Dim.CustomLayout.GRID_HGAP, boxedLabel("Default Theme"), themeChoices);
        themeRow.setAlignment(Pos.CENTER_LEFT);

        swap = new ToggleButton("\u21C4  Swap sides");
        swap.setFocusTraversable(false);
        swap.setTooltip(new Tooltip("Two panels: left and right change places.\n"
                + "Three or four panels: the columns are mirrored.\n"
                + "Not used with one panel or all five."));
        swap.selectedProperty().addListener((obs, was, isNow) -> {
            if (!updating) {
                working.setSwapped(isNow);
                live(true);
            }
        });
        HBox swapRow = new HBox(Dim.CustomLayout.GRID_HGAP, boxedLabel("Panel Order"), swap);
        swapRow.setAlignment(Pos.CENTER_LEFT);

        fontSize = new Spinner<>(new SpinnerValueFactory.IntegerSpinnerValueFactory(
                (int) Typography.UI_FONT_SIZE_MIN, (int) Typography.UI_FONT_SIZE_MAX,
                (int) working.fontSize(), 1));
        fontSize.setEditable(false);
        fontSize.setFocusTraversable(false);
        fontSize.setPrefWidth(Dim.CustomLayout.BUTTON_WIDTH);
        fontSize.setTooltip(new Tooltip("Text size of every panel, the ribbon, the footer and the menus,\n"
                + (int) Typography.UI_FONT_SIZE_MIN + " to " + (int) Typography.UI_FONT_SIZE_MAX
                + " (factory " + (int) Typography.DEFAULT_UI_FONT_SIZE + "). The editor and the Command Window\n"
                + "keep their own code size. Shown at once; Apply keeps it."));
        fontSize.valueProperty().addListener((obs, was, isNow) -> {
            if (!updating && isNow != null) {
                working.setFontSize(isNow);
                live(false);
            }
        });
        HBox fontRow = new HBox(Dim.CustomLayout.GRID_HGAP, boxedLabel("Font Size"), fontSize);
        fontRow.setAlignment(Pos.CENTER_LEFT);

        Button reset = actionButton("Reset to factory",
                "All panels, the theme's own colours, navy strips, light theme, standard layouts\n"
                        + "in their own colours, font size " + (int) Typography.DEFAULT_UI_FONT_SIZE
                        + ". Shown at once on the Default layout;\nsaved only when you press Apply.");
        reset.setMinWidth(Region.USE_PREF_SIZE);
        reset.setOnAction(e -> resetToFactory());
        HBox resetRow = new HBox(reset);
        resetRow.setAlignment(Pos.CENTER_LEFT);

        applyButton = actionButton("Apply", "Save these choices and close");
        applyButton.setDefaultButton(true);
        applyButton.setOnAction(e -> apply());
        Button cancel = actionButton("Cancel", "Undo every change made in this window and close");
        cancel.setCancelButton(true);
        cancel.setOnAction(e -> stage.close());
        HBox buttons = new HBox(Dim.CustomLayout.BUTTON_GAP, applyButton, cancel);
        buttons.setAlignment(Pos.CENTER_RIGHT);

        Region spacer = new Region();
        spacer.setStyle("-fx-background-color: transparent;");
        VBox.setVgrow(spacer, Priority.ALWAYS);

        VBox column = new VBox(Dim.CustomLayout.RIGHT_ROW_GAP, baseRow, themeRow, swapRow, fontRow,
                spacer, resetRow, buttons);
        column.setFillWidth(true);
        column.setStyle("-fx-background-color: transparent;");
        return column;
    }

    private Label columnHeader(String text, Pos alignment) {
        Label label = new Label(text);
        label.setMaxWidth(Double.MAX_VALUE);
        label.setAlignment(alignment);
        headers.add(label);
        return label;
    }

    private static void setMinRowHeight(Region node) {
        node.setMinHeight(Dim.CustomLayout.SWATCH_HEIGHT);
    }

    /** A label in a 1 px box, exactly as tall as a colour box; outline from the palette. */
    private static Label boxedLabel(String text) {
        Label label = new Label(text);
        double h = Dim.CustomLayout.SWATCH_HEIGHT;
        label.setMinWidth(Dim.CustomLayout.RIGHT_LABEL_WIDTH);
        label.setPrefWidth(Dim.CustomLayout.RIGHT_LABEL_WIDTH);
        label.setMinHeight(h);
        label.setPrefHeight(h);
        label.setMaxHeight(h);
        label.setPadding(new Insets(0, 8, 0, 8));
        label.setStyle("-fx-border-color: -astra-menu-border; -fx-border-width: 1; -fx-border-insets: 0;");
        return label;
    }

    private static Button colourBox(double width) {
        Button box = new Button();
        double h = Dim.CustomLayout.SWATCH_HEIGHT;
        box.setMinSize(width, h);
        box.setPrefSize(width, h);
        box.setMaxSize(width, h);
        box.setFocusTraversable(false);
        return box;
    }

    /** A button in the IDE frame's style ({@link AstraFrame#button}). */
    private static Button actionButton(String text, String tip) {
        Button b = AstraFrame.button(text);
        b.setMinWidth(Dim.CustomLayout.BUTTON_WIDTH);
        b.setPrefWidth(Dim.CustomLayout.BUTTON_WIDTH);
        b.setTooltip(new Tooltip(tip));
        return b;
    }

    // =====================================================================
    // Values <-> controls
    // =====================================================================

    /** Shows {@link #working} for the layout being edited in every control. */
    private void refreshControls() {
        boolean was = updating;
        updating = true;
        try {
            boolean custom = editing.isCustom();
            Set<Panel> fixed = custom ? null : LAYOUT_PANELS.getOrDefault(editing, EnumSet.noneOf(Panel.class));
            for (Panel panel : Panel.values()) {
                CheckBox tick = ticks.get(panel);
                if (tick != null) {
                    tick.setDisable(!custom);
                    tick.setSelected(custom ? working.isShown(panel) : fixed.contains(panel));
                }
                paint(lightBoxes.get(panel), working.color(editing, panel, false),
                        editing.label() + " \u2013 " + panel.label() + " - Light");
                paint(darkBoxes.get(panel), working.color(editing, panel, true),
                        editing.label() + " \u2013 " + panel.label() + " - Dark");
            }
            if (panelsHeader != null) {
                panelsHeader.setText(custom ? "Panels" : "Panels of " + editing.label());
            }
            paint(baseBox, working.base(editing), editing.label() + " \u2013 title strips and ribbon tab bar");
            if (lightTheme != null) {
                boolean dark = CustomLayoutConfig.DARK.equals(working.theme());
                darkTheme.setSelected(dark);
                lightTheme.setSelected(!dark);
                lightTheme.setDisable(!custom);
                darkTheme.setDisable(!custom);
            }
            if (swap != null) {
                swap.setSelected(working.isSwapped());
            }
            if (fontSize != null) {
                fontSize.getValueFactory().setValue((int) working.fontSize());
            }
        } finally {
            updating = was;
        }
        refreshButtons();
    }

    /** Swap and Apply follow the Custom tick count. */
    private void refreshButtons() {
        boolean none = working.shownCount() == 0;
        if (swap != null) {
            swap.setDisable(!editing.isCustom() || !working.canSwap());
        }
        if (applyButton != null) {
            applyButton.setDisable(none);
        }
        if (hint != null) {
            hint.setVisible(none);
            hint.setManaged(none);
        }
    }

    /**
     * The few things the frame's palette does not cover: the column headers'
     * blue and the Swap toggle's outline. Follows the theme while open.
     */
    private void paintThemed() {
        boolean dark = CustomLayoutConfig.DARK.equals(ThemeManager.getActiveTheme());
        for (Label header : headers) {
            header.setStyle("-fx-font-weight: bold; -fx-text-fill: " + (dark ? HEADER_BLUE_DARK : HEADER_BLUE) + ";");
        }
        if (swap != null) {
            swap.setStyle("-fx-border-color: -astra-menu-border; -fx-border-width: 1;"
                    + " -fx-border-insets: 0; -fx-background-insets: 0;"
                    + " -fx-border-radius: 0; -fx-background-radius: 0;");
        }
    }

    /**
     * Paints a colour box. Every inset is zeroed: Modena's button background
     * reaches one pixel below the button ({@code 0 0 -1 0}).
     */
    private static void paint(Button box, Color color, String what) {
        if (box == null || color == null) {
            return;
        }
        box.setStyle("-fx-background-color: " + CustomLayoutConfig.hex(color) + ";"
                + " -fx-background-insets: 0; -fx-background-radius: 0;"
                + " -fx-border-color: #2b2b2b; -fx-border-width: 1;"
                + " -fx-border-insets: 0; -fx-border-radius: 0;"
                + " -fx-padding: 0; -fx-effect: null; -fx-cursor: hand;");
        box.setTooltip(new Tooltip(what + ": " + CustomLayoutConfig.hex(color) + "\nClick to change"));
    }

    private void pickPanel(Panel panel, boolean dark) {
        String what = editing.label() + " \u2013 " + panel.label() + (dark ? " - Dark" : " - Light");
        pickColour(what, working.color(editing, panel, dark), c -> working.setColor(editing, panel, dark, c));
    }

    /**
     * Opens the colour dialog with live preview: every colour tried is shown
     * in the main window as the sliders move; Cancel puts the old one back.
     */
    private void pickColour(String what, Color before, Consumer<Color> set) {
        boolean[] tried = { false };
        Color picked = CustomColorDialog.pick(stage, what, before, c -> {
            tried[0] = true;
            set.accept(c);
            paintSoon();
        });
        set.accept(picked != null ? picked : before);
        refreshControls();
        if (picked != null || tried[0]) {
            live(false);
        }
    }

    /** Coalesces slider drags into one repaint per pulse. */
    private void paintSoon() {
        if (paintPending) {
            return;
        }
        paintPending = true;
        Platform.runLater(() -> {
            paintPending = false;
            refreshControls();
            live(false);
        });
    }

    // =====================================================================
    // Live preview / Reset / Apply / Cancel
    // =====================================================================

    /**
     * Shows {@link #working} in the main window now.
     *
     * @param structural true when panels or their order change (ticks, Swap,
     *                   layout radio, Reset): the layout is rebuilt. False for
     *                   colours, theme and font size: repainted only, when the
     *                   layout being edited is already on screen.
     */
    private void live(boolean structural) {
        if (updating || !ready) {
            return;
        }
        if (editing.isCustom() && working.shownCount() == 0) {
            // Nothing to show; the last valid preview stays, Apply is greyed.
            return;
        }
        previewed = true;
        CustomLayoutConfig.setPreview(working);
        Typography.setUiFontSize(working.fontSize());
        boolean onScreen = LayoutManager.current() == editing && !CustomLayoutConfig.isPlainStandard();
        if (structural || !onScreen) {
            show(editing);
        } else {
            applyCustomTheme(editing);
            CustomLayoutTheme.refresh();
            LayoutRibbon.refreshSelection();
            afterScreenChange();
        }
    }

    /**
     * Factory values into this window, shown live on the Default layout.
     * Nothing is saved: Apply keeps them (and the Custom tile then brings
     * Default back), Cancel puts back everything the window opened with.
     */
    private void resetToFactory() {
        working = CustomLayoutConfig.factory();
        selectRadio(WindowLayout.DEFAULT);
        refreshControls();
        live(true);
    }

    private void apply() {
        applied = true;
        CustomLayoutConfig.save(working);
        CustomLayoutConfig.setLastApplied(editing);
        CustomLayoutConfig.setPreview(null);
        Typography.setUiFontSize(working.fontSize());
        if (previewed && LayoutManager.current() == editing && !CustomLayoutConfig.isPlainStandard()) {
            // Already on screen from the live preview: keep the dividers.
            applyCustomTheme(editing);
            CustomLayoutTheme.refresh();
            LayoutRibbon.refreshSelection();
        } else {
            show(editing);
        }
        stage.close();
    }

    /**
     * Drops the live preview and puts back the layout, theme and font size
     * the window opened with. Does nothing after Apply, or if nothing was
     * shown live.
     */
    private void revert() {
        if (applied || !previewed) {
            return;
        }
        previewed = false;
        CustomLayoutConfig.setPreview(null);
        Typography.setUiFontSize(fontSizeAtOpen);
        CustomLayoutConfig.setPlainStandard(plainStandardAtOpen);
        if (ide != null && themeAtOpen != null && !themeAtOpen.equals(ThemeManager.getActiveTheme())) {
            ThemeManager.applyTheme(ide, themeAtOpen);
        }
        LayoutManager.rebuild(layoutAtOpen);
        LayoutRibbon.refreshSelection();
    }

    /**
     * Puts a layout on screen with {@link CustomLayoutConfig#effective()}.
     * Custom also brings its theme.
     */
    private void show(WindowLayout layout) {
        applyCustomTheme(layout);
        // From this window a layout shows the colours chosen for it; the
        // gallery's standard tiles show the factory look again.
        CustomLayoutConfig.setPlainStandard(false);
        LayoutManager.rebuild(layout);
        // A standard layout in changed colours is marked as Custom in the
        // Settings > Layout gallery; factory colours mark the layout itself.
        LayoutRibbon.refreshSelection();
        afterScreenChange();
    }

    /** Custom carries its own theme; a standard layout keeps the one in use. */
    private void applyCustomTheme(WindowLayout layout) {
        if (layout.isCustom() && ide != null && !working.theme().equals(ThemeManager.getActiveTheme())) {
            ThemeManager.applyTheme(ide, working.theme());
        }
    }

    /** This window follows the main window's sheets and its new font size. */
    private void afterScreenChange() {
        frame.refreshSheets();
        paintThemed();
        if (stage.isShowing()) {
            stage.sizeToScene();
        }
    }
}
