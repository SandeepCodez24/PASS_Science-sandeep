package ui.editor;

import java.nio.file.Files;
import java.nio.file.Path;

import javafx.scene.control.Tab;
import javafx.scene.control.Tooltip;
import ui.UI_Main;

/**
 * Marks editor tabs whose file no longer exists on disk: the tab title is
 * struck out, and its tooltip says where the file was and how to get it back.
 *
 * <h3>What counts as deleted</h3>
 * <p>
 * A tab is deleted when it belongs to a saved file ({@link EditorFileInfo#path}
 * is set) and that path does not exist now. An untitled tab that was never
 * saved is never marked. The text in the editor is untouched either way: it is
 * the only copy left, and Ctrl+S writes it back.
 * </p>
 *
 * <h3>When the check runs</h3>
 * <ul>
 * <li>After every change made from the File Explorer -- delete, undo, redo,
 * paste, new, refresh -- through {@code DirectoryFileOps.afterChange}. So
 * deleting an open file strikes its tab, and Undo in the explorer clears the
 * strike again. Deleting a folder strikes every open file inside it.</li>
 * <li>After every save, through {@code ProjectManager.refreshProjectTree}.
 * Ctrl+S on a struck tab recreates the file (and its folder, if that went
 * too), and the strike goes.</li>
 * <li>Whenever the Astra window regains focus. A file deleted outside Astra --
 * in Windows Explorer, say -- is noticed when the user comes back. Only the
 * files open in tabs are checked; nothing watches the disk in the
 * background.</li>
 * </ul>
 *
 * <h3>How it is drawn</h3>
 * <p>
 * The tab gets the style class {@link #DELETED_CLASS}. The strike-through
 * itself is a rule in the generated sheet ({@code DesignStylesheet.editorTabs}),
 * not a colour, so both themes get it without any change to their CSS.
 * </p>
 */
public final class EditorFileStatus {

    /** Style class carried by the tab of a file that no longer exists. */
    public static final String DELETED_CLASS = "file-deleted";

    /** Where a tab's own tooltip is parked while the deleted note replaces it. */
    private static final String SAVED_TOOLTIP_KEY = "astra.fileStatus.savedTooltip";

    /** Marks a tab whose tooltip is the deleted note, so it is not parked twice. */
    private static final String NOTE_KEY = "astra.fileStatus.note";

    private static boolean installed = false;

    private EditorFileStatus() {
    }

    /**
     * Re-checks the open tabs every time the main window regains focus. Call
     * once, after the main window is built.
     *
     * @param ide the IDE controller
     */
    public static void install(UI_Main ide) {
        if (installed || ide == null || ide.stage == null) {
            return;
        }
        installed = true;
        ide.stage.focusedProperty().addListener((obs, was, now) -> {
            if (Boolean.TRUE.equals(now)) {
                refresh(ide);
            }
        });
        refresh(ide);
    }

    /**
     * Checks every open tab against the disk and strikes out, or un-strikes,
     * its title. Cheap: one existence check per open tab.
     *
     * @param ide the IDE controller
     */
    public static void refresh(UI_Main ide) {
        if (ide == null || ide.editorTabs == null) {
            return;
        }
        for (Tab tab : ide.editorTabs.getTabs()) {
            mark(tab, isMissing(tab));
        }
    }

    /**
     * @param tab an editor tab
     * @return true if the tab is currently struck out
     */
    public static boolean isDeleted(Tab tab) {
        return tab != null && tab.getStyleClass().contains(DELETED_CLASS);
    }

    // =====================================================================
    // Internals
    // =====================================================================

    private static boolean isMissing(Tab tab) {
        if (tab == null || !(tab.getUserData() instanceof EditorFileInfo info) || info.path == null) {
            return false;
        }
        try {
            return !Files.exists(info.path);
        } catch (SecurityException e) {
            return false;
        }
    }

    private static void mark(Tab tab, boolean deleted) {
        if (tab == null) {
            return;
        }
        boolean marked = tab.getStyleClass().contains(DELETED_CLASS);

        if (deleted) {
            if (!marked) {
                tab.getStyleClass().add(DELETED_CLASS);
            }
            if (!tab.getProperties().containsKey(NOTE_KEY)) {
                // Park whatever tooltip the tab had, so it can come back.
                tab.getProperties().put(SAVED_TOOLTIP_KEY, tab.getTooltip());
                tab.getProperties().put(NOTE_KEY, Boolean.TRUE);
            }
            tab.setTooltip(new Tooltip(note(tab)));
            return;
        }

        if (marked) {
            tab.getStyleClass().remove(DELETED_CLASS);
        }
        if (tab.getProperties().containsKey(NOTE_KEY)) {
            Object saved = tab.getProperties().remove(SAVED_TOOLTIP_KEY);
            tab.getProperties().remove(NOTE_KEY);
            tab.setTooltip(saved instanceof Tooltip t ? t : null);
        }
    }

    private static String note(Tab tab) {
        Path path = tab.getUserData() instanceof EditorFileInfo info ? info.path : null;
        String where = path == null ? "" : "\n" + path;
        return "This file has been deleted from disk." + where
                + "\nSave (Ctrl+S) to write it back.";
    }
}
