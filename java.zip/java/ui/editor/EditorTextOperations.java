package ui.editor;

import org.fxmisc.richtext.CodeArea;
import javafx.scene.Node;
import javafx.scene.control.IndexRange;
import javafx.scene.control.Tab;
import javafx.scene.control.TextArea;
import org.fxmisc.flowless.VirtualizedScrollPane;

/**
 * Handles text operations: extraction, insertion, and text manipulation.
 * Provides utilities for working with CodeArea and TextArea editors.
 */
public class EditorTextOperations {

    /**
     * Extracts text content from a tab's editor.
     * Handles CodeArea (with scrollpane) and TextArea.
     * 
     * @param tab the tab to extract text from
     * @return the text content or empty string
     */
    public static String getEditorText(Tab tab) {
        if (tab == null) {
            return "";
        }

        Node content = tab.getContent();
        if (content instanceof VirtualizedScrollPane<?> scrollPane) {
            Node inner = scrollPane.getContent();
            if (inner instanceof CodeArea editor) {
                return editor.getText();
            }
        }
        if (content instanceof CodeArea editor) {
            return editor.getText();
        }
        if (content instanceof TextArea editor) {
            return editor.getText();
        }
        return "";
    }

    /**
     * Sets text content in a tab's editor.
     * Handles CodeArea (with scrollpane) and TextArea.
     * 
     * @param tab  the tab to update
     * @param text the new text content
     */
    public static void setEditorText(Tab tab, String text) {
        if (tab == null) {
            return;
        }

        Node content = tab.getContent();
        if (content instanceof VirtualizedScrollPane<?> scrollPane) {
            Node inner = scrollPane.getContent();
            if (inner instanceof CodeArea editor) {
                editor.replaceText(text);
                return;
            }
        }
        if (content instanceof CodeArea editor) {
            editor.replaceText(text);
            return;
        }
        if (content instanceof TextArea editor) {
            editor.setText(text);
        }
    }

    /**
     * Converts selected lines (or current line if no selection) to command lines in
     * CodeArea.
     * Adds or removes "\\\\" prefix to each line.
     * If no selection, converts the current line where cursor is positioned.
     * 
     * @param editor the CodeArea editor
     */
    public static void commentSelectedLinesCodeArea(CodeArea editor) {
        String text = editor.getText();
        int start, end;

        IndexRange selection = editor.getSelection();
        if (selection != null && selection.getLength() > 0) {
            // Selection exists: process selected lines
            start = lineStart(text, selection.getStart());
            end = lineEnd(text, selection.getEnd());
        } else {
            // No selection: process the current line where cursor is
            int caretPos = editor.getCaretPosition();
            start = lineStart(text, caretPos);
            end = lineEnd(text, caretPos);
        }

        String updated = addCommandPrefixPerLine(text.substring(start, end));
        editor.replaceText(start, end, updated);
        editor.selectRange(start, start + updated.length());
    }

    /**
     * Converts selected lines (or current line if no selection) to command lines in
     * TextArea.
     * Adds or removes "\\\\" prefix to each line.
     * If no selection, converts the current line where cursor is positioned.
     * 
     * @param editor the TextArea editor
     */
    public static void commentSelectedLinesTextArea(TextArea editor) {
        String text = editor.getText();
        int start, end;

        IndexRange selection = editor.getSelection();
        if (selection != null && selection.getLength() > 0) {
            // Selection exists: process selected lines
            start = lineStart(text, selection.getStart());
            end = lineEnd(text, selection.getEnd());
        } else {
            // No selection: process the current line where cursor is
            int caretPos = editor.getCaretPosition();
            start = lineStart(text, caretPos);
            end = lineEnd(text, caretPos);
        }

        String updated = addCommandPrefixPerLine(text.substring(start, end));
        editor.replaceText(start, end, updated);
        editor.selectRange(start, start + updated.length());
    }

    /**
     * Finds the start of the line containing the given index.
     * 
     * @param text  the text content
     * @param index the position in text
     * @return the start position of the line
     */
    private static int lineStart(String text, int index) {
        int safeIndex = Math.max(0, Math.min(index, text.length()));
        int nl = text.lastIndexOf('\n', Math.max(0, safeIndex - 1));
        return nl + 1;
    }

    /**
     * Finds the end of the line containing the given index.
     * 
     * @param text  the text content
     * @param index the position in text
     * @return the end position of the line (after the newline if present)
     */
    private static int lineEnd(String text, int index) {
        int safeIndex = Math.max(0, Math.min(index, text.length()));
        int nl = text.indexOf('\n', safeIndex);
        return nl == -1 ? text.length() : nl + 1;
    }

    /**
     * Toggles command prefix ("\\\\ ") on each line in a text block.
     * Removes prefix if all non-empty lines have it, adds if none/some have it.
     * 
     * @param block the text block to toggle
     * @return the toggled text block
     */
    private static String addCommandPrefixPerLine(String block) {
        if (block.isEmpty()) {
            return "\\\\ ";
        }

        String[] lines = block.split("\n", -1);
        boolean allHavePrefix = lines.length > 0;

        for (String line : lines) {
            if (!line.isEmpty() && !hasCommandPrefix(line)) {
                allHavePrefix = false;
                break;
            }
        }

        StringBuilder out = new StringBuilder();
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];

            if (allHavePrefix && hasCommandPrefix(line)) {
                out.append(stripCommandPrefix(line));
            } else if (!allHavePrefix && !line.isEmpty()) {
                out.append("\\\\ ").append(line);
            } else {
                out.append(line);
            }

            if (i < lines.length - 1) {
                out.append("\n");
            }
        }

        return out.toString();
    }

    private static boolean hasCommandPrefix(String line) {
        return line.startsWith("\\\\ ") || line.startsWith("\\ ") || line.equals("\\\\") || line.equals("\\");
    }

    private static String stripCommandPrefix(String line) {
        if (line.startsWith("\\\\ ")) {
            return line.substring(3);
        }
        if (line.startsWith("\\ ")) {
            return line.substring(2);
        }
        if (line.equals("\\\\") || line.equals("\\")) {
            return "";
        }
        return line;
    }
}
