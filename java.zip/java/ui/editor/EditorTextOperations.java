package ui.editor;

import org.fxmisc.flowless.VirtualizedScrollPane;
import org.fxmisc.richtext.CodeArea;

import javafx.application.Platform;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.IndexRange;
import javafx.scene.control.Tab;
import javafx.scene.control.TextArea;

/**
 * Handles text operations: extraction, insertion, and text manipulation.
 * Provides utilities for working with CodeArea and TextArea editors.
 *
 * <p>
 * The comment commands -- Ctrl+/ (toggle), and the context menu's
 * <b>Comment Out</b> and <b>Uncomment Out</b> -- all go through one transform,
 * {@link #transform(String, CommentAction)}, so the three can never disagree
 * about what a comment is. The prefix is {@code \\ }.
 * </p>
 */
public class EditorTextOperations {

    /**
     * Finds the text control inside a tab, however deeply it is wrapped.
     *
     * <p><b>Changed for folding.</b> A {@code .nc} tab's content is now a
     * {@code StackPane} holding the {@code VirtualizedScrollPane} plus the
     * transparent "..." overlay, so the old two-case check
     * ({@code VirtualizedScrollPane} or bare control) would have returned an
     * empty string for every folded-capable tab -- which would have silently
     * saved empty files. This walks the tree instead, so it is correct for the
     * old shape, the new shape, and any future wrapper.
     *
     * @param node the tab content
     * @return the CodeArea or TextArea found, or {@code null}
     */
    public static Node findEditorNode(Node node) {
        if (node == null) {
            return null;
        }
        if (node instanceof CodeArea || node instanceof TextArea) {
            return node;
        }
        if (node instanceof VirtualizedScrollPane<?> scrollPane) {
            return findEditorNode(scrollPane.getContent());
        }
        if (node instanceof Parent parent) {
            for (Node child : parent.getChildrenUnmodifiable()) {
                Node found = findEditorNode(child);
                if (found != null) {
                    return found;
                }
            }
        }
        return null;
    }

    /**
     * Finds the text control belonging to a tab.
     *
     * <p>Convenience wrapper over {@link #findEditorNode(Node)} for callers
     * that hold a {@link Tab} rather than its content node -- the ribbon's
     * undo/redo cluster, for one. Made public because the tree walk above is
     * the single correct way to reach the editor now that a {@code .nc} tab's
     * content may be wrapped; duplicating it elsewhere is how the two copies
     * drift apart.
     *
     * @param tab the tab to look inside
     * @return the {@code CodeArea} or {@code TextArea} found, or {@code null}
     */
    public static Node findEditor(Tab tab) {
        return tab == null ? null : findEditorNode(tab.getContent());
    }

    /**
     * Extracts text content from a tab's editor.
     *
     * <p>Fold state never affects this: RichTextFX folding hides paragraphs at
     * the view layer only, so {@code getText()} always returns the entire
     * document. Saving a file with blocks collapsed writes the whole file.
     * 
     * @param tab the tab to extract text from
     * @return the text content or empty string
     */
    public static String getEditorText(Tab tab) {
        if (tab == null) {
            return "";
        }
        Node editor = findEditorNode(tab.getContent());
        if (editor instanceof CodeArea codeArea) {
            return codeArea.getText();
        }
        if (editor instanceof TextArea textArea) {
            return textArea.getText();
        }
        return "";
    }

    /**
     * Sets text content in a tab's editor.
     * 
     * @param tab  the tab to update
     * @param text the new text content
     */
    public static void setEditorText(Tab tab, String text) {
        if (tab == null) {
            return;
        }
        Node editor = findEditorNode(tab.getContent());
        if (editor instanceof CodeArea codeArea) {
            codeArea.replaceText(text);
            return;
        }
        if (editor instanceof TextArea textArea) {
            textArea.setText(text);
        }
    }

    // =====================================================================
    // Comment Out / Uncomment Out
    // =====================================================================

    /**
     * What a comment command does to the lines it covers.
     *
     * <ul>
     * <li>{@link #TOGGLE} -- Ctrl+/: uncomment when every line with content
     * already carries the prefix, comment otherwise. Pressed twice over the
     * same lines it always gives back the original text.</li>
     * <li>{@link #COMMENT} -- the context menu's <b>Comment Out</b>: always
     * adds the prefix.</li>
     * <li>{@link #UNCOMMENT} -- the context menu's <b>Uncomment Out</b>:
     * removes the prefix from every line that has one.</li>
     * </ul>
     */
    public enum CommentAction {
        TOGGLE, COMMENT, UNCOMMENT
    }

    /**
     * Ctrl+/ in a CodeArea: toggles the {@code \\ } comment prefix on the
     * selected lines, or on the caret's line when nothing is selected.
     *
     * <h3>Repeated presses alternate</h3>
     * <p>
     * The lines acted on end at the last selected line's own end, never its
     * newline, and a selection that ends at column 0 of a line does not include
     * that line. After toggling, exactly the toggled lines are re-selected, so
     * the next press acts on the same lines and takes the prefix off again.
     * </p>
     * <p>
     * That re-selection is now also re-asserted on the next two FX pulses if
     * the text has not changed since. Folding and highlighting react to the
     * edit on a later pulse, and a paragraph refresh there could collapse the
     * selection to the caret; the next press would then act on one line only,
     * or pull in the line below, and add a second {@code \\} instead of
     * removing the first. With the selection held, the second press always
     * sees the block it just commented.
     * </p>
     * <p>
     * With no selection the caret stays where it was in the text. Each press
     * is one undo step. Blank lines inside the selection are commented as well
     * (see {@link #transform(String, CommentAction)}), so a commented-out
     * section stays one comment block -- and one fold -- however many empty
     * lines it contains.
     * </p>
     *
     * @param editor the CodeArea editor
     */
    public static void commentSelectedLinesCodeArea(CodeArea editor) {
        applyCodeArea(editor, CommentAction.TOGGLE);
    }

    /**
     * Comment Out in a CodeArea: adds the prefix to the selected lines, or the
     * caret's line.
     *
     * @param editor the CodeArea editor
     */
    public static void commentOutCodeArea(CodeArea editor) {
        applyCodeArea(editor, CommentAction.COMMENT);
    }

    /**
     * Uncomment Out in a CodeArea: removes the prefix from the selected lines,
     * or the caret's line.
     *
     * @param editor the CodeArea editor
     */
    public static void uncommentOutCodeArea(CodeArea editor) {
        applyCodeArea(editor, CommentAction.UNCOMMENT);
    }

    /**
     * Ctrl+/ in a TextArea; the twin of
     * {@link #commentSelectedLinesCodeArea(CodeArea)}.
     *
     * @param editor the TextArea editor
     */
    public static void commentSelectedLinesTextArea(TextArea editor) {
        applyTextArea(editor, CommentAction.TOGGLE);
    }

    /** @param editor the TextArea editor; Comment Out */
    public static void commentOutTextArea(TextArea editor) {
        applyTextArea(editor, CommentAction.COMMENT);
    }

    /** @param editor the TextArea editor; Uncomment Out */
    public static void uncommentOutTextArea(TextArea editor) {
        applyTextArea(editor, CommentAction.UNCOMMENT);
    }

    /**
     * @param editor a CodeArea
     * @return true if Comment Out would change the lines it covers: at least
     *         one line with content has no prefix yet, or the lines are all
     *         blank
     */
    public static boolean canCommentOut(CodeArea editor) {
        return editor != null && canCommentOut(editor.getText(), editor.getSelection(), editor.getCaretPosition());
    }

    /**
     * @param editor a CodeArea
     * @return true if Uncomment Out would change the lines it covers: at least
     *         one of them carries the prefix
     */
    public static boolean canUncommentOut(CodeArea editor) {
        return editor != null && canUncommentOut(editor.getText(), editor.getSelection(), editor.getCaretPosition());
    }

    /** @param editor a TextArea; see {@link #canCommentOut(CodeArea)} */
    public static boolean canCommentOut(TextArea editor) {
        return editor != null && canCommentOut(editor.getText(), editor.getSelection(), editor.getCaretPosition());
    }

    /** @param editor a TextArea; see {@link #canUncommentOut(CodeArea)} */
    public static boolean canUncommentOut(TextArea editor) {
        return editor != null && canUncommentOut(editor.getText(), editor.getSelection(), editor.getCaretPosition());
    }

    // ---- shared plumbing -------------------------------------------------

    private static void applyCodeArea(CodeArea editor, CommentAction action) {
        if (editor == null || !editor.isEditable()) {
            return;
        }
        String text = editor.getText();
        IndexRange selection = editor.getSelection();
        boolean hasSelection = selection != null && selection.getLength() > 0;
        int caret = editor.getCaretPosition();

        int[] range = hasSelection
                ? blockRange(text, selection.getStart(), selection.getEnd())
                : blockRange(text, caret, caret);
        int start = range[0];
        int end = range[1];

        String original = text.substring(start, end);
        String updated = transform(original, action);
        if (updated.equals(original)) {
            return;
        }

        editor.getUndoManager().preventMerge();
        editor.replaceText(start, end, updated);
        editor.getUndoManager().preventMerge();

        int newEnd = start + updated.length();
        Runnable restore;
        if (hasSelection) {
            restore = () -> {
                IndexRange now = editor.getSelection();
                if (now == null || now.getStart() != start || now.getEnd() != newEnd) {
                    editor.selectRange(start, newEnd);
                }
            };
        } else {
            int shifted = caret + (updated.length() - original.length());
            int target = Math.max(start, Math.min(shifted, newEnd));
            restore = () -> {
                if (editor.getSelection().getLength() != 0 || editor.getCaretPosition() != target) {
                    editor.moveTo(target);
                }
            };
        }
        restore.run();
        holdAfterEdit(editor::getText, editor.getText(), restore);
    }

    private static void applyTextArea(TextArea editor, CommentAction action) {
        if (editor == null || !editor.isEditable()) {
            return;
        }
        String text = editor.getText();
        IndexRange selection = editor.getSelection();
        boolean hasSelection = selection != null && selection.getLength() > 0;
        int caret = editor.getCaretPosition();

        int[] range = hasSelection
                ? blockRange(text, selection.getStart(), selection.getEnd())
                : blockRange(text, caret, caret);
        int start = range[0];
        int end = range[1];

        String original = text.substring(start, end);
        String updated = transform(original, action);
        if (updated.equals(original)) {
            return;
        }

        editor.replaceText(start, end, updated);

        int newEnd = start + updated.length();
        Runnable restore;
        if (hasSelection) {
            restore = () -> {
                IndexRange now = editor.getSelection();
                if (now == null || now.getStart() != start || now.getEnd() != newEnd) {
                    editor.selectRange(start, newEnd);
                }
            };
        } else {
            int shifted = caret + (updated.length() - original.length());
            int target = Math.max(start, Math.min(shifted, newEnd));
            restore = () -> {
                if (editor.getSelection().getLength() != 0 || editor.getCaretPosition() != target) {
                    editor.positionCaret(target);
                }
            };
        }
        restore.run();
        holdAfterEdit(editor::getText, editor.getText(), restore);
    }

    /**
     * Re-applies a selection on the next pulse and the one after, but only if
     * the document is still exactly what the comment command left. Anything
     * that edited the text in between -- the user typing, an undo -- wins, and
     * the selection is left alone.
     */
    private static void holdAfterEdit(java.util.function.Supplier<String> currentText, String expected,
            Runnable restore) {
        Runnable check = () -> {
            if (expected.equals(currentText.get())) {
                restore.run();
            }
        };
        Platform.runLater(() -> {
            check.run();
            Platform.runLater(check);
        });
    }

    private static boolean canCommentOut(String text, IndexRange selection, int caret) {
        String block = blockAt(text, selection, caret);
        String[] lines = block.split("\n", -1);
        boolean anyContent = false;
        for (String line : lines) {
            if (line.isBlank()) {
                continue;
            }
            anyContent = true;
            if (!hasCommandPrefix(line)) {
                return true;
            }
        }
        return !anyContent;
    }

    private static boolean canUncommentOut(String text, IndexRange selection, int caret) {
        String block = blockAt(text, selection, caret);
        for (String line : block.split("\n", -1)) {
            if (hasCommandPrefix(line)) {
                return true;
            }
        }
        return false;
    }

    private static String blockAt(String text, IndexRange selection, int caret) {
        if (text == null) {
            return "";
        }
        boolean hasSelection = selection != null && selection.getLength() > 0;
        int[] range = hasSelection
                ? blockRange(text, selection.getStart(), selection.getEnd())
                : blockRange(text, caret, caret);
        return text.substring(range[0], range[1]);
    }

    /**
     * The lines a toggle acts on: from the start of the first selected line to
     * the end of the last selected line, excluding that line's newline. A
     * selection ending at column 0 of a line stops at the line above it.
     *
     * @param text     the document
     * @param selStart selection start (or the caret)
     * @param selEnd   selection end (or the caret)
     * @return {start, end}
     */
    private static int[] blockRange(String text, int selStart, int selEnd) {
        int safeStart = Math.max(0, Math.min(selStart, text.length()));
        int safeEnd = Math.max(safeStart, Math.min(selEnd, text.length()));

        int start = lineStart(text, safeStart);
        int effectiveEnd = safeEnd;
        if (safeEnd > safeStart && safeEnd > start && text.charAt(safeEnd - 1) == '\n') {
            effectiveEnd = safeEnd - 1;
        }
        int nl = text.indexOf('\n', effectiveEnd);
        int end = nl == -1 ? text.length() : nl;
        return new int[] { start, end };
    }

    /**
     * Finds the start of the line containing the given index.
     * 
     * @param text  the text content
     * @param index the position in text
     * @return the start position of the line
     */
    private static int lineStart(String text, int index) {
        int safeIndex = Math.max(0, Math.min(index, text.length()));
        if (safeIndex == 0) {
            return 0;
        }
        int nl = text.lastIndexOf('\n', safeIndex - 1);
        return nl + 1;
    }

    /**
     * Applies a comment command to each line of a block.
     *
     * <h3>Blank lines are commented too</h3>
     * Every line of the block is commented, blank ones included, so a section
     * with empty lines in it stays one comment run -- and one fold:
     *
     * <pre>
     *   x = 5;          \\ x = 5;
     *                   \\
     *   y = x;    -&gt;    \\ y = x;
     * </pre>
     *
     * A blank line gets a bare {@code \\} (no trailing space), and uncommenting
     * turns a bare {@code \\} back into an empty line, so a comment / uncomment
     * round trip restores the block exactly. A line holding only spaces counts
     * as blank; its spaces are not kept, since a whitespace-only line carries
     * nothing.
     *
     * <h3>Toggle: add or remove?</h3>
     * The block is uncommented when every line that has content carries the
     * prefix; otherwise it is commented. Blank lines take no part in that
     * decision, so a commented section written before blank lines were
     * commented (with bare, uncommented blank lines in it) still uncomments in
     * one press. A block made only of blank lines is commented.
     *
     * @param block  the lines, joined by {@code \n}, without a trailing newline
     * @param action what to do
     * @return the new text of the block
     */
    private static String transform(String block, CommentAction action) {
        if (block.isEmpty()) {
            return action == CommentAction.UNCOMMENT ? block : "\\\\ ";
        }

        String[] lines = block.split("\n", -1);
        boolean uncomment;
        if (action == CommentAction.TOGGLE) {
            boolean anyContent = false;
            boolean allHavePrefix = true;
            for (String line : lines) {
                if (line.isBlank()) {
                    continue;
                }
                anyContent = true;
                if (!hasCommandPrefix(line)) {
                    allHavePrefix = false;
                }
            }
            uncomment = anyContent && allHavePrefix;
        } else {
            uncomment = action == CommentAction.UNCOMMENT;
        }

        StringBuilder out = new StringBuilder(block.length() + lines.length * 3);
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            if (uncomment) {
                out.append(hasCommandPrefix(line) ? stripCommandPrefix(line) : line);
            } else if (line.isBlank()) {
                out.append("\\\\");
            } else {
                out.append("\\\\ ").append(line);
            }
            if (i < lines.length - 1) {
                out.append("\n");
            }
        }
        return out.toString();
    }

    private static boolean hasCommandPrefix(String line) {
        return line.startsWith("\\\\ ") || line.startsWith("\\ ") || line.equals("\\\\") || line.equals("\\");
    }

    private static String stripCommandPrefix(String line) {
        if (line.startsWith("\\\\ ")) {
            return line.substring(3);
        }
        if (line.startsWith("\\ ")) {
            return line.substring(2);
        }
        if (line.equals("\\\\") || line.equals("\\")) {
            return "";
        }
        return line;
    }
}
