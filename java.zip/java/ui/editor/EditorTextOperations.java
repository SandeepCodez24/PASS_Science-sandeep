package ui.editor;

import org.fxmisc.flowless.VirtualizedScrollPane;
import org.fxmisc.richtext.CodeArea;

import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.IndexRange;
import javafx.scene.control.Tab;
import javafx.scene.control.TextArea;

/**
 * Handles text operations: extraction, insertion, and text manipulation.
 * Provides utilities for working with CodeArea and TextArea editors.
 */
public class EditorTextOperations {

    /**
     * Finds the text control inside a tab, however deeply it is wrapped.
     *
     * <p><b>Changed for folding.</b> A {@code .nc} tab's content is now a
     * {@code StackPane} holding the {@code VirtualizedScrollPane} plus the
     * transparent "..." overlay, so the old two-case check
     * ({@code VirtualizedScrollPane} or bare control) would have returned an
     * empty string for every folded-capable tab -- which would have silently
     * saved empty files. This walks the tree instead, so it is correct for the
     * old shape, the new shape, and any future wrapper.
     *
     * @param node the tab content
     * @return the CodeArea or TextArea found, or {@code null}
     */
    public static Node findEditorNode(Node node) {
        if (node == null) {
            return null;
        }
        if (node instanceof CodeArea || node instanceof TextArea) {
            return node;
        }
        if (node instanceof VirtualizedScrollPane<?> scrollPane) {
            return findEditorNode(scrollPane.getContent());
        }
        if (node instanceof Parent parent) {
            for (Node child : parent.getChildrenUnmodifiable()) {
                Node found = findEditorNode(child);
                if (found != null) {
                    return found;
                }
            }
        }
        return null;
    }

    /**
     * Finds the text control belonging to a tab.
     *
     * <p>Convenience wrapper over {@link #findEditorNode(Node)} for callers
     * that hold a {@link Tab} rather than its content node -- the ribbon's
     * undo/redo cluster, for one. Made public because the tree walk above is
     * the single correct way to reach the editor now that a {@code .nc} tab's
     * content may be wrapped; duplicating it elsewhere is how the two copies
     * drift apart.
     *
     * @param tab the tab to look inside
     * @return the {@code CodeArea} or {@code TextArea} found, or {@code null}
     */
    public static Node findEditor(Tab tab) {
        return tab == null ? null : findEditorNode(tab.getContent());
    }

    /**
     * Extracts text content from a tab's editor.
     *
     * <p>Fold state never affects this: RichTextFX folding hides paragraphs at
     * the view layer only, so {@code getText()} always returns the entire
     * document. Saving a file with blocks collapsed writes the whole file.
     * 
     * @param tab the tab to extract text from
     * @return the text content or empty string
     */
    public static String getEditorText(Tab tab) {
        if (tab == null) {
            return "";
        }
        Node editor = findEditorNode(tab.getContent());
        if (editor instanceof CodeArea codeArea) {
            return codeArea.getText();
        }
        if (editor instanceof TextArea textArea) {
            return textArea.getText();
        }
        return "";
    }

    /**
     * Sets text content in a tab's editor.
     * 
     * @param tab  the tab to update
     * @param text the new text content
     */
    public static void setEditorText(Tab tab, String text) {
        if (tab == null) {
            return;
        }
        Node editor = findEditorNode(tab.getContent());
        if (editor instanceof CodeArea codeArea) {
            codeArea.replaceText(text);
            return;
        }
        if (editor instanceof TextArea textArea) {
            textArea.setText(text);
        }
    }

    /**
     * Toggles the {@code \\ } comment prefix on the selected lines, or on the
     * caret's line when nothing is selected, in a CodeArea.
     *
     * <h3>Bug fixed: repeated Ctrl+? kept adding {@code \\}</h3>
     * The old code ended its line range <i>after</i> the last line's newline
     * and then re-selected that whole range. The new selection therefore ended
     * at column 0 of the line <b>below</b> the block. On the next press that
     * extra, uncommented line was pulled into the range, so "every line already
     * has the prefix" was false and the prefix was added again instead of being
     * removed. Re-selecting by hand only helped because a hand-made selection
     * does not spill into the next line.
     *
     * <p>
     * The range now ends at the last selected line's own end, never its
     * newline, and a selection that ends at column 0 of a line does not include
     * that line. After toggling, exactly the toggled lines are re-selected, so
     * pressing Ctrl+? again toggles the same lines back. With no selection the
     * caret stays where it was in the text instead of the line being selected.
     * Each press is one undo step.
     *
     * <p>
     * Blank lines inside the selection are commented as well (see
     * {@link #addCommandPrefixPerLine(String)}), so a commented-out section
     * stays one comment block -- and one fold -- however many empty lines it
     * contains.
     *
     * @param editor the CodeArea editor
     */
    public static void commentSelectedLinesCodeArea(CodeArea editor) {
        String text = editor.getText();
        IndexRange selection = editor.getSelection();
        boolean hasSelection = selection != null && selection.getLength() > 0;
        int caret = editor.getCaretPosition();

        int[] range = hasSelection
                ? blockRange(text, selection.getStart(), selection.getEnd())
                : blockRange(text, caret, caret);
        int start = range[0];
        int end = range[1];

        String original = text.substring(start, end);
        String updated = addCommandPrefixPerLine(original);
        if (updated.equals(original)) {
            return;
        }

        editor.getUndoManager().preventMerge();
        editor.replaceText(start, end, updated);
        editor.getUndoManager().preventMerge();

        if (hasSelection) {
            editor.selectRange(start, start + updated.length());
        } else {
            int shifted = caret + (updated.length() - original.length());
            editor.moveTo(Math.max(start, Math.min(shifted, start + updated.length())));
        }
    }

    /**
     * TextArea twin of {@link #commentSelectedLinesCodeArea(CodeArea)}, with
     * the same fix.
     *
     * @param editor the TextArea editor
     */
    public static void commentSelectedLinesTextArea(TextArea editor) {
        String text = editor.getText();
        IndexRange selection = editor.getSelection();
        boolean hasSelection = selection != null && selection.getLength() > 0;
        int caret = editor.getCaretPosition();

        int[] range = hasSelection
                ? blockRange(text, selection.getStart(), selection.getEnd())
                : blockRange(text, caret, caret);
        int start = range[0];
        int end = range[1];

        String original = text.substring(start, end);
        String updated = addCommandPrefixPerLine(original);
        if (updated.equals(original)) {
            return;
        }

        editor.replaceText(start, end, updated);

        if (hasSelection) {
            editor.selectRange(start, start + updated.length());
        } else {
            int shifted = caret + (updated.length() - original.length());
            editor.positionCaret(Math.max(start, Math.min(shifted, start + updated.length())));
        }
    }

    /**
     * The lines a toggle acts on: from the start of the first selected line to
     * the end of the last selected line, excluding that line's newline. A
     * selection ending at column 0 of a line stops at the line above it.
     *
     * @param text     the document
     * @param selStart selection start (or the caret)
     * @param selEnd   selection end (or the caret)
     * @return {start, end}
     */
    private static int[] blockRange(String text, int selStart, int selEnd) {
        int safeStart = Math.max(0, Math.min(selStart, text.length()));
        int safeEnd = Math.max(safeStart, Math.min(selEnd, text.length()));

        int start = lineStart(text, safeStart);
        int effectiveEnd = safeEnd;
        if (safeEnd > safeStart && safeEnd > start && text.charAt(safeEnd - 1) == '\n') {
            effectiveEnd = safeEnd - 1;
        }
        int nl = text.indexOf('\n', effectiveEnd);
        int end = nl == -1 ? text.length() : nl;
        return new int[] { start, end };
    }

    /**
     * Finds the start of the line containing the given index.
     * 
     * @param text  the text content
     * @param index the position in text
     * @return the start position of the line
     */
    private static int lineStart(String text, int index) {
        int safeIndex = Math.max(0, Math.min(index, text.length()));
        if (safeIndex == 0) {
            return 0;
        }
        int nl = text.lastIndexOf('\n', safeIndex - 1);
        return nl + 1;
    }

    /**
     * Toggles the comment prefix on each line of a block.
     *
     * <h3>Blank lines are commented too</h3>
     * Commenting out a section used to skip its empty lines, so a section with
     * blank lines in it came back as several separate comment runs -- and the
     * editor folded it as several regions instead of one. Every line of the
     * block is now commented, blank ones included:
     *
     * <pre>
     *   x = 5;          \\ x = 5;
     *                   \\
     *   y = x;    -&gt;    \\ y = x;
     * </pre>
     *
     * A blank line gets a bare {@code \\} (no trailing space), and uncommenting
     * turns a bare {@code \\} back into an empty line, so a comment / uncomment
     * round trip restores the block exactly. A line holding only spaces counts
     * as blank; its spaces are not kept, since a whitespace-only line carries
     * nothing.
     *
     * <h3>Add or remove?</h3>
     * The block is uncommented when every line that has content carries the
     * prefix; otherwise it is commented. Blank lines take no part in that
     * decision, so a commented section written before this change (with bare,
     * uncommented blank lines in it) still uncomments in one press. A block
     * made only of blank lines is commented.
     *
     * @param block the text block to toggle
     * @return the toggled text block
     */
    private static String addCommandPrefixPerLine(String block) {
        if (block.isEmpty()) {
            return "\\\\ ";
        }

        String[] lines = block.split("\n", -1);
        boolean anyContent = false;
        boolean allHavePrefix = true;
        for (String line : lines) {
            if (line.isBlank()) {
                continue;
            }
            anyContent = true;
            if (!hasCommandPrefix(line)) {
                allHavePrefix = false;
            }
        }
        boolean uncomment = anyContent && allHavePrefix;

        StringBuilder out = new StringBuilder(block.length() + lines.length * 3);
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            if (uncomment) {
                out.append(hasCommandPrefix(line) ? stripCommandPrefix(line) : line);
            } else if (line.isBlank()) {
                out.append("\\\\");
            } else {
                out.append("\\\\ ").append(line);
            }
            if (i < lines.length - 1) {
                out.append("\n");
            }
        }
        return out.toString();
    }

    private static boolean hasCommandPrefix(String line) {
        return line.startsWith("\\\\ ") || line.startsWith("\\ ") || line.equals("\\\\") || line.equals("\\");
    }

    private static String stripCommandPrefix(String line) {
        if (line.startsWith("\\\\ ")) {
            return line.substring(3);
        }
        if (line.startsWith("\\ ")) {
            return line.substring(2);
        }
        if (line.equals("\\\\") || line.equals("\\")) {
            return "";
        }
        return line;
    }
}
