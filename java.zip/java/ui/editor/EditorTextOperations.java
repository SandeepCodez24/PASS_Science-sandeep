package ui.editor;

import org.fxmisc.flowless.VirtualizedScrollPane;
import org.fxmisc.richtext.CodeArea;

import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.IndexRange;
import javafx.scene.control.Tab;
import javafx.scene.control.TextArea;

/**
 * Handles text operations: extraction, insertion, and text manipulation.
 * Provides utilities for working with CodeArea and TextArea editors.
 */
public class EditorTextOperations {

    /**
     * Finds the text control inside a tab, however deeply it is wrapped.
     *
     * <p><b>Changed for folding.</b> A {@code .nc} tab's content is now a
     * {@code StackPane} holding the {@code VirtualizedScrollPane} plus the
     * transparent "..." overlay, so the old two-case check
     * ({@code VirtualizedScrollPane} or bare control) would have returned an
     * empty string for every folded-capable tab -- which would have silently
     * saved empty files. This walks the tree instead, so it is correct for the
     * old shape, the new shape, and any future wrapper.
     *
     * @param node the tab content
     * @return the CodeArea or TextArea found, or {@code null}
     */
    public static Node findEditorNode(Node node) {
        if (node == null) {
            return null;
        }
        if (node instanceof CodeArea || node instanceof TextArea) {
            return node;
        }
        if (node instanceof VirtualizedScrollPane<?> scrollPane) {
            return findEditorNode(scrollPane.getContent());
        }
        if (node instanceof Parent parent) {
            for (Node child : parent.getChildrenUnmodifiable()) {
                Node found = findEditorNode(child);
                if (found != null) {
                    return found;
                }
            }
        }
        return null;
    }

    /**
     * Finds the text control belonging to a tab.
     *
     * <p>Convenience wrapper over {@link #findEditorNode(Node)} for callers
     * that hold a {@link Tab} rather than its content node -- the ribbon's
     * undo/redo cluster, for one. Made public because the tree walk above is
     * the single correct way to reach the editor now that a {@code .nc} tab's
     * content may be wrapped; duplicating it elsewhere is how the two copies
     * drift apart.
     *
     * @param tab the tab to look inside
     * @return the {@code CodeArea} or {@code TextArea} found, or {@code null}
     */
    public static Node findEditor(Tab tab) {
        return tab == null ? null : findEditorNode(tab.getContent());
    }

    /**
     * Extracts text content from a tab's editor.
     *
     * <p>Fold state never affects this: RichTextFX folding hides paragraphs at
     * the view layer only, so {@code getText()} always returns the entire
     * document. Saving a file with blocks collapsed writes the whole file.
     * 
     * @param tab the tab to extract text from
     * @return the text content or empty string
     */
    public static String getEditorText(Tab tab) {
        if (tab == null) {
            return "";
        }
        Node editor = findEditorNode(tab.getContent());
        if (editor instanceof CodeArea codeArea) {
            return codeArea.getText();
        }
        if (editor instanceof TextArea textArea) {
            return textArea.getText();
        }
        return "";
    }

    /**
     * Sets text content in a tab's editor.
     * 
     * @param tab  the tab to update
     * @param text the new text content
     */
    public static void setEditorText(Tab tab, String text) {
        if (tab == null) {
            return;
        }
        Node editor = findEditorNode(tab.getContent());
        if (editor instanceof CodeArea codeArea) {
            codeArea.replaceText(text);
            return;
        }
        if (editor instanceof TextArea textArea) {
            textArea.setText(text);
        }
    }

    /**
     * Converts selected lines (or current line if no selection) to command lines in
     * CodeArea.
     * Adds or removes "\\" prefix to each line.
     * If no selection, converts the current line where cursor is positioned.
     * 
     * @param editor the CodeArea editor
     */
    public static void commentSelectedLinesCodeArea(CodeArea editor) {
        String text = editor.getText();
        int start, end;

        IndexRange selection = editor.getSelection();
        if (selection != null && selection.getLength() > 0) {
            // Selection exists: process selected lines
            start = lineStart(text, selection.getStart());
            end = lineEnd(text, selection.getEnd());
        } else {
            // No selection: process the current line where cursor is
            int caretPos = editor.getCaretPosition();
            start = lineStart(text, caretPos);
            end = lineEnd(text, caretPos);
        }

        String updated = addCommandPrefixPerLine(text.substring(start, end));
        editor.replaceText(start, end, updated);
        editor.selectRange(start, start + updated.length());
    }

    /**
     * Converts selected lines (or current line if no selection) to command lines in
     * TextArea.
     * Adds or removes "\\" prefix to each line.
     * If no selection, converts the current line where cursor is positioned.
     * 
     * @param editor the TextArea editor
     */
    public static void commentSelectedLinesTextArea(TextArea editor) {
        String text = editor.getText();
        int start, end;

        IndexRange selection = editor.getSelection();
        if (selection != null && selection.getLength() > 0) {
            // Selection exists: process selected lines
            start = lineStart(text, selection.getStart());
            end = lineEnd(text, selection.getEnd());
        } else {
            // No selection: process the current line where cursor is
            int caretPos = editor.getCaretPosition();
            start = lineStart(text, caretPos);
            end = lineEnd(text, caretPos);
        }

        String updated = addCommandPrefixPerLine(text.substring(start, end));
        editor.replaceText(start, end, updated);
        editor.selectRange(start, start + updated.length());
    }

    /**
     * Finds the start of the line containing the given index.
     * 
     * @param text  the text content
     * @param index the position in text
     * @return the start position of the line
     */
    private static int lineStart(String text, int index) {
        int safeIndex = Math.max(0, Math.min(index, text.length()));
        int nl = text.lastIndexOf('\n', Math.max(0, safeIndex - 1));
        return nl + 1;
    }

    /**
     * Finds the end of the line containing the given index.
     * 
     * @param text  the text content
     * @param index the position in text
     * @return the end position of the line (after the newline if present)
     */
    private static int lineEnd(String text, int index) {
        int safeIndex = Math.max(0, Math.min(index, text.length()));
        int nl = text.indexOf('\n', safeIndex);
        return nl == -1 ? text.length() : nl + 1;
    }

    /**
     * Toggles command prefix ("\\ ") on each line in a text block.
     * Removes prefix if all non-empty lines have it, adds if none/some have it.
     * 
     * @param block the text block to toggle
     * @return the toggled text block
     */
    private static String addCommandPrefixPerLine(String block) {
        if (block.isEmpty()) {
            return "\\\\ ";
        }

        String[] lines = block.split("\n", -1);
        boolean allHavePrefix = lines.length > 0;
        for (String line : lines) {
            if (!line.isEmpty() && !hasCommandPrefix(line)) {
                allHavePrefix = false;
                break;
            }
        }

        StringBuilder out = new StringBuilder();
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            if (allHavePrefix && hasCommandPrefix(line)) {
                out.append(stripCommandPrefix(line));
            } else if (!allHavePrefix && !line.isEmpty()) {
                out.append("\\\\ ").append(line);
            } else {
                out.append(line);
            }
            if (i < lines.length - 1) {
                out.append("\n");
            }
        }
        return out.toString();
    }

    private static boolean hasCommandPrefix(String line) {
        return line.startsWith("\\\\ ") || line.startsWith("\\ ") || line.equals("\\\\") || line.equals("\\");
    }

    private static String stripCommandPrefix(String line) {
        if (line.startsWith("\\\\ ")) {
            return line.substring(3);
        }
        if (line.startsWith("\\ ")) {
            return line.substring(2);
        }
        if (line.equals("\\\\") || line.equals("\\")) {
            return "";
        }
        return line;
    }
}
