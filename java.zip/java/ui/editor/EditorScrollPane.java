package ui.editor;

import org.fxmisc.flowless.VirtualizedScrollPane;
import org.fxmisc.richtext.CodeArea;

import javafx.beans.InvalidationListener;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.scene.Node;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.ScrollPane.ScrollBarPolicy;
import ui.editor.folding.FoldableCodeArea;

/**
 * The scroll pane around a {@code .nc} editor. It is still a
 * {@code VirtualizedScrollPane<CodeArea>}, so every
 * {@code instanceof VirtualizedScrollPane} unwrap in the project keeps working.
 *
 * <h3>Why it exists: scroll bars under zoom</h3>
 * <p>
 * Zoom scales the editor as one picture ({@link FoldableCodeArea#setZoom}).
 * Everything Flowless measures inside the editor -- total width and height,
 * scroll offsets, the visible amount -- is then in the editor's own, zoomed
 * units, and stays consistent. One decision is not: whether a scroll bar is
 * needed at all compares the editor's total size (zoomed units) with this
 * pane's size (screen pixels). At 150% a line that runs off the right edge
 * could fail that test and leave no horizontal bar to reach it.
 * </p>
 * <p>
 * So while the zoom is not 100%, this class makes that decision itself, in
 * screen pixels, and sets each bar's policy to {@code ALWAYS} or
 * {@code NEVER}. At 100% the policies go back to {@code AS_NEEDED} and
 * Flowless decides exactly as before.
 * </p>
 */
public class EditorScrollPane extends VirtualizedScrollPane<CodeArea> {

    private final CodeArea area;

    /**
     * @param content the editor
     */
    public EditorScrollPane(CodeArea content) {
        super(content);
        this.area = content;
        getStyleClass().add("editor-scroll-pane");

        InvalidationListener update = obs -> updateBars();
        content.totalWidthEstimateProperty().addListener(update);
        content.totalHeightEstimateProperty().addListener(update);
        content.paddingProperty().addListener(update);
        widthProperty().addListener(update);
        heightProperty().addListener(update);
    }

    /**
     * Re-evaluates the scroll bars. Called by {@code EditorViewSettings}
     * after a zoom change, and on every size change.
     */
    public void updateBars() {
        double zoom = area instanceof FoldableCodeArea foldable ? foldable.getZoom() : 1.0;
        if (zoom == 1.0) {
            if (getHbarPolicy() != ScrollBarPolicy.AS_NEEDED) {
                setHbarPolicy(ScrollBarPolicy.AS_NEEDED);
            }
            if (getVbarPolicy() != ScrollBarPolicy.AS_NEEDED) {
                setVbarPolicy(ScrollBarPolicy.AS_NEEDED);
            }
            return;
        }

        Insets pad = area.getPadding();
        Double totalW = area.totalWidthEstimateProperty().getValue();
        Double totalH = area.totalHeightEstimateProperty().getValue();
        if (totalW == null || totalH == null) {
            return;
        }
        // Everything in screen pixels.
        double contentW = (totalW + pad.getLeft() + pad.getRight()) * zoom;
        double contentH = (totalH + pad.getTop() + pad.getBottom()) * zoom;
        double paneW = getWidth();
        double paneH = getHeight();

        boolean needH0 = contentW > paneW;
        boolean needV0 = contentH > paneH;
        // A bar on one side takes room from the other, which may call for
        // the second bar too -- the same rule Flowless uses.
        boolean needH = needH0 || needV0 && contentW + barThickness(Orientation.VERTICAL) > paneW;
        boolean needV = needV0 || needH0 && contentH + barThickness(Orientation.HORIZONTAL) > paneH;

        ScrollBarPolicy h = needH ? ScrollBarPolicy.ALWAYS : ScrollBarPolicy.NEVER;
        ScrollBarPolicy v = needV ? ScrollBarPolicy.ALWAYS : ScrollBarPolicy.NEVER;
        if (getHbarPolicy() != h) {
            setHbarPolicy(h);
        }
        if (getVbarPolicy() != v) {
            setVbarPolicy(v);
        }
    }

    /** Width of the vertical bar, or height of the horizontal one. */
    private double barThickness(Orientation orientation) {
        for (Node child : getChildrenUnmodifiable()) {
            if (child instanceof ScrollBar bar && bar.getOrientation() == orientation) {
                return orientation == Orientation.VERTICAL ? bar.prefWidth(-1) : bar.prefHeight(-1);
            }
        }
        return 0;
    }
}
