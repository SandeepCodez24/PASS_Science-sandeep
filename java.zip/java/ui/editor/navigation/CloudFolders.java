package ui.editor.navigation;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Stream;

/**
 * Finds the cloud folders the Cloud button can go to.
 *
 * <h3>Today: OneDrive</h3>
 * <p>
 * OneDrive syncs to an ordinary local folder, so "browsing the cloud" is
 * navigating there. The folder is found three ways, because no single one is
 * reliable across personal and work accounts:
 * </p>
 * <ol>
 * <li>the {@code OneDrive}, {@code OneDriveCommercial} and
 * {@code OneDriveConsumer} environment variables the OneDrive client sets;</li>
 * <li>any folder directly under the user's home whose name starts with
 * {@code OneDrive} -- this is what catches {@code OneDrive - Company}, which
 * the old lookup (env vars plus {@code ~\OneDrive}) missed;</li>
 * <li>nothing else. No registry, no network.</li>
 * </ol>
 * <p>
 * Duplicates are removed after canonicalising, since {@code OneDrive} and
 * {@code OneDriveCommercial} usually point at the same folder.
 * </p>
 *
 * <h3>Later: the Neural Code cloud</h3>
 * <p>
 * When Astra gets its own cloud storage, this is the one class to extend: add
 * its mount point (or a virtual entry) to {@link #folders()} and the Cloud
 * button's menu picks it up unchanged.
 * </p>
 */
public final class CloudFolders {

    private static final String[] ONEDRIVE_ENV = { "OneDrive", "OneDriveCommercial", "OneDriveConsumer" };
    private static final String ONEDRIVE_PREFIX = "onedrive";

    private CloudFolders() {
    }

    /**
     * @return every reachable cloud folder, in discovery order, never null
     */
    public static List<Path> folders() {
        Map<String, Path> found = new LinkedHashMap<>();

        for (String key : ONEDRIVE_ENV) {
            String value = System.getenv(key);
            if (value != null && !value.isBlank()) {
                add(found, Path.of(value));
            }
        }

        Path home = Path.of(System.getProperty("user.home"));
        try (Stream<Path> children = Files.list(home)) {
            children.filter(Files::isDirectory)
                    .filter(p -> p.getFileName() != null
                            && p.getFileName().toString().toLowerCase(Locale.ROOT).startsWith(ONEDRIVE_PREFIX))
                    .sorted(Comparator.comparing(p -> p.getFileName().toString().toLowerCase(Locale.ROOT)))
                    .forEach(p -> add(found, p));
        } catch (IOException | RuntimeException ignored) {
            // An unreadable home folder just contributes nothing.
        }

        return new ArrayList<>(found.values());
    }

    /**
     * A friendly name for a cloud folder: {@code OneDrive - Company} stays as
     * is, a bare {@code OneDrive} reads {@code OneDrive - Personal}.
     *
     * @param folder a folder from {@link #folders()}
     * @return the label
     */
    public static String label(Path folder) {
        String name = FolderPaths.label(folder);
        if (name.equalsIgnoreCase("OneDrive")) {
            return "OneDrive - Personal";
        }
        return name;
    }

    private static void add(Map<String, Path> into, Path candidate) {
        try {
            if (!FolderPaths.isFolder(candidate)) {
                return;
            }
            Path canonical = FolderPaths.canonical(candidate);
            into.putIfAbsent(canonical.toString().toLowerCase(Locale.ROOT), canonical);
        } catch (RuntimeException ignored) {
            // Skip anything that cannot be resolved.
        }
    }
}
