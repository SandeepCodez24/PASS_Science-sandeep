package ui.editor.navigation;

import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;

/**
 * The Back / Forward history: the folders in which a file was actually run.
 *
 * <h3>What goes in</h3>
 * <ul>
 * <li>Each Run adds the project folder in force at that moment
 * ({@link #recordRun(Path)}, called from {@code EditorFileRunner}).</li>
 * <li>Running twice in the same folder adds nothing the second time.</li>
 * <li>Browsing -- breadcrumb, Up, Home, Cloud, Root, Open Folder -- adds
 * nothing. A folder has to be run in to earn a place.</li>
 * <li>A run while stepped back drops everything ahead of the cursor, as a
 * browser does.</li>
 * <li>At most {@link #MAX_ENTRIES} folders are kept; the oldest go first.</li>
 * </ul>
 *
 * <h3>How Back decides where to go</h3>
 * <p>
 * If the breadcrumb is showing the folder under the cursor, Back steps to the
 * one before it. If the user has wandered off to a folder that is not the one
 * under the cursor, the first Back simply returns to the cursor's folder --
 * "take me back to where I last ran" -- and only the next one steps further.
 * </p>
 *
 * <p>
 * Folders deleted since they were recorded are dropped silently whenever the
 * history is read, so Back never lands on something that no longer exists.
 * The list and the cursor are mirrored into {@link Preferences}.
 * </p>
 *
 * <p>
 * Not thread-safe beyond the listener list; call it from the FX thread, which
 * is where both the runner and the navigation buttons live.
 * </p>
 */
public final class FolderHistory {

    /** Longest history kept. */
    public static final int MAX_ENTRIES = 20;

    private static final Preferences PREFS = Preferences.userRoot().node("astra/folder_history");
    private static final String KEY_ENTRIES = "entries";
    private static final String KEY_CURSOR = "cursor";

    /**
     * Separator for the stored list. A character Windows forbids in paths, so
     * it can never appear inside an entry.
     */
    private static final String SEP = "|";

    private static final List<Path> ENTRIES = new ArrayList<>();
    private static int cursor = -1;
    private static boolean loaded;

    private static final List<Runnable> LISTENERS = new CopyOnWriteArrayList<>();

    private FolderHistory() {
    }

    /**
     * Records that a file was run with this folder as the project folder.
     *
     * @param folder the project folder; ignored if null or not a folder
     */
    public static void recordRun(Path folder) {
        ensureLoaded();
        if (!FolderPaths.isFolder(folder)) {
            return;
        }
        Path entry = FolderPaths.canonical(folder);
        prune();

        if (cursor >= 0 && FolderPaths.sameCanonical(ENTRIES.get(cursor), entry)) {
            // Same folder as the one under the cursor. Like reloading a page:
            // nothing is added and the Forward entries are kept.
            return;
        }

        truncateAfterCursor();
        ENTRIES.add(entry);
        while (ENTRIES.size() > MAX_ENTRIES) {
            ENTRIES.remove(0);
        }
        cursor = ENTRIES.size() - 1;
        save();
        fire();
    }

    /**
     * @param shown the folder the breadcrumb is showing; may be null
     * @return true if {@link #back(Path)} would return somewhere
     */
    public static boolean canGoBack(Path shown) {
        shown = FolderPaths.canonical(shown);
        ensureLoaded();
        prune();
        if (cursor < 0) {
            return false;
        }
        return cursor > 0 || !FolderPaths.sameCanonical(ENTRIES.get(cursor), shown);
    }

    /**
     * @return true if {@link #forward()} would return somewhere
     */
    public static boolean canGoForward() {
        ensureLoaded();
        prune();
        return cursor >= 0 && cursor < ENTRIES.size() - 1;
    }

    /**
     * Moves the cursor back and returns the folder to show.
     *
     * @param shown the folder the breadcrumb is showing; may be null
     * @return the folder to go to, or null if there is nowhere to go
     */
    public static Path back(Path shown) {
        shown = FolderPaths.canonical(shown);
        ensureLoaded();
        prune();
        if (cursor < 0) {
            return null;
        }
        if (!FolderPaths.sameCanonical(ENTRIES.get(cursor), shown)) {
            // Wandered off: return to the run folder under the cursor first.
            return ENTRIES.get(cursor);
        }
        if (cursor == 0) {
            return null;
        }
        cursor--;
        save();
        fire();
        return ENTRIES.get(cursor);
    }

    /**
     * Moves the cursor forward and returns the folder to show.
     *
     * @return the folder to go to, or null if there is nowhere to go
     */
    public static Path forward() {
        ensureLoaded();
        prune();
        if (cursor < 0 || cursor >= ENTRIES.size() - 1) {
            return null;
        }
        cursor++;
        save();
        fire();
        return ENTRIES.get(cursor);
    }

    /**
     * @return a snapshot of the history, oldest first
     */
    public static List<Path> entries() {
        ensureLoaded();
        prune();
        return List.copyOf(ENTRIES);
    }

    /**
     * @return index of the current entry in {@link #entries()}, or -1 if empty
     */
    public static int cursor() {
        ensureLoaded();
        return cursor;
    }

    /**
     * Forgets the whole history, in memory and on disk.
     */
    public static void clear() {
        ensureLoaded();
        ENTRIES.clear();
        cursor = -1;
        save();
        fire();
    }

    /**
     * Registers a callback run whenever the history or its cursor moves.
     *
     * @param listener the callback
     */
    public static void addListener(Runnable listener) {
        if (listener != null) {
            LISTENERS.add(listener);
        }
    }

    // -----------------------------------------------------------------
    // internals
    // -----------------------------------------------------------------

    private static boolean truncateAfterCursor() {
        boolean changed = false;
        while (ENTRIES.size() - 1 > cursor) {
            ENTRIES.remove(ENTRIES.size() - 1);
            changed = true;
        }
        return changed;
    }

    /** Drops entries whose folder has gone, keeping the cursor on the same entry where possible. */
    private static void prune() {
        boolean changed = false;
        for (int i = ENTRIES.size() - 1; i >= 0; i--) {
            if (!FolderPaths.isFolder(ENTRIES.get(i))) {
                ENTRIES.remove(i);
                if (i <= cursor) {
                    cursor--;
                }
                changed = true;
            }
        }
        // Two neighbours can become equal once the entry between them is
        // gone; collapse them so Back never "moves" to the folder already shown.
        for (int i = ENTRIES.size() - 1; i > 0; i--) {
            if (FolderPaths.sameCanonical(ENTRIES.get(i), ENTRIES.get(i - 1))) {
                ENTRIES.remove(i);
                if (i <= cursor) {
                    cursor--;
                }
                changed = true;
            }
        }
        if (ENTRIES.isEmpty()) {
            cursor = -1;
        } else if (cursor < 0) {
            cursor = 0;
        } else if (cursor >= ENTRIES.size()) {
            cursor = ENTRIES.size() - 1;
        }
        if (changed) {
            save();
        }
    }

    private static void ensureLoaded() {
        if (loaded) {
            return;
        }
        loaded = true;
        String stored = PREFS.get(KEY_ENTRIES, "");
        if (!stored.isBlank()) {
            for (String raw : stored.split("\\" + SEP)) {
                if (raw.isBlank()) {
                    continue;
                }
                try {
                    // Stored canonical, but canonicalise again in case a drive
                    // alias was added or removed since the last session.
                    ENTRIES.add(FolderPaths.canonical(Path.of(raw)));
                } catch (InvalidPathException ignored) {
                    // A malformed stored entry is skipped rather than fatal.
                }
            }
        }
        while (ENTRIES.size() > MAX_ENTRIES) {
            ENTRIES.remove(0);
        }
        cursor = Math.min(PREFS.getInt(KEY_CURSOR, ENTRIES.size() - 1), ENTRIES.size() - 1);
        prune();
    }

    private static void save() {
        StringBuilder joined = new StringBuilder();
        for (Path p : ENTRIES) {
            if (joined.length() > 0) {
                joined.append(SEP);
            }
            joined.append(p);
        }
        // Preferences caps a value at 8192 characters. Twenty long paths fit;
        // if they ever do not, keep the newest ones.
        String value = joined.toString();
        while (value.length() > Preferences.MAX_VALUE_LENGTH && value.contains(SEP)) {
            value = value.substring(value.indexOf(SEP) + 1);
        }
        PREFS.put(KEY_ENTRIES, value);
        PREFS.putInt(KEY_CURSOR, cursor);
        try {
            PREFS.flush();
        } catch (BackingStoreException ignored) {
            // The history still holds for this session.
        }
    }

    private static void fire() {
        for (Runnable listener : LISTENERS) {
            try {
                listener.run();
            } catch (RuntimeException e) {
                e.printStackTrace();
            }
        }
    }
}
