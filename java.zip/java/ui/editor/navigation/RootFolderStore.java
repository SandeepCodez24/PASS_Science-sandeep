package ui.editor.navigation;

import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;

/**
 * The root folder the user has declared with the Root button's
 * "Set current folder as root".
 *
 * <p>
 * This is the root now. The older meaning -- "the project folder that was
 * active when a file was last run" -- is still recorded by
 * {@code HomeFilesProject.rememberRunRoot} and is used only as the fallback
 * when nothing has been declared. Both the Root button and Open &gt; Open Root
 * Folder go through {@code EditorFileOpener.openRootFolder}, which applies that
 * order.
 * </p>
 *
 * <p>
 * The declaration survives restarts. A declared folder that has since been
 * deleted or disconnected reads back as "none declared" but is not forgotten,
 * so reconnecting a drive brings it back.
 * </p>
 */
public final class RootFolderStore {

    private static final Preferences PREFS = Preferences.userRoot().node("astra/root_folder");
    private static final String KEY_DECLARED = "declaredRoot";

    private static final List<Runnable> LISTENERS = new CopyOnWriteArrayList<>();

    private RootFolderStore() {
    }

    /**
     * @return the declared root if one is set and it exists right now,
     *         otherwise null
     */
    public static Path declared() {
        Path stored = stored();
        return FolderPaths.isFolder(stored) ? stored : null;
    }

    /**
     * @return the declared root as stored, whether or not it exists right now,
     *         or null if none has been declared
     */
    public static Path stored() {
        String raw = PREFS.get(KEY_DECLARED, null);
        if (raw == null || raw.isBlank()) {
            return null;
        }
        try {
            return Path.of(raw);
        } catch (InvalidPathException e) {
            return null;
        }
    }

    /**
     * @return true if a root has been declared, even if it is unreachable now
     */
    public static boolean isDeclared() {
        return stored() != null;
    }

    /**
     * Declares a folder as the root.
     *
     * @param folder the folder; ignored if null or not a folder
     * @return true if the declaration was stored
     */
    public static boolean declare(Path folder) {
        if (!FolderPaths.isFolder(folder)) {
            return false;
        }
        PREFS.put(KEY_DECLARED, FolderPaths.canonical(folder).toString());
        flush();
        fire();
        return true;
    }

    /**
     * Forgets the declared root.
     */
    public static void clear() {
        PREFS.remove(KEY_DECLARED);
        flush();
        fire();
    }

    /**
     * Registers a callback run whenever the declaration changes.
     *
     * @param listener the callback
     */
    public static void addListener(Runnable listener) {
        if (listener != null) {
            LISTENERS.add(listener);
        }
    }

    private static void flush() {
        try {
            PREFS.flush();
        } catch (BackingStoreException ignored) {
            // The value still holds for this session.
        }
    }

    private static void fire() {
        for (Runnable listener : LISTENERS) {
            try {
                listener.run();
            } catch (RuntimeException e) {
                e.printStackTrace();
            }
        }
    }
}
