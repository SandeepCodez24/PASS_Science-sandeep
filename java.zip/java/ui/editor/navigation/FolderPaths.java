package ui.editor.navigation;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import ui.ui_functions.tools.DriveAliases;

/**
 * One way of writing a folder path, used by everything that compares,
 * remembers or displays one.
 *
 * <p>
 * The navigation code compares paths constantly -- "is the breadcrumb already
 * showing the folder history would take us to?", "is this run folder the same
 * as the last one?" -- and those comparisons are only meaningful if both sides
 * went through the same clean-up. {@code D:\My Research Works},
 * {@code C:\D-Drive\D\My Research Works} and {@code d:\my research works\.}
 * are one folder; {@link #canonical(Path)} turns all three into the first.
 * </p>
 */
public final class FolderPaths {

    /** {@code %NAME%} environment references, as typed in Windows paths. */
    private static final Pattern ENV_REF = Pattern.compile("%([^%\\\\/]+)%");

    private FolderPaths() {
    }

    /**
     * Absolute, normalised, resolved through links and junctions, and written
     * with the drive letter the user knows the folder by.
     *
     * <p>
     * {@code toRealPath} runs first so every route to a folder collapses to one
     * physical path, then {@link DriveAliases#preferred} puts the alias letter
     * back. A folder that cannot be resolved (deleted, disconnected share)
     * falls back to its plain absolute form.
     * </p>
     *
     * @param path any path; may be null
     * @return the canonical path, or null if the input was null
     */
    public static Path canonical(Path path) {
        if (path == null) {
            return null;
        }

        Path absolute;
        try {
            absolute = path.toAbsolutePath().normalize();
        } catch (RuntimeException e) {
            return path;
        }

        Path physical;
        try {
            physical = absolute.toRealPath();
        } catch (IOException | RuntimeException e) {
            physical = absolute;
        }

        return DriveAliases.preferred(physical);
    }

    /**
     * @param path a path; may be null
     * @return true if it names a folder that exists right now
     */
    public static boolean isFolder(Path path) {
        if (path == null) {
            return false;
        }
        try {
            return Files.isDirectory(path);
        } catch (RuntimeException e) {
            return false;
        }
    }

    /**
     * Compares two folders after canonicalising both.
     *
     * @param a first folder; may be null
     * @param b second folder; may be null
     * @return true if both are non-null and name the same folder
     */
    public static boolean same(Path a, Path b) {
        if (a == null || b == null) {
            return false;
        }
        Path ca = canonical(a);
        Path cb = canonical(b);
        if (ca.equals(cb)) {
            return true;
        }
        // Windows paths are case-insensitive; Path.equals already honours that
        // on the default Windows filesystem, but be explicit for safety.
        return ca.toString().toLowerCase(Locale.ROOT).equals(cb.toString().toLowerCase(Locale.ROOT));
    }

    /**
     * Compares two paths that are <em>already</em> canonical, without touching
     * the disk. For hot paths such as the navigation history, whose entries
     * are stored canonical and are compared on every breadcrumb redraw.
     *
     * @param a first canonical path; may be null
     * @param b second canonical path; may be null
     * @return true if both are non-null and equal, ignoring case
     */
    public static boolean sameCanonical(Path a, Path b) {
        if (a == null || b == null) {
            return false;
        }
        return a.equals(b)
                || a.toString().toLowerCase(Locale.ROOT).equals(b.toString().toLowerCase(Locale.ROOT));
    }

    /**
     * The text for a breadcrumb crumb or a menu entry: the folder's own name,
     * or, for a drive root, the root without its trailing separator
     * ({@code D:\} reads as {@code D:}).
     *
     * @param path the folder
     * @return the label, never null
     */
    public static String label(Path path) {
        if (path == null) {
            return "";
        }
        Path name = path.getFileName();
        if (name != null) {
            return name.toString();
        }
        String raw = path.toString();
        if (raw.length() > 1 && (raw.endsWith("\\") || raw.endsWith("/"))) {
            raw = raw.substring(0, raw.length() - 1);
        }
        return raw;
    }

    /**
     * Turns what the user typed or pasted into the breadcrumb into a path.
     *
     * <p>
     * Forgiving about the usual ways a path arrives from the clipboard:
     * surrounding quotes (Explorer's "Copy as path" adds them), stray
     * whitespace, {@code %USERPROFILE%}-style variables, a leading {@code ~},
     * and a path relative to the folder currently shown. It does <em>not</em>
     * check that the result exists; the caller decides what to do about that.
     * </p>
     *
     * @param text the typed text; may be null
     * @param base the folder to resolve a relative path against; may be null
     * @return the parsed absolute path, or null if the text is empty or is not
     *         a legal path at all
     */
    public static Path parseTyped(String text, Path base) {
        if (text == null) {
            return null;
        }
        String cleaned = text.trim();
        while (cleaned.length() >= 2
                && ((cleaned.startsWith("\"") && cleaned.endsWith("\""))
                        || (cleaned.startsWith("'") && cleaned.endsWith("'")))) {
            cleaned = cleaned.substring(1, cleaned.length() - 1).trim();
        }
        if (cleaned.isEmpty()) {
            return null;
        }

        cleaned = expandEnvironment(cleaned);

        if (cleaned.equals("~") || cleaned.startsWith("~\\") || cleaned.startsWith("~/")) {
            cleaned = System.getProperty("user.home") + cleaned.substring(1);
        }

        // "D:" on its own means the root of D, not "the current folder on D".
        if (cleaned.length() == 2 && cleaned.charAt(1) == ':' && Character.isLetter(cleaned.charAt(0))) {
            cleaned = cleaned + "\\";
        }

        try {
            Path typed = Path.of(cleaned);
            if (!typed.isAbsolute()) {
                if (base == null) {
                    return null;
                }
                typed = base.resolve(typed);
            }
            return typed.toAbsolutePath().normalize();
        } catch (InvalidPathException | UnsupportedOperationException e) {
            return null;
        }
    }

    private static String expandEnvironment(String text) {
        Matcher m = ENV_REF.matcher(text);
        StringBuilder out = new StringBuilder();
        while (m.find()) {
            String value = System.getenv(m.group(1));
            m.appendReplacement(out, Matcher.quoteReplacement(value != null ? value : m.group(0)));
        }
        m.appendTail(out);
        return out.toString();
    }
}
