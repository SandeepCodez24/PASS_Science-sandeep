package ui.editor.navigation;

import java.nio.file.Path;

import javafx.scene.control.TreeItem;
import ui.UI_Main;
import ui.cli.CLI_Main;
import ui.editor.homeTab.EditorFileOpener;
import ui.editor.homeTab.HomeFilesProject;

/**
 * What the navigation bar and the breadcrumb actually do. No JavaFX controls
 * live here -- {@code ui.explorer.navigation.NavigationBar} and
 * {@code BreadcrumbBar} build the buttons and call in.
 *
 * <h3>"The folder being shown"</h3>
 * <p>
 * Every action measures from the project tree's root, not from
 * {@code ide.currentFolder}. Opening a file moves {@code currentFolder} to that
 * file's parent (it is the file chooser's start directory), but the tree and
 * the breadcrumb stay put, and Up / Set Root / Back have to agree with what the
 * user can see.
 * </p>
 *
 * <h3>Moving the tree</h3>
 * <p>
 * Every move goes through {@link EditorFileOpener#loadFolderAsProject}, the
 * same path Open Folder uses. That installs the new tree root, redraws the
 * breadcrumb and remembers the folder as the last project, so "Open Last
 * Project" follows browsing as well.
 * </p>
 *
 * <h3>Messages</h3>
 * <p>
 * When a button has nowhere to go it says so in the Command Window rather than
 * doing nothing silently, and repaints the prompt afterwards.
 * </p>
 */
public final class NavigationActions {

    private NavigationActions() {
    }

    // =================================================================
    // Where are we
    // =================================================================

    /**
     * @param ide the IDE controller
     * @return the project tree's root folder, canonicalised, or null if the
     *         tree is empty
     */
    public static Path projectFolder(UI_Main ide) {
        if (ide == null || ide.projectTree == null) {
            return null;
        }
        TreeItem<Path> root = ide.projectTree.getRoot();
        if (root == null || root.getValue() == null) {
            return null;
        }
        return FolderPaths.canonical(root.getValue());
    }

    /**
     * The folder the breadcrumb is showing: the tree root, or failing that the
     * editor's current folder.
     *
     * @param ide the IDE controller
     * @return the folder, canonicalised, or null if there is none
     */
    public static Path shownFolder(UI_Main ide) {
        Path project = projectFolder(ide);
        if (project != null) {
            return project;
        }
        return (ide != null) ? FolderPaths.canonical(ide.currentFolder) : null;
    }

    // =================================================================
    // Moving
    // =================================================================

    /**
     * Shows a folder in the tree and the breadcrumb.
     *
     * @param ide    the IDE controller
     * @param folder the folder to show
     * @return true if the folder exists and was loaded
     */
    public static boolean goTo(UI_Main ide, Path folder) {
        if (ide == null || !FolderPaths.isFolder(folder)) {
            return false;
        }
        EditorFileOpener.loadFolderAsProject(ide, FolderPaths.canonical(folder));
        return true;
    }

    /**
     * Home: always {@code Documents\NeuralCode}, created if missing.
     *
     * @param ide the IDE controller
     */
    public static void goHome(UI_Main ide) {
        Path home = DefaultFolders.neuralCodeHome();
        if (!goTo(ide, home)) {
            say("Home folder is not available: " + home);
        }
    }

    /**
     * Back: the previous folder a file was run in.
     *
     * @param ide the IDE controller
     */
    public static void goBack(UI_Main ide) {
        Path target = FolderHistory.back(shownFolder(ide));
        if (target == null) {
            say("No earlier run folder to go back to.");
            return;
        }
        goTo(ide, target);
    }

    /**
     * Forward: the next folder a file was run in, after stepping back.
     *
     * @param ide the IDE controller
     */
    public static void goForward(UI_Main ide) {
        Path target = FolderHistory.forward();
        if (target == null) {
            say("No later run folder to go forward to.");
            return;
        }
        goTo(ide, target);
    }

    /**
     * Up: one level above the folder being shown.
     *
     * @param ide the IDE controller
     */
    public static void goUp(UI_Main ide) {
        Path shown = shownFolder(ide);
        Path parent = (shown != null) ? shown.getParent() : null;
        if (parent == null) {
            say(shown == null ? "No folder is open." : "Already at the top of " + FolderPaths.label(shown) + ".");
            return;
        }
        goTo(ide, parent);
    }

    /**
     * Root button click: the declared root, falling back to the last run root.
     * Shares its logic with Open &gt; Open Root Folder.
     *
     * @param ide the IDE controller
     */
    public static void goToRoot(UI_Main ide) {
        EditorFileOpener.openRootFolder(ide);
    }

    /**
     * Declares the folder being shown as the root.
     *
     * @param ide the IDE controller
     */
    public static void declareShownAsRoot(UI_Main ide) {
        Path shown = shownFolder(ide);
        if (shown == null || !RootFolderStore.declare(shown)) {
            say("No folder to set as root.");
            return;
        }
        say("Root folder set: " + shown);
    }

    /**
     * Forgets the declared root.
     *
     * @param ide the IDE controller
     */
    public static void clearRoot(UI_Main ide) {
        if (!RootFolderStore.isDeclared()) {
            say("No root folder is set.");
            return;
        }
        RootFolderStore.clear();
        Path fallback = HomeFilesProject.runRoot();
        say(fallback != null
                ? "Root folder cleared. Open Root Folder now uses the last run folder: " + fallback
                : "Root folder cleared.");
    }

    // =================================================================
    // State for the buttons
    // =================================================================

    /**
     * @param ide the IDE controller
     * @return true if Back has somewhere to go
     */
    public static boolean canGoBack(UI_Main ide) {
        return FolderHistory.canGoBack(shownFolder(ide));
    }

    /**
     * @return true if Forward has somewhere to go
     */
    public static boolean canGoForward() {
        return FolderHistory.canGoForward();
    }

    /**
     * @param ide the IDE controller
     * @return true if the folder being shown has a parent
     */
    public static boolean canGoUp(UI_Main ide) {
        Path shown = shownFolder(ide);
        return shown != null && shown.getParent() != null;
    }

    // =================================================================
    // Runs
    // =================================================================

    /**
     * Records a run: adds the project folder to the Back/Forward history and
     * stores it as the fallback root. Called by {@code EditorFileRunner} once a
     * run is actually going ahead, so a file that fails its error check moves
     * neither.
     *
     * @param ide        the IDE controller
     * @param fileFolder the running file's own folder, used only when the tree
     *                   has no root
     */
    public static void recordRun(UI_Main ide, Path fileFolder) {
        Path folder = projectFolder(ide);
        if (folder == null) {
            folder = FolderPaths.canonical(fileFolder);
        }
        if (!FolderPaths.isFolder(folder)) {
            return;
        }
        HomeFilesProject.rememberRunRoot(folder);
        FolderHistory.recordRun(folder);
    }

    // =================================================================
    // Messages
    // =================================================================

    /**
     * Prints a one-line note to the Command Window and repaints the prompt.
     *
     * @param message the note, without a trailing newline
     */
    public static void say(String message) {
        CLI_Main.appendOutput(message + "\n");
        CLI_Main.appendPrompt();
    }
}
