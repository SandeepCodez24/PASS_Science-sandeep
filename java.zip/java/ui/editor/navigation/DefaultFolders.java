package ui.editor.navigation;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The fixed places the IDE knows about: the user's Documents folder and the
 * {@code Documents\NeuralCode} folder the Home button always goes to.
 *
 * <h3>Why Documents is looked up rather than assumed</h3>
 * <p>
 * {@code user.home + "\\Documents"} is right on a fresh Windows profile and
 * wrong on any machine where OneDrive "folder backup" is on: there Windows
 * moves Documents to {@code %USERPROFILE%\OneDrive - <Company>\Documents} and
 * the old folder is left empty or missing. Explorer follows the move because it
 * reads the shell-folder registry key; this class reads the same key.
 * </p>
 *
 * <h3>Which NeuralCode wins</h3>
 * <ol>
 * <li>{@code NeuralCode} inside the Documents folder Windows reports, if it
 * exists.</li>
 * <li>{@code NeuralCode} inside {@code user.home\Documents}, if it exists --
 * so a machine that already has a NeuralCode folder there keeps using it even
 * if Documents has since been redirected.</li>
 * <li>Otherwise a new {@code NeuralCode} (no space) is created inside the
 * Documents folder Windows reports.</li>
 * </ol>
 * <p>
 * Both lookups are cached for the session; the registry is read once.
 * </p>
 */
public final class DefaultFolders {

    /** The folder name the Home button goes to. No space, by decision. */
    public static final String NEURAL_CODE_FOLDER = "NeuralCode";

    private static final String SHELL_FOLDERS_KEY =
            "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\User Shell Folders";

    /** The registry value Windows uses for Documents. Its name is historical. */
    private static final String DOCUMENTS_VALUE = "Personal";

    private static final Pattern REG_LINE =
            Pattern.compile("^\\s*" + DOCUMENTS_VALUE + "\\s+REG_(?:EXPAND_)?SZ\\s+(.+?)\\s*$");

    private static final Pattern ENV_REF = Pattern.compile("%([^%]+)%");

    private static volatile Path documents;

    private DefaultFolders() {
    }

    /**
     * @return the user's Documents folder as Windows reports it, falling back
     *         to {@code user.home\Documents}, then to {@code user.home}
     */
    public static Path documents() {
        Path cached = documents;
        if (cached != null) {
            return cached;
        }
        synchronized (DefaultFolders.class) {
            if (documents == null) {
                documents = resolveDocuments();
            }
            return documents;
        }
    }

    /**
     * The Home button's target: {@code Documents\NeuralCode}, created if it is
     * missing.
     *
     * @return the folder; never null. If it cannot be created, the Documents
     *         folder itself is returned so Home still goes somewhere sensible.
     */
    public static Path neuralCodeHome() {
        Path known = documents().resolve(NEURAL_CODE_FOLDER);
        if (Files.isDirectory(known)) {
            return known;
        }

        Path legacy = homeDocuments().resolve(NEURAL_CODE_FOLDER);
        if (Files.isDirectory(legacy)) {
            return legacy;
        }

        try {
            Files.createDirectories(known);
            System.out.println("Created NeuralCode directory: " + known);
            return known;
        } catch (Exception e) {
            System.err.println("Could not create " + known + ": " + e.getMessage());
            return FolderPaths.isFolder(documents()) ? documents() : Path.of(System.getProperty("user.home"));
        }
    }

    // -----------------------------------------------------------------
    // internals
    // -----------------------------------------------------------------

    private static Path homeDocuments() {
        return Path.of(System.getProperty("user.home"), "Documents");
    }

    private static Path resolveDocuments() {
        Path fromRegistry = isWindows() ? readRegistryDocuments() : null;
        if (fromRegistry != null && Files.isDirectory(fromRegistry)) {
            return fromRegistry;
        }
        Path home = homeDocuments();
        if (Files.isDirectory(home)) {
            return home;
        }
        return Path.of(System.getProperty("user.home"));
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
    }

    /**
     * Asks {@code reg.exe} for the Documents shell folder. A short-lived child
     * process rather than JNA, because the project has no native-access
     * dependency and this runs once per session.
     */
    private static Path readRegistryDocuments() {
        Process process = null;
        try {
            process = new ProcessBuilder("reg", "query", SHELL_FOLDERS_KEY, "/v", DOCUMENTS_VALUE)
                    .redirectErrorStream(true)
                    .start();

            String found = null;
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream(), Charset.defaultCharset()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    Matcher m = REG_LINE.matcher(line);
                    if (m.matches()) {
                        found = m.group(1);
                    }
                }
            }

            if (!process.waitFor(3, TimeUnit.SECONDS) || found == null || found.isBlank()) {
                return null;
            }
            return Path.of(expand(found)).toAbsolutePath().normalize();
        } catch (Exception e) {
            return null;
        } finally {
            if (process != null && process.isAlive()) {
                process.destroyForcibly();
            }
        }
    }

    private static String expand(String value) {
        Matcher m = ENV_REF.matcher(value);
        StringBuilder out = new StringBuilder();
        while (m.find()) {
            String env = System.getenv(m.group(1));
            m.appendReplacement(out, Matcher.quoteReplacement(env != null ? env : m.group(0)));
        }
        m.appendTail(out);
        return out.toString();
    }
}
