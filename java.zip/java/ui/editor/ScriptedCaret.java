package ui.editor;

import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.regex.Matcher;

import org.fxmisc.richtext.GenericStyledArea;
import org.fxmisc.richtext.SelectionImpl;
import org.fxmisc.richtext.model.TwoDimensional.Bias;

import javafx.application.Platform;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import language.semantic.ScriptedName;
import language.syntax.UPITokenMaker;

/**
 * How the caret and the editing keys treat a name with a subscript or a
 * superscript ({@code F_$4}, {@code μ_$i_@2}), in the editor and the Command
 * Window alike.
 *
 * <h3>One unit from outside, editable from inside</h3>
 * <p>
 * The document holds {@code F_$4_@2}; the screen shows F with a lowered 4 and
 * a raised 2 (the markers {@code _$} / {@code _@} are drawn with no width,
 * {@link UPITokenMaker#MARKER_CLASS}). The script -- everything from the first
 * marker to the end of the name -- behaves like one piece, as an equation does
 * in a word processor:
 * </p>
 * <pre>
 *   F_$4_@2|  = x       outside, at the end of the name
 *     Backspace         deletes the whole script:      F|  = x
 *     ←                 steps inside (caret does not move; a thin box
 *                       appears around the part being edited)
 *
 *   F|_$4_@2  = x       outside, at the end of the base
 *     Delete            deletes the whole script:      F|  = x
 *     →                 steps inside, before the 4
 *
 *   inside a part       ← / → move one character, and from one part to the
 *                       other; past either end they leave the script
 *                       Backspace / Delete remove one character; removing a
 *                       part's last character removes its marker too, so no
 *                       bare _$ is ever left behind
 *                       typing goes into the part; Esc, → at the end, a
 *                       space or an operator leave it
 * </pre>
 * <p>
 * A letter or digit typed just after a name goes into its script -- the
 * language has no closing marker, so it cannot sit on the baseline there --
 * and the box shows it.
 * </p>
 *
 * <h3>Nothing is ever joined into a script</h3>
 * <p>
 * {@code F_$4 = unit_matrix(6)} must never become {@code F_$4unit_matrix(6)}
 * by deleting what stands between them: that is one name whose subscript is
 * {@code 4unit_matrix}. Any deletion that would put a name character directly
 * after the end of a scripted name -- Backspace, Delete, Ctrl+Backspace,
 * Ctrl+Delete, deleting or cutting a selection -- is refused; a single
 * Backspace / Delete steps over the character instead.
 * </p>
 *
 * <h3>Reads what is drawn</h3>
 * <p>
 * A name counts only when its marker is drawn hidden -- the highlighter gave
 * it {@link UPITokenMaker#MARKER_CLASS}, which it does only for a valid name
 * outside a string. So the keys always agree with what the user sees: a
 * marker shown as typed ({@code A_$} with nothing after it, a name inside a
 * string, an interpreter output line in the Command Window) is plain text.
 * </p>
 */
public final class ScriptedCaret {

    /** Set in an area's properties while this class is moving its caret. */
    private static final Object MOVING = new Object();

    /** Area property: true while the caret, at the very end of a name, is inside its script. */
    private static final Object INSIDE_AT_END = new Object();

    /** Area property: the box drawn around the part being edited. */
    private static final Object BOX = new Object();

    /** Area property: a box update is queued. */
    private static final Object BOX_QUEUED = new Object();

    /** Area property: a character was just typed (the caret move that follows is typing). */
    private static final Object TYPING = new Object();

    /** The box: a thin outline over a faint fill, the same in both themes. */
    private static final Color BOX_STROKE = Color.web("#2F80ED");
    private static final Color BOX_FILL = Color.web("#2F80ED", 0.12);

    private ScriptedCaret() {
    }

    // =====================================================================
    // Installing
    // =====================================================================

    /**
     * For the editor: the caret listener (a caret placed inside a hidden
     * marker by a click or Home/End moves into the script), typing and the
     * box. The editing keys are handled by {@link #handleKey}, which the
     * editor calls from its own key filter
     * ({@code EditorActions.handleStyledGroupNavigation}).
     *
     * @param area the text area
     */
    public static void install(GenericStyledArea<?, ?, ?> area) {
        if (area == null) {
            return;
        }
        installCommon(area, true);
    }

    /**
     * For the Command Window: the editing keys, typing and the box, but no
     * caret correction -- output moves the console's caret all the time, and
     * its own scrolling code ({@code ConsoleArea}, {@code ConsoleViewport})
     * must stay the only thing reacting to that.
     *
     * @param area the text area
     */
    public static void installKeysOnly(GenericStyledArea<?, ?, ?> area) {
        if (area == null) {
            return;
        }
        area.addEventFilter(KeyEvent.KEY_PRESSED, e -> handleKey(area, e));
        installCommon(area, false);
    }

    /**
     * Installs everything, keys included, for an area with no key filter of
     * its own calling {@link #handleKey}.
     *
     * @param area the text area
     */
    public static void installWithKeys(GenericStyledArea<?, ?, ?> area) {
        if (area == null) {
            return;
        }
        area.addEventFilter(KeyEvent.KEY_PRESSED, e -> handleKey(area, e));
        installCommon(area, true);
    }

    private static void installCommon(GenericStyledArea<?, ?, ?> area, boolean correctCaret) {
        area.caretPositionProperty().addListener((obs, was, now) -> {
            if (area.getProperties().get(MOVING) != null) {
                return;
            }
            // After the change has finished applying (and the highlighter has
            // restyled): a listener must not move the caret in the middle of
            // a text replacement.
            boolean typing = area.getProperties().remove(TYPING) != null;
            Platform.runLater(() -> {
                if (correctCaret) {
                    snap(area);
                }
                if (typing) {
                    // Typing a script keeps the caret in it, even at the end
                    // of the name; anything else typed there leaves it.
                    setInsideAtEnd(area, typedIntoScript(area));
                } else {
                    // Moved by a click, Home, an arrow over plain text, a
                    // recall: at the end of a name the caret is outside.
                    area.getProperties().remove(INSIDE_AT_END);
                }
                updateBox(area);
            });
        });
        area.addEventFilter(KeyEvent.KEY_TYPED, e -> {
            String typed = e.getCharacter();
            if (typed != null && !typed.isEmpty() && typed.charAt(0) >= 0x20 && !e.isShortcutDown()) {
                area.getProperties().put(TYPING, Boolean.TRUE);
            }
        });
        area.addEventFilter(MouseEvent.MOUSE_PRESSED, e -> area.getProperties().remove(INSIDE_AT_END));
    }

    // =====================================================================
    // Queries
    // =====================================================================

    /**
     * @param area a text area
     * @return true while the caret is inside a script (the box is shown)
     */
    public static boolean isEditingScript(GenericStyledArea<?, ?, ?> area) {
        return area != null && area.getSelection().getLength() == 0
                && partAtCaret(area) != null;
    }

    // =====================================================================
    // Keys
    // =====================================================================

    /**
     * Handles the editing keys at a scripted name (see the class notes).
     * Call from a {@code KEY_PRESSED} event filter: the default caret move and
     * delete happen on key-pressed.
     *
     * @param area  the text area
     * @param event the key event
     * @return true when the key was handled (and consumed)
     */
    public static boolean handleKey(GenericStyledArea<?, ?, ?> area, KeyEvent event) {
        if (area == null || event == null || event.isConsumed() || !area.isEditable()) {
            return false;
        }
        boolean handled = isPlain(event) && area.getSelection().getLength() == 0
                ? handlePlainKey(area, event.getCode())
                : refuseJoiningDeletion(area, event);
        if (handled) {
            event.consume();
        }
        queueBoxUpdate(area);
        return handled;
    }

    private static boolean handlePlainKey(GenericStyledArea<?, ?, ?> area, KeyCode code) {
        int pos = area.getCaretPosition();
        Name name = nameAround(area, pos);
        if (name != null) {
            Part part = name.partAt(pos, insideAtEnd(area));
            if (part != null) {
                return keyInside(area, code, name, part, pos);
            }
            if (keyAtName(area, code, name, pos)) {
                return true;
            }
        }
        return keyNearName(area, code, pos);
    }

    /** A key with the caret inside a script part. */
    private static boolean keyInside(GenericStyledArea<?, ?, ?> area, KeyCode code, Name name, Part part, int pos) {
        switch (code) {
            case LEFT -> {
                Part previous = name.previous(part);
                if (pos > part.contentStart()) {
                    moveInside(area, pos - charLengthBefore(area, pos));
                } else if (previous != null) {
                    moveInside(area, previous.end());
                } else {
                    moveOutside(area, name.scriptStart()); // step out, to the left
                }
                return true;
            }
            case RIGHT -> {
                Part next = name.next(part);
                if (pos < part.end()) {
                    moveInside(area, pos + charLengthAt(area, pos));
                } else if (next != null) {
                    moveInside(area, next.contentStart());
                } else {
                    area.getProperties().remove(INSIDE_AT_END); // step out, to the right
                }
                return true;
            }
            case BACK_SPACE -> {
                if (pos > part.contentStart()) {
                    deleteInside(area, name, part, pos - charLengthBefore(area, pos), pos);
                    return true;
                }
                return keyInside(area, KeyCode.LEFT, name, part, pos); // nothing of the part before it
            }
            case DELETE -> {
                if (pos < part.end()) {
                    deleteInside(area, name, part, pos, pos + charLengthAt(area, pos));
                    return true;
                }
                if (name.next(part) != null) {
                    return true; // the next part's marker: never deleted on its own
                }
                return keyNearName(area, code, pos); // after the name: whatever follows it
            }
            case ESCAPE -> {
                moveOutside(area, name.end());
                return true;
            }
            default -> {
                return false;
            }
        }
    }

    /** A key with the caret outside a script, at the end of the base or of the name. */
    private static boolean keyAtName(GenericStyledArea<?, ?, ?> area, KeyCode code, Name name, int pos) {
        boolean atEnd = pos == name.end();
        boolean atScript = pos == name.scriptStart();
        return switch (code) {
            case LEFT -> {
                if (atEnd) {
                    area.getProperties().put(INSIDE_AT_END, Boolean.TRUE); // step in
                }
                yield atEnd;
            }
            case RIGHT -> {
                if (atScript) {
                    moveInside(area, name.parts().get(0).contentStart()); // step in
                }
                yield atScript;
            }
            case BACK_SPACE -> {
                if (atEnd) {
                    deleteScript(area, name);
                }
                yield atEnd;
            }
            case DELETE -> {
                if (atScript) {
                    deleteScript(area, name);
                }
                yield atScript;
            }
            default -> false;
        };
    }

    /** Backspace / Delete anywhere else: refused when it would join a name into a script. */
    private static boolean keyNearName(GenericStyledArea<?, ?, ?> area, KeyCode code, int pos) {
        if (code == KeyCode.BACK_SPACE && pos > 0) {
            int from = pos - charLengthBefore(area, pos);
            if (wouldJoin(area, from, pos)) {
                moveOutside(area, from); // step over instead
                return true;
            }
        } else if (code == KeyCode.DELETE && pos < area.getLength()) {
            int to = pos + charLengthAt(area, pos);
            if (wouldJoin(area, pos, to)) {
                moveOutside(area, to); // step over instead
                return true;
            }
        }
        return false;
    }

    /**
     * A deletion with a selection or a modifier (Ctrl+Backspace,
     * Ctrl+Delete, Ctrl+X, Shift+Delete) that would join something into a
     * script is refused.
     */
    private static boolean refuseJoiningDeletion(GenericStyledArea<?, ?, ?> area, KeyEvent event) {
        KeyCode code = event.getCode();
        boolean cut = (code == KeyCode.X && event.isShortcutDown())
                || (code == KeyCode.DELETE && event.isShiftDown());
        if (code != KeyCode.BACK_SPACE && code != KeyCode.DELETE && !cut) {
            return false;
        }
        int from;
        int to;
        if (area.getSelection().getLength() > 0) {
            from = area.getSelection().getStart();
            to = area.getSelection().getEnd();
        } else if (cut) {
            return false; // nothing to cut
        } else if (event.isShortcutDown() || event.isAltDown()) {
            int pos = area.getCaretPosition();
            if (code == KeyCode.BACK_SPACE) {
                from = wordBoundary(area, pos, false);
                to = pos;
            } else {
                from = pos;
                to = wordBoundary(area, pos, true);
            }
        } else {
            return false;
        }
        return from < to && wouldJoin(area, from, to);
    }

    // =====================================================================
    // Edits
    // =====================================================================

    /**
     * Removes a whole script: {@code F_$4_@2} becomes {@code F}. Nothing can
     * be joined by it: whatever follows the name is not a name character, or
     * it would belong to the name.
     */
    private static void deleteScript(GenericStyledArea<?, ?, ?> area, Name name) {
        delete(area, name.scriptStart(), name.end());
        moveOutside(area, name.scriptStart());
    }

    /**
     * Deletes {@code from..to} inside a part. When that is all the part has
     * left, its marker goes too.
     */
    private static void deleteInside(GenericStyledArea<?, ?, ?> area, Name name, Part part, int from, int to) {
        if (from <= part.contentStart() && to >= part.end()) {
            boolean last = name.next(part) == null;
            Part previous = name.previous(part);
            delete(area, part.markerStart(), part.end());
            if (previous != null && last) {
                // F_$4_@2 -> F_$4: still editing, now the subscript.
                moveInside(area, part.markerStart());
            } else {
                moveOutside(area, part.markerStart());
            }
            return;
        }
        delete(area, from, to);
        moveInside(area, from);
    }

    /** Deletes text as this class's own edit: the caret listener leaves it alone. */
    private static void delete(GenericStyledArea<?, ?, ?> area, int from, int to) {
        area.getProperties().put(MOVING, Boolean.TRUE);
        try {
            area.deleteText(from, to);
        } finally {
            area.getProperties().remove(MOVING);
        }
    }

    /**
     * True when deleting {@code from..to} would leave a name character
     * directly after a script, extending it: the deletion starts in a script
     * or at the end of its name, runs to the end of the name or past it, and
     * a name character comes after it ({@code F_$4 = unit} losing
     * {@code " = "}, or a selection {@code "4 = u"}).
     */
    private static boolean wouldJoin(GenericStyledArea<?, ?, ?> area, int from, int to) {
        if (from <= 0 || to >= area.getLength()) {
            return false;
        }
        if (!ScriptedName.isNameChar(codePointAt(area, to))) {
            return false;
        }
        Name name = nameAround(area, from);
        return name != null && from >= name.parts().get(0).contentStart()
                && from <= name.end() && to >= name.end();
    }

    // =====================================================================
    // The box
    // =====================================================================

    private static void queueBoxUpdate(GenericStyledArea<?, ?, ?> area) {
        if (area.getProperties().get(BOX_QUEUED) != null) {
            return;
        }
        area.getProperties().put(BOX_QUEUED, Boolean.TRUE);
        Platform.runLater(() -> {
            area.getProperties().remove(BOX_QUEUED);
            updateBox(area);
        });
    }

    /**
     * Draws the box around the part the caret is in, or hides it, and opens
     * the name being edited when its scripts are drawn stacked
     * ({@link ScriptStack}).
     */
    private static void updateBox(GenericStyledArea<?, ?, ?> area) {
        Name name = area.getSelection().getLength() == 0 ? nameAround(area, area.getCaretPosition()) : null;
        Part part = null;
        int editedName = -1;
        if (name != null) {
            part = name.partAt(area.getCaretPosition(), insideAtEnd(area));
            if (part != null) {
                editedName = name.start();
            }
        }
        ScriptStack.caretInName(area, editedName);
        SelectionImpl<?, ?, ?> box = box(area);
        if (part == null) {
            box.selectRange(0, 0);
        } else {
            box.selectRange(part.contentStart(), part.end());
        }
    }

    private static SelectionImpl<?, ?, ?> box(GenericStyledArea<?, ?, ?> area) {
        Object box = area.getProperties().get(BOX);
        if (box instanceof SelectionImpl<?, ?, ?> existing) {
            return existing;
        }
        SelectionImpl<?, ?, ?> created = createBox(area);
        area.getProperties().put(BOX, created);
        return created;
    }

    private static <P, S, T> SelectionImpl<P, S, T> createBox(GenericStyledArea<P, S, T> area) {
        SelectionImpl<P, S, T> box = new SelectionImpl<>("script-edit", area, path -> {
            path.setStroke(BOX_STROKE);
            path.setStrokeWidth(1);
            path.setHighlightFill(BOX_FILL);
        });
        area.addSelection(box);
        return box;
    }

    /**
     * True after typing when the character just typed went into a script and
     * the caret is at the end of the name -- writing {@code F_$45}, or a
     * letter typed just after {@code F_$4}, which the language puts into the
     * subscript.
     */
    private static boolean typedIntoScript(GenericStyledArea<?, ?, ?> area) {
        int pos = area.getCaretPosition();
        Name name = nameAround(area, pos);
        return name != null && pos == name.end() && pos > name.parts().get(0).contentStart();
    }

    private static void setInsideAtEnd(GenericStyledArea<?, ?, ?> area, boolean inside) {
        if (inside) {
            area.getProperties().put(INSIDE_AT_END, Boolean.TRUE);
        } else {
            area.getProperties().remove(INSIDE_AT_END);
        }
    }

    // =====================================================================
    // Caret moves
    // =====================================================================

    /** Moves a caret that sits inside a hidden marker into the script. */
    private static void snap(GenericStyledArea<?, ?, ?> area) {
        if (area.getSelection().getLength() != 0) {
            return;
        }
        int caret = area.getCaretPosition();
        if (caret > 0 && caret < area.getLength() && isHidden(area, caret - 1)) {
            Name name = nameAround(area, caret);
            if (name != null) {
                for (Part part : name.parts()) {
                    if (caret > part.markerStart() && caret < part.contentStart()) {
                        moveInside(area, part.contentStart());
                        return;
                    }
                }
            }
        }
    }

    private static boolean insideAtEnd(GenericStyledArea<?, ?, ?> area) {
        return area.getProperties().get(INSIDE_AT_END) != null;
    }

    private static Part partAtCaret(GenericStyledArea<?, ?, ?> area) {
        int pos = area.getCaretPosition();
        Name name = nameAround(area, pos);
        return name == null ? null : name.partAt(pos, insideAtEnd(area));
    }

    /** Moves the caret to a place inside a script (the end of a name counts as inside). */
    private static void moveInside(GenericStyledArea<?, ?, ?> area, int position) {
        moveTo(area, position);
        area.getProperties().put(INSIDE_AT_END, Boolean.TRUE);
    }

    /** Moves the caret to a place outside every script. */
    private static void moveOutside(GenericStyledArea<?, ?, ?> area, int position) {
        moveTo(area, position);
        area.getProperties().remove(INSIDE_AT_END);
    }

    private static void moveTo(GenericStyledArea<?, ?, ?> area, int position) {
        area.getProperties().put(MOVING, Boolean.TRUE);
        try {
            area.moveTo(Math.max(0, Math.min(position, area.getLength())));
            area.requestFollowCaret();
        } finally {
            area.getProperties().remove(MOVING);
        }
    }

    // =====================================================================
    // Finding the name at a position
    // =====================================================================

    /**
     * One part of a script, in document offsets.
     *
     * @param markerStart  where its {@code _$} / {@code _@} starts
     * @param contentStart where its own text starts
     * @param end          one past its last character
     */
    private record Part(int markerStart, int contentStart, int end) {
    }

    /**
     * A drawn scripted name, in document offsets.
     *
     * @param start       its first character
     * @param scriptStart where its first marker starts (the end of the base)
     * @param end         one past its last character
     * @param parts       its script parts, in written order
     */
    private record Name(int start, int scriptStart, int end, List<Part> parts) {

        /**
         * The part a caret at {@code pos} is in, or null when it is outside.
         * The end of one part is inside it (typing there extends it); the end
         * of the name is inside only when the caret stepped in.
         */
        Part partAt(int pos, boolean insideAtEnd) {
            if (pos == end && !insideAtEnd) {
                return null;
            }
            for (Part part : parts) {
                if (pos >= part.contentStart() && pos <= part.end()) {
                    return part;
                }
            }
            return null;
        }

        Part previous(Part part) {
            int i = parts.indexOf(part);
            return i > 0 ? parts.get(i - 1) : null;
        }

        Part next(Part part) {
            int i = parts.indexOf(part);
            return i >= 0 && i + 1 < parts.size() ? parts.get(i + 1) : null;
        }
    }

    /**
     * The drawn scripted name that {@code pos} lies in or at either end of;
     * null when there is none (no name, an invalid one, or one shown as
     * typed).
     */
    private static Name nameAround(GenericStyledArea<?, ?, ?> area, int pos) {
        if (pos < 0 || pos > area.getLength()) {
            return null;
        }
        int paragraph = area.offsetToPosition(pos, Bias.Forward).getMajor();
        String line = area.getParagraph(paragraph).getText();
        if (!ScriptedName.hasScripts(line)) {
            return null;
        }
        int lineStart = area.getAbsolutePosition(paragraph, 0);
        int column = pos - lineStart;
        Matcher m = ScriptedName.SCRIPTED_NAME.matcher(line);
        while (m.find()) {
            if (m.start() > column) {
                break;
            }
            if (column > m.end()) {
                continue;
            }
            ScriptedName.Parsed parsed = ScriptedName.parse(m.group());
            if (!parsed.isValid() || parsed.parts().size() < 2) {
                return null;
            }
            List<Part> parts = new ArrayList<>(parsed.parts().size() - 1);
            int base = lineStart + m.start();
            for (ScriptedName.Part p : parsed.parts()) {
                if (p.kind() != ScriptedName.Kind.BASE) {
                    parts.add(new Part(base + p.markerStart(), base + p.contentStart(), base + p.end()));
                }
            }
            // Only a name the highlighter drew as scripted counts.
            if (!isHidden(area, parts.get(0).markerStart())) {
                return null;
            }
            return new Name(base, parts.get(0).markerStart(), base + m.end() - m.start(), parts);
        }
        return null;
    }

    /** True when the character at {@code index} is drawn hidden (a marker). */
    static boolean isHidden(GenericStyledArea<?, ?, ?> area, int index) {
        if (index < 0 || index >= area.getLength()) {
            return false;
        }
        Object style = area.getStyleOfChar(index);
        return style instanceof Collection<?> classes && classes.contains(UPITokenMaker.MARKER_CLASS);
    }

    // =====================================================================
    // Characters
    // =====================================================================

    private static boolean isPlain(KeyEvent event) {
        return !event.isShiftDown() && !event.isControlDown() && !event.isAltDown()
                && !event.isMetaDown() && !event.isShortcutDown();
    }

    /** The previous (or next) word boundary on the caret's line, as Ctrl+Backspace / Ctrl+Delete use. */
    private static int wordBoundary(GenericStyledArea<?, ?, ?> area, int pos, boolean forward) {
        int paragraph = area.getCurrentParagraph();
        String line = area.getParagraph(paragraph).getText();
        int lineStart = area.getAbsolutePosition(paragraph, 0);
        int column = Math.max(0, Math.min(pos - lineStart, line.length()));
        // At either end of the line the word key takes the line break.
        if (forward && column >= line.length()) {
            return Math.min(area.getLength(), pos + 1);
        }
        if (!forward && column == 0) {
            return Math.max(0, pos - 1);
        }
        BreakIterator words = BreakIterator.getWordInstance();
        words.setText(line);
        int boundary = forward ? words.following(column) : words.preceding(column);
        if (boundary == BreakIterator.DONE) {
            boundary = forward ? line.length() : 0;
        }
        return lineStart + boundary;
    }

    private static int codePointAt(GenericStyledArea<?, ?, ?> area, int index) {
        String two = area.getText(index, Math.min(area.getLength(), index + 2));
        return two.isEmpty() ? -1 : two.codePointAt(0);
    }

    /** UTF-16 length of the character starting at {@code index}. */
    private static int charLengthAt(GenericStyledArea<?, ?, ?> area, int index) {
        if (index + 1 < area.getLength()) {
            String two = area.getText(index, index + 2);
            if (Character.isHighSurrogate(two.charAt(0)) && Character.isLowSurrogate(two.charAt(1))) {
                return 2;
            }
        }
        return 1;
    }

    /** UTF-16 length of the character ending just before {@code index}. */
    private static int charLengthBefore(GenericStyledArea<?, ?, ?> area, int index) {
        if (index >= 2) {
            String two = area.getText(index - 2, index);
            if (Character.isHighSurrogate(two.charAt(0)) && Character.isLowSurrogate(two.charAt(1))) {
                return 2;
            }
        }
        return 1;
    }
}
