package ui.editor;

import org.fxmisc.richtext.CodeArea;

import javafx.application.Platform;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Tab;
import javafx.scene.control.TextArea;
import ui.UI_Main;

/**
 * Undo and redo for the ribbon's action cluster.
 *
 * <h3>Why this is not one line</h3>
 * <p>
 * There is no single undo stack in this application. Every tab owns its own,
 * and the two tab kinds expose it through different APIs: {@code .nc} tabs
 * hold a {@link CodeArea} (RichTextFX, backed by an {@code UndoManager}),
 * plain-text tabs hold a {@link TextArea} (JavaFX, backed by its own internal
 * stack). So "undo" means "undo in whichever control the <i>currently
 * selected</i> tab happens to hold", and the button's enabled state has to
 * follow the selection as well as the edits.
 * </p>
 *
 * <h3>Build order (this is what the first version got wrong)</h3>
 * <p>
 * {@code ToolbarSetup.setupToolbars} runs from inside
 * {@code Main_Window.buildUI}, and whether {@code ide.editorTabs} has been
 * assigned by that point depends on the order of the calls in that method. The
 * first version of {@code bind} opened with
 * </p>
 *
 * <pre>
 *   if (ide == null || ide.editorTabs == null) return;
 * </pre>
 *
 * <p>
 * which meant that if the ribbon happened to be built first, the two buttons
 * silently left that method with <b>no action handler at all</b> and stayed
 * dead for the life of the process. Nothing logged, nothing threw.
 * </p>
 * <p>
 * The handlers are now attached unconditionally -- they resolve the active tab
 * at click time anyway, so they never needed the tab pane to exist yet. Only
 * the greying-out listeners do, and those retry on the FX pulse until the tab
 * pane appears, then give up quietly and leave both buttons enabled. A button
 * that is wrongly enabled does nothing when pressed; a button that is wrongly
 * disabled cannot be pressed at all, so that is the safer way to fail.
 * </p>
 *
 * <h3>What this deliberately does not do</h3>
 * <p>
 * It does not touch the tab's {@code *} modified marker. Undoing back to the
 * last saved state leaves the asterisk in place, as it did before -- that
 * marker is set by a text listener in {@code EditorTabFactory} and is
 * append-only. Making it accurate needs a saved-state snapshot per tab, which
 * is a separate change.
 * </p>
 */
public final class EditorUndoRedo {

    /** Marks an editor whose text listener is already installed. */
    private static final String LISTENER_KEY = "astra.undoRedo.listenerInstalled";

    /**
     * How many FX pulses to wait for {@code ide.editorTabs} before giving up on
     * the disabled-state bindings. Twenty is far more than the one or two the
     * remainder of {@code buildUI} actually needs, and bounds the retry so a
     * genuinely absent tab pane cannot spin forever.
     */
    private static final int MAX_BIND_ATTEMPTS = 20;

    private EditorUndoRedo() {
    }

    /* =====================================================================
     * ACTIONS
     * ===================================================================== */

    /**
     * Undoes the last edit in the active tab's editor.
     *
     * @param ide the IDE controller
     */
    public static void undo(UI_Main ide) {
        Node editor = activeEditor(ide);
        if (editor instanceof CodeArea codeArea) {
            codeArea.undo();
            codeArea.requestFocus();
        } else if (editor instanceof TextArea textArea) {
            textArea.undo();
            textArea.requestFocus();
        }
    }

    /**
     * Redoes the last undone edit in the active tab's editor.
     *
     * @param ide the IDE controller
     */
    public static void redo(UI_Main ide) {
        Node editor = activeEditor(ide);
        if (editor instanceof CodeArea codeArea) {
            codeArea.redo();
            codeArea.requestFocus();
        } else if (editor instanceof TextArea textArea) {
            textArea.redo();
            textArea.requestFocus();
        }
    }

    /* =====================================================================
     * AVAILABILITY
     * ===================================================================== */

    /**
     * @param ide the IDE controller
     * @return true if the active editor has something to undo
     */
    public static boolean isUndoAvailable(UI_Main ide) {
        Node editor = activeEditor(ide);
        if (editor instanceof CodeArea codeArea) {
            return codeArea.getUndoManager().isUndoAvailable();
        }
        if (editor instanceof TextArea textArea) {
            return textArea.isUndoable();
        }
        return false;
    }

    /**
     * @param ide the IDE controller
     * @return true if the active editor has something to redo
     */
    public static boolean isRedoAvailable(UI_Main ide) {
        Node editor = activeEditor(ide);
        if (editor instanceof CodeArea codeArea) {
            return codeArea.getUndoManager().isRedoAvailable();
        }
        if (editor instanceof TextArea textArea) {
            return textArea.isRedoable();
        }
        return false;
    }

    /* =====================================================================
     * BUTTON BINDING
     * ===================================================================== */

    /**
     * Wires two ribbon buttons to the active tab, and keeps them greyed out
     * when their action would do nothing.
     *
     * <p>
     * Safe to call before the editor tab pane exists; see the class notes.
     * </p>
     *
     * @param ide  the IDE controller
     * @param undo the Undo button
     * @param redo the Redo button
     */
    public static void bind(UI_Main ide, Button undo, Button redo) {
        if (ide == null || undo == null || redo == null) {
            return;
        }

        // Attached first and unconditionally. These look the active tab up on
        // every click, so they work whether or not the tab pane exists yet.
        undo.setOnAction(e -> {
            undo(ide);
            refresh(ide, undo, redo);
        });
        redo.setOnAction(e -> {
            redo(ide);
            refresh(ide, undo, redo);
        });

        installListeners(ide, undo, redo, 0);
    }

    /**
     * Installs the selection and text listeners once the tab pane is there,
     * retrying on the FX thread until it is.
     *
     * @param ide     the IDE controller
     * @param undo    the Undo button
     * @param redo    the Redo button
     * @param attempt how many pulses have already been spent waiting
     */
    private static void installListeners(UI_Main ide, Button undo, Button redo, int attempt) {
        if (ide.editorTabs == null) {
            if (attempt < MAX_BIND_ATTEMPTS) {
                Platform.runLater(() -> installListeners(ide, undo, redo, attempt + 1));
            } else {
                // Give up, but leave the buttons usable rather than stuck off.
                undo.setDisable(false);
                redo.setDisable(false);
                System.err.println("EditorUndoRedo: editorTabs never appeared; "
                        + "undo/redo still work, but will not grey out.");
            }
            return;
        }

        ide.editorTabs.getSelectionModel().selectedItemProperty()
                .addListener((obs, was, now) -> {
                    attachTextListener(now, () -> refresh(ide, undo, redo));
                    refresh(ide, undo, redo);
                });

        // A tab may already be selected by the time we get here.
        attachTextListener(ide.editorTabs.getSelectionModel().getSelectedItem(),
                () -> refresh(ide, undo, redo));

        refresh(ide, undo, redo);
    }

    private static void refresh(UI_Main ide, Button undo, Button redo) {
        undo.setDisable(!isUndoAvailable(ide));
        redo.setDisable(!isRedoAvailable(ide));
    }

    /* =====================================================================
     * INTERNALS
     * ===================================================================== */

    /**
     * @param ide the IDE controller
     * @return the active tab's {@code CodeArea} or {@code TextArea}, or null
     */
    private static Node activeEditor(UI_Main ide) {
        if (ide == null || ide.editorTabs == null) {
            return null;
        }
        Tab tab = ide.editorTabs.getSelectionModel().getSelectedItem();
        return EditorTextOperations.findEditor(tab);
    }

    /**
     * Installs a one-per-editor text listener that refreshes the buttons.
     *
     * @param tab    the tab whose editor should report edits, may be null
     * @param onEdit what to run when its text changes
     */
    private static void attachTextListener(Tab tab, Runnable onEdit) {
        Node editor = EditorTextOperations.findEditor(tab);
        if (editor == null || editor.getProperties().containsKey(LISTENER_KEY)) {
            return;
        }
        editor.getProperties().put(LISTENER_KEY, Boolean.TRUE);

        if (editor instanceof CodeArea codeArea) {
            codeArea.textProperty().addListener((obs, was, now) -> onEdit.run());
        } else if (editor instanceof TextArea textArea) {
            textArea.textProperty().addListener((obs, was, now) -> onEdit.run());
        }
    }
}
