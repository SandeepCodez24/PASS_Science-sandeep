package ui.editor.search;

import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import language.replace.Greek;
import language.replace.Malayalam;
import language.replace.Sanskrit;
import language.replace.Subscript;
import language.replace.Superscript;
import language.replace.Tamil;
import language.replace.Telugu;
import language.replace.Uniconstant;

/**
 * What the search needs to know about Neural Code text that a plain string
 * search does not.
 *
 * <h3>1. A letter is not always one {@code char}</h3>
 * <p>
 * கா is க followed by the vowel sign ா; क्ष is क, the virama ्, and ष. A plain
 * {@code indexOf("க")} finds the க inside கா, and replacing it leaves a vowel
 * sign with no letter under it -- text the semantic encoder cannot map.
 * {@link Letters#isBoundary(int)} says where a letter really starts and ends,
 * and every match must begin and end on such a boundary.
 * </p>
 *
 * <h3>2. The virama joins letters in most Indic scripts, but not in Tamil</h3>
 * <p>
 * In Devanagari, Telugu, Malayalam and their neighbours, consonant + virama +
 * consonant is drawn as one conjunct, so the point after the virama is not a
 * boundary. Tamil's pulli (்) is a visible mark and க் is a complete letter of
 * its own ({@code \var(\tamil(\ik))}), so after it IS a boundary.
 * </p>
 *
 * <h3>3. Sub- and superscripts are marked with invisible characters</h3>
 * <p>
 * {@link Subscript#styledSubscript} writes ZWJ c ZWJ for a one-letter
 * subscript and ZWJ&times;3 ... ZWJ&times;3 for a group; superscripts do the
 * same with ZWNJ. {@link Markers} finds those groups so a replacement can never
 * cut one open or put something inside one that the encoder would not
 * produce.
 * </p>
 *
 * <h3>4. {@code \var(...)} is typed, the glyph is stored</h3>
 * <p>
 * The editor turns {@code \var(\mu)} into μ as it is typed, and the saved file
 * holds μ. {@link #toGlyphs(String)} does the same for the search fields, from
 * the very maps in {@code language.replace}, so both spellings find the same
 * variable and a replacement is always written as the glyph.
 * </p>
 */
public final class NcText {

    /** Subscript marker (see {@link Subscript}). */
    public static final char SUB = '\u200D';

    /** Superscript marker (see {@link Superscript}). */
    public static final char SUP = '\u200C';

    /**
     * The typed form -&gt; glyph maps, in the order
     * {@code SymbolReplacer.replaceSymbols} applies them, so the search field
     * converts exactly as the editor does.
     */
    private static final List<Map<String, String>> SYMBOL_MAPS = List.of(
            Greek.SYMBOL_MAP,
            Tamil.TAMIL_VOWEL_MAP,
            Tamil.TAMIL_CONSONANT_MAP,
            Sanskrit.SYMBOL_MAP,
            Malayalam.MALAYALAM_VOWEL_MAP,
            Malayalam.MALAYALAM_CONSONANT_MAP,
            Telugu.TELUGU_VOWEL_MAP,
            Telugu.TELUGU_CONSONANT_MAP,
            Uniconstant.SYMBOL_MAP);

    private NcText() {
    }

    // =====================================================================
    // Typed form -> glyph
    // =====================================================================

    /**
     * Replaces every complete {@code \var(...)} / {@code \con(...)} form with
     * its glyph. Text without a backslash is returned unchanged at once.
     *
     * @param text the text as typed
     * @return the text as the editor would store it
     */
    public static String toGlyphs(String text) {
        if (text == null || text.indexOf('\\') < 0) {
            return text;
        }
        String out = text;
        for (Map<String, String> map : SYMBOL_MAPS) {
            for (Map.Entry<String, String> e : map.entrySet()) {
                if (out.contains(e.getKey())) {
                    out = out.replace(e.getKey(), e.getValue());
                }
            }
        }
        return out;
    }

    // =====================================================================
    // Character classes
    // =====================================================================

    /**
     * @param c a char
     * @return true for the sub- or superscript marker
     */
    public static boolean isMarker(char c) {
        return c == SUB || c == SUP;
    }

    /**
     * @param cp a code point
     * @return true for a combining mark: vowel signs, virama, nukta, anusvara
     */
    public static boolean isMark(int cp) {
        int type = Character.getType(cp);
        return type == Character.NON_SPACING_MARK
                || type == Character.COMBINING_SPACING_MARK
                || type == Character.ENCLOSING_MARK;
    }

    /**
     * A virama that fuses the consonants on either side into one conjunct.
     * Tamil's pulli (U+0BCD) is deliberately absent: it is a visible mark and
     * leaves a complete letter behind it.
     *
     * @param c a char
     * @return true for a joining virama
     */
    public static boolean isJoiningVirama(char c) {
        return switch (c) {
            case '\u094D', // Devanagari (Sanskrit)
                    '\u09CD', // Bengali
                    '\u0A4D', // Gurmukhi
                    '\u0ACD', // Gujarati
                    '\u0B4D', // Oriya
                    '\u0C4D', // Telugu
                    '\u0CCD', // Kannada
                    '\u0D4D' // Malayalam
                    -> true;
            default -> false;
        };
    }

    /**
     * A character that can be part of a Neural Code name: letters and digits
     * of any script with their marks, {@code _}, the sub/superscript digits and
     * letters, the sub/superscript markers, and the {@code ∞} in {@code 𝑹∞}.
     *
     * @param cp a code point
     * @return true if it belongs to an identifier
     */
    public static boolean isIdentifierPart(int cp) {
        if (cp == '_' || cp == SUB || cp == SUP || cp == '\u221E') {
            return true;
        }
        if (Character.isLetterOrDigit(cp) || isMark(cp)) {
            return true;
        }
        int type = Character.getType(cp);
        return type == Character.OTHER_NUMBER // ₀ ¹ ²
                || type == Character.LETTER_NUMBER
                || type == Character.MODIFIER_LETTER; // ₐ ₑ ⁿ
    }

    // =====================================================================
    // Letter boundaries
    // =====================================================================

    /**
     * Answers "does a letter start here?" for one piece of text. Build one per
     * text and reuse it for every match in that text.
     */
    public static final class Letters {

        private final String text;
        private final BreakIterator breaks;

        /**
         * @param text the text to judge
         */
        public Letters(String text) {
            this.text = text;
            this.breaks = BreakIterator.getCharacterInstance();
            this.breaks.setText(text);
        }

        /**
         * @param pos an offset in the text, 0 to length inclusive
         * @return true if a match may begin or end at {@code pos}
         */
        public boolean isBoundary(int pos) {
            int len = text.length();
            if (pos <= 0 || pos >= len) {
                return pos == 0 || pos == len;
            }
            char here = text.charAt(pos);
            char before = text.charAt(pos - 1);

            // Never inside a surrogate pair (𝝅, 𝑹 ...).
            if (Character.isLowSurrogate(here) && Character.isHighSurrogate(before)) {
                return false;
            }
            // The sub/superscript markers are Astra's own separators: the
            // letter beside one is complete. Checked before the grapheme rule,
            // which would glue a ZWJ to the letter before it.
            if (isMarker(here) || isMarker(before)) {
                return true;
            }
            // After a joining virama the next consonant is part of a conjunct.
            if (isJoiningVirama(before)) {
                return false;
            }
            // A vowel sign, virama or other mark belongs to the letter before.
            if (isMark(text.codePointAt(pos))) {
                return false;
            }
            return breaks.isBoundary(pos);
        }
    }

    // =====================================================================
    // Sub / superscript marker groups
    // =====================================================================

    /**
     * One marked sub- or superscript: its markers and the letters between.
     *
     * @param open         index of the first opening marker
     * @param contentStart index of the first letter inside
     * @param contentEnd   index just past the last letter inside
     * @param close        index just past the last closing marker
     * @param multi        true for a ZWJ&times;3 group, false for a single
     * @param marker       {@link #SUB} or {@link #SUP}
     */
    public record Group(int open, int contentStart, int contentEnd, int close, boolean multi, char marker) {

        /** @return true for a subscript */
        public boolean isSubscript() {
            return marker == SUB;
        }
    }

    /** Where a match sits relative to the marked groups. */
    public enum Placement {
        /** Plain text, touching no group. */
        OUTSIDE,
        /** Entirely inside one group's letters. */
        INSIDE,
        /** Covers one or more whole groups, markers included. */
        WHOLE_GROUPS,
        /** Cuts a group open. */
        STRADDLES
    }

    /** The marked groups of one text, found once and asked many times. */
    public static final class Markers {

        private final List<Group> groups;

        /**
         * @param text the text to parse
         */
        public Markers(String text) {
            List<Group> found = new ArrayList<>();
            parse(text, SUB, found);
            parse(text, SUP, found);
            found.sort((a, b) -> Integer.compare(a.open(), b.open()));
            this.groups = Collections.unmodifiableList(found);
        }

        /** @return every group, in text order */
        public List<Group> groups() {
            return groups;
        }

        /**
         * @param start match start
         * @param end   match end (exclusive)
         * @return the group a match lies inside, or null
         */
        public Group enclosing(int start, int end) {
            for (Group g : groups) {
                if (g.open() >= end) {
                    break;
                }
                if (start >= g.contentStart() && end <= g.contentEnd()) {
                    return g;
                }
            }
            return null;
        }

        /**
         * @param start match start
         * @param end   match end (exclusive)
         * @return where the match sits
         */
        public Placement place(int start, int end) {
            boolean touched = false;
            for (Group g : groups) {
                if (g.open() >= end) {
                    break;
                }
                if (g.close() <= start) {
                    continue;
                }
                // The group overlaps the match.
                if (start >= g.contentStart() && end <= g.contentEnd()) {
                    return Placement.INSIDE;
                }
                if (start <= g.open() && end >= g.close()) {
                    touched = true;
                    continue;
                }
                return Placement.STRADDLES;
            }
            return touched ? Placement.WHOLE_GROUPS : Placement.OUTSIDE;
        }

        /**
         * Finds the groups of one marker kind. See {@link Subscript}: a single
         * group is marker, one letter, marker; a multi group opens and closes
         * with three markers. A run of four is a multi close followed by a
         * single open, which is why the closing run consumes exactly three.
         */
        private static void parse(String text, char m, List<Group> out) {
            int n = text.length();
            int i = 0;
            while (i < n) {
                if (text.charAt(i) != m) {
                    i++;
                    continue;
                }
                int run = runLength(text, i, m);
                if (run >= 3) {
                    int contentStart = i + 3;
                    int j = contentStart;
                    int contentEnd = n;
                    int close = n;
                    while (j < n) {
                        if (text.charAt(j) == m) {
                            int r = runLength(text, j, m);
                            if (r >= 3) {
                                contentEnd = j;
                                close = j + 3;
                                break;
                            }
                            j += r;
                        } else {
                            j++;
                        }
                    }
                    out.add(new Group(i, contentStart, contentEnd, close, true, m));
                    i = close;
                } else {
                    int contentStart = i + 1;
                    if (contentStart < n && text.charAt(contentStart) != m) {
                        int contentEnd = contentStart + Character.charCount(text.codePointAt(contentStart));
                        if (contentEnd < n && text.charAt(contentEnd) == m) {
                            out.add(new Group(i, contentStart, contentEnd, contentEnd + 1, false, m));
                            i = contentEnd + 1;
                            continue;
                        }
                    }
                    // A stray marker: step over it.
                    i++;
                }
            }
        }

        private static int runLength(String text, int from, char m) {
            int j = from;
            while (j < text.length() && text.charAt(j) == m) {
                j++;
            }
            return j - from;
        }
    }

    /**
     * @param text any text
     * @return true if every marker in it belongs to a complete group
     */
    public static boolean markersBalanced(String text) {
        int markers = 0;
        for (int i = 0; i < text.length(); i++) {
            if (isMarker(text.charAt(i))) {
                markers++;
            }
        }
        if (markers == 0) {
            return true;
        }
        int inGroups = 0;
        for (Group g : new Markers(text).groups()) {
            if (g.contentEnd() == text.length() && g.close() == text.length() && g.multi()) {
                return false; // unterminated
            }
            inGroups += (g.contentStart() - g.open()) + (g.close() - g.contentEnd());
        }
        return inGroups == markers;
    }

    /**
     * Rewrites a replacement that will sit inside a marked group the way the
     * editor itself writes that group's letters: digits become the Unicode
     * sub/superscript digits in a multi group (see
     * {@link Subscript#styledSubscriptText}).
     *
     * @param replacement the replacement
     * @param group       the group it goes into
     * @return the adapted text, or null if it cannot go into that group
     */
    public static String adaptForGroup(String replacement, Group group) {
        if (replacement.isEmpty()) {
            return null; // would leave an empty, malformed group
        }
        int count = replacement.codePointCount(0, replacement.length());
        if (!group.multi()) {
            // A single group holds exactly one letter; digits are never
            // written this way (they use the Unicode digit forms instead).
            if (count != 1) {
                return null;
            }
            int cp = replacement.codePointAt(0);
            return Character.isLetter(cp) ? replacement : null;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < replacement.length();) {
            int cp = replacement.codePointAt(i);
            i += Character.charCount(cp);
            if (cp >= '0' && cp <= '9') {
                char d = (char) cp;
                sb.append(group.isSubscript() ? Subscript.numericSubscript(d) : Superscript.unicode(d));
            } else if (Character.isLetterOrDigit(cp) || Character.getType(cp) == Character.OTHER_NUMBER) {
                sb.appendCodePoint(cp);
            } else {
                return null;
            }
        }
        return sb.toString();
    }
}
