package ui.editor.search;

import java.text.BreakIterator;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import language.replace.Greek;
import language.replace.Malayalam;
import language.replace.Sanskrit;
import language.replace.Tamil;
import language.replace.Telugu;
import language.replace.Uniconstant;

/**
 * What the search needs to know about Neural Code text that a plain string
 * search does not.
 *
 * <h3>1. A letter is not always one {@code char}</h3>
 * <p>
 * கா is க followed by the vowel sign ா; क्ष is क, the virama ्, and ष. A plain
 * {@code indexOf("க")} finds the க inside கா, and replacing it leaves a vowel
 * sign with no letter under it -- text the semantic encoder cannot map.
 * {@link Letters#isBoundary(int)} says where a letter really starts and ends,
 * and every match must begin and end on such a boundary.
 * </p>
 *
 * <h3>2. The virama joins letters in most Indic scripts, but not in Tamil</h3>
 * <p>
 * In Devanagari, Telugu, Malayalam and their neighbours, consonant + virama +
 * consonant is drawn as one conjunct, so the point after the virama is not a
 * boundary. Tamil's pulli (்) is a visible mark and க் is a complete letter of
 * its own ({@code \var(\tamil(\ik))}), so after it IS a boundary.
 * </p>
 *
 * <h3>3. Sub- and superscripts are ordinary text</h3>
 * <p>
 * A subscript is written {@code A_$1} and a superscript {@code A_@2}, and the
 * document holds exactly those characters (the editor only hides {@code _$}
 * when drawing). So a search finds them as typed, {@code $} and {@code @}
 * count as name characters for Whole Word, and
 * {@link SearchEngine#judge} refuses a replacement that would cut a
 * {@code _$} / {@code _@} marker in half. The old hidden-marker groups
 * (zero-width joiners) are gone; {@link Markers} is kept for its callers and
 * now never finds a group, and a zero-width joiner is once more just part of
 * a Malayalam or Sanskrit letter.
 * </p>
 *
 * <h3>4. {@code \var(...)} is typed, the glyph is stored</h3>
 * <p>
 * The editor turns {@code \var(\mu)} into μ as it is typed, and the saved file
 * holds μ. {@link #toGlyphs(String)} does the same for the search fields, from
 * the very maps in {@code language.replace}, so both spellings find the same
 * variable and a replacement is always written as the glyph.
 * </p>
 */
public final class NcText {

    /** @deprecated the old hidden subscript marker; subscripts are written {@code A_$1}. */
    @Deprecated
    public static final char SUB = '\u200D';

    /** @deprecated the old hidden superscript marker; superscripts are written {@code A_@2}. */
    @Deprecated
    public static final char SUP = '\u200C';

    /**
     * The typed form -&gt; glyph maps, in the order
     * {@code SymbolReplacer.replaceSymbols} applies them, so the search field
     * converts exactly as the editor does.
     */
    private static final List<Map<String, String>> SYMBOL_MAPS = List.of(
            Greek.SYMBOL_MAP,
            Tamil.TAMIL_VOWEL_MAP,
            Tamil.TAMIL_CONSONANT_MAP,
            Sanskrit.SYMBOL_MAP,
            Malayalam.MALAYALAM_VOWEL_MAP,
            Malayalam.MALAYALAM_CONSONANT_MAP,
            Telugu.TELUGU_VOWEL_MAP,
            Telugu.TELUGU_CONSONANT_MAP,
            Uniconstant.SYMBOL_MAP);

    private NcText() {
    }

    // =====================================================================
    // Typed form -> glyph
    // =====================================================================

    /**
     * Replaces every complete {@code \var(...)} / {@code \con(...)} form with
     * its glyph. Text without a backslash is returned unchanged at once.
     *
     * @param text the text as typed
     * @return the text as the editor would store it
     */
    public static String toGlyphs(String text) {
        if (text == null || text.indexOf('\\') < 0) {
            return text;
        }
        String out = text;
        for (Map<String, String> map : SYMBOL_MAPS) {
            for (Map.Entry<String, String> e : map.entrySet()) {
                if (out.contains(e.getKey())) {
                    out = out.replace(e.getKey(), e.getValue());
                }
            }
        }
        return out;
    }

    // =====================================================================
    // Character classes
    // =====================================================================

    /**
     * @param c a char
     * @return always false: there are no hidden marker characters any more
     * @deprecated subscripts are written {@code A_$1}, as visible text
     */
    @Deprecated
    public static boolean isMarker(char c) {
        return false;
    }

    /**
     * @param cp a code point
     * @return true for a combining mark: vowel signs, virama, nukta, anusvara
     */
    public static boolean isMark(int cp) {
        int type = Character.getType(cp);
        return type == Character.NON_SPACING_MARK
                || type == Character.COMBINING_SPACING_MARK
                || type == Character.ENCLOSING_MARK;
    }

    /**
     * A virama that fuses the consonants on either side into one conjunct.
     * Tamil's pulli (U+0BCD) is deliberately absent: it is a visible mark and
     * leaves a complete letter behind it.
     *
     * @param c a char
     * @return true for a joining virama
     */
    public static boolean isJoiningVirama(char c) {
        return switch (c) {
            case '\u094D', // Devanagari (Sanskrit)
                    '\u09CD', // Bengali
                    '\u0A4D', // Gurmukhi
                    '\u0ACD', // Gujarati
                    '\u0B4D', // Oriya
                    '\u0C4D', // Telugu
                    '\u0CCD', // Kannada
                    '\u0D4D' // Malayalam
                    -> true;
            default -> false;
        };
    }

    /**
     * A character that can be part of a Neural Code name: letters and digits
     * of any script with their marks, {@code _}, the {@code $} / {@code @} of
     * a subscript / superscript marker ({@code A_$1}), the zero-width joiners
     * of Malayalam and Sanskrit letters, and -- for physical-constant symbols
     * -- the sub/superscript digits and letters and the {@code ∞} in
     * {@code 𝑹∞}.
     *
     * @param cp a code point
     * @return true if it belongs to an identifier
     */
    public static boolean isIdentifierPart(int cp) {
        if (cp == '_' || cp == '$' || cp == '@' || cp == '\u200C' || cp == '\u200D' || cp == '\u221E') {
            return true;
        }
        if (Character.isLetterOrDigit(cp) || isMark(cp)) {
            return true;
        }
        int type = Character.getType(cp);
        return type == Character.OTHER_NUMBER // ₀ ¹ ²
                || type == Character.LETTER_NUMBER
                || type == Character.MODIFIER_LETTER; // ₐ ₑ ⁿ
    }

    // =====================================================================
    // Letter boundaries
    // =====================================================================

    /**
     * Answers "does a letter start here?" for one piece of text. Build one per
     * text and reuse it for every match in that text.
     */
    public static final class Letters {

        private final String text;
        private final BreakIterator breaks;

        /**
         * @param text the text to judge
         */
        public Letters(String text) {
            this.text = text;
            this.breaks = BreakIterator.getCharacterInstance();
            this.breaks.setText(text);
        }

        /**
         * @param pos an offset in the text, 0 to length inclusive
         * @return true if a match may begin or end at {@code pos}
         */
        public boolean isBoundary(int pos) {
            int len = text.length();
            if (pos <= 0 || pos >= len) {
                return pos == 0 || pos == len;
            }
            char here = text.charAt(pos);
            char before = text.charAt(pos - 1);

            // Never inside a surrogate pair (𝝅, 𝑹 ...).
            if (Character.isLowSurrogate(here) && Character.isHighSurrogate(before)) {
                return false;
            }
            // After a joining virama the next consonant is part of a conjunct.
            if (isJoiningVirama(before)) {
                return false;
            }
            // A vowel sign, virama or other mark belongs to the letter before.
            if (isMark(text.codePointAt(pos))) {
                return false;
            }
            return breaks.isBoundary(pos);
        }
    }

    // =====================================================================
    // Sub / superscript marker groups
    // =====================================================================

    /**
     * One marked sub- or superscript of the old hidden-marker design. Kept for
     * its callers; no group is ever found now.
     *
     * @param open         index of the first opening marker
     * @param contentStart index of the first letter inside
     * @param contentEnd   index just past the last letter inside
     * @param close        index just past the last closing marker
     * @param multi        true for a ZWJ&times;3 group, false for a single
     * @param marker       {@link #SUB} or {@link #SUP}
     */
    public record Group(int open, int contentStart, int contentEnd, int close, boolean multi, char marker) {

        /** @return true for a subscript */
        public boolean isSubscript() {
            return marker == SUB;
        }
    }

    /** Where a match sits relative to the marked groups. */
    public enum Placement {
        /** Plain text, touching no group. */
        OUTSIDE,
        /** Entirely inside one group's letters. */
        INSIDE,
        /** Covers one or more whole groups, markers included. */
        WHOLE_GROUPS,
        /** Cuts a group open. */
        STRADDLES
    }

    /** The marked groups of one text, found once and asked many times. */
    public static final class Markers {

        private final List<Group> groups;

        /**
         * @param text the text (no longer parsed: there are no marker groups)
         */
        public Markers(String text) {
            this.groups = Collections.emptyList();
        }

        /** @return every group, in text order */
        public List<Group> groups() {
            return groups;
        }

        /**
         * @param start match start
         * @param end   match end (exclusive)
         * @return the group a match lies inside, or null
         */
        public Group enclosing(int start, int end) {
            for (Group g : groups) {
                if (g.open() >= end) {
                    break;
                }
                if (start >= g.contentStart() && end <= g.contentEnd()) {
                    return g;
                }
            }
            return null;
        }

        /**
         * @param start match start
         * @param end   match end (exclusive)
         * @return where the match sits
         */
        public Placement place(int start, int end) {
            boolean touched = false;
            for (Group g : groups) {
                if (g.open() >= end) {
                    break;
                }
                if (g.close() <= start) {
                    continue;
                }
                // The group overlaps the match.
                if (start >= g.contentStart() && end <= g.contentEnd()) {
                    return Placement.INSIDE;
                }
                if (start <= g.open() && end >= g.close()) {
                    touched = true;
                    continue;
                }
                return Placement.STRADDLES;
            }
            return touched ? Placement.WHOLE_GROUPS : Placement.OUTSIDE;
        }

    }

    /**
     * @param text any text
     * @return true if every marker in it belongs to a complete group
     */
    public static boolean markersBalanced(String text) {
        return true;
    }

    /**
     * Kept for callers of the old hidden-marker groups, which no longer
     * exist.
     *
     * @param replacement the replacement
     * @param group       the group it goes into
     * @return the adapted text, or null if it cannot go into that group
     */
    @Deprecated
    public static String adaptForGroup(String replacement, Group group) {
        return null; // there are no marker groups any more
    }
}
