package ui.editor.search;

import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.image.ImageView;
import javafx.scene.control.Tooltip;
import javafx.scene.input.ContextMenuEvent;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.ScrollEvent;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.util.Duration;
import ui.design.section_dims.Search_dim;
import ui.editor.search.SearchIcons.Icon;

/**
 * The find / replace bar: layout and controls only. What the controls do is
 * {@link EditorSearch}'s business.
 *
 * <pre>
 *   col 0      col 1                  col 2     col 3      col 4
 *   [&gt;]   [ find ........... x ]   [3/15]   [ Find  ]  [&lt;-][-&gt;] [Aa][ab][.*][f{}]  X
 *         [ replace ............ ]            [Replace]  [ Replace All ]
 *         status line ....................................................
 * </pre>
 *
 * <p>
 * The expand toggle and the counter span both rows when Replace is showing,
 * as in the layout drawing. The status line appears only while there is
 * something to say (a regex error, a Replace All summary with its Undo).
 * </p>
 */
public final class SearchBar extends GridPane {

    private final Button expand = new Button();
    private final ImageView expandIcon = SearchIcons.create(Icon.EXPAND_RIGHT, Search_dim.ICON_SIZE);

    private final TextField findField = new TextField();
    private final Button clear = new Button();
    private final StackPane findBox = new StackPane();

    private final TextField replaceField = new TextField();

    private final Label counter = new Label("0/0");

    private final Button find = new Button("Find");
    private final Button replace = new Button("Replace");
    private final Button replaceAll = new Button("Replace All");

    private final Button prev = iconButton(Icon.PREV, "Previous match (Shift+Enter, Shift+F3)");
    private final Button next = iconButton(Icon.NEXT, "Next match (Enter, F3)");

    private final ToggleButton matchCase = toggle(Icon.MATCH_CASE, "Match Case (Alt+M)");
    private final ToggleButton wholeWord = toggle(Icon.WHOLE_WORD, "Whole Word (Alt+W)");
    private final ToggleButton regex = toggle(Icon.REGEX, "Use Regular Expression (Alt+R)");
    private final ToggleButton functionClass = toggle(Icon.FUNCTION_CLASS,
            "Function and Class names only, in the root folder (Alt+F)");

    private final Button close = iconButton(Icon.CLOSE, "Close (Esc)");

    private final HBox tools = new HBox(Search_dim.H_GAP);
    private final Label status = new Label();
    private final Hyperlink undo = new Hyperlink("Undo");
    private final HBox statusRow = new HBox(Search_dim.H_GAP, status, undo);

    private boolean replaceShown = false;

    /** Builds the bar with Replace folded away and Match Case on. */
    public SearchBar() {
        getStyleClass().add("search-bar");
        setHgap(Search_dim.H_GAP);
        setVgap(Search_dim.V_GAP);
        setPadding(new Insets(Search_dim.PADDING));
        setAlignment(Pos.CENTER_LEFT);

        buildExpand();
        buildFindField();
        buildReplaceField();
        buildCounter();
        buildTextButtons();
        buildTools();
        buildStatus();

        ColumnConstraints fieldCol = new ColumnConstraints();
        fieldCol.setHgrow(Priority.SOMETIMES);
        fieldCol.setMinWidth(Search_dim.FIELD_MIN_WIDTH);
        fieldCol.setPrefWidth(Search_dim.FIELD_WIDTH);
        getColumnConstraints().addAll(new ColumnConstraints(), fieldCol);

        add(expand, 0, 0);
        add(findBox, 1, 0);
        add(counter, 2, 0);
        add(find, 3, 0);
        add(tools, 4, 0);

        add(replaceField, 1, 1);
        add(replace, 3, 1);
        add(replaceAll, 4, 1);

        add(statusRow, 1, 2, 4, 1);

        matchCase.setSelected(true); // the IDE's default
        setReplaceShown(false);
        showStatus(null, false, false);

        // Keep the bar's own clicks, wheel turns and right-clicks away from the
        // tab pane and the editor behind it. The fields' own copy/paste menus
        // still open: they handle the event before it bubbles up to here.
        addEventHandler(MouseEvent.MOUSE_PRESSED, MouseEvent::consume);
        addEventHandler(MouseEvent.MOUSE_RELEASED, MouseEvent::consume);
        addEventHandler(MouseEvent.MOUSE_CLICKED, MouseEvent::consume);
        addEventHandler(ScrollEvent.SCROLL, ScrollEvent::consume);
        addEventHandler(ContextMenuEvent.CONTEXT_MENU_REQUESTED, ContextMenuEvent::consume);

        // The bar sits inside the editor's TabPane, whose own key handling
        // selects tabs with the arrow, Home and End keys. A TextField leaves
        // Up, Down and Page Up/Down unconsumed, so without this a Down arrow
        // in the Find field would switch the editor tab. Tab is left alone so
        // focus still moves between the Find and Replace fields.
        addEventHandler(KeyEvent.KEY_PRESSED, e -> {
            if (e.isControlDown() || e.isAltDown() || e.isMetaDown()) {
                return;
            }
            switch (e.getCode()) {
                case UP, DOWN, LEFT, RIGHT, HOME, END, PAGE_UP, PAGE_DOWN -> e.consume();
                default -> {
                    // left to the scene
                }
            }
        });
    }

    // =====================================================================
    // Building
    // =====================================================================

    private void buildExpand() {
        expand.getStyleClass().add("search-expand");
        expand.setGraphic(expandIcon);
        expand.setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        expand.setFocusTraversable(false);
        expand.setMinWidth(Search_dim.EXPAND_WIDTH);
        expand.setPrefWidth(Search_dim.EXPAND_WIDTH);
        expand.setMaxHeight(Double.MAX_VALUE);
        expand.setTooltip(tip("Toggle Replace (Ctrl+H)"));
        GridPane.setVgrow(expand, Priority.ALWAYS);
        GridPane.setValignment(expand, VPos.CENTER);
    }

    private void buildFindField() {
        findField.getStyleClass().add("search-field");
        findField.setPromptText("Find");
        findField.setPrefHeight(Search_dim.ROW_HEIGHT);
        findField.setMinHeight(Search_dim.ROW_HEIGHT);
        // Room on the right for the clear x, so text never runs under it.
        findField.setStyle("-fx-padding: 0 " + Search_dim.CLEAR_RESERVE + " 0 6;");

        clear.getStyleClass().add("search-clear");
        clear.setGraphic(SearchIcons.create(Icon.CLEAR, Search_dim.CLEAR_ICON_SIZE));
        clear.setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        clear.setFocusTraversable(false);
        clear.setTooltip(tip("Clear"));
        clear.visibleProperty().bind(findField.textProperty().isNotEmpty());

        findBox.getChildren().addAll(findField, clear);
        StackPane.setAlignment(clear, Pos.CENTER_RIGHT);
        StackPane.setMargin(clear, new Insets(0, 2, 0, 0));
        findBox.setMinWidth(Search_dim.FIELD_MIN_WIDTH);
        findBox.setPrefWidth(Search_dim.FIELD_WIDTH);
        findBox.setMaxWidth(Double.MAX_VALUE);
    }

    private void buildReplaceField() {
        replaceField.getStyleClass().addAll("search-field", "search-replace-field");
        replaceField.setPromptText("Replace");
        replaceField.setPrefHeight(Search_dim.ROW_HEIGHT);
        replaceField.setMinHeight(Search_dim.ROW_HEIGHT);
        replaceField.setMinWidth(Search_dim.FIELD_MIN_WIDTH);
        replaceField.setPrefWidth(Search_dim.FIELD_WIDTH);
        replaceField.setMaxWidth(Double.MAX_VALUE);
    }

    private void buildCounter() {
        counter.getStyleClass().add("search-counter");
        counter.setMinWidth(Search_dim.COUNTER_MIN_WIDTH);
        counter.setAlignment(Pos.CENTER);
        counter.setMaxHeight(Double.MAX_VALUE);
        GridPane.setHalignment(counter, HPos.CENTER);
        GridPane.setValignment(counter, VPos.CENTER);
    }

    private void buildTextButtons() {
        for (Button b : new Button[] { find, replace, replaceAll }) {
            b.getStyleClass().add("search-text-button");
            b.setMinHeight(Search_dim.ROW_HEIGHT);
            b.setPrefHeight(Search_dim.ROW_HEIGHT);
            b.setMinWidth(Search_dim.TEXT_BUTTON_MIN_WIDTH);
            b.setMaxWidth(Double.MAX_VALUE);
            b.setFocusTraversable(false);
        }
        find.setTooltip(tip("Find (Enter)"));
        replace.setTooltip(tip("Replace this match (Enter in the Replace field)"));
        replaceAll.setTooltip(tip("Replace all matches (Ctrl+Alt+Enter)"));
        GridPane.setHalignment(replaceAll, HPos.LEFT);
    }

    private void buildTools() {
        close.getStyleClass().add("search-close");
        HBox gap = new HBox();
        gap.setMinWidth(Search_dim.H_GAP);
        tools.setAlignment(Pos.CENTER_LEFT);
        tools.getChildren().addAll(prev, next, gap, matchCase, wholeWord, regex, functionClass, close);
        HBox.setMargin(close, new Insets(0, 0, 0, Search_dim.H_GAP * 2));
    }

    private void buildStatus() {
        statusRow.getStyleClass().add("search-status-row");
        statusRow.setAlignment(Pos.CENTER_LEFT);
        status.getStyleClass().add("search-status");
        status.setWrapText(true);
        status.setMaxWidth(Search_dim.FIELD_WIDTH * 2.2);
        undo.getStyleClass().add("search-undo");
        undo.setFocusTraversable(false);
    }

    private static Button iconButton(Icon icon, String tooltip) {
        Button b = new Button();
        b.getStyleClass().add("search-icon-button");
        b.setGraphic(SearchIcons.create(icon, Search_dim.ICON_SIZE));
        b.setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        size(b);
        b.setTooltip(tip(tooltip));
        b.setFocusTraversable(false);
        return b;
    }

    private static ToggleButton toggle(Icon icon, String tooltip) {
        ToggleButton b = new ToggleButton();
        b.getStyleClass().add("search-toggle");
        b.setGraphic(SearchIcons.create(icon, Search_dim.ICON_SIZE));
        b.setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        size(b);
        b.setTooltip(tip(tooltip));
        b.setFocusTraversable(false);
        return b;
    }

    private static void size(javafx.scene.control.ButtonBase b) {
        double s = Search_dim.ICON_BUTTON;
        b.setMinSize(s, s);
        b.setPrefSize(s, s);
        b.setMaxSize(s, s);
    }

    private static Tooltip tip(String text) {
        Tooltip t = new Tooltip(text);
        t.setShowDelay(Duration.millis(400));
        return t;
    }

    // =====================================================================
    // State shown by the bar
    // =====================================================================

    /**
     * Folds or unfolds the Replace row. The arrow turns, and in replace mode
     * the Find field turns light coral and the Replace field pale turquoise.
     *
     * @param shown true to show Replace
     */
    public void setReplaceShown(boolean shown) {
        replaceShown = shown;
        for (javafx.scene.Node n : new javafx.scene.Node[] { replaceField, replace, replaceAll }) {
            n.setVisible(shown);
            n.setManaged(shown);
        }
        GridPane.setRowSpan(expand, shown ? 2 : 1);
        GridPane.setRowSpan(counter, shown ? 2 : 1);
        SearchIcons.set(expandIcon, shown ? Icon.EXPAND_DOWN : Icon.EXPAND_RIGHT);
        toggleClass(findField, "search-find-replacing", shown);
        toggleClass(this, "search-bar-replacing", shown);
        relayoutHost();
    }

    /** @return true while the Replace row shows */
    public boolean isReplaceShown() {
        return replaceShown;
    }

    /**
     * @param text  the counter text
     * @param none  true to show it as "nothing found"
     * @param hint  tooltip, or null
     */
    public void setCounter(String text, boolean none, String hint) {
        counter.setText(text);
        toggleClass(counter, "search-counter-none", none);
        counter.setTooltip(hint == null ? null : tip(hint));
        relayoutHost();
    }

    /**
     * @param error true to draw the Find field as invalid (bad expression)
     */
    public void setFindError(boolean error) {
        toggleClass(findField, "search-field-error", error);
    }

    /**
     * Shows or hides the status line.
     *
     * @param message  the message, or null to hide the line
     * @param warning  true to draw it in the warning colour
     * @param withUndo true to offer the Undo link
     */
    public void showStatus(String message, boolean warning, boolean withUndo) {
        boolean shown = message != null && !message.isEmpty();
        status.setText(shown ? message : "");
        toggleClass(status, "search-status-warning", warning);
        undo.setVisible(shown && withUndo);
        undo.setManaged(shown && withUndo);
        statusRow.setVisible(shown);
        statusRow.setManaged(shown);
        relayoutHost();
    }

    /**
     * Enables Replace and Replace All, with the reason shown as their tooltip
     * when they are off.
     *
     * @param enabled true to enable
     * @param reason  why not, or null
     */
    public void setReplaceEnabled(boolean enabled, String reason) {
        replace.setDisable(!enabled);
        replaceAll.setDisable(!enabled);
        replaceField.setDisable(!enabled);
        String why = enabled ? null : reason;
        replace.setTooltip(tip(why != null ? why : "Replace this match (Enter in the Replace field)"));
        replaceAll.setTooltip(tip(why != null ? why : "Replace all matches (Ctrl+Alt+Enter)"));
    }

    /**
     * @param prompt the Find field's grey hint ("Find" or "Find in root folder")
     */
    public void setFindPrompt(String prompt) {
        findField.setPromptText(prompt);
    }

    /**
     * The bar is an unmanaged child of the editor's tab pane, which sizes and
     * places it. Its own size changes (Replace row, status line, a longer
     * counter) do not reach the tab pane by themselves, so ask it directly.
     */
    private void relayoutHost() {
        if (getParent() != null) {
            getParent().requestLayout();
        }
    }

    private static void toggleClass(javafx.scene.Node node, String cls, boolean on) {
        if (on) {
            if (!node.getStyleClass().contains(cls)) {
                node.getStyleClass().add(cls);
            }
        } else {
            node.getStyleClass().remove(cls);
        }
    }

    // =====================================================================
    // Controls, for EditorSearch
    // =====================================================================

    /** @return the expand toggle */
    public Button expandButton() {
        return expand;
    }

    /** @return the Find field */
    public TextField findField() {
        return findField;
    }

    /** @return the clear x inside the Find field */
    public Button clearButton() {
        return clear;
    }

    /** @return the Replace field */
    public TextField replaceField() {
        return replaceField;
    }

    /** @return the Find button */
    public Button findButton() {
        return find;
    }

    /** @return the Replace button */
    public Button replaceButton() {
        return replace;
    }

    /** @return the Replace All button */
    public Button replaceAllButton() {
        return replaceAll;
    }

    /** @return the previous-match button */
    public Button prevButton() {
        return prev;
    }

    /** @return the next-match button */
    public Button nextButton() {
        return next;
    }

    /** @return Match Case */
    public ToggleButton matchCaseToggle() {
        return matchCase;
    }

    /** @return Whole Word */
    public ToggleButton wholeWordToggle() {
        return wholeWord;
    }

    /** @return Use Regular Expression */
    public ToggleButton regexToggle() {
        return regex;
    }

    /** @return Function &amp; Class */
    public ToggleButton functionClassToggle() {
        return functionClass;
    }

    /** @return the close button */
    public Button closeButton() {
        return close;
    }

    /** @return the Undo link of the status line */
    public Hyperlink undoLink() {
        return undo;
    }
}
