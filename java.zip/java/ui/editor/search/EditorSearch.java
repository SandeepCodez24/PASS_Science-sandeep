package ui.editor.search;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

import org.fxmisc.flowless.VirtualizedScrollPane;
import org.fxmisc.richtext.CodeArea;

import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Tab;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.input.ContextMenuEvent;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.util.Duration;
import language.language_ui.handler.EditorContextMenuManager;
import language.syntax.syntax_checker.ErrorChecker;
import ui.UI_Main;
import ui.design.section_dims.Search_dim;
import ui.editor.EditorFileInfo;
import ui.editor.navigation.RootFolderStore;
import ui.managers.EditorManager;
import ui.managers.ProjectManager;

/**
 * Find and replace for the editor tab: Ctrl+F, Ctrl+H, the editor's
 * right-click menu, and the empty editor area's right-click menu all come
 * here.
 *
 * <h3>Two scopes</h3>
 * <ul>
 * <li><b>This file</b> -- a file is open and Function &amp; Class is off.
 * The search runs as you type, every match is painted, and the arrows step
 * through them.</li>
 * <li><b>Root folder</b> -- no file is open, or Function &amp; Class is on.
 * The {@code .nc} / {@code .txt} files under the root are searched when Enter
 * or Find is pressed (not on every keystroke), and the arrows step through the
 * matches file by file, opening each file as its turn comes. Replace All
 * writes files that are not open straight to disk after a confirmation, with
 * a backup behind the status line's Undo; files that are open are changed in
 * their tab.</li>
 * </ul>
 * <p>
 * The scope is chosen when the bar opens (and whenever Function &amp; Class is
 * switched) and then kept until the bar closes, so stepping through the root
 * folder is not interrupted by the files it opens. Ctrl+F in an open file
 * always brings the search back to that file.
 * </p>
 *
 * <h3>The language's own letters</h3>
 * <p>
 * Both fields accept the typed form ({@code \var(\sanskrit(\a))}) and show it
 * as the glyph, exactly as the editor does. Every replacement is judged by
 * {@link SearchEngine#judge} first; one that would break a letter, a conjunct
 * or a sub/superscript is skipped and reported, never written. After a
 * replacement in a {@code .nc} file, {@link ErrorChecker} is run on the
 * before and after text, and any errors the change added are reported.
 * </p>
 */
public final class EditorSearch {

    private enum Scope {
        EDITOR, ROOT
    }

    private static EditorSearch instance;

    private final UI_Main ide;
    private final EditorTabPane pane;
    private final SearchBar bar = new SearchBar();

    private Scope scope = Scope.EDITOR;
    private SearchEngine.Query query;

    // ---- this-file scope ----
    private Node editor;
    private HitPainter painter;
    private List<SearchEngine.Hit> hits = List.of();
    private int current = -1;
    private final ChangeListener<String> editorTextListener = (obs, o, n) -> scheduleLive(false);
    private final PauseTransition liveDelay = new PauseTransition(
            Duration.millis(Search_dim.LIVE_SEARCH_DELAY_MS));
    private boolean revealOnLive = true;

    // ---- root scope ----
    private final ExecutorService worker = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "astra-search");
        t.setDaemon(true);
        return t;
    });
    private final AtomicInteger generation = new AtomicInteger();
    private Path rootFolder;
    private RootSearch.Result rootResult;
    private boolean rootStale = true;
    private int rootCurrent = -1;
    private boolean navigating = false;

    // ---- undo of the last Replace All ----
    private Runnable pendingUndo;

    private EditorSearch(UI_Main ide, EditorTabPane pane) {
        this.ide = ide;
        this.pane = pane;
        bar.setVisible(false);
        pane.setOverlay(bar);
        wire();
    }

    // =====================================================================
    // Entry points
    // =====================================================================

    /**
     * Installs the search on the editor's tab pane. Called once by
     * {@code Main_Window.setupEditorTabs}.
     *
     * @param ide  the IDE controller
     * @param pane the editor tab pane
     */
    public static void install(UI_Main ide, EditorTabPane pane) {
        if (instance != null) {
            return;
        }
        instance = new EditorSearch(ide, pane);
    }

    /**
     * Opens the bar (Ctrl+F / Ctrl+H, or a right-click menu).
     *
     * @param withReplace true to unfold the Replace row as well
     */
    public static void open(boolean withReplace) {
        if (instance != null) {
            instance.show(withReplace);
        }
    }

    /** Closes the bar. */
    public static void close() {
        if (instance != null) {
            instance.hide();
        }
    }

    /** @return true while the bar is showing */
    public static boolean isOpen() {
        return instance != null && instance.bar.isVisible();
    }

    /** Next match (F3). Opens the bar if it is closed. */
    public static void findNext() {
        if (instance != null) {
            if (!isOpen()) {
                instance.show(false);
            }
            instance.step(+1);
        }
    }

    /** Previous match (Shift+F3). Opens the bar if it is closed. */
    public static void findPrevious() {
        if (instance != null) {
            if (!isOpen()) {
                instance.show(false);
            }
            instance.step(-1);
        }
    }

    // =====================================================================
    // Wiring
    // =====================================================================

    private void wire() {
        liveDelay.setOnFinished(e -> searchEditor(revealOnLive));

        glyphsAsTyped(bar.findField());
        glyphsAsTyped(bar.replaceField());

        bar.findField().textProperty().addListener((obs, o, n) -> queryChanged());
        for (ToggleButton t : new ToggleButton[] { bar.matchCaseToggle(), bar.wholeWordToggle(),
                bar.regexToggle() }) {
            t.selectedProperty().addListener((obs, o, n) -> queryChanged());
        }
        bar.functionClassToggle().selectedProperty().addListener((obs, o, n) -> {
            chooseScope();
            queryChanged();
        });

        bar.expandButton().setOnAction(e -> {
            bar.setReplaceShown(!bar.isReplaceShown());
            if (bar.isReplaceShown()) {
                bar.replaceField().requestFocus();
            }
        });
        bar.clearButton().setOnAction(e -> {
            bar.findField().clear();
            bar.findField().requestFocus();
        });
        bar.findButton().setOnAction(e -> step(+1));
        bar.nextButton().setOnAction(e -> step(+1));
        bar.prevButton().setOnAction(e -> step(-1));
        bar.replaceButton().setOnAction(e -> replaceOne());
        bar.replaceAllButton().setOnAction(e -> replaceAll());
        bar.closeButton().setOnAction(e -> hide());
        bar.undoLink().setOnAction(e -> undoLast());

        bar.addEventFilter(KeyEvent.KEY_PRESSED, this::onKey);

        pane.getSelectionModel().selectedItemProperty().addListener((obs, o, n) -> onTabChanged());
        pane.getTabs().addListener((javafx.collections.ListChangeListener<Tab>) c -> {
            if (isOpen() && pane.getTabs().isEmpty() && scope == Scope.EDITOR) {
                chooseScope();
                queryChanged();
            }
        });

        // Right-click on the empty editor area (no file open).
        pane.addEventHandler(ContextMenuEvent.CONTEXT_MENU_REQUESTED, e -> {
            if (pane.getTabs().isEmpty() && !e.isConsumed()) {
                EditorContextMenuManager.showEmptyAreaMenu(pane, e, () -> open(false));
            }
        });
    }

    /**
     * Turns a completed {@code \var(...)} into its glyph in a search field,
     * the same way the editor does while typing.
     */
    private static void glyphsAsTyped(TextField field) {
        field.textProperty().addListener((obs, o, n) -> {
            String glyphs = NcText.toGlyphs(n);
            if (glyphs != null && !glyphs.equals(n)) {
                Platform.runLater(() -> {
                    if (n.equals(field.getText())) {
                        int fromEnd = n.length() - field.getCaretPosition();
                        field.setText(glyphs);
                        field.positionCaret(Math.max(0, glyphs.length() - fromEnd));
                    }
                });
            }
        });
    }

    private void onKey(KeyEvent e) {
        KeyCode code = e.getCode();
        Object source = e.getTarget();
        boolean inReplace = isWithin(source, bar.replaceField());

        if (code == KeyCode.ESCAPE) {
            hide();
            e.consume();
            return;
        }
        if (code == KeyCode.ENTER) {
            if (e.isControlDown() && e.isAltDown()) {
                replaceAll();
            } else if (inReplace) {
                replaceOne();
            } else {
                step(e.isShiftDown() ? -1 : +1);
            }
            e.consume();
            return;
        }
        if (e.isAltDown() && !e.isControlDown()) {
            ToggleButton t = switch (code) {
                case M -> bar.matchCaseToggle();
                case W -> bar.wholeWordToggle();
                case R -> bar.regexToggle();
                case F -> bar.functionClassToggle();
                default -> null;
            };
            if (t != null) {
                t.setSelected(!t.isSelected());
                e.consume();
            }
        }
    }

    private static boolean isWithin(Object target, Node node) {
        if (!(target instanceof Node n)) {
            return false;
        }
        for (Node p = n; p != null; p = p.getParent()) {
            if (p == node) {
                return true;
            }
        }
        return false;
    }

    // =====================================================================
    // Show / hide
    // =====================================================================

    private void show(boolean withReplace) {
        boolean wasOpen = bar.isVisible();
        bar.setVisible(true);
        pane.requestLayout();

        if (withReplace) {
            bar.setReplaceShown(true);
        } else if (!wasOpen) {
            bar.setReplaceShown(false);
        }

        chooseScope();
        prefillFromSelection();

        TextField field = withReplace && !bar.findField().getText().isEmpty()
                ? bar.replaceField()
                : bar.findField();
        Platform.runLater(() -> {
            field.requestFocus();
            field.selectAll();
        });
        queryChanged();
    }

    private void hide() {
        if (!bar.isVisible()) {
            return;
        }
        generation.incrementAndGet(); // abandon a running root scan
        liveDelay.stop();
        detachEditor();
        bar.setVisible(false);
        bar.showStatus(null, false, false);
        pendingUndo = null;
        rootResult = null;
        rootStale = true;
        // Hand the keyboard back to the editor.
        Node target = activeEditor();
        if (target != null) {
            target.requestFocus();
        }
    }

    /** Puts a one-line editor selection into the Find field, as VS Code does. */
    private void prefillFromSelection() {
        Node ed = activeEditor();
        String selected = null;
        if (ed instanceof CodeArea area) {
            selected = area.getSelectedText();
        } else if (ed instanceof TextArea area) {
            selected = area.getSelectedText();
        }
        if (selected == null || selected.isEmpty() || selected.contains("\n") || selected.length() > 200) {
            return;
        }
        if (bar.regexToggle().isSelected()) {
            selected = selected.replaceAll("[\\\\^$.|?*+()\\[\\]{}]", "\\\\$0");
        }
        bar.findField().setText(selected);
    }

    // =====================================================================
    // Scope
    // =====================================================================

    private void chooseScope() {
        Scope next = bar.functionClassToggle().isSelected() || activeEditor() == null
                ? Scope.ROOT
                : Scope.EDITOR;
        if (next != scope) {
            scope = next;
            rootResult = null;
            rootStale = true;
            rootCurrent = -1;
        }
        if (scope == Scope.ROOT) {
            rootFolder = resolveRoot();
            String name = rootFolder == null ? "root folder"
                    : (rootFolder.getFileName() == null ? rootFolder.toString()
                            : rootFolder.getFileName().toString());
            bar.setFindPrompt(bar.functionClassToggle().isSelected()
                    ? "Functions and classes in " + name
                    : "Find in " + name);
        } else {
            bar.setFindPrompt("Find");
        }
        updateReplaceAvailability();
        attachEditor(activeEditor());
    }

    private void updateReplaceAvailability() {
        if (bar.functionClassToggle().isSelected()) {
            bar.setReplaceEnabled(false,
                    "Renaming only the definition would break every call to it. "
                            + "Turn off Function & Class to replace everywhere.");
        } else {
            bar.setReplaceEnabled(true, null);
        }
    }

    /**
     * The declared root (Root button), else the folder the File Explorer
     * shows, else the editor's current folder.
     */
    private Path resolveRoot() {
        Path declared = RootFolderStore.declared();
        if (declared != null) {
            return declared;
        }
        if (ide.projectTree != null && ide.projectTree.getRoot() != null) {
            Path shown = ide.projectTree.getRoot().getValue();
            if (shown != null && Files.isDirectory(shown)) {
                return shown;
            }
        }
        return ide.currentFolder != null && Files.isDirectory(ide.currentFolder) ? ide.currentFolder : null;
    }

    private void onTabChanged() {
        if (!isOpen() || navigating) {
            return;
        }
        if (scope == Scope.EDITOR) {
            chooseScope();
            queryChanged();
        } else {
            // Root scope: keep stepping state, but paint the matches of
            // whichever file the user switched to.
            attachEditor(activeEditor());
            paintRootFileIfListed();
        }
    }

    // =====================================================================
    // The query
    // =====================================================================

    private SearchEngine.Options options() {
        return new SearchEngine.Options(
                bar.matchCaseToggle().isSelected(),
                bar.wholeWordToggle().isSelected(),
                bar.regexToggle().isSelected(),
                bar.functionClassToggle().isSelected());
    }

    private void queryChanged() {
        if (!isOpen()) {
            return;
        }
        query = SearchEngine.compile(bar.findField().getText(), options());
        bar.setFindError(query.error() != null);
        pendingUndo = null;
        if (query.error() != null) {
            bar.showStatus("Regular expression: " + query.error(), true, false);
        } else {
            bar.showStatus(null, false, false);
        }

        if (scope == Scope.EDITOR) {
            scheduleLive(true);
        } else {
            rootStale = true;
            rootResult = null;
            rootCurrent = -1;
            if (painter != null) {
                painter.clear();
            }
            if (query.isEmpty() || query.error() != null) {
                bar.setCounter("0/0", false, null);
            } else {
                bar.setCounter("\u2014", false, "Press Enter or Find to search "
                        + (rootFolder == null ? "the root folder" : rootFolder.toString()));
            }
        }
    }

    // =====================================================================
    // This-file scope
    // =====================================================================

    private void scheduleLive(boolean reveal) {
        if (!isOpen() || scope != Scope.EDITOR) {
            return;
        }
        revealOnLive = reveal;
        liveDelay.playFromStart();
    }

    /**
     * Searches the open file.
     *
     * @param reveal true to select and scroll to the current match; false when
     *               the user is typing in the editor and must not be disturbed
     */
    private void searchEditor(boolean reveal) {
        if (!isOpen() || scope != Scope.EDITOR || editor == null) {
            return;
        }
        if (query == null || !query.isUsable()) {
            hits = List.of();
            current = -1;
            if (painter != null) {
                painter.clear();
            }
            bar.setCounter("0/0", false, null);
            return;
        }
        String text = textOf(editor);
        int anchor = reveal ? selectionStart(editor) : caretOf(editor);
        hits = SearchEngine.find(text, query);
        current = firstAtOrAfter(hits, anchor);
        if (reveal && current >= 0) {
            select(editor, hits.get(current));
        }
        paintAndCount();
    }

    private void paintAndCount() {
        if (painter != null) {
            painter.paint(hits, current);
        }
        if (hits.isEmpty()) {
            bar.setCounter("0/0", query != null && query.isUsable(), "No matches in this file");
        } else {
            String more = hits.size() >= SearchEngine.MAX_HITS_PER_TEXT ? "+" : "";
            bar.setCounter((current + 1) + "/" + hits.size() + more, false,
                    hits.size() > Search_dim.MAX_PAINTED_HITS
                            ? "The first " + Search_dim.MAX_PAINTED_HITS + " matches are highlighted"
                            : null);
        }
    }

    private void stepEditor(int direction) {
        if (editor == null) {
            return;
        }
        if (hits.isEmpty()) {
            searchEditor(true);
            return;
        }
        // If the user moved the caret since, step from where it is now.
        int[] sel = selectionOf(editor);
        SearchEngine.Hit cur = current >= 0 && current < hits.size() ? hits.get(current) : null;
        boolean onCurrent = cur != null && sel[0] == cur.start() && sel[1] == cur.end();
        if (onCurrent) {
            current = Math.floorMod(current + direction, hits.size());
        } else if (direction > 0) {
            current = firstAtOrAfter(hits, sel[1]);
        } else {
            current = lastBefore(hits, sel[0]);
        }
        select(editor, hits.get(current));
        paintAndCount();
    }

    // =====================================================================
    // Root scope
    // =====================================================================

    /**
     * Scans the root folder on the worker thread.
     *
     * @param then run on the FX thread once the result is in, or null
     */
    private void runRoot(Runnable then) {
        if (query == null || !query.isUsable()) {
            bar.setCounter("0/0", false, null);
            return;
        }
        rootFolder = resolveRoot();
        if (rootFolder == null) {
            bar.showStatus("No root folder. Set one with the Root button, or open a folder.", true, false);
            return;
        }
        int gen = generation.incrementAndGet();
        SearchEngine.Query q = query;
        Path root = rootFolder;
        Map<Path, String> live = liveTexts();
        bar.setCounter("\u2026", false, "Searching " + root);
        worker.submit(() -> {
            RootSearch.Result result = RootSearch.scan(root, q, live, () -> generation.get() != gen);
            Platform.runLater(() -> {
                if (generation.get() != gen || result == null) {
                    return;
                }
                rootResult = result;
                rootStale = false;
                rootCurrent = -1;
                countRoot();
                if (result.truncated() || result.unreadable() > 0) {
                    StringBuilder note = new StringBuilder();
                    if (result.truncated()) {
                        note.append("Stopped at the search limit; narrow the search to see everything. ");
                    }
                    if (result.unreadable() > 0) {
                        note.append(result.unreadable()).append(" file(s) skipped: not UTF-8 text.");
                    }
                    bar.showStatus(note.toString().trim(), true, false);
                }
                if (then != null) {
                    then.run();
                }
            });
        });
    }

    private void countRoot() {
        if (rootResult == null || rootResult.total() == 0) {
            bar.setCounter("0/0", rootResult != null, rootFolder == null ? null
                    : "No matches in " + rootFolder);
            return;
        }
        int files = rootResult.files().size();
        String position = rootCurrent < 0 ? "0" : String.valueOf(rootCurrent + 1);
        bar.setCounter(position + "/" + rootResult.total() + " \u00B7 " + files + (files == 1 ? " file" : " files"),
                false, "In " + rootFolder);
    }

    private void stepRoot(int direction) {
        if (rootStale || rootResult == null) {
            runRoot(() -> {
                if (rootResult != null && rootResult.total() > 0) {
                    goRoot(direction > 0 ? 0 : rootResult.total() - 1);
                }
            });
            return;
        }
        if (rootResult.total() == 0) {
            return;
        }
        int next = rootCurrent < 0
                ? (direction > 0 ? 0 : rootResult.total() - 1)
                : Math.floorMod(rootCurrent + direction, rootResult.total());
        goRoot(next);
    }

    /** Opens the file holding match {@code g} (counting across all files) and selects it. */
    private void goRoot(int g) {
        if (rootResult == null || rootResult.total() == 0) {
            return;
        }
        g = Math.max(0, Math.min(g, rootResult.total() - 1));
        int[] at = locate(g);
        RootSearch.FileHits fh = rootResult.files().get(at[0]);

        navigating = true;
        try {
            EditorManager.openFileDirectly(ide, fh.path());
        } finally {
            navigating = false;
        }
        attachEditor(activeEditor());
        if (editor == null || !fh.path().equals(activePath())) {
            bar.showStatus("Could not open " + fh.path().getFileName(), true, false);
            return;
        }

        // Search the tab's own text: it may differ from what was scanned.
        List<SearchEngine.Hit> live = SearchEngine.find(textOf(editor), query);
        if (live.size() != fh.hits().size()) {
            replaceFileHits(at[0], live);
            if (rootResult.total() == 0) {
                rootCurrent = -1;
                countRoot();
                return;
            }
            g = Math.min(g, rootResult.total() - 1);
            at = locate(g);
            if (!rootResult.files().get(at[0]).path().equals(fh.path())) {
                goRoot(g); // this file has no matches left; carry on to the next
                return;
            }
        }
        hits = live;
        current = Math.min(at[1], live.size() - 1);
        rootCurrent = g;
        select(editor, hits.get(current));
        if (painter != null) {
            painter.paint(hits, current);
        }
        countRoot();
    }

    /** Paints the matches of the active file when it is part of the root result. */
    private void paintRootFileIfListed() {
        if (rootResult == null || editor == null || query == null || !query.isUsable()) {
            return;
        }
        Path path = activePath();
        for (RootSearch.FileHits fh : rootResult.files()) {
            if (fh.path().equals(path)) {
                hits = SearchEngine.find(textOf(editor), query);
                current = -1;
                if (painter != null) {
                    painter.paint(hits, -1);
                }
                return;
            }
        }
        if (painter != null) {
            painter.clear();
        }
    }

    /** @return {file index, match index in that file} for a global index */
    private int[] locate(int g) {
        int remaining = g;
        List<RootSearch.FileHits> files = rootResult.files();
        for (int i = 0; i < files.size(); i++) {
            int n = files.get(i).hits().size();
            if (remaining < n) {
                return new int[] { i, remaining };
            }
            remaining -= n;
        }
        int last = files.size() - 1;
        return new int[] { last, files.get(last).hits().size() - 1 };
    }

    private void replaceFileHits(int fileIndex, List<SearchEngine.Hit> newHits) {
        List<RootSearch.FileHits> files = new ArrayList<>(rootResult.files());
        RootSearch.FileHits old = files.get(fileIndex);
        if (newHits.isEmpty()) {
            files.remove(fileIndex);
        } else {
            files.set(fileIndex, new RootSearch.FileHits(old.path(), newHits, true));
        }
        int total = 0;
        for (RootSearch.FileHits f : files) {
            total += f.hits().size();
        }
        rootResult = new RootSearch.Result(files, total, rootResult.scanned(), rootResult.unreadable(),
                rootResult.truncated());
    }

    private int globalIndexOf(Path path, int local) {
        int g = 0;
        for (RootSearch.FileHits fh : rootResult.files()) {
            if (fh.path().equals(path)) {
                return g + Math.min(local, fh.hits().size() - 1);
            }
            g += fh.hits().size();
        }
        return Math.min(g, Math.max(0, rootResult.total() - 1));
    }

    // =====================================================================
    // Stepping
    // =====================================================================

    private void step(int direction) {
        if (query == null) {
            queryChanged();
        }
        if (query == null || !query.isUsable()) {
            return;
        }
        if (scope == Scope.EDITOR) {
            liveDelay.stop();
            if (hits.isEmpty()) {
                searchEditor(true);
            } else {
                stepEditor(direction);
            }
        } else {
            stepRoot(direction);
        }
    }

    // =====================================================================
    // Replace
    // =====================================================================

    private void replaceOne() {
        if (!bar.isReplaceShown() || bar.functionClassToggle().isSelected()
                || query == null || !query.isUsable()) {
            return;
        }
        if (scope == Scope.ROOT) {
            if (rootStale || rootResult == null) {
                runRoot(() -> {
                    if (rootResult != null && rootResult.total() > 0) {
                        goRoot(0);
                    }
                });
                return;
            }
            if (rootResult.total() == 0) {
                return;
            }
            if (rootCurrent < 0) {
                goRoot(0); // the first press selects, the next one replaces
                return;
            }
        }
        if (editor == null) {
            return;
        }

        // Always work from the text as it is now -- the user may have typed
        // in the editor since the last search.
        liveDelay.stop();
        String before = textOf(editor);
        hits = SearchEngine.find(before, query);
        current = indexOfExact(hits, selectionOf(editor));
        if (current < 0) {
            // The selection is not a match: this press selects the next one.
            if (scope == Scope.EDITOR) {
                current = hits.isEmpty() ? -1 : firstAtOrAfter(hits, selectionStart(editor));
                if (current >= 0) {
                    select(editor, hits.get(current));
                }
                paintAndCount();
            } else {
                goRoot(Math.max(rootCurrent, 0));
            }
            return;
        }

        SearchEngine.Hit hit = hits.get(current);
        String expanded;
        try {
            expanded = SearchEngine.expand(before, hit, query, bar.replaceField().getText());
        } catch (IllegalArgumentException ex) {
            bar.showStatus("Replacement: " + ex.getMessage(), true, false);
            return;
        }
        if (expanded == null) {
            refresh();
            return;
        }
        SearchEngine.Judgement j = SearchEngine.judge(before, new NcText.Markers(before), hit, expanded);
        if (!j.allowed()) {
            bar.showStatus("Skipped: this replacement " + j.refusal().text() + ".", true, false);
            step(+1);
            return;
        }

        replaceIn(editor, hit.start(), hit.end(), j.text());
        int added = RootSearch.newErrors(errorProbePath(), before, textOf(editor));
        bar.showStatus(added > 0
                ? "This replacement added " + added + " syntax error" + (added == 1 ? "" : "s")
                        + ". Ctrl+Z undoes it."
                : null, added > 0, false);

        int resumeAt = hit.start() + j.text().length();
        List<SearchEngine.Hit> live = SearchEngine.find(textOf(editor), query);
        int localNext = -1;
        for (int i = 0; i < live.size(); i++) {
            if (live.get(i).start() >= resumeAt) {
                localNext = i;
                break;
            }
        }

        if (scope == Scope.EDITOR) {
            hits = live;
            current = hits.isEmpty() ? -1 : (localNext >= 0 ? localNext : 0);
            if (current >= 0) {
                select(editor, hits.get(current));
            }
            paintAndCount();
            return;
        }

        // Root scope: carry on in this file, then in the next one.
        Path path = activePath();
        int fileIndex = fileIndexOf(path);
        if (fileIndex >= 0) {
            replaceFileHits(fileIndex, live);
        }
        if (rootResult.total() == 0) {
            rootCurrent = -1;
            hits = List.of();
            if (painter != null) {
                painter.clear();
            }
            countRoot();
            bar.showStatus("All matches replaced.", false, false);
            return;
        }
        int g;
        if (localNext >= 0) {
            g = globalIndexOf(path, localNext);
        } else {
            // A file with no matches left has been dropped from the list, so
            // the next file now sits at its index.
            int nextFile = live.isEmpty() ? fileIndex : fileIndex + 1;
            g = startOfFile(Math.max(0, nextFile));
        }
        goRoot(Math.floorMod(g, rootResult.total()));
    }

    private static int indexOfExact(List<SearchEngine.Hit> list, int[] selection) {
        for (int i = 0; i < list.size(); i++) {
            SearchEngine.Hit h = list.get(i);
            if (h.start() == selection[0] && h.end() == selection[1]) {
                return i;
            }
        }
        return -1;
    }

    /**
     * A path whose extension tells {@link RootSearch#newErrors} whether to run
     * the Neural Code checker on the active tab (an unsaved tab has no path).
     */
    private Path errorProbePath() {
        Tab tab = pane.getSelectionModel().getSelectedItem();
        if (tab != null && tab.getUserData() instanceof EditorFileInfo info) {
            if (info.path != null) {
                return info.path;
            }
            return Path.of(".nc".equalsIgnoreCase(info.ext) ? "untitled.nc" : "untitled.txt");
        }
        return Path.of("untitled.txt");
    }

    private int fileIndexOf(Path path) {
        if (rootResult == null || path == null) {
            return -1;
        }
        for (int i = 0; i < rootResult.files().size(); i++) {
            if (rootResult.files().get(i).path().equals(path)) {
                return i;
            }
        }
        return -1;
    }

    /** Global index of the first match of the file now at {@code fileIndex}. */
    private int startOfFile(int fileIndex) {
        int g = 0;
        for (int i = 0; i < fileIndex && i < rootResult.files().size(); i++) {
            g += rootResult.files().get(i).hits().size();
        }
        return g;
    }

    private void replaceAll() {
        if (!bar.isReplaceShown() || bar.functionClassToggle().isSelected()
                || query == null || !query.isUsable()) {
            return;
        }
        if (scope == Scope.EDITOR) {
            replaceAllInEditor();
        } else if (rootStale || rootResult == null) {
            runRoot(this::confirmRootReplaceAll);
        } else {
            confirmRootReplaceAll();
        }
    }

    private void replaceAllInEditor() {
        if (editor == null) {
            return;
        }
        String before = textOf(editor);
        SearchEngine.ReplaceAll r;
        try {
            r = SearchEngine.replaceAll(before, query, bar.replaceField().getText());
        } catch (IllegalArgumentException ex) {
            bar.showStatus("Replacement: " + ex.getMessage(), true, false);
            return;
        }
        if (!r.changed()) {
            bar.showStatus(r.refusedCount() > 0
                    ? "Nothing replaced: " + refusalSummary(r) + "."
                    : "Nothing to replace.", r.refusedCount() > 0, false);
            return;
        }
        applyAsOneEdit(editor, before, r);
        String after = textOf(editor);
        int added = RootSearch.newErrors(errorProbePath(), before, after);

        StringBuilder msg = new StringBuilder("Replaced ").append(r.replaced());
        if (r.refusedCount() > 0) {
            msg.append(" \u00B7 skipped ").append(r.refusedCount()).append(" (").append(refusalSummary(r)).append(')');
        }
        if (added > 0) {
            msg.append(" \u00B7 adds ").append(added).append(" syntax error").append(added == 1 ? "" : "s");
        }
        Node target = editor;
        pendingUndo = () -> {
            if (after.equals(textOf(target))) {
                replaceIn(target, 0, after.length(), before);
                bar.showStatus("Replace All undone.", false, false);
            } else {
                bar.showStatus("The file changed since; use Ctrl+Z to undo.", true, false);
            }
        };
        bar.showStatus(msg.toString(), added > 0 || r.refusedCount() > 0, true);
        searchEditor(false);
    }

    private void confirmRootReplaceAll() {
        if (rootResult == null || rootResult.total() == 0) {
            bar.showStatus("Nothing to replace.", false, false);
            return;
        }
        Map<Path, Tab> open = openTabsByPath();
        StringBuilder list = new StringBuilder();
        int shown = 0;
        int onDisk = 0;
        for (RootSearch.FileHits fh : rootResult.files()) {
            boolean isOpen = open.containsKey(fh.path());
            if (!isOpen) {
                onDisk++;
            }
            if (shown < 15) {
                list.append(relative(fh.path())).append("  \u2014  ").append(fh.hits().size())
                        .append(fh.hits().size() == 1 ? " match" : " matches")
                        .append(isOpen ? "  (open tab)" : "").append('\n');
                shown++;
            }
        }
        if (rootResult.files().size() > shown) {
            list.append("\u2026 and ").append(rootResult.files().size() - shown).append(" more file(s)\n");
        }
        list.append('\n');
        if (onDisk > 0) {
            list.append(onDisk).append(onDisk == 1 ? " file is" : " files are")
                    .append(" written to disk now. A backup is kept: Undo in the search bar restores them.\n");
        }
        if (onDisk < rootResult.files().size()) {
            list.append("Open files are changed in their tab; save them to keep the change.\n");
        }
        list.append("Replacements that would break a letter, a conjunct or a sub/superscript are skipped.");

        ButtonType go = new ButtonType("Replace All", ButtonBar.ButtonData.OK_DONE);
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, list.toString(), go, ButtonType.CANCEL);
        alert.initOwner(ide.stage);
        alert.setTitle("Replace All");
        alert.setHeaderText("Replace " + rootResult.total() + (rootResult.total() == 1 ? " match" : " matches")
                + " in " + rootResult.files().size() + (rootResult.files().size() == 1 ? " file" : " files")
                + " under " + (rootFolder == null ? "the root folder" : rootFolder.getFileName()) + "?");
        if (ide.scene != null) {
            alert.getDialogPane().getStylesheets().addAll(ide.scene.getStylesheets());
        }
        if (alert.showAndWait().orElse(ButtonType.CANCEL) != go) {
            return;
        }
        doRootReplaceAll(open);
    }

    private void doRootReplaceAll(Map<Path, Tab> open) {
        String replacement = bar.replaceField().getText();
        SearchEngine.Query q = query;

        // 1. Open tabs: changed in the tab, on the FX thread, one undo step each.
        List<Runnable> tabUndos = new ArrayList<>();
        int tabReplaced = 0;
        int refused = 0;
        List<String> withErrors = new ArrayList<>();
        List<Path> diskFiles = new ArrayList<>();
        for (RootSearch.FileHits fh : rootResult.files()) {
            Tab tab = open.get(fh.path());
            if (tab == null) {
                diskFiles.add(fh.path());
                continue;
            }
            Node ed = editorOf(tab);
            if (ed == null) {
                continue;
            }
            String before = textOf(ed);
            SearchEngine.ReplaceAll r;
            try {
                r = SearchEngine.replaceAll(before, q, replacement);
            } catch (IllegalArgumentException ex) {
                bar.showStatus("Replacement: " + ex.getMessage(), true, false);
                return;
            }
            refused += r.refusedCount();
            if (!r.changed()) {
                continue;
            }
            applyAsOneEdit(ed, before, r);
            String after = textOf(ed);
            tabReplaced += r.replaced();
            int added = RootSearch.newErrors(fh.path(), before, after);
            if (added > 0) {
                withErrors.add(fh.path().getFileName() + " (" + added + ")");
            }
            tabUndos.add(() -> {
                if (after.equals(textOf(ed))) {
                    replaceIn(ed, 0, after.length(), before);
                }
            });
        }

        // 2. Closed files: written to disk on the worker, with a backup first.
        int tabsDone = tabReplaced;
        int refusedInTabs = refused;
        bar.setCounter("\u2026", false, "Replacing");
        worker.submit(() -> {
            RootSearch.Backup backup;
            List<RootSearch.DiskOutcome> outcomes;
            try {
                backup = RootSearch.newBackup();
                outcomes = RootSearch.replaceOnDisk(diskFiles, q, replacement, backup);
            } catch (Exception ex) {
                Platform.runLater(() -> bar.showStatus("Replace All failed: " + ex.getMessage(), true, false));
                return;
            }
            Platform.runLater(() -> finishRootReplaceAll(tabsDone, refusedInTabs, withErrors, tabUndos,
                    backup, outcomes));
        });
    }

    private void finishRootReplaceAll(int tabReplaced, int refused, List<String> withErrors,
            List<Runnable> tabUndos, RootSearch.Backup backup, List<RootSearch.DiskOutcome> outcomes) {
        int diskReplaced = 0;
        int diskFiles = 0;
        List<String> failed = new ArrayList<>();
        for (RootSearch.DiskOutcome o : outcomes) {
            if (o.failure() != null) {
                failed.add(o.path().getFileName() + ": " + o.failure());
                continue;
            }
            refused += o.refused();
            if (o.replaced() > 0) {
                diskReplaced += o.replaced();
                diskFiles++;
            }
            if (o.newErrors() > 0) {
                withErrors.add(o.path().getFileName() + " (" + o.newErrors() + ")");
            }
        }
        cleanUpOnExit(backup);
        if (diskFiles > 0) {
            ProjectManager.refreshProjectTree(ide);
        }

        StringBuilder msg = new StringBuilder("Replaced ").append(tabReplaced + diskReplaced);
        if (diskFiles > 0) {
            msg.append(" \u00B7 ").append(diskFiles).append(diskFiles == 1 ? " file" : " files").append(" saved");
        }
        if (!tabUndos.isEmpty()) {
            msg.append(" \u00B7 ").append(tabUndos.size()).append(tabUndos.size() == 1 ? " open tab" : " open tabs")
                    .append(" changed (unsaved)");
        }
        if (refused > 0) {
            msg.append(" \u00B7 skipped ").append(refused).append(" unsafe");
        }
        if (!withErrors.isEmpty()) {
            msg.append(" \u00B7 new syntax errors in ").append(String.join(", ", withErrors));
        }
        if (!failed.isEmpty()) {
            msg.append(" \u00B7 not written: ").append(String.join("; ", failed));
        }
        boolean warn = refused > 0 || !withErrors.isEmpty() || !failed.isEmpty();

        pendingUndo = () -> {
            int restored = RootSearch.restore(backup);
            for (Runnable u : tabUndos) {
                u.run();
            }
            ProjectManager.refreshProjectTree(ide);
            rootStale = true;
            rootResult = null;
            rootCurrent = -1;
            countRootAfterChange();
            bar.showStatus("Replace All undone: " + restored + " file(s) restored"
                    + (tabUndos.isEmpty() ? "" : ", " + tabUndos.size() + " tab(s) reverted") + ".", false, false);
        };

        rootStale = true;
        rootResult = null;
        rootCurrent = -1;
        if (painter != null) {
            painter.clear();
        }
        countRootAfterChange();
        bar.showStatus(msg.toString(), warn, true);
    }

    private void countRootAfterChange() {
        bar.setCounter("\u2014", false, "Press Enter or Find to search again");
    }

    private void undoLast() {
        Runnable undo = pendingUndo;
        pendingUndo = null;
        if (undo != null) {
            undo.run();
        }
        if (scope == Scope.EDITOR) {
            searchEditor(false);
        }
    }

    private static String refusalSummary(SearchEngine.ReplaceAll r) {
        List<String> parts = new ArrayList<>();
        r.refused().forEach((reason, n) -> parts.add(n + " " + reason.text()));
        return String.join(", ", parts);
    }

    private static void cleanUpOnExit(RootSearch.Backup backup) {
        // deleteOnExit runs in reverse order: the folder is registered first
        // so it is deleted last, after the files in it.
        File folder = backup.folder().toFile();
        folder.deleteOnExit();
        for (Path[] entry : backup.entries()) {
            entry[1].toFile().deleteOnExit();
        }
    }

    private String relative(Path path) {
        if (rootFolder != null && path.startsWith(rootFolder)) {
            return rootFolder.relativize(path).toString();
        }
        return path.toString();
    }

    // =====================================================================
    // Editors and tabs
    // =====================================================================

    private void refresh() {
        if (scope == Scope.EDITOR) {
            searchEditor(true);
        } else {
            rootStale = true;
        }
    }

    private Node activeEditor() {
        Tab tab = pane.getSelectionModel().getSelectedItem();
        return tab == null ? null : editorOf(tab);
    }

    private Path activePath() {
        Tab tab = pane.getSelectionModel().getSelectedItem();
        if (tab != null && tab.getUserData() instanceof EditorFileInfo info && info.path != null) {
            return RootSearch.normalise(info.path);
        }
        return null;
    }

    private static Node editorOf(Tab tab) {
        Node content = tab.getContent();
        if (content instanceof VirtualizedScrollPane<?> scroll && scroll.getContent() instanceof CodeArea area) {
            return area;
        }
        if (content instanceof TextArea area) {
            return area;
        }
        return null;
    }

    private void attachEditor(Node next) {
        if (next == editor) {
            return;
        }
        detachEditor();
        editor = next;
        if (editor instanceof CodeArea area) {
            painter = new HitPainter(area);
            area.textProperty().addListener(editorTextListener);
        } else if (editor instanceof TextArea area) {
            area.textProperty().addListener(editorTextListener);
        }
    }

    private void detachEditor() {
        if (painter != null) {
            painter.clear();
            painter = null;
        }
        if (editor instanceof CodeArea area) {
            area.textProperty().removeListener(editorTextListener);
        } else if (editor instanceof TextArea area) {
            area.textProperty().removeListener(editorTextListener);
        }
        editor = null;
        hits = List.of();
        current = -1;
    }

    private Map<Path, Tab> openTabsByPath() {
        Map<Path, Tab> map = new HashMap<>();
        for (Tab tab : pane.getTabs()) {
            if (tab.getUserData() instanceof EditorFileInfo info && info.path != null) {
                map.put(RootSearch.normalise(info.path), tab);
            }
        }
        return map;
    }

    private Map<Path, String> liveTexts() {
        Map<Path, String> map = new HashMap<>();
        openTabsByPath().forEach((path, tab) -> {
            Node ed = editorOf(tab);
            if (ed != null) {
                map.put(path, textOf(ed));
            }
        });
        return map;
    }

    // ---- text access, for both editor kinds ----

    private static String textOf(Node ed) {
        if (ed instanceof CodeArea area) {
            return area.getText();
        }
        if (ed instanceof TextArea area) {
            return area.getText();
        }
        return "";
    }

    private static int caretOf(Node ed) {
        if (ed instanceof CodeArea area) {
            return area.getCaretPosition();
        }
        if (ed instanceof TextArea area) {
            return area.getCaretPosition();
        }
        return 0;
    }

    private static int selectionStart(Node ed) {
        return selectionOf(ed)[0];
    }

    private static int[] selectionOf(Node ed) {
        if (ed instanceof CodeArea area) {
            return new int[] { area.getSelection().getStart(), area.getSelection().getEnd() };
        }
        if (ed instanceof TextArea area) {
            return new int[] { area.getSelection().getStart(), area.getSelection().getEnd() };
        }
        return new int[] { 0, 0 };
    }

    private static void select(Node ed, SearchEngine.Hit hit) {
        if (ed instanceof CodeArea area) {
            area.selectRange(hit.start(), hit.end());
            area.requestFollowCaret();
        } else if (ed instanceof TextArea area) {
            area.selectRange(hit.start(), hit.end());
        }
    }

    private static void replaceIn(Node ed, int start, int end, String text) {
        if (ed instanceof CodeArea area) {
            area.replaceText(start, end, text);
        } else if (ed instanceof TextArea area) {
            area.replaceText(start, end, text);
        }
    }

    /**
     * Writes a Replace All as ONE edit spanning the first to the last change,
     * so a single Ctrl+Z takes the whole thing back.
     */
    private static void applyAsOneEdit(Node ed, String before, SearchEngine.ReplaceAll r) {
        String after = r.text();
        int tail = before.length() - r.lastEdit();
        String middle = after.substring(r.firstEdit(), after.length() - tail);
        replaceIn(ed, r.firstEdit(), r.lastEdit(), middle);
    }

    // ---- index helpers ----

    private static int firstAtOrAfter(List<SearchEngine.Hit> list, int pos) {
        if (list.isEmpty()) {
            return -1;
        }
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).start() >= pos) {
                return i;
            }
        }
        return 0; // wrap to the top
    }

    private static int lastBefore(List<SearchEngine.Hit> list, int pos) {
        for (int i = list.size() - 1; i >= 0; i--) {
            if (list.get(i).end() <= pos) {
                return i;
            }
        }
        return list.size() - 1; // wrap to the bottom
    }
}
