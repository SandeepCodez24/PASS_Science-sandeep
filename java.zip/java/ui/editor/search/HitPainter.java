package ui.editor.search;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.fxmisc.richtext.CodeArea;
import org.fxmisc.richtext.Selection;
import org.fxmisc.richtext.SelectionImpl;

import javafx.scene.paint.Color;
import ui.design.section_dims.Search_dim;

/**
 * Paints every match in a {@code .nc} editor.
 *
 * <h3>Why extra selections and not style spans</h3>
 * <p>
 * The syntax colouring owns the editor's style spans and rewrites all of them
 * on every change ({@code EditorTabFactory}). A match colour written as a
 * style span would be wiped by the next keystroke, and would itself wipe the
 * token colours under it. RichTextFX can draw any number of additional
 * selections, each a shape behind the text: they never touch the document or
 * its spans, follow scrolling, zoom and folding by themselves, and disappear
 * the moment they are removed. So each match is one extra selection.
 * </p>
 *
 * <p>
 * The current match is the editor's own selection (so Replace, Copy and
 * typing all act on it) plus a stronger extra shape underneath.
 * </p>
 *
 * <p>
 * Colours come from {@code themes/search/search_*.css} through the shape's
 * {@code -fx-highlight-fill}; the value set here is only the fallback until
 * the stylesheet applies.
 * </p>
 */
final class HitPainter {

    private final CodeArea area;
    private final List<Selection<Collection<String>, String, Collection<String>>> painted = new ArrayList<>();
    private int serial = 0;

    HitPainter(CodeArea area) {
        this.area = area;
    }

    CodeArea area() {
        return area;
    }

    /**
     * Repaints the matches.
     *
     * @param hits    every match, in text order
     * @param current index of the current match, or -1
     */
    void paint(List<SearchEngine.Hit> hits, int current) {
        clear();
        int length = area.getLength();
        int limit = Math.min(hits.size(), Search_dim.MAX_PAINTED_HITS);
        // Keep the current match painted even when it lies past the limit.
        for (int i = 0; i < limit; i++) {
            add(hits.get(i), i == current, length);
        }
        if (current >= limit && current < hits.size()) {
            add(hits.get(current), true, length);
        }
    }

    private void add(SearchEngine.Hit hit, boolean isCurrent, int length) {
        if (hit.end() > length || hit.start() < 0) {
            return; // the text moved under us; the next repaint catches up
        }
        String styleClass = isCurrent ? "search-hit-current" : "search-hit";
        Color fallback = fallback(isCurrent);
        SelectionImpl<Collection<String>, String, Collection<String>> sel = new SelectionImpl<>(
                "astra-search-" + (serial++), area,
                path -> {
                    path.getStyleClass().add(styleClass);
                    path.setHighlightFill(fallback);
                    path.setStrokeWidth(0);
                    path.setMouseTransparent(true);
                });
        if (area.addSelection(sel)) {
            sel.selectRange(hit.start(), hit.end());
            painted.add(sel);
        } else {
            sel.dispose();
        }
    }

    /** Removes every painted match. */
    void clear() {
        for (Selection<Collection<String>, String, Collection<String>> sel : painted) {
            try {
                area.removeSelection(sel); // also disposes it
            } catch (RuntimeException ignored) {
                // An editor being torn down; nothing left to clean.
            }
        }
        painted.clear();
    }

    private static Color fallback(boolean current) {
        boolean dark = SearchIcons.isDarkTheme();
        if (current) {
            return dark ? Color.rgb(255, 160, 40, 0.55) : Color.rgb(255, 150, 20, 0.55);
        }
        return dark ? Color.rgb(255, 214, 64, 0.26) : Color.rgb(255, 214, 64, 0.45);
    }
}
