package ui.editor.search;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * The search itself: no JavaFX, no files, just text in and matches out, so it
 * can be used the same way for an editor tab and for a file on disk.
 *
 * <h3>What a match must satisfy</h3>
 * <ol>
 * <li>The pattern matches (literal or regular expression, with or without
 * case).</li>
 * <li>It starts and ends on a letter boundary ({@link NcText.Letters}), so no
 * vowel sign or conjunct is ever cut in half.</li>
 * <li>With Whole Word, the characters on either side are not part of a Neural
 * Code name ({@link NcText#isIdentifierPart}).</li>
 * </ol>
 *
 * <h3>Function &amp; Class</h3>
 * <p>
 * Only the names in {@code function ...:} and {@code class ...:} headers are
 * searched. With Whole Word the whole name must match.
 * </p>
 *
 * <h3>Replacing</h3>
 * <p>
 * Every replacement is judged before it is made ({@link #judge}). One that
 * would leave a vowel sign without its letter, fuse into the next letter
 * through a virama, or break a sub/superscript is skipped and counted, never
 * written.
 * </p>
 */
public final class SearchEngine {

    /** Hard cap on matches collected from one text. */
    public static final int MAX_HITS_PER_TEXT = 20000;

    /** Characters a Neural Code name is made of, for the header patterns. */
    private static final String NAME = "[\\p{L}\\p{M}\\p{N}_\\u200C\\u200D]+";

    /** {@code function f(x):}, {@code function y = f(x):}, {@code function [a, b] = f(x):}. */
    private static final Pattern FUNCTION_HEADER = Pattern.compile(
            "^[ \\t]*function\\s+(?:(?:\\[[^\\]\\n]*\\]|" + NAME + ")\\s*=\\s*)?(" + NAME + ")\\s*\\(",
            Pattern.MULTILINE);

    /** {@code class A(args):}. */
    private static final Pattern CLASS_HEADER = Pattern.compile(
            "^[ \\t]*class\\s+(" + NAME + ")\\s*\\(",
            Pattern.MULTILINE);

    private SearchEngine() {
    }

    // =====================================================================
    // Types
    // =====================================================================

    /**
     * The four toggles.
     *
     * @param matchCase     Match Case (on by default)
     * @param wholeWord     Whole Word
     * @param regex         Use Regular Expression
     * @param functionClass Function &amp; Class names only
     */
    public record Options(boolean matchCase, boolean wholeWord, boolean regex, boolean functionClass) {
    }

    /**
     * One match.
     *
     * @param start first char
     * @param end   one past the last char
     */
    public record Hit(int start, int end) {
    }

    /** Why a replacement was not made. */
    public enum Refusal {
        /** The replacement starts with a vowel sign or other mark. */
        ORPHAN_MARK("would leave a vowel sign without its letter"),
        /** The replacement ends in a virama that would fuse with the next letter. */
        JOINS_NEXT_LETTER("would join the next letter into a conjunct"),
        /** The match or the replacement cuts a sub/superscript open. */
        BREAKS_SCRIPT("would break a subscript or superscript"),
        /** The replacement cannot be written inside that sub/superscript. */
        NOT_FOR_SCRIPT("cannot be written inside a subscript or superscript");

        private final String text;

        Refusal(String text) {
            this.text = text;
        }

        /** @return a short reason for the status line */
        public String text() {
            return text;
        }
    }

    /** A compiled search, or the reason it could not be compiled. */
    public static final class Query {

        private final Pattern pattern;
        private final String needle;
        private final String error;
        private final Options options;

        private Query(Pattern pattern, String needle, String error, Options options) {
            this.pattern = pattern;
            this.needle = needle;
            this.error = error;
            this.options = options;
        }

        /** @return true when there is nothing to search for */
        public boolean isEmpty() {
            return needle == null || needle.isEmpty();
        }

        /** @return true when the query can run */
        public boolean isUsable() {
            return !isEmpty() && pattern != null;
        }

        /** @return the regular-expression error, or null */
        public String error() {
            return error;
        }

        /** @return the options it was built with */
        public Options options() {
            return options;
        }

        /** @return the search text after {@code \var(...)} conversion */
        public String needle() {
            return needle;
        }

        Pattern pattern() {
            return pattern;
        }
    }

    /**
     * The outcome of a Replace All on one text.
     *
     * @param text      the new text
     * @param replaced  how many matches were replaced
     * @param refused   how many were skipped, by reason
     * @param firstEdit start of the first change, or -1 if nothing changed
     * @param lastEdit  end of the last change in the OLD text, or -1
     */
    public record ReplaceAll(String text, int replaced, Map<Refusal, Integer> refused, int firstEdit, int lastEdit) {

        /** @return total matches skipped */
        public int refusedCount() {
            int n = 0;
            for (int v : refused.values()) {
                n += v;
            }
            return n;
        }

        /** @return true if the text changed */
        public boolean changed() {
            return replaced > 0;
        }
    }

    // =====================================================================
    // Compiling
    // =====================================================================

    /**
     * Builds a query. {@code \var(...)} forms are turned into their glyphs
     * first, so both spellings find the same variable.
     *
     * @param raw     the search text as typed
     * @param options the toggles
     * @return the query; check {@link Query#error()} for a bad expression
     */
    public static Query compile(String raw, Options options) {
        String needle = NcText.toGlyphs(raw == null ? "" : raw);
        if (needle.isEmpty()) {
            return new Query(null, needle, null, options);
        }
        int flags = Pattern.MULTILINE;
        if (!options.matchCase()) {
            flags |= Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
        }
        try {
            Pattern p = options.regex()
                    ? Pattern.compile(needle, flags | Pattern.UNICODE_CHARACTER_CLASS)
                    : Pattern.compile(Pattern.quote(needle), flags);
            return new Query(p, needle, null, options);
        } catch (PatternSyntaxException e) {
            return new Query(null, needle, e.getDescription(), options);
        }
    }

    // =====================================================================
    // Finding
    // =====================================================================

    /**
     * Finds every match in a text: definition names when Function &amp; Class
     * is on, otherwise everything.
     *
     * @param text  the text
     * @param query the query
     * @return the matches in text order, at most {@link #MAX_HITS_PER_TEXT}
     */
    public static List<Hit> find(String text, Query query) {
        if (text == null || query == null || !query.isUsable()) {
            return List.of();
        }
        return query.options().functionClass()
                ? findDefinitions(text, query)
                : findText(text, query);
    }

    private static List<Hit> findText(String text, Query query) {
        List<Hit> hits = new ArrayList<>();
        NcText.Letters letters = new NcText.Letters(text);
        Matcher m = query.pattern().matcher(text);
        while (m.find() && hits.size() < MAX_HITS_PER_TEXT) {
            if (accept(text, letters, m.start(), m.end(), query.options().wholeWord())) {
                hits.add(new Hit(m.start(), m.end()));
            }
        }
        return hits;
    }

    private static List<Hit> findDefinitions(String text, Query query) {
        List<int[]> names = new ArrayList<>();
        collectNames(FUNCTION_HEADER, text, names);
        collectNames(CLASS_HEADER, text, names);
        names.sort((a, b) -> Integer.compare(a[0], b[0]));

        List<Hit> hits = new ArrayList<>();
        NcText.Letters letters = new NcText.Letters(text);
        Matcher m = query.pattern().matcher(text);
        for (int[] name : names) {
            m.region(name[0], name[1]);
            while (m.find() && hits.size() < MAX_HITS_PER_TEXT) {
                int s = m.start();
                int e = m.end();
                if (e == s || !letters.isBoundary(s) || !letters.isBoundary(e)) {
                    continue;
                }
                // Whole Word on a definition means the whole name.
                if (query.options().wholeWord() && (s != name[0] || e != name[1])) {
                    continue;
                }
                hits.add(new Hit(s, e));
            }
        }
        return hits;
    }

    private static void collectNames(Pattern header, String text, List<int[]> out) {
        Matcher m = header.matcher(text);
        while (m.find()) {
            out.add(new int[] { m.start(1), m.end(1) });
        }
    }

    private static boolean accept(String text, NcText.Letters letters, int s, int e, boolean wholeWord) {
        if (e == s) {
            return false;
        }
        if (!letters.isBoundary(s) || !letters.isBoundary(e)) {
            return false;
        }
        if (wholeWord) {
            if (s > 0 && NcText.isIdentifierPart(text.codePointBefore(s))) {
                return false;
            }
            if (e < text.length() && NcText.isIdentifierPart(text.codePointAt(e))) {
                return false;
            }
        }
        return true;
    }

    // =====================================================================
    // Replacing
    // =====================================================================

    /**
     * Works out the replacement for one match: {@code \var(...)} converted,
     * and in regex mode {@code $1} / {@code ${name}} filled in.
     *
     * @param text        the text the match is in
     * @param hit         the match
     * @param query       the query that found it
     * @param replacement the replacement as typed
     * @return the text to write, or null if the match no longer holds
     * @throws IllegalArgumentException for a bad group reference
     */
    public static String expand(String text, Hit hit, Query query, String replacement) {
        String glyphs = NcText.toGlyphs(replacement == null ? "" : replacement);
        if (!query.options().regex()) {
            return glyphs;
        }
        Matcher m = query.pattern().matcher(text);
        if (!m.find(hit.start()) || m.start() != hit.start() || m.end() != hit.end()) {
            return null;
        }
        return expandGroups(m, glyphs);
    }

    /**
     * Decides whether one replacement is safe, and returns what to actually
     * write (a replacement inside a sub/superscript has its digits rewritten).
     *
     * @param text     the text
     * @param markers  its marked groups
     * @param hit      the match
     * @param expanded the replacement from {@link #expand}
     * @return the text to write, or a refusal
     */
    public static Judgement judge(String text, NcText.Markers markers, Hit hit, String expanded) {
        if (!expanded.isEmpty()) {
            if (NcText.isMark(expanded.codePointAt(0))) {
                return Judgement.refuse(Refusal.ORPHAN_MARK);
            }
            char last = expanded.charAt(expanded.length() - 1);
            if (NcText.isJoiningVirama(last) && hit.end() < text.length()
                    && Character.isLetter(text.codePointAt(hit.end()))) {
                return Judgement.refuse(Refusal.JOINS_NEXT_LETTER);
            }
        }
        switch (markers.place(hit.start(), hit.end())) {
            case OUTSIDE, WHOLE_GROUPS -> {
                return NcText.markersBalanced(expanded)
                        ? Judgement.write(expanded)
                        : Judgement.refuse(Refusal.BREAKS_SCRIPT);
            }
            case INSIDE -> {
                NcText.Group group = markers.enclosing(hit.start(), hit.end());
                // Replacing only part of a single-letter group cannot happen:
                // the whole group content is one letter.
                String adapted = group == null ? null : NcText.adaptForGroup(expanded, group);
                return adapted == null
                        ? Judgement.refuse(Refusal.NOT_FOR_SCRIPT)
                        : Judgement.write(adapted);
            }
            default -> {
                return Judgement.refuse(Refusal.BREAKS_SCRIPT);
            }
        }
    }

    /**
     * The verdict on one replacement.
     *
     * @param text    what to write, when allowed
     * @param refusal why not, when refused
     */
    public record Judgement(String text, Refusal refusal) {

        static Judgement write(String text) {
            return new Judgement(text, null);
        }

        static Judgement refuse(Refusal refusal) {
            return new Judgement(null, refusal);
        }

        /** @return true when the replacement may be written */
        public boolean allowed() {
            return refusal == null;
        }
    }

    /**
     * Replaces every safe match in a text.
     *
     * @param text        the text
     * @param query       the query
     * @param replacement the replacement as typed
     * @return the new text and the counts
     * @throws IllegalArgumentException for a bad group reference
     */
    public static ReplaceAll replaceAll(String text, Query query, String replacement) {
        Map<Refusal, Integer> refused = new EnumMap<>(Refusal.class);
        List<Hit> hits = find(text, query);
        if (hits.isEmpty()) {
            return new ReplaceAll(text, 0, refused, -1, -1);
        }
        String glyphs = NcText.toGlyphs(replacement == null ? "" : replacement);
        NcText.Markers markers = new NcText.Markers(text);
        Matcher m = query.options().regex() ? query.pattern().matcher(text) : null;

        StringBuilder out = new StringBuilder(text.length() + 16);
        int copied = 0;
        int replaced = 0;
        int first = -1;
        int lastEnd = -1;
        for (Hit hit : hits) {
            String expanded = glyphs;
            if (m != null) {
                if (!m.find(hit.start()) || m.start() != hit.start() || m.end() != hit.end()) {
                    continue;
                }
                expanded = expandGroups(m, glyphs);
            }
            Judgement j = judge(text, markers, hit, expanded);
            if (!j.allowed()) {
                refused.merge(j.refusal(), 1, Integer::sum);
                continue;
            }
            out.append(text, copied, hit.start()).append(j.text());
            copied = hit.end();
            replaced++;
            if (first < 0) {
                first = hit.start();
            }
            lastEnd = hit.end();
        }
        out.append(text, copied, text.length());
        return new ReplaceAll(out.toString(), replaced, refused, first, lastEnd);
    }

    /**
     * Fills in {@code $n}, {@code ${name}} and {@code \x} escapes the way
     * {@link Matcher#appendReplacement} does, but returns the result instead
     * of appending it, so it can be judged before anything is written.
     */
    private static String expandGroups(Matcher m, String replacement) {
        StringBuilder sb = new StringBuilder();
        int i = 0;
        int n = replacement.length();
        while (i < n) {
            char c = replacement.charAt(i);
            if (c == '\\' && i + 1 < n) {
                sb.append(replacement.charAt(i + 1));
                i += 2;
            } else if (c == '$' && i + 1 < n) {
                char next = replacement.charAt(i + 1);
                if (next == '{') {
                    int close = replacement.indexOf('}', i + 2);
                    if (close < 0) {
                        throw new IllegalArgumentException("Unclosed ${ in the replacement");
                    }
                    String group = m.group(replacement.substring(i + 2, close));
                    sb.append(group == null ? "" : group);
                    i = close + 1;
                } else if (Character.isDigit(next)) {
                    int num = next - '0';
                    int j = i + 2;
                    while (j < n && Character.isDigit(replacement.charAt(j))) {
                        int bigger = num * 10 + (replacement.charAt(j) - '0');
                        if (bigger > m.groupCount()) {
                            break;
                        }
                        num = bigger;
                        j++;
                    }
                    if (num > m.groupCount()) {
                        throw new IllegalArgumentException("No group " + num + " in the expression");
                    }
                    String group = m.group(num);
                    sb.append(group == null ? "" : group);
                    i = j;
                } else {
                    sb.append(c);
                    i++;
                }
            } else {
                sb.append(c);
                i++;
            }
        }
        return sb.toString();
    }
}
