package ui.editor.search;

import javafx.geometry.Bounds;
import javafx.scene.Node;
import javafx.scene.control.Skin;
import javafx.scene.control.TabPane;
import javafx.scene.control.skin.TabPaneSkin;
import javafx.scene.layout.Region;
import ui.design.section_dims.Search_dim;

/**
 * The editor's {@link TabPane}, able to float the find / replace bar over the
 * top right of its content.
 *
 * <h3>Why the bar lives inside the tab pane</h3>
 * <p>
 * The bar has to sit over the editor wherever the Layout band puts the editor,
 * and it has to be there with no tab open at all, when the search runs over
 * the root folder. The one node that is always the editor area, in every
 * layout, is this tab pane -- {@code LayoutManager} places it, so a wrapper
 * around it would need the layouts rewritten. Instead the tab pane's skin
 * carries the bar as one extra child, drawn above the tabs' content and
 * positioned after every layout pass. Nothing that reads
 * {@code ide.editorTabs} sees a difference: it is still a {@code TabPane},
 * and every tab's content is untouched.
 * </p>
 */
public final class EditorTabPane extends TabPane {

    private Region overlay;

    /**
     * Sets the node floated at the top right (the search bar). It starts
     * hidden; the owner shows it.
     *
     * @param node the bar
     */
    public void setOverlay(Region node) {
        this.overlay = node;
        node.setManaged(false);
        if (getSkin() instanceof OverlaySkin skin) {
            skin.attach(node);
        }
        requestLayout();
    }

    @Override
    protected Skin<?> createDefaultSkin() {
        OverlaySkin skin = new OverlaySkin(this);
        if (overlay != null) {
            skin.attach(overlay);
        }
        return skin;
    }

    /**
     * The standard skin plus the overlay: laid out after the tabs, and kept
     * last among the children so tab content added later never covers it.
     */
    private static final class OverlaySkin extends TabPaneSkin {

        private final EditorTabPane pane;
        private Region overlay;

        OverlaySkin(EditorTabPane pane) {
            super(pane);
            this.pane = pane;
        }

        void attach(Region node) {
            if (overlay != null) {
                getChildren().remove(overlay);
            }
            overlay = node;
            getChildren().add(node);
        }

        @Override
        protected void layoutChildren(double x, double y, double w, double h) {
            super.layoutChildren(x, y, w, h);
            if (overlay == null || !overlay.isVisible()) {
                return;
            }
            if (getChildren().indexOf(overlay) != getChildren().size() - 1) {
                overlay.toFront();
            }

            // Below the tab strip when there are tabs; at the top otherwise.
            double top = y;
            Node header = pane.lookup(".tab-header-area");
            if (header != null && header.isVisible() && !pane.getTabs().isEmpty()) {
                Bounds b = header.getBoundsInParent();
                top = Math.max(top, b.getMaxY());
            }

            double available = Math.max(0, w - Search_dim.MARGIN_RIGHT - Search_dim.MARGIN_RIGHT / 2);
            double pw = Math.min(overlay.prefWidth(-1), available);
            pw = Math.max(pw, Math.min(overlay.minWidth(-1), available));
            double ph = overlay.prefHeight(pw);
            double left = x + w - Search_dim.MARGIN_RIGHT - pw;
            overlay.resizeRelocate(snapPositionX(Math.max(x, left)), snapPositionY(top + Search_dim.MARGIN_TOP),
                    snapSizeX(pw), snapSizeY(ph));
        }
    }
}
