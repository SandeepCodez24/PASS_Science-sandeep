package ui.editor.search;

import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 * The find / replace bar's icons, in a light and a dark ink.
 *
 * <pre>
 *   /icons/search/{light,dark}/search_&lt;name&gt;.png     48 x 48, 96 dpi, RGBA
 * </pre>
 *
 * <p>
 * The same pattern as {@code FoldIcons}: a weak registry of every icon on
 * screen, re-pointed in place by {@link #setDarkTheme(boolean)}, which
 * {@code ThemeManager.applyIconInk} calls.
 * </p>
 */
public final class SearchIcons {

    /** The icon set. The enum name, lower-cased, is the file name suffix. */
    public enum Icon {
        EXPAND_RIGHT, EXPAND_DOWN, MATCH_CASE, WHOLE_WORD, REGEX, FUNCTION_CLASS,
        PREV, NEXT, CLOSE, CLEAR;

        String file() {
            return "search_" + name().toLowerCase(java.util.Locale.ROOT) + ".png";
        }
    }

    private static final String BASE = "/icons/search/";
    private static final String ICON_KEY = "search-icon";

    private static boolean darkTheme = false;
    private static final Map<String, Image> CACHE = new HashMap<>();
    private static final List<WeakReference<ImageView>> REGISTRY = new ArrayList<>();

    private SearchIcons() {
    }

    /**
     * @param icon which icon
     * @param size drawn size, px
     * @return an ImageView registered for theme repainting
     */
    public static ImageView create(Icon icon, double size) {
        ImageView view = new ImageView();
        view.setFitWidth(size);
        view.setFitHeight(size);
        view.setPreserveRatio(true);
        view.setSmooth(true);
        view.getProperties().put(ICON_KEY, icon);
        view.setImage(image(icon, darkTheme));
        synchronized (REGISTRY) {
            REGISTRY.add(new WeakReference<>(view));
        }
        return view;
    }

    /**
     * Points an existing view at another icon, keeping its registration.
     *
     * @param view a view from {@link #create}
     * @param icon the new icon
     */
    public static void set(ImageView view, Icon icon) {
        if (view == null) {
            return;
        }
        view.getProperties().put(ICON_KEY, icon);
        view.setImage(image(icon, darkTheme));
    }

    /**
     * Re-inks every icon on screen. Called by {@code ThemeManager.applyIconInk}.
     *
     * @param dark true for the dark theme
     */
    public static void setDarkTheme(boolean dark) {
        darkTheme = dark;
        synchronized (REGISTRY) {
            Iterator<WeakReference<ImageView>> it = REGISTRY.iterator();
            while (it.hasNext()) {
                ImageView view = it.next().get();
                if (view == null) {
                    it.remove();
                    continue;
                }
                if (view.getProperties().get(ICON_KEY) instanceof Icon icon) {
                    view.setImage(image(icon, dark));
                }
            }
        }
    }

    /** @return true while the dark ink is in force */
    public static boolean isDarkTheme() {
        return darkTheme;
    }

    private static Image image(Icon icon, boolean dark) {
        String resource = BASE + (dark ? "dark/" : "light/") + icon.file();
        synchronized (CACHE) {
            Image cached = CACHE.get(resource);
            if (cached != null) {
                return cached;
            }
            try (InputStream in = SearchIcons.class.getResourceAsStream(resource)) {
                if (in == null) {
                    System.err.println("Search icon missing: " + resource);
                    return null;
                }
                Image loaded = new Image(in);
                CACHE.put(resource, loaded);
                return loaded;
            } catch (Exception e) {
                System.err.println("Search icon failed to load: " + resource + " -- " + e.getMessage());
                return null;
            }
        }
    }
}
