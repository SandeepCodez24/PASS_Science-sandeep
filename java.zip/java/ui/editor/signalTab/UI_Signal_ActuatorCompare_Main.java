package ui.editor.signalTab;

import java.io.InputStream;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

import ui.UI_Main;
import ui.editor.signalTab.SignalRegistry.Signal;

/**
 * Actuator signal comparison window, opened from the Compare zone of the
 * Actuators compare control.
 *
 * <p>
 * Two views over the same pair, switched by the Merged / Split toggle:
 * </p>
 *
 * <pre>
 *   Merged   one chart, both traces overlaid, shared axes
 *   Split    two charts stacked, one trace each, independent value axes
 * </pre>
 *
 * <p>
 * Merged answers "where do they diverge"; split answers "what does each one
 * actually look like", which matters when an artificial trace and a real one
 * sit at very different amplitudes and the overlay flattens the smaller of the
 * two. The footer carries the numbers behind the picture: sample count, RMS
 * difference and peak difference.
 * </p>
 *
 * <p>
 * Self-contained by design. The Sensors side has its own window class rather
 * than sharing this one, so the two can grow apart -- drive-side comparison
 * will want current and slew-rate limits that mean nothing on the sensor side.
 * </p>
 */
public final class UI_Signal_ActuatorCompare_Main {

    private static final String NAVY_BLUE = "#004073";
    private static final String FOOTER_GREY = "#d9dcdf";
    private static final String FOOTER_RULE = "#c2c7cc";
    private static final String ICON_PATH = "/icons/ic_18_nc.PNG";
    private static final String WINDOW_TITLE = "Compare Actuator Signals";

    /**
     * Upper bound on plotted points per trace. Beyond this the trace is
     * decimated: a JavaFX {@code LineChart} builds a node per data point, and
     * a few thousand of them is where panning starts to stutter.
     */
    private static final int MAX_POINTS = 1200;

    private static Stage window;

    private UI_Signal_ActuatorCompare_Main() {
    }

    /**
     * Opens the comparison window for one pair. Reopening with a different
     * pair refreshes the window in place rather than stacking a second one.
     *
     * @param ide        the IDE controller
     * @param artificial the drive trace chosen in the left selector
     * @param real       the delivered trace chosen in the right selector
     */
    public static void open(UI_Main ide, Signal artificial, Signal real) {
        if (artificial == null || real == null) {
            return;
        }

        if (window == null || !window.isShowing()) {
            window = new Stage();
            window.setTitle(WINDOW_TITLE);
            window.setResizable(true);
            window.initModality(Modality.NONE);
            window.setMinWidth(680);
            window.setMinHeight(460);
            applyWindowIcon(window);
            if (ide != null && ide.stage != null) {
                window.initOwner(ide.stage);
            }
            window.setOnHidden(event -> window = null);
        }

        Scene scene = new Scene(buildRoot(artificial, real), 900, 560);
        if (ide != null && ide.stage != null && ide.stage.getScene() != null) {
            scene.getStylesheets().addAll(ide.stage.getScene().getStylesheets());
        }
        window.setScene(scene);
        window.show();
        window.toFront();
        window.requestFocus();
    }

    // =====================================================================
    // Layout
    // =====================================================================

    private static BorderPane buildRoot(Signal a, Signal b) {

        Label title = new Label(WINDOW_TITLE);
        title.setStyle("-fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: bold;");

        Label subtitle = new Label(a.name() + "   vs   " + b.name());
        subtitle.setStyle("-fx-text-fill: #bcd3e8; -fx-font-size: 11.5px;");

        Region titleSpacer = new Region();
        HBox.setHgrow(titleSpacer, Priority.ALWAYS);

        HBox titleBar = new HBox(12, title, titleSpacer, subtitle);
        titleBar.setAlignment(Pos.CENTER_LEFT);
        titleBar.setPadding(new Insets(9, 14, 9, 14));
        titleBar.setStyle("-fx-background-color: " + NAVY_BLUE + ";");

        // --- the two views ------------------------------------------------
        LineChart<Number, Number> merged = chart("Time (s)", axisLabel(a, b), true);
        merged.getData().add(series(a));
        merged.getData().add(series(b));

        LineChart<Number, Number> topSplit = chart(null, axisLabel(a, a), true);
        topSplit.getData().add(series(a));

        LineChart<Number, Number> bottomSplit = chart("Time (s)", axisLabel(b, b), true);
        bottomSplit.getData().add(series(b));
        // Split view draws one series per chart, so both would otherwise take
        // the first series colour. This hook re-colours the lower chart to
        // match the second trace in the merged view.
        bottomSplit.getStyleClass().add("series-b");

        VBox split = new VBox(4, topSplit, bottomSplit);
        split.setFillWidth(true);
        VBox.setVgrow(topSplit, Priority.ALWAYS);
        VBox.setVgrow(bottomSplit, Priority.ALWAYS);

        StackPane views = new StackPane(merged, split);
        views.setPadding(new Insets(6, 8, 2, 8));

        // --- merge / split toggle -----------------------------------------
        ToggleGroup mode = new ToggleGroup();

        ToggleButton mergedBtn = modeButton("Merged", mode,
                "Both traces overlaid on one pair of axes");
        ToggleButton splitBtn = modeButton("Split", mode,
                "One chart per trace, stacked, with independent value axes");

        mode.selectedToggleProperty().addListener((obs, old, now) -> {
            // A ToggleGroup lets the selected button be clicked off. Put it
            // back rather than leaving both views hidden.
            if (now == null) {
                mode.selectToggle(old);
                return;
            }
            boolean showSplit = now == splitBtn;
            merged.setVisible(!showSplit);
            merged.setManaged(!showSplit);
            split.setVisible(showSplit);
            split.setManaged(showSplit);
        });
        mergedBtn.setSelected(true);
        split.setVisible(false);
        split.setManaged(false);

        Label viewLabel = new Label("View");
        viewLabel.getStyleClass().add("signal-compare-controls-label");

        HBox controls = new HBox(8, viewLabel, mergedBtn, splitBtn);
        controls.setAlignment(Pos.CENTER_LEFT);
        controls.setPadding(new Insets(7, 14, 7, 14));
        controls.getStyleClass().add("signal-compare-controls");

        // --- footer --------------------------------------------------------
        Label stats = new Label(statistics(a, b));
        stats.setStyle("-fx-text-fill: #33383d; -fx-font-size: 11.5px;");

        HBox footerBar = new HBox(stats);
        footerBar.setAlignment(Pos.CENTER_LEFT);
        footerBar.setPadding(new Insets(0, 14, 0, 14));
        footerBar.setMinHeight(27);
        footerBar.setPrefHeight(27);
        footerBar.setStyle(
                "-fx-background-color: " + FOOTER_GREY + ";"
                        + "-fx-border-color: " + FOOTER_RULE + " transparent transparent transparent;"
                        + "-fx-border-width: 1 0 0 0;");

        BorderPane root = new BorderPane();
        root.setTop(new VBox(titleBar, controls));
        root.setCenter(views);
        root.setBottom(footerBar);
        return root;
    }

    private static ToggleButton modeButton(String text, ToggleGroup group, String tip) {
        ToggleButton button = new ToggleButton(text);
        button.setToggleGroup(group);
        button.setFocusTraversable(false);
        button.setTooltip(new Tooltip(tip));
        button.getStyleClass().add("signal-compare-toggle");
        return button;
    }

    private static LineChart<Number, Number> chart(String xLabel, String yLabel, boolean legend) {
        NumberAxis x = new NumberAxis();
        x.setForceZeroInRange(false);
        if (xLabel != null) {
            x.setLabel(xLabel);
        }

        NumberAxis y = new NumberAxis();
        y.setForceZeroInRange(false);
        if (yLabel != null) {
            y.setLabel(yLabel);
        }

        LineChart<Number, Number> lineChart = new LineChart<>(x, y);
        lineChart.setCreateSymbols(false);
        lineChart.setAnimated(false);
        lineChart.setLegendVisible(legend);
        lineChart.getStyleClass().add("signal-compare-chart");
        return lineChart;
    }

    private static XYChart.Series<Number, Number> series(Signal signal) {
        XYChart.Series<Number, Number> series = new XYChart.Series<>();
        series.setName(signal.name());

        int stride = Math.max(1, signal.length() / MAX_POINTS);
        for (int i = 0; i < signal.length(); i += stride) {
            series.getData().add(new XYChart.Data<>(signal.timeAt(i), signal.sampleAt(i)));
        }
        return series;
    }

    private static String axisLabel(Signal a, Signal b) {
        String unit = a.unit();
        if (unit == null || unit.isBlank() || !unit.equals(b.unit())) {
            return "Amplitude";
        }
        return "Amplitude (" + unit + ")";
    }

    // =====================================================================
    // Numbers behind the picture
    // =====================================================================

    private static String statistics(Signal a, Signal b) {
        int n = Math.min(a.length(), b.length());
        if (n == 0) {
            return "Nothing to compare: one of the traces is empty";
        }

        double sumSquares = 0;
        double peak = 0;
        for (int i = 0; i < n; i++) {
            double delta = a.sampleAt(i) - b.sampleAt(i);
            sumSquares += delta * delta;
            peak = Math.max(peak, Math.abs(delta));
        }
        double rms = Math.sqrt(sumSquares / n);

        StringBuilder text = new StringBuilder();
        text.append("n = ").append(n)
                .append("     RMS \u0394 = ").append(String.format("%.4f", rms))
                .append("     peak \u0394 = ").append(String.format("%.4f", peak));

        if (a.sampleRate() != b.sampleRate()) {
            // Index-by-index differencing assumes a common time base. Say so
            // rather than quietly reporting a number that means little.
            text.append("     sample rates differ (")
                    .append(String.format("%.0f", a.sampleRate())).append(" Hz vs ")
                    .append(String.format("%.0f", b.sampleRate()))
                    .append(" Hz) \u2014 differenced sample by sample");
        } else if (a.length() != b.length()) {
            text.append("     lengths differ \u2014 compared over the shorter trace");
        }

        return text.toString();
    }

    /**
     * Loads the Neural Code icon from the classpath and applies it to the
     * stage. Failure to load is non-fatal: the window keeps the default icon.
     *
     * @param stage stage to decorate
     */
    private static void applyWindowIcon(Stage stage) {
        try (InputStream in = UI_Signal_ActuatorCompare_Main.class.getResourceAsStream(ICON_PATH)) {
            if (in == null) {
                System.err.println("Window icon not found on classpath: " + ICON_PATH);
                return;
            }
            Image icon = new Image(in);
            if (!icon.isError()) {
                stage.getIcons().add(icon);
            }
        } catch (Exception ex) {
            System.err.println("Failed to load window icon: " + ex.getMessage());
        }
    }
}
