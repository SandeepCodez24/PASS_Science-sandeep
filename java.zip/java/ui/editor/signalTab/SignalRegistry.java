package ui.editor.signalTab;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * The signal set behind the Signals ribbon's two compare controls.
 *
 * <p>
 * Four buckets, keyed by {@link Domain} and {@link Source}: the Sensors
 * control reads {@code SENSOR/ARTIFICIAL} on its left selector and
 * {@code SENSOR/REAL} on its right; Actuators reads the matching pair. Feed
 * Artificial, Feed Real, Deliver Artificial and Deliver Real will each publish
 * into their own bucket through {@link #add} once their windows are built.
 * </p>
 *
 * <p>
 * Until then the registry ships with demo waveforms so the selectors and the
 * comparison window are usable straight away. Every seeded entry is flagged
 * {@link Signal#isSample()} and shows a {@code (demo)} suffix in the drop-down,
 * so it is never mistaken for acquired data. Call
 * {@link #removeSamples(Domain, Source)} the first time a real feed lands in a
 * bucket and the demo entries step aside.
 * </p>
 */
public final class SignalRegistry {

    /** Which half of the ribbon a signal belongs to. */
    public enum Domain {
        /** Signals fed in from a sensor. */
        SENSOR,
        /** Signals delivered out to an actuator. */
        ACTUATOR
    }

    /** Where a signal came from. */
    public enum Source {
        /** Synthesized by the tool. */
        ARTIFICIAL,
        /** Acquired from hardware. */
        REAL
    }

    /** Sample rate of the seeded demo waveforms, in Hz. */
    private static final double DEMO_RATE = 200;

    /** Length of the seeded demo waveforms, in seconds. */
    private static final double DEMO_SECONDS = 2.0;

    private static final Map<Domain, Map<Source, List<Signal>>> STORE =
            new EnumMap<>(Domain.class);

    static {
        for (Domain domain : Domain.values()) {
            Map<Source, List<Signal>> bySource = new EnumMap<>(Source.class);
            for (Source source : Source.values()) {
                bySource.put(source, new CopyOnWriteArrayList<>());
            }
            STORE.put(domain, bySource);
        }
        seed();
    }

    private SignalRegistry() {
    }

    // =====================================================================
    // One signal
    // =====================================================================

    /**
     * A uniformly sampled trace: a name, a sample rate and the samples
     * themselves. Immutable, so a signal handed to a comparison window cannot
     * change underneath it while the window is open.
     */
    public static final class Signal {

        private final String name;
        private final double sampleRate;
        private final double[] samples;
        private final String unit;
        private final boolean sample;

        /**
         * @param name       display name, shown in the drop-down and the chart
         *                   legend
         * @param sampleRate sample rate in Hz; must be greater than zero
         * @param samples    the samples, copied defensively
         * @param unit       unit label for the value axis, e.g. {@code "V"}
         * @param sample     true for a built-in demo waveform
         */
        public Signal(String name, double sampleRate, double[] samples,
                String unit, boolean sample) {
            this.name = (name != null) ? name : "unnamed";
            this.sampleRate = (sampleRate > 0) ? sampleRate : 1;
            this.samples = (samples != null) ? samples.clone() : new double[0];
            this.unit = (unit != null) ? unit : "";
            this.sample = sample;
        }

        /**
         * @return display name
         */
        public String name() {
            return name;
        }

        /**
         * @return sample rate in Hz
         */
        public double sampleRate() {
            return sampleRate;
        }

        /**
         * @return a copy of the samples
         */
        public double[] samples() {
            return samples.clone();
        }

        /**
         * @param index sample index
         * @return the sample at {@code index}
         */
        public double sampleAt(int index) {
            return samples[index];
        }

        /**
         * @return number of samples
         */
        public int length() {
            return samples.length;
        }

        /**
         * @param index sample index
         * @return the time of that sample in seconds
         */
        public double timeAt(int index) {
            return index / sampleRate;
        }

        /**
         * @return length of the trace in seconds
         */
        public double duration() {
            return samples.length / sampleRate;
        }

        /**
         * @return unit label for the value axis
         */
        public String unit() {
            return unit;
        }

        /**
         * @return true if this is a built-in demo waveform
         */
        public boolean isSample() {
            return sample;
        }

        @Override
        public String toString() {
            return name;
        }
    }

    // =====================================================================
    // Store
    // =====================================================================

    /**
     * @param domain sensor or actuator side
     * @param source artificial or real
     * @return the bucket's contents, in insertion order; never null
     */
    public static List<Signal> list(Domain domain, Source source) {
        return Collections.unmodifiableList(new ArrayList<>(bucket(domain, source)));
    }

    /**
     * Publishes a signal into a bucket. Called by the Feed and Deliver windows
     * once they produce or acquire something.
     *
     * @param domain sensor or actuator side
     * @param source artificial or real
     * @param signal the signal; null is ignored
     */
    public static void add(Domain domain, Source source, Signal signal) {
        if (signal != null) {
            bucket(domain, source).add(signal);
        }
    }

    /**
     * Drops the built-in demo waveforms from one bucket, leaving anything
     * published through {@link #add} untouched.
     *
     * @param domain sensor or actuator side
     * @param source artificial or real
     */
    public static void removeSamples(Domain domain, Source source) {
        bucket(domain, source).removeIf(Signal::isSample);
    }

    /**
     * @param domain sensor or actuator side
     * @param source artificial or real
     * @return true if the bucket holds nothing
     */
    public static boolean isEmpty(Domain domain, Source source) {
        return bucket(domain, source).isEmpty();
    }

    /**
     * Names a signal for the drop-down: the plain name, with a {@code (demo)}
     * suffix on the built-in waveforms.
     *
     * @param signal the signal; null yields an em dash
     * @return the label to display
     */
    public static String displayName(Signal signal) {
        if (signal == null) {
            return "\u2014";
        }
        return signal.isSample() ? signal.name() + " (demo)" : signal.name();
    }

    private static List<Signal> bucket(Domain domain, Source source) {
        return STORE.get(domain).get(source);
    }

    // =====================================================================
    // Demo waveforms
    // =====================================================================

    private static void seed() {
        add(Domain.SENSOR, Source.ARTIFICIAL, sine("Sine 5 Hz", 5, 1.0));
        add(Domain.SENSOR, Source.ARTIFICIAL, square("Square 2 Hz", 2, 0.8));
        add(Domain.SENSOR, Source.ARTIFICIAL, chirp("Chirp 1-12 Hz", 1, 12, 0.9));
        add(Domain.SENSOR, Source.ARTIFICIAL, ramp("Ramp 1 Hz", 1, 1.0));

        add(Domain.SENSOR, Source.REAL, noisy(sine("Sine 5 Hz", 5, 0.94), "Noisy Sine 5 Hz", 0.09, 7));
        add(Domain.SENSOR, Source.REAL, noisy(ramp("Ramp 1 Hz", 1, 1.05), "Noisy Ramp 1 Hz", 0.07, 13));

        add(Domain.ACTUATOR, Source.ARTIFICIAL, sine("Sine 3 Hz", 3, 1.0));
        add(Domain.ACTUATOR, Source.ARTIFICIAL, square("Square 1 Hz", 1, 0.8));
        add(Domain.ACTUATOR, Source.ARTIFICIAL, ramp("Ramp 0.5 Hz", 0.5, 1.0));

        add(Domain.ACTUATOR, Source.REAL,
                noisy(sine("Sine 3 Hz", 3, 0.91), "Noisy Sine 3 Hz", 0.08, 21));
        add(Domain.ACTUATOR, Source.REAL,
                noisy(square("Square 1 Hz", 1, 0.77), "Noisy Square 1 Hz", 0.10, 29));
    }

    private static int demoLength() {
        return (int) Math.round(DEMO_RATE * DEMO_SECONDS);
    }

    private static Signal sine(String name, double frequency, double amplitude) {
        int n = demoLength();
        double[] data = new double[n];
        for (int i = 0; i < n; i++) {
            data[i] = amplitude * Math.sin(2 * Math.PI * frequency * (i / DEMO_RATE));
        }
        return new Signal(name, DEMO_RATE, data, "V", true);
    }

    private static Signal square(String name, double frequency, double amplitude) {
        int n = demoLength();
        double[] data = new double[n];
        for (int i = 0; i < n; i++) {
            double phase = (frequency * (i / DEMO_RATE)) % 1.0;
            data[i] = (phase < 0.5) ? amplitude : -amplitude;
        }
        return new Signal(name, DEMO_RATE, data, "V", true);
    }

    private static Signal chirp(String name, double startHz, double endHz, double amplitude) {
        int n = demoLength();
        double[] data = new double[n];
        double rate = (endHz - startHz) / DEMO_SECONDS;
        for (int i = 0; i < n; i++) {
            double t = i / DEMO_RATE;
            double phase = 2 * Math.PI * (startHz * t + 0.5 * rate * t * t);
            data[i] = amplitude * Math.sin(phase);
        }
        return new Signal(name, DEMO_RATE, data, "V", true);
    }

    private static Signal ramp(String name, double frequency, double amplitude) {
        int n = demoLength();
        double[] data = new double[n];
        for (int i = 0; i < n; i++) {
            double phase = (frequency * (i / DEMO_RATE)) % 1.0;
            data[i] = amplitude * (2 * phase - 1);
        }
        return new Signal(name, DEMO_RATE, data, "V", true);
    }

    /**
     * Adds band-limited-looking noise to an existing waveform. The generator is
     * seeded, so the demo set is identical on every run and a comparison made
     * yesterday still matches one made today.
     */
    private static Signal noisy(Signal base, String name, double level, long seed) {
        Random random = new Random(seed);
        double[] data = base.samples();
        double drift = 0;
        for (int i = 0; i < data.length; i++) {
            drift = 0.85 * drift + random.nextGaussian() * level;
            data[i] += drift;
        }
        return new Signal(name, base.sampleRate(), data, base.unit(), true);
    }
}
