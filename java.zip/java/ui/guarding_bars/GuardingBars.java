package ui.guarding_bars;

import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Region;

/**
 * Puts the two guarding bars into the main window.
 *
 * <h3>Placement</h3>
 * <p>
 * The bars are the {@code left} and {@code right} of the window's
 * {@link BorderPane}. A BorderPane gives its top (ribbon and quick-access
 * row) and bottom (footer) the full width and puts left / centre / right
 * between them, so the bars run exactly from below the breadcrumb down to the
 * footer, outside every layout {@code LayoutManager} builds.
 * </p>
 *
 * <h3>Colour</h3>
 * <p>
 * The bars share one colour with the ribbon's tool band and the footer:
 * {@code -astra-chrome}, in {@code themes/shared/palette_light.css} and
 * {@code palette_dark.css}. Their rules -- the fill and the inner-edge line,
 * which is the same grey as the dividers and the line under the quick-access
 * row -- are in {@code themes/shared/surfaces.css} (section 5), and the line's
 * width comes from {@code Dim.GuardingBars.INNER_LINE} through the generated
 * sheet. Both shared sheets are already on the scene, so nothing is attached
 * here any more; {@code themes/guarding_bars/guarding_light.css} and
 * {@code guarding_dark.css} are no longer used and can be deleted.
 * </p>
 */
public final class GuardingBars {

    private static guarding_leftbar left;
    private static guarding_rightbar right;

    private GuardingBars() {
    }

    /**
     * Builds both bars and places them either side of the layout host.
     *
     * @param root   the window's root pane
     * @param center the layout host returned by {@code LayoutManager.install};
     *               kept in the signature so the call site stays as it is
     */
    public static void install(BorderPane root, Region center) {
        if (root == null) {
            return;
        }
        left = new guarding_leftbar();
        right = new guarding_rightbar();
        root.setLeft(left);
        root.setRight(right);
    }

    /** @return the left bar, or null before {@link #install} */
    public static guarding_leftbar left() {
        return left;
    }

    /** @return the right bar, or null before {@link #install} */
    public static guarding_rightbar right() {
        return right;
    }
}
