package ui.account;

import javafx.application.Platform;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.image.ImageView;
import ui.ui_functions.tools.ToolbarIcons;

/**
 * A SINGLE ribbon control that represents the user's account/license state.
 *
 * <p>Behaviour (as clarified by the design):
 * <ul>
 *   <li><b>Signed OUT</b> &rarr; the control simply reads "Sign in". Clicking
 *       it starts the sign-in flow (license validation against the server).</li>
 *   <li><b>Signed IN</b> &rarr; the control shows the user's name with a
 *       dropdown arrow. The dropdown exposes exactly two items:
 *       <b>My Account</b> and <b>Sign out</b>.</li>
 * </ul>
 *
 * <p>All server/license calls are routed through {@link AccountService}, which
 * is currently a DUMMY stub. Replace its method bodies with the real
 * internet/license-server integration later; the UI here will not need to
 * change.
 *
 * <p>Lives in {@code ui.account} rather than {@code ui.ui_functions.tools}:
 * this is account and licensing state, not a toolbar widget, and the ribbon
 * is only one of the places it may end up being shown. Anything outside this
 * package reaches the stub as {@code AccountMenu.AccountService}, so an
 * {@code import ui.account.AccountMenu;} is enough.
 */
public final class AccountMenu {

    private final MenuButton control = new MenuButton();
    private final MenuItem myAccountItem = new MenuItem("My Account");
    private final MenuItem signOutItem = new MenuItem("Sign out");

    public AccountMenu() {
        control.getStyleClass().add("account-menu");
        control.setFocusTraversable(false);
        // White text + arrow on the navy ribbon; transparent background.
        control.setStyle(
                "-fx-background-color: transparent;"
                        + "-fx-text-fill: white;"
                        + "-fx-font-weight: bold;"
                        + "-fx-font-size: 12;"
                        + "-fx-mark-color: white;"
                        + "-fx-padding: 4 8;");

        // Signed-in dropdown items.
        myAccountItem.setOnAction(e -> onMyAccount());
        signOutItem.setOnAction(e -> onSignOut());

        // When signed OUT, clicking the control itself should sign in.
        // A MenuButton normally just opens its popup, so we intercept the
        // action and, if there are no items (signed-out state), sign in.
        control.setOnMouseClicked(e -> {
            if (!AccountService.isSignedIn()) {
                onSignIn();
                e.consume();
            }
        });

        refresh();
    }

    /** The node to add into the ribbon's right-cluster. */
    public MenuButton getNode() {
        return control;
    }

    // ---- State-driven rendering -------------------------------------------

    /** Rebuilds the control to match the current sign-in state. */
    public void refresh() {
        if (AccountService.isSignedIn()) {
            control.setText(AccountService.getDisplayName());
            control.setGraphic(icon("/icons/ic_account.png"));
            // Show the dropdown arrow + the two options.
            control.getItems().setAll(myAccountItem, signOutItem);
        } else {
            control.setText("Sign in");
            control.setGraphic(icon("/icons/NC_ribbon/ic_signin.png"));
            // No items -> the whole control behaves as a single "Sign in" button.
            control.getItems().clear();
        }
    }

    private ImageView icon(String path) {
        try {
            return ToolbarIcons.icon(path);
        } catch (Exception ex) {
            return null;
        }
    }

    // ---- Actions (each talks to the license/server layer) -----------------

    private void onSignIn() {
        // Kept synchronous + dummy for now. When wired to the real server,
        // do the network call off the FX thread and update UI via runLater.
        boolean ok = AccountService.signIn();
        Platform.runLater(this::refresh);
        if (!ok) {
            System.err.println("Sign-in failed (dummy).");
        }
    }

    private void onSignOut() {
        AccountService.signOut();
        Platform.runLater(this::refresh);
    }

    private void onMyAccount() {
        AccountService.openMyAccount();
    }

    // =======================================================================
    // DUMMY license/account service.
    // Replace each method body with the real internet/license-server logic.
    // The UI above is already wired to call these at the right moments.
    // =======================================================================
    public static final class AccountService {
        private static boolean signedIn = false;
        private static String displayName = "";

        private AccountService() {}

        public static boolean isSignedIn() {
            return signedIn;
        }

        public static String getDisplayName() {
            return displayName.isBlank() ? "Account" : displayName;
        }

        /**
         * DUMMY sign-in. TODO: call the license server over the internet,
         * validate the license, and return true only on success.
         */
        public static boolean signIn() {
            // --- placeholder: pretend the server approved the license ---
            signedIn = true;
            displayName = "Sivaraman";
            System.out.println("[AccountService] (dummy) signed in as " + displayName);
            return true;
        }

        /**
         * DUMMY sign-out. TODO: notify the server / release the license seat.
         */
        public static void signOut() {
            System.out.println("[AccountService] (dummy) signing out " + displayName);
            signedIn = false;
            displayName = "";
        }

        /**
         * DUMMY "My Account". TODO: open the account/license portal or a
         * details dialog populated from the server response.
         */
        public static void openMyAccount() {
            System.out.println("[AccountService] (dummy) open My Account / license details");
        }
    }
}
