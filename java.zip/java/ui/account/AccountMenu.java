package ui.account;

import javafx.scene.control.Alert;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.image.ImageView;
import javafx.stage.Window;
import ui.managers.ThemeManager;
import ui.ui_functions.tools.ToolbarIcons;

/**
 * A SINGLE ribbon control that represents the user's account/license state.
 *
 * <p>Behaviour:
 * <ul>
 *   <li><b>Signed OUT</b> &rarr; the control simply reads "Sign in". Clicking
 *       it starts the sign-in flow.</li>
 *   <li><b>Signed IN</b> &rarr; the control shows the user's name with a
 *       dropdown arrow. The dropdown exposes exactly two items:
 *       <b>My Account</b> and <b>Sign out</b>.</li>
 * </ul>
 *
 * <h3>This edition</h3>
 * <p>Astra currently ships without a license server, so there is nothing to
 * sign in to. {@link AccountService#signIn()} reports that honestly and the
 * control explains it in a small dialog, instead of pretending a sign-in
 * succeeded. When the server exists, only {@link AccountService} changes; the
 * UI here is already wired to call it at the right moments.
 *
 * <p>Lives in {@code ui.account} rather than {@code ui.ui_functions.tools}:
 * this is account and licensing state, not a toolbar widget, and the ribbon
 * is only one of the places it may end up being shown. Anything outside this
 * package reaches the service as {@code AccountMenu.AccountService}, so an
 * {@code import ui.account.AccountMenu;} is enough.
 */
public final class AccountMenu {

    private static final String DIALOG_TITLE = "Account";

    private final MenuButton control = new MenuButton();
    private final MenuItem myAccountItem = new MenuItem("My Account");
    private final MenuItem signOutItem = new MenuItem("Sign out");

    public AccountMenu() {
        control.getStyleClass().add("account-menu");
        control.setFocusTraversable(false);
        // White text + arrow on the navy ribbon; transparent background.
        control.setStyle(
                "-fx-background-color: transparent;"
                        + "-fx-text-fill: white;"
                        + "-fx-font-weight: bold;"
                        + "-fx-font-size: 12;"
                        + "-fx-mark-color: white;"
                        + "-fx-padding: 4 8;");

        // Signed-in dropdown items.
        myAccountItem.setOnAction(e -> onMyAccount());
        signOutItem.setOnAction(e -> onSignOut());

        // When signed OUT, clicking the control itself should sign in.
        // A MenuButton normally just opens its popup, so the click is
        // intercepted and, in the signed-out state, starts sign-in instead.
        control.setOnMouseClicked(e -> {
            if (!AccountService.isSignedIn()) {
                e.consume();
                onSignIn();
            }
        });

        refresh();
    }

    /** @return the node to add into the ribbon's right-hand cluster */
    public MenuButton getNode() {
        return control;
    }

    // ---- State-driven rendering -------------------------------------------

    /** Rebuilds the control to match the current sign-in state. */
    public void refresh() {
        if (AccountService.isSignedIn()) {
            control.setText(AccountService.getDisplayName());
            control.setGraphic(icon("/icons/ic_account.png"));
            // Show the dropdown arrow + the two options.
            control.getItems().setAll(myAccountItem, signOutItem);
        } else {
            control.setText("Sign in");
            control.setGraphic(icon("/icons/NC_ribbon/ic_signin.png"));
            // No items -> the whole control behaves as a single "Sign in" button.
            control.getItems().clear();
        }
    }

    private ImageView icon(String path) {
        try {
            return ToolbarIcons.icon(path);
        } catch (Exception ex) {
            return null;
        }
    }

    // ---- Actions ----------------------------------------------------------

    private void onSignIn() {
        if (AccountService.signIn()) {
            refresh();
        } else {
            showInfo("Sign-in is not available yet",
                    "This version of Astra works fully without an account. "
                            + "Online sign-in and license management will arrive in a later release.");
        }
    }

    private void onSignOut() {
        AccountService.signOut();
        refresh();
    }

    private void onMyAccount() {
        showInfo(AccountService.getDisplayName(), AccountService.accountSummary());
    }

    /** Small themed information dialog, owned by the window the control sits in. */
    private void showInfo(String header, String body) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(DIALOG_TITLE);
        alert.setHeaderText(header);
        alert.setContentText(body);
        Window owner = control.getScene() != null ? control.getScene().getWindow() : null;
        if (owner != null) {
            alert.initOwner(owner);
        }
        ThemeManager.registerScene(alert.getDialogPane().getScene());
        alert.show();
    }

    // =======================================================================
    // Account / license service.
    //
    // The single place that will talk to the license server. In this edition
    // there is no server, so sign-in is reported as unavailable and the
    // signed-in state can never be reached. Replacing these method bodies is
    // the only change needed when the server arrives.
    // =======================================================================
    public static final class AccountService {
        private static boolean signedIn = false;
        private static String displayName = "";

        private AccountService() {
        }

        /** @return true while a user is signed in */
        public static boolean isSignedIn() {
            return signedIn;
        }

        /** @return the signed-in user's name, or "Account" if none is known */
        public static String getDisplayName() {
            return displayName.isBlank() ? "Account" : displayName;
        }

        /**
         * Validates the user's license with the license server and signs in.
         *
         * <p>This edition has no license server, so this always returns false
         * and the signed-out state is kept. Running the network call off the
         * FX thread belongs here once the server exists; the caller only needs
         * the boolean.
         *
         * @return true only when the server approved the license
         */
        public static boolean signIn() {
            return false;
        }

        /**
         * Signs out locally. With a license server this is also where the
         * license seat is released.
         */
        public static void signOut() {
            signedIn = false;
            displayName = "";
        }

        /** @return the text shown in the My Account dialog */
        public static String accountSummary() {
            return signedIn
                    ? "Signed in as " + getDisplayName() + "."
                    : "Not signed in.";
        }
    }
}
