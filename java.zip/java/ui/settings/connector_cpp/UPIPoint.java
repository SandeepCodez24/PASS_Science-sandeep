package ui.settings.connector_cpp;

public record UPIPoint(double x, double y) {
}