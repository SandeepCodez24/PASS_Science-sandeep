package ui.settings.connector_cpp;

public record UPIVariable(String name, String value, String size, String datatype) {
}