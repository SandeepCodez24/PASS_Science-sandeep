package ui.codebot;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import javafx.application.Platform;
import javafx.css.PseudoClass;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Tab;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import ui.UI_Main;
import ui.codebot.service.ChatMessage;
import ui.codebot.service.CodeBotRequest;
import ui.codebot.service.CodeBotService;
import ui.codebot.service.CodeBotServices;
import ui.design.Dim;
import ui.design.section_dims.CodeBot_dim;
import ui.directory.DirectoryFont;
import ui.directory.DirectoryTreeBuilder;
import ui.editor.EditorFileInfo;
import ui.explorer.PanelTitleBar;
import ui.ui_functions.tools.HomeRibbonIcons;

/**
 * The Code Bot Assistant: a chat panel that opens at the bottom of the File
 * Explorer.
 *
 * <pre>
 *   +--------------------------------------------------------------+
 *   | [bot] Code Bot Assistant        ( Offline )      [+]  [x]    |  title strip
 *   +--------------------------------------------------------------+
 *   |  [o] Hello! I'm Code Bot ...                                  |
 *   |      ( How do I write a function? ) ( Show me ... ) ...  |  conversation
 *   |                                   +------------------------+ |
 *   |                                   | user question          | |
 *   |                                   +------------------------+ |
 *   |  [o] API Connection is needed                                 |
 *   +--------------------------------------------------------------+
 *   |  +--------------------------------------------------+  [>]   |  input
 *   |  Enter to send  ·  Shift+Enter for a new line                 |
 *   +--------------------------------------------------------------+
 * </pre>
 *
 * <h3>Title strip</h3>
 * <p>
 * A {@link PanelTitleBar} of its own, registered with {@code PanelActivation}
 * as the {@code CODE_BOT} region: it turns navy when the bot is the panel
 * last clicked, and grey otherwise -- independently of the File Explorer
 * strip above it, like the Command Window and Variable Explorer. The chip
 * shows whether a real back end is connected. {@code [+]} starts a new
 * conversation; {@code [x]} closes the panel (the ribbon's Code Bot button
 * toggles it too).
 * </p>
 *
 * <h3>Back end</h3>
 * <p>
 * Questions go to {@link CodeBotServices#get()}, today the dummy service that
 * answers "API Connection is needed". Each request carries the conversation
 * so far, the file open in the editor and the explorer's folder, ready for the
 * retrieval step. Replies are matched to the conversation they were asked in,
 * so a late reply after "new conversation" is dropped.
 * </p>
 *
 * <h3>Font</h3>
 * <p>
 * All the bot's text uses the File Explorer's row font (the breadcrumb font),
 * through {@link DirectoryFont}, instead of the larger default. Secondary
 * text is {@code 0.85} of it.
 * </p>
 */
public final class CodeBotPanel extends VBox {

    private static final PseudoClass CONNECTED = PseudoClass.getPseudoClass("connected");

    private static final String WELCOME = "Hello! I'm Code Bot, your Neural Code assistant.\n"
            + "Ask me about syntax, built-in functions, error messages or how to structure a script.";

    /** Starter questions shown under the welcome message. */
    private static final List<String> SUGGESTIONS = List.of(
            "How do I write a function?",
            "Show me an example class",
            "Explain the last error");

    private final UI_Main ide;
    private final Runnable onClose;

    private final PanelTitleBar titleBar;
    private final Label status = new Label();
    private final Label hint = new Label("Enter to send  \u00b7  Shift+Enter for a new line");
    private DirectoryFont font = DirectoryFont.current();
    private final VBox messages = new VBox();
    private final ScrollPane scroll = new ScrollPane(messages);
    private final CodeBotInput input;

    private final List<ChatMessage> history = new ArrayList<>();
    private Node suggestions;
    private CodeBotMessageView.Typing typing;

    /** Bumped by "new conversation", so replies to older questions are ignored. */
    private int conversation;

    /** Keep the view at the bottom while new content arrives. */
    private boolean pinBottom = true;

    /**
     * @param ide     the IDE controller
     * @param onClose run by the title strip's close button
     */
    public CodeBotPanel(UI_Main ide, Runnable onClose) {
        this.ide = ide;
        this.onClose = onClose;
        getStyleClass().add("code-bot-panel");
        setMinHeight(CodeBot_dim.PANEL_MIN_HEIGHT);

        titleBar = buildHeader();

        messages.getStyleClass().add("code-bot-messages");
        messages.setSpacing(CodeBot_dim.MESSAGE_GAP);
        messages.setPadding(new Insets(CodeBot_dim.LIST_PADDING));
        messages.setFillWidth(true);

        scroll.getStyleClass().add("code-bot-scroll");
        scroll.setFitToWidth(true);
        scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scroll.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        VBox.setVgrow(scroll, Priority.ALWAYS);
        scroll.vvalueProperty().addListener((o, was, isNow) ->
                pinBottom = isNow.doubleValue() >= scroll.getVmax() - 0.02);
        messages.heightProperty().addListener(o -> {
            if (pinBottom) {
                scroll.setVvalue(scroll.getVmax());
            }
        });

        input = new CodeBotInput(this::ask);
        hint.getStyleClass().add("code-bot-hint");
        VBox inputArea = new VBox(4, input, hint);
        inputArea.getStyleClass().add("code-bot-input-area");
        inputArea.setPadding(new Insets(CodeBot_dim.INPUT_OUTER_PADDING));

        getChildren().addAll(titleBar.getNode(), scroll, inputArea);
        applyFont();
        startConversation();
    }

    /** @return the title strip, for registration with {@code PanelActivation} */
    public PanelTitleBar titleBar() {
        return titleBar;
    }

    /**
     * Re-reads the explorer's row font and applies it to the parts that stay
     * on screen (question box, hint, status chip, suggestions). Messages take
     * the font current when they are added.
     */
    public void refreshFont() {
        font = DirectoryFont.current();
        applyFont();
        if (suggestions instanceof FlowPane chips) {
            chips.getChildren().forEach(chip -> chip.setStyle(font.css()));
        }
    }

    private void applyFont() {
        input.setFontStyle(font.css());
        hint.setStyle(font.css(CodeBotMessageView.SMALL));
        status.setStyle(font.css(CodeBotMessageView.SMALL));
    }

    /** Puts the keyboard focus in the question box. */
    public void focusInput() {
        input.focus();
    }

    /** Clears the conversation and shows the welcome message again. */
    public void newConversation() {
        CodeBotServices.get().cancelAll();
        conversation++;
        stopTyping();
        input.busyProperty().set(false);
        history.clear();
        messages.getChildren().clear();
        startConversation();
        focusInput();
    }

    // =====================================================================
    // Title strip
    // =====================================================================

    /**
     * A standard panel strip with the bot's icon before the title, the
     * status chip after it, and the new-conversation and close buttons at the
     * right end.
     */
    private PanelTitleBar buildHeader() {
        PanelTitleBar strip = PanelTitleBar.create("Code Bot Assistant");
        HBox bar = strip.getNode();
        bar.getStyleClass().add("code-bot-header");

        status.getStyleClass().add("code-bot-status");
        refreshStatus();

        Button fresh = glyphButton(CodeBotGlyphs.newChat(CodeBot_dim.HEADER_GLYPH_SIZE), "New conversation");
        fresh.setOnAction(event -> newConversation());
        Button close = glyphButton(CodeBotGlyphs.close(CodeBot_dim.HEADER_GLYPH_SIZE), "Close Code Bot");
        close.setOnAction(event -> onClose.run());

        // The strip is [title, spacer]; put the icon before the title and
        // the chip right after it, and the buttons at the end.
        bar.getChildren().add(0, HomeRibbonIcons.icon("ic_h_06_code_bot", CodeBot_dim.HEADER_ICON_SIZE));
        bar.getChildren().add(2, status);
        bar.getChildren().addAll(fresh, close);
        bar.setSpacing(6);
        return strip;
    }

    private static Button glyphButton(Node glyph, String tip) {
        double box = Dim.TitleBar.GLYPH_BUTTON_SIZE;
        Button button = new Button("", glyph);
        button.getStyleClass().add("panel-title-button");
        button.setFocusTraversable(false);
        button.setMinSize(box, box);
        button.setPrefSize(box, box);
        button.setMaxSize(box, box);
        button.setTooltip(new Tooltip(tip));
        return button;
    }

    private void refreshStatus() {
        boolean connected = CodeBotServices.get().isConnected();
        status.setText(connected ? "Online" : "Offline");
        status.pseudoClassStateChanged(CONNECTED, connected);
        status.setTooltip(new Tooltip(connected
                ? "Connected to the Code Bot service"
                : "No Code Bot service is connected yet"));
    }

    // =====================================================================
    // Conversation
    // =====================================================================

    private void startConversation() {
        refreshStatus();
        appendView(ChatMessage.bot(WELCOME, ChatMessage.Kind.NORMAL), false);

        FlowPane chips = new FlowPane(6, 6);
        chips.getStyleClass().add("code-bot-suggestions");
        chips.setPadding(new Insets(0, 0, 0, CodeBot_dim.AVATAR_SIZE + CodeBot_dim.AVATAR_GAP));
        for (String question : SUGGESTIONS) {
            Button chip = new Button(question);
            chip.getStyleClass().add("code-bot-chip");
            chip.setStyle(font.css());
            chip.setFocusTraversable(false);
            chip.setOnAction(event -> input.sendText(question));
            chips.getChildren().add(chip);
        }
        suggestions = chips;
        messages.getChildren().add(chips);
    }

    /** Sends one question to the service and shows the reply when it comes. */
    private void ask(String question) {
        if (suggestions != null) {
            messages.getChildren().remove(suggestions);
            suggestions = null;
        }
        ChatMessage asked = ChatMessage.user(question);
        CodeBotRequest request = new CodeBotRequest(question, history, activeFile(),
                DirectoryTreeBuilder.rootFolder());
        appendView(asked, true);

        input.busyProperty().set(true);
        startTyping();

        int askedIn = conversation;
        CodeBotService service = CodeBotServices.get();
        try {
            service.ask(request).whenComplete((reply, failure) -> Platform.runLater(() -> {
                if (askedIn != conversation) {
                    return; // the user started a new conversation meanwhile
                }
                stopTyping();
                input.busyProperty().set(false);
                if (failure != null || reply == null) {
                    String why = failure == null ? "No reply." : rootMessage(failure);
                    appendView(ChatMessage.bot("Code Bot could not answer: " + why, ChatMessage.Kind.ERROR), true);
                } else {
                    appendView(ChatMessage.bot(reply.text(), reply.kind()), true);
                }
                refreshStatus();
            }));
        } catch (RuntimeException ex) {
            stopTyping();
            input.busyProperty().set(false);
            appendView(ChatMessage.bot("Code Bot could not answer: " + rootMessage(ex), ChatMessage.Kind.ERROR), true);
        }
    }

    private void appendView(ChatMessage message, boolean remember) {
        if (remember) {
            history.add(message);
        }
        pinBottom = true;
        int at = typing == null ? messages.getChildren().size()
                : messages.getChildren().indexOf(typing.node());
        messages.getChildren().add(Math.max(0, at), CodeBotMessageView.build(message, scroll.widthProperty()
                .subtract(2 * CodeBot_dim.LIST_PADDING + 16), font));
    }

    private void startTyping() {
        stopTyping();
        typing = CodeBotMessageView.typing();
        pinBottom = true;
        messages.getChildren().add(typing.node());
    }

    private void stopTyping() {
        if (typing != null) {
            typing.stop();
            messages.getChildren().remove(typing.node());
            typing = null;
        }
    }

    /** The file in the selected editor tab, or null. */
    private Path activeFile() {
        if (ide == null || ide.editorTabs == null) {
            return null;
        }
        Tab tab = ide.editorTabs.getSelectionModel().getSelectedItem();
        return tab != null && tab.getUserData() instanceof EditorFileInfo info ? info.path : null;
    }

    private static String rootMessage(Throwable failure) {
        Throwable t = failure;
        while (t.getCause() != null && t.getCause() != t) {
            t = t.getCause();
        }
        String message = t.getMessage();
        return message == null || message.isBlank() ? t.getClass().getSimpleName() : message;
    }
}
