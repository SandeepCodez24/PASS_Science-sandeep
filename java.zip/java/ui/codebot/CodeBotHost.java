package ui.codebot;

import javafx.application.Platform;
import javafx.geometry.Orientation;
import javafx.scene.Node;
import javafx.scene.control.SplitPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import ui.UI_Main;
import ui.design.Dim;
import ui.design.section_dims.CodeBot_dim;
import ui.explorer.CollapsiblePanel;
import ui.explorer.PanelActivation;
import ui.layout.LayoutManager;

/**
 * Owns the Code Bot panel's open / closed state, builds the File Explorer's
 * body, and docks the bot where the current layout asks for it.
 *
 * <pre>
 *   File Explorer panel body (Default layout)
 *   +-----------------------------------+
 *   |  directory tree                   |   60%
 *   |===================================|   <- draggable divider
 *   |  Code Bot Assistant          [x]  |   40%
 *   +-----------------------------------+
 * </pre>
 *
 * <h3>Where the bot goes</h3>
 * <p>
 * {@link #show()} and {@link #hide()} flip the open state and hand the
 * placement to {@link LayoutManager#dockBot}. The Home ribbon's Code Bot
 * button calls {@link #toggle(UI_Main)}.
 * </p>
 *
 * <h3>Static layouts</h3>
 * <ul>
 * <li>The bot's own close button works only in Default
 * ({@link #setCloseEnabled}); elsewhere it is faded.</li>
 * <li>In the layouts built around the bot (Bot Centered, Editor-Bot-CLI,
 * Custom with Chat Bot ticked) it cannot be closed at all, not even from
 * the ribbon ({@link LayoutManager#isBotPinned()}).</li>
 * <li>In a Custom layout without Chat Bot the bot does not open; the
 * Command Window says so ({@link LayoutManager#canShowBot()}).</li>
 * </ul>
 */
public final class CodeBotHost {

    private static final String BODY_CLASS = "file-explorer-body";

    private static UI_Main ideRef;
    private static CollapsiblePanel explorer;
    private static SplitPane split;
    private static Node tree;
    private static CodeBotPanel bot;

    /** The user's intent: open or closed, independent of where it is docked. */
    private static boolean open;

    /** Whether the bot's own close button works in the current layout. */
    private static boolean closeEnabled = true;

    private CodeBotHost() {
    }

    // =====================================================================
    // Construction
    // =====================================================================

    /**
     * Builds the File Explorer's body: a vertical split that holds the tree
     * (and, when docked there, the bot).
     *
     * @param ide      the IDE controller
     * @param treeNode the directory tree
     * @return the body to hand to the File Explorer's {@link CollapsiblePanel}
     */
    public static Node buildBody(UI_Main ide, Node treeNode) {
        ideRef = ide;
        tree = treeNode;

        split = new SplitPane(treeNode);
        split.setOrientation(Orientation.VERTICAL);
        split.getStyleClass().add("code-bot-split");
        if (treeNode instanceof Region region) {
            region.setMinHeight(CodeBot_dim.TREE_MIN_HEIGHT);
        }
        HBox.setHgrow(split, Priority.ALWAYS);

        HBox body = new HBox(split);
        body.getStyleClass().add(BODY_CLASS);
        body.setFillHeight(true);
        return body;
    }

    /**
     * Connects the body to its panel.
     *
     * @param panel     the File Explorer panel built around {@link #buildBody}
     * @param mainSplit no longer used; kept so the call sites stay as they are
     */
    public static void attach(CollapsiblePanel panel, SplitPane mainSplit) {
        explorer = panel;
    }

    /**
     * The bot panel, created on first use. The conversation lives in it, so
     * the same instance moves between layouts.
     *
     * @return the Code Bot panel
     */
    public static CodeBotPanel panel() {
        if (bot == null) {
            bot = new CodeBotPanel(ideRef, CodeBotHost::hide);
            bot.setCloseEnabled(closeEnabled);
            PanelActivation.register(PanelActivation.Panel.CODE_BOT, bot.titleBar(), bot);
        }
        return bot;
    }

    /**
     * Fades the bot's close button (static layouts) or brings it back
     * (Default). Called by {@code LayoutManager} after every layout build.
     *
     * @param enabled true to let the close button work
     */
    public static void setCloseEnabled(boolean enabled) {
        closeEnabled = enabled;
        if (bot != null) {
            bot.setCloseEnabled(enabled);
        }
    }

    // =====================================================================
    // Open / close
    // =====================================================================

    /**
     * The ribbon's Code Bot button: opens the bot, or closes it if open
     * (unless the layout is built around it).
     *
     * @param ide the IDE controller
     */
    public static void toggle(UI_Main ide) {
        if (ide != null) {
            ideRef = ide;
        }
        if (isShowing()) {
            hide();
        } else {
            show();
        }
    }

    /** @return true while the bot is open, wherever it is docked */
    public static boolean isShowing() {
        return open;
    }

    /** Opens the bot where the current layout docks it, and focuses it. */
    public static void show() {
        if (!LayoutManager.canShowBot()) {
            LayoutManager.notice("The Code Bot is not part of this Custom layout.");
            return;
        }
        CodeBotPanel panel = panel();
        panel.refreshFont();
        open = true;
        if (!LayoutManager.dockBot(true)) {
            placeInExplorer(CodeBot_dim.OPEN_DIVIDER_POSITION);
        }
        PanelActivation.setActive(PanelActivation.Panel.CODE_BOT);
        panel.focusInput();
    }

    /** Closes the bot; its neighbour takes the space back. */
    public static void hide() {
        if (!open || LayoutManager.isBotPinned()) {
            return;
        }
        open = false;
        if (!LayoutManager.dockBot(false)) {
            removeFromExplorer();
        }
        if (isExplorerOnScreen()) {
            PanelActivation.setActive(PanelActivation.Panel.FILE_EXPLORER);
            if (tree != null) {
                tree.requestFocus();
            }
        } else {
            PanelActivation.setActive(PanelActivation.Panel.EDITOR);
        }
    }

    /**
     * Marks the bot closed without touching the window. {@code LayoutManager}
     * uses this while it tears a layout down.
     */
    public static void markClosed() {
        open = false;
    }

    // =====================================================================
    // Docking inside the File Explorer
    // =====================================================================

    /**
     * Puts the bot under the tree, expanding a collapsed explorer first.
     *
     * @param dividerPosition tree share of the explorer's height, e.g. 0.60
     */
    public static void placeInExplorer(double dividerPosition) {
        if (split == null) {
            return;
        }
        CodeBotPanel panel = panel();
        SplitPane.setResizableWithParent(panel, Boolean.FALSE);
        panel.setMinWidth(Region.USE_COMPUTED_SIZE);
        if (explorer != null && explorer.isCollapsed()) {
            explorer.setCollapsed(false);
        }
        if (!split.getItems().contains(panel)) {
            split.getItems().add(panel);
        }
        split.setDividerPositions(dividerPosition);
        Platform.runLater(() -> split.setDividerPositions(dividerPosition));
    }

    /** Takes the bot out of the explorer; the tree gets the full height. */
    public static void removeFromExplorer() {
        if (split != null && bot != null) {
            split.getItems().remove(bot);
        }
    }

    /**
     * Readies the bot for docking in a column of its own: resizable with its
     * split, and never narrower than {@code Dim.Layout.BOT_COLUMN_MIN_WIDTH}.
     *
     * @return the bot panel
     */
    public static CodeBotPanel prepareForColumn() {
        CodeBotPanel panel = panel();
        SplitPane.setResizableWithParent(panel, Boolean.TRUE);
        panel.setMinWidth(Dim.Layout.BOT_COLUMN_MIN_WIDTH);
        return panel;
    }

    private static boolean isExplorerOnScreen() {
        return explorer != null && explorer.getScene() != null;
    }
}
