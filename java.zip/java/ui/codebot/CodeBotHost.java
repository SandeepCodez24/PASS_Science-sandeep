package ui.codebot;

import javafx.application.Platform;
import javafx.collections.ListChangeListener;
import javafx.geometry.Orientation;
import javafx.scene.Node;
import javafx.scene.control.SplitPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Paint;
import javafx.scene.paint.RadialGradient;
import ui.UI_Main;
import ui.design.section_dims.CodeBot_dim;
import ui.design.section_dims.DirectoryMenu_dim;
import ui.explorer.CollapsiblePanel;
import ui.explorer.PanelActivation;

/**
 * Places the Code Bot inside the File Explorer panel, and draws the explorer's
 * static left edge.
 *
 * <pre>
 *   File Explorer panel body
 *   +--+--------------------------------+
 *   |  |  directory tree                |
 *   |  |                                |   60%
 *   |e |================================|   <- draggable divider
 *   |d |  Code Bot Assistant       [x]  |
 *   |g |  ...                           |   40%
 *   |e |  [ question            ] [>]   |
 *   +--+--------------------------------+
 * </pre>
 *
 * <h3>Opening and closing</h3>
 * <p>
 * The bot is not in the layout until the Home ribbon's <b>Code Bot</b> button
 * is pressed ({@link #toggle}). Opening adds it under the tree in a vertical
 * split at {@link CodeBot_dim#OPEN_DIVIDER_POSITION} (tree 60%, bot 40%); the
 * divider can then be dragged anywhere between the two minimum heights, and
 * the explorer's right-hand divider stays draggable as before. Pressing the
 * button again, or the bot's close button, removes it and gives the tree the
 * full height back. A collapsed File Explorer is expanded first. The
 * conversation is kept while the panel is closed.
 * </p>
 *
 * <h3>Active highlight</h3>
 * <p>
 * The bot is its own {@code PanelActivation} region ({@code CODE_BOT}), so
 * its title strip and the File Explorer's are highlighted separately: the one
 * clicked last is navy, the other grey. Opening the bot makes it the active
 * region; closing it hands the highlight back to the File Explorer.
 * </p>
 *
 * <h3>The edge strip</h3>
 * <p>
 * A {@link DirectoryMenu_dim#EDGE_STRIP_WIDTH}-pixel line down the whole left
 * side of the body -- beside the tree and beside the bot. Its colour is taken
 * from the main window's own divider between the File Explorer and the editor,
 * read from that divider's live background, so the two always match, in both
 * themes, whatever the theme sheet says. The theme sheets carry a fallback
 * colour for the moment before the divider exists.
 * </p>
 */
public final class CodeBotHost {

    private static final String EDGE_CLASS = "directory-edge-strip";
    private static final String BODY_CLASS = "file-explorer-body";
    private static final String DIVIDER_CLASS = "split-pane-divider";

    private static UI_Main ideRef;
    private static CollapsiblePanel explorer;
    private static SplitPane split;
    private static Node tree;
    private static Region edge;
    private static CodeBotPanel bot;
    private static Region trackedDivider;

    private CodeBotHost() {
    }

    // =====================================================================
    // Construction
    // =====================================================================

    /**
     * Builds the File Explorer's body: the edge strip, and a vertical split
     * that holds the tree (and, when opened, the bot).
     *
     * @param ide      the IDE controller
     * @param treeNode the directory tree
     * @return the body to hand to the File Explorer's {@link CollapsiblePanel}
     */
    public static Node buildBody(UI_Main ide, Node treeNode) {
        ideRef = ide;
        tree = treeNode;

        edge = new Region();
        edge.getStyleClass().add(EDGE_CLASS);
        edge.setMinWidth(DirectoryMenu_dim.EDGE_STRIP_WIDTH);
        edge.setPrefWidth(DirectoryMenu_dim.EDGE_STRIP_WIDTH);
        edge.setMaxWidth(DirectoryMenu_dim.EDGE_STRIP_WIDTH);
        edge.setMaxHeight(Double.MAX_VALUE);
        edge.setMouseTransparent(true);

        split = new SplitPane(treeNode);
        split.setOrientation(Orientation.VERTICAL);
        split.getStyleClass().add("code-bot-split");
        if (treeNode instanceof Region region) {
            region.setMinHeight(CodeBot_dim.TREE_MIN_HEIGHT);
        }
        HBox.setHgrow(split, Priority.ALWAYS);

        HBox body = new HBox(edge, split);
        body.getStyleClass().add(BODY_CLASS);
        body.setFillHeight(true);
        return body;
    }

    /**
     * Connects the body to its panel and the main window's split, once both
     * exist.
     *
     * @param panel     the File Explorer panel built around {@link #buildBody}
     * @param mainSplit the main horizontal split (explorer | editor | variables)
     */
    public static void attach(CollapsiblePanel panel, SplitPane mainSplit) {
        explorer = panel;
        if (mainSplit != null) {
            mainSplit.getChildrenUnmodifiable().addListener((ListChangeListener<Node>) change -> trackDivider(mainSplit));
            Platform.runLater(() -> trackDivider(mainSplit));
        }
    }

    // =====================================================================
    // Open / close
    // =====================================================================

    /**
     * The ribbon's Code Bot button: opens the bot, or closes it if open.
     *
     * @param ide the IDE controller
     */
    public static void toggle(UI_Main ide) {
        if (ide != null) {
            ideRef = ide;
        }
        if (isShowing()) {
            hide();
        } else {
            show();
        }
    }

    /** @return true while the bot is in the explorer */
    public static boolean isShowing() {
        return split != null && bot != null && split.getItems().contains(bot);
    }

    /** Opens the bot at the 60 / 40 split and focuses its question box. */
    public static void show() {
        if (split == null) {
            return;
        }
        if (bot == null) {
            bot = new CodeBotPanel(ideRef, CodeBotHost::hide);
            SplitPane.setResizableWithParent(bot, Boolean.FALSE);
            // Its own region: navy when the bot was clicked last, grey when
            // the tree (or anything else) was. The explorer's filter sits on
            // an ancestor and fires first, so a click in the bot ends on
            // CODE_BOT.
            PanelActivation.register(PanelActivation.Panel.CODE_BOT, bot.titleBar(), bot);
        } else {
            bot.refreshFont();
        }
        if (explorer != null && explorer.isCollapsed()) {
            explorer.setCollapsed(false);
        }
        if (!split.getItems().contains(bot)) {
            split.getItems().add(bot);
        }
        // Next pulse: the split has to lay out with both items before a
        // divider position is honoured.
        Platform.runLater(() -> split.setDividerPositions(CodeBot_dim.OPEN_DIVIDER_POSITION));
        PanelActivation.setActive(PanelActivation.Panel.CODE_BOT);
        bot.focusInput();
    }

    /** Closes the bot; the tree takes the full height again. */
    public static void hide() {
        if (split == null || bot == null) {
            return;
        }
        split.getItems().remove(bot);
        PanelActivation.setActive(PanelActivation.Panel.FILE_EXPLORER);
        if (tree != null) {
            tree.requestFocus();
        }
    }

    // =====================================================================
    // Edge colour
    // =====================================================================

    /**
     * Finds the divider between the File Explorer and the editor -- the main
     * split's own first divider, not one of a nested split -- and follows its
     * background.
     */
    private static void trackDivider(SplitPane mainSplit) {
        Region found = null;
        for (Node child : mainSplit.getChildrenUnmodifiable()) {
            if (child instanceof Region region && region.getStyleClass().contains(DIVIDER_CLASS)) {
                found = region;
                break;
            }
        }
        if (found == null || found == trackedDivider) {
            return;
        }
        trackedDivider = found;
        Region divider = found;
        divider.backgroundProperty().addListener((o, was, isNow) -> paintEdge(divider));
        paintEdge(divider);
    }

    /**
     * Copies the divider's visible colour onto the strip. An inline style is
     * used because a stylesheet rule would override a value set in code.
     */
    private static void paintEdge(Region divider) {
        if (edge == null) {
            return;
        }
        Color color = visibleColor(divider.getBackground());
        edge.setStyle(color == null ? "" : "-fx-background-color: " + css(color) + ";");
    }

    private static Color visibleColor(Background background) {
        if (background == null) {
            return null;
        }
        for (BackgroundFill fill : background.getFills()) {
            Color color = asColor(fill.getFill());
            if (color != null && color.getOpacity() > 0.05) {
                return color;
            }
        }
        return null;
    }

    private static Color asColor(Paint paint) {
        if (paint instanceof Color color) {
            return color;
        }
        if (paint instanceof LinearGradient gradient && !gradient.getStops().isEmpty()) {
            return gradient.getStops().get(0).getColor();
        }
        if (paint instanceof RadialGradient gradient && !gradient.getStops().isEmpty()) {
            return gradient.getStops().get(0).getColor();
        }
        return null;
    }

    private static String css(Color c) {
        return String.format(java.util.Locale.ROOT, "rgba(%d,%d,%d,%.3f)",
                (int) Math.round(c.getRed() * 255),
                (int) Math.round(c.getGreen() * 255),
                (int) Math.round(c.getBlue() * 255),
                c.getOpacity());
    }
}
