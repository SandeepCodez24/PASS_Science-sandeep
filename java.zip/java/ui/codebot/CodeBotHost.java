package ui.codebot;

import javafx.application.Platform;
import javafx.collections.ListChangeListener;
import javafx.geometry.Orientation;
import javafx.scene.Node;
import javafx.scene.control.SplitPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Paint;
import javafx.scene.paint.RadialGradient;
import ui.UI_Main;
import ui.design.Dim;
import ui.design.section_dims.CodeBot_dim;
import ui.design.section_dims.DirectoryMenu_dim;
import ui.explorer.CollapsiblePanel;
import ui.explorer.PanelActivation;
import ui.layout.LayoutManager;

/**
 * Owns the Code Bot panel's open / closed state, builds the File Explorer's
 * body (with its static left edge), and docks the bot inside that body when
 * the current layout asks for it.
 *
 * <pre>
 *   File Explorer panel body (Default layout)
 *   +--+--------------------------------+
 *   |  |  directory tree                |
 *   |  |                                |   60%
 *   |e |================================|   <- draggable divider
 *   |d |  Code Bot Assistant       [x]  |
 *   |g |  ...                           |   40%
 *   |e |  [ question            ] [>]   |
 *   +--+--------------------------------+
 * </pre>
 *
 * <h3>Where the bot goes</h3>
 * <p>
 * This class no longer decides that. {@link #show()} and {@link #hide()} flip
 * the open state and hand the placement to {@link LayoutManager#dockBot}: the
 * Default and Directory Centered layouts dock it under the tree through
 * {@link #placeInExplorer(double)}; the other layouts dock it in splits of
 * their own. When the bot closes, its neighbour in whichever split held it
 * takes the space back. The Home ribbon's Code Bot button still calls
 * {@link #toggle(UI_Main)}, unchanged. The conversation is kept while the
 * panel is closed and while it moves between layouts.
 * </p>
 * <p>
 * If {@code LayoutManager} was never installed (a stripped-down harness, say),
 * the bot falls back to the explorer, which is exactly the old behaviour.
 * </p>
 *
 * <h3>Active highlight</h3>
 * <p>
 * The bot is its own {@code PanelActivation} region ({@code CODE_BOT}).
 * Opening it makes it the active region; closing it hands the highlight to the
 * File Explorer if the explorer is on screen, otherwise to the editor.
 * </p>
 *
 * <h3>The edge strip</h3>
 * <p>
 * A {@link DirectoryMenu_dim#EDGE_STRIP_WIDTH}-pixel line down the whole left
 * side of the explorer body. Its colour is taken from the main window's own
 * divider between the File Explorer and the editor, read from that divider's
 * live background, so the two always match in both themes.
 * {@code LayoutManager} calls {@link #attach} again whenever a layout rebuilds
 * the main split.
 * </p>
 */
public final class CodeBotHost {

    private static final String EDGE_CLASS = "directory-edge-strip";
    private static final String BODY_CLASS = "file-explorer-body";
    private static final String DIVIDER_CLASS = "split-pane-divider";

    private static UI_Main ideRef;
    private static CollapsiblePanel explorer;
    private static SplitPane split;
    private static Node tree;
    private static Region edge;
    private static CodeBotPanel bot;
    private static Region trackedDivider;

    /** The user's intent: open or closed, independent of where it is docked. */
    private static boolean open;

    private CodeBotHost() {
    }

    // =====================================================================
    // Construction
    // =====================================================================

    /**
     * Builds the File Explorer's body: the edge strip, and a vertical split
     * that holds the tree (and, when docked there, the bot).
     *
     * @param ide      the IDE controller
     * @param treeNode the directory tree
     * @return the body to hand to the File Explorer's {@link CollapsiblePanel}
     */
    public static Node buildBody(UI_Main ide, Node treeNode) {
        ideRef = ide;
        tree = treeNode;

        edge = new Region();
        edge.getStyleClass().add(EDGE_CLASS);
        edge.setMinWidth(DirectoryMenu_dim.EDGE_STRIP_WIDTH);
        edge.setPrefWidth(DirectoryMenu_dim.EDGE_STRIP_WIDTH);
        edge.setMaxWidth(DirectoryMenu_dim.EDGE_STRIP_WIDTH);
        edge.setMaxHeight(Double.MAX_VALUE);
        edge.setMouseTransparent(true);

        split = new SplitPane(treeNode);
        split.setOrientation(Orientation.VERTICAL);
        split.getStyleClass().add("code-bot-split");
        if (treeNode instanceof Region region) {
            region.setMinHeight(CodeBot_dim.TREE_MIN_HEIGHT);
        }
        HBox.setHgrow(split, Priority.ALWAYS);

        HBox body = new HBox(edge, split);
        body.getStyleClass().add(BODY_CLASS);
        body.setFillHeight(true);
        return body;
    }

    /**
     * Connects the body to its panel and to the main window's split. Called
     * once at start-up and again by {@code LayoutManager} whenever a layout
     * rebuilds the main split with the explorer in it.
     *
     * @param panel     the File Explorer panel built around {@link #buildBody}
     * @param mainSplit the main horizontal split holding the explorer
     */
    public static void attach(CollapsiblePanel panel, SplitPane mainSplit) {
        explorer = panel;
        if (mainSplit != null) {
            mainSplit.getChildrenUnmodifiable().addListener((ListChangeListener<Node>) change -> trackDivider(mainSplit));
            Platform.runLater(() -> trackDivider(mainSplit));
        }
    }

    /**
     * The bot panel, created on first use. The conversation lives in it, so
     * the same instance moves between layouts.
     *
     * @return the Code Bot panel
     */
    public static CodeBotPanel panel() {
        if (bot == null) {
            bot = new CodeBotPanel(ideRef, CodeBotHost::hide);
            // Its own region: navy when the bot was clicked last, grey when
            // anything else was. Registered once; the filter travels with the
            // node wherever it is docked.
            PanelActivation.register(PanelActivation.Panel.CODE_BOT, bot.titleBar(), bot);
        }
        return bot;
    }

    // =====================================================================
    // Open / close
    // =====================================================================

    /**
     * The ribbon's Code Bot button: opens the bot, or closes it if open.
     *
     * @param ide the IDE controller
     */
    public static void toggle(UI_Main ide) {
        if (ide != null) {
            ideRef = ide;
        }
        if (isShowing()) {
            hide();
        } else {
            show();
        }
    }

    /** @return true while the bot is open, wherever it is docked */
    public static boolean isShowing() {
        return open;
    }

    /** Opens the bot where the current layout docks it, and focuses it. */
    public static void show() {
        CodeBotPanel panel = panel();
        panel.refreshFont();
        open = true;
        if (!LayoutManager.dockBot(true)) {
            placeInExplorer(CodeBot_dim.OPEN_DIVIDER_POSITION);
        }
        PanelActivation.setActive(PanelActivation.Panel.CODE_BOT);
        panel.focusInput();
    }

    /** Closes the bot; its neighbour takes the space back. */
    public static void hide() {
        if (!open) {
            return;
        }
        open = false;
        if (!LayoutManager.dockBot(false)) {
            removeFromExplorer();
        }
        if (isExplorerOnScreen()) {
            PanelActivation.setActive(PanelActivation.Panel.FILE_EXPLORER);
            if (tree != null) {
                tree.requestFocus();
            }
        } else {
            PanelActivation.setActive(PanelActivation.Panel.EDITOR);
        }
    }

    /**
     * Marks the bot closed without touching the window. {@code LayoutManager}
     * uses this while it tears a layout down, before it has anywhere to put
     * the bot.
     */
    public static void markClosed() {
        open = false;
    }

    // =====================================================================
    // Docking inside the File Explorer
    // =====================================================================

    /**
     * Puts the bot under the tree, expanding a collapsed explorer first.
     *
     * @param dividerPosition tree share of the explorer's height, e.g. 0.60
     */
    public static void placeInExplorer(double dividerPosition) {
        if (split == null) {
            return;
        }
        CodeBotPanel panel = panel();
        SplitPane.setResizableWithParent(panel, Boolean.FALSE);
        // Inside the explorer the bot follows the explorer's own minimum.
        panel.setMinWidth(Region.USE_COMPUTED_SIZE);
        if (explorer != null && explorer.isCollapsed()) {
            explorer.setCollapsed(false);
        }
        if (!split.getItems().contains(panel)) {
            split.getItems().add(panel);
        }
        // Next pulse: the split has to lay out with both items before a
        // divider position is honoured.
        split.setDividerPositions(dividerPosition);
        Platform.runLater(() -> split.setDividerPositions(dividerPosition));
    }

    /** Takes the bot out of the explorer; the tree gets the full height. */
    public static void removeFromExplorer() {
        if (split != null && bot != null) {
            split.getItems().remove(bot);
        }
    }

    /**
     * Readies the bot for docking in a column of its own: resizable with its
     * split, and never narrower than {@code Dim.Layout.BOT_COLUMN_MIN_WIDTH}.
     *
     * @return the bot panel
     */
    public static CodeBotPanel prepareForColumn() {
        CodeBotPanel panel = panel();
        SplitPane.setResizableWithParent(panel, Boolean.TRUE);
        panel.setMinWidth(Dim.Layout.BOT_COLUMN_MIN_WIDTH);
        return panel;
    }

    private static boolean isExplorerOnScreen() {
        return explorer != null && explorer.getScene() != null;
    }

    // =====================================================================
    // Edge colour
    // =====================================================================

    /**
     * Finds the divider between the File Explorer and the editor -- the main
     * split's own first divider, not one of a nested split -- and follows its
     * background.
     */
    private static void trackDivider(SplitPane mainSplit) {
        Region found = null;
        for (Node child : mainSplit.getChildrenUnmodifiable()) {
            if (child instanceof Region region && region.getStyleClass().contains(DIVIDER_CLASS)) {
                found = region;
                break;
            }
        }
        if (found == null || found == trackedDivider) {
            return;
        }
        trackedDivider = found;
        Region divider = found;
        divider.backgroundProperty().addListener((o, was, isNow) -> paintEdge(divider));
        paintEdge(divider);
    }

    /**
     * Copies the divider's visible colour onto the strip. An inline style is
     * used because a stylesheet rule would override a value set in code.
     */
    private static void paintEdge(Region divider) {
        if (edge == null) {
            return;
        }
        Color color = visibleColor(divider.getBackground());
        edge.setStyle(color == null ? "" : "-fx-background-color: " + css(color) + ";");
    }

    private static Color visibleColor(Background background) {
        if (background == null) {
            return null;
        }
        for (BackgroundFill fill : background.getFills()) {
            Color color = asColor(fill.getFill());
            if (color != null && color.getOpacity() > 0.05) {
                return color;
            }
        }
        return null;
    }

    private static Color asColor(Paint paint) {
        if (paint instanceof Color color) {
            return color;
        }
        if (paint instanceof LinearGradient gradient && !gradient.getStops().isEmpty()) {
            return gradient.getStops().get(0).getColor();
        }
        if (paint instanceof RadialGradient gradient && !gradient.getStops().isEmpty()) {
            return gradient.getStops().get(0).getColor();
        }
        return null;
    }

    private static String css(Color c) {
        return String.format(java.util.Locale.ROOT, "rgba(%d,%d,%d,%.3f)",
                (int) Math.round(c.getRed() * 255),
                (int) Math.round(c.getGreen() * 255),
                (int) Math.round(c.getBlue() * 255),
                c.getOpacity());
    }
}
