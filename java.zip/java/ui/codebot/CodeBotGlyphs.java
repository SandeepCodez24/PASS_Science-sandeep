package ui.codebot;

import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.shape.SVGPath;
import javafx.scene.shape.StrokeLineCap;
import javafx.scene.shape.StrokeLineJoin;

/**
 * The Code Bot panel's small vector glyphs.
 *
 * <p>
 * Drawn as paths rather than PNGs because they sit on surfaces whose colour
 * changes at run time -- the title strip turns navy when the File Explorer is
 * the active panel, and grey when it is not -- and a path simply takes its
 * colour from the theme CSS ({@code .code-bot-glyph} for strokes,
 * {@code .code-bot-glyph-fill} for fills).
 * </p>
 */
final class CodeBotGlyphs {

    static final String STROKE_CLASS = "code-bot-glyph";
    static final String FILL_CLASS = "code-bot-glyph-fill";

    private CodeBotGlyphs() {
    }

    /** A diagonal cross, {@code size} square. */
    static Node close(double size) {
        return stroked("M0,0 L" + size + "," + size + " M" + size + ",0 L0," + size);
    }

    /** A plus sign: start a new conversation. */
    static Node newChat(double size) {
        double h = size / 2;
        return stroked("M" + h + ",0 V" + size + " M0," + h + " H" + size);
    }

    /** A paper plane pointing right, {@code size} square. */
    static Node send(double size) {
        double s = size;
        SVGPath path = new SVGPath();
        path.setContent("M0," + (0.06 * s)
                + " L" + s + "," + (0.5 * s)
                + " L0," + (0.94 * s)
                + " L" + (0.12 * s) + "," + (0.56 * s)
                + " L" + (0.62 * s) + "," + (0.5 * s)
                + " L" + (0.12 * s) + "," + (0.44 * s) + " Z");
        path.getStyleClass().add(FILL_CLASS);
        return new Group(path);
    }

    private static Node stroked(String content) {
        SVGPath path = new SVGPath();
        path.setContent(content);
        path.setFill(null);
        path.setStrokeWidth(1.6);
        path.setStrokeLineCap(StrokeLineCap.ROUND);
        path.setStrokeLineJoin(StrokeLineJoin.ROUND);
        path.getStyleClass().add(STROKE_CLASS);
        return new Group(path);
    }
}
