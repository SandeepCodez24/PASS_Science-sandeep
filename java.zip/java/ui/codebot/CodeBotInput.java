package ui.codebot;

import java.util.function.Consumer;
import javafx.application.Platform;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.css.PseudoClass;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.Tooltip;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.text.Text;
import ui.design.section_dims.CodeBot_dim;

/**
 * The question box at the bottom of the Code Bot panel: a rounded field that
 * grows with its text, and a send button inside it at the right.
 *
 * <ul>
 * <li><b>Enter</b> sends.</li>
 * <li><b>Shift+Enter</b> starts a new line.</li>
 * <li>The field grows one line at a time up to
 * {@link CodeBot_dim#INPUT_MAX_LINES}, then scrolls.</li>
 * <li>While a reply is awaited ({@link #busyProperty()}), the send button is
 * disabled but the user may keep typing the next question.</li>
 * </ul>
 */
final class CodeBotInput extends HBox {

    private static final PseudoClass ACTIVE = PseudoClass.getPseudoClass("active");

    private final TextArea area = new TextArea();
    private final Button send = new Button();
    private final BooleanProperty busy = new SimpleBooleanProperty(false);
    private final Text measure = new Text();
    private final Consumer<String> onSend;

    /**
     * @param onSend receives the trimmed text when the user sends
     */
    CodeBotInput(Consumer<String> onSend) {
        this.onSend = onSend;
        getStyleClass().add("code-bot-input-box");
        setAlignment(Pos.BOTTOM_RIGHT);

        area.getStyleClass().add("code-bot-input");
        area.setWrapText(true);
        area.setPrefRowCount(1);
        area.setPromptText("Ask Code Bot about Neural Code\u2026");
        HBox.setHgrow(area, Priority.ALWAYS);

        send.getStyleClass().add("code-bot-send");
        send.setGraphic(CodeBotGlyphs.send(CodeBot_dim.SEND_GLYPH_SIZE));
        send.setFocusTraversable(false);
        double box = CodeBot_dim.SEND_BUTTON_SIZE;
        send.setMinSize(box, box);
        send.setPrefSize(box, box);
        send.setMaxSize(box, box);
        send.setTooltip(new Tooltip("Send (Enter)"));
        send.disableProperty().bind(busy.or(area.textProperty().isEmpty()));
        send.setOnAction(event -> submit());
        HBox.setMargin(send, new Insets(0, 0, 2, 0));

        getChildren().addAll(area, send);

        area.addEventFilter(KeyEvent.KEY_PRESSED, event -> {
            if (event.getCode() != KeyCode.ENTER) {
                return;
            }
            event.consume();
            if (event.isShiftDown()) {
                area.replaceSelection("\n");
            } else if (!busy.get()) {
                submit();
            }
        });
        area.focusedProperty().addListener((o, was, isNow) -> pseudoClassStateChanged(ACTIVE, isNow));
        area.textProperty().addListener(o -> fitHeight());
        area.widthProperty().addListener(o -> fitHeight());
        area.fontProperty().addListener(o -> fitHeight());
    }

    /** @return true while a reply is awaited */
    BooleanProperty busyProperty() {
        return busy;
    }

    /** Moves the keyboard focus into the field. */
    void focus() {
        Platform.runLater(area::requestFocus);
    }

    /**
     * @param css inline font style for the typed text
     */
    void setFontStyle(String css) {
        area.setStyle(css);
    }

    /** Puts text in the field (used by the suggestion chips) and sends it. */
    void sendText(String text) {
        if (busy.get()) {
            return;
        }
        area.setText(text);
        submit();
    }

    private void submit() {
        String text = area.getText() == null ? "" : area.getText().strip();
        if (text.isEmpty() || busy.get()) {
            return;
        }
        area.clear();
        onSend.accept(text);
    }

    /**
     * Grows or shrinks the field to fit its wrapped text, between one line
     * and {@link CodeBot_dim#INPUT_MAX_LINES}.
     */
    private void fitHeight() {
        double width = area.getWidth() - area.getInsets().getLeft() - area.getInsets().getRight() - 14;
        if (width <= 0) {
            return;
        }
        measure.setFont(area.getFont());
        measure.setWrappingWidth(0);
        measure.setText("X");
        double lineHeight = measure.getLayoutBounds().getHeight();
        String text = area.getText();
        measure.setText(text == null || text.isEmpty() ? "X" : text + (text.endsWith("\n") ? "X" : ""));
        measure.setWrappingWidth(width);
        int lines = (int) Math.round(measure.getLayoutBounds().getHeight() / lineHeight);
        int rows = Math.max(1, Math.min(CodeBot_dim.INPUT_MAX_LINES, lines));
        if (area.getPrefRowCount() != rows) {
            area.setPrefRowCount(rows);
        }
    }
}
