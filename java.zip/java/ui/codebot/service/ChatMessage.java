package ui.codebot.service;

import java.time.LocalDateTime;
import java.util.Objects;

/**
 * One line of a Code Bot conversation.
 *
 * @param role who said it
 * @param text what was said; bot replies may contain ``` fenced code blocks
 * @param time when it was said
 * @param kind how a bot reply should be shown
 */
public record ChatMessage(Role role, String text, LocalDateTime time, Kind kind) {

    /** Speaker. */
    public enum Role {
        USER,
        BOT
    }

    /** Presentation of a message. */
    public enum Kind {
        /** An ordinary message. */
        NORMAL,
        /** A notice from the service itself, e.g. "API Connection is needed". */
        NOTICE,
        /** A failure while asking the service. */
        ERROR
    }

    public ChatMessage {
        Objects.requireNonNull(role);
        text = text == null ? "" : text;
        time = time == null ? LocalDateTime.now() : time;
        kind = kind == null ? Kind.NORMAL : kind;
    }

    /** A question typed by the user, stamped now. */
    public static ChatMessage user(String text) {
        return new ChatMessage(Role.USER, text, LocalDateTime.now(), Kind.NORMAL);
    }

    /** A bot message, stamped now. */
    public static ChatMessage bot(String text, Kind kind) {
        return new ChatMessage(Role.BOT, text, LocalDateTime.now(), kind);
    }
}
