package ui.codebot.service;

import java.util.concurrent.CompletableFuture;

/**
 * The back end the Code Bot panel talks to.
 *
 * <p>
 * The panel knows only this interface. Today it is backed by
 * {@link DummyCodeBotService}; the planned implementation -- retrieval over
 * the Neural Code programming manual feeding a small language model -- plugs
 * in through {@link CodeBotServices#install(CodeBotService)} without any
 * change to the UI.
 * </p>
 *
 * <h3>Threading</h3>
 * <p>
 * {@link #ask} must not block: it returns at once and completes the future
 * from any thread. The panel moves the result onto the JavaFX thread itself.
 * </p>
 */
public interface CodeBotService {

    /**
     * Asks one question.
     *
     * @param request the question and its context
     * @return completes with the reply; completing exceptionally is shown to
     *         the user as an error message
     */
    CompletableFuture<CodeBotReply> ask(CodeBotRequest request);

    /**
     * @return true when a real back end is reachable; drives the status chip
     *         in the panel's title strip
     */
    default boolean isConnected() {
        return false;
    }

    /**
     * Stops a request in flight, if the back end supports it. Called when
     * the user clears the conversation.
     */
    default void cancelAll() {
    }
}
