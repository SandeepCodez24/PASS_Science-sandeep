package ui.codebot.service;

import java.nio.file.Path;
import java.util.List;

/**
 * What the panel sends to the service for one question.
 *
 * <p>
 * The context fields are there for the planned retrieval step: the manual
 * search can be narrowed by the file the user is working on, and the model
 * can be given the conversation so far. The dummy service ignores them.
 * </p>
 *
 * @param question   the user's text, trimmed
 * @param history    the conversation before this question, oldest first
 * @param activeFile the file in the selected editor tab, or null
 * @param folder     the folder the File Explorer is showing, or null
 */
public record CodeBotRequest(String question, List<ChatMessage> history, Path activeFile, Path folder) {

    public CodeBotRequest {
        question = question == null ? "" : question.strip();
        history = history == null ? List.of() : List.copyOf(history);
    }
}
