package ui.codebot.service;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import ui.design.section_dims.CodeBot_dim;

/**
 * Stand-in back end until the real API exists: every question is answered
 * with "API Connection is needed".
 *
 * <p>
 * The reply arrives after a short delay on a background thread, as a real
 * one would, so the panel's waiting state (typing dots, disabled send button)
 * is exercised now rather than first seen when the API lands.
 * </p>
 */
public final class DummyCodeBotService implements CodeBotService {

    /** The fixed reply. */
    public static final String REPLY = "API Connection is needed";

    @Override
    public CompletableFuture<CodeBotReply> ask(CodeBotRequest request) {
        return CompletableFuture.supplyAsync(
                () -> new CodeBotReply(REPLY, CodeBotReply.Status.NOT_CONNECTED),
                CompletableFuture.delayedExecutor(CodeBot_dim.DUMMY_REPLY_DELAY_MS, TimeUnit.MILLISECONDS));
    }
}
