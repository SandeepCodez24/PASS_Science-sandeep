package ui.codebot.service;

import java.util.Objects;

/**
 * Holds the one {@link CodeBotService} the panel uses.
 *
 * <p>
 * Starts with {@link DummyCodeBotService}. When the API is ready, install the
 * real service once at start-up (for example in {@code Main} or
 * {@code UI_Main}):
 * </p>
 * <pre>
 *   CodeBotServices.install(new ManualRagCodeBotService(...));
 * </pre>
 */
public final class CodeBotServices {

    private static volatile CodeBotService current = new DummyCodeBotService();

    private CodeBotServices() {
    }

    /** @return the active service, never null */
    public static CodeBotService get() {
        return current;
    }

    /**
     * Replaces the active service.
     *
     * @param service the new back end
     */
    public static void install(CodeBotService service) {
        current = Objects.requireNonNull(service);
    }
}
