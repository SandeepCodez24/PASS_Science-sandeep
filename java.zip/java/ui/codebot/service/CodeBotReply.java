package ui.codebot.service;

/**
 * The service's answer to one {@link CodeBotRequest}.
 *
 * @param text   the answer; may contain ``` fenced code blocks
 * @param status whether it is an answer, a notice or a failure
 */
public record CodeBotReply(String text, Status status) {

    /** Outcome of a request. */
    public enum Status {
        /** A real answer. */
        OK,
        /** No back end is connected yet. */
        NOT_CONNECTED,
        /** The back end failed. */
        ERROR
    }

    public CodeBotReply {
        text = text == null ? "" : text;
        status = status == null ? Status.OK : status;
    }

    /** @return the message kind the panel should draw this reply with */
    public ChatMessage.Kind kind() {
        return switch (status) {
            case OK -> ChatMessage.Kind.NORMAL;
            case NOT_CONNECTED -> ChatMessage.Kind.NOTICE;
            case ERROR -> ChatMessage.Kind.ERROR;
        };
    }
}
