package ui.codebot;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.beans.binding.DoubleExpression;
import javafx.css.PseudoClass;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Circle;
import javafx.util.Duration;
import ui.codebot.service.ChatMessage;
import ui.design.section_dims.CodeBot_dim;
import ui.directory.DirectoryFont;
import ui.ui_functions.tools.HomeRibbonIcons;

/**
 * Draws one message of the conversation.
 *
 * <pre>
 *   (bot)  [o] +---------------------------+
 *              | text ...                  |
 *              | +-- nc ------------ Copy -+ |
 *              | | code                    | |
 *              | +-------------------------+ |
 *              +---------------------------+
 *              Code Bot  10:42
 *
 *   (user)            +-------------------+
 *                     | question ...      |
 *                     +-------------------+
 *                                  10:42
 * </pre>
 *
 * <p>
 * Bot text may carry Markdown-style fenced code blocks (three back-ticks, an
 * optional language name). Each block is drawn in the editor's monospaced
 * font in its own box with a Copy button, since answers from the manual will
 * often be Neural Code snippets the user wants to paste into the editor.
 * Right-clicking any bubble offers "Copy message".
 * </p>
 *
 * <p>
 * Text uses the File Explorer's row font ({@link DirectoryFont}); the time
 * stamp and the code block's caption are {@link #SMALL} of it, and code keeps
 * its monospaced family at the full size.
 * </p>
 *
 * <p>
 * The kind of a bot message chooses its bubble: an ordinary answer, a notice
 * from the service (amber, e.g. "API Connection is needed") or an error
 * (red).
 * </p>
 */
final class CodeBotMessageView {

    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm");
    private static final String FENCE = "```";

    /** Size of secondary text (time stamps, captions) relative to the row font. */
    static final double SMALL = 0.85;

    private static final PseudoClass USER = PseudoClass.getPseudoClass("user");
    private static final PseudoClass BOT = PseudoClass.getPseudoClass("bot");
    private static final PseudoClass NOTICE = PseudoClass.getPseudoClass("notice");
    private static final PseudoClass ERROR = PseudoClass.getPseudoClass("error");

    private CodeBotMessageView() {
    }

    /**
     * @param message   the message
     * @param listWidth the width of the message list, to cap the bubble
     * @param font      the explorer's row font
     * @return the message row
     */
    static Node build(ChatMessage message, DoubleExpression listWidth, DirectoryFont font) {
        boolean user = message.role() == ChatMessage.Role.USER;

        VBox bubble = new VBox(6);
        bubble.getStyleClass().add("code-bot-bubble");
        bubble.pseudoClassStateChanged(USER, user);
        bubble.pseudoClassStateChanged(BOT, !user);
        bubble.pseudoClassStateChanged(NOTICE, message.kind() == ChatMessage.Kind.NOTICE);
        bubble.pseudoClassStateChanged(ERROR, message.kind() == ChatMessage.Kind.ERROR);
        bubble.setFillWidth(true);
        bubble.maxWidthProperty().bind(listWidth
                .subtract(user ? 0 : CodeBot_dim.AVATAR_SIZE + CodeBot_dim.AVATAR_GAP)
                .multiply(CodeBot_dim.BUBBLE_MAX_SHARE));
        bubble.getChildren().addAll(segments(message.text(), user, font));

        MenuItem copy = new MenuItem("Copy message");
        copy.setOnAction(event -> toClipboard(message.text()));
        ContextMenu menu = new ContextMenu(copy);
        bubble.setOnContextMenuRequested(event -> {
            menu.show(bubble, event.getScreenX(), event.getScreenY());
            event.consume();
        });

        Label meta = new Label((user ? "" : "Code Bot  \u00b7  ") + TIME.format(message.time()));
        meta.getStyleClass().add("code-bot-meta");
        meta.setStyle(font.css(SMALL));

        VBox column = new VBox(3, bubble, meta);
        column.setAlignment(user ? Pos.TOP_RIGHT : Pos.TOP_LEFT);
        column.setFillWidth(true);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        HBox row = user
                ? new HBox(spacer, column)
                : new HBox(CodeBot_dim.AVATAR_GAP, avatar(), column, spacer);
        row.getStyleClass().add("code-bot-row");
        row.setAlignment(Pos.TOP_LEFT);
        return row;
    }

    /**
     * The "Code Bot is thinking" row: the avatar and three pulsing dots.
     *
     * @return the row; call {@link Typing#stop()} before removing it
     */
    static Typing typing() {
        HBox dots = new HBox(CodeBot_dim.TYPING_DOT_GAP);
        dots.getStyleClass().addAll("code-bot-bubble", "code-bot-typing");
        dots.pseudoClassStateChanged(BOT, true);
        dots.setAlignment(Pos.CENTER);
        Timeline timeline = new Timeline();
        double cycle = CodeBot_dim.TYPING_CYCLE_MS;
        for (int i = 0; i < 3; i++) {
            Circle dot = new Circle(CodeBot_dim.TYPING_DOT_RADIUS);
            dot.getStyleClass().add("code-bot-typing-dot");
            dot.setOpacity(0.3);
            dots.getChildren().add(dot);
            double offset = i * cycle / 6;
            timeline.getKeyFrames().addAll(
                    new KeyFrame(Duration.millis(offset), new KeyValue(dot.opacityProperty(), 0.3)),
                    new KeyFrame(Duration.millis(offset + cycle / 4), new KeyValue(dot.opacityProperty(), 1.0)),
                    new KeyFrame(Duration.millis(offset + cycle / 2), new KeyValue(dot.opacityProperty(), 0.3)),
                    new KeyFrame(Duration.millis(cycle), new KeyValue(dot.opacityProperty(), 0.3)));
        }
        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.play();

        HBox row = new HBox(CodeBot_dim.AVATAR_GAP, avatar(), dots);
        row.getStyleClass().add("code-bot-row");
        row.setAlignment(Pos.TOP_LEFT);
        return new Typing(row, timeline);
    }

    /** The typing row and its animation. */
    record Typing(Node node, Timeline timeline) {
        void stop() {
            timeline.stop();
        }
    }

    // =====================================================================
    // Pieces
    // =====================================================================

    static Node avatar() {
        StackPane avatar = new StackPane(HomeRibbonIcons.icon("ic_h_06_code_bot", CodeBot_dim.AVATAR_SIZE * 0.68));
        avatar.getStyleClass().add("code-bot-avatar");
        avatar.setMinSize(CodeBot_dim.AVATAR_SIZE, CodeBot_dim.AVATAR_SIZE);
        avatar.setPrefSize(CodeBot_dim.AVATAR_SIZE, CodeBot_dim.AVATAR_SIZE);
        avatar.setMaxSize(CodeBot_dim.AVATAR_SIZE, CodeBot_dim.AVATAR_SIZE);
        return avatar;
    }

    /** Splits text at ``` fences into prose labels and code boxes. */
    private static List<Node> segments(String text, boolean user, DirectoryFont font) {
        List<Node> nodes = new ArrayList<>();
        if (user || !text.contains(FENCE)) {
            nodes.add(prose(text, font));
            return nodes;
        }
        int at = 0;
        while (at < text.length()) {
            int open = text.indexOf(FENCE, at);
            if (open < 0) {
                addProse(nodes, text.substring(at), font);
                break;
            }
            addProse(nodes, text.substring(at, open), font);
            int lineEnd = text.indexOf('\n', open + FENCE.length());
            if (lineEnd < 0) {
                addProse(nodes, text.substring(open), font);
                break;
            }
            String language = text.substring(open + FENCE.length(), lineEnd).strip();
            int close = text.indexOf(FENCE, lineEnd + 1);
            String code = close < 0 ? text.substring(lineEnd + 1) : text.substring(lineEnd + 1, close);
            nodes.add(code(language, stripTrailingNewline(code), font));
            at = close < 0 ? text.length() : close + FENCE.length();
        }
        if (nodes.isEmpty()) {
            nodes.add(prose("", font));
        }
        return nodes;
    }

    private static void addProse(List<Node> nodes, String text, DirectoryFont font) {
        String trimmed = text.strip();
        if (!trimmed.isEmpty()) {
            nodes.add(prose(trimmed, font));
        }
    }

    private static Label prose(String text, DirectoryFont font) {
        Label label = new Label(text);
        label.getStyleClass().add("code-bot-text");
        label.setStyle(font.css());
        label.setWrapText(true);
        label.setMinHeight(Region.USE_PREF_SIZE);
        label.setMaxWidth(Double.MAX_VALUE);
        return label;
    }

    private static Node code(String language, String code, DirectoryFont font) {
        Label lang = new Label(language.isEmpty() ? "code" : language);
        lang.getStyleClass().add("code-bot-code-lang");
        lang.setStyle(font.css(SMALL));
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        Button copy = new Button("Copy");
        copy.getStyleClass().add("code-bot-code-copy");
        copy.setStyle(font.css(SMALL));
        copy.setFocusTraversable(false);
        copy.setOnAction(event -> {
            toClipboard(code);
            copy.setText("Copied");
            Timeline reset = new Timeline(new KeyFrame(Duration.seconds(1.5), e -> copy.setText("Copy")));
            reset.play();
        });
        HBox header = new HBox(lang, spacer, copy);
        header.getStyleClass().add("code-bot-code-header");
        header.setAlignment(Pos.CENTER_LEFT);

        Label body = new Label(code);
        body.getStyleClass().add("code-bot-code");
        body.setStyle(font.sizeCss(1.0));
        body.setMinHeight(Region.USE_PREF_SIZE);
        ScrollPane scroll = new ScrollPane(body);
        scroll.getStyleClass().add("code-bot-code-scroll");
        scroll.setFitToHeight(true);
        scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        scroll.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);

        VBox box = new VBox(header, scroll);
        box.getStyleClass().add("code-bot-code-box");
        box.setMaxWidth(Double.MAX_VALUE);
        return box;
    }

    private static String stripTrailingNewline(String text) {
        return text.endsWith("\n") ? text.substring(0, text.length() - 1) : text;
    }

    private static void toClipboard(String text) {
        ClipboardContent content = new ClipboardContent();
        content.putString(text);
        Clipboard.getSystemClipboard().setContent(content);
    }
}
