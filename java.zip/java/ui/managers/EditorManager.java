package ui.managers;

import java.nio.file.Path;

import javafx.scene.control.Tab;
import ui.UI_Main;
import ui.cli.CLI_Main;
import ui.editor.EditorFileInfo;
import ui.editor.homeTab.EditorFileCreator;
import ui.editor.homeTab.EditorFileOpener;
import ui.editor.homeTab.EditorFileRunner;
import ui.editor.homeTab.EditorFileSaver;

/**
 * High-level orchestrator for file and editor operations. Delegates to the
 * specialised editor classes for each concrete operation.
 *
 * <p><b>Backend ownership.</b> The persistent {@code nc.exe} interpreter is now
 * owned solely by {@link CLI_Main}. {@link #startUPITerminal(UI_Main)} simply
 * delegates to {@link CLI_Main#start(UI_Main)}, which is idempotent — so even
 * though it is reachable from {@code UI_Main.buildUI} (and previously from the
 * runner), only ONE interpreter is ever launched. That removes the duplicate
 * {@code >> >>} prompt and the doubled console output.</p>
 */
public class EditorManager {

    /* =========================================================
     * NEW FILES
     * ========================================================= */

    public static void newPlainTextFile(UI_Main ide) {
        EditorFileCreator.newPlainTextFile(ide);
    }

    public static void newUPIFile(UI_Main ide) {
        EditorFileCreator.newUPIFile(ide);
    }

    public static void newClassFile(UI_Main ide) {
        EditorFileCreator.newClassFile(ide);
    }

    public static void newFunctionFile(UI_Main ide) {
        EditorFileCreator.newFunctionFile(ide);
    }

    /* =========================================================
     * OPEN FILE
     * ========================================================= */

    public static void openFile(UI_Main ide) {
        EditorFileOpener.openFile(ide);
    }

    public static void openFileDirectly(UI_Main ide, Path path) {
        EditorFileOpener.openFileDirectly(ide, path);
    }

    public static void openNcFile(UI_Main ide) {
        EditorFileOpener.openNcFile(ide);
    }

    public static void openProjectFolder(UI_Main ide) {
        EditorFileOpener.openProjectFolder(ide);
    }

    public static void openLastProject(UI_Main ide) {
        EditorFileOpener.openLastProject(ide);
    }

    public static void openRootFolder(UI_Main ide) {
        EditorFileOpener.openRootFolder(ide);
    }

    /* =========================================================
     * SAVE
     * ========================================================= */

    public static void saveCurrentFile(UI_Main ide) {
        EditorFileSaver.saveCurrentFile(ide);
    }

    public static void saveAsFile(UI_Main ide) {
        EditorFileSaver.saveAsFile(ide);
    }

    public static void saveToProjectRoot(UI_Main ide) {
        EditorFileSaver.saveToProjectRoot(ide);
    }

    public static void saveInFolder(UI_Main ide) {
        EditorFileSaver.saveInFolder(ide);
    }

    /* =========================================================
     * RUN FILE
     * ========================================================= */

    /**
     * Runs the current file on the shared persistent backend.
     *
     * @param ide the IDE controller
     */
    public static void runCurrentFile(UI_Main ide) {
        EditorFileRunner.runCurrentFile(ide);
    }

    /* =========================================================
     * TERMINAL
     * ========================================================= */

    /**
     * Sends a raw command to the running backend over its stdin. Uses the
     * writer that {@link CLI_Main} attaches to {@code ide.processWriter}.
     *
     * @param ide     the IDE controller
     * @param command the command to send
     */
    public static void sendCommandToTerminal(UI_Main ide, String command) {
        if (ide == null) {
            return;
        }
        try {
            if (ide.processWriter == null || !ide.programRunning) {
                ide.console.appendText("UPI terminal is not running.\n");
                return;
            }
            ide.processWriter.write(command);
            ide.processWriter.newLine();
            ide.processWriter.flush();
        } catch (Exception e) {
            ide.console.appendText("Failed to send command: " + e.getMessage() + "\n");
        }
    }

    /**
     * Starts the single persistent UPI backend. Safe to call more than once —
     * {@link CLI_Main#start(UI_Main)} is idempotent.
     *
     * @param ide the IDE controller
     */
    public static void startUPITerminal(UI_Main ide) {
        CLI_Main.start(ide);
    }

    /* =========================================================
     * PLOTTING
     * ========================================================= */

    public static void plotCurrentUPIFile(UI_Main ide) {
        runCurrentFile(ide);
    }

    /* =========================================================
     * HELPERS
     * ========================================================= */

    /**
     * @param ide the IDE controller
     * @return true if the active tab holds a {@code .nc} file
     */
    public static boolean isCurrentUPIFile(UI_Main ide) {
        if (ide == null || ide.editorTabs == null) {
            return false;
        }
        Tab tab = ide.editorTabs.getSelectionModel().getSelectedItem();
        if (tab == null) {
            return false;
        }
        Object userData = tab.getUserData();
        if (!(userData instanceof EditorFileInfo info)) {
            return false;
        }
        return ".nc".equalsIgnoreCase(info.ext);
    }

    /**
     * @deprecated The demo C++ integration has been removed. Kept as a no-op so
     *             any remaining caller compiles; please delete the call.
     */
    @Deprecated
    public static void integrateDemoCpp(UI_Main ide) {
        // Intentionally does nothing.
    }
}
