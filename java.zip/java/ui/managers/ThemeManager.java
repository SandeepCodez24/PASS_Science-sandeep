package ui.managers;

import java.net.URL;

import javafx.animation.FadeTransition;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.util.Duration;
import ui.UI_Main;
import ui.ui_functions.tools.HomeFilesIcons;
import ui.ui_functions.tools.ToolbarIcons;
import ui.ui_functions.tools.ToolbarNavigation;

/**
 * Owns the light/dark theme: which stylesheet is on the scene, which ink the
 * Files icon set uses, and which glyph the toggle button shows.
 */
public class ThemeManager {

    private static final String BASE_CSS = "/themes/plot.css";
    private static final String THEME_PATH = "/themes/";
    private static final String SYNTAX_CSS = "/language_design/syntax.css";
    // Dark-only overlay, layered on top of syntax.css when the dark theme is
    // active so identifiers etc. stay readable. See syntax-dark.css.
    private static final String SYNTAX_DARK_CSS = "/language_design/syntax-dark.css";

    private static final String DARK = "dark";
    private static final String LIGHT = "light";

    private static String activeTheme = LIGHT;

    /*
     * =========================================================
     * INIT (CALL ONCE AFTER SCENE CREATION)
     * =========================================================
     */
    public static void init(UI_Main ide) {
        if (ide.scene == null)
            return;
        loadBaseCSS(ide);
        applySavedTheme(ide);
    }

    /*
     * =========================================================
     * BASE CSS (LOAD ONLY ONCE)
     * =========================================================
     */
    public static void loadBaseCSS(UI_Main ide) {
        if (ide.scene == null)
            return;
        URL url = ThemeManager.class.getResource(BASE_CSS);
        if (url == null)
            return;
        String base = url.toExternalForm();
        if (!ide.scene.getStylesheets().contains(base)) {
            ide.scene.getStylesheets().add(0, base);
        }
        ide.baseStylesheet = base;
    }

    /*
     * =========================================================
     * APPLY SAVED THEME
     * =========================================================
     */
    public static void applySavedTheme(UI_Main ide) {
        String theme = ide.prefs.get("theme", LIGHT);
        applyTheme(ide, theme);
    }

    /*
     * =========================================================
     * TOGGLE THEME
     * =========================================================
     */
    public static void toggleTheme(UI_Main ide) {
        final String next = DARK.equals(activeTheme) ? LIGHT : DARK;

        // No node to animate -> switch instantly.
        if (ide.rootNode == null) {
            applyTheme(ide, next);
            return;
        }

        FadeTransition out = new FadeTransition(Duration.millis(120), ide.rootNode);
        out.setFromValue(1);
        out.setToValue(0);
        out.setOnFinished(e -> {
            // Swap the theme while the UI is invisible, then fade back in. This
            // is the body that was previously empty, which is why toggling only
            // dimmed the screen and never actually changed the theme.
            applyTheme(ide, next);

            FadeTransition in = new FadeTransition(Duration.millis(120), ide.rootNode);
            in.setFromValue(0);
            in.setToValue(1);
            in.play();
        });
        out.play();
    }

    /*
     * =========================================================
     * APPLY THEME (CORE ENGINE)
     * =========================================================
     */
    public static void applyTheme(UI_Main ide, String theme) {
        if (ide.scene == null)
            return;

        loadBaseCSS(ide);

        URL themeResource = ThemeManager.class.getResource(THEME_PATH + theme + ".css");
        if (themeResource == null) {
            System.err.println("Theme stylesheet missing: " + THEME_PATH + theme + ".css");
            return;
        }
        String themeUrl = themeResource.toExternalForm();

        // Language syntax stylesheet (token styles for CodeArea). The light
        // palette (syntax.css) is always present; the dark overlay
        // (syntax-dark.css) is layered on top ONLY for the dark theme, added
        // AFTER syntax.css so its overrides win, and removed for the light
        // theme. Guarded so repeated toggles never stack duplicates.
        URL syntax = ThemeManager.class.getResource(SYNTAX_CSS);
        if (syntax != null) {
            String syntaxUrl = syntax.toExternalForm();
            if (!ide.scene.getStylesheets().contains(syntaxUrl)) {
                ide.scene.getStylesheets().add(syntaxUrl);
            }
        }

        URL syntaxDark = ThemeManager.class.getResource(SYNTAX_DARK_CSS);
        if (syntaxDark != null) {
            String syntaxDarkUrl = syntaxDark.toExternalForm();
            // Always remove first so it can be re-added last (after syntax.css)
            // and so the light theme never keeps the dark overrides.
            ide.scene.getStylesheets().remove(syntaxDarkUrl);
            if (DARK.equals(theme)) {
                ide.scene.getStylesheets().add(syntaxDarkUrl);
            }
        }

        /* REMOVE OLD THEME */
        if (ide.currentThemeStylesheet != null) {
            ide.scene.getStylesheets().remove(ide.currentThemeStylesheet);
        }

        /* ADD NEW THEME */
        ide.scene.getStylesheets().add(themeUrl);

        ide.currentThemeStylesheet = themeUrl;
        ide.currentTheme = theme;
        activeTheme = theme;
        ide.prefs.put("theme", theme);

        applyIconInk(theme);
        updateThemeIcon(ide);
    }

    /*
     * =========================================================
     * ICON UPDATE
     * =========================================================
     */

    /**
     * Points the Files ribbon icons at the matching ink. Those PNGs are raster,
     * so unlike the rest of the palette they cannot follow the stylesheet on
     * their own -- the set ships twice and this picks one. Every icon already on
     * screen is re-pointed in place, so the ribbon does not need rebuilding.
     *
     * @param theme the theme just applied
     */
    private static void applyIconInk(String theme) {
        boolean dark = DARK.equals(theme);

        HomeFilesIcons.setDarkTheme(dark);

        // ToolbarIcons was never being told about the theme, so every icon it
        // loaded kept the light-theme ink and the "/icons/dark/..." variants
        // were unreachable. Setting the flag here is what makes the breadcrumb
        // chevrons -- and any other dark asset added later -- resolve.
        ToolbarIcons.setDarkMode(dark);

        // Those chevrons are already on screen as raster ImageViews, so the
        // flag alone does not repaint them. Redraw the strip.
        ToolbarNavigation.refreshThemeIcons();
    }

    public static void updateThemeIcon(UI_Main ide) {

    }

    /**
     * @return the theme currently in force, for secondary windows built before
     */
    public static String getActiveTheme() {
        return activeTheme;
    }

    public static void registerScene(Scene scene) {

    }
}
