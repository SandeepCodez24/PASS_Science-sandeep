package ui.managers;

import java.net.URL;
import java.util.function.Function;

import javafx.animation.FadeTransition;
import javafx.beans.property.ReadOnlyStringProperty;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.scene.Scene;
import javafx.util.Duration;
import ui.UI_Main;
import ui.editor.folding.FoldIcons;
import ui.editor.search.SearchIcons;
import ui.explorer.navigation.NaviBreadIcons;
import ui.ui_functions.tools.HomeFilesIcons;
import ui.ui_functions.tools.HomeRibbonIcons;
import ui.ui_functions.tools.LayoutIcons;
import ui.ui_functions.tools.NcRibbonIcons;
import ui.ui_functions.tools.SettingsIcons;
import ui.ui_functions.tools.SignalIcons;
import ui.ui_functions.tools.ToolbarIcons;

/**
 * Owns the light/dark theme: which stylesheet is on the scene, which ink the
 * Files icon set uses, and which glyph the toggle button shows.
 *
 * <h3>Editor stylesheets</h3>
 * Everything the editor paints -- syntax token colours, the CodeArea surface,
 * the gutter band, the fold column and badge, and the step runner's current
 * line and arrow -- now lives in a single swapped pair:
 *
 * <pre>
 *   /themes/editorColor/editor_light.css
 *   /themes/editorColor/editor_dark.css
 * </pre>
 *
 * That pair replaces four stylesheets this class used to juggle
 * ({@code syntax.css}, {@code syntax-dark.css}, the folding pair and the
 * step-runner pair), and it replaces the {@code .code-area} block that used to
 * sit in {@code dark.css}. The two files are full twins rather than a base plus
 * a dark overlay, so exactly one of them is on the scene at any moment.
 *
 * <p>
 * <b>Load order matters.</b> The editor sheet is added <i>after</i> the theme
 * sheet, so where the two carry the same selector at the same specificity --
 * {@code .code-area}, for instance -- the editor sheet wins. Do not move that
 * call above the theme sheet.
 *
 * <h3>Text colours</h3>
 * The syntax token colours are no longer in the editor pair. They are in
 *
 * <pre>
 *   /themes/texts/text_light.css
 *   /themes/texts/text_dark.css
 * </pre>
 *
 * which {@link TextColourManager} puts on the scene straight after the editor
 * sheet (see {@link #applyEditorStylesheet}), followed by the user's choices
 * from Settings &gt; Text Colours when there are any. The text sheet follows
 * the editor sheet's brightness, not the theme's.
 *
 * <h3>Editor ink in the Custom layout</h3>
 * The Custom layout lets the user give the editor a background of either
 * brightness in either theme. Syntax colours made for a white page are
 * unreadable on a dark one, so the Custom layout installs an
 * {@linkplain #setEditorInkSelector editor ink selector}: given the theme, it
 * says which of the two editor sheets to load. With no selector (every other
 * layout) the editor sheet simply follows the theme, as before.
 *
 * <h3>Theme changes are observable</h3>
 * {@link #themeProperty()} changes after a theme has been fully applied, so
 * anything that derives colours from the theme (the Custom layout's sheet)
 * can rebuild itself.
 */
public class ThemeManager {

    private static final String BASE_CSS = "/themes/plot.css";
    private static final String THEME_PATH = "/themes/";

    // The one editor stylesheet pair. See the class javadoc.
    private static final String EDITOR_LIGHT_CSS = "/themes/editorColor/editor_light.css";
    private static final String EDITOR_DARK_CSS = "/themes/editorColor/editor_dark.css";

    /**
     * Stylesheets this class used to add, listed so they can be removed if an
     * incremental build still has them on the scene from an earlier run.
     *
     * <p>
     * Once the old files are deleted from {@code src/main/resources} these
     * resolve to null and the cleanup is a no-op, which is why it costs nothing
     * to leave in place. Delete this array and
     * {@link #removeLegacyEditorStylesheets(UI_Main)} whenever you like.
     */
    private static final String[] LEGACY_EDITOR_CSS = {
            "/language_design/syntax.css",
            "/language_design/syntax-dark.css",
            "/themes/folding/folding-light.css",
            "/themes/folding/folding-dark.css",
            "/themes/steprunner/steprunner-light.css",
            "/themes/steprunner/steprunner-dark.css"
    };

    private static final String DARK = "dark";
    private static final String LIGHT = "light";

    private static String activeTheme = LIGHT;

    /** Follows {@link #activeTheme}; set last in {@link #applyTheme}. */
    private static final ReadOnlyStringWrapper THEME = new ReadOnlyStringWrapper(LIGHT);

    /**
     * Theme name in, "use the dark editor sheet?" out; null answer or null
     * selector means follow the theme. See the class notes.
     */
    private static Function<String, Boolean> editorInkSelector;

    /*
     * =========================================================
     * INIT (CALL ONCE AFTER SCENE CREATION)
     * =========================================================
     */
    public static void init(UI_Main ide) {
        if (ide.scene == null)
            return;
        loadBaseCSS(ide);
        applySavedTheme(ide);
    }

    /*
     * =========================================================
     * BASE CSS (LOAD ONLY ONCE)
     * =========================================================
     */
    public static void loadBaseCSS(UI_Main ide) {
        if (ide.scene == null)
            return;

        URL url = ThemeManager.class.getResource(BASE_CSS);
        if (url == null)
            return;

        String base = url.toExternalForm();
        if (!ide.scene.getStylesheets().contains(base)) {
            ide.scene.getStylesheets().add(0, base);
        }
        ide.baseStylesheet = base;
    }

    /*
     * =========================================================
     * APPLY SAVED THEME
     * =========================================================
     */
    public static void applySavedTheme(UI_Main ide) {
        String theme = ide.prefs.get("theme", LIGHT);
        applyTheme(ide, theme);
    }

    /*
     * =========================================================
     * TOGGLE THEME
     * =========================================================
     */
    public static void toggleTheme(UI_Main ide) {
        final String next = DARK.equals(activeTheme) ? LIGHT : DARK;

        // No node to animate -> switch instantly.
        if (ide.rootNode == null) {
            applyTheme(ide, next);
            return;
        }

        FadeTransition out = new FadeTransition(Duration.millis(120), ide.rootNode);
        out.setFromValue(1);
        out.setToValue(0);
        out.setOnFinished(e -> {
            // Swap the theme while the UI is invisible, then fade back in. This
            // is the body that was previously empty, which is why toggling only
            // dimmed the screen and never actually changed the theme.
            applyTheme(ide, next);

            FadeTransition in = new FadeTransition(Duration.millis(120), ide.rootNode);
            in.setFromValue(0);
            in.setToValue(1);
            in.play();
        });
        out.play();
    }

    /*
     * =========================================================
     * APPLY THEME (CORE ENGINE)
     * =========================================================
     */
    public static void applyTheme(UI_Main ide, String theme) {
        if (ide.scene == null)
            return;

        loadBaseCSS(ide);

        URL themeResource = ThemeManager.class.getResource(THEME_PATH + theme + ".css");
        if (themeResource == null) {
            System.err.println("Theme stylesheet missing: " + THEME_PATH + theme + ".css");
            return;
        }
        String themeUrl = themeResource.toExternalForm();

        /* REMOVE OLD THEME */
        if (ide.currentThemeStylesheet != null) {
            ide.scene.getStylesheets().remove(ide.currentThemeStylesheet);
        }

        /* ADD NEW THEME */
        ide.scene.getStylesheets().add(themeUrl);
        ide.currentThemeStylesheet = themeUrl;

        /* ADD THE EDITOR SHEET LAST, so it outranks the theme on shared rules */
        removeLegacyEditorStylesheets(ide);
        applyEditorStylesheet(ide, theme);

        ide.currentTheme = theme;
        activeTheme = theme;

        ide.prefs.put("theme", theme);

        applyIconInk(theme);
        updateThemeIcon(ide);

        // Last, once everything above is in place.
        THEME.set(theme);
    }

    /**
     * Chooses which editor sheet loads, independently of the theme. Applied
     * at once if a scene exists, and on every later theme switch.
     *
     * @param ide      the IDE controller (may be null before the scene exists)
     * @param selector theme name to "dark editor sheet?", or null to follow
     *                 the theme again
     */
    public static void setEditorInkSelector(UI_Main ide, Function<String, Boolean> selector) {
        editorInkSelector = selector;
        if (ide != null && ide.scene != null) {
            applyEditorStylesheet(ide, activeTheme);
        }
    }

    /**
     * @return the theme in force, observable; changes after a switch is
     *         complete
     */
    public static ReadOnlyStringProperty themeProperty() {
        return THEME.getReadOnlyProperty();
    }

    /**
     * Swaps in the editor palette for the theme being applied.
     *
     * <p>
     * Both sheets are removed before the matching one is added, so repeated
     * toggles never stack duplicates and the light theme can never keep the
     * dark editor colours -- the failure the old syntax-dark overlay had to
     * guard against by hand.
     *
     * @param ide   the IDE controller
     * @param theme the theme being applied
     */
    private static void applyEditorStylesheet(UI_Main ide, String theme) {
        URL editorLight = ThemeManager.class.getResource(EDITOR_LIGHT_CSS);
        URL editorDark = ThemeManager.class.getResource(EDITOR_DARK_CSS);

        if (editorLight != null) {
            ide.scene.getStylesheets().remove(editorLight.toExternalForm());
        }
        if (editorDark != null) {
            ide.scene.getStylesheets().remove(editorDark.toExternalForm());
        }

        boolean darkInk = DARK.equals(theme);
        if (editorInkSelector != null) {
            Boolean chosen = editorInkSelector.apply(theme);
            if (chosen != null) {
                darkInk = chosen;
            }
        }

        URL editor = darkInk ? editorDark : editorLight;
        if (editor != null) {
            ide.scene.getStylesheets().add(editor.toExternalForm());
        } else {
            System.err.println("Editor stylesheet missing: "
                    + (darkInk ? EDITOR_DARK_CSS : EDITOR_LIGHT_CSS));
        }

        // The text colours go straight after the editor sheet, in the same
        // brightness, so a dark editor in the light theme gets dark-editor
        // text colours too.
        TextColourManager.apply(ide, theme, darkInk);
    }

    /**
     * Drops any of the superseded editor stylesheets that are still on the
     * scene. Harmless and free once the old files are gone.
     *
     * @param ide the IDE controller
     */
    private static void removeLegacyEditorStylesheets(UI_Main ide) {
        for (String path : LEGACY_EDITOR_CSS) {
            URL url = ThemeManager.class.getResource(path);
            if (url != null) {
                ide.scene.getStylesheets().remove(url.toExternalForm());
            }
        }
    }

    /*
     * =========================================================
     * ICON UPDATE
     * =========================================================
     */

    /**
     * Points the raster icon sets at the matching ink. Those PNGs are raster,
     * so unlike the rest of the palette they cannot follow the stylesheet on
     * their own -- each set ships twice and this picks one. Every icon already
     * on screen is re-pointed in place, so the ribbon does not need rebuilding.
     *
     * @param theme the theme just applied
     */
    private static void applyIconInk(String theme) {
        boolean dark = DARK.equals(theme);
        HomeFilesIcons.setDarkTheme(dark);

        // The Home ribbon's non-Files icons (Run, Stop, Plot, Import, Step,
        // Code Bot, ...) live under /icons/home_icons with a "_dark" twin each.
        // Without this line they kept their light-theme art on the dark band --
        // the icons that "weren't loading" in dark mode. HomeRibbonIcons holds
        // a weak registry of every icon on screen and re-points them here.
        HomeRibbonIcons.setDarkTheme(dark);

        // This call is technically redundant while ToolbarIcons.setDarkMode
        // below forwards to the same method -- setDarkTheme short-circuits
        // when the flag has not moved, so the second call is free. It is
        // stated explicitly because this is the one place a reader looks to
        // find out which icon sets follow the theme, and a set that only
        // switches as a side effect of another class is a set that quietly
        // stops switching the day that forward is removed.
        NcRibbonIcons.setDarkTheme(dark);

        // ToolbarIcons was never being told about the theme, so every icon it
        // loaded kept the light-theme ink and the "/icons/dark/..." variants
        // were unreachable. Setting the flag here is what makes the breadcrumb
        // chevrons -- and any other dark asset added later -- resolve.
        ToolbarIcons.setDarkMode(dark);

        // The fold column's + / - glyphs are raster too, and they sit in every
        // open editor tab rather than on the ribbon. FoldIcons keeps the same
        // kind of weak registry and re-points each marker in place, so folds
        // stay exactly as the user left them across a theme switch.
        FoldIcons.setDarkTheme(dark);

        // The navigation bar and breadcrumb icons (Home, Back, Forward, Up,
        // Cloud, Root, the folder mark and the chevrons) live under
        // /icons/naviBread/{light,dark}. NaviBreadIcons keeps a weak registry
        // like the sets above and re-points every one in place, so the
        // breadcrumb no longer has to be redrawn to change ink.
        NaviBreadIcons.setDarkTheme(dark);

        // The Signals band's icons. SignalIcons' own documentation asked for
        // this call, but it was never added, so the Signals band kept its
        // light ink after switching to dark.
        SignalIcons.setDarkTheme(dark);

        // The Settings band (Layout, Text Colours, Syntax, Plot Setup, Net Setup) and
        // the gear beside "Settings..." in the suggestion popup's menu.
        SettingsIcons.setDarkTheme(dark);

        // The Layout band that opens from Settings > Layout: the six layout
        // tiles, Full Screen, the gutter toggles and the zoom rows, under
        // /icons/layout/{light,dark}.
        LayoutIcons.setDarkTheme(dark);

        // The editor's find / replace bar: expand arrow, the four toggles,
        // previous / next, clear and close, under /icons/search/{light,dark}.
        // It also tells the match painter which fallback colours to use.
        SearchIcons.setDarkTheme(dark);
    }

    public static void updateThemeIcon(UI_Main ide) {
    }

    /**
     * @return the theme currently in force, for secondary windows built before
     */
    public static String getActiveTheme() {
        return activeTheme;
    }

    public static void registerScene(Scene scene) {
    }
}
