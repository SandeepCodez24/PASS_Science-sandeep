package ui.managers;

import java.net.URL;

import javafx.animation.FadeTransition;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.util.Duration;
import ui.UI_Main;
import ui.ui_functions.tools.HomeFilesIcons;

/**
 * Owns the light/dark theme: which stylesheet is on the scene, which ink the
 * Files icon set uses, and which glyph the toggle button shows.
 */
public class ThemeManager {

    private static final String BASE_CSS = "/themes/plot.css";
    private static final String THEME_PATH = "/themes/";
    private static final String SYNTAX_CSS = "/language_design/syntax.css";

    private static final String DARK = "dark";
    private static final String LIGHT = "light";

    private static String activeTheme = LIGHT;

    /*
     * =========================================================
     * INIT (CALL ONCE AFTER SCENE CREATION)
     * =========================================================
     */
    public static void init(UI_Main ide) {

        if (ide.scene == null)
            return;

        loadBaseCSS(ide);
        applySavedTheme(ide);
    }

    /*
     * =========================================================
     * BASE CSS (LOAD ONLY ONCE)
     * =========================================================
     */
    public static void loadBaseCSS(UI_Main ide) {

        if (ide.scene == null)
            return;

        URL url = ThemeManager.class.getResource(BASE_CSS);
        if (url == null)
            return;

        String base = url.toExternalForm();

        if (!ide.scene.getStylesheets().contains(base)) {
            ide.scene.getStylesheets().add(0, base);
        }

        ide.baseStylesheet = base;
    }

    /*
     * =========================================================
     * APPLY SAVED THEME
     * =========================================================
     */
    public static void applySavedTheme(UI_Main ide) {

        String theme = ide.prefs.get("theme", LIGHT);
        applyTheme(ide, theme);
    }

    /*
     * =========================================================
     * TOGGLE THEME
     * =========================================================
     */
    public static void toggleTheme(UI_Main ide) {

        if (ide.rootNode == null)
            return;

        FadeTransition out = new FadeTransition(Duration.millis(120), ide.rootNode);
        out.setFromValue(1);
        out.setToValue(0);

        out.setOnFinished(e -> {

            String current = ide.currentTheme == null ? LIGHT : ide.currentTheme;
            String next = current.equals(LIGHT) ? DARK : LIGHT;

            applyTheme(ide, next);

            FadeTransition in = new FadeTransition(Duration.millis(120), ide.rootNode);
            in.setFromValue(0);
            in.setToValue(1);
            in.play();
        });

        out.play();
    }

    /*
     * =========================================================
     * APPLY THEME (CORE ENGINE)
     * =========================================================
     */
    public static void applyTheme(UI_Main ide, String theme) {

        if (ide.scene == null)
            return;

        loadBaseCSS(ide);

        URL themeResource = ThemeManager.class.getResource(THEME_PATH + theme + ".css");
        if (themeResource == null) {
            System.err.println("Theme stylesheet missing: " + THEME_PATH + theme + ".css");
            return;
        }
        String themeUrl = themeResource.toExternalForm();

        // Language syntax stylesheet (token styles for CodeArea). Guarded, so
        // toggling the theme repeatedly does not stack duplicate copies of it
        // on the scene.
        URL syntax = ThemeManager.class.getResource(SYNTAX_CSS);
        if (syntax != null) {
            String syntaxUrl = syntax.toExternalForm();
            if (!ide.scene.getStylesheets().contains(syntaxUrl)) {
                ide.scene.getStylesheets().add(syntaxUrl);
            }
        }

        /* REMOVE OLD THEME */
        if (ide.currentThemeStylesheet != null) {
            ide.scene.getStylesheets().remove(ide.currentThemeStylesheet);
        }

        /* ADD NEW THEME */
        ide.scene.getStylesheets().add(themeUrl);

        ide.currentThemeStylesheet = themeUrl;
        ide.currentTheme = theme;
        activeTheme = theme;
        ide.prefs.put("theme", theme);

        applyIconInk(theme);
        updateThemeIcon(ide);
    }

    /*
     * =========================================================
     * ICON UPDATE
     * =========================================================
     */

    /**
     * Points the Files ribbon icons at the matching ink. Those PNGs are
     * raster, so unlike the rest of the palette they cannot follow the
     * stylesheet on their own -- the set ships twice and this picks one.
     * Every icon already on screen is re-pointed in place, so the ribbon does
     * not need rebuilding.
     *
     * @param theme the theme just applied
     */
    private static void applyIconInk(String theme) {
        HomeFilesIcons.setDarkTheme(DARK.equals(theme));
    }

    public static void updateThemeIcon(UI_Main ide) {

        if (ide.themeToggle == null)
            return;

        if (ide.themeIconView == null) {
            ide.themeIconView = new ImageView();
            ide.themeIconView.setFitWidth(16);
            ide.themeIconView.setFitHeight(16);
            ide.themeIconView.setPreserveRatio(true);
            ide.themeToggle.setGraphic(ide.themeIconView);
        }
        ide.themeIconView.setSmooth(true);
        ide.themeIconView.setCache(true);
        ide.themeIconView.setImage(
                DARK.equals(ide.currentTheme)
                        ? ide.sunIcon
                        : ide.moonIcon);
    }

    /**
     * @return the theme currently in force, for secondary windows built before
     *         they have a UI_Main to ask
     */
    public static String getActiveTheme() {
        return activeTheme;
    }

    public static void registerScene(Scene scene) {

        if (scene == null)
            return;

        URL base = ThemeManager.class.getResource(BASE_CSS);

        if (base != null) {

            String css = base.toExternalForm();

            if (!scene.getStylesheets().contains(css)) {
                scene.getStylesheets().add(css);
            }
        }

        URL theme = ThemeManager.class.getResource(
                THEME_PATH + activeTheme + ".css");

        if (theme != null) {

            String css = theme.toExternalForm();

            if (!scene.getStylesheets().contains(css)) {
                scene.getStylesheets().add(css);
            }
        }
    }
}
