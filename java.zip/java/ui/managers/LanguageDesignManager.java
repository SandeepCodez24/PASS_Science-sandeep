package ui.managers;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import language.replace.Greek;
import language.replace.Malayalam;
import language.replace.Sanskrit;
import language.replace.Subscript;
import language.replace.Superscript;
import language.replace.Tamil;
import language.replace.Telugu;
import language.replace.Uniconstant;
import language.semantic.SemanticEncoder;
import ui.editor.EditorFileInfo;

public final class LanguageDesignManager {

    private LanguageDesignManager() {
        // Utility class
    }

    public static String preprocess(String code) {
        StringBuilder cleaned = new StringBuilder();
        String[] lines = code.split("\\R");

        for (String line : lines) {
            // Remove everything after # or \\ (outside quoted strings)
            line = stripTrailingComment(line);

            line = line.trim();
            if (line.isEmpty()) {
                continue;
            }

            // Normalize formatting used by the semantic encoder.
            line = line.replaceAll("\\s*=\\s*", "=");
            line = line.replaceAll("\\s*;\\s*", ";");

            cleaned.append(line).append("\n");
        }

        return cleaned.toString();
    }

    public static Path buildSemanticPath(EditorFileInfo info) {
        if (info == null || info.path == null) {
            return Path.of("cleaned_Runfile.nc");
        }

        Path parent = info.path.getParent();
        if (parent == null) {
            parent = Path.of(".");
        }

        return parent.resolve("cleaned_Runfile.nc");
    }

    public static Path buildVariablePath(EditorFileInfo info) {
        if (info == null || info.path == null) {
            return Path.of("variables_Runfile.dict");
        }

        Path parent = info.path.getParent();
        if (parent == null) {
            parent = Path.of(".");
        }

        return parent.resolve("variables_Runfile.dict");
    }

    /**
     * Build path for the Java dictionary file used by VariableFileWriter.writeJavaDictionaryFile.
     */
    public static Path buildJavaDictionaryPath(EditorFileInfo info) {
        if (info == null || info.path == null) {
            return Path.of("java_dictionary_Runfile.dict");
        }

        Path parent = info.path.getParent();
        if (parent == null) {
            parent = Path.of(".");
        }

        return parent.resolve("java_dictionary_Runfile.dict");
    }

    public static boolean isUpiFile(Path path) {
        String name = path.getFileName().toString().toLowerCase();
        return name.endsWith(".nc");
    }

    public static String writeSemanticFileFromUiCode(String uiCode, Path semanticPath) throws IOException {
        String cleanedCode = preprocess(uiCode);
        // Apply replacements (Greek/Sanskrit/Tamil/Hindi and sub/superscripts) before encoding
        String replaced = applySymbolReplacements(cleanedCode);
        String semanticCode = SemanticEncoder.encode(replaced);

        Files.writeString(
                semanticPath,
                semanticCode,
                StandardOpenOption.CREATE,
                StandardOpenOption.TRUNCATE_EXISTING);

        return semanticCode;
    }

    public static String applySymbolReplacements(String text) {
        String replaced = text;

        // Greek symbols
        for (var entry : Greek.SYMBOL_MAP.entrySet()) {
            replaced = replaced.replace(entry.getKey(), entry.getValue());
        }

        // Sanskrit symbols
        for (var entry : Sanskrit.SYMBOL_MAP.entrySet()) {
            replaced = replaced.replace(entry.getKey(), entry.getValue());
        }
        
        // Uni constants
        for (var entry : Uniconstant.SYMBOL_MAP.entrySet()) {
            replaced = replaced.replace(entry.getKey(), entry.getValue());
        }

        // Tamil vowels
        for (var entry : Tamil.TAMIL_VOWEL_MAP.entrySet()) {
            replaced = replaced.replace(entry.getKey(), entry.getValue());
        }

        // Tamil consonants
        for (var entry : Tamil.TAMIL_CONSONANT_MAP.entrySet()) {
            replaced = replaced.replace(entry.getKey(), entry.getValue());
        }

         // Malayalam vowels
        for (var entry : Malayalam.MALAYALAM_VOWEL_MAP.entrySet()) {
            replaced = replaced.replace(entry.getKey(), entry.getValue());
        }

        // Malayalam consonants
        for (var entry : Malayalam.MALAYALAM_CONSONANT_MAP.entrySet())  {
            replaced = replaced.replace(entry.getKey(), entry.getValue());
        }

        // Telugu vowels
        for (var entry : Telugu.TELUGU_VOWEL_MAP.entrySet()) {
            replaced = replaced.replace(entry.getKey(), entry.getValue());
        }

        // Telugu consonants
        for (var entry : Telugu.TELUGU_CONSONANT_MAP.entrySet()) {
            replaced = replaced.replace(entry.getKey(), entry.getValue());
        }

        // Superscript: ^^0 -> ⁰, ^^1 -> ¹, etc.
        for (char c = '0'; c <= '9'; c++) {
            if (Superscript.hasUnicode(c)) {
                replaced = replaced.replace("^^" + c, Superscript.unicode(c));
            }
        }

        // Subscript: __0 -> ₀, __1 -> ₁, etc.
        for (char c = '0'; c <= '9'; c++) {
            if (Subscript.hasNumericSubscript(c)) {
                replaced = replaced.replace("__" + c, Subscript.numericSubscript(c));
            }
        }

        return replaced;
    }

    /**
     * Convert editor-only marker sequences (ZERO WIDTH NON-JOINER/U+200C and
     * ZERO WIDTH JOINER/U+200D) used for CSS-based superscript/subscript into
     * Unicode characters where possible for variable-file output.
     */
    public static String normalizeMarkersForVariables(String text) {
        if (text == null || text.isEmpty()) return text;

        String s = text;

        // Multi-letter superscript group: \u200C\u200C\u200C ... \u200C\u200C\u200C
        Pattern p = Pattern.compile("\u200C\u200C\u200C(.*?)\u200C\u200C\u200C", Pattern.DOTALL);
        Matcher m = p.matcher(s);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String grp = m.group(1);
            StringBuilder rep = new StringBuilder();
            for (char ch : grp.toCharArray()) {
                if (language.replace.Superscript.hasUnicode(ch)) {
                    rep.append(language.replace.Superscript.unicode(ch));
                } else {
                    rep.append(ch);
                }
            }
            m.appendReplacement(sb, Matcher.quoteReplacement(rep.toString()));
        }
        m.appendTail(sb);
        s = sb.toString();

       

        // Single-character superscript: \u200C x \u200C
        p = Pattern.compile("\u200C(.)\u200C", Pattern.DOTALL);
        m = p.matcher(s);
        sb = new StringBuffer();
        while (m.find()) {
            char ch = m.group(1).charAt(0);
            String rep = language.replace.Superscript.hasUnicode(ch)
                    ? language.replace.Superscript.unicode(ch)
                    : String.valueOf(ch);
            m.appendReplacement(sb, Matcher.quoteReplacement(rep));
        }
        m.appendTail(sb);
        s = sb.toString();

       

        // Remove any remaining marker characters
        s = s.replace("\u200C", "").replace("\u200D", "");

        return s;
    }

    private static String stripTrailingComment(String line) {
        boolean inQuote = false;

        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (ch == '"' && !isEscaped(line, i)) {
                inQuote = !inQuote;
                continue;
            }

            if (!inQuote) {
                if (ch == '#') {
                    return line.substring(0, i);
                }
                if (ch == '\\' && i + 1 < line.length() && line.charAt(i + 1) == '\\') {
                    return line.substring(0, i);
                }
            }
        }

        return line;
    }

    private static boolean isEscaped(String text, int index) {
        int backslashCount = 0;
        int i = index - 1;
        while (i >= 0 && text.charAt(i) == '\\') {
            backslashCount++;
            i--;
        }
        return backslashCount % 2 != 0;
    }
}