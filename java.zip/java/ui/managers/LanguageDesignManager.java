package ui.managers;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import language.replace.Greek;
import language.replace.Malayalam;
import language.replace.Sanskrit;
import language.replace.Subscript;
import language.replace.Superscript;
import language.replace.Tamil;
import language.replace.Telugu;
import language.replace.Uniconstant;
import language.semantic.ScriptMarkers;
import language.semantic.SemanticEncoder;
import ui.editor.EditorFileInfo;

/**
 * Turns editor text into the machine-readable form the interpreter runs.
 *
 * <h3>Where cleaned_Runfile.nc lives</h3>
 * It is now written to a private temp directory, not beside the user's source.
 * That is the shape you want for the standalone build (the cleaned file is an
 * implementation detail the user should never see) and it also stops the file
 * cluttering project folders during development. Two escape hatches:
 * <ul>
 *   <li>{@code -Dastra.temp.dir=<path>} moves the directory.</li>
 *   <li>{@code -Dastra.cleaned.beside=true} writes it next to the source
 *       instead, which is handy while you are debugging the encoder.</li>
 * </ul>
 *
 * <h3>Symbol replacement ordering</h3>
 * Replacements are applied longest-key-first. Iterating the raw {@code HashMap}
 * meant the one-character Tamil rule could fire before the two-character rule
 * and corrupt the result.
 *
 * <h3>String literals are not code (fixed)</h3>
 * {@link #preprocess(String)} used to run
 * {@code replaceAll("\\s*=\\s*", "=")} across the whole line. That rewrote the
 * <i>contents</i> of string literals, so
 *
 * <pre>
 *   publish("7 + 5 =", 7 + 5);
 * </pre>
 *
 * reached the interpreter as {@code publish("7 + 5=",7+5);} and printed a
 * different message than the user wrote. The collapse now runs only on the
 * stretches of a line that sit outside a literal. {@link #stripTrailingComment}
 * gained the same awareness: it tracked {@code "} alone, so an apostrophe --
 * in a literal or in prose -- opened a quote that never closed and any
 * {@code #} after it was kept as code.
 *
 * <p>
 * Both {@code "} and {@code '} delimit strings and each nests freely inside the
 * other, so only the quote that opened a literal can close it. This matches the
 * rule the editor's syntax checker applies, which is the point: the two must
 * agree about where code stops and text starts.
 */
public final class LanguageDesignManager {

    private static final String TEMP_DIR_PROPERTY = "astra.temp.dir";
    private static final String BESIDE_PROPERTY = "astra.cleaned.beside";
    private static final String CLEANED_FILE = "cleaned_Runfile.nc";

    /** All visual-to-editor-token rules, longest key first. */
    private static final List<Map.Entry<String, String>> REPLACEMENTS = buildReplacements();

    private LanguageDesignManager() {
    }

    /**
     * Strips comments and normalises whitespace ahead of encoding.
     *
     * <p>
     * The {@code ~~} continuation marker is deliberately left in place: joining
     * split lines is the interpreter's job, and folding them here would change
     * the line numbering the backend reports against.
     *
     * @param code raw editor text
     * @return preprocessed text
     */
    public static String preprocess(String code) {
        StringBuilder cleaned = new StringBuilder();
        for (String rawLine : code.split("\\R")) {
            String line = stripTrailingComment(rawLine).trim();
            if (line.isEmpty()) {
                continue;
            }
            cleaned.append(collapseSpacingOutsideStrings(line)).append('\n');
        }
        return cleaned.toString();
    }

    /**
     * Resolves where {@code cleaned_Runfile.nc} should be written for a file.
     *
     * @param info the editor tab's file info (may be null)
     * @return the cleaned file's path
     */
    public static Path buildSemanticPath(EditorFileInfo info) {
        if (Boolean.getBoolean(BESIDE_PROPERTY) && info != null && info.path != null) {
            Path parent = info.path.getParent();
            return (parent == null ? Path.of(".") : parent).resolve(CLEANED_FILE);
        }
        return runtimeTempDirectory().resolve(CLEANED_FILE);
    }

    /**
     * @return the private directory holding generated run artefacts, created
     *         if needed; falls back to the current directory if it cannot be
     *         created
     */
    public static Path runtimeTempDirectory() {
        String configured = System.getProperty(TEMP_DIR_PROPERTY);
        Path base = configured != null && !configured.isBlank()
                ? Path.of(configured)
                : Path.of(System.getProperty("java.io.tmpdir")).resolve("Astra");
        try {
            Files.createDirectories(base);
            return base;
        } catch (IOException ex) {
            return Path.of(".");
        }
    }

    /**
     * @param info the editor tab's file info
     * @return legacy variable-dictionary path (unused by the new pipeline)
     */
    public static Path buildVariablePath(EditorFileInfo info) {
        return runtimeTempDirectory().resolve("variables_Runfile.dict");
    }

    /**
     * @param info the editor tab's file info
     * @return legacy Java-dictionary path (unused by the new pipeline)
     */
    public static Path buildJavaDictionaryPath(EditorFileInfo info) {
        return runtimeTempDirectory().resolve("java_dictionary_Runfile.dict");
    }

    /**
     * @param path a file path
     * @return true when it is a Neural Code source file
     */
    public static boolean isUpiFile(Path path) {
        return path != null && path.getFileName().toString().toLowerCase().endsWith(".nc");
    }

    /**
     * The one and only conversion from editor text to the cleaned run file.
     *
     * @param uiCode       the editor's text
     * @param semanticPath where to write the cleaned file
     * @return the cleaned code that was written
     * @throws IOException if the file cannot be written
     */
    public static String writeSemanticFileFromUiCode(String uiCode, Path semanticPath) throws IOException {
        String semanticCode = toCleanedCode(uiCode);
        Path parent = semanticPath.getParent();
        if (parent != null) {
            Files.createDirectories(parent);
        }
        Files.writeString(semanticPath, semanticCode, StandardCharsets.UTF_8,
                StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        return semanticCode;
    }

    /**
     * Editor text to cleaned code, without writing anything. Exposed so the
     * runner and any future caller cannot accidentally skip a stage — the
     * previous runner called {@code SemanticEncoder.encode} directly and
     * therefore never applied the symbol replacements.
     *
     * @param uiCode the editor's text
     * @return the cleaned code
     */
    public static String toCleanedCode(String uiCode) {
        return SemanticEncoder.encode(applySymbolReplacements(preprocess(uiCode)));
    }

    /**
     * Applies every symbol dictionary plus the {@code ^^n} / {@code __n} script
     * shorthands, longest rule first.
     *
     * @param text the text to transform
     * @return the transformed text
     */
    public static String applySymbolReplacements(String text) {
        String replaced = text;
        for (Map.Entry<String, String> entry : REPLACEMENTS) {
            replaced = replaced.replace(entry.getKey(), entry.getValue());
        }
        for (char c = '0'; c <= '9'; c++) {
            if (Superscript.hasUnicode(c)) {
                replaced = replaced.replace("^^" + c, Superscript.unicode(c));
            }
            if (Subscript.hasNumericSubscript(c)) {
                replaced = replaced.replace("__" + c, Subscript.numericSubscript(c));
            }
        }
        return replaced;
    }

    /**
     * Converts editor-only zero-width markers into real Unicode where possible
     * and drops the rest, so no invisible character can reach the interpreter.
     *
     * @param text the text to normalise
     * @return the normalised text
     */
    public static String normalizeMarkersForVariables(String text) {
        if (text == null || text.isEmpty()) {
            return text;
        }
        // The encoder already understands both the group and the single-marker
        // forms, so normalisation is just the safety sweep now.
        return text.replace(String.valueOf(ScriptMarkers.ZWJ), "")
                .replace(String.valueOf(ScriptMarkers.ZWNJ), "");
    }

    // -----------------------------------------------------------------
    // Internals
    // -----------------------------------------------------------------

    private static List<Map.Entry<String, String>> buildReplacements() {
        Map<String, String> merged = new LinkedHashMap<>();
        merged.putAll(Greek.SYMBOL_MAP);
        merged.putAll(Sanskrit.SYMBOL_MAP);
        merged.putAll(Uniconstant.SYMBOL_MAP);
        merged.putAll(Tamil.TAMIL_VOWEL_MAP);
        merged.putAll(Tamil.TAMIL_CONSONANT_MAP);
        merged.putAll(Malayalam.MALAYALAM_VOWEL_MAP);
        merged.putAll(Malayalam.MALAYALAM_CONSONANT_MAP);
        merged.putAll(Telugu.TELUGU_VOWEL_MAP);
        merged.putAll(Telugu.TELUGU_CONSONANT_MAP);

        List<Map.Entry<String, String>> entries = new ArrayList<>(merged.entrySet());
        entries.sort(Comparator
                .comparingInt((Map.Entry<String, String> e) -> e.getKey().length())
                .reversed()
                .thenComparing(Map.Entry::getKey));
        return List.copyOf(entries);
    }

    /**
     * Collapses the whitespace around {@code =} and {@code ;}, but only in the
     * stretches of the line that lie outside a string literal.
     *
     * @param line one comment-stripped, trimmed line
     * @return the line with spacing normalised outside its literals
     */
    private static String collapseSpacingOutsideStrings(String line) {
        StringBuilder out = new StringBuilder(line.length());
        StringBuilder codeSegment = new StringBuilder();
        char openQuote = 0;

        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);

            if (openQuote != 0) {
                // Inside a literal: copied through byte for byte.
                out.append(ch);
                if (ch == openQuote && !isEscaped(line, i)) {
                    openQuote = 0;
                }
                continue;
            }

            if ((ch == '"' || ch == '\'') && !isEscaped(line, i)) {
                out.append(collapseSpacing(codeSegment.toString()));
                codeSegment.setLength(0);
                out.append(ch);
                openQuote = ch;
                continue;
            }

            codeSegment.append(ch);
        }

        out.append(collapseSpacing(codeSegment.toString()));
        return out.toString();
    }

    private static String collapseSpacing(String text) {
        if (text.isEmpty()) {
            return text;
        }
        return text.replaceAll("\\s*=\\s*", "=").replaceAll("\\s*;\\s*", ";");
    }

    /**
     * Removes a trailing {@code #} or {@code \\} comment, honouring both string
     * delimiters.
     *
     * @param line one physical line
     * @return the line with any comment removed
     */
    private static String stripTrailingComment(String line) {
        char openQuote = 0;

        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);

            if (openQuote != 0) {
                if (ch == openQuote && !isEscaped(line, i)) {
                    openQuote = 0;
                }
                continue;
            }

            if ((ch == '"' || ch == '\'') && !isEscaped(line, i)) {
                openQuote = ch;
                continue;
            }

            if (ch == '#') {
                return line.substring(0, i);
            }
            if (ch == '\\' && i + 1 < line.length() && line.charAt(i + 1) == '\\') {
                return line.substring(0, i);
            }
        }

        return line;
    }

    private static boolean isEscaped(String text, int index) {
        int backslashCount = 0;
        int i = index - 1;
        while (i >= 0 && text.charAt(i) == '\\') {
            backslashCount++;
            i--;
        }
        return backslashCount % 2 != 0;
    }
}
