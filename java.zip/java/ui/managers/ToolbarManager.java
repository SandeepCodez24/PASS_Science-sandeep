package ui.managers;

import java.nio.file.Path;

import javafx.scene.control.ToolBar;
import javafx.scene.image.Image;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import ui.UI_Main;
import ui.ui_functions.tools.ToolbarIcons;
import ui.ui_functions.tools.ToolbarNavigation;
import ui.ui_functions.tools.ToolbarSetup;
import ui.ui_functions.tools.ToolbarState;

public class ToolbarManager {

    public static ToolBar ribbonBar;
    public static StackPane toolbarStack;
    public static ToolBar quickAccessBar;
    public static Region quickPathLabel;

    public static Image loadIconPublic(String path) {
        return ToolbarIcons.loadIconPublic(path);
    }

    public static void setupToolbars(UI_Main ide) {
        ToolbarSetup.setupToolbars(ide);
        syncState();
    }

    public static void updateQuickPath(Path path) {
        ToolbarNavigation.updateQuickPath(path);
        quickPathLabel = ToolbarState.quickPathLabel;
    }

    private static void syncState() {
        ribbonBar = ToolbarState.ribbonBar;
        toolbarStack = ToolbarState.toolbarStack;
        quickAccessBar = ToolbarState.quickAccessBar;
        quickPathLabel = ToolbarState.quickPathLabel;
    }

    static {
        syncState();
    }

    private boolean programRunning = false;

    public boolean isProgramRunning() {
        return programRunning;
    }

    public void setProgramRunning(boolean running) {
        this.programRunning = running;
    }
}