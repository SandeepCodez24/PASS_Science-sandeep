package ui.managers;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import javafx.scene.control.TreeItem;
import javafx.stage.DirectoryChooser;
import ui.UI_Main;
import ui.directory.DirectoryTreeItem;
import ui.directory.NcMetrics;
import ui.directory.repo.RepoStatusRegistry;

/**
 * Loads and refreshes the directory explorer's contents.
 *
 * <h3>What changed</h3>
 * <ul>
 * <li>The recursive {@code buildTree} is gone. Nodes are
 * {@link DirectoryTreeItem}s, which read their folder when they are first
 * expanded. The old version walked the whole subtree before showing anything,
 * which was already wasteful and becomes unusable now that the Info column
 * reads files.</li>
 * <li>Every root change tells {@link RepoStatusRegistry}, so the Repo column
 * can ask once whether the new root is a working copy instead of once per
 * row.</li>
 * <li>{@code ide.projectTree} is a {@code TreeTableView} now. Every method used
 * here -- {@code setRoot}, {@code getRoot}, {@code getSelectionModel} -- exists
 * on both types with the same signature, so the body is otherwise as it
 * was.</li>
 * </ul>
 */
public class ProjectManager {

    /**
     * Load a project folder chosen from a dialog.
     *
     * <p>
     * Kept for any older call sites. New code should go through
     * {@code EditorFileOpener.openProjectFolder}, which additionally records
     * the folder as the last project so the Open menu can return to it.
     * </p>
     *
     * @param ide the IDE controller
     */
    public static void loadProject(UI_Main ide) {
        if (ide == null) {
            return;
        }
        DirectoryChooser dc = new DirectoryChooser();
        dc.setTitle("Select Project Folder");
        File dir = dc.showDialog(ide.stage);
        if (dir == null) {
            return;
        }
        loadProjectFromPath(ide, dir.toPath());
    }

    /**
     * Load a project from a specific path.
     *
     * <p>
     * This is the single place that moves the project root: it sets
     * {@code ide.currentFolder}, pushes the path to the breadcrumb bar, and
     * installs a fresh tree root. Anything that wants the tree to point
     * somewhere new comes through here -- including a double-click on a folder
     * in the tree, which reaches it via
     * {@code NavigationActions.goTo}. That is what keeps the tree and the
     * breadcrumb in step in both directions.
     * </p>
     *
     * @param ide  the IDE controller
     * @param path the folder to show
     */
    public static void loadProjectFromPath(UI_Main ide, Path path) {
        if (ide == null || path == null || !Files.isDirectory(path)) {
            return;
        }

        Path normalised = path.toAbsolutePath().normalize();
        ide.currentFolder = normalised;
        ToolbarManager.updateQuickPath(normalised);

        // Asked once per root, not once per row.
        RepoStatusRegistry.rootChanged(normalised);

        if (ide.projectTree == null) {
            return;
        }

        ide.projectTree.setRoot(DirectoryTreeItem.rootFor(normalised));
        if (ide.projectTree.getSelectionModel() != null) {
            ide.projectTree.getSelectionModel().clearSelection();
        }
    }

    /**
     * Redraw the tree in place, keeping the same root.
     *
     * <p>
     * Use this after files change on disk. It deliberately does not read
     * {@code ide.currentFolder}, because opening a file moves that field to the
     * file's parent and the tree should not follow. When the tree has no root
     * at all, {@code currentFolder} is used as a starting point.
     * </p>
     *
     * <p>
     * The cached line, function and class counts are dropped at the same time.
     * A refresh is what happens after a save, and a saved file is exactly the
     * one whose counts are now wrong.
     * </p>
     *
     * @param ide the IDE controller
     */
    public static void refreshProjectTree(UI_Main ide) {
        if (ide == null || ide.projectTree == null) {
            return;
        }

        TreeItem<Path> existing = ide.projectTree.getRoot();
        Path rootPath = (existing != null) ? existing.getValue() : ide.currentFolder;
        if (rootPath == null || !Files.isDirectory(rootPath)) {
            return;
        }

        NcMetrics.invalidateAll();
        ide.projectTree.setRoot(DirectoryTreeItem.rootFor(rootPath));
    }
}
