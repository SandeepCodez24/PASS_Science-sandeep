package ui.managers;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.stream.Stream;

import javafx.scene.control.TreeItem;
import javafx.stage.DirectoryChooser;
import ui.UI_Main;

public class ProjectManager {

    /**
     * Load a project folder chosen from a dialog.
     *
     * <p>
     * Kept for any older call sites. New code should go through
     * {@code EditorFileOpener.openProjectFolder}, which additionally records
     * the folder as the last project so the Open menu can return to it.
     * </p>
     *
     * @param ide the IDE controller
     */
    public static void loadProject(UI_Main ide) {
        if (ide == null) {
            return;
        }
        DirectoryChooser dc = new DirectoryChooser();
        dc.setTitle("Select Project Folder");
        File dir = dc.showDialog(ide.stage);
        if (dir == null) {
            return;
        }
        loadProjectFromPath(ide, dir.toPath());
    }

    /**
     * Load a project from a specific path.
     *
     * <p>
     * This is the single place that moves the project root: it sets
     * {@code ide.currentFolder}, pushes the path to the quick-path/breadcrumb
     * bar, and installs a fresh tree root. Anything that wants the tree to
     * point somewhere new must come through here rather than through
     * {@link #refreshProjectTree(UI_Main)}, which only redraws where the tree
     * already is.
     * </p>
     *
     * @param ide  the IDE controller
     * @param path the folder to show
     */
    public static void loadProjectFromPath(UI_Main ide, Path path) {
        if (ide == null || path == null || !Files.isDirectory(path)) {
            return;
        }

        Path normalised = path.toAbsolutePath().normalize();

        ide.currentFolder = normalised;
        ToolbarManager.updateQuickPath(normalised);

        if (ide.projectTree == null) {
            return;
        }

        TreeItem<Path> root = new TreeItem<>(normalised);
        root.setExpanded(true);
        buildTree(root);

        ide.projectTree.setRoot(root);
        if (ide.projectTree.getSelectionModel() != null) {
            ide.projectTree.getSelectionModel().clearSelection();
        }
    }

    /**
     * Recursively build the tree structure for folders and files.
     *
     * @param parent the item whose children are to be populated
     */
    private static void buildTree(TreeItem<Path> parent) {
        try (Stream<Path> s = Files.list(parent.getValue())) {
            s.forEach(p -> {
                TreeItem<Path> item = new TreeItem<>(p);
                parent.getChildren().add(item);
                if (Files.isDirectory(p)) {
                    buildTree(item);
                }
            });
        } catch (IOException ignored) {
            // Unreadable folder: show it as a leaf rather than failing the load.
        }
    }

    /**
     * Redraw the tree in place, keeping the same root.
     *
     * <p>
     * Use this after files change on disk. It deliberately does not read
     * {@code ide.currentFolder}, because opening a file moves that field to the
     * file's parent and the tree should not follow. When the tree has no root
     * at all, {@code currentFolder} is used as a starting point.
     * </p>
     *
     * @param ide the IDE controller
     */
    public static void refreshProjectTree(UI_Main ide) {
        if (ide == null || ide.projectTree == null) {
            return;
        }

        TreeItem<Path> existing = ide.projectTree.getRoot();
        Path rootPath = (existing != null) ? existing.getValue() : ide.currentFolder;

        if (rootPath == null || !Files.isDirectory(rootPath)) {
            return;
        }

        TreeItem<Path> newRoot = new TreeItem<>(rootPath);
        newRoot.setExpanded(true);
        buildTree(newRoot);

        ide.projectTree.setRoot(newRoot);
    }
}
