package ui.managers;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.stream.Stream;

import javafx.scene.control.TreeItem;
import javafx.stage.DirectoryChooser;
import ui.UI_Main;

public class ProjectManager {

    /**
     * Load a project folder and populate the tree recursively.
     */
    public static void loadProject(UI_Main ide) {
        DirectoryChooser dc = new DirectoryChooser();
        dc.setTitle("Select Project Folder");
        File dir = dc.showDialog(ide.stage);
        if (dir == null)
            return;

        ide.currentFolder = dir.toPath();
        ToolbarManager.updateQuickPath(ide.currentFolder);

        TreeItem<Path> root = new TreeItem<>(dir.toPath());
        root.setExpanded(true);

        buildTree(root);
        ide.projectTree.setRoot(root);
    }

    /**
     * Load a project from a specific path (for navigation).
     */
    public static void loadProjectFromPath(UI_Main ide, Path path) {
        if (path == null || !Files.isDirectory(path))
            return;

        ide.currentFolder = path;
        ToolbarManager.updateQuickPath(ide.currentFolder);

        TreeItem<Path> root = new TreeItem<>(path);
        root.setExpanded(true);

        buildTree(root);
        ide.projectTree.setRoot(root);
    }

    /**
     * Recursively build the tree structure for folders and files.
     */
    private static void buildTree(TreeItem<Path> parent) {
        try (Stream<Path> s = Files.list(parent.getValue())) {
            s.forEach(p -> {
                TreeItem<Path> item = new TreeItem<>(p);
                parent.getChildren().add(item);
                if (Files.isDirectory(p)) {
                    buildTree(item);
                }
            });
        } catch (IOException ignored) {
        }
    }

    /**
     * Refresh the project tree to reflect changes in the file system.
     * Rebuilds the tree from the current project root.
     * 
     * @param ide the IDE controller
     */
    public static void refreshProjectTree(UI_Main ide) {
        if (ide.projectTree.getRoot() == null) {
            return;
        }

        Path rootPath = ide.projectTree.getRoot().getValue();
        TreeItem<Path> newRoot = new TreeItem<>(rootPath);
        newRoot.setExpanded(true);

        buildTree(newRoot);
        ide.projectTree.setRoot(newRoot);
    }

}