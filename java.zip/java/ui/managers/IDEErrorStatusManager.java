package ui.managers;

import ui.UI_Main;
import ui.design.Typography;
import javafx.scene.control.Tooltip;
import language.syntax.syntax_checker.ErrorChecker;

/**
 * The footer's error and warning counters.
 *
 * <p>
 * The counts combine three sources: the editor's syntax check, the compiler and
 * the interpreter. The editor's count comes from
 * {@link ErrorChecker.ErrorReport#getErrorCount()}, so every category the
 * checker knows -- operator sequence errors included -- is already counted
 * here without this class naming it.
 *
 * <h3>What changed (four categories)</h3>
 * The editor's share of the error tooltip now lists the four user-facing
 * categories -- Undefined Variable, Syntax, Unassigned Variable and
 * Indentation Errors -- from {@link ErrorChecker.ErrorReport#toCategoryText()},
 * the same classification the gutter and the Command Window use. Unterminated
 * string literals are Syntax Errors now, so the warning tooltip no longer
 * lists them; it shows the editor's warning count, which is currently always
 * zero.
 *
 * <h3>Earlier change</h3>
 * The tooltips used to read only "Total Errors: 7", so the user had to open the
 * file and hunt for red dots to learn what kind of errors they were. They now
 * break the editor's share down by category, reusing
 * {@link ErrorChecker.ErrorReport#toTooltipText()}, so the footer and the
 * editor's status box always list the same categories and a new category
 * appears in both at once. Compiler and interpreter counts are listed beneath
 * whenever they are non-zero.
 */
public final class IDEErrorStatusManager {

    private static int compilerErrors = 0;
    private static int compilerWarnings = 0;
    private static int interpreterErrors = 0;
    private static int interpreterWarnings = 0;
    private static int editorErrors = 0;
    private static int editorWarnings = 0;
    private static UI_Main currentIDE = null;

    /** The editor's latest report, for the tooltip breakdown; null when unknown. */
    private static ErrorChecker.ErrorReport editorReport = null;

    /** Set once the counters follow the Font Size setting. */
    private static boolean followingFontSize;

    private IDEErrorStatusManager() {
        // Utility class
    }

    public static void initialize(UI_Main ide) {
        if (!followingFontSize) {
            followingFontSize = true;
            // The counters' style is inline (it carries their colour), and an
            // inline style is only read when it is set: set it again when the
            // UI font size changes.
            Typography.addFontSizeListener(IDEErrorStatusManager::refreshDisplay);
        }
        currentIDE = ide;
        compilerErrors = 0;
        compilerWarnings = 0;
        interpreterErrors = 0;
        interpreterWarnings = 0;
        editorErrors = 0;
        editorWarnings = 0;
        editorReport = null;
        updateDisplayWithCombinedCounts();
    }

    private static void refreshDisplay() {
        if (currentIDE != null) {
            updateDisplayWithCombinedCounts();
        }
    }

    private static void updateDisplayWithCombinedCounts() {
        if (currentIDE == null || currentIDE.footerErrorButton == null || currentIDE.footerWarningButton == null) {
            return;
        }

        int totalErrors = editorErrors + compilerErrors + interpreterErrors;
        int totalWarnings = editorWarnings + compilerWarnings + interpreterWarnings;

        currentIDE.footerErrorButton.setText("✖ " + totalErrors);
        currentIDE.footerWarningButton.setText("⚠ " + totalWarnings);
        applyErrorButtonStyle(currentIDE, totalErrors);
        applyWarningButtonStyle(currentIDE, totalWarnings);

        currentIDE.footerErrorButton.setTooltip(new Tooltip(errorTooltip(totalErrors)));
        currentIDE.footerWarningButton.setTooltip(new Tooltip(warningTooltip(totalWarnings)));
    }

    /**
     * "Total Errors: n", then the editor's per-category counts, then the
     * compiler and interpreter shares when there are any.
     */
    private static String errorTooltip(int totalErrors) {
        StringBuilder text = new StringBuilder("Total Errors: ").append(totalErrors);
        if (editorReport != null) {
            text.append("\n\nEditor");
            for (String line : editorReport.toCategoryText().split("\n")) {
                text.append("\n  ").append(line);
            }
        }
        if (compilerErrors > 0) {
            text.append("\n\nCompiler errors: ").append(compilerErrors);
        }
        if (interpreterErrors > 0) {
            text.append("\n").append(compilerErrors > 0 ? "" : "\n")
                    .append("Interpreter errors: ").append(interpreterErrors);
        }
        return text.toString();
    }

    /** "Total Warnings: n" with the same breakdown. */
    private static String warningTooltip(int totalWarnings) {
        StringBuilder text = new StringBuilder("Total Warnings: ").append(totalWarnings);
        if (editorReport != null) {
            text.append("\n\nEditor warnings: ").append(editorReport.getWarningCount());
        }
        if (compilerWarnings > 0) {
            text.append("\n\nCompiler warnings: ").append(compilerWarnings);
        }
        if (interpreterWarnings > 0) {
            text.append("\n").append(compilerWarnings > 0 ? "" : "\n")
                    .append("Interpreter warnings: ").append(interpreterWarnings);
        }
        return text.toString();
    }

    public static void updateErrorStatusIndicator(UI_Main ide, int errors) {
        if (ide == null || ide.footerErrorButton == null || ide.footerWarningButton == null) {
            return;
        }
        
        currentIDE = ide;
        editorErrors = errors;
        editorWarnings = 0;
        editorReport = null; // a bare count carries no breakdown
        
        updateDisplayWithCombinedCounts();
    }

    public static void updateErrorStatusIndicator(UI_Main ide, ErrorChecker.ErrorReport report) {
        if (report == null) {
            updateErrorStatusIndicator(ide, 0);
            return;
        }

        if (ide == null || ide.footerErrorButton == null || ide.footerWarningButton == null) {
            return;
        }

        currentIDE = ide;
        editorErrors = report.getErrorCount();
        editorWarnings = report.getWarningCount();
        editorReport = report;
        
        updateDisplayWithCombinedCounts();
    }

    /**
     * Updates compiler error counts.
     * Called when C++/C files are compiled.
     *
     * @param errors compiler error count
     * @param warnings compiler warning count
     */
    public static void updateCompilerErrorCounts(int errors, int warnings) {
        compilerErrors = errors;
        compilerWarnings = warnings;
        refreshDisplay();
    }

    /**
     * Updates interpreter error counts.
     * Called when user types in interpreter terminal.
     *
     * @param errors interpreter error count
     * @param warnings interpreter warning count
     */
    public static void updateInterpreterErrorCounts(int errors, int warnings) {
        interpreterErrors = errors;
        interpreterWarnings = warnings;
        refreshDisplay();
    }

    /**
     * Gets current compiler error count.
     *
     * @return error count
     */
    public static int getCompilerErrorCount() {
        return compilerErrors;
    }

    /**
     * Gets current compiler warning count.
     *
     * @return warning count
     */
    public static int getCompilerWarningCount() {
        return compilerWarnings;
    }

    /**
     * Clears compiler error counts.
     */
    public static void clearCompilerErrors() {
        compilerErrors = 0;
        compilerWarnings = 0;
    }

    private static void applyErrorButtonStyle(UI_Main ide, int errorCount) {
        if (ide == null || ide.footerErrorButton == null) {
            return;
        }

        ide.footerErrorButton.setStyle("-fx-text-fill: #d32f2f; " + counterFont()
                + " -fx-background-color: transparent; -fx-padding: 0 4 0 4;");
    }

    private static void applyWarningButtonStyle(UI_Main ide, int warningCount) {
        if (ide == null || ide.footerWarningButton == null) {
            return;
        }

        ide.footerWarningButton.setStyle("-fx-text-fill: #f9a825; " + counterFont()
                + " -fx-background-color: transparent; -fx-padding: 0 4 0 4;");
    }

    /**
     * The counters' font: the footer-button role -- secondary text, 0.85 of
     * the UI font size -- in bold. It used to be a fixed 12.
     */
    private static String counterFont() {
        return Typography.css(Typography.Role.FOOTER_BUTTON) + " -fx-font-weight: bold;";
    }
}