package ui.managers;

import ui.UI_Main;
import javafx.scene.control.Tooltip;
import language.syntax.syntax_checker.ErrorChecker;

public final class IDEErrorStatusManager {

    private static int compilerErrors = 0;
    private static int compilerWarnings = 0;
    private static int interpreterErrors = 0;
    private static int interpreterWarnings = 0;
    private static int editorErrors = 0;
    private static int editorWarnings = 0;
    private static UI_Main currentIDE = null;

    private IDEErrorStatusManager() {
        // Utility class
    }

    public static void initialize(UI_Main ide) {
        currentIDE = ide;
        compilerErrors = 0;
        compilerWarnings = 0;
        interpreterErrors = 0;
        interpreterWarnings = 0;
        editorErrors = 0;
        editorWarnings = 0;
        updateDisplayWithCombinedCounts();
    }

    private static void refreshDisplay() {
        if (currentIDE != null) {
            updateDisplayWithCombinedCounts();
        }
    }

    private static void updateDisplayWithCombinedCounts() {
        if (currentIDE == null || currentIDE.footerErrorButton == null || currentIDE.footerWarningButton == null) {
            return;
        }

        int totalErrors = editorErrors + compilerErrors + interpreterErrors;
        int totalWarnings = editorWarnings + compilerWarnings + interpreterWarnings;

        currentIDE.footerErrorButton.setText("✖ " + totalErrors);
        currentIDE.footerWarningButton.setText("⚠ " + totalWarnings);
        applyErrorButtonStyle(currentIDE, totalErrors);
        applyWarningButtonStyle(currentIDE, totalWarnings);

        currentIDE.footerErrorButton.setTooltip(new Tooltip("Total Errors: " + totalErrors));
        currentIDE.footerWarningButton.setTooltip(new Tooltip("Total Warnings: " + totalWarnings));
    }

    public static void updateErrorStatusIndicator(UI_Main ide, int errors) {
        if (ide == null || ide.footerErrorButton == null || ide.footerWarningButton == null) {
            return;
        }
        
        currentIDE = ide;
        editorErrors = errors;
        editorWarnings = 0;
        
        updateDisplayWithCombinedCounts();
    }

    public static void updateErrorStatusIndicator(UI_Main ide, ErrorChecker.ErrorReport report) {
        if (report == null) {
            updateErrorStatusIndicator(ide, 0);
            return;
        }

        if (ide == null || ide.footerErrorButton == null || ide.footerWarningButton == null) {
            return;
        }

        currentIDE = ide;
        editorErrors = report.getErrorCount();
        editorWarnings = report.getWarningCount();
        
        updateDisplayWithCombinedCounts();
    }

    /**
     * Updates compiler error counts.
     * Called when C++/C files are compiled.
     *
     * @param errors compiler error count
     * @param warnings compiler warning count
     */
    public static void updateCompilerErrorCounts(int errors, int warnings) {
        compilerErrors = errors;
        compilerWarnings = warnings;
        refreshDisplay();
    }

    /**
     * Updates interpreter error counts.
     * Called when user types in interpreter terminal.
     *
     * @param errors interpreter error count
     * @param warnings interpreter warning count
     */
    public static void updateInterpreterErrorCounts(int errors, int warnings) {
        interpreterErrors = errors;
        interpreterWarnings = warnings;
        refreshDisplay();
    }

    /**
     * Gets current compiler error count.
     *
     * @return error count
     */
    public static int getCompilerErrorCount() {
        return compilerErrors;
    }

    /**
     * Gets current compiler warning count.
     *
     * @return warning count
     */
    public static int getCompilerWarningCount() {
        return compilerWarnings;
    }

    /**
     * Clears compiler error counts.
     */
    public static void clearCompilerErrors() {
        compilerErrors = 0;
        compilerWarnings = 0;
    }

    private static void applyErrorButtonStyle(UI_Main ide, int errorCount) {
        if (ide == null || ide.footerErrorButton == null) {
            return;
        }

        ide.footerErrorButton.setStyle(
                "-fx-text-fill: #d32f2f; -fx-font-size: 12; -fx-font-weight: bold; -fx-background-color: transparent; -fx-padding: 0 4 0 4;");
    }

    private static void applyWarningButtonStyle(UI_Main ide, int warningCount) {
        if (ide == null || ide.footerWarningButton == null) {
            return;
        }

        ide.footerWarningButton.setStyle(
                "-fx-text-fill: #f9a825; -fx-font-size: 12; -fx-font-weight: bold; -fx-background-color: transparent; -fx-padding: 0 4 0 4;");
    }
}