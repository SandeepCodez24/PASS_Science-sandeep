package ui.managers;

import ui.UI_Main;
import ui.cli.CLI_Main;

/**
 * Prints IDE messages in the Command Window.
 *
 * <p>
 * Both methods used to call {@code ide.console.appendText} directly. That
 * wrote around the console's freeze: the text landed after the prompt,
 * inside the editable input, so the next ENTER sent the message to the
 * interpreter as a command. They now go through
 * {@link CLI_Main#printNotice(String)}, which puts the message on a line of
 * its own above the prompt (or among the output while a command runs).
 * </p>
 */
public final class TerminalManager {

    private TerminalManager() {
    }

    /**
     * @param ide     the IDE controller (kept so existing callers compile)
     * @param message the message, without a trailing newline
     */
    public static void print(UI_Main ide, String message) {
        CLI_Main.printNotice(message == null ? "" : message);
    }

    /**
     * @param ide     the IDE controller (kept so existing callers compile)
     * @param message the message, without a trailing newline
     */
    public static void println(UI_Main ide, String message) {
        CLI_Main.printNotice(message == null ? "" : message);
    }
}
