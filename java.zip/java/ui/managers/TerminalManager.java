package ui.managers;

import javafx.application.Platform;
import ui.UI_Main;

public final class TerminalManager {

    private TerminalManager() {
    }

    public static void print(UI_Main ide, String message) {

        Platform.runLater(() -> ide.console.appendText(message + "\n"));
    }

    public static void println(UI_Main ide, String message) {

        Platform.runLater(() -> ide.console.appendText(message + "\n"));
    }
}