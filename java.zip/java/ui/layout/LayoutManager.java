package ui.layout;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import javafx.application.Platform;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Orientation;
import javafx.scene.Node;
import javafx.scene.control.SplitPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import ui.UI_Main;
import ui.cli.EditorCommandWindow;
import ui.codebot.CodeBotHost;
import ui.codebot.CodeBotPanel;
import ui.design.Dim;
import ui.design.section_dims.CodeBot_dim;
import ui.editor.settingsTab.UI_Settings_CustomLayout_Main;
import ui.explorer.CollapsiblePanel;
import ui.explorer.PanelActivation;

/**
 * Arranges the main window's five regions -- File Explorer, editor, Command
 * Window, Variable Explorer and Code Bot -- into the layout chosen on the
 * Settings &gt; Layout band.
 *
 * <h3>How a switch works</h3>
 * <p>
 * The five region nodes are built once, by {@code Main_Window}, and never
 * rebuilt: the editor keeps its tabs, the console its history, the bot its
 * conversation. A switch tears down the splits of the old layout (emptying
 * them, so every region is free to join a new parent), builds fresh splits
 * for the new one, and puts the top split into a {@link StackPane} host that
 * sits in the window's centre. Divider positions always come from
 * {@code Dim.Layout} (or {@code Dim.Split} for the Default layout), so
 * choosing a layout resets any dragging done before.
 * </p>
 *
 * <pre>
 *   DEFAULT             H[ Explorer(tree / bot) | V[Editor / CLI] | Variables ]
 *   BOT_CENTERED        H[ V[Editor / Variables] | Bot ]
 *   EDITOR_CLI          V[ Editor / CLI ]          bot open: V[ Editor / H[CLI | Bot] ]
 *   DIRECTORY_CENTERED  H[ Explorer(tree / bot) | V[Editor / CLI] ]
 *   EDITOR_BOT_CLI      H[ Editor | CLI ]          bot open: H[ Editor | Bot | CLI ]
 * </pre>
 *
 * <h3>The Code Bot</h3>
 * <p>
 * Every layout registers two small actions: where the bot goes when it opens
 * and how the space is handed back when it closes. {@code CodeBotHost}
 * calls {@link #dockBot(boolean)}, so the Home ribbon's Code Bot button and
 * the bot's own close button behave correctly in every layout. Bot Centered
 * and Editor-Bot-CLI open the bot when chosen; the others keep it open if it
 * already was.
 * </p>
 *
 * <h3>Panels that change behaviour with the layout</h3>
 * <ul>
 * <li>The Variable Explorer cannot collapse to its rail in Bot Centered,
 * where it sits under the editor rather than beside it.</li>
 * <li>The Command Window can minimise only where it sits directly under the
 * editor (Default, Directory Centered, Editor-CLI with the bot closed).</li>
 * </ul>
 *
 * <h3>Bot Centered and errors</h3>
 * <p>
 * Bot Centered has no Command Window. When a run prints an error to the
 * console, the Variable Explorer's place is given to the Command Window so
 * the error is seen. It stays there until a layout is chosen again (clicking
 * the Bot Centered tile brings the Variable Explorer back). A console line
 * counts as an error when it contains the word "error", "errors" or
 * "error(s)" -- not "0 errors", and not a name such as {@code error_test.nc}.
 * </p>
 *
 * <h3>Persistence</h3>
 * <p>
 * The chosen layout is saved in the IDE's {@code Preferences} and restored at
 * the next launch.
 * </p>
 */
public final class LayoutManager {

    private static final String KEY_LAYOUT = "layout.window";

    /** "error", "errors", "Error:", "error(s)" -- not "0 errors", not error_x. */
    private static final Pattern ERROR_MARK =
            Pattern.compile("(?i)(?<!\\b0 )\\berror(?:s\\b|\\(s\\)|\\b)");

    private static final StackPane HOST = new StackPane();
    private static final ObjectProperty<WindowLayout> CURRENT = new SimpleObjectProperty<>(null);

    /** Every split built for the current layout, so teardown can empty them. */
    private static final List<SplitPane> BUILT = new ArrayList<>();

    private static UI_Main ide;
    private static CollapsiblePanel explorer;
    private static CollapsiblePanel variables;
    private static Node editor;
    private static VBox cli;

    private static Runnable dockShow;
    private static Runnable dockHide;

    /** Bot Centered only: the Editor / Variables column, for the error swap. */
    private static SplitPane workColumn;
    private static boolean cliRevealed;

    private LayoutManager() {
    }

    // =====================================================================
    // Installation
    // =====================================================================

    /**
     * Takes charge of the five regions and applies the saved layout.
     *
     * @param ideRef        the IDE controller (its editor tabs and console
     *                      must already exist)
     * @param explorerPanel the File Explorer panel
     * @param variablePanel the Variable Explorer panel
     * @param commandWindow the Command Window panel
     * @return the node to place in the window's centre
     */
    public static Region install(UI_Main ideRef, CollapsiblePanel explorerPanel,
            CollapsiblePanel variablePanel, VBox commandWindow) {
        ide = ideRef;
        explorer = explorerPanel;
        variables = variablePanel;
        editor = ideRef.editorTabs;
        cli = commandWindow;

        HOST.getStyleClass().add("layout-host");
        if (ide.console != null) {
            ide.console.textProperty().addListener(LayoutManager::onConsoleText);
        }

        WindowLayout saved = WindowLayout.fromName(
                ide.prefs == null ? null : ide.prefs.get(KEY_LAYOUT, WindowLayout.DEFAULT.name()));
        apply(saved);
        return HOST;
    }

    /** @return true once {@link #install} has run */
    public static boolean isInstalled() {
        return ide != null;
    }

    /** @return the layout on screen, observable, for the band's tiles */
    public static ReadOnlyObjectProperty<WindowLayout> currentProperty() {
        return CURRENT;
    }

    /** @return the layout on screen */
    public static WindowLayout current() {
        return CURRENT.get();
    }

    // =====================================================================
    // Switching
    // =====================================================================

    /**
     * Rearranges the window. {@link WindowLayout#CUSTOM} opens the Custom
     * Layout window instead and leaves the arrangement alone. Choosing the
     * layout already on screen re-applies it, which resets its dividers.
     *
     * @param layout the layout to show
     */
    public static void apply(WindowLayout layout) {
        if (!isInstalled() || layout == null) {
            return;
        }
        if (!layout.isArrangement()) {
            UI_Settings_CustomLayout_Main.open(ide);
            return;
        }

        boolean botWasOpen = CodeBotHost.isShowing();
        teardown();

        switch (layout) {
            case BOT_CENTERED -> buildBotCentered();
            case EDITOR_CLI -> buildEditorCli();
            case DIRECTORY_CENTERED -> buildDirectoryCentered();
            case EDITOR_BOT_CLI -> buildEditorBotCli();
            default -> buildDefault();
        }

        CURRENT.set(layout);
        if (ide.prefs != null) {
            ide.prefs.put(KEY_LAYOUT, layout.name());
        }

        if (layout.opensBot() || botWasOpen) {
            CodeBotHost.show();
        } else {
            keepActiveRegionOnScreen();
        }
    }

    /**
     * Docks or undocks the Code Bot in the current layout. Called by
     * {@code CodeBotHost}.
     *
     * @param open true to dock it, false to hand its space back
     * @return false if no layout is installed, so the caller should fall back
     *         to the explorer
     */
    public static boolean dockBot(boolean open) {
        Runnable action = open ? dockShow : dockHide;
        if (!isInstalled() || action == null) {
            return false;
        }
        action.run();
        return true;
    }

    // =====================================================================
    // Teardown
    // =====================================================================

    /**
     * Empties the old layout so every region can join a new parent. A node in
     * a SplitPane's item list sits inside the split's own wrapper, so emptying
     * the list is the only reliable way to release it.
     */
    private static void teardown() {
        EditorCommandWindow.setMinimizeAllowed(true);
        EditorCommandWindow.setMinimized(false);
        EditorCommandWindow.attachTo(null);

        explorer.setCollapseEnabled(true);
        explorer.setCollapsed(false);
        explorer.attachTo(null);
        variables.setCollapseEnabled(true);
        variables.setCollapsed(false);
        variables.attachTo(null);

        CodeBotHost.markClosed();
        CodeBotHost.removeFromExplorer();

        for (SplitPane split : BUILT) {
            split.getItems().clear();
        }
        BUILT.clear();
        HOST.getChildren().clear();

        dockShow = null;
        dockHide = null;
        workColumn = null;
        cliRevealed = false;
    }

    // =====================================================================
    // The five arrangements
    // =====================================================================

    /** H[ Explorer | V[Editor / CLI] | Variables ]; bot under the tree. */
    private static void buildDefault() {
        SplitPane center = split(Orientation.VERTICAL, editor, cli);
        SplitPane.setResizableWithParent(cli, Boolean.FALSE);
        dividers(center, Dim.Split.EDITOR_OVER_CONSOLE);
        EditorCommandWindow.attachTo(center);

        SplitPane main = split(Orientation.HORIZONTAL, explorer, center, variables);
        double variableShare = (1.0 - Dim.Split.MAIN_RIGHT) * Dim.Window.VARIABLE_EXPLORER_LAUNCH_SCALE;
        dividers(main, Dim.Split.MAIN_LEFT, 1.0 - variableShare);
        explorer.attachTo(main);
        variables.attachTo(main);
        CodeBotHost.attach(explorer, main);

        dockShow = () -> CodeBotHost.placeInExplorer(CodeBot_dim.OPEN_DIVIDER_POSITION);
        dockHide = CodeBotHost::removeFromExplorer;

        HOST.getChildren().setAll(main);
    }

    /** H[ V[Editor / Variables] | Bot ]; no Command Window until an error. */
    private static void buildBotCentered() {
        SplitPane left = split(Orientation.VERTICAL, editor, variables);
        SplitPane.setResizableWithParent(variables, Boolean.TRUE);
        dividers(left, Dim.Layout.BOT_CENTERED_EDITOR_OVER_VARIABLES);
        variables.setCollapseEnabled(false);
        workColumn = left;

        EditorCommandWindow.setMinimizeAllowed(false);

        SplitPane main = split(Orientation.HORIZONTAL, left);

        dockShow = () -> {
            CodeBotPanel bot = CodeBotHost.prepareForColumn();
            if (!main.getItems().contains(bot)) {
                main.getItems().add(bot);
            }
            dividers(main, Dim.Layout.BOT_CENTERED_WORK_SHARE);
        };
        dockHide = () -> main.getItems().remove(CodeBotHost.panel());

        HOST.getChildren().setAll(main);
    }

    /** V[ Editor / CLI ], 50 / 50; the bot shares the bottom row with the CLI. */
    private static void buildEditorCli() {
        SplitPane main = split(Orientation.VERTICAL, editor, cli);
        SplitPane.setResizableWithParent(cli, Boolean.TRUE);
        dividers(main, Dim.Layout.EDITOR_CLI_EDITOR_OVER_CONSOLE);
        EditorCommandWindow.attachTo(main);

        SplitPane[] bottom = new SplitPane[1];

        dockShow = () -> {
            if (bottom[0] != null && main.getItems().contains(bottom[0])) {
                return;
            }
            // Beside the bot the CLI no longer sits directly under the
            // editor, so it cannot minimise there.
            EditorCommandWindow.setMinimizeAllowed(false);
            EditorCommandWindow.attachTo(null);
            double[] keep = main.getDividerPositions();

            SplitPane row = split(Orientation.HORIZONTAL);
            int at = main.getItems().indexOf(cli);
            main.getItems().set(at < 0 ? 1 : at, row);
            row.getItems().addAll(cli, CodeBotHost.prepareForColumn());
            dividers(row, Dim.Layout.EDITOR_CLI_CONSOLE_BESIDE_BOT);
            dividers(main, keep);
            bottom[0] = row;
        };
        dockHide = () -> {
            SplitPane row = bottom[0];
            if (row == null) {
                return;
            }
            double[] keep = main.getDividerPositions();
            row.getItems().clear();
            int at = main.getItems().indexOf(row);
            main.getItems().set(at < 0 ? 1 : at, cli);
            dividers(main, keep);
            EditorCommandWindow.attachTo(main);
            EditorCommandWindow.setMinimizeAllowed(true);
            bottom[0] = null;
        };

        HOST.getChildren().setAll(main);
    }

    /** H[ Explorer | V[Editor / CLI] ]; bot under the tree at 50 / 50. */
    private static void buildDirectoryCentered() {
        SplitPane center = split(Orientation.VERTICAL, editor, cli);
        SplitPane.setResizableWithParent(cli, Boolean.FALSE);
        dividers(center, Dim.Split.EDITOR_OVER_CONSOLE);
        EditorCommandWindow.attachTo(center);

        SplitPane main = split(Orientation.HORIZONTAL, explorer, center);
        dividers(main, Dim.Layout.DIRECTORY_SHARE);
        explorer.attachTo(main);
        CodeBotHost.attach(explorer, main);

        dockShow = () -> CodeBotHost.placeInExplorer(Dim.Layout.DIRECTORY_TREE_OVER_BOT);
        dockHide = CodeBotHost::removeFromExplorer;

        HOST.getChildren().setAll(main);
    }

    /** H[ Editor | Bot | CLI ], three equal columns. */
    private static void buildEditorBotCli() {
        SplitPane main = split(Orientation.HORIZONTAL, editor, cli);
        SplitPane.setResizableWithParent(cli, Boolean.TRUE);
        dividers(main, Dim.Layout.TWO_COLUMN_SPLIT);
        EditorCommandWindow.setMinimizeAllowed(false);

        dockShow = () -> {
            CodeBotPanel bot = CodeBotHost.prepareForColumn();
            if (!main.getItems().contains(bot)) {
                main.getItems().add(1, bot);
            }
            dividers(main, Dim.Layout.THREE_COLUMN_FIRST, Dim.Layout.THREE_COLUMN_SECOND);
        };
        dockHide = () -> {
            main.getItems().remove(CodeBotHost.panel());
            dividers(main, Dim.Layout.TWO_COLUMN_SPLIT);
        };

        HOST.getChildren().setAll(main);
    }

    // =====================================================================
    // Bot Centered: show the Command Window when a run reports an error
    // =====================================================================

    private static void onConsoleText(ObservableValue<? extends String> obs, String was, String now) {
        if (CURRENT.get() != WindowLayout.BOT_CENTERED || cliRevealed || workColumn == null) {
            return;
        }
        if (now == null || was == null || now.length() <= was.length()) {
            return;
        }
        // Console output only ever grows at the end, so the new part is the
        // tail; nothing before it needs to be scanned again.
        String appended = now.substring(was.length());
        if (ERROR_MARK.matcher(appended).find()) {
            // Outside the text-change notification, which is still running.
            Platform.runLater(LayoutManager::revealCommandWindow);
        }
    }

    private static void revealCommandWindow() {
        if (cliRevealed || workColumn == null) {
            return;
        }
        int at = workColumn.getItems().indexOf(variables);
        if (at < 0) {
            return;
        }
        cliRevealed = true;
        double[] keep = workColumn.getDividerPositions();
        SplitPane.setResizableWithParent(cli, Boolean.TRUE);
        workColumn.getItems().set(at, cli);
        dividers(workColumn, keep);
        PanelActivation.setActive(PanelActivation.Panel.COMMAND_WINDOW);
        if (ide.console != null) {
            ide.console.positionCaret(ide.console.getLength());
        }
    }

    // =====================================================================
    // Helpers
    // =====================================================================

    private static SplitPane split(Orientation orientation, Node... items) {
        SplitPane split = new SplitPane(items);
        split.setOrientation(orientation);
        BUILT.add(split);
        return split;
    }

    /**
     * Sets divider positions now and again on the next pulse: a split that is
     * already on screen honours new positions only once it has laid out with
     * its new items.
     */
    private static void dividers(SplitPane split, double... positions) {
        if (positions == null || positions.length == 0) {
            return;
        }
        split.setDividerPositions(positions);
        Platform.runLater(() -> split.setDividerPositions(positions));
    }

    /**
     * After a switch, a region that is no longer on screen must not keep the
     * navy highlight. Falls back to the editor.
     */
    private static void keepActiveRegionOnScreen() {
        PanelActivation.Panel active = PanelActivation.getActive();
        Node node = null;
        if (active != null) {
            node = switch (active) {
                case FILE_EXPLORER -> explorer;
                case VARIABLE_EXPLORER -> variables;
                case COMMAND_WINDOW -> cli;
                case CODE_BOT -> CodeBotHost.isShowing() ? CodeBotHost.panel() : null;
                case EDITOR -> editor;
            };
        }
        if (node == null || !isInLayout(node)) {
            PanelActivation.setActive(PanelActivation.Panel.EDITOR);
        }
    }

    private static boolean isInLayout(Node node) {
        for (Node n = node; n != null; n = n.getParent()) {
            if (n == HOST) {
                return true;
            }
        }
        return false;
    }
}
