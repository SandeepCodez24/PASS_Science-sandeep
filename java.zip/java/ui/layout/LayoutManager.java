package ui.layout;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;

import javafx.application.Platform;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.geometry.Orientation;
import javafx.scene.Node;
import javafx.scene.control.SplitPane;
import javafx.scene.control.Tab;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import ui.UI_Main;
import ui.cli.CLI_Main;
import ui.cli.EditorCommandWindow;
import ui.cli.StandaloneCliWindow;
import ui.codebot.CodeBotHost;
import ui.codebot.CodeBotPanel;
import ui.design.Dim;
import ui.design.section_dims.CodeBot_dim;
import ui.editor.settingsTab.UI_Settings_CustomLayout_Main;
import ui.explorer.CollapsiblePanel;
import ui.explorer.PanelActivation;
import ui.explorer.signal.SignalExplorerHost;
import ui.layout.custom.CustomLayoutConfig;
import ui.layout.custom.CustomLayoutTheme;
import ui.ui_functions.Variable;

/**
 * Arranges the main window's regions -- File Explorer, editor, Command
 * Window, Variable Explorer and Code Bot -- into the layout chosen on the
 * Settings &gt; Layout band.
 *
 * <h3>How a switch works</h3>
 * <p>
 * The region nodes are built once, by {@code Main_Window}, and never
 * rebuilt. A switch tears down the splits of the old layout (emptying them,
 * so every region is free to join a new parent), builds fresh splits for the
 * new one, and puts the top split into a {@link StackPane} host. Divider
 * positions always come from {@code Dim}, so choosing a layout resets any
 * dragging done before.
 * </p>
 *
 * <pre>
 *   DEFAULT             H[ Explorer(tree / bot) | V[Editor / CLI] | Variables ]      2 : 8 : 2
 *   BOT_CENTERED        H[ V[Editor / Variables] | Bot ]
 *   EDITOR_CLI          V[ Editor / CLI ]          bot open: V[ Editor / H[CLI | Bot] ]
 *   DIRECTORY_CENTERED  H[ Explorer(tree / bot) | V[Editor / CLI] ]
 *   EDITOR_BOT_CLI      H[ Editor | CLI ]          bot open: H[ Editor | Bot | CLI ]
 *   CUSTOM              the ticked panels only (see below)
 * </pre>
 *
 * <h3>Default is the only layout that minimises and closes</h3>
 * <p>
 * In every other layout ({@link WindowLayout#isStatic()}) the dividers still
 * drag, but nothing minimises or closes: the File Explorer and Variable
 * Explorer triangles, the Command Window's Minimize, the Code Bot's and the
 * Signal Explorer's close marks and the Variable Explorer's Close are shown
 * faded ({@link #applyPanelControls}). The Code Bot stays open in the
 * layouts built around it (Bot Centered, Editor-Bot-CLI, Custom with Chat
 * Bot ticked): the ribbon's Code Bot button does not close it there.
 * </p>
 *
 * <h3>The Custom layout</h3>
 * <p>
 * Only the panels ticked in the Custom Layout window are in the window; the
 * others are left out, not minimised. Reading order is Default's: File
 * Explorer, Code Bot, editor, Command Window, Variable Explorer.
 * </p>
 * <ul>
 * <li><b>1 panel</b> fills the window.</li>
 * <li><b>2 panels</b> sit side by side, 50 / 50, in reading order (or the
 * other way round when Swap is on).</li>
 * <li><b>3 to 5 panels</b> keep Default's columns -- [Explorer / Bot] |
 * [Editor / CLI] | [Variables] -- with the empty places removed and the
 * remaining columns keeping 2 : 8 : 2 between them. With 3 or 4 panels Swap
 * mirrors the columns.</li>
 * </ul>
 * <p>
 * A ticked Variable Explorer that is in its own window (Separate Window) is
 * not counted: the others share the space.
 * </p>
 * <p>
 * What a missing panel would have shown is still collected. When it is
 * asked for, the Command Window says so if it is on screen: a file opened
 * without the editor (it opens in the background), the Code Bot button
 * without Chat Bot, the Signal Explorer or a run's variables without the
 * Variable Explorer.
 * </p>
 *
 * <h3>The Signal Explorer</h3>
 * <p>
 * Part of the Variable Explorer, in every layout that shows it. A layout
 * switch keeps it open or closed: teardown takes it out of the body and
 * {@link SignalExplorerHost#redock()} puts it back.
 * </p>
 *
 * <h3>Colours</h3>
 * <p>
 * {@link CustomLayoutTheme#setLayout} paints the layout on screen with its
 * own palette from the Custom Layout window when that layout uses one.
 * </p>
 *
 * <h3>Bot Centered and errors</h3>
 * <p>
 * Bot Centered has no Command Window. When a run prints an error, the
 * Variable Explorer's place is given to the Command Window so the error is
 * seen, until a layout is chosen again.
 * </p>
 *
 * <h3>Standalone CLI</h3>
 * <p>
 * The Command Window's three-dot menu can put it in a window of its own
 * ({@link #setCliStandalone}, {@link StandaloneCliWindow}). No layout then
 * places it, and its place goes to the panel that was above or beside it:
 * </p>
 * <pre>
 *   DEFAULT             H[ Explorer | Editor | Variables ]           2 : 8 : 2
 *   BOT_CENTERED        unchanged (no CLI); an error restores the window if minimised
 *   EDITOR_CLI          V[ Editor ]                bot open: V[ Editor / Bot ]
 *   DIRECTORY_CENTERED  H[ Explorer | Editor ]
 *   EDITOR_BOT_CLI      H[ Editor ]                bot open: H[ Editor | Bot ] 50 / 50
 *   CUSTOM              the CLI is not counted; with no editor ticked, its
 *                       place (the centre column) goes to the first of
 *                       Variable Explorer, Code Bot, File Explorer that is shown
 * </pre>
 * <p>
 * The choice is remembered across restarts. It is not used -- the Command
 * Window stays in the layout and the menu entry is greyed -- in a Custom
 * layout where the CLI would be the only panel left in the main window, and
 * the Command Window has no place at all in a Custom layout without the CLI.
 * The choice comes back into force as soon as the layout allows it. Minimize
 * is greyed while standalone.
 * </p>
 *
 * <h3>When the Variable Explorer is not in the window</h3>
 * <ul>
 * <li><b>Separate Window</b> ({@link #setVariablesDetached}): no layout
 * places it; the other panels share the space.</li>
 * <li><b>Closed</b> ({@link #setVariablesClosed}): the same, until the next
 * command or script starts or a layout is chosen. Only Default offers
 * Close.</li>
 * <li><b>Full Screen</b> ({@link #setVariablesFullScreen}): every other
 * region makes way.</li>
 * </ul>
 */
public final class LayoutManager {

    private static final String KEY_LAYOUT = "layout.window";

    /** Preference: the user's Standalone CLI choice. */
    private static final String KEY_CLI_STANDALONE = "layout.cliStandalone";

    /** "error", "errors", "Error:", "error(s)" -- not "0 errors", not error_x. */
    private static final Pattern ERROR_MARK =
            Pattern.compile("(?i)(?<!\\b0 )\\berror(?:s\\b|\\(s\\)|\\b)");

    private static final StackPane HOST = new StackPane();
    private static final ObjectProperty<WindowLayout> CURRENT = new SimpleObjectProperty<>(null);

    /** Every split built for the current layout, so teardown can empty them. */
    private static final List<SplitPane> BUILT = new ArrayList<>();

    private static UI_Main ide;
    private static CollapsiblePanel explorer;
    private static CollapsiblePanel variables;
    private static Node editor;
    private static VBox cli;

    private static Runnable dockShow;
    private static Runnable dockHide;

    /** Bot Centered only: the Editor / Variables column, for the error swap. */
    private static SplitPane workColumn;
    private static boolean cliRevealed;

    /** Something has run since the layout was built (variables are the user's). */
    private static boolean runSinceBuild;

    /** Custom only: the "Variable Explorer not in this layout" note was printed. */
    private static boolean variablesNoticed;

    private static ObservableList<Variable> watchedVariables;

    /** Separate Window view: the Variable Explorer has a window of its own. */
    private static boolean variablesDetached;

    /** The Variable Explorer was closed from its menu. */
    private static boolean variablesClosed;

    /** The Variable Explorer fills the window (its Full Screen). */
    private static boolean variablesFullScreen;

    /** Shown beside the Variable Explorer in Full Screen (its variable tabs). */
    private static Node fullScreenCompanion;

    /** Run once Full Screen has ended and the layout is back. */
    private static Runnable fullScreenExit;

    /** The Code Bot was open when Full Screen began. */
    private static boolean botBeforeFullScreen;

    /** The user's choice: the Command Window in a window of its own. */
    private static boolean cliStandalone;

    /**
     * In force for the layout on screen: {@link #cliStandalone} where the
     * layout allows it. No builder places the Command Window while true.
     */
    private static boolean cliDetached;

    /** The next standalone show was asked for by the user: take the keyboard. */
    private static boolean cliFocusOnShow;

    private static final ListChangeListener<Variable> VARIABLES_CHANGED = change -> {
        boolean added = false;
        while (change.next()) {
            if (change.wasAdded()) {
                added = true;
            }
        }
        if (added) {
            Platform.runLater(LayoutManager::onVariablesAdded);
        }
    };

    private LayoutManager() {
    }

    // =====================================================================
    // Installation
    // =====================================================================

    /**
     * Takes charge of the regions and applies the saved layout.
     *
     * @param ideRef        the IDE controller (its editor tabs and console
     *                      must already exist)
     * @param explorerPanel the File Explorer panel
     * @param editorArea    the editor area (the editor tabs and the variable
     *                      tabs); null to place {@code ide.editorTabs}
     * @param variablePanel the Variable Explorer panel
     * @param commandWindow the Command Window panel
     * @return the node to place in the window's centre
     */
    public static Region install(UI_Main ideRef, CollapsiblePanel explorerPanel, Node editorArea,
            CollapsiblePanel variablePanel, VBox commandWindow) {
        ide = ideRef;
        explorer = explorerPanel;
        variables = variablePanel;
        editor = editorArea != null ? editorArea : ideRef.editorTabs;
        cli = commandWindow;

        HOST.getStyleClass().add("layout-host");
        if (ide.console != null) {
            ide.console.textProperty().addListener((_, was, now) -> onConsoleText(was, now));
        }

        // Opening the Signal Explorer must make it visible: expand the
        // Variable Explorer if it is a rail, or say why it cannot be seen.
        SignalExplorerHost.setRevealColumn(() -> {
            if (variablesClosed) {
                setVariablesClosed(false);
            }
            if (variablesDetached) {
                return;
            }
            if (!isInLayout(variables)) {
                notice("The Signal Explorer is part of the Variable Explorer, which is not part of this layout.");
                return;
            }
            if (variables.isCollapsed()) {
                variables.setCollapsed(false);
            }
        });

        CustomLayoutConfig.init(ide);
        CustomLayoutTheme.attach(ide, HOST);
        installHooks();

        // Restored like the layout: a CLI left standalone comes back
        // standalone (its window appears once the IDE window is up).
        cliStandalone = ide.prefs != null && ide.prefs.getBoolean(KEY_CLI_STANDALONE, false);

        WindowLayout saved = WindowLayout.fromName(
                ide.prefs == null ? null : ide.prefs.get(KEY_LAYOUT, WindowLayout.DEFAULT.name()));
        rebuild(saved);
        return HOST;
    }

    /** @return true once {@link #install} has run */
    public static boolean isInstalled() {
        return ide != null;
    }

    /** @return the layout on screen, observable, for the band's tiles */
    public static ReadOnlyObjectProperty<WindowLayout> currentProperty() {
        return CURRENT;
    }

    /** @return the layout on screen */
    public static WindowLayout current() {
        return CURRENT.get();
    }

    /**
     * @return true while a static layout is on screen (every layout but
     *         Default): nothing may minimise or close
     */
    public static boolean isStaticLayout() {
        WindowLayout layout = CURRENT.get();
        return layout != null && layout.isStatic();
    }

    // =====================================================================
    // Switching
    // =====================================================================

    /**
     * Rearranges the window -- the Layout band's tiles. Choosing
     * {@link WindowLayout#CUSTOM} also opens the Custom Layout window.
     *
     * @param layout the layout to show
     */
    public static void apply(WindowLayout layout) {
        applyFresh(layout, true);
    }

    /**
     * The Custom tile on the Layout band.
     *
     * <p>
     * The tile means "my own layout": whatever the Custom Layout window last
     * applied -- Custom itself, or a standard layout in its own colours (Bot
     * Centered in olive, say).
     * </p>
     * <ul>
     * <li>If that look is already on screen, nothing is rebuilt: the window
     * just opens over it, dividers untouched.</li>
     * <li>Otherwise the last applied layout is put back
     * ({@link CustomLayoutConfig#lastApplied()}) with its saved colours, then
     * the window opens.</li>
     * </ul>
     * <p>
     * Only applying something else (Reset to factory + Apply included)
     * changes what the tile brings back.
     * </p>
     */
    public static void openCustom() {
        if (!isInstalled()) {
            return;
        }
        WindowLayout current = CURRENT.get();
        boolean customLookOnScreen = current != null && !variablesFullScreen
                && !CustomLayoutConfig.isPlainStandard()
                && (current.isCustom() || CustomLayoutConfig.saved().usesColours(current));
        if (!customLookOnScreen) {
            CustomLayoutConfig.setPlainStandard(false);
            applyFresh(CustomLayoutConfig.lastApplied(), false);
        }
        Platform.runLater(() -> UI_Settings_CustomLayout_Main.open(ide));
    }

    /** {@link #apply}, with the choice of opening the Custom Layout window. */
    private static void applyFresh(WindowLayout layout, boolean openCustomWindow) {
        variablesClosed = false;
        boolean wasFullScreen = variablesFullScreen;
        variablesFullScreen = false;
        arrange(layout, openCustomWindow);
        if (wasFullScreen) {
            runFullScreenExit();
        }
    }

    /**
     * Rearranges the window without opening any window. Used at launch and
     * by the Custom Layout window's Preview, Apply and Cancel.
     *
     * @param layout the layout to show
     */
    public static void rebuild(WindowLayout layout) {
        arrange(layout, false);
    }

    private static void arrange(WindowLayout layout, boolean openCustomWindow) {
        if (!isInstalled() || layout == null) {
            return;
        }

        boolean botWasOpen = CodeBotHost.isShowing();
        teardown();

        // Standalone CLI for this build. When it is not in force, the panel
        // comes home from its window before any split wants it.
        cliDetached = cliStandalone && allowsCliStandalone(layout);
        if (!cliDetached) {
            StandaloneCliWindow.release();
            EditorCommandWindow.setStandalone(false);
        }

        if (variablesFullScreen) {
            // The Code Bot is not part of Full Screen; it comes back after.
            botBeforeFullScreen = botBeforeFullScreen || botWasOpen;
            buildVariablesFullScreen();
            SignalExplorerHost.redock();
            CURRENT.set(layout);
            applyPanelControls(layout);
            CustomLayoutTheme.setLayout(layout);
            syncStandaloneCli();
            PanelActivation.setActive(PanelActivation.Panel.VARIABLE_EXPLORER);
            return;
        }
        botWasOpen = botWasOpen || botBeforeFullScreen;
        botBeforeFullScreen = false;

        switch (layout) {
            case BOT_CENTERED -> buildBotCentered();
            case EDITOR_CLI -> buildEditorCli();
            case DIRECTORY_CENTERED -> buildDirectoryCentered();
            case EDITOR_BOT_CLI -> buildEditorBotCli();
            case CUSTOM -> buildCustom();
            default -> buildDefault();
        }

        SignalExplorerHost.redock();

        CURRENT.set(layout);
        if (ide.prefs != null) {
            ide.prefs.put(KEY_LAYOUT, layout.name());
        }
        applyPanelControls(layout);
        CustomLayoutTheme.setLayout(layout);
        syncStandaloneCli();

        boolean openBot = layout.isCustom()
                ? CustomLayoutConfig.effective().isShown(CustomLayoutConfig.Panel.CHAT_BOT)
                : layout.opensBot() || botWasOpen;
        if (openBot) {
            CodeBotHost.show();
        } else {
            keepActiveRegionOnScreen();
        }

        if (layout.isCustom() && openCustomWindow) {
            Platform.runLater(() -> UI_Settings_CustomLayout_Main.open(ide));
        }
    }

    /**
     * Default: every minimise and close works. Every other layout: they are
     * shown faded. Called after each build.
     */
    private static void applyPanelControls(WindowLayout layout) {
        boolean free = !layout.isStatic();
        explorer.setCollapseEnabled(free);
        if (!variablesDetached) {
            variables.setCollapseEnabled(free && !variablesFullScreen);
        }
        EditorCommandWindow.setMinimizeAllowed(free && !cliDetached);
        CodeBotHost.setCloseEnabled(free);
        SignalExplorerHost.setControlsEnabled(free);
    }

    /**
     * Docks or undocks the Code Bot in the current layout. Called by
     * {@code CodeBotHost}.
     *
     * @param open true to dock it, false to hand its space back
     * @return false if no layout is installed, so the caller should fall back
     *         to the explorer
     */
    public static boolean dockBot(boolean open) {
        Runnable action = open ? dockShow : dockHide;
        if (!isInstalled() || action == null) {
            return false;
        }
        action.run();
        return true;
    }

    /**
     * @return false only in a Custom layout without Chat Bot, where the
     *         Code Bot has no place
     */
    public static boolean canShowBot() {
        if (!isInstalled() || variablesFullScreen) {
            return true;
        }
        return !isCustom() || CustomLayoutConfig.effective().isShown(CustomLayoutConfig.Panel.CHAT_BOT);
    }

    /**
     * @return true in the layouts built around the Code Bot, where it cannot
     *         be closed: Bot Centered, Editor-Bot-CLI, Custom with Chat Bot
     */
    public static boolean isBotPinned() {
        WindowLayout layout = CURRENT.get();
        if (!isInstalled() || variablesFullScreen || layout == null) {
            return false;
        }
        return switch (layout) {
            case BOT_CENTERED, EDITOR_BOT_CLI -> true;
            case CUSTOM -> CustomLayoutConfig.effective().isShown(CustomLayoutConfig.Panel.CHAT_BOT);
            default -> false;
        };
    }

    /**
     * Prints a short note in the Command Window, if the Command Window is on
     * screen; otherwise does nothing.
     *
     * @param message the note
     */
    public static void notice(String message) {
        if (message == null || cli == null || !isCliOnScreen()) {
            return;
        }
        Platform.runLater(() -> CLI_Main.printNotice(message));
    }

    // =====================================================================
    // Teardown
    // =====================================================================

    /**
     * Empties the old layout so every region can join a new parent.
     */
    private static void teardown() {
        EditorCommandWindow.setMinimizeAllowed(true);
        EditorCommandWindow.setMinimized(false);
        EditorCommandWindow.attachTo(null);
        SplitPane.setResizableWithParent(cli, Boolean.TRUE);

        explorer.setCollapseEnabled(true);
        explorer.setCollapsed(false);
        explorer.attachTo(null);
        if (!variablesDetached) {
            variables.setCollapseEnabled(true);
            variables.setCollapsed(false);
            variables.attachTo(null);
            SplitPane.setResizableWithParent(variables, Boolean.TRUE);
        }

        CodeBotHost.markClosed();
        CodeBotHost.removeFromExplorer();
        SignalExplorerHost.removeFromVariables();

        for (SplitPane split : BUILT) {
            split.getItems().clear();
        }
        BUILT.clear();
        HOST.getChildren().clear();

        dockShow = null;
        dockHide = null;
        workColumn = null;
        cliRevealed = false;
        runSinceBuild = false;
        variablesNoticed = false;
    }

    // =====================================================================
    // The arrangements
    // =====================================================================

    /** H[ Explorer | V[Editor / CLI] | Variables ] at 2 : 8 : 2; bot under the tree. */
    private static void buildDefault() {
        Node center = editorColumn();
        SplitPane main = threeColumns(center);
        HOST.getChildren().setAll(main);
    }

    /**
     * The editor column: Editor over Command Window, or the editor alone
     * while the Command Window is standalone (the editor takes its place).
     */
    private static Node editorColumn() {
        return cliDetached ? editor : editorOverConsole();
    }

    /** The vertical Editor / Command Window split. */
    private static SplitPane editorOverConsole() {
        SplitPane center = split(Orientation.VERTICAL, editor, cli);
        SplitPane.setResizableWithParent(cli, Boolean.FALSE);
        dividers(center, Dim.Split.EDITOR_OVER_CONSOLE);
        SplitRatio.hold(center, Dim.Split.EDITOR_OVER_CONSOLE);
        EditorCommandWindow.attachTo(center);
        return center;
    }

    /**
     * H[ Explorer | center | Variables ] at 2 : 8 : 2, held until the user
     * drags; the bot docks under the tree.
     */
    private static SplitPane threeColumns(Node center) {
        SplitPane main;
        if (variablesInLayout()) {
            main = split(Orientation.HORIZONTAL, explorer, center, variables);
            double[] positions = Dim.Split.mainPositions();
            dividers(main, positions);
            SplitRatio.hold(main, positions);
            variables.attachTo(main);
        } else {
            main = split(Orientation.HORIZONTAL, explorer, center);
            dividers(main, Dim.Layout.DIRECTORY_SHARE);
            SplitRatio.hold(main, Dim.Layout.DIRECTORY_SHARE);
        }
        explorer.attachTo(main);
        CodeBotHost.attach(explorer, main);

        dockShow = () -> CodeBotHost.placeInExplorer(CodeBot_dim.OPEN_DIVIDER_POSITION);
        dockHide = CodeBotHost::removeFromExplorer;
        return main;
    }

    /** H[ V[Editor / Variables] | Bot ]; no Command Window until an error. */
    private static void buildBotCentered() {
        SplitPane left;
        if (variablesInLayout()) {
            left = split(Orientation.VERTICAL, editor, variables);
            SplitPane.setResizableWithParent(variables, Boolean.TRUE);
            dividers(left, Dim.Layout.BOT_CENTERED_EDITOR_OVER_VARIABLES);
        } else {
            left = split(Orientation.VERTICAL, editor);
        }
        workColumn = left;

        SplitPane main = split(Orientation.HORIZONTAL, left);

        dockShow = () -> {
            CodeBotPanel bot = CodeBotHost.prepareForColumn();
            if (!main.getItems().contains(bot)) {
                main.getItems().add(bot);
            }
            dividers(main, Dim.Layout.BOT_CENTERED_WORK_SHARE);
        };
        dockHide = () -> main.getItems().remove(CodeBotHost.panel());

        HOST.getChildren().setAll(main);
    }

    /** V[ Editor / CLI ], 50 / 50; the bot shares the bottom row with the CLI. */
    private static void buildEditorCli() {
        if (cliDetached) {
            buildEditorCliStandalone();
            return;
        }
        SplitPane main = split(Orientation.VERTICAL, editor, cli);
        SplitPane.setResizableWithParent(cli, Boolean.TRUE);
        dividers(main, Dim.Layout.EDITOR_CLI_EDITOR_OVER_CONSOLE);

        SplitPane[] bottom = new SplitPane[1];

        dockShow = () -> {
            if (bottom[0] != null && main.getItems().contains(bottom[0])) {
                return;
            }
            double[] keep = main.getDividerPositions();
            SplitPane row = split(Orientation.HORIZONTAL);
            int at = main.getItems().indexOf(cli);
            main.getItems().set(at < 0 ? 1 : at, row);
            row.getItems().addAll(cli, CodeBotHost.prepareForColumn());
            dividers(row, Dim.Layout.EDITOR_CLI_CONSOLE_BESIDE_BOT);
            dividers(main, keep);
            bottom[0] = row;
        };
        dockHide = () -> {
            SplitPane row = bottom[0];
            if (row == null) {
                return;
            }
            double[] keep = main.getDividerPositions();
            row.getItems().clear();
            int at = main.getItems().indexOf(row);
            main.getItems().set(at < 0 ? 1 : at, cli);
            dividers(main, keep);
            bottom[0] = null;
        };

        HOST.getChildren().setAll(main);
    }

    /**
     * Editor-CLI with the Command Window standalone: the editor alone; the
     * bot, when open, takes the bottom row the CLI had, 50 / 50.
     */
    private static void buildEditorCliStandalone() {
        SplitPane main = split(Orientation.VERTICAL, editor);
        dockShow = () -> {
            CodeBotPanel bot = CodeBotHost.prepareForColumn();
            if (!main.getItems().contains(bot)) {
                main.getItems().add(bot);
            }
            dividers(main, Dim.Layout.EDITOR_CLI_EDITOR_OVER_CONSOLE);
        };
        dockHide = () -> main.getItems().remove(CodeBotHost.panel());
        HOST.getChildren().setAll(main);
    }

    /** H[ Explorer | V[Editor / CLI] ]; bot under the tree at 50 / 50. */
    private static void buildDirectoryCentered() {
        Node center = editorColumn();

        SplitPane main = split(Orientation.HORIZONTAL, explorer, center);
        dividers(main, Dim.Layout.DIRECTORY_SHARE);
        explorer.attachTo(main);
        CodeBotHost.attach(explorer, main);

        dockShow = () -> CodeBotHost.placeInExplorer(Dim.Layout.DIRECTORY_TREE_OVER_BOT);
        dockHide = CodeBotHost::removeFromExplorer;

        HOST.getChildren().setAll(main);
    }

    /** H[ Editor | CLI ], three equal columns once the bot opens. */
    private static void buildEditorBotCli() {
        if (cliDetached) {
            // The CLI's column is gone: Editor | Bot, 50 / 50.
            SplitPane main = split(Orientation.HORIZONTAL, editor);
            dockShow = () -> {
                CodeBotPanel bot = CodeBotHost.prepareForColumn();
                if (!main.getItems().contains(bot)) {
                    main.getItems().add(bot);
                }
                dividers(main, Dim.Layout.TWO_COLUMN_SPLIT);
            };
            dockHide = () -> main.getItems().remove(CodeBotHost.panel());
            HOST.getChildren().setAll(main);
            return;
        }
        SplitPane main = split(Orientation.HORIZONTAL, editor, cli);
        SplitPane.setResizableWithParent(cli, Boolean.TRUE);
        dividers(main, Dim.Layout.TWO_COLUMN_SPLIT);

        dockShow = () -> {
            CodeBotPanel bot = CodeBotHost.prepareForColumn();
            if (!main.getItems().contains(bot)) {
                main.getItems().add(1, bot);
            }
            dividers(main, Dim.Layout.THREE_COLUMN_FIRST, Dim.Layout.THREE_COLUMN_SECOND);
        };
        dockHide = () -> {
            main.getItems().remove(CodeBotHost.panel());
            dividers(main, Dim.Layout.TWO_COLUMN_SPLIT);
        };

        HOST.getChildren().setAll(main);
    }

    // =====================================================================
    // Custom: only the ticked panels
    // =====================================================================

    /**
     * Builds the ticked panels: 1 fills the window, 2 sit side by side
     * 50 / 50, 3 to 5 keep Default's columns. See the class notes.
     */
    private static void buildCustom() {
        CustomLayoutConfig config = CustomLayoutConfig.effective();
        boolean dir = config.isShown(CustomLayoutConfig.Panel.DIRECTORY);
        boolean bot = config.isShown(CustomLayoutConfig.Panel.CHAT_BOT);
        boolean ed = config.isShown(CustomLayoutConfig.Panel.EDITOR);
        // A standalone Command Window is not counted: the others share the space.
        boolean con = config.isShown(CustomLayoutConfig.Panel.CLI) && !cliDetached;
        // A Variable Explorer in its own window, or closed, is not counted.
        boolean vars = config.isShown(CustomLayoutConfig.Panel.VARIABLES) && variablesInLayout();

        int count = (dir ? 1 : 0) + (bot ? 1 : 0) + (ed ? 1 : 0) + (con ? 1 : 0) + (vars ? 1 : 0);
        if (count == 0) {
            // Nothing ticked is left in the window (only the Variable
            // Explorer was ticked, and it is in its own window): the editor
            // holds the space rather than an empty window.
            ed = true;
            count = 1;
        }

        // The bot is placed by the build itself; nothing to do on open, and
        // it is never closed in Custom.
        dockShow = () -> {
        };
        dockHide = () -> {
        };

        if (count <= 2) {
            List<Node> nodes = new ArrayList<>(2);
            if (dir) {
                nodes.add(explorer);
            }
            if (bot) {
                nodes.add(CodeBotHost.prepareForColumn());
            }
            if (ed) {
                nodes.add(editor);
            }
            if (con) {
                nodes.add(cli);
            }
            if (vars) {
                nodes.add(variables);
            }
            if (count == 1) {
                attachCustom(null);
                HOST.getChildren().setAll(nodes.get(0));
                return;
            }
            if (config.isSwapped()) {
                Collections.reverse(nodes);
            }
            SplitPane main = split(Orientation.HORIZONTAL, nodes.toArray(Node[]::new));
            for (Node n : nodes) {
                SplitPane.setResizableWithParent(n, Boolean.TRUE);
            }
            dividers(main, Dim.CustomLayout.TWO_PANEL_SPLIT);
            SplitRatio.hold(main, Dim.CustomLayout.TWO_PANEL_SPLIT);
            attachCustom(main);
            HOST.getChildren().setAll(main);
            return;
        }

        // 3 to 5: Default's columns with the empty places removed.
        List<Node> columns = new ArrayList<>(3);
        List<Double> units = new ArrayList<>(3);

        // Standalone CLI with no editor ticked: the centre column (the CLI's
        // place) goes to the first shown of Variable Explorer, Code Bot, File
        // Explorer, which leaves its own column.
        Node substitute = null;
        if (cliDetached && !ed && config.isShown(CustomLayoutConfig.Panel.CLI)) {
            if (vars) {
                substitute = variables;
                vars = false;
            } else if (bot) {
                substitute = CodeBotHost.prepareForColumn();
                bot = false;
            } else if (dir) {
                substitute = explorer;
                dir = false;
            }
        }

        Node left = null;
        if (dir) {
            left = explorer;
            if (bot) {
                dockShow = () -> CodeBotHost.placeInExplorer(CodeBot_dim.OPEN_DIVIDER_POSITION);
            }
        } else if (bot) {
            left = CodeBotHost.prepareForColumn();
        }
        if (left != null) {
            columns.add(left);
            units.add(Dim.Split.UNITS_EXPLORER);
        }

        Node center = null;
        if (ed && con) {
            center = editorOverConsole();
        } else if (ed) {
            center = editor;
        } else if (con) {
            center = cli;
        } else if (substitute != null) {
            center = substitute;
        }
        if (center != null) {
            columns.add(center);
            units.add(Dim.Split.UNITS_EDITOR);
        }

        if (vars) {
            columns.add(variables);
            units.add(Dim.Split.UNITS_VARIABLES);
        }

        if (config.isSwapped() && count < 5) {
            Collections.reverse(columns);
            Collections.reverse(units);
        }

        SplitPane main = split(Orientation.HORIZONTAL, columns.toArray(Node[]::new));
        double total = 0;
        for (double u : units) {
            total += u;
        }
        double[] positions = new double[Math.max(0, columns.size() - 1)];
        double acc = 0;
        for (int i = 0; i < positions.length; i++) {
            acc += units.get(i);
            positions[i] = acc / total;
        }
        if (positions.length > 0) {
            dividers(main, positions);
            SplitRatio.hold(main, positions);
        }
        attachCustom(main);
        HOST.getChildren().setAll(main);
    }

    /** Tells the side panels which split they are in (null for none). */
    private static void attachCustom(SplitPane main) {
        explorer.attachTo(main);
        CodeBotHost.attach(explorer, main);
        if (!variablesDetached) {
            variables.attachTo(main);
        }
    }

    // =====================================================================
    // Notes for panels a Custom layout leaves out
    // =====================================================================

    /** Connected once. Each hook checks the layout on screen. */
    private static void installHooks() {
        CLI_Main.busyProperty().addListener((obs, was, busy) -> {
            if (Boolean.TRUE.equals(busy)) {
                runSinceBuild = true;
            }
        });

        // A file opens without the editor in the window.
        if (ide.editorTabs != null) {
            ide.editorTabs.getTabs().addListener((ListChangeListener<Tab>) change -> {
                while (change.next()) {
                    if (change.wasAdded() && isCustom() && !isInLayout(editor)) {
                        notice("The editor is not part of this Custom layout.");
                        return;
                    }
                }
            });
        }

        // A run produces variables without the Variable Explorer.
        if (ide.varTable != null) {
            watchVariables(ide.varTable.getItems());
            ide.varTable.itemsProperty().addListener((obs, was, isNow) -> watchVariables(isNow));
        }
    }

    private static void watchVariables(ObservableList<Variable> list) {
        if (watchedVariables != null) {
            watchedVariables.removeListener(VARIABLES_CHANGED);
        }
        watchedVariables = list;
        if (list != null) {
            list.addListener(VARIABLES_CHANGED);
        }
    }

    /** Once per Custom build: variables are kept but not shown. */
    private static void onVariablesAdded() {
        if (!isCustom() || !runSinceBuild || variablesNoticed || variablesDetached
                || isInLayout(variables)) {
            return;
        }
        variablesNoticed = true;
        notice("The Variable Explorer is not part of this Custom layout; variables are kept.");
    }

    private static boolean isCustom() {
        return CURRENT.get() == WindowLayout.CUSTOM;
    }

    // =====================================================================
    // Bot Centered: show the Command Window when a run reports an error
    // =====================================================================

    private static void onConsoleText(String was, String now) {
        // Standalone: in every layout (Bot Centered included), an error brings
        // a minimised Command Window window back instead of moving panels.
        boolean botCentered = CURRENT.get() == WindowLayout.BOT_CENTERED && !cliRevealed && workColumn != null;
        if (!cliDetached && !botCentered) {
            return;
        }
        if (now == null || was == null || now.length() <= was.length()) {
            return;
        }
        String appended = now.substring(was.length());
        if (!ERROR_MARK.matcher(appended).find()) {
            return;
        }
        if (cliDetached) {
            Platform.runLater(StandaloneCliWindow::revealIfMinimised);
        } else {
            Platform.runLater(LayoutManager::revealCommandWindow);
        }
    }

    private static void revealCommandWindow() {
        if (cliRevealed || workColumn == null || cliDetached) {
            return;
        }
        int at = workColumn.getItems().indexOf(variables);
        cliRevealed = true;
        SplitPane.setResizableWithParent(cli, Boolean.TRUE);
        if (at < 0) {
            workColumn.getItems().add(cli);
            dividers(workColumn, Dim.Layout.BOT_CENTERED_EDITOR_OVER_VARIABLES);
        } else {
            double[] keep = workColumn.getDividerPositions();
            workColumn.getItems().set(at, cli);
            dividers(workColumn, keep);
        }
        PanelActivation.setActive(PanelActivation.Panel.COMMAND_WINDOW);
        if (ide.console != null) {
            ide.console.positionCaret(ide.console.getLength());
        }
    }

    // =====================================================================
    // The Variable Explorer: separate window, closed, full screen
    // =====================================================================

    /** @return true when the current layout may place the Variable Explorer */
    private static boolean variablesInLayout() {
        return !variablesDetached && !variablesClosed;
    }

    /**
     * Separate Window view on or off. The layout is rebuilt without (or with)
     * the Variable Explorer; the other panels share the space.
     *
     * @param detached true while the Variable Explorer has its own window
     */
    public static void setVariablesDetached(boolean detached) {
        if (variablesDetached == detached) {
            return;
        }
        variablesDetached = detached;
        rebuildCurrent();
    }

    /** @return true while the Variable Explorer is in its own window */
    public static boolean isVariablesDetached() {
        return variablesDetached;
    }

    /**
     * The Variable Explorer's Close (true), or its return (false).
     *
     * @param closed true to take it out of the window
     */
    public static void setVariablesClosed(boolean closed) {
        if (variablesClosed == closed) {
            return;
        }
        variablesClosed = closed;
        rebuildCurrent();
    }

    /** @return true while the Variable Explorer is closed */
    public static boolean isVariablesClosed() {
        return variablesClosed;
    }

    /**
     * The Variable Explorer's Full Screen.
     *
     * @param on        true to start it, false to end it
     * @param companion shown beside the Variable Explorer (its variable
     *                  tabs); ignored when ending
     * @param onExit    run once it has ended and the layout is back; ignored
     *                  when ending
     */
    public static void setVariablesFullScreen(boolean on, Node companion, Runnable onExit) {
        if (on == variablesFullScreen) {
            return;
        }
        if (on) {
            fullScreenCompanion = companion;
            fullScreenExit = onExit;
            variablesFullScreen = true;
            rebuildCurrent();
        } else {
            variablesFullScreen = false;
            rebuildCurrent();
            runFullScreenExit();
        }
    }

    /** @return true while the Variable Explorer fills the window */
    public static boolean isVariablesFullScreen() {
        return variablesFullScreen;
    }

    private static void runFullScreenExit() {
        Runnable exit = fullScreenExit;
        fullScreenExit = null;
        fullScreenCompanion = null;
        if (exit != null) {
            exit.run();
        }
    }

    private static void rebuildCurrent() {
        if (!isInstalled()) {
            return;
        }
        WindowLayout layout = CURRENT.get();
        rebuild(layout == null ? WindowLayout.DEFAULT : layout);
    }

    /** H[ Variables | variable tabs ]: everything else makes way. */
    private static void buildVariablesFullScreen() {
        variables.setCollapseEnabled(false);
        SplitPane main = fullScreenCompanion == null
                ? split(Orientation.HORIZONTAL, variables)
                : split(Orientation.HORIZONTAL, variables, fullScreenCompanion);
        if (fullScreenCompanion != null) {
            SplitPane.setResizableWithParent(variables, Boolean.FALSE);
            dividers(main, Dim.VariableExplorer.FULL_SCREEN_TABLE_SHARE);
        }
        HOST.getChildren().setAll(main);
    }

    // =====================================================================
    // Standalone CLI
    // =====================================================================

    /**
     * The Command Window menu's Standalone CLI / Exit Standalone CLI. The
     * choice is saved and restored at the next launch; the layout is rebuilt
     * without (or with) the Command Window, and the editor takes its place.
     *
     * @param on true to put the Command Window in a window of its own
     */
    public static void setCliStandalone(boolean on) {
        if (!isInstalled()) {
            return;
        }
        if (on && !allowsCliStandalone(CURRENT.get())) {
            return;
        }
        boolean changes = cliStandalone != on || cliDetached != on;
        cliStandalone = on;
        if (ide.prefs != null) {
            ide.prefs.putBoolean(KEY_CLI_STANDALONE, on);
        }
        if (!changes) {
            return;
        }
        cliFocusOnShow = on;
        rebuildCurrent();
        cliFocusOnShow = false;
        if (!on && isInLayout(cli)) {
            // Docked back: the keyboard follows it into the main window.
            Platform.runLater(() -> {
                if (ide.stage != null) {
                    ide.stage.requestFocus();
                }
                PanelActivation.setActive(PanelActivation.Panel.COMMAND_WINDOW);
                if (ide.console != null) {
                    ide.console.requestFocus();
                }
            });
        }
    }

    /** @return the user's Standalone CLI choice (it may be waiting for a layout that allows it) */
    public static boolean isCliStandalone() {
        return cliStandalone;
    }

    /** @return true while the Command Window is in its own window */
    public static boolean isCliDetached() {
        return cliDetached;
    }

    /**
     * @return true when the menu entry works: always to exit, and to enter
     *         unless the Command Window would be the only panel left in the
     *         main window (a Custom layout)
     */
    public static boolean canToggleCliStandalone() {
        return isInstalled() && (cliDetached || allowsCliStandalone(CURRENT.get()));
    }

    /**
     * @return false only in a Custom layout without the CLI, where the menu
     *         leaves the entry out
     */
    public static boolean isCliStandaloneOffered() {
        WindowLayout layout = CURRENT.get();
        return layout == null || !layout.isCustom()
                || CustomLayoutConfig.effective().isShown(CustomLayoutConfig.Panel.CLI);
    }

    /**
     * Every layout but a Custom one where the CLI is not ticked, or is the
     * only panel the main window would hold (a Variable Explorer in its own
     * window, or closed, does not count as one).
     */
    private static boolean allowsCliStandalone(WindowLayout layout) {
        if (layout == null || !layout.isCustom()) {
            return true;
        }
        CustomLayoutConfig config = CustomLayoutConfig.effective();
        if (!config.isShown(CustomLayoutConfig.Panel.CLI)) {
            return false;
        }
        return config.isShown(CustomLayoutConfig.Panel.EDITOR)
                || config.isShown(CustomLayoutConfig.Panel.DIRECTORY)
                || config.isShown(CustomLayoutConfig.Panel.CHAT_BOT)
                || (config.isShown(CustomLayoutConfig.Panel.VARIABLES) && variablesInLayout());
    }

    /** After a build: the Command Window's own window follows {@link #cliDetached}. */
    private static void syncStandaloneCli() {
        if (cliDetached) {
            EditorCommandWindow.setStandalone(true);
            StandaloneCliWindow.show(ide, cli, cliFocusOnShow);
        }
    }

    /** @return true while the Command Window can be seen: in the layout or in its own window */
    private static boolean isCliOnScreen() {
        return isInLayout(cli) || (cliDetached && StandaloneCliWindow.isShowing());
    }

    // =====================================================================
    // Helpers
    // =====================================================================

    private static SplitPane split(Orientation orientation, Node... items) {
        SplitPane split = new SplitPane(items);
        split.setOrientation(orientation);
        BUILT.add(split);
        return split;
    }

    /**
     * Sets divider positions now and again on the next pulse: a split that is
     * already on screen honours new positions only once it has laid out with
     * its new items.
     */
    private static void dividers(SplitPane split, double... positions) {
        if (positions == null || positions.length == 0) {
            return;
        }
        split.setDividerPositions(positions);
        Platform.runLater(() -> split.setDividerPositions(positions));
    }

    /**
     * After a switch, a region that is no longer on screen must not keep the
     * navy highlight. Falls back to the editor.
     */
    private static void keepActiveRegionOnScreen() {
        PanelActivation.Panel active = PanelActivation.getActive();
        Node node = null;
        if (active != null) {
            node = switch (active) {
                case FILE_EXPLORER -> explorer;
                case VARIABLE_EXPLORER -> variables;
                case COMMAND_WINDOW -> cli;
                case CODE_BOT -> CodeBotHost.isShowing() ? CodeBotHost.panel() : null;
                case SIGNAL_EXPLORER -> SignalExplorerHost.isPlaced() ? SignalExplorerHost.panelIfBuilt() : null;
                case EDITOR -> editor;
            };
        }
        boolean onScreen = node != null && (isInLayout(node) || (node == cli && isCliOnScreen()));
        if (!onScreen) {
            PanelActivation.setActive(PanelActivation.Panel.EDITOR);
        }
    }

    private static boolean isInLayout(Node node) {
        for (Node n = node; n != null; n = n.getParent()) {
            if (n == HOST) {
                return true;
            }
        }
        return false;
    }
}
