package ui.layout;

import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.beans.property.ReadOnlyBooleanWrapper;
import javafx.stage.Stage;
import ui.UI_Main;

/**
 * The Full Screen toggle on the Settings &gt; Layout band (and F11).
 *
 * <p>
 * On: the window takes the whole screen, covering the operating system's
 * title bar and task bar. The ribbon, the breadcrumb bar and the footer stay
 * where they are. Off: the window goes back to exactly the size and state it
 * had before -- maximised or not -- with the task bar visible again.
 * </p>
 *
 * <p>
 * JavaFX's own "Press ESC to exit full-screen mode" banner is suppressed. Esc
 * still leaves full screen (the JavaFX default), and so do F11 and the band
 * button; {@link #fullScreenProperty()} follows the stage, so the button stays
 * in step however full screen was left.
 * </p>
 */
public final class FullScreenToggle {

    private static final ReadOnlyBooleanWrapper FULL_SCREEN = new ReadOnlyBooleanWrapper(false);

    private static Stage stage;

    private FullScreenToggle() {
    }

    /**
     * Connects the toggle to the main stage. Safe to call more than once.
     *
     * @param ide the IDE controller
     */
    public static void install(UI_Main ide) {
        if (ide == null || ide.stage == null || ide.stage == stage) {
            return;
        }
        stage = ide.stage;
        stage.setFullScreenExitHint("");
        FULL_SCREEN.set(stage.isFullScreen());
        stage.fullScreenProperty().addListener((obs, was, isNow) -> FULL_SCREEN.set(isNow));
    }

    /** Switches full screen on or off. */
    public static void toggle() {
        setFullScreen(!isFullScreen());
    }

    /**
     * @param on true for full screen
     */
    public static void setFullScreen(boolean on) {
        if (stage == null || stage.isFullScreen() == on) {
            return;
        }
        stage.setFullScreen(on);
    }

    /** @return true while the window is full screen */
    public static boolean isFullScreen() {
        return FULL_SCREEN.get();
    }

    /** @return the full-screen state, observable, for the band's button */
    public static ReadOnlyBooleanProperty fullScreenProperty() {
        return FULL_SCREEN.getReadOnlyProperty();
    }
}
