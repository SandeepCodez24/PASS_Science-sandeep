package ui.layout;

import ui.ui_functions.tools.LayoutIcons;

/**
 * The window arrangements offered on the Settings &gt; Layout band.
 *
 * <pre>
 *   DEFAULT             [Dir / Bot] | [Editor / CLI] | [Variables]
 *   BOT_CENTERED        [Editor / Variables] | [Code Bot, full height]
 *   EDITOR_CLI          [Editor] over [CLI (| Bot)]
 *   DIRECTORY_CENTERED  [Dir (/ Bot)] | [Editor / CLI]
 *   EDITOR_BOT_CLI      [Editor] | [Code Bot] | [CLI]
 *   CUSTOM              opens the Custom Layout window; changes nothing yet
 * </pre>
 *
 * <p>
 * The name is what the preference stores, so renaming a constant resets that
 * preference to {@link #DEFAULT} on the next launch rather than failing.
 * </p>
 */
public enum WindowLayout {

    DEFAULT("Default", "Default layout: explorer, editor, Command Window and Variable Explorer",
            LayoutIcons.LAYOUT_DEFAULT, false),

    BOT_CENTERED("Bot Centered", "Code Bot in the full right column; editor over Variable Explorer",
            LayoutIcons.LAYOUT_BOT_CENTERED, true),

    EDITOR_CLI("Editor-CLI", "Editor over Command Window only, 50 / 50",
            LayoutIcons.LAYOUT_EDITOR_CLI, false),

    DIRECTORY_CENTERED("Directory Centered", "File Explorer beside the editor and Command Window",
            LayoutIcons.LAYOUT_DIRECTORY_CENTERED, false),

    EDITOR_BOT_CLI("Editor-Bot-CLI", "Editor, Code Bot and Command Window in three equal columns",
            LayoutIcons.LAYOUT_EDITOR_BOT_CLI, true),

    CUSTOM("Custom", "Build your own layout",
            LayoutIcons.LAYOUT_CUSTOM, false);

    private final String label;
    private final String tooltip;
    private final String iconName;
    private final boolean opensBot;

    WindowLayout(String label, String tooltip, String iconName, boolean opensBot) {
        this.label = label;
        this.tooltip = tooltip;
        this.iconName = iconName;
        this.opensBot = opensBot;
    }

    /** @return the text under the tile */
    public String label() {
        return label;
    }

    /** @return the tile's tooltip */
    public String tooltip() {
        return tooltip;
    }

    /** @return the icon's base name under {@code /icons/layout} */
    public String iconName() {
        return iconName;
    }

    /**
     * @return true for the arrangements built around the Code Bot, which open
     *         it automatically when chosen
     */
    public boolean opensBot() {
        return opensBot;
    }

    /**
     * @return true for an arrangement that changes the window; false for
     *         {@link #CUSTOM}, which only opens its window for now
     */
    public boolean isArrangement() {
        return this != CUSTOM;
    }

    /**
     * @param name a stored preference value
     * @return the matching layout, or {@link #DEFAULT} for anything unknown
     */
    public static WindowLayout fromName(String name) {
        if (name != null) {
            for (WindowLayout layout : values()) {
                if (layout.name().equals(name) && layout.isArrangement()) {
                    return layout;
                }
            }
        }
        return DEFAULT;
    }
}
