package ui.layout.custom;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

import javafx.application.Platform;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import ui.UI_Main;
import ui.design.Dim;
import ui.explorer.TitleBarIcon;
import ui.layout.WindowLayout;
import ui.layout.custom.CustomLayoutConfig.Palette;
import ui.layout.custom.CustomLayoutConfig.Panel;
import ui.managers.TextColourManager;
import ui.managers.ThemeManager;
import ui.managers.ToolbarManager;

/**
 * Paints the colours chosen in the Custom Layout window: each panel's body,
 * its text, and the active title strip.
 *
 * <h3>Which layout is painted</h3>
 * <p>
 * The layout on screen ({@link #setLayout}) is painted with its own
 * {@link Palette} when {@link CustomLayoutConfig#usesColours} says so:
 * always for Custom, and for a standard layout while its tick in the Custom
 * Layout window's layout list is on. Otherwise nothing here is attached and
 * the theme's own colours show.
 * </p>
 *
 * <h3>How it stays out of the other layouts</h3>
 * <p>
 * The colours are a generated stylesheet attached to the layout host -- the
 * node every panel sits in -- not to the scene, and every rule starts with
 * {@code .custom-layout-on}, a class the host carries only while a palette
 * is in force. The ribbon, the breadcrumb bar and the footer are outside the
 * host and never touched.
 * </p>
 *
 * <h3>Why the rules always win</h3>
 * <p>
 * The {@code .custom-layout-on} prefix gives every rule one more class than
 * the theme rule it replaces, a parent's stylesheet is consulted after the
 * scene's, and every declaration is {@code !important}, so long selectors in
 * feature sheets (editor palette, Code Bot) cannot beat it.
 * </p>
 *
 * <h3>Readable text</h3>
 * <p>
 * Text colour follows the background ({@link CustomLayoutConfig#ink}). The
 * editor switches its whole palette through
 * {@link ThemeManager#setEditorInkSelector}; the Command Window its typed
 * command palette through {@link TextColourManager#setConsoleInkSelector};
 * the active title-strip glyphs through
 * {@link TitleBarIcon#setActiveInkOnDark}.
 * </p>
 *
 * <h3>Selection follows the base colour</h3>
 * <p>
 * The selected row in the File Explorer and the Variable Explorer is derived
 * from the Base Color ({@link #selection}).
 * </p>
 *
 * <h3>The Signal Explorer</h3>
 * <p>
 * Part of the Variable Explorer: it takes the Variable Explorer's colour.
 * </p>
 *
 * <h3>Windows of their own</h3>
 * <p>
 * A separate window (CLI History, a dialog) is not inside the layout host,
 * so the sheet above never reaches it. Its title strip reads the base colour
 * from {@link #baseProperty()} instead, which is null while the theme's own
 * colours are in force; {@code ui.design.AstraFrame} follows it.
 * </p>
 *
 * <h3>A panel in a window of its own (Standalone CLI)</h3>
 * <p>
 * The standalone Command Window is a panel, not a dialog, so it should keep
 * the colours the layout gives the CLI. Its holder is registered with
 * {@link #addHost}: it carries the same sheet and the same
 * {@code .custom-layout-on} class as the layout host, kept in step on every
 * refresh, until {@link #removeHost}.
 * </p>
 *
 * <h3>The window chrome</h3>
 * <p>
 * The Base Color also paints the navy chrome around the ribbon (Row-1 tab
 * strip and the window background behind the ribbon) through their inline
 * styles, which are put back exactly as they were when no palette is in
 * force.
 * </p>
 */
public final class CustomLayoutTheme {

    /** The class the layout host carries while a palette is in force. */
    public static final String ON_CLASS = "custom-layout-on";

    /** The class the Row-1 tab strip carries while a palette is in force. */
    public static final String CHROME_CLASS = "custom-chrome-on";

    private static final String P = "." + ON_CLASS + " ";

    /** Every chrome node's inline style before a palette changed it. */
    private static final Map<Node, String> ORIGINAL_STYLE = new IdentityHashMap<>();

    private static String chromeSheet;
    private static Parent chromeSheetOwner;

    private static UI_Main ide;
    private static Region host;
    private static WindowLayout layout;
    private static String sheet;

    /** Holders outside the layout host that wear the same sheet (Standalone CLI). */
    private static final List<Region> EXTRA_HOSTS = new ArrayList<>();

    /** The base colour in force, or null for the theme's own title colour. */
    private static final ReadOnlyObjectWrapper<Color> BASE = new ReadOnlyObjectWrapper<>();

    private CustomLayoutTheme() {
    }

    /**
     * The active title-strip colour the Custom Layout window has put in
     * force, for windows outside the layout host. Changes on every
     * Preview, Apply, layout switch and theme switch.
     *
     * @return the base colour, or null while the theme's own colours show
     */
    public static ReadOnlyObjectProperty<Color> baseProperty() {
        return BASE.getReadOnlyProperty();
    }

    /** @return the base colour in force now, or null for the theme's own */
    public static Color activeBase() {
        return BASE.get();
    }

    /**
     * Connects the painter to the layout host and to theme changes. Called
     * once by {@code LayoutManager.install}.
     *
     * @param ideRef  the IDE controller
     * @param hostRef the node every panel sits in
     */
    public static void attach(UI_Main ideRef, Region hostRef) {
        ide = ideRef;
        host = hostRef;
        ThemeManager.themeProperty().addListener((obs, was, isNow) -> refresh());
        // The ribbon is built after the layout; paint it once both are in
        // the scene.
        host.sceneProperty().addListener((obs, was, isNow) -> {
            if (isNow != null) {
                Platform.runLater(CustomLayoutTheme::refreshChrome);
            }
        });
    }

    /**
     * Gives a holder outside the layout host the layout's colours, now and
     * on every refresh. Safe to call more than once.
     *
     * @param extra the holder (the standalone Command Window's)
     */
    public static void addHost(Region extra) {
        if (extra == null || EXTRA_HOSTS.contains(extra)) {
            return;
        }
        EXTRA_HOSTS.add(extra);
        if (sheet != null) {
            extra.getStylesheets().add(sheet);
            extra.getStyleClass().add(ON_CLASS);
        }
    }

    /**
     * Takes the colours off a holder added with {@link #addHost}.
     *
     * @param extra the holder
     */
    public static void removeHost(Region extra) {
        if (extra == null || !EXTRA_HOSTS.remove(extra)) {
            return;
        }
        if (sheet != null) {
            extra.getStylesheets().remove(sheet);
        }
        extra.getStyleClass().remove(ON_CLASS);
    }

    /**
     * @param onScreen the layout now on screen (null for none)
     */
    public static void setLayout(WindowLayout onScreen) {
        layout = onScreen;
        refresh();
    }

    /**
     * Kept for older callers.
     *
     * @param on true while the Custom layout is on screen
     * @deprecated use {@link #setLayout}
     */
    @Deprecated
    public static void setEnabled(boolean on) {
        setLayout(on ? WindowLayout.CUSTOM : null);
    }

    /** @return the palette in force on screen, or null for the theme's own */
    private static Palette paletteOnScreen() {
        if (layout == null) {
            return null;
        }
        CustomLayoutConfig config = CustomLayoutConfig.effective();
        return config.usesColours(layout) ? config.palette(layout) : null;
    }

    /** Rebuilds the sheet from {@link CustomLayoutConfig#effective()}. */
    public static void refresh() {
        if (host == null) {
            return;
        }
        if (sheet != null) {
            host.getStylesheets().remove(sheet);
            for (Region extra : EXTRA_HOSTS) {
                extra.getStylesheets().remove(sheet);
            }
            sheet = null;
        }
        host.getStyleClass().remove(ON_CLASS);
        for (Region extra : EXTRA_HOSTS) {
            extra.getStyleClass().remove(ON_CLASS);
        }

        Palette palette = paletteOnScreen();
        BASE.set(palette == null ? null : palette.base());
        if (palette == null) {
            TitleBarIcon.setActiveInkOnDark(true);
            ThemeManager.setEditorInkSelector(ide, null);
            TextColourManager.setConsoleInkSelector(null);
            refreshChrome();
            return;
        }

        boolean dark = CustomLayoutConfig.DARK.equals(ThemeManager.getActiveTheme());

        sheet = dataUri(css(palette, dark));
        host.getStylesheets().add(sheet);
        host.getStyleClass().add(ON_CLASS);
        for (Region extra : EXTRA_HOSTS) {
            extra.getStylesheets().add(sheet);
            extra.getStyleClass().add(ON_CLASS);
        }

        TitleBarIcon.setActiveInkOnDark(!CustomLayoutConfig.isLight(palette.base()));
        // Captured per refresh: every change to the config calls refresh again.
        Color lightEditor = palette.color(Panel.EDITOR, false);
        Color darkEditor = palette.color(Panel.EDITOR, true);
        ThemeManager.setEditorInkSelector(ide, theme -> !CustomLayoutConfig.isLight(
                CustomLayoutConfig.DARK.equals(theme) ? darkEditor : lightEditor));
        Color lightCli = palette.color(Panel.CLI, false);
        Color darkCli = palette.color(Panel.CLI, true);
        TextColourManager.setConsoleInkSelector(theme -> !CustomLayoutConfig.isLight(
                CustomLayoutConfig.DARK.equals(theme) ? darkCli : lightCli));
        refreshChrome();
    }

    // =====================================================================
    // The chrome: Row-1 tab strip and the background behind the ribbon
    // =====================================================================

    /**
     * Paints the chrome in the base colour while a palette is in force, or
     * puts the original inline styles back. Safe to call before the ribbon
     * exists.
     */
    public static void refreshChrome() {
        List<Node> chrome = chromeNodes();
        Node tabStrip = ToolbarManager.ribbonBar;

        if (chromeSheet != null && chromeSheetOwner != null) {
            chromeSheetOwner.getStylesheets().remove(chromeSheet);
        }
        chromeSheet = null;
        chromeSheetOwner = null;
        if (tabStrip != null) {
            tabStrip.getStyleClass().remove(CHROME_CLASS);
        }

        Palette palette = paletteOnScreen();
        if (palette == null) {
            for (Node node : chrome) {
                String original = ORIGINAL_STYLE.remove(node);
                if (original != null) {
                    node.setStyle(original);
                }
            }
            return;
        }

        Color base = palette.base();
        String fill = "-fx-background-color: " + hex(base) + ";";
        for (Node node : chrome) {
            String original = ORIGINAL_STYLE.computeIfAbsent(node,
                    n -> n.getStyle() == null ? "" : n.getStyle());
            String sep = original.isBlank() || original.trim().endsWith(";") ? " " : "; ";
            // A later declaration in the same inline style wins.
            node.setStyle(original + sep + fill);
        }

        // Tab labels are white on navy. On a light base colour they turn
        // dark; on a dark one the theme's white already reads.
        //
        // The SELECTED tab is not on the base colour: it is painted in the
        // band's colour (-astra-chrome), so it keeps the band's own ink --
        // white in the dark theme, near-black in the light one -- rather than
        // the base colour's. Its rule is more specific, so it wins over the
        // first one; the ink is a palette token, so it follows a theme switch
        // without this sheet being rebuilt.
        if (tabStrip instanceof Parent strip && CustomLayoutConfig.isLight(base)) {
            String ink = hex(CustomLayoutConfig.ink(base));
            StringBuilder css = new StringBuilder();
            String c = "." + CHROME_CLASS;
            rule(css, c + " .ribbon-tab, " + c + " .ribbon-tab .label, " + c + " .ribbon-tab .text",
                    "-fx-text-fill: " + ink + " !important; -fx-fill: " + ink + " !important;");
            rule(css, c + " .ribbon-tab:selected, " + c + " .ribbon-tab:selected .label, "
                    + c + " .ribbon-tab:selected .text",
                    "-fx-text-fill: -astra-ribbon-tab-selected-text !important;"
                            + " -fx-fill: -astra-ribbon-tab-selected-text !important;");
            chromeSheet = dataUri(css.toString());
            chromeSheetOwner = strip;
            strip.getStylesheets().add(chromeSheet);
            strip.getStyleClass().add(CHROME_CLASS);
        }
    }

    /**
     * The nodes whose inline style carries the navy: the Row-1 tab strip,
     * the box holding the three ribbon rows, and the window's root.
     */
    private static List<Node> chromeNodes() {
        List<Node> nodes = new ArrayList<>();
        if (ToolbarManager.ribbonBar != null) {
            nodes.add(ToolbarManager.ribbonBar);
        }
        if (ide != null && ide.rootNode instanceof BorderPane root) {
            if (root.getTop() != null) {
                nodes.add(root.getTop());
            }
            nodes.add(root);
        }
        return nodes;
    }

    // =====================================================================
    // The sheet
    // =====================================================================

    private static String css(Palette c, boolean dark) {
        StringBuilder css = new StringBuilder(4096);
        base(css, c.base());
        editor(css, c.color(Panel.EDITOR, dark));
        directory(css, c.color(Panel.DIRECTORY, dark), c.base());
        console(css, c.color(Panel.CLI, dark));
        variables(css, c.color(Panel.VARIABLES, dark), c.base());
        bot(css, c.color(Panel.CHAT_BOT, dark));
        // Part of the Variable Explorer: same colour.
        signals(css, c.color(Panel.VARIABLES, dark));
        return css.toString();
    }

    /** The active title strip, its collapsed rail, label and button hover. */
    private static void base(StringBuilder css, Color base) {
        String bg = hex(base);
        String edge = hex(CustomLayoutConfig.mix(base, Color.BLACK, 0.25));
        String ink = hex(CustomLayoutConfig.ink(base));
        String hover = CustomLayoutConfig.isLight(base) ? "rgba(0, 0, 0, 0.12)" : "rgba(255, 255, 255, 0.20)";

        rule(css, P + ".panel-title-bar.panel-active",
                "-fx-background-color: " + bg + ";"
                        + " -fx-border-color: transparent transparent " + edge + " transparent;");
        rule(css, P + ".panel-rail.panel-title-bar.panel-active",
                "-fx-background-color: " + bg + ";"
                        + " -fx-border-color: transparent " + edge + " transparent transparent;");
        rule(css, P + ".panel-active .panel-title-label, " + P + ".panel-active .panel-rail-label",
                "-fx-text-fill: " + ink + ";");
        rule(css, P + ".panel-active .panel-title-button:hover",
                "-fx-background-color: " + hover + ";");
    }

    private static void editor(StringBuilder css, Color c) {
        String bg = hex(c);
        String tabs = "." + Dim.Editor.TAB_PANE_CLASS;
        rule(css, P + ".tab-pane" + tabs + ", "
                + P + tabs + " .tab-content-area, "
                + P + tabs + " .code-area",
                "-fx-background-color: " + bg + ";");
        // A plain-text tab (TextArea) has no syntax colours: flip its text.
        rule(css, P + tabs + " .text-area",
                "-fx-control-inner-background: " + bg + ";"
                        + " -fx-text-fill: " + hex(CustomLayoutConfig.ink(c)) + ";");
    }

    private static void directory(StringBuilder css, Color c, Color base) {
        String bg = hex(c);
        String ink = hex(CustomLayoutConfig.ink(c));
        rule(css, P + ".file-explorer-body, "
                + P + ".file-explorer-body .tree-view, "
                + P + ".file-explorer-body .tree-table-view, "
                + P + ".file-explorer-body .directory-tree",
                "-fx-background-color: " + bg + ";"
                        + " -fx-control-inner-background: " + bg + ";"
                        + " -fx-control-inner-background-alt: " + bg + ";");
        rule(css, P + ".file-explorer-body .tree-view .virtual-flow, "
                + P + ".file-explorer-body .tree-table-view .virtual-flow, "
                + P + ".file-explorer-body .tree-table-view .placeholder",
                "-fx-background-color: " + bg + ";");
        rule(css, P + ".file-explorer-body .tree-cell, "
                + P + ".file-explorer-body .tree-table-row-cell > .tree-table-cell",
                "-fx-text-fill: " + ink + ";");

        Color sel = selection(base);
        Color selOff = selectionUnfocused(base);
        rule(css, P + ".file-explorer-body .directory-tree, "
                + P + ".file-explorer-body .tree-table-view",
                "-fx-selection-bar: " + hex(sel) + ";"
                        + " -fx-selection-bar-non-focused: " + hex(selOff) + ";");
        rule(css, P + ".file-explorer-body .tree-table-row-cell:filled:selected > .tree-table-cell, "
                + P + ".file-explorer-body .tree-table-row-cell:filled:selected > .tree-table-cell .label",
                "-fx-text-fill: " + hex(CustomLayoutConfig.ink(selOff)) + ";");
        rule(css, P + ".file-explorer-body .tree-table-view:focused .tree-table-row-cell:filled:selected > .tree-table-cell, "
                + P + ".file-explorer-body .tree-table-view:focused .tree-table-row-cell:filled:selected > .tree-table-cell .label",
                "-fx-text-fill: " + hex(CustomLayoutConfig.ink(sel)) + ";");
    }

    /**
     * The selected-row colour for a base colour: a dark base gives a lighter
     * tint of itself (55 % of the way to white), a light base a darker shade
     * (30 % of the way to black).
     *
     * @param base the Base Color
     * @return the selection colour while the list has focus
     */
    static Color selection(Color base) {
        return CustomLayoutConfig.isLight(base)
                ? CustomLayoutConfig.mix(base, Color.BLACK, 0.30)
                : CustomLayoutConfig.mix(base, Color.WHITE, 0.55);
    }

    /**
     * The same, softer, for a list that does not have focus.
     *
     * @param base the Base Color
     * @return the selection colour while the list is not focused
     */
    static Color selectionUnfocused(Color base) {
        return CustomLayoutConfig.isLight(base)
                ? CustomLayoutConfig.mix(base, Color.BLACK, 0.15)
                : CustomLayoutConfig.mix(base, Color.WHITE, 0.75);
    }

    /** The Command Window surface, caret and error colour. */
    private static void console(StringBuilder css, Color c) {
        String bg = hex(c);
        boolean light = CustomLayoutConfig.isLight(c);
        rule(css, P + ".console-area, " + P + ".console-scroll",
                "-fx-background-color: " + bg + ";");
        rule(css, P + ".console-area .caret",
                "-fx-stroke: " + hex(CustomLayoutConfig.ink(c)) + ";");
        rule(css, P + ".console-area.console-error .text.console-output",
                "-fx-fill: " + (light ? "#c62828" : "#ef9a9a") + ";");
    }

    private static void variables(StringBuilder css, Color c, Color base) {
        Color ink = CustomLayoutConfig.ink(c);
        String bg = hex(c);
        String alt = hex(CustomLayoutConfig.mix(c, ink, 0.04));
        String hover = hex(CustomLayoutConfig.mix(c, ink, 0.09));
        Color selColor = selection(base);
        String selected = hex(selColor);
        String table = P + ".variable-explorer-table";

        rule(css, table + ", " + table + " .virtual-flow, " + table + " .corner, " + table + " .placeholder",
                "-fx-background-color: " + bg + ";"
                        + " -fx-control-inner-background: " + bg + ";"
                        + " -fx-control-inner-background-alt: " + alt + ";");
        rule(css, table + " .table-row-cell:even", "-fx-background-color: " + bg + ";");
        rule(css, table + " .table-row-cell:odd", "-fx-background-color: " + alt + ";");
        rule(css, table + " .table-row-cell:hover", "-fx-background-color: " + hover + ";");
        rule(css, table + " .table-row-cell:selected", "-fx-background-color: " + selected + ";");
        rule(css, table + " .table-cell, " + table + " .placeholder .label",
                "-fx-text-fill: " + hex(ink) + ";");
        rule(css, table + " .table-row-cell:selected .table-cell",
                "-fx-text-fill: " + hex(CustomLayoutConfig.ink(selColor)) + ";");
        rule(css, table + " .table-row-cell:selected .text",
                "-fx-fill: " + hex(CustomLayoutConfig.ink(selColor)) + ";");
    }

    private static void bot(StringBuilder css, Color c) {
        String bg = hex(c);
        Color ink = CustomLayoutConfig.ink(c);
        rule(css, P + ".code-bot-panel, "
                + P + ".code-bot-panel .code-bot-scroll, "
                + P + ".code-bot-panel .code-bot-scroll > .viewport, "
                + P + ".code-bot-panel .code-bot-messages, "
                + P + ".code-bot-panel .code-bot-input-area",
                "-fx-background-color: " + bg + ";");
        rule(css, P + ".code-bot-panel .code-bot-hint",
                "-fx-text-fill: " + hex(CustomLayoutConfig.mix(ink, c, 0.35)) + ";");
    }

    private static void signals(StringBuilder css, Color c) {
        rule(css, P + ".signal-explorer-body",
                "-fx-background-color: " + hex(c) + ";");
        rule(css, P + ".signal-explorer-body .label",
                "-fx-text-fill: " + hex(CustomLayoutConfig.ink(c)) + ";");
    }

    /**
     * Writes one rule, making every declaration {@code !important} unless it
     * already is.
     */
    private static void rule(StringBuilder css, String selector, String body) {
        StringBuilder important = new StringBuilder();
        for (String declaration : body.split(";")) {
            String d = declaration.trim();
            if (d.isEmpty()) {
                continue;
            }
            important.append(d);
            if (!d.endsWith("!important")) {
                important.append(" !important");
            }
            important.append("; ");
        }
        css.append(selector).append(" { ").append(important).append("}\n");
    }

    private static String dataUri(String css) {
        return "data:text/css;base64,"
                + Base64.getEncoder().encodeToString(css.getBytes(StandardCharsets.UTF_8));
    }

    private static String hex(Color c) {
        return CustomLayoutConfig.hex(c);
    }
}
