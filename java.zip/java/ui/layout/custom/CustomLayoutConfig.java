package ui.layout.custom;

import java.util.EnumMap;
import java.util.Locale;
import java.util.Map;

import javafx.scene.paint.Color;
import ui.UI_Main;
import ui.design.Typography;
import ui.layout.WindowLayout;

/**
 * What the user chose in the Custom Layout window.
 *
 * <ul>
 * <li><b>Custom panels</b> -- which of the five panels are part of the
 * Custom layout ({@link #isShown}), and whether the Custom layout is
 * mirrored ({@link #isSwapped}).</li>
 * <li><b>Colours, per layout</b> -- every layout, the five standard ones and
 * Custom, has a {@link Palette}: each panel's body colour in the light and
 * the dark theme, and the base (title-strip) colour.</li>
 * <li><b>When colours apply</b> -- Custom always uses its palette. A
 * standard layout uses its palette as soon as any colour in it differs from
 * factory ({@link #usesColours}); untouched, it keeps the theme's own look.
 * "Reset to factory" therefore puts every standard layout back to the
 * theme.</li>
 * <li><b>Theme</b> -- the theme Custom starts in.</li>
 * <li><b>Font size</b> -- the one UI font size for every layout: panels,
 * ribbon, footer, menus. Editor and Command Window text keep their own code
 * size. Stored under {@link Typography#FONT_SIZE_PREF_KEY}, which
 * {@code Typography} reads at launch.</li>
 * </ul>
 *
 * <h3>Three copies</h3>
 * <ul>
 * <li><b>Factory</b> -- {@link #factory()}: every panel ticked, the theme's
 * own colours, navy strips, light theme, standard layouts not coloured,
 * {@link Typography#DEFAULT_UI_FONT_SIZE}.</li>
 * <li><b>Saved</b> -- {@link #saved()}: what Apply last stored in the IDE's
 * Preferences; restored at every launch.</li>
 * <li><b>Preview</b> -- {@link #setPreview}: the live preview while the
 * Custom Layout window is open (every change shows at once). Never stored;
 * Apply and Cancel clear it.</li>
 * </ul>
 * <p>
 * {@link #effective()} is the one the window draws from: the preview while
 * there is one, otherwise the saved copy.
 * </p>
 *
 * <h3>The Signal Explorer</h3>
 * <p>
 * It is part of the Variable Explorer: it has no row of its own, is shown
 * whenever the Variable Explorer is, and takes the Variable Explorer's body
 * colours.
 * </p>
 */
public final class CustomLayoutConfig {

    /** The five panels in the Custom Layout window, in its row order. */
    public enum Panel {
        EDITOR("Editor Tab", "#ffffff", "#1e1e1e"),
        DIRECTORY("Directory Explorer", "#ffffff", "#252526"),
        CLI("CLI", "#ffffff", "#1e1e1e"),
        VARIABLES("Variable Explorer", "#ffffff", "#1e1e1e"),
        CHAT_BOT("Chat Bot", "#ffffff", "#252526");

        private final String label;
        private final Color factoryLight;
        private final Color factoryDark;

        Panel(String label, String factoryLight, String factoryDark) {
            this.label = label;
            this.factoryLight = Color.web(factoryLight);
            this.factoryDark = Color.web(factoryDark);
        }

        /** @return the text beside the tick box */
        public String label() {
            return label;
        }

        /**
         * @param dark true for the dark theme
         * @return the theme's own body colour for this panel
         */
        public Color factoryColor(boolean dark) {
            return dark ? factoryDark : factoryLight;
        }
    }

    /** One layout's colours: panel bodies in both themes and the base colour. */
    public static final class Palette {

        private final Map<Panel, Color> light = new EnumMap<>(Panel.class);
        private final Map<Panel, Color> dark = new EnumMap<>(Panel.class);
        private Color base = FACTORY_BASE;

        private Palette() {
            for (Panel p : Panel.values()) {
                light.put(p, p.factoryLight);
                dark.put(p, p.factoryDark);
            }
        }

        private Palette copy() {
            Palette c = new Palette();
            c.light.putAll(light);
            c.dark.putAll(dark);
            c.base = base;
            return c;
        }

        /**
         * @param panel     a panel
         * @param darkTheme true for the dark theme's colour
         * @return the panel's body colour in that theme
         */
        public Color color(Panel panel, boolean darkTheme) {
            return darkTheme ? dark.get(panel) : light.get(panel);
        }

        /** @return the colour of the active title strip */
        public Color base() {
            return base;
        }

        /** @return true while every colour is still the factory one */
        public boolean isFactory() {
            if (!FACTORY_BASE.equals(base)) {
                return false;
            }
            for (Panel p : Panel.values()) {
                if (!p.factoryLight.equals(light.get(p)) || !p.factoryDark.equals(dark.get(p))) {
                    return false;
                }
            }
            return true;
        }
    }

    /** The navy every title strip uses outside Custom. */
    public static final Color FACTORY_BASE = Color.web("#004073");

    public static final String LIGHT = "light";
    public static final String DARK = "dark";

    /** Custom's keys keep their old names, so saved Custom colours survive. */
    private static final String KEY = "layout.custom.";

    private static UI_Main ide;
    private static CustomLayoutConfig saved;
    private static CustomLayoutConfig preview;

    private final Map<Panel, Boolean> shown = new EnumMap<>(Panel.class);
    private final Map<WindowLayout, Palette> palettes = new EnumMap<>(WindowLayout.class);
    private String theme = LIGHT;
    private boolean swapped;
    private double fontSize = Typography.DEFAULT_UI_FONT_SIZE;

    private CustomLayoutConfig() {
        for (Panel p : Panel.values()) {
            shown.put(p, Boolean.TRUE);
        }
        for (WindowLayout l : WindowLayout.values()) {
            palettes.put(l, new Palette());
        }
    }

    // =====================================================================
    // The three copies
    // =====================================================================

    /**
     * Reads the saved copy from the IDE's Preferences. Called once by
     * {@code LayoutManager.install}.
     *
     * @param ideRef the IDE controller
     */
    public static void init(UI_Main ideRef) {
        ide = ideRef;
        saved = load();
        plainStandard = ide != null && ide.prefs != null
                && Boolean.parseBoolean(ide.prefs.get(KEY + "plainStandard", "false"));
        lastApplied = readLastApplied();
    }

    // =====================================================================
    // The layout the Custom Layout window last applied
    // =====================================================================

    private static final String LAST_KEY = KEY + "lastLayout";

    /**
     * The layout the Custom Layout window last applied: Custom, or a standard
     * layout in its own colours. The Custom tile brings it back and the
     * window opens on it, so a saved custom look stays until the user
     * applies another one.
     */
    private static WindowLayout lastApplied;

    /** @return the layout the window last applied ({@link WindowLayout#CUSTOM} if none) */
    public static WindowLayout lastApplied() {
        if (lastApplied == null) {
            lastApplied = readLastApplied();
        }
        return lastApplied;
    }

    /**
     * Remembers the layout the window applied, in memory and in Preferences.
     *
     * @param layout the layout; null means Custom
     */
    public static void setLastApplied(WindowLayout layout) {
        lastApplied = layout == null ? WindowLayout.CUSTOM : layout;
        if (ide != null && ide.prefs != null) {
            ide.prefs.put(LAST_KEY, lastApplied.name());
        }
    }

    private static WindowLayout readLastApplied() {
        if (ide == null || ide.prefs == null) {
            return WindowLayout.CUSTOM;
        }
        return WindowLayout.fromName(ide.prefs.get(LAST_KEY, WindowLayout.CUSTOM.name()));
    }

    // =====================================================================
    // Standard layout picked from the gallery: always its own look
    // =====================================================================

    /**
     * True while a standard layout is on screen because it was picked from
     * the Settings &gt; Layout gallery. It is then shown in its factory look
     * -- the navy base and the theme's own panel colours -- whatever colours
     * were saved for it, so the five standard tiles always give the standard
     * layouts. The colours saved for a standard layout are shown only when it
     * is previewed or applied from the Custom Layout window, and the gallery
     * then marks Custom.
     */
    private static boolean plainStandard;

    /**
     * @param plain true when a standard layout was picked from the gallery
     *              (factory look), false when the Custom Layout window puts
     *              a layout on screen (its saved colours). Remembered across
     *              restarts.
     */
    public static void setPlainStandard(boolean plain) {
        plainStandard = plain;
        if (ide != null && ide.prefs != null) {
            ide.prefs.put(KEY + "plainStandard", String.valueOf(plain));
        }
    }

    /** @return true while standard layouts are shown in their factory look */
    public static boolean isPlainStandard() {
        return plainStandard;
    }

    /** @return a fresh factory copy */
    public static CustomLayoutConfig factory() {
        return new CustomLayoutConfig();
    }

    /** @return the copy Apply last stored (factory if nothing was stored) */
    public static CustomLayoutConfig saved() {
        if (saved == null) {
            saved = load();
        }
        return saved;
    }

    /** @return the preview while there is one, otherwise the saved copy */
    public static CustomLayoutConfig effective() {
        return preview != null ? preview : saved();
    }

    /**
     * @param config what the live preview shows, or null to drop the preview
     */
    public static void setPreview(CustomLayoutConfig config) {
        preview = config == null ? null : config.copy();
    }

    /** @return true while a preview is on screen */
    public static boolean isPreviewing() {
        return preview != null;
    }

    /**
     * Stores a copy as the saved one, in memory and in Preferences.
     *
     * @param config the values to keep
     */
    public static void save(CustomLayoutConfig config) {
        saved = config.copy();
        if (ide == null || ide.prefs == null) {
            return;
        }
        for (Panel p : Panel.values()) {
            ide.prefs.put(KEY + "show." + p.name(), String.valueOf(saved.isShown(p)));
        }
        for (WindowLayout l : WindowLayout.values()) {
            String k = prefix(l);
            Palette pal = saved.palettes.get(l);
            for (Panel p : Panel.values()) {
                ide.prefs.put(k + "light." + p.name(), hex(pal.light.get(p)));
                ide.prefs.put(k + "dark." + p.name(), hex(pal.dark.get(p)));
            }
            ide.prefs.put(k + "base", hex(pal.base));
        }
        ide.prefs.put(KEY + "theme", saved.theme);
        ide.prefs.put(KEY + "swap", String.valueOf(saved.swapped));
        ide.prefs.putDouble(Typography.FONT_SIZE_PREF_KEY, saved.fontSize);
    }

    private static CustomLayoutConfig load() {
        CustomLayoutConfig c = new CustomLayoutConfig();
        if (ide == null || ide.prefs == null) {
            return c;
        }
        for (Panel p : Panel.values()) {
            c.shown.put(p, Boolean.parseBoolean(ide.prefs.get(KEY + "show." + p.name(), "true")));
        }
        for (WindowLayout l : WindowLayout.values()) {
            String k = prefix(l);
            Palette pal = c.palettes.get(l);
            for (Panel p : Panel.values()) {
                pal.light.put(p, parse(ide.prefs.get(k + "light." + p.name(), null), p.factoryLight));
                pal.dark.put(p, parse(ide.prefs.get(k + "dark." + p.name(), null), p.factoryDark));
            }
            pal.base = parse(ide.prefs.get(k + "base", null), FACTORY_BASE);
        }
        c.theme = DARK.equals(ide.prefs.get(KEY + "theme", LIGHT)) ? DARK : LIGHT;
        c.swapped = Boolean.parseBoolean(ide.prefs.get(KEY + "swap", "false"));
        c.fontSize = Typography.clampFontSize(
                ide.prefs.getDouble(Typography.FONT_SIZE_PREF_KEY, Typography.DEFAULT_UI_FONT_SIZE));
        return c;
    }

    private static String prefix(WindowLayout l) {
        return l.isCustom() ? KEY : KEY + l.name() + ".";
    }

    /** @return an independent copy */
    public CustomLayoutConfig copy() {
        CustomLayoutConfig c = new CustomLayoutConfig();
        c.shown.putAll(shown);
        for (WindowLayout l : WindowLayout.values()) {
            c.palettes.put(l, palettes.get(l).copy());
        }
        c.theme = theme;
        c.swapped = swapped;
        c.fontSize = fontSize;
        return c;
    }

    // =====================================================================
    // Custom: panels and order
    // =====================================================================

    /**
     * @param panel a panel
     * @return true if it is part of the Custom layout
     */
    public boolean isShown(Panel panel) {
        return Boolean.TRUE.equals(shown.get(panel));
    }

    /**
     * @param panel a panel
     * @param show  true to make it part of the Custom layout
     */
    public void setShown(Panel panel, boolean show) {
        shown.put(panel, show);
    }

    /** @return how many panels are ticked */
    public int shownCount() {
        int n = 0;
        for (Panel p : Panel.values()) {
            if (isShown(p)) {
                n++;
            }
        }
        return n;
    }

    /** @return true when the tick count allows the swap (2, 3 or 4 panels) */
    public boolean canSwap() {
        int n = shownCount();
        return n >= 2 && n <= 4;
    }

    /** @return true when the Custom layout is mirrored left to right */
    public boolean isSwapped() {
        return swapped;
    }

    public void setSwapped(boolean value) {
        swapped = value;
    }

    // =====================================================================
    // Colours, per layout
    // =====================================================================

    /**
     * @param layout a layout (null means Custom)
     * @return its colours
     */
    public Palette palette(WindowLayout layout) {
        return palettes.get(layout == null ? WindowLayout.CUSTOM : layout);
    }

    /**
     * @param layout a layout
     * @return true when that layout is painted with its palette: always for
     *         Custom; for a standard layout once any of its colours differs
     *         from factory
     */
    public boolean usesColours(WindowLayout layout) {
        if (layout == null) {
            return false;
        }
        if (layout.isCustom()) {
            return true;
        }
        // Picked from the gallery: the standard layout in its own look.
        return !plainStandard && !palette(layout).isFactory();
    }

    /** Custom's colour for a panel. */
    public Color color(Panel panel, boolean darkTheme) {
        return color(WindowLayout.CUSTOM, panel, darkTheme);
    }

    public Color color(WindowLayout layout, Panel panel, boolean darkTheme) {
        return palette(layout).color(panel, darkTheme);
    }

    /** Sets Custom's colour for a panel. */
    public void setColor(Panel panel, boolean darkTheme, Color color) {
        setColor(WindowLayout.CUSTOM, panel, darkTheme, color);
    }

    public void setColor(WindowLayout layout, Panel panel, boolean darkTheme, Color color) {
        if (color != null) {
            Palette p = palette(layout);
            (darkTheme ? p.dark : p.light).put(panel, opaque(color));
        }
    }

    /** @return Custom's base colour */
    public Color base() {
        return base(WindowLayout.CUSTOM);
    }

    public Color base(WindowLayout layout) {
        return palette(layout).base;
    }

    /** Sets Custom's base colour. */
    public void setBase(Color color) {
        setBase(WindowLayout.CUSTOM, color);
    }

    public void setBase(WindowLayout layout, Color color) {
        if (color != null) {
            palette(layout).base = opaque(color);
        }
    }

    // =====================================================================
    // Theme
    // =====================================================================

    /** @return {@link #LIGHT} or {@link #DARK} */
    public String theme() {
        return theme;
    }

    public void setTheme(String value) {
        theme = DARK.equals(value) ? DARK : LIGHT;
    }

    // =====================================================================
    // Font size (all layouts)
    // =====================================================================

    /**
     * @return the UI font size: panels, ribbon, footer, menus and dialogs, in
     *         every layout
     */
    public double fontSize() {
        return fontSize;
    }

    /**
     * @param size the UI font size; clamped to
     *             {@link Typography#UI_FONT_SIZE_MIN} ..
     *             {@link Typography#UI_FONT_SIZE_MAX} and rounded to a whole
     *             pixel
     */
    public void setFontSize(double size) {
        fontSize = Typography.clampFontSize(size);
    }

    // =====================================================================
    // Colour helpers
    // =====================================================================

    /**
     * @param c a colour
     * @return {@code #RRGGBB}
     */
    public static String hex(Color c) {
        return String.format(Locale.ROOT, "#%02X%02X%02X",
                (int) Math.round(c.getRed() * 255),
                (int) Math.round(c.getGreen() * 255),
                (int) Math.round(c.getBlue() * 255));
    }

    /**
     * True when dark text reads better on this colour than light text, by
     * the WCAG contrast ratio.
     *
     * @param c a background colour
     * @return true for a light background
     */
    public static boolean isLight(Color c) {
        double l = luminance(c);
        double onBlack = (l + 0.05) / 0.05;
        double onWhite = 1.05 / (l + 0.05);
        return onBlack >= onWhite;
    }

    /**
     * @param background a background colour
     * @return the readable text colour for it
     */
    public static Color ink(Color background) {
        return isLight(background) ? Color.web("#1f1f1f") : Color.web("#f0f0f0");
    }

    /**
     * @param a     first colour
     * @param b     second colour
     * @param share how much of {@code b}, 0..1
     * @return the blend
     */
    public static Color mix(Color a, Color b, double share) {
        double s = Math.max(0, Math.min(1, share));
        return new Color(
                a.getRed() + (b.getRed() - a.getRed()) * s,
                a.getGreen() + (b.getGreen() - a.getGreen()) * s,
                a.getBlue() + (b.getBlue() - a.getBlue()) * s,
                1.0);
    }

    private static double luminance(Color c) {
        return 0.2126 * channel(c.getRed()) + 0.7152 * channel(c.getGreen()) + 0.0722 * channel(c.getBlue());
    }

    private static double channel(double v) {
        return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
    }

    private static Color opaque(Color c) {
        return new Color(c.getRed(), c.getGreen(), c.getBlue(), 1.0);
    }

    private static Color parse(String web, Color fallback) {
        if (web == null || web.isBlank()) {
            return fallback;
        }
        try {
            return opaque(Color.web(web));
        } catch (IllegalArgumentException ex) {
            return fallback;
        }
    }
}
