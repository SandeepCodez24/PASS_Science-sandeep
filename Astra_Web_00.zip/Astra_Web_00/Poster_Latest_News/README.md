# Poster_Latest_News

Dynamic content for the first page. It changes periodically and is kept apart from the fixed site.

| Item | Purpose |
|---|---|
| `Posters/` | Pictures for the poster bar (carousel) on `main.html` |
| `News/` | One page per news item (`<slug>.html`) |
| `News/Images/` | Card pictures for the Latest News bar |

To add a news item: put its picture in `News/Images/`, add the page to the `news` section of `Webpage_Framework/site-map.json`, add its card to `main.html`, then run the build tools.
