(function () {
  'use strict';

  /* Header dropdowns: Products, Solutions, Learn and Search all open a panel under the ribbon */
  var triggers = Array.prototype.slice.call(document.querySelectorAll('[data-panel]'));

  function panelOf(trigger) {
    return document.getElementById(trigger.dataset.panel);
  }

  function closePanels(except) {
    triggers.forEach(function (trigger) {
      if (except && trigger.dataset.panel === except.dataset.panel) return;
      trigger.setAttribute('aria-expanded', 'false');
      panelOf(trigger).hidden = true;
    });
  }

  triggers.forEach(function (trigger) {
    trigger.addEventListener('click', function () {
      var open = trigger.getAttribute('aria-expanded') === 'true';
      closePanels(trigger);
      if (!open) setMenu(false);
      /* a panel can have two triggers (desktop and mobile search), keep both in sync */
      triggers.forEach(function (other) {
        if (other.dataset.panel === trigger.dataset.panel) other.setAttribute('aria-expanded', String(!open));
      });
      var panel = panelOf(trigger);
      panel.hidden = open;
      if (!open) {
        var field = panel.querySelector('input[type="search"]');
        if (field) field.focus();
      }
    });
  });

  document.addEventListener('click', function (event) {
    if (!event.target.closest('[data-header]')) closePanels();
    if (event.target.closest('.panel a')) closePanels();
  });

  document.addEventListener('keydown', function (event) {
    if (event.key !== 'Escape') return;
    var open = triggers.filter(function (trigger) {
      return trigger.getAttribute('aria-expanded') === 'true' && trigger.offsetParent !== null;
    })[0];
    closePanels();
    if (open) open.focus();
  });

  /* Mobile menu */
  var menuToggle = document.querySelector('[data-menu-toggle]');
  var mobileMenu = document.getElementById('mobile-menu');

  function setMenu(open) {
    if (!menuToggle || !mobileMenu) return;
    mobileMenu.hidden = !open;
    menuToggle.setAttribute('aria-expanded', String(open));
    menuToggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
  }

  if (menuToggle && mobileMenu) {
    menuToggle.addEventListener('click', function () {
      if (mobileMenu.hidden) closePanels();
      setMenu(mobileMenu.hidden);
    });

    mobileMenu.addEventListener('click', function (event) {
      if (event.target.closest('a')) setMenu(false);
    });

    mobileMenu.addEventListener('toggle', function (event) {
      if (!event.target.open) return;
      mobileMenu.querySelectorAll('details').forEach(function (item) {
        if (item !== event.target) item.open = false;
      });
    }, true);
  }

  /* Poster bar: four posters, arrows, dots and a gentle auto-advance */
  var carousel = document.querySelector('[data-carousel]');

  if (carousel) {
    var track = carousel.querySelector('[data-track]');
    var slides = Array.prototype.slice.call(track.children);
    var dots = Array.prototype.slice.call(carousel.querySelectorAll('[data-dots] button'));
    var current = 0;
    var timer = null;
    var still = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    function show(index) {
      current = (index + slides.length) % slides.length;
      track.style.transform = 'translateX(' + (-100 * current) + '%)';
      slides.forEach(function (slide, i) {
        var active = i === current;
        slide.classList.toggle('is-active', active);
        slide.setAttribute('aria-hidden', String(!active));
        if ('inert' in slide) slide.inert = !active;
      });
      dots.forEach(function (dot, i) {
        if (i === current) dot.setAttribute('aria-current', 'true');
        else dot.removeAttribute('aria-current');
      });
    }

    function play() {
      if (still || timer) return;
      timer = window.setInterval(function () { show(current + 1); }, 7000);
    }

    function pause() {
      window.clearInterval(timer);
      timer = null;
    }

    carousel.querySelector('[data-prev]').addEventListener('click', function () { show(current - 1); });
    carousel.querySelector('[data-next]').addEventListener('click', function () { show(current + 1); });
    dots.forEach(function (dot, i) {
      dot.addEventListener('click', function () { show(i); });
    });
    carousel.addEventListener('mouseenter', pause);
    carousel.addEventListener('mouseleave', play);
    carousel.addEventListener('focusin', pause);
    carousel.addEventListener('focusout', play);
    carousel.addEventListener('keydown', function (event) {
      if (event.key === 'ArrowLeft') show(current - 1);
      if (event.key === 'ArrowRight') show(current + 1);
    });
    document.addEventListener('visibilitychange', function () {
      if (document.hidden) pause(); else play();
    });

    show(0);
    play();
  }

  /* Tabs (Language Guide About/Examples and example levels). Without JS every panel stays visible. */
  document.querySelectorAll('[data-tabs]').forEach(function (container) {
    var list = Array.prototype.filter.call(container.children, function (child) {
      return child.getAttribute('role') === 'tablist';
    })[0];
    if (!list) return;
    var tabs = Array.prototype.slice.call(list.querySelectorAll('[role="tab"]'));

    function select(tab, focus) {
      tabs.forEach(function (item) {
        var on = item === tab;
        item.setAttribute('aria-selected', String(on));
        item.tabIndex = on ? 0 : -1;
        var panel = document.getElementById(item.getAttribute('aria-controls'));
        if (panel) panel.hidden = !on;
      });
      if (focus) tab.focus();
    }

    tabs.forEach(function (tab, index) {
      tab.addEventListener('click', function () { select(tab); });
      tab.addEventListener('keydown', function (event) {
        var step = event.key === 'ArrowRight' ? 1 : event.key === 'ArrowLeft' ? -1 : 0;
        if (!step) return;
        event.preventDefault();
        select(tabs[(index + step + tabs.length) % tabs.length], true);
      });
    });

    select(tabs.filter(function (tab) { return tab.getAttribute('aria-selected') === 'true'; })[0] || tabs[0]);
  });

  /* Default Functions reference lists: filter by words, and open an entry linked as #ref-<name>. */
  document.querySelectorAll('[data-ref]').forEach(function (ref) {
    var input = ref.querySelector('[data-ref-filter]');
    var status = ref.querySelector('[data-ref-count]');
    var entries = Array.prototype.slice.call(ref.querySelectorAll('.ref-entry'));
    var sections = Array.prototype.slice.call(ref.querySelectorAll('.ref-section'));
    if (input) {
      input.addEventListener('input', function () {
        var words = input.value.toLowerCase().trim().split(/\s+/).filter(Boolean);
        var shown = 0;
        entries.forEach(function (entry) {
          var text = entry.getAttribute('data-words') || '';
          var hit = words.every(function (w) { return text.indexOf(w) !== -1; });
          entry.hidden = !hit;
          if (hit) shown += 1;
        });
        sections.forEach(function (sec) {
          sec.hidden = !sec.querySelector('.ref-entry:not([hidden])');
        });
        if (status) status.textContent = words.length ? shown + ' of ' + entries.length + ' functions' : entries.length + ' functions';
      });
    }
    function openFromHash() {
      if (location.hash.indexOf('#ref-') !== 0) return;
      var target = document.getElementById(decodeURIComponent(location.hash.slice(1)));
      if (!target || !ref.contains(target)) return;
      var panel = ref.closest('[role="tabpanel"]');
      var tab = panel && document.getElementById(panel.getAttribute('aria-labelledby'));
      if (tab) tab.click();
      target.open = true;
      target.scrollIntoView();
    }
    window.addEventListener('hashchange', openFromHash);
    openFromHash();
  });

  /* Copy to clipboard: code boxes ([data-copy]) and letter tiles ([data-copy-text]) */
  function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) {
      return navigator.clipboard.writeText(text);
    }
    return new Promise(function (resolve, reject) {
      var area = document.createElement('textarea');
      area.value = text;
      area.setAttribute('readonly', '');
      area.style.position = 'fixed';
      area.style.opacity = '0';
      document.body.appendChild(area);
      area.select();
      try { document.execCommand('copy') ? resolve() : reject(); } catch (e) { reject(e); }
      document.body.removeChild(area);
    });
  }

  function flash(element, className, ms) {
    element.classList.add(className);
    clearTimeout(element._flash);
    element._flash = setTimeout(function () { element.classList.remove(className); }, ms || 1600);
  }

  document.querySelectorAll('[data-copy]').forEach(function (button) {
    var label = button.querySelector('span');
    button.addEventListener('click', function () {
      var head = button.closest('.lg-codehead');
      /* data-source holds the code as typed (names keep their _$ / _@ markers) */
      var pre = head && head.nextElementSibling;
      var code = pre ? (pre.getAttribute('data-source') || pre.textContent) : '';
      copyText(code).then(function () {
        if (label) label.textContent = 'Copied';
        flash(button, 'is-copied');
        setTimeout(function () { if (label) label.textContent = 'Copy'; }, 1600);
      }, function () {
        if (label) label.textContent = 'Press Ctrl+C';
      });
    });
  });

  /* Letter finder (Non-English Variables): click to copy, search across every language */
  document.querySelectorAll('[data-letter-finder]').forEach(function (finder) {
    var status = finder.querySelector('[data-lf-status]');
    var search = finder.querySelector('[data-lf-search]');
    var tiles = Array.prototype.slice.call(finder.querySelectorAll('[data-copy-text]'));
    var defaultStatus = status ? status.textContent : '';

    tiles.forEach(function (tile) {
      tile.addEventListener('click', function () {
        var letter = tile.getAttribute('data-copy-text');
        copyText(letter).then(function () {
          flash(tile, 'is-copied');
          if (status) {
            status.textContent = 'Copied ' + letter + '  ·  in the NC IDE, type ' + tile.getAttribute('data-command');
            flash(status, 'is-copied', 2400);
          }
        });
      });
    });

    function filter() {
      var query = search.value.trim().toLowerCase();
      var matches = 0;
      tiles.forEach(function (tile) {
        var hit = !query || tile.getAttribute('data-key').toLowerCase().indexOf(query) === 0 ||
          tile.getAttribute('data-glyph').indexOf(search.value.trim()) !== -1;
        if (hit && query) matches++;
        var inChart = tile.closest('.lf-chart');
        tile.classList.toggle(inChart ? 'is-dim' : 'is-hidden', !hit);
      });
      finder.querySelectorAll('.lf-chart tbody tr').forEach(function (row) {
        row.classList.toggle('is-hidden', !!query && !row.querySelector('[data-copy-text]:not(.is-dim)'));
      });
      finder.querySelectorAll('.lf-group').forEach(function (group) {
        var any = group.querySelector('[data-copy-text]:not(.is-hidden):not(.is-dim)');
        group.classList.toggle('is-hidden', !!query && !any);
      });
      if (status) status.textContent = query ? matches + ' letter' + (matches === 1 ? '' : 's') + ' match “' + search.value.trim() + '”' : defaultStatus;
      /* show the first language that has a match */
      if (query) {
        var current = finder.querySelector('.lf-tab[aria-selected="true"]');
        var panel = current && document.getElementById(current.getAttribute('aria-controls'));
        if (panel && !panel.querySelector('[data-copy-text]:not(.is-hidden):not(.is-dim)')) {
          finder.querySelectorAll('.lf-tab').forEach(function (tab) {
            var p = document.getElementById(tab.getAttribute('aria-controls'));
            if (p && p.querySelector('[data-copy-text]:not(.is-hidden):not(.is-dim)') && panel) {
              tab.click();
              panel = null;
            }
          });
        }
      }
    }
    if (search) search.addEventListener('input', filter);
  });

  /* Language Guide contents: collapsible on small screens */
  var navToggle = document.querySelector('[data-lg-nav-toggle]');
  if (navToggle) navToggle.addEventListener('click', function () {
    var open = navToggle.getAttribute('aria-expanded') !== 'true';
    navToggle.setAttribute('aria-expanded', String(open));
    navToggle.parentElement.classList.toggle('is-open', open);
  });

  /* Search page: show what was searched for (site search is not built yet) */
  var echo = document.querySelector('[data-search-echo]');

  if (echo) {
    var query = new URLSearchParams(window.location.search).get('q') || '';
    var input = document.querySelector('[data-search-input]');
    if (input) input.value = query;
    echo.textContent = query
      ? 'You searched for “' + query + '”. Site search is under development, so no results are shown yet.'
      : 'Site search is under development. Soon you will be able to search every page of neuralcolindes.com.';
  }
})();
