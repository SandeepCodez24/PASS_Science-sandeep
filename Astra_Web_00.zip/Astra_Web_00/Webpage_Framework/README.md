# Webpage_Framework

The central pivot that connects every page.

| Item | Purpose |
|---|---|
| `site-map.json` | Registry of every page: path, title, icon, description, breadcrumb and related pages. Add a page here first. |
| `Styles/layout.css` | Dimensions: ribbon height, content width, gutters and the column count of every grid at each screen width. |
| `Styles/site.css` | Components: ribbon bar, poster bar, news, learning column, footer, placeholder pages. |
| `Styles/language-guide.css` | Documentation page layout (sidebar + content). |
| `Scripts/site.js` | Menus, poster carousel, tabs, search. |
| `Pages/` | General pages: Products, Solutions, Company, Store, Support, Learn hubs and search. |
| `Build_Tools/` | Python builders. Not part of the published site. |

Stylesheets load in this order: `Control_Sheet/control-sheet.css` (fonts, sizes, colours), then `layout.css`, then `site.css`.

## After any change

```
python Webpage_Framework/Build_Tools/build_language_guide.py   # only if lg_content.py changed
python Webpage_Framework/Build_Tools/build_pages.py            # placeholders + header/footer on every page
python Webpage_Framework/Build_Tools/check_site.py             # links + CSS validity
```

`main.html` (root) is the single source of the shared header and footer. `build_pages.py` copies them into every page.

## Naming

Folders use `Capitalised_Words` and files use `lowercase-hyphen.html`. No spaces or `&`, because these names become URLs.
