#!/usr/bin/env python3
"""Build the Default Functions chapter: Neural_Code/default-functions.html and
Neural_Code/Default_Functions/<Domain_Folder>/<page>.html, from Build_Tools/df_content.py.

The pages use the Language Guide's design and parts (build_language_guide.py): tabs About /
Examples / Syntax Error, code boxes with a Copy button, outputs from the real NC interpreter.
On top of that, an About component can show a figure (an image under Images/).

Outputs are cached in Build_Tools/df_outputs.json; an example is re-run only when its code
changes (or with --run).

    python Webpage_Framework/Build_Tools/build_default_functions.py          # re-run changed examples, rebuild
    python Webpage_Framework/Build_Tools/build_default_functions.py --run    # re-run every example

Then run build_pages.py (menus/chrome) and check_site.py from the same folder.
"""
import hashlib
import html
import json
import re
import shutil
import subprocess
import zipfile
import sys
sys.dont_write_bytecode = True  # keep Build_Tools free of __pycache__
import tempfile
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
from build_language_guide import (LEVELS, NC_EXE, code_box, component, errors_panel, examples,  # noqa: E402
                                  figure, folder, head, highlight, out_box)
from df_content import CALLING, DOMAINS, LANDING, MULTICORE, PAGES, SAMPLES  # noqa: E402
from site_chrome import SITE, page  # noqa: E402

OUTPUTS = TOOLS / 'df_outputs.json'
CODE = SITE / 'Neural_Code'
CHAPTER = CODE / 'Default_Functions'
HOME = 'default-functions.html'


# ------------------------------------------------------------------ running examples
def jobs():
    yield 'landing/threads', MULTICORE['control_code']
    yield 'landing/calling', CALLING['code']
    for slug, pg in PAGES.items():
        for level, _ in LEVELS:
            yield f'{slug}/{level}', pg['examples'][level]['code']
        for n, e in enumerate(pg.get('errors', []), 1):
            yield f'{slug}/err{n}', e['wrong']
            yield f'{slug}/err{n}-fix', e['fix']


def run_examples(force=False):
    cache = json.loads(OUTPUTS.read_text(encoding='utf-8')) if OUTPUTS.exists() else {}
    have_nc = NC_EXE.exists()
    ran = missing = 0
    work = Path(tempfile.mkdtemp(prefix='nc_df_'))
    # Sample files: every example runs in a folder holding data/ (the published samples) and an empty out/.
    (work / 'data').mkdir()
    for folder_ in SAMPLES.values():
        for f in (SITE / folder_).iterdir():
            if f.is_file() and f.suffix != '.zip':
                shutil.copy2(f, work / 'data' / f.name)
    live = dict(jobs())
    for key, code in live.items():
        digest = hashlib.sha1(code.encode('utf-8')).hexdigest()
        if not force and cache.get(key, {}).get('sha1') == digest:
            continue
        if not have_nc:
            missing += 1
            continue
        shutil.rmtree(work / 'out', ignore_errors=True)
        (work / 'out').mkdir()
        script = work / 'example.nc'
        script.write_text(code + '\n', encoding='utf-8')
        result = subprocess.run([str(NC_EXE), str(script)], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, cwd=work, timeout=300)
        output = result.stdout.decode('utf-8', errors='replace')
        for form in {str(work), str(work).replace('\\', '/'), str(work.resolve())}:
            output = output.replace(form + '\\', '').replace(form + '/', '').replace(form, '<current folder>')
        cache[key] = {'sha1': digest, 'exit': result.returncode, 'output': output.replace('\r\n', '\n')}
        ran += 1
    cache = {k: v for k, v in cache.items() if k in live}
    OUTPUTS.write_text(json.dumps(cache, ensure_ascii=False, indent=1, sort_keys=True), encoding='utf-8')
    if missing:
        print(f'WARNING: nc.exe not found at {NC_EXE}; {missing} example(s) have no up-to-date output.')
    print(f'Ran {ran} example(s) through nc.exe.')
    for key in sorted(live):
        if key not in cache:
            continue
        out, code = cache[key]['output'], cache[key]['exit']
        wrong = re.search(r'/err\d+$', key) is not None
        if wrong and code == 0:
            print(f'WARNING: {key} should fail but nc.exe ran it without an error')
        if not wrong and code != 0:
            print(f'WARNING: {key} failed in nc.exe: {out.strip().splitlines()[-1] if out.strip() else ""}')
    return cache


def make_sample_zips():
    """<folder>/../<domain>-samples.zip, remade only when a sample file is newer than the zip."""
    for dom, folder_ in SAMPLES.items():
        src = SITE / folder_
        files = sorted(f for f in src.iterdir() if f.is_file())
        target = src.parent / f'{dom}-samples.zip'
        if target.exists() and all(f.stat().st_mtime <= target.stat().st_mtime for f in files):
            continue
        with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as z:
            for f in files:
                z.write(f, f'{src.name}/{f.name}')
        print(f'Wrote {target.relative_to(SITE).as_posix()} ({len(files)} files)')


# ------------------------------------------------------------------ page parts
def built_pages():
    """(domain slug, page slug) for every page that exists, in reading order."""
    return [(d[0], p) for d in DOMAINS for p in d[5]]


def page_url(dom, slug, here):
    """Link from `here` ('landing' or a domain slug) to a chapter page."""
    if here == 'landing':
        return f'Default_Functions/{folder(dom)}/{slug}.html'
    return f'{slug}.html' if here == dom else f'../{folder(dom)}/{slug}.html'


def sidebar(here, current=None):
    home = HOME if here == 'landing' else f'../../{HOME}'
    rows = [f'        <a class="lg-nav-home" href="{home}"{" aria-current=\"page\"" if here == "landing" else ""}>'
            f'Default Functions home</a>']
    for dom, title, _, _, _, slugs in DOMAINS:
        soon = '' if slugs else ' <span class="lg-soon">soon</span>'
        rows.append(f'        <p class="lg-nav-section">{html.escape(title)}{soon}</p>')
        if slugs:
            rows.append('        <ul>')
            for slug in slugs:
                mark = ' aria-current="page"' if slug == current else ''
                rows.append(f'          <li><a href="{page_url(dom, slug, here)}"{mark}>{html.escape(PAGES[slug]["title"])}</a></li>')
            rows.append('        </ul>')
    links = '\n'.join(rows)
    return f'''      <aside class="lg-sidebar" aria-label="Default Functions">
        <button class="lg-nav-toggle" type="button" aria-expanded="false" aria-controls="lg-nav" data-lg-nav-toggle>Default Functions contents</button>
        <nav class="lg-nav" id="lg-nav">
{links}
        </nav>
      </aside>'''


def band(root, crumbs):
    trail = '<span>/</span>'.join(f'<a href="{root}{href}">{html.escape(name)}</a>' if href else
                                  f'<span>{html.escape(name)}</span>' for name, href in crumbs)
    return f'''    <div class="lg-band">
      <div class="lg-band-inner">
        <nav class="lg-crumbs" aria-label="Breadcrumb"><a href="{root}main.html">Home</a><span>/</span>{trail}</nav>
        <p class="lg-band-title">Default Functions</p>
      </div>
    </div>'''


def pager(dom, slug):
    order = built_pages()
    i = order.index((dom, slug))
    if i > 0:
        d, p = order[i - 1]
        prev = f'<a class="lg-prev" href="{page_url(d, p, dom)}"><span>Previous</span>{html.escape(PAGES[p]["title"])}</a>'
    else:
        prev = f'<a class="lg-prev" href="../../{HOME}"><span>Previous</span>Default Functions home</a>'
    if i < len(order) - 1:
        d, p = order[i + 1]
        nxt = f'<a class="lg-next" href="{page_url(d, p, dom)}"><span>Next</span>{html.escape(PAGES[p]["title"])}</a>'
    else:
        nxt = f'<a class="lg-next" href="../../{HOME}"><span>Next</span>Default Functions home</a>'
    return f'        <nav class="lg-pager" aria-label="Previous and next page">{prev}{nxt}</nav>'


# ------------------------------------------------------------------ pages
SCIPY_REF = TOOLS / 'df_scipy_reference.json'
_scipy_cache = {}
CONTROL = re.compile(r'[\x00-\x08\x0b-\x1f\x7f�]')


def scipy_sections():
    if not _scipy_cache and SCIPY_REF.exists():
        _scipy_cache.update(json.loads(SCIPY_REF.read_text(encoding='utf-8')))
    return _scipy_cache


def reference_panel(pg):
    """The Reference tab: every function of the page's sections, generated from df_scipy_reference.json."""
    sections = scipy_sections()
    parts, count = [], 0
    for key in pg['reference']:
        sec = sections[key]
        rows = []
        datas = sec['data']
        if datas:
            blocks = ''.join(
                f'<p class="lg-box-label">Data {i + 1}:</p><pre class="lg-code"><code>{highlight(d)}</code></pre>'
                for i, d in enumerate(datas))
            rows.append(f'<details class="ref-data"><summary>Data the examples below use '
                        f'({len(datas)} block{"s" if len(datas) > 1 else ""}) - run it first</summary>{blocks}</details>')
        for e in sec['entries']:
            count += 1
            meta = ''.join(f'<dt>{k}</dt><dd>{html.escape(v)}</dd>' for k, v in
                           (('Inputs', e['inputs']), ('Needs', e['needs']), ('Returns', e['returns'])) if v)
            if e['scipy']:
                meta += f'<dt>SciPy</dt><dd><code>scipy.{html.escape(e["scipy"])}</code></dd>'
            if e['data'] is not None and len(datas) > 1:
                meta += f'<dt>Data</dt><dd>block {e["data"] + 1} above</dd>'
            calls = ''.join(
                f'<p class="lg-box-label">{html.escape(c["label"][:1].upper() + c["label"][1:])}:</p>'
                f'<pre class="lg-code"><code>{highlight(c["code"])}</code></pre>'
                + (f'<pre class="lg-output"><samp>{html.escape(CONTROL.sub("", c["out"]))}</samp></pre>' if c['out'] else '')
                for c in e['calls'][:pg.get('reference_calls', 2)])
            words = html.escape(f'{e["name"]} {e["desc"]} {e["scipy"]}'.lower(), quote=True)
            rows.append(f'<details class="ref-entry" id="ref-{html.escape(e["name"], quote=True)}" data-words="{words}">'
                        f'<summary><code class="ref-sig">{html.escape(e["sig"])}</code>'
                        f'<span class="ref-desc">{html.escape(e["desc"])}</span></summary>'
                        f'<div class="ref-body"><dl class="ref-meta">{meta}</dl>{calls}</div></details>')
        title = pg.get('reference_titles', {}).get(key, key.replace('_', ' ').capitalize())
        parts.append(f'<section class="ref-section"><h3 class="ref-section-title">{html.escape(title)} '
                     f'<small>{len(sec["entries"])}</small></h3>{"".join(rows)}</section>')
    head = (f'<div class="ref-bar"><label class="lf-search"><span class="sr-only">Filter functions</span>'
            f'<input type="search" placeholder="Filter {count} functions by name, description or SciPy name" '
            f'data-ref-filter></label><p class="lf-status" data-ref-count aria-live="polite">{count} functions</p></div>'
            '<p class="ref-note">Every function with its inputs, what it returns, the SciPy function it matches, and '
            'one or two calls with the output NC prints. Inputs are given in order. Click a function to open it.</p>')
    return count, '          <div class="ref" data-ref>' + head + ''.join(parts) + '</div>'


def build_page(dom, dom_title, slug, outputs):
    pg = PAGES[slug]
    root = '../../../'
    crumbs = [('Neural Code', 'Neural_Code/overview.html'), ('Default Functions', f'Neural_Code/{HOME}'),
              (dom_title, None)]
    title = html.escape(pg['title'])
    about = '\n'.join(component(c, i, root) for i, c in enumerate(pg['about'], 1))
    ref_tab = ref_panel = ''
    if pg.get('reference'):
        n_ref, ref_html = reference_panel(pg)
        ref_tab = ('\n              <button class="lg-tab" type="button" role="tab" id="t-ref" aria-controls="p-ref" '
                   f'aria-selected="false">Reference<span class="lg-tab-count">{n_ref}</span></button>')
        ref_panel = ('\n            <div class="lg-panel" role="tabpanel" id="p-ref" aria-labelledby="t-ref">\n'
                     f'{ref_html}\n            </div>')
    err_tab = err_panel = ''
    if pg.get('errors'):
        err_tab = ('\n              <button class="lg-tab lg-tab-err" type="button" role="tab" id="t-errors" '
                   f'aria-controls="p-errors" aria-selected="false">Syntax Error<span class="lg-tab-count">'
                   f'{len(pg["errors"])}</span></button>')
        err_panel = ('\n            <div class="lg-panel" role="tabpanel" id="p-errors" aria-labelledby="t-errors">\n'
                     f'{errors_panel(slug, pg, outputs, root)}\n            </div>')
    body = f'''{band(root, crumbs)}
    <div class="lg-layout">
{sidebar(dom, slug)}
      <div class="lg-main">
        <header class="lg-head">
          <p class="lg-kicker">{html.escape(dom_title.upper())}</p>
          <h1>{title}</h1>
          <p class="lg-summary">{pg["summary"]}</p>
        </header>
          <div class="lg-tabs" data-tabs>
            <div class="lg-tab-list" role="tablist" aria-label="{title}">
              <button class="lg-tab" type="button" role="tab" id="t-about" aria-controls="p-about" aria-selected="true">About</button>
              <button class="lg-tab" type="button" role="tab" id="t-examples" aria-controls="p-examples" aria-selected="false">Examples</button>{ref_tab}{err_tab}
            </div>
            <div class="lg-panel" role="tabpanel" id="p-about" aria-labelledby="t-about">
{about}
            </div>
            <div class="lg-panel" role="tabpanel" id="p-examples" aria-labelledby="t-examples">
{examples(slug, pg, outputs, root)}
            </div>{ref_panel}{err_panel}
          </div>
{pager(dom, slug)}
      </div>
    </div>'''
    description = re.sub(r'<[^>]+>', '', pg['summary'])
    target = CHAPTER / folder(dom) / f'{slug}.html'
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(page(root, f'{pg["title"]} - Default Functions', description, body, head(root)),
                      encoding='utf-8')


def domain_card(n, dom, title, desc, topics, slugs):
    if slugs:
        items = ''.join(f'<li><a href="{page_url(dom, s, "landing")}">{html.escape(PAGES[s]["title"])}</a></li>'
                        for s in slugs)
        status = '<span class="df-ready">Ready</span>'
    else:
        items = ''.join(f'<li>{html.escape(t)}</li>' for t in topics)
        status = '<span class="lg-soon">soon</span>'
    return f'''          <section class="lg-card df-card{"" if slugs else " df-card-soon"}">
            <p class="df-card-num">{n:02d} {status}</p>
            <h3>{html.escape(title)}</h3>
            <p class="df-card-text">{desc}</p>
            <ul>{items}</ul>
          </section>'''


def build_landing(outputs):
    root = '../'
    m = MULTICORE
    promises = ''.join(f'<div><p class="df-promise">{html.escape(t)}</p><p>{d}</p></div>' for t, d in m['promises'])
    head_row, *rows = m['kinds']
    kinds = ('<div class="lg-table-wrap"><table class="lg-table"><thead><tr>' +
             ''.join(f'<th>{h}</th>' for h in head_row) + '</tr></thead><tbody>' +
             ''.join('<tr>' + ''.join(f'<td>{v}</td>' for v in r) + '</tr>' for r in rows) + '</tbody></table></div>')
    intro = ''.join(f'<p>{t}</p>' for t in m['intro'])
    cards = '\n'.join(domain_card(i, *d[:2], d[3], d[4], d[5]) for i, d in enumerate(DOMAINS, 1))
    order = built_pages()
    start = (f'<a class="btn btn-accent lg-start" href="{page_url(*order[0], 'landing')}">Start with '
             f'{html.escape(PAGES[order[0][1]]["title"])}</a>') if order else ''
    body = f'''{band(root, [('Neural Code', 'Neural_Code/overview.html'), ('Default Functions', None)])}
    <div class="lg-layout">
{sidebar('landing')}
      <div class="lg-main">
        <header class="lg-head">
          <p class="lg-kicker">NEURAL CODE</p>
          <h1>{html.escape(LANDING["title"])}</h1>
          <p class="lg-summary">{LANDING["summary"]}</p>
          {start}
        </header>

        <section class="df-section" aria-labelledby="df-cores">
          <h2 id="df-cores">Built for every core</h2>
          <div class="df-text">{intro}</div>
          {figure(m["figure"], root)}
          <div class="df-promises">{promises}</div>
          <h3 class="df-sub">How many threads a function uses</h3>
          <p class="df-note">Each function knows what limits it. Work that streams through memory stops getting faster after a few threads, so NC caps it; heavy arithmetic uses every core.</p>
          {kinds}
          <h3 class="df-sub">Threads from a script</h3>
          <p class="df-note">{m["control_text"]}</p>
          <div class="lg-box">
            {code_box(m["control_code"], root)}
            {out_box(outputs.get('landing/threads', {}), label='Output (on a 28-thread PC):')}
          </div>
          <h3 class="df-sub">A multicore workout</h3>
          <p class="df-note">{m["workout_text"]}</p>
          <div class="lg-box">
            {code_box(m["workout_code"], root)}
          </div>
        </section>

        <section class="df-section" aria-labelledby="df-calling">
          <h2 id="df-calling">One way to call every function</h2>
          <p class="df-note">{CALLING["text"]}</p>
          <div class="lg-box">
            {code_box(CALLING["code"], root)}
            {out_box(outputs.get('landing/calling', {}))}
          </div>
        </section>

        <section class="lg-howto df-section" aria-labelledby="howto">
          <h2 id="howto">How each page works</h2>
          <div class="lg-howto-grid">
            <div><p class="lg-howto-tab">About</p><p>Each part of the topic in turn: what it does, its maths written as a formula, a diagram where one helps, and the syntax.</p></div>
            <div><p class="lg-howto-tab">Examples</p><p>Three runnable examples &mdash; <strong>basic</strong>, <strong>mid level</strong> and <strong>strong</strong> &mdash; each with the output NC prints for it and a Copy button.</p></div>
            <div><p class="lg-howto-tab lg-howto-tab-err">Syntax Error</p><p>Common mistakes: the wrong code, the message NC prints, and the corrected code with its output.</p></div>
          </div>
        </section>

        <section class="df-section" aria-labelledby="df-domains">
          <h2 id="df-domains">The domains</h2>
          <p class="df-note">The functions are grouped into ten domains. Each card lists the pages of its domain.</p>
          <div class="lg-cards df-cards">
{cards}
          </div>
        </section>
      </div>
    </div>'''
    target = CODE / HOME
    target.write_text(page(root, 'Default Functions', re.sub(r'<[^>]+>', '', LANDING['summary']), body,
                           head(root, math=False)), encoding='utf-8')


def main():
    make_sample_zips()
    outputs = run_examples(force='--run' in sys.argv)
    for dom, title, _, _, _, slugs in DOMAINS:
        for slug in slugs:
            build_page(dom, title, slug, outputs)
    build_landing(outputs)
    wanted = {CHAPTER / folder(d) / f'{s}.html' for d, s in built_pages()}
    CHAPTER.mkdir(exist_ok=True)
    for old in CHAPTER.rglob('*.html'):
        if old not in wanted:
            old.unlink()
            print(f'Removed {old.relative_to(SITE).as_posix()} (no longer in Default Functions)')
    for d in sorted(CHAPTER.iterdir()):
        if d.is_dir() and not any(d.iterdir()):
            d.rmdir()
    if not any(CHAPTER.iterdir()):
        CHAPTER.rmdir()  # no domain pages yet
    print(f'Built the Default Functions home page and {len(wanted)} pages.')


if __name__ == '__main__':
    main()
