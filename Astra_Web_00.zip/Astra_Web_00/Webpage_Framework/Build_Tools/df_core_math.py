"""Default Functions - Core Math Functions (source: Function_Test/Code/A_02_Function_Syntax_tests,
files R1-R10; R9 holds one example for each of the 90 vector- and scalar-math functions).

Every example and error card is run through nc.exe by build_default_functions.py.
"""
from df_helpers import err, ex, fig, fn, reference

IMG = 'Images/Neural_Code/Default_Functions/Core_Math/'
LG = '../../Language_Guide/'          # from Neural_Code/Default_Functions/Core_Math/ to the Language Guide
PAGES = {}

# ================================================================== 1. Calling built-in functions
PAGES['calling-built-ins'] = {
    'title': 'Calling Built-in Functions',
    'summary': 'Built-in functions take their values in order or by name, with the same rules as the functions '
               'you write. This page shows how to read a reference heading and what NC tells you when a call '
               'does not fit.',
    'about': [
        fn('Reading a reference heading', 'Every function on these pages is introduced by its call, for example '
           '<code>allclose(A, B, atol=0.1, rtol=0)</code>. The inputs are listed in order; '
           '<code>name=value</code> shows a default, and square brackets such as <code>max(A[, B])</code> mark an '
           'input you may leave out.',
           more=['The table under each heading repeats the inputs with their meaning and default. '
                 '"By name only" means the input must be written as <code>name=value</code>.'],
           syntax='allclose(A, B, atol=0.1, rtol=0)\nmax(A[, B], axis=k)'),
        fn('Values in order', 'Plain values fill the inputs from left to right, so the third plain value of '
           '<code>allclose</code> is <code>atol</code>.',
           syntax='allclose(A, B, 0.2)        # the same as allclose(A, B, atol=0.2)'),
        fn('Values by name', 'Named values go to their input first; plain values then fill the inputs that are '
           'still open, from left to right. In <code>allclose(A, B, 0.2, atol=0.1)</code>, <code>atol</code> is '
           '0.1 and the plain 0.2 fills the next open input, <code>rtol</code>.',
           more=[f'This is the same rule as for your own functions: see <a href="{LG}Functions/'
                 'defaults-named-inputs.html">Defaults &amp; Named Inputs</a> in the Language Guide.'],
           syntax='allclose(B=B, A=A, atol=0.01)\nround(3.14159, decimals=2)\nclip([1, 5, 9], lo=2, hi=6)'),
        fn('Inputs by name only', 'Some inputs change what a function does rather than giving it data. They are '
           'given by name only: <code>axis</code> of <code>max</code> and <code>min</code>, <code>deg</code> of '
           '<code>angle</code>.',
           syntax='max([1, 5; 7, 2], axis=0)\nangle([1i, -1], deg=true)'),
        fn('Functions that take values in order only', 'A few functions do not accept names yet, for example '
           '<code>sqrt</code> and <code>einsum</code>. NC says so if you name one of their values.',
           syntax='sqrt(4)\neinsum("i,i->", [1, 2, 3], [4, 5, 6])'),
        fn('Calling with a dot', '<code>x.f()</code> calls the built-in <code>f</code> with <code>x</code> as its '
           'first value, so <code>x.sqrt()</code> is <code>sqrt(x)</code>. Other values follow in order.',
           syntax='x = 16;\nx.sqrt()'),
        fn('Your names come first', 'A variable you create with the same name as a built-in constant is used '
           'instead of the constant, inside the function where you made it. <code>euler_gamma</code> is '
           '0.577216 until you assign <code>euler_gamma = 5</code>.',
           syntax='a = euler_gamma;      # 0.577216\neuler_gamma = 5;\nc = euler_gamma + 1; # 6'),
    ],
    'examples': {
        'basic': ex('In order and by name', 'Three ways to give <code>allclose</code> its tolerance, and two '
                    'built-ins with named inputs.', '''
A = [1, 1; 1, 1];
B = [0.95, 1; 1, 1.2];
publish("allclose(A, B)            ", allclose(A, B));
publish("allclose(A, B, 0.25)      ", allclose(A, B, 0.25));
publish("allclose(A, B, atol=0.25) ", allclose(A, B, atol=0.25));
publish("round:", round([1.234, 5.678], decimals=1));
publish("clip :", clip([1, 5, 9], lo=2, hi=6));
'''),
        'mid': ex('Names and plain values together', 'Named values are placed first; the plain values fill the '
                  'rest in order. <code>gcd(12, B=18)</code> names the second input; <code>polydiv</code> takes '
                  'both inputs by name, in any order.', '''
A = [1, 1; 1, 1];
B = [0.95, 1; 1, 1.2];
r8 = allclose(A, B, 0.2, atol=0.1)
g = gcd(12, B=18)
[q, r] = polydiv(p2=[1, 1], p1=[1, 3, 2])
m = max([1, 5; 7, 2], axis=0)
d = angle([1i, -1], deg=true)
'''),
        'strong': ex('Dots, constants and your own names', 'Calling with a dot, the built-in constant '
                     '<code>euler_gamma</code>, and a variable of the same name that takes its place inside one '
                     'function only.', '''
x = 16;
publish("x.sqrt() =", x.sqrt());

function y = useg():
   y = euler_gamma;
fnend
function y = useg2():
   euler_gamma = 7;
   y = euler_gamma;
fnend
publish("euler_gamma =", euler_gamma, "  2 * euler_gamma =", 2 * euler_gamma);
publish("useg() =", useg(), "  useg2() =", useg2(), "  useg() again =", useg());
euler_gamma = 5;
publish("after euler_gamma = 5 in the script:", euler_gamma + 1, "  useg() =", useg());
'''),
    },
    'errors': [
        err('An input name that does not exist', 'NC lists the inputs the function has, and its usage.',
            'A = [1, 1; 1, 1];\nB = [0.95, 1; 1, 1.2];\nr = allclose(A, B, tol=0.1);',
            'A = [1, 1; 1, 1];\nB = [0.95, 1; 1, 1.2];\nr = allclose(A, B, atol=0.1);\npublish(r);'),
        err('A required value is missing', '<code>allclose</code> compares two values; <code>B</code> has no '
            'default.', 'A = [1, 1; 1, 1];\nr = allclose(A, atol=0.1);',
            'A = [1, 1; 1, 1];\nr = allclose(A, A * 1.05, atol=0.1);\npublish(r);'),
        err('The same input given twice', 'Each input can be given once.',
            'A = [1, 1; 1, 1];\nr = allclose(A, A, atol=0.1, atol=0.2);',
            'A = [1, 1; 1, 1];\nr = allclose(A, A, atol=0.1, rtol=0.2);\npublish(r);'),
        err('Naming a value of a function that takes values in order only', '<code>sqrt</code> does not accept '
            'names yet.', 'r = sqrt(x=4);', 'r = sqrt(4);\npublish(r);'),
        err('Too many values', '<code>exp</code> takes one value.', 'r = exp(1, 2);', 'r = exp(1) * exp(2);\npublish(r);'),
        err('A by-name input with the wrong kind of value', '<code>deg</code> is a true/false switch.',
            'r = angle(1i, deg=1);', 'r = angle(1i, deg=true);\npublish(r);'),
    ],
}

# ================================================================== 2. Comparing values
A_CMP = 'A = [1, 1, 1; 1, 1, 1; 1, 1, 1];\nB = [0.99999999, 0.91, 0.999; 1.000001, 1.0, 1.00001; 0.999999, 0.999999, 0.99999];\n'

PAGES['comparing-values'] = {
    'title': 'Comparing Values',
    'summary': 'Largest and smallest values, equality, and equality within a tolerance: '
               '<code>max</code>, <code>min</code>, <code>fmax</code>, <code>fmin</code>, <code>equal</code>, '
               '<code>equiv</code>, <code>allclose</code> and <code>isclose</code>.',
    'about': reference('Every function here works on numbers, vectors and matrices; <code>max</code> and '
                       '<code>min</code> also work on N-dimensional matrices.', [
        fn('max(A[, B], axis=k)', 'The largest element of A; with <code>axis</code>, the largest along that axis; '
           '<code>max(A, B)</code> gives the larger of each pair of elements.',
           inputs=[('A', 'number, vector, matrix or N-D matrix', ''),
                   ('B', 'a second value of the same size, or one number', 'left out'),
                   ('axis', '0 = down each column, 1 = along each row (-1 = the last axis); by name only',
                    'all elements')],
           more=['A <code>nan</code> in A makes the result <code>nan</code>; use <code>fmax</code> to skip it. '
                 '<code>axis</code> works with one value only, not with <code>max(A, B)</code>.'],
           math=r'\max(A) = \max_{i,j} A_{ij}, \qquad \max(A, \text{axis}=0)_j = \max_i A_{ij}',
           syntax='max([1, 2; 7, 4])            # 7\nmax([1, 2; 7, 4], axis=0)    # 7  4\nmax([1, 2; 7, 4], axis=1)    # 2  7\nmax([1, 2; 7, 4], [3, 3; 3, 3])',
           short='the largest element, the largest along an axis, or the larger of each pair'),
        fn('min(A[, B], axis=k)', 'The smallest element of A; with <code>axis</code>, the smallest along that '
           'axis; <code>min(A, B)</code> gives the smaller of each pair.',
           inputs=[('A, B, axis', 'as <code>max</code>', '')],
           syntax='min([1, 2; 7, 4])            # 1\nmin([1, 2; 7, 4], axis=-1)   # 1  4',
           short='the smallest element, along an axis, or of each pair'),
        fn('fmax(A, B)', 'The larger of each pair of elements; a <code>nan</code> loses to a number.',
           inputs=[('A, B', 'numbers, vectors or matrices of the same size (or one number)', '')],
           syntax='fmax([1, 8, nan], [4, 2, 3])   # 4  8  3'),
        fn('fmin(A, B)', 'The smaller of each pair of elements; a <code>nan</code> loses to a number.',
           inputs=[('A, B', 'as <code>fmax</code>', '')],
           syntax='fmin([1, 8, nan], [4, 2, 3])   # 1  2  3'),
        fn('equal(A, B)', 'True when A and B have the same size and exactly the same elements.',
           inputs=[('A, B', 'any two values', '')],
           syntax='equal(unit_matrix(3), unit_matrix(3))   # true'),
        fn('equiv(A, B)', 'True when A and B are equal after a row (or a single number) is repeated to the size '
           'of the other.',
           inputs=[('A, B', 'any two values', '')],
           syntax='equiv([1, 2, 3], [1, 2, 3; 1, 2, 3])   # true'),
        fn('allclose(A, B, atol=0.1, rtol=0)', 'True when <em>every</em> element of A is within the tolerance of '
           'the matching element of B.',
           inputs=[('A, B', 'values of the same size (or one number)', ''),
                   ('atol', 'absolute tolerance; a third plain value is <code>atol</code>', '0.1'),
                   ('rtol', 'relative tolerance, a fraction of |B|', '0')],
           more=['The absolute part suits values near zero; the relative part grows with the size of B, which '
                 'suits large values. Use both to cover both.'],
           math=r'|A_{ij} - B_{ij}| \;\le\; \text{atol} + \text{rtol}\,|B_{ij}| \quad\text{for every } i, j',
           figure=fig(IMG + 'comparing-values-01.svg',
                      'A band around B: its half-width is atol plus rtol times |B|, so it widens as |B| grows. '
                      'Points of A inside the band count as close.',
                      'The tolerance band: a value of A is close to B when it falls inside '
                      '<code>atol + rtol·|B|</code> of it. With <code>rtol</code> the band widens for larger values.'),
           syntax='allclose(A, B)              # atol = 0.1\nallclose(A, B, 0.05)        # atol = 0.05\nallclose(A, B, atol=0, rtol=0.1)',
           short='true when every element is within a tolerance'),
        fn('isclose(A, B, atol=0.1, rtol=0)', 'The same test as <code>allclose</code>, answered for each element: '
           'a matrix of true and false.',
           inputs=[('A, B, atol, rtol', 'as <code>allclose</code>', '')],
           syntax='isclose(1, 1.05)      # true\nisclose(1, 1.2)       # false',
           short='true / false for each element'),
    ]),
    'examples': {
        'basic': ex('Largest and smallest', 'The largest and smallest element, per column and per row, and the '
                    'larger of each pair.', '''
M = [1, 5, 2; 7, 0, 4];
a = max(M)
b = min(M)
c = max(M, axis=0)
d = max(M, axis=1)
e = max(M, [3, 3, 3; 3, 3, 3])
'''),
        'mid': ex('Tolerances', 'One matrix of measurements against the value it should have. The loose default '
                  'accepts it; a tighter tolerance finds the one value that is off, and <code>isclose</code> '
                  'shows where.', A_CMP + '''
publish("allclose(A, B)                 ", allclose(A, B));
publish("allclose(A, B, 0.05)           ", allclose(A, B, 0.05));
publish("allclose(A, B, atol=0.2)       ", allclose(A, B, atol=0.2));
publish("allclose(A, B, atol=0, rtol=0.1)", allclose(A, B, atol=0, rtol=0.1));
I = isclose(A, B, atol=0.05)
'''),
        'strong': ex('N-D matrices, nan and exact equality', '<code>max</code> on a 2 x 2 x 2 matrix along each '
                     'axis, <code>nan</code> handling with <code>fmax</code>, and the difference between '
                     '<code>equal</code>, <code>equiv</code> and <code>allclose</code>.', '''
N = [1, 2; 3, 4 ;; 5, 6; 9, 8];
g = max(N)
h = max(N, axis=0)
i = min(N, axis=2)
l = max([1, nan, 3])
f = fmax([1, nan, 3], [0, 2, 0])
row = [1, 2, 3];
grid = [1, 2, 3; 1, 2, 3];
publish("equal:", equal(row, grid), "  equiv:", equiv(row, grid));
publish("equal(row, row + 0.01):", equal(row, row + 0.01), "  allclose:", allclose(row, row + 0.01));
'''),
    },
    'errors': [
        err('An axis the value does not have', 'A matrix has axes 0 and 1 (or -1 and -2).',
            'm = max([1, 2; 7, 4], axis=2);', 'm = max([1, 2; 7, 4], axis=1);\npublish(m);'),
        err('axis with two values', '<code>axis</code> works on one value. To compare two values pair by pair, '
            'leave it out.', 'm = max([1, 2], [3, 4], axis=0);', 'm = max([1, 2], [3, 4]);\npublish(m);'),
    ],
}

# ================================================================== 3. Powers and logarithms
PAGES['powers-logarithms'] = {
    'title': 'Powers, Exponentials & Logarithms',
    'summary': 'Powers and exponentials in any whole base, reciprocals, and logarithms that stay exact for tiny '
               'values and do not overflow for huge ones.',
    'about': reference('All of these work element by element on numbers, vectors and matrices.', [
        fn('exp(x)', 'e raised to every element.', inputs=[('x', 'number, vector or matrix', '')],
           more=['<code>exp(-inf)</code> is 0.'], math=r'\exp(x) = e^{x}', syntax='exp(1)    # 2.718282'),
        fn('exp2(x)', '2 raised to every element.', inputs=[('x', 'number, vector or matrix', '')],
           math=r'\text{exp2}(x) = 2^{x}', syntax='exp2(3)   # 8'),
        fn('expN(x)', 'N raised to every element, for any whole base N written in the name: '
           '<code>exp4(x)</code> is 4<sup>x</sup>, <code>exp10(x)</code> is 10<sup>x</sup>.',
           inputs=[('x', 'number, vector or matrix', '')], math=r'\text{exp}N(x) = N^{x}',
           syntax='exp4(3)   # 64\nexp10(2)  # 100', short='N<sup>x</sup> for any whole base N: exp4, exp10, ...'),
        fn('power(A, n)', 'Every element raised to the power n.',
           inputs=[('A', 'values', ''), ('n', 'powers (same size, or one number)', '')],
           more=['On a matrix, <code>A^n</code> is the <em>matrix</em> power (A times A ...); <code>power</code> '
                 'always works element by element.'],
           math=r'\text{power}(A, n)_{ij} = A_{ij}^{\,n}', syntax='power([1, 2; 3, 4], 2)   # 1 4; 9 16',
           short='every element to the power n'),
        fn('reciprocal(A)', '1 divided by every element.', inputs=[('A', 'values', '')],
           more=['On a matrix, <code>1/A</code> is the inverse matrix; <code>reciprocal</code> works element by '
                 'element.'],
           math=r'\text{reciprocal}(A)_{ij} = 1 / A_{ij}', syntax='reciprocal([1, 2; 4, 8])'),
        fn('log1p(x)', 'log(1 + x), exact even when x is tiny.', inputs=[('x', 'number, vector or matrix', '')],
           more=['For x = 1e-10, working out 1 + x first loses most of x\'s digits; <code>log1p</code> keeps them.'],
           math=r'\text{log1p}(x) = \ln(1 + x) \approx x - \tfrac{x^2}{2} \text{ for small } x',
           syntax='log1p(1e-10)'),
        fn('logaddexp(A, B)', 'log(e<sup>A</sup> + e<sup>B</sup>), worked out without overflow.',
           inputs=[('A, B', 'numbers, vectors or matrices of the same size', '')],
           more=['e<sup>1000</sup> is far beyond the largest number a computer stores, yet '
                 '<code>logaddexp(1000, 1000)</code> is simply 1000 + ln 2.'],
           math=r'\text{logaddexp}(a, b) = \ln(e^{a} + e^{b}) = \max(a,b) + \ln\!\left(1 + e^{-|a-b|}\right)',
           syntax='logaddexp(1000, 1000)   # 1000.693147'),
        fn('logaddexp2(A, B)', 'log<sub>2</sub>(2<sup>A</sup> + 2<sup>B</sup>), without overflow.',
           inputs=[('A, B', 'as <code>logaddexp</code>', '')],
           math=r'\text{logaddexp2}(a, b) = \log_2(2^{a} + 2^{b})', syntax='logaddexp2(3, 3)   # 4'),
        fn('logaddexpN(A, B)', 'log<sub>N</sub>(N<sup>A</sup> + N<sup>B</sup>) for any whole base N written in '
           'the name, such as <code>logaddexp4</code>.',
           inputs=[('A, B', 'as <code>logaddexp</code>', '')],
           math=r'\text{logaddexp}N(a, b) = \log_N(N^{a} + N^{b})', syntax='logaddexp4(0.5, 0.5)   # 1',
           short='log<sub>N</sub>(N<sup>A</sup> + N<sup>B</sup>) for any whole base N'),
    ]),
    'examples': {
        'basic': ex('Exponentials in several bases', 'e, 2, 4 and 10 as the base, and <code>exp(-inf)</code>.', '''
a = exp(1)
b = exp2([1, 2, 3])
c = exp4(ones([2, 2]) * 3)
d = exp10(2)
A = ones([3, 3]);
A[0, 0] = -inf;
e = exp(A)
'''),
        'mid': ex('Element by element or matrix', '<code>power</code> and <code>reciprocal</code> work on each '
                  'element; <code>^</code> and <code>1/</code> on a matrix are the matrix power and inverse.', '''
M = [1, 2; 3, 4];
p = power(M, 2)
mp = M ^ 2
r = reciprocal([1, 2; 4, 8])
'''),
        'strong': ex('Logarithms that stay accurate', 'For a tiny x, <code>log1p</code> keeps the digits that '
                     '<code>log(1 + x)</code> loses. For huge values, <code>logaddexp</code> gives the answer where '
                     'working out e<sup>1000</sup> would overflow. This is how probabilities are added in '
                     'log space.', '''
x = 1e-10;
publish("relative error of log(1 + x):", log(1 + x) / x - 1);
publish("relative error of log1p(x)  :", log1p(x) / x - 1, " (the true value is -x/2 = -5e-11)");
publish("exp(1000)  =", exp(1000));
publish("logaddexp(1000, 1000) =", logaddexp(1000, 1000));
publish("logaddexp2(3, 3)      =", logaddexp2(3, 3));
publish("logaddexp4(0.5, 0.5)  =", logaddexp4(0.5, 0.5));
p = log([0.2, 0.3]);
publish("log(0.2 + 0.3) =", log(0.5), "  logaddexp(log 0.2, log 0.3) =", logaddexp(p[0], p[1]));
'''),
    },
    'errors': [
        err('Too many values for exp', '<code>exp</code> takes one value. Multiply two exponentials, or add the '
            'exponents first.', 'r = exp(1, 2);', 'r = exp(1 + 2);\npublish(r);'),
    ],
}

# ================================================================== 4. Rounding, signs and limits
PAGES['rounding-signs-limits'] = {
    'title': 'Rounding, Signs & Limits',
    'summary': 'Round up, down, to the nearest or toward zero; take signs apart and put them back; and keep values '
               'inside a range.',
    'about': reference('Every function here works element by element on numbers, vectors and matrices.', [
        fn('ceil(x)', 'Rounds every element <em>up</em> to a whole number.', inputs=[('x', 'values', '')],
           math=r'\lceil x \rceil', syntax='ceil([1.2, -1.2])   # 2  -1',
           figure=fig(IMG + 'rounding-signs-limits-01.svg',
                      'Four step curves for x from -3 to 3: floor steps down, ceil steps up, fix steps toward zero, '
                      'and round jumps at each half.',
                      'The four ways to reach a whole number. <code>floor</code> always moves down, '
                      '<code>ceil</code> up, <code>fix</code>/<code>trunc</code> toward zero, and '
                      '<code>round</code> to the nearest.')),
        fn('floor(x)', 'Rounds every element <em>down</em> to a whole number.', inputs=[('x', 'values', '')],
           math=r'\lfloor x \rfloor', syntax='floor([1.2, -1.2])  # 1  -2'),
        fn('round(x, decimals=0)', 'Rounds to <code>decimals</code> places; a half goes away from zero '
           '(2.5 &rarr; 3, -2.5 &rarr; -3).',
           inputs=[('x', 'values', ''), ('decimals', 'places after the point (may be named)', '0')],
           more=['To send halves to the even neighbour, as some libraries do, use <code>rint</code>.'],
           syntax='round(3.14159, decimals=2)   # 3.14\nround([2.5, -2.5])           # 3  -3',
           short='the nearest, to a number of decimals; halves away from zero'),
        fn('rint(x)', 'The nearest whole number; a half goes to the <em>even</em> neighbour.',
           inputs=[('x', 'values', '')],
           more=['Halves sent to the even neighbour do not drift upward when many values are rounded and then '
                 'added up.'],
           syntax='rint([1.5, 2.5, 3.5])   # 2  2  4', short='the nearest whole number; halves to even'),
        fn('fix(x)', 'Rounds every element toward zero.', inputs=[('x', 'values', '')],
           syntax='fix([-2.7, 2.7])   # -2  2'),
        fn('trunc(x)', 'Drops the part after the point: the same as <code>fix</code>.', inputs=[('x', 'values', '')],
           syntax='trunc(-23.3)   # -23'),
        fn('fabs(x)', 'The absolute value of every element, always as a decimal number.',
           inputs=[('x', 'real values', '')], math=r'|x|', syntax='fabs([-1.5, 2.0, -3.8])'),
        fn('sign(x)', '-1, 0 or 1 for every element.', inputs=[('x', 'values', '')],
           math=r'\operatorname{sign}(x) = \begin{cases} -1 & x < 0 \\ 0 & x = 0 \\ 1 & x > 0 \end{cases}',
           syntax='sign([-10.5, 0, 4.2])   # -1  0  1'),
        fn('copysign(x, s)', 'The size of x with the sign of s, element by element.',
           inputs=[('x', 'the sizes', ''), ('s', 'the signs (same size, or one number)', '')],
           math=r'\text{copysign}(x, s) = |x| \cdot \operatorname{sign}(s)', syntax='copysign(5, -1)   # -5'),
        fn('signbit(x)', 'True where the sign bit is set: negative numbers, and also -0.0.',
           inputs=[('x', 'values', '')], syntax='signbit([1.5, -1.5, 0.0, -0.0])'),
        fn('heaviside(x, h0)', 'The unit step: 0 where x &lt; 0, 1 where x &gt; 0, and h0 where x is exactly 0.',
           inputs=[('x', 'values', ''), ('h0', 'the value used at 0 (may be named)', '')],
           math=r'H(x) = \begin{cases} 0 & x < 0 \\ h_0 & x = 0 \\ 1 & x > 0 \end{cases}',
           syntax='heaviside([-2, 0, 3], 0.5)   # 0  0.5  1'),
        fn('clip(A, lo, hi)', 'Every element limited to the range lo to hi.',
           inputs=[('A', 'values', ''), ('lo', 'lower limit (may be named)', ''), ('hi', 'upper limit (may be named)', '')],
           math=r'\text{clip}(a) = \min(\max(a, lo), hi)', syntax='clip([1, 5, 9], lo=2, hi=6)   # 2  5  6'),
    ]),
    'examples': {
        'basic': ex('Four ways to a whole number', 'The same values through <code>floor</code>, <code>ceil</code>, '
                    '<code>fix</code> and <code>round</code>.', '''
X = [1.2, -1.2, 2.5; -2.5, 3.0, 0.1];
f = floor(X)
c = ceil(X)
t = fix(X)
r = round(X)
'''),
        'mid': ex('Halves and decimals', '<code>round</code> sends halves away from zero, <code>rint</code> to the '
                  'even neighbour; <code>round</code> also takes a number of decimals.', '''
H = [-2.5, -1.5, 1.5, 2.5, 3.5];
r = round(H)
e = rint(H)
X = [1.234, 5.678; -1.234, -5.678];
r2 = round(X, 2)
r3 = round(3.21121, decimals=3)
'''),
        'strong': ex('Signs, steps and limits', 'A signal clipped to the range of a sensor, its sign, a step '
                     'function, and signs moved from one vector to another.', '''
v = [-7.5, -2, 0, 1.25, 4, 12];
publish("clipped to -5..5   :", clip(v, lo=-5, hi=5));
publish("sign               :", sign(v));
publish("step, H(0) = 0.5   :", heaviside(v, 0.5));
publish("size               :", fabs(v));
publish("sizes of v, signs of -v:", copysign(v, -v));
publish("sign bit of -0.0   :", signbit(-0.0), "  of 0.0:", signbit(0.0));
'''),
    },
}

# ================================================================== 5. Angles and complex parts
PAGES['angles-complex'] = {
    'title': 'Angles & Complex Parts',
    'summary': 'The angle of a point, the length of a hypotenuse, continuous phase, the sinc function, and the '
               'parts of complex numbers.',
    'about': reference('All of these work element by element. Angles are in radians unless a function says '
                       'otherwise; <code>rad2dec</code> turns radians into degrees.', [
        fn('inv_tan2(Y, X)', 'The angle of the point (X, Y), in radians, from -&pi; to &pi;. Note the order: '
           'Y first.',
           inputs=[('Y', 'the y values', ''), ('X', 'the x values (same size, or one number)', '')],
           more=['Unlike tan<sup>-1</sup>(Y/X), it knows which quarter the point is in: (1, 1) and (-1, -1) give '
                 'different angles.'],
           math=r'\theta = \operatorname{atan2}(y, x) \in (-\pi, \pi]',
           figure=fig(IMG + 'angles-complex-01.svg',
                      'Four points on a circle, one in each quarter, with their angles: (1, 1) at 45 degrees, '
                      '(-1, 1) at 135, (-1, -1) at -135 and (1, -1) at -45.',
                      'One point in each quarter and the angle <code>inv_tan2(Y, X)</code> gives it, shown in degrees.'),
           syntax='rad2dec(inv_tan2(1, 1))     # 45\nrad2dec(inv_tan2(-1, -1))   # -135',
           short='the angle of the point (X, Y), -&pi; to &pi;'),
        fn('hypot(A, B)', 'The hypotenuse for every pair of sides.',
           inputs=[('A, B', 'the two sides (same size, or one number)', '')],
           math=r'\text{hypot}(a, b) = \sqrt{a^2 + b^2}', syntax='hypot(4, 3)   # 5'),
        fn('anglewrap(theta, discont=pi)', 'Removes jumps bigger than <code>discont</code> between neighbouring '
           'angles by adding or taking away 2&pi;, so a phase becomes continuous.',
           inputs=[('theta', 'vector of angles in radians', ''),
                   ('discont', 'largest jump left alone (may be named)', '&pi;')],
           more=['Measured phases are usually wrapped into -&pi; to &pi;; <code>anglewrap</code> undoes the '
                 'wrapping so the phase can be differentiated or fitted.'],
           figure=fig(IMG + 'angles-complex-02.svg',
                      'A wrapped phase jumps from pi to minus pi like a saw tooth; the unwrapped phase is a smooth '
                      'rising line.',
                      'A phase that rises steadily, as it is measured (wrapped into -&pi; to &pi;) and after '
                      '<code>anglewrap</code>.'),
           syntax='anglewrap([0.0, 1.5, 3.14, -3.14, -1.5])', short='continuous phase: removes 2&pi; jumps'),
        fn('sinc(x)', 'The normalised sinc function, with sinc(0) = 1.', inputs=[('x', 'values', '')],
           math=r'\operatorname{sinc}(x) = \frac{\sin(\pi x)}{\pi x}, \qquad \operatorname{sinc}(0) = 1',
           syntax='sinc(0.5)   # 0.63662'),
        fn('angle(z, deg=false)', 'The angle of every complex element, in radians, or in degrees with '
           '<code>deg=true</code>.',
           inputs=[('z', 'number, vector or matrix', ''), ('deg', 'true for degrees; by name only', 'false')],
           math=r'\arg(a + bi) = \operatorname{atan2}(b, a)', syntax='angle([1, 1i, -1], deg=true)   # 0  90  180'),
        fn('conj(z)', 'The complex conjugate of every element.', inputs=[('z', 'real or complex values', '')],
           math=r'\overline{a + bi} = a - bi', syntax='conj(1 + 2i)   # 1-2i'),
        fn('real(z)', 'The real part of every element.', inputs=[('z', 'values', '')],
           math=r'\operatorname{Re}(a + bi) = a', syntax='real(3 - 4i)   # 3'),
        fn('img(z)', 'The imaginary part of every element (<code>imag(z)</code> is the same).',
           inputs=[('z', 'values', '')], math=r'\operatorname{Im}(a + bi) = b', syntax='img(3 - 4i)    # -4'),
    ]),
    'examples': {
        'basic': ex('Angles and hypotenuses', 'The angle of one point in each quarter, in degrees, and two '
                    'right triangles.', '''
Y = [1.0, 1.0, -1.0, -1.0];
X = [1.0, -1.0, -1.0, 1.0];
deg = rad2dec(inv_tan2(Y, X))
up = rad2dec(inv_tan2(1, 0))
h = hypot([3, 5], [4, 12])
'''),
        'mid': ex('Complex parts', 'Parts, conjugates and angles of a few complex numbers.', '''
Z = [1 + 2i, 3 - 4i, 5.0];
c = conj(Z)
re = real(Z)
im = img(Z)
r = angle([1 + 0i, 0 + 1i, -1 + 0i])
d = angle([1 + 0i, 0 + 1i, -1 + 0i], deg=true)
'''),
        'strong': ex('A phase that keeps turning', 'A phasor that turns 1.2 radians per step. Its measured angle '
                     'is wrapped into -&pi; to &pi;; <code>anglewrap</code> recovers the steady rise. Then the '
                     'sinc function, which describes the spectrum of a rectangular pulse.', '''
k = [0:7];
z = exp(1i * 1.2 * k);
wrapped = angle(z)
unwrapped = anglewrap(wrapped)
steps = unwrapped[1:7] - unwrapped[0:6]
s = sinc([-1.0, -0.5, 0.0, 0.25, 0.5, 1.0])
'''),
    },
    'errors': [
        err('deg that is not true or false', '<code>deg</code> is a switch.', 'd = angle(1i, deg=1);',
            'd = angle(1i, deg=true);\npublish(d);'),
    ],
}

# ================================================================== 6. Whole numbers and bits
PAGES['integers-bits'] = {
    'title': 'Whole Numbers & Bits',
    'summary': 'Greatest common divisors and least common multiples, division rounded down, and bit-by-bit '
               'operations on whole numbers.',
    'about': reference('These functions need whole numbers (true/false also works for the bitwise ones). They work '
                       'element by element; the second value can be one number for all elements.', [
        fn('gcd(A[, B])', 'The greatest common divisor of each pair; <code>gcd(A)</code> alone gives the divisor '
           'of all elements of A.',
           inputs=[('A', 'whole numbers', ''), ('B', 'whole numbers of the same size (may be named)', 'left out')],
           math=r'\gcd(12, 18) = 6', syntax='gcd(12, 18)          # 6\ngcd([12, 18, 24])    # 6'),
        fn('lcm(A[, B])', 'The least common multiple of each pair; <code>lcm(A)</code> alone gives the multiple '
           'of all elements of A.',
           inputs=[('A, B', 'as <code>gcd</code>', '')],
           math=r'\operatorname{lcm}(a, b) = \frac{|a\,b|}{\gcd(a, b)}', syntax='lcm([1:10])   # 2520'),
        fn('floor_divide(A, n)', 'A divided by n, rounded <em>down</em>: -7 / 2 gives -4.',
           inputs=[('A', 'values', ''), ('n', 'divisors (same size, or one number)', '')],
           more=['The <code>//</code> operator rounds toward zero instead: <code>-7 // 2</code> is -3.'],
           math=r'\text{floor\_divide}(a, n) = \lfloor a / n \rfloor', syntax='floor_divide([7, -7, 9], 2)   # 3  -4  4'),
        fn('bitwise_and(A, B)', 'Bit-by-bit AND: a bit is 1 where both bits are 1.',
           inputs=[('A, B', 'whole numbers (or true/false)', '')],
           figure=fig(IMG + 'integers-bits-01.svg',
                      'The bits of 12 (1100) and 6 (0110) lined up, with the results of AND (0100 = 4), '
                      'OR (1110 = 14) and XOR (1010 = 10).',
                      'The bits of 12 and 6 and what <code>bitwise_and</code>, <code>bitwise_or</code> and '
                      '<code>bitwise_xor</code> make of them.'),
           syntax='bitwise_and(12, 6)   # 4'),
        fn('bitwise_or(A, B)', 'Bit-by-bit OR: a bit is 1 where either bit is 1.',
           inputs=[('A, B', 'whole numbers', '')], syntax='bitwise_or(12, 6)    # 14'),
        fn('bitwise_xor(A, B)', 'Bit-by-bit exclusive OR: a bit is 1 where the two bits differ.',
           inputs=[('A, B', 'whole numbers', '')], syntax='bitwise_xor(12, 6)   # 10'),
        fn('left_shift(A, n)', 'Moves the bits n places left: A times 2<sup>n</sup>.',
           inputs=[('A', 'whole numbers', ''), ('n', 'how many places (63 at most)', '')],
           math=r'\text{left\_shift}(a, n) = a \cdot 2^{n}', syntax='left_shift([1, 3, 5], 2)   # 4  12  20'),
        fn('right_shift(A, n)', 'Moves the bits n places right: A divided by 2<sup>n</sup>, rounded down.',
           inputs=[('A', 'whole numbers', ''), ('n', 'how many places', '')],
           math=r'\text{right\_shift}(a, n) = \lfloor a / 2^{n} \rfloor', syntax='right_shift([16, 7, -7], 1)   # 8  3  -4'),
        fn('bitwise_count(A)', 'How many bits are 1 in |x|.', inputs=[('A', 'whole numbers', '')],
           syntax='bitwise_count([0, 7, 255])   # 0  3  8'),
        fn('invert(A)', 'True becomes false and false becomes true.', inputs=[('A', 'true/false values', '')],
           syntax='invert([true, false])   # false  true'),
    ]),
    'examples': {
        'basic': ex('Divisors and multiples', 'Pair by pair, and over a whole vector.', '''
X = [12, 24, 30; 12, 24, 30];
Y = [8, 16, 45; 8, 16, 45];
g = gcd(X, Y)
g1 = gcd([12, 18, 24])
l = lcm(X, Y)
l1 = lcm([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
'''),
        'mid': ex('Bits', 'AND, OR and XOR of 12 and 10 with 6, shifts, and counting the 1 bits.', '''
a = bitwise_and([12, 10], 6)
o = bitwise_or([12, 10], 6)
x = bitwise_xor([12, 10], 6)
l = left_shift([1, 3, 5], 2)
r = right_shift([16, 7, -7], 1)
n = bitwise_count([0, 7, 255])
'''),
        'strong': ex('Gear ratios and status flags', 'Two gears meet again after lcm of their tooth counts; '
                     'a ratio is reduced with gcd; and an 8-bit status word is tested, set and flipped with '
                     'bit operations.', '''
teeth = [24, 36];
publish("the same teeth meet again after", lcm(teeth[0], teeth[1]), "teeth");
g = gcd(teeth[0], teeth[1]);
publish("ratio", teeth[0] / g, ":", teeth[1] / g);

status = 37;
publish("status bits set:", bitwise_count(status));
publish("bit 2 on?", bitwise_and(status, left_shift(1, 2)) != 0);
status = bitwise_or(status, left_shift(1, 1));
publish("after setting bit 1:", status);
status = bitwise_xor(status, left_shift(1, 0));
publish("after flipping bit 0:", status);
publish("floor_divide(-7, 2) =", floor_divide(-7, 2), "   -7 // 2 =", -7 // 2);
'''),
    },
    'errors': [
        err('gcd of a decimal number', '<code>gcd</code> and <code>lcm</code> work on whole numbers only.',
            'g = gcd(2.5, 5);', 'g = gcd(25, 50);\npublish(g);'),
        err('Bits of a decimal number', 'Bitwise functions need whole numbers.', 'b = bitwise_and(2.5, 1);',
            'b = bitwise_and(round(2.5), 1);\npublish(b);'),
        err('A shift that is too far', 'A shift can move at most 63 places.', 'b = left_shift(1, 70);',
            'b = left_shift(1, 10);\npublish(b);'),
        err('An input name that does not exist', 'NC lists the inputs <code>gcd</code> has.',
            'g = gcd([12, 18], h=2);', 'g = gcd([12, 18], B=2);\npublish(g);'),
    ],
}

# ================================================================== 7. Floating-point precision
PAGES['floating-point'] = {
    'title': 'Floating-Point Precision',
    'summary': 'How finely a computer can tell numbers apart, how a number is stored as mantissa and exponent, and '
               'how NC shows full precision when it matters.',
    'about': reference('NC stores decimal numbers as 64-bit doubles: about 16 significant digits. The functions '
                       'below look at the gaps between them and at how they are built.', [
        fn('nextafter(x, y)', 'The next double after x, in the direction of y.',
           inputs=[('x', 'start values', ''), ('y', 'direction (same size, or one number)', '')],
           syntax='nextafter(1, 2)   # 1.0000000000000002\nnextafter(1, 0)   # 0.9999999999999999'),
        fn('spacing(x)', 'The gap from x to the next double up. At 1 it is the machine epsilon.',
           inputs=[('x', 'values', '')],
           more=['The gap grows with the size of x: the relative precision stays about the same.'],
           math=r'\text{spacing}(1) = \varepsilon = 2^{-52} \approx 2.22 \times 10^{-16}',
           figure=fig(IMG + 'floating-point-01.svg',
                      'A number line from 1 to 8 with marks for doubles: between each power of two the marks are '
                      'evenly spaced, and the gap doubles at every power of two.',
                      'Doubles are not evenly spread: the gap between neighbours doubles at every power of two. '
                      '(The marks are far apart here; the real gap at 1 is 2.2e-16.)'),
           syntax='spacing(1.0)      # 2.220446e-16\nspacing(1000.0)   # 1.136868e-13'),
        fn('[m, e] = frexp(x)', 'Splits x into a mantissa m and an exponent e with x = m &middot; 2<sup>e</sup> '
           'and 0.5 &le; |m| &lt; 1 (m = 0 and e = 0 for 0).',
           inputs=[('x', 'values', '')], math=r'x = m \cdot 2^{e}, \qquad 0.5 \le |m| < 1',
           syntax='[m, e] = frexp(8)   # 0.5  4', short='mantissa and exponent: x = m &middot; 2<sup>e</sup>'),
        fn('ldexp(m, e)', 'm &middot; 2<sup>e</sup>: the reverse of <code>frexp</code>.',
           inputs=[('m', 'mantissas', ''), ('e', 'whole-number exponents (same size, or one number)', '')],
           syntax='ldexp(0.5, 4)   # 8'),
        fn('[f, i] = modf(x)', 'The part after the point (f) and the whole part (i), both with the sign of x.',
           inputs=[('x', 'values', '')], syntax='[f, i] = modf(-2.718)   # -0.718  -2',
           short='fractional and whole parts'),
        fn('euler_gamma', 'The Euler&ndash;Mascheroni constant, 0.5772156649015329.',
           more=['A variable you name <code>euler_gamma</code> yourself is used instead of it (see '
                 '<a href="calling-built-ins.html">Calling Built-in Functions</a>).'],
           math=r'\gamma = \lim_{n\to\infty}\left(\sum_{k=1}^{n} \frac{1}{k} - \ln n\right) \approx 0.5772',
           syntax='g = euler_gamma', short='the Euler&ndash;Mascheroni constant &gamma;'),
    ], lead=[
        fn('How NC shows numbers', 'A single number is shown with as many digits as it needs to be told apart '
           'from its neighbours: <code>nextafter(1, 2)</code> prints as 1.0000000000000002, while 1/3 prints in '
           'the short form 0.333333.',
           more=['A matrix is shown in a short, lined-up form, which can hide a difference in the last digits. '
                 'To see it, look at one element, or subtract and look at the difference.'],
           syntax='E = nextafter(ones([2, 2]), 2)   # shows 1.0000 ...\nE[0, 0]                          # 1.0000000000000002'),
    ]),
    'examples': {
        'basic': ex('The gap after 1', 'The next double up and down from 1, and the size of the step.', '''
a = nextafter(1, 2)
b = nextafter(1, 0)
c = nextafter(1, 2) - 1
d = spacing(1.0)
s = spacing(1000.0)
'''),
        'mid': ex('Mantissa and exponent', 'Take numbers apart with <code>frexp</code>, put them back with '
                  '<code>ldexp</code>, and split off the fractional part with <code>modf</code>.', '''
X = [8.0, 3.0, 0.0];
[M, E] = frexp(X)
back = ldexp(M, E)
[F, I] = modf([3.14159, -2.718, 5.0])
'''),
        'strong': ex('What the display shows and hides', 'Short display for a matrix, full precision for one '
                     'element, and why 0.1 + 0.2 is not 0.3 for a computer, though a tolerance accepts it.', '''
E = nextafter(ones([2, 2]), 2)
e00 = E[0, 0]
k = 1.0000001
m = -0.99999999999
s = 0.1 + 0.2;
publish("0.1 + 0.2 == 0.3 ?", s == 0.3, "  difference:", s - 0.3);
publish("within 4 gaps of 0.3 ?", abs(s - 0.3) <= 4 * spacing(0.3), "  allclose:", allclose(s, 0.3, atol=1e-12));
g = euler_gamma
'''),
    },
}

# ================================================================== 8. Products
PAGES['products'] = {
    'title': 'Vector & Matrix Products',
    'summary': 'Dot, inner, outer, cross and Kronecker products, tensor contractions written with index letters, '
               'traces and diagonals.',
    'about': reference('Products that combine two vectors or matrices into a number, a vector or a bigger matrix.', [
        fn('dot(A, B[, axis])', 'The sum of conj(A) times B, element by element: one number. With '
           '<code>axis</code>, one dot product per column (0) or per row (1, also -1).',
           inputs=[('A, B', 'the same number of elements; a complex A is conjugated', ''),
                   ('axis', '0 = per column, 1 or -1 = per row; by name', 'all elements')],
           math=r'\text{dot}(a, b) = \sum_k \overline{a_k}\, b_k',
           syntax='dot([1, 2, 3], [4, 5, 6])    # 32\ndot(X, X, axis=0)            # one value per column',
           short='sum of conj(A)&middot;B; per column or row with axis'),
        fn('inner(A, B)', 'A number for two vectors; A&middot;B<sup>T</sup> for two matrices.',
           inputs=[('A, B', 'vectors of the same length, or matrices with equal column counts', '')],
           syntax='inner([1, 2, 3], [0, 1, 0])   # 2'),
        fn('outer(a, b)', 'The matrix of every product a(i)&middot;b(j).',
           inputs=[('a, b', 'vectors of any lengths', '')], math=r'\text{outer}(a, b)_{ij} = a_i\, b_j',
           syntax='outer([1, 2], [3, 4, 5])'),
        fn('cross(a, b[, axis])', 'The cross product of 3-element vectors; for matrices, row by row (axis 1) or '
           'column by column (axis 0).',
           inputs=[('a, b', '3-element vectors, or matrices of the same size', ''),
                   ('axis', '0 or 1; left out: rows when they hold 3 values', '')],
           more=['For two 2-element vectors it gives the single number a<sub>1</sub>b<sub>2</sub> &minus; '
                 'a<sub>2</sub>b<sub>1</sub>.'],
           math=r'a \times b = \begin{pmatrix} a_2 b_3 - a_3 b_2 \\ a_3 b_1 - a_1 b_3 \\ a_1 b_2 - a_2 b_1 \end{pmatrix}',
           figure=fig(IMG + 'products-01.svg',
                      'Two vectors a and b in a plane, and their cross product pointing straight out of the plane, '
                      'with length equal to the area of the parallelogram they span.',
                      'a &times; b is at right angles to both, by the right-hand rule; its length is the area of the '
                      'parallelogram a and b span.'),
           syntax='cross([1, 0, 0], [0, 1, 0])   # 0  0  1', short='the cross product, row by row or column by column'),
        fn('tensordot(A, B, axes=2)', '<code>axes=2</code>: the sum of A times B element by element; '
           '<code>axes=1</code>: the matrix product A&middot;B.',
           inputs=[('A, B', 'matrices', ''), ('axes', '1 or 2', '2')],
           syntax='tensordot(x1, x2, axes=1)   # x1 * x2'),
        fn('einsum(subscripts, A, B, ...)', 'Sums of products described by index letters: <code>"i,i->"</code> is '
           'the dot product, <code>"ij->ji"</code> the transpose, <code>"ij,jk->ik"</code> the matrix product.',
           inputs=[('subscripts', 'text with one letter group per value', ''),
                   ('A, B, ...', 'one value per letter group; in order only', '')],
           more=['A letter that appears in the inputs but not after <code>-&gt;</code> is summed over.'],
           math=r'\texttt{"ij,jk->ik"}:\quad C_{ik} = \sum_j A_{ij} B_{jk}',
           syntax='einsum("i,i->", [1, 2, 3], [4, 5, 6])   # 32\neinsum("ij->ji", [1, 2; 3, 4])',
           short='sums of products written with index letters'),
        fn('kron(A, B)', 'The Kronecker product: every element of A times all of B.',
           inputs=[('A, B', 'matrices of any sizes', '')],
           math=r'A \otimes B = \begin{pmatrix} a_{11} B & a_{12} B \\ a_{21} B & a_{22} B \end{pmatrix}',
           syntax='kron([1, 2; 3, 4], [0, 5; 6, 7])'),
        fn('trace(A)', 'The sum of the main diagonal.', inputs=[('A', 'matrix', '')],
           math=r'\operatorname{tr}(A) = \sum_i A_{ii}', syntax='trace([1, 2, 3; 4, 5, 6; 7, 8, 9])   # 15'),
        fn('diagonal(A, k=0)', 'The k-th diagonal of A: k &gt; 0 above the main one, k &lt; 0 below.',
           inputs=[('A', 'matrix', ''), ('k', 'which diagonal (may be named)', '0')],
           syntax='diagonal(A)        # 1  5  9\ndiagonal(A, k=1)   # 2  6'),
    ]),
    'examples': {
        'basic': ex('Dot, inner and outer', 'Three ways to multiply two vectors, and a complex dot product.', '''
d = dot([1, 2, 3], [4, 5, 6])
i = inner([1, 2, 3], [0, 1, 0])
o = outer([1, 2], [3, 4, 5])
z = dot([1 + 2i, 3 + 4i], [5 + 6i, 7 + 8i])
'''),
        'mid': ex('Per column and per row', '<code>axis</code> turns one dot product into one per column or row; '
                  '<code>cross</code> works row by row or column by column the same way.', '''
A = [1, 2, 3; 4, 5, 6];
B = [7, 8, 9; 1, 2, 3];
total = dot(A, B)
cols = dot(A, B, axis=0)
rows = dot(A, B, axis=1)
c = cross(A, B, axis=1)
c0 = cross([1, 2; 3, 4; 5, 6], [6, 5; 4, 3; 2, 1], axis=0)
'''),
        'strong': ex('Torque, index letters and block matrices', 'The torque of a force about a pivot, the same '
                     'matrix product written three ways, a Kronecker product, a trace and a diagonal.', '''
r = [0.5, 0, 0];
F = [0, 20, 0];
torque = cross(r, F)
x1 = [0, 1, 2; 3, 4, 5];
x2 = [0, 1; 2, 3; 4, 5];
mm = tensordot(x1, x2, axes=1)
mm2 = einsum("ij,jk->ik", x1, x2)
same = allclose(mm, x1 * x2)
s = tensordot(x1, x1)
k = kron([1, 2; 3, 4], [0, 5; 6, 7])
t = trace([1, 2, 3; 4, 5, 6; 7, 8, 9])
d1 = diagonal([1, 2, 3; 4, 5, 6; 7, 8, 9], k=-1)
'''),
    },
    'errors': [
        err('An axis that does not exist', '<code>dot</code> takes axis 0 or 1 (or -1, -2).',
            'A = [1, 2, 3; 4, 5, 6];\nd = dot(A, A, axis=2);', 'A = [1, 2, 3; 4, 5, 6];\nd = dot(A, A, axis=1);\npublish(d);'),
        err('Naming the values of einsum', '<code>einsum</code> takes its values in order.',
            'e = einsum("i,i->", [1, 2], operands=[3, 4]);', 'e = einsum("i,i->", [1, 2], [3, 4]);\npublish(e);'),
    ],
}

# ================================================================== 9. Norms and decompositions
PAGES['norms-decompositions'] = {
    'title': 'Norms & Decompositions',
    'summary': 'The size of a vector or matrix, how sensitive a matrix is, its determinant, eigenvalues and '
               'eigenvectors, and its SVD, QR and Cholesky factors.',
    'about': reference('Square matrices are needed for determinants and eigenvalues; norms, SVD and QR work on any '
                       'shape.', [
        fn('vector_norm(x, ord=2)', 'The length of x: <code>ord=2</code> Euclidean, <code>1</code> the sum of '
           '|x|, <code>inf</code> the largest |x|.',
           inputs=[('x', 'vector (or all elements of a matrix)', ''), ('ord', '1, 2 or inf (may be named)', '2')],
           more=['<code>norm(x)</code> is the same as <code>vector_norm(x)</code>.'],
           math=r'\|x\|_1 = \sum |x_i|, \quad \|x\|_2 = \sqrt{\sum x_i^2}, \quad \|x\|_\infty = \max |x_i|',
           syntax='vector_norm([3, -4])          # 5\nvector_norm([3, -4], ord=1)   # 7'),
        fn('matrix_norm(A[, ord])', 'The Frobenius norm by default, or <code>ord</code> = 1, 2, inf, "fro" or '
           '"nuc".', inputs=[('A', 'matrix', ''), ('ord', '1, 2, inf, "fro", "nuc"', '"fro"')],
           math=r'\|A\|_F = \sqrt{\sum_{i,j} A_{ij}^2}', syntax='matrix_norm([1, 2; 3, 4])   # 5.477226'),
        fn('cond(A, p=2)', 'The condition number: how much A can magnify a small error in the data.',
           inputs=[('A', 'matrix', ''), ('p', '2, 1, inf or "fro" (may be named)', '2')],
           more=['Near 1 is excellent; 10<sup>k</sup> means about k digits can be lost when solving with A.'],
           math=r'\kappa(A) = \|A\|\,\|A^{-1}\| = \sigma_{\max} / \sigma_{\min} \;(p = 2)',
           syntax='cond([1, 2; 3, 4])   # 14.933034'),
        fn('[sign, logdet] = slogdet(A)', 'The sign of det(A) and log|det(A)|, safe for determinants too big or '
           'too small to store.', inputs=[('A', 'square matrix', '')],
           math=r'\det A = \text{sign} \cdot e^{\text{logdet}}', syntax='[s, l] = slogdet([4, 1; 2, 3])   # 1  2.302585',
           short='sign and log of the determinant'),
        fn('[V, D] = eig(A)', 'The eigenvalues of A as a column; with two outputs, also the eigenvectors V and the '
           'diagonal D with A&middot;V = V&middot;D.', inputs=[('A', 'square matrix', '')],
           math=r'A\,v = \lambda\,v', syntax='eig([1, -2; 2, 1])   # 1+2i, 1-2i', short='eigenvalues and eigenvectors'),
        fn('eigvr(A) / eigvl(A)', 'Right eigenvectors (A&middot;v = &lambda;v) or left eigenvectors '
           '(w<sup>T</sup>A = &lambda;w<sup>T</sup>), as columns.', inputs=[('A', 'square matrix', '')],
           syntax='eigvr([1, 2, 0; 0, 3, 1; 0, 0, 4])'),
        fn('eig_ascend(A)', 'The eigenvalues of a symmetric matrix, smallest first.',
           inputs=[('A', 'real symmetric (or complex Hermitian) matrix', '')],
           syntax='eig_ascend([1, 2; 2, 1])   # -1  3'),
        fn('[U, S, V] = svd(A)', 'The singular value decomposition A = U&middot;S&middot;V&prime;: S is a diagonal '
           'matrix of the singular values; with one output, <code>svd</code> gives them as a column.', inputs=[('A', 'matrix of any shape', '')],
           more=['Geometrically, A turns the unit circle into an ellipse: S are the lengths of its half-axes, the '
                 'columns of U their directions, and the columns of V the directions that are sent there.'],
           math=r'A = U\,S\,V^{H}, \qquad A\,v_k = \sigma_k\, u_k', figure=fig(IMG + 'norms-decompositions-01.svg',
                      'Left: the unit circle with two right-angled directions v1 and v2. Right: the ellipse that the '
                      'matrix makes of it, with half-axes sigma1 u1 and sigma2 u2.',
                      'What the SVD says: A sends the directions v<sub>1</sub>, v<sub>2</sub> (columns of V) to '
                      '&sigma;<sub>1</sub>u<sub>1</sub>, &sigma;<sub>2</sub>u<sub>2</sub>, the half-axes of an '
                      'ellipse. Drawn for A = [2, 1; 1, 1.5].'),
           syntax="[U, S, V] = svd(A)    # A = U * S * V'\ns = svd(A)             # singular values only",
           short='singular value decomposition'),
        fn('svdvals(A)', 'The singular values only, largest first.', inputs=[('A', 'matrix', '')],
           syntax='svdvals([1, 0, -1; 0, 1, 0; 1, 1, 1])'),
        fn('[Q, R] = qr(A)', 'A = Q&middot;R with Q orthonormal and R upper triangular.',
           inputs=[('A', 'matrix', '')], math=r'A = QR, \qquad Q^{T} Q = I', syntax='[Q, R] = qr([1, 2; 3, 4])',
           short='QR decomposition'),
        fn('cholesky(A)', 'The lower-triangular L with A = L&middot;L<sup>T</sup>.',
           inputs=[('A', 'symmetric positive-definite matrix', '')], math=r'A = L L^{T}',
           syntax='cholesky([4, 12, -16; 12, 37, -43; -16, -43, 98])'),
    ]),
    'examples': {
        'basic': ex('Lengths and sizes', 'Vector norms in three flavours, two matrix norms and a condition number.', '''
a = vector_norm([40.0, 30.0])
b = vector_norm([3, -4], ord=1)
c = vector_norm([3, -4], ord=inf)
f = matrix_norm([1, 2; 3, 4])
g = matrix_norm([1, 2; 3, 4], ord=1)
k = cond([1, 2; 3, 4])
'''),
        'mid': ex('Eigenvalues', 'A rotation-like matrix has complex eigenvalues; a symmetric one real ones, '
                  'sorted by <code>eig_ascend</code>.', '''
A = [1, -2; 2, 1];
l = eig(A)
[V, D] = eig(A)
s = eig_ascend([1, 2; 2, 1])
[sg, ld] = slogdet([4, 1; 2, 3])
'''),
        'strong': ex('Three factorisations, checked', 'SVD, QR and Cholesky of small matrices, each multiplied back '
                     'together and compared with the original.', '''
A = [1, 0, -1; 0, 1, 0; 1, 1, 1];
[U, S, V] = svd(A)
publish("U S V' == A ?", allclose(U * S * V', A, atol=1e-12));
publish("singular values:", svdvals(A));
[Q, R] = qr([1, 2; 3, 4])
publish("Q R == A ?", allclose(Q * R, [1, 2; 3, 4], atol=1e-12));
K = [4, 12, -16; 12, 37, -43; -16, -43, 98];
L = cholesky(K)
publish("L L' == K ?", allclose(L * L', K, atol=1e-12));
'''),
    },
    'errors': [
        err('Cholesky of a matrix that is not positive definite', '<code>[1, 2; 2, 1]</code> has a negative '
            'eigenvalue, so no L exists.', 'L = cholesky([1, 2; 2, 1]);', 'L = cholesky([2, 1; 1, 2]);\npublish(L);'),
    ],
}

# ================================================================== 10. Solving linear systems
PAGES['solving-systems'] = {
    'title': 'Solving Linear Systems',
    'summary': 'Exact solutions of square systems, least-squares fits, pseudo-inverses, and the tensor versions '
               'for N-dimensional matrices.',
    'about': reference('All of these solve A&middot;x = b in some sense. Prefer <code>solve</code> to '
                       'multiplying by an inverse: it is faster and more accurate.', [
        fn('solve(A, b)', 'The x with A&middot;x = b.',
           inputs=[('A', 'square, invertible matrix', ''), ('b', 'a column, or a matrix of columns', '')],
           math=r'A\,x = b', syntax='solve([3, 1; 1, 2], [9; 8])   # 2; 3'),
        fn('pinv(A)', 'The Moore&ndash;Penrose pseudo-inverse; works for any shape.',
           inputs=[('A', 'matrix', '')], math=r'A^{+} = V\,\Sigma^{+} U^{H}', syntax='pinv([1, 2; 3, 4; 5, 6])'),
        fn('[x, residuals, rank, s] = lstsq(A, b[, rcond])', 'The least-squares x that makes |A&middot;x &minus; b| '
           'as small as possible, the sum of squared residuals, the rank of A and its singular values.',
           inputs=[('A', 'matrix', ''), ('b', 'column(s) with as many rows as A', ''),
                   ('rcond', 'singular values below rcond &times; the largest count as zero (may be named)',
                    'machine epsilon &times; max(rows, columns)')],
           more=['With more equations than unknowns (an over-determined system), <code>lstsq</code> finds the best '
                 'compromise: the straight line through scattered points, for example.'],
           math=r'x = \arg\min_x \|A x - b\|_2^2',
           figure=fig(IMG + 'solving-systems-01.svg',
                      'Four measured points and the straight line fitted to them by least squares, with the vertical '
                      'residuals drawn from each point to the line.',
                      'Fitting y = a&middot;t + c to four points: <code>lstsq</code> makes the sum of the squared '
                      'vertical distances as small as possible.'),
           syntax='[x, res, rk, s] = lstsq(Xa, Y)\nx = lstsq(M, y, rcond=1e-3)', short='least-squares solution'),
        fn('tensorinv(A, ind=2)', 'The inverse of an N-D matrix with respect to its first <code>ind</code> axes; '
           'the result has A\'s other axes first, then its first <code>ind</code> axes.',
           inputs=[('A', 'matrix or N-D matrix', ''), ('ind', 'how many leading axes (may be named)', '2')],
           more=['For an ordinary square matrix use <code>ind=1</code>: the result is the usual inverse.'],
           syntax='tensorinv([4, 7; 2, 6], ind=1)'),
        fn('tensorsolve(A, b[, axes])', 'The x with tensordot(A, x, x.ndim) = b; x takes A\'s last axes.',
           inputs=[('A', 'matrix or N-D matrix', ''), ('b', 'values shaped like A\'s first axes', ''),
                   ('axes', 'axes of A moved to the end first (may be named)', 'none')],
           syntax='tensorsolve([3, 1; 1, 2], [9, 8])   # 2  3'),
    ]),
    'examples': {
        'basic': ex('A square system', 'Solve a 2 x 2 system and check the answer.', '''
A = [3, 1; 1, 2];
b = [9; 8];
x = solve(A, b)
check = A * x
'''),
        'mid': ex('A straight line through four points', 'Four measurements, two unknowns: the slope and the '
                  'intercept. <code>lstsq</code> gives the best fit, the leftover error, the rank and the '
                  'singular values.', '''
Xa = [0, 1; 1, 1; 2, 1; 3, 1];
Y = [-1; 0.2; 0.9; 2.1];
[x, res, rk, s] = lstsq(Xa, Y)
publish("slope", x[0, 0], " intercept", x[1, 0]);
p = pinv([1, 2; 3, 4; 5, 6])
'''),
        'strong': ex('Nearly dependent columns and tensors', 'Two columns that differ by 1e-7 make the matrix '
                     'almost rank 1. <code>rcond</code> decides whether the tiny singular value counts. Then the '
                     'tensor inverse and solve of a 2 x 2 x 2 x 2 array.', '''
M = [1, 1; 1, 1.0000001; 1, 1];
y = [1; 2; 3];
[x, res, rk, s] = lstsq(M, y, rcond=1e-3)
T = reshape([2, 0, 0, 0, 0, 3, 0, 0, 0, 0, 4, 0, 0, 0, 0, 5], [2, 2, 2, 2]);
Ti = tensorinv(T);
sz = shape(Ti)
x2 = tensorsolve(T, [2, 3; 4, 5])
'''),
    },
    'errors': [
        err('A singular matrix', 'The second row is twice the first, so there is no unique x. NC suggests '
            '<code>lstsq</code>.', 'x = solve([1, 2; 2, 4], [1; 2]);',
            'x = lstsq([1, 2; 2, 4], [1; 2]);\npublish(x);'),
        err('tensorinv of a square matrix with the default ind', 'The default <code>ind=2</code> is for N-D '
            'matrices. For a 2-D matrix, use <code>ind=1</code>.', 'Ai = tensorinv([1, 2; 3, 4]);',
            'Ai = tensorinv([1, 2; 3, 4], ind=1);\npublish(Ai);'),
    ],
}

# ================================================================== 11. Polynomials
PDD = 'P = poly1d([2, 3, 1]);\n'

PAGES['polynomials'] = {
    'title': 'Polynomials',
    'summary': 'Polynomials as coefficient vectors or as <code>poly1d</code> values: evaluate, find roots, fit, add, '
               'multiply, divide, differentiate and convolve.',
    'about': reference('A polynomial is written as its coefficients, highest power first: <code>[2, 3, 1]</code> is '
                       '2x<sup>2</sup> + 3x + 1. Every function accepts either a coefficient vector or a '
                       '<code>poly1d</code>.', [
        fn('P = poly1d(c, r=false, variable="x")', 'A polynomial value. <code>P(x)</code> is its value at x, '
           '<code>P[k]</code> the coefficient of x<sup>k</sup>, and <code>P.coeffs</code>, <code>P.order</code>, '
           '<code>P.roots</code> its parts.',
           inputs=[('c', 'coefficients, highest power first (the roots when r=true)', ''),
                   ('r', 'true: c are the roots (may be named)', 'false'),
                   ('variable', 'the letter used to print it (may be named)', '"x"')],
           more=['<code>P(x)</code> takes one value in order: a number, a vector, a matrix or a complex number. '
                 'A poly1d can be passed to functions like any other value.'],
           math=r'P(x) = c_0 x^{n} + c_1 x^{n-1} + \dots + c_n',
           figure=fig(IMG + 'polynomials-01.svg',
                      'The parabola 2x squared plus 3x plus 1 crossing zero at x = -1 and x = -0.5, with its '
                      'derivative 4x + 3 drawn as a straight line that is zero at the lowest point.',
                      '<code>P = poly1d([2, 3, 1])</code>: its roots -1 and -0.5, and '
                      '<code>polyder(P)</code> = 4x + 3, which is zero where P is lowest.'),
           syntax='P = poly1d([2, 3, 1])     # 2x^2 + 3x + 1\nP(2)                      # 15\nP[2]                      # 2\nP.roots',
           short='a polynomial value: P(x), P[k], P.roots'),
        fn('polyval(p, x)', 'The polynomial p at every element of x.',
           inputs=[('p', 'coefficients (or a poly1d)', ''), ('x', 'values', '')],
           syntax='polyval([2, 3, 1], [0, 1, 2])   # 1  6  15'),
        fn('roots(p)', 'The roots of p as a column, complex where needed.',
           inputs=[('p', 'coefficients (or a poly1d)', '')], syntax='roots([1, -3, 2])   # 2; 1\nroots([1, 0, 1])    # i; -i'),
        fn('poly(r)', 'The polynomial with the roots r, or the characteristic polynomial of a square matrix.',
           inputs=[('r', 'vector of roots, or a square matrix', '')], math=r'\prod_k (x - r_k)',
           syntax='poly([1, 2])   # 1  -3  2'),
        fn('polyfit(x, y, deg)', 'The least-squares polynomial of degree <code>deg</code> through the points.',
           inputs=[('x, y', 'vectors of the same length', ''), ('deg', 'whole number', '')],
           syntax='polyfit([0, 1, 2, 3], [-1, 0.2, 0.9, 2.1], 1)'),
        fn('polyadd(p1, p2)', 'p1 + p2, lined up at the constant term.', inputs=[('p1, p2', 'coefficients', '')],
           syntax='polyadd([1, 2, 3], [4, 5])   # 1  6  8'),
        fn('polysub(p1, p2)', 'p1 &minus; p2.', inputs=[('p1, p2', 'coefficients', '')],
           syntax='polysub([1, 2, 3], [1, 1])   # 1  1  2'),
        fn('polymul(p1, p2)', 'p1 &middot; p2.', inputs=[('p1, p2', 'coefficients', '')],
           syntax='polymul([1, 2], [1, 3])   # 1  5  6'),
        fn('[q, r] = polydiv(p1, p2)', 'The quotient q and remainder r of p1 / p2.',
           inputs=[('p1, p2', 'coefficients (may be named)', '')], math=r'p_1 = q\,p_2 + r',
           syntax='[q, r] = polydiv([1, 3, 2], [1, 1])   # q = 1  2,  r = 0', short='quotient and remainder'),
        fn('polyder(p, m=1)', 'The m-th derivative of p.',
           inputs=[('p', 'coefficients (or a poly1d)', ''), ('m', 'how many times (may be named)', '1')],
           syntax='polyder([1, 3, 2])        # 2  3\npolyder([1, 3, 2], m=2)   # 2'),
        fn('convolve(a, v, mode="full")', 'The discrete convolution of two vectors (the same as multiplying them as '
           'polynomials when mode is "full").',
           inputs=[('a, v', 'vectors', ''), ('mode', '"full", "same" or "valid" (may be named)', '"full"')],
           math=r'(a * v)_n = \sum_k a_k\, v_{n-k}',
           syntax='convolve([1, 2, 3], [0, 1, 0.5])\nconvolve([1, 2, 3], [0, 1, 0.5], mode="same")'),
    ]),
    'examples': {
        'basic': ex('A polynomial value', 'Make 2x<sup>2</sup> + 3x + 1, evaluate it, and read its parts.', '''
P = poly1d([2, 3, 1])
v = P(2)
vs = P([0, 1, 2])
c = P[2]
o = P.order
r = P.roots
'''),
        'mid': ex('Building and taking apart', 'From roots to coefficients and back, arithmetic on coefficient '
                  'vectors, a division with no remainder, and two more ways to make a poly1d.', '''
p = poly([1, 2])
r = roots(p)
s = polyadd([1, 2, 3], [4, 5])
d = polysub([1, 2, 3], [1, 1])
m = polymul([1, 2], [1, 3])
[q, rem] = polydiv([1, 3, 2], [1, 1])
Q = poly1d([1, 2], r=true)
T = poly1d([1, 0, -1], variable="t")
'''),
        'strong': ex('Fit, differentiate, find the minimum', 'Fit a parabola to measurements, take its derivative, '
                     'and find where it is lowest; pass a poly1d to your own function; and smooth a signal with '
                     '<code>convolve</code>.', '''
x = [0, 1, 2, 3, 4];
y = [5.1, 2.0, 0.9, 2.1, 4.9];
c = polyfit(x, y, 2)
P = poly1d(c);
dP = polyder(P)
xmin = roots(dP)
publish("lowest value", P(xmin[0, 0]), "at x =", xmin[0, 0]);

function y = twice(F, x):
   y = 2 * F(x);
fnend
publish("twice(P, 3) =", twice(P, 3), "  P(1+2i) =", P(1 + 2i));
smooth = convolve([1, 4, 2, 8, 5], [1, 1, 1] / 3, mode="same")
'''),
    },
    'errors': [
        err('Two values for a polynomial', 'A poly1d takes one value: the x to evaluate at.', PDD + 'v = P(1, 2);',
            PDD + 'v = P([1, 2]);\npublish(v);'),
        err('A coefficient index that is not whole', '<code>P[k]</code> needs the power k as a whole number.',
            PDD + 'c = P[1.5];', PDD + 'c = P[1];\npublish(c);'),
        err('A polynomial of a polynomial', 'Composition is not supported yet: give numbers.', PDD + 'v = P(P);',
            PDD + 'v = P(P(2));\npublish(v);'),
    ],
}
