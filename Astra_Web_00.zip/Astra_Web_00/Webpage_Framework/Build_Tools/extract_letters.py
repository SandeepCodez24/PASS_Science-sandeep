#!/usr/bin/env python3
"""Read the NC editor's letter-input tables (Java, language/replace/*.java) and write
Build_Tools/lg_letters.json, which build_language_guide.py turns into the letter tables
on the Non-English Variables page.

In the NC editor, typing a command such as \\var(\\tamil(\\a)) is replaced by the letter அ.
The JSON is kept in this folder so the pages can be rebuilt without the Java sources.

    python Webpage_Framework/Build_Tools/extract_letters.py            # re-read the Java files
    set NC_REPLACE=C:\\path\\to\\language\\replace                       # if they are somewhere else
"""
import json
import os
import re
import sys
import unicodedata
from pathlib import Path

sys.dont_write_bytecode = True
TOOLS = Path(__file__).resolve().parent
REPLACE = Path(os.environ.get('NC_REPLACE', r'D:\My Research Works\PASS Science Works\Main_Repository'
                                           r'\Astra_UniPro_01\src\main\java\language\replace'))
OUT = TOOLS / 'lg_letters.json'

# language key, page label, Java file, font hint, native name
LANGUAGES = [
    ('greek', 'Greek', 'Greek.java', 'Ελληνικά'),
    ('tamil', 'Tamil', 'Tamil.java', 'தமிழ்'),
    ('sanskrit', 'Sanskrit', 'Sanskrit.java', 'संस्कृतम्'),
    ('malayalam', 'Malayalam', 'Malayalam.java', 'മലയാളം'),
    ('telugu', 'Telugu', 'Telugu.java', 'తెలుగు'),
]
VIRAMA = {'\u0BCD', '\u0D4D', '\u094D', '\u0C4D'}


def java_string(s):
    return s.replace('\\\\', '\\')


def read_entries(path):
    """[(section, command, letter)] in file order; commented-out lines are skipped."""
    entries, section = [], 'Letters'
    for line in path.read_text(encoding='utf-8').splitlines():
        code = line.strip()
        m = re.match(r'//\s*=+\s*([A-Z ]+?)\s*[(=]', code)
        if m:
            section = m.group(1).strip().title()
            continue
        if code.startswith('//'):
            continue
        m = re.match(r'(\w+)\.put\("((?:[^"\\]|\\.)*)",\s*"((?:[^"\\]|\\.)*)"\)', code)
        if m:
            sec = {'TAMIL_VOWEL_MAP': 'Vowels', 'MALAYALAM_VOWEL_MAP': 'Vowels', 'TELUGU_VOWEL_MAP': 'Vowels'}.get(
                m.group(1), 'Consonants' if 'CONSONANT' in m.group(1) else section)
            entries.append((sec, java_string(m.group(2)), m.group(3)))
            continue
        m = re.match(r'put\("([^"]*)",\s*"([^"]*)"\)', code)       # Sanskrit helper: put(token, letter)
        if m:
            entries.append((section, f'\\var(\\sanskrit(\\{m.group(1)}))', m.group(2)))
    return entries


def key_of(command):
    """'\\var(\\tamil(\\ka))' -> 'ka';  '\\var(\\alpha)' -> 'alpha'."""
    return re.search(r'\\(\w+)\)+$', command).group(1)


def classify(lang, entries):
    """Split a language into tile groups and (optionally) a syllable chart."""
    groups, chart_rows, chart_cols, cells, other = {}, [], [], {}, []
    if lang == 'greek':
        return {'groups': [{'name': 'Letters', 'items': [[key_of(c), g] for _, c, g in entries]}], 'chart': None}
    bases = {}
    for sec, cmd, glyph in entries:
        key = key_of(cmd)
        if sec in ('Vowels', 'Compound Letters', 'Special Symbols'):
            groups.setdefault(sec, []).append([key, glyph])
        elif len(glyph) == 1 and unicodedata.category(glyph) == 'Lo':
            bases[glyph] = key
            chart_rows.append([key, glyph])
            groups.setdefault('Consonants', []).append([key, glyph])
        elif len(glyph) == 2 and glyph[1] in VIRAMA:
            groups.setdefault('Pure consonants (with virama)', []).append([key, glyph])
        elif len(glyph) >= 2 and glyph[0] in bases and all(unicodedata.category(ch) in ('Mn', 'Mc') for ch in glyph[1:]):
            sign = glyph[1:]
            if sign not in chart_cols:
                chart_cols.append(sign)
            cells.setdefault(glyph[0], {})
            if sign in cells[glyph[0]]:
                other.append([key, glyph])
            else:
                cells[glyph[0]][sign] = [key, glyph]
        else:
            other.append([key, glyph])
    if other:
        groups.setdefault('Other signs and letters', []).extend(other)
    order = ['Vowels', 'Consonants', 'Pure consonants (with virama)', 'Compound Letters', 'Special Symbols',
             'Other signs and letters']
    chart = None
    if chart_cols:
        chart = {'cols': chart_cols,
                 'rows': [[k, g, [cells.get(g, {}).get(s) for s in chart_cols]] for k, g in chart_rows]}
    return {'groups': [{'name': n, 'items': groups[n]} for n in order if n in groups], 'chart': chart}


def main():
    data = []
    for lang, label, fname, native in LANGUAGES:
        entries = read_entries(REPLACE / fname)
        pattern = '\\var(\\KEY)' if lang == 'greek' else f'\\var(\\{lang}(\\KEY))'
        data.append({'lang': lang, 'label': label, 'native': native, 'pattern': pattern,
                     'count': len(entries), **classify(lang, entries)})
        print(f'{label:10} {len(entries):4} letters')
    OUT.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding='utf-8')
    print(f'wrote {OUT.name}')


if __name__ == '__main__':
    main()
