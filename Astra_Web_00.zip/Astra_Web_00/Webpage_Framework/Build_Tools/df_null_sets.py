"""Default Functions - Null Sets (source: Function_Test/Code/A_10_Nullset, nullset_tests.nc and
nullset_editor_tests.nc).

The rules for non-English variable names themselves are in the Language Guide (Getting Started,
Non-English Variables).
"""
from df_helpers import comp, err, ex, fig, fn, reference

IMG = 'Images/Neural_Code/Default_Functions/Null_Sets/'
LG = '../../Language_Guide/Getting_Started/non-english-variables.html'
PAGES = {}

PAGES['nullset-functions'] = {
    'title': 'Null Set Functions',
    'summary': 'One call makes a whole set of letters into variables with the value 0: the vowels of Tamil, '
               'Malayalam, Sanskrit or Telugu, or twelve Greek letters.',
    'about': reference('A null set is a ready-made group of single-letter variables, all starting at 0, so a formula '
                       'can use <code>α</code>, <code>β</code>, <code>γ</code> or <code>அ</code>, <code>ஆ</code> '
                       'without declaring each one. The letters follow the rules of '
                       '<a href="' + LG + '">Non-English Variables</a>.', [
        fn('nullset_tamizh()', 'Makes the 12 Tamil vowels variables and gives back their values as a 1 x 12 row.',
           syntax='t = nullset_tamizh();\nx = அ + ஆ;', short='the 12 Tamil vowels'),
        fn('nullset_malayalam()', 'Makes the 12 Malayalam vowels variables; gives back a 1 x 12 row.',
           syntax='m = nullset_malayalam();', short='the 12 Malayalam vowels'),
        fn('nullset_sanskrit()', 'Makes the 14 Sanskrit (Devanagari) vowels variables; gives back a 1 x 14 row.',
           syntax='s = nullset_sanskrit();', short='the 14 Sanskrit vowels'),
        fn('nullset_telugu()', 'Makes the 15 Telugu vowels variables, including <code>అం</code> and '
           '<code>అః</code>; gives back a 1 x 15 row.', syntax='u = nullset_telugu();\nఅం = 4;',
           short='the 15 Telugu vowels'),
        fn('nullset_greek()', 'Makes twelve Greek letters variables; gives back a 1 x 12 row. <code>π</code> and '
           '<code>σ</code> are not in the set: they are the constants pi and Stefan&ndash;Boltzmann, and stay so.',
           syntax='g = nullset_greek();\ny = α * x ^ 2 + β * x + γ;', short='twelve Greek letters'),
    ], lead=[
        comp('The five sets', ['Each function takes no inputs. The letters, in the order of the row it gives back:'],
             table=[['Function', 'Letters', 'Count'],
                    ['<code>nullset_tamizh()</code>', 'அ ஆ இ ஈ உ ஊ எ ஏ ஐ ஒ ஓ ஔ', '12'],
                    ['<code>nullset_malayalam()</code>', 'അ ആ ഇ ഈ ഉ ഊ എ ഏ ഐ ഒ ഓ ഔ', '12'],
                    ['<code>nullset_sanskrit()</code>', 'अ आ इ ई उ ऊ ऋ ॠ ऌ ॡ ए ऐ ओ औ', '14'],
                    ['<code>nullset_telugu()</code>', 'అ ఆ ఇ ఈ ఉ ఊ ఋ ఎ ఏ ఐ ఒ ఓ ఔ అం అః', '15'],
                    ['<code>nullset_greek()</code>', 'α β γ δ η θ λ μ ρ τ φ ω', '12']]),
        comp('The rules', [
            'A letter is set to 0 only if it does not exist yet: a letter that already has a value <em>keeps</em> '
            'it, so calling a set again never resets your work.',
            'The row that comes back shows every letter\'s current value at its place in the set. A letter that '
            'holds text shows the text; a letter that holds a matrix shows <code>nan</code>.',
            'The letters always go to the workspace, even when the call is inside a function, so a set can be '
            'prepared by a set-up function. Afterwards they are ordinary variables: assign them, use them, clear '
            'them.'],
            syntax='μ = 10;\ng = nullset_greek();   # μ stays 10; g[7] is 10, the rest 0'),
        comp('In the IDE', [
            'The editor knows the letters are defined as soon as a <code>nullset_*()</code> call appears, so it marks '
            'no "undefined name" on them, also when the call is inside a function.',
            'The Variable Explorer shows <strong>one row per set</strong> instead of one row per letter. Letters '
            'with a value come first, in set order, in teal; letters still 0 follow in crimson. Clicking the row opens '
            'a tab, <code>nullset_greek()</code>, listing each letter and its value; a value can be changed '
            'there by double-clicking it. Right-click the row to copy the names or clear every letter of the set; '
            '<code>clear</code> in the Command Window removes every set. A letter holding text also keeps a row of '
            'its own.',
            'In the suggestion box, letters with a value are offered first and letters still 0 last; typing '
            '<code>nullset</code> lists the five functions.'],
            figure=fig(IMG + 'nullset-functions-01.svg',
                       'A Variable Explorer row for the Greek set after theta was given the text angle and mu the '
                       'value 10: name column [θ, μ, α, …], value column [angle, 10, 0, …], size 1x12, type nullset. '
                       'θ and μ are teal, the letters still 0 crimson. Below it, the tab nullset_greek() lists each letter '
                       'and its value, with θ and μ first.',
                       'One Variable Explorer row for the whole Greek set, and the tab it opens.')),
    ]),
    'examples': {
        'basic': ex('Twelve Greek letters in one call', 'The row holds twelve zeros; the letters can be used at once.', '''
g = nullset_greek();
publish("values:", numel(g), " sum:", sum(g));
α = 2;
β = -3;
γ = 1;
x = [0, 0.5, 1, 2];
publish("α x² + β x + γ =", α * x ^. 2 + β * x + γ);
publish("δ is still", δ, "  π is still", round(π, decimals=5));
'''),
        'mid': ex('Values are kept, never reset', 'A letter set before the call keeps its value, and calling the set '
                  'again does not reset it. The row shows text as text and a matrix as nan.', '''
μ = 10;
g = nullset_greek();
publish("μ =", μ, "  the 8th value of the row:", g[7], "  sum:", sum(g));

அ = 5;
அ = அ * 2;
t = nullset_tamizh();
publish("அ =", அ, "  row:", t);

θ = "angle";
λ = [1, 2, 3];
g = nullset_greek();
publish(g);
'''),
        'strong': ex('Prepared by a set-up function', 'A function creates the Sanskrit and Telugu sets; the letters '
                     'still exist after it returns. The Telugu letters <code>అం</code> and <code>అః</code> are '
                     'variables like the others.', '''
function prepare():
   nullset_sanskrit();
   nullset_telugu();
fnend

prepare();
अ = 3;
ऋ = 4;
ఆ = 1;
అం = 4;
publish("अ² + ऋ² =", अ ^ 2 + ऋ ^ 2);
publish("ఆ + అం + అః =", ఆ + అం + అః);
s = nullset_sanskrit();
u = nullset_telugu();
publish("Sanskrit:", numel(s), "letters,", sum(s != 0), "with a value");
publish("Telugu:  ", numel(u), "letters,", sum(u != 0), "with a value");
'''),
    },
    'errors': [
        err('A letter used before its set', 'Without the call, <code>ω</code> is not a variable yet.', '''
y = ω + 1;''', '''
nullset_greek();
y = ω + 1;
publish(y);'''),
        err('A letter that is not in the set', '<code>ε</code> is not one of the twelve Greek letters, so the set '
            'does not create it. Give it a value yourself.', '''
nullset_greek();
publish(α + ε);''', '''
nullset_greek();
ε = 0;
publish(α + ε);'''),
        err('A value given to the call', 'The null set functions take no inputs.', '''
nullset_greek(1);''', '''
g = nullset_greek();
publish(numel(g));'''),
        err('nullset_tamil instead of nullset_tamizh', 'The Tamil set is named after the language\'s own name, '
            'Tamizh.', '''
nullset_tamil();''', '''
t = nullset_tamizh();
publish(numel(t));'''),
    ],
}
