#!/usr/bin/env python3
"""Site health check. Run after every change:  python Webpage_Framework/Build_Tools/check_site.py

1. Every relative link/src/action on every page points at a file that exists.
2. Every CSS file is structurally valid (no cut-off selector, unbalanced bracket or
   unclosed comment -- one such slip makes browsers drop every style after it).
3. Every class used in main.html has at least one CSS rule (flags forgotten styles).
"""
import re
import sys
from pathlib import Path

SITE = Path(__file__).resolve().parents[2]
SKIP = ('Webpage_Framework/Build_Tools', 'Icons/Brand/Source', 'Cloud_Storage/Documents/Sample_Data')  # tool files and sample data, not site pages
problems = 0

# 1. links
broken = {}
pages = 0
for page in SITE.rglob('*.html'):
    rel = page.relative_to(SITE)
    if rel.as_posix().startswith(SKIP):
        continue
    pages += 1
    for url in re.findall(r'\b(?:href|src|action)="([^"#?][^"]*)"', page.read_text(encoding='utf-8')):
        if re.match(r'[a-z][a-z0-9+.-]*:', url):
            continue
        path = url.split('#')[0].split('?')[0]
        if path and not (page.parent / path).exists():
            broken.setdefault(url, []).append(rel.as_posix())
print(f'Links: {pages} pages, {len(broken)} broken targets')
for url, where in sorted(broken.items())[:20]:
    print(f'  {url}  (in {len(where)} pages, e.g. {where[0]})')
problems += len(broken)

# 2. CSS structure
for css in SITE.rglob('*.css'):
    raw = css.read_text(encoding='utf-8')
    issues = []
    if raw.count('/*') != raw.count('*/'):
        issues.append('unclosed comment')
    text = re.sub(r'/\*.*?\*/', '', raw, flags=re.S)
    depth, buf, line = 0, '', 1
    for ch in text:
        if ch == '\n':
            line += 1
        if ch == '{':
            sel = buf.strip()
            if not sel or sel.count('(') != sel.count(')') or ';' in sel or '}' in sel:
                issues.append(f'line {line}: broken selector "{sel[-80:]}"')
            depth += 1
            buf = ''
        elif ch == '}':
            depth -= 1
            buf = ''
            if depth < 0:
                issues.append(f'line {line}: extra closing bracket')
                depth = 0
        elif ch == ';':  # ends a declaration, or an @import at the top level
            buf = ''
        else:
            buf += ch
    if depth:
        issues.append(f'{depth} unclosed bracket(s)')
    print(f'CSS {css.relative_to(SITE).as_posix()}: {"OK" if not issues else "; ".join(issues)}')
    problems += len(issues)

# 2b. every var(--name) used in any stylesheet is defined somewhere (an undefined one fails silently)
all_css = '\n'.join(re.sub(r'/\*.*?\*/', '', f.read_text(encoding='utf-8'), flags=re.S) for f in SITE.rglob('*.css'))
defined = set(re.findall(r'(--[\w-]+)\s*:', all_css))
undefined = sorted(set(re.findall(r'var\((--[\w-]+)', all_css)) - defined)
print('CSS variables used but never defined:', ', '.join(undefined) or 'none')
problems += len(undefined)

# 3. classes in main.html without CSS
css_text = re.sub(r'/\*.*?\*/', '', (SITE / 'Webpage_Framework' / 'Styles' / 'site.css').read_text(encoding='utf-8'), flags=re.S)
html = (SITE / 'main.html').read_text(encoding='utf-8')
used = {c for group in re.findall(r'class="([^"]+)"', html) for c in group.split()}
unstyled = sorted(c for c in used if not re.search(r'\.' + re.escape(c) + r'(?![\w-])', css_text))
print('Classes in main.html with no CSS rule:', ', '.join(unstyled) or 'none')

sys.exit(1 if problems else 0)
