#!/usr/bin/env python3
"""Build the placeholder ("Under development") pages and refresh the shared chrome.

1. Every page listed in Webpage_Framework/site-map.json is written as a placeholder
   page that uses the header and footer of main.html (the home page). Icons are found
   by name anywhere under Icons/. A placeholder is never written over a real page: any
   page containing site_chrome.BUILT_MARKER is left alone, so it can stay listed in the
   site map (for menus and related-page lists).
2. The search page is written (the target of the header search box).
3. Every other HTML page on the site gets the current header and footer from
   main.html, so a change to the ribbon bar or the useful-link bar reaches the whole site.

Run:  python Webpage_Framework/Build_Tools/build_pages.py
"""
import html
import json
import sys
sys.dont_write_bytecode = True  # keep Build_Tools free of __pycache__
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
from site_chrome import (BUILT_MARKER, FOOT_END, FOOT_START, FRAMEWORK, HEAD_END,  # noqa: E402
                         HEAD_START, SITE, localise, page, shared_parts)


SITE_MAP = FRAMEWORK / 'site-map.json'


def load_site_map():
    """Read Webpage_Framework/site-map.json: (sections by id, search page path)."""
    data = json.loads(SITE_MAP.read_text(encoding='utf-8'))
    return {sec['id']: sec for sec in data['sections']}, data['search']


SECTIONS, SEARCH = load_site_map()


ICONS = {f.stem: f.relative_to(SITE).as_posix() for f in (SITE / 'Icons').rglob('*.svg')
         if 'Brand' not in f.parts}


def icon(name, root):
    """An icon by name from Icons/<Group>/ (navy line icons; '-white' variants for dark backgrounds)."""
    assert name in ICONS, f'missing icon {name}.svg under Icons/'
    return f'<img src="{root}{ICONS[name]}" alt="">'


def root_of(path):
    """'../' once per folder between a site-relative page path and the site root."""
    return '../' * path.count('/')


def link_list(pages, root, current=None):
    rows = []
    for pg in pages:
        mark = ' aria-current="page"' if pg['path'] == current else ''
        rows.append(f'              <li><a href="{root}{pg["path"]}"{mark}>{html.escape(pg["title"])}</a></li>')
    return '\n'.join(rows)


def build_stub(sec, pg):
    path, title, text = pg['path'], pg['title'], pg['description']
    root = root_of(path)
    trail = ''.join(
        (f'<a href="{root}{href}">{html.escape(name)}</a>' if href else f'<span>{html.escape(name)}</span>') + '<span>/</span>'
        for name, href in sec['crumbs'] if href != path)

    lists = []
    child = SECTIONS.get(pg.get('children'))
    if child:
        lists.append(f'''          <div class="stub-related">
            <h2>In {html.escape(title)}</h2>
            <ul>
{link_list(child['pages'], root)}
            </ul>
          </div>''')
    lists.append(f'''          <div class="stub-related">
            <h2>More in {html.escape(sec['label'])}</h2>
            <ul>
{link_list(sec['pages'], root, current=path)}
            </ul>
          </div>''')
    related = '\n'.join(lists)

    body = f'''    <section class="stub">
      <div class="section-inner">
        <nav class="stub-crumbs" aria-label="Breadcrumb">
          <a href="{root}main.html">Home</a><span>/</span>{trail}<span aria-current="page">{html.escape(title)}</span>
        </nav>
        <div class="stub-card">
          <div class="stub-icon">{icon(pg['icon'], root)}</div>
          <div>
            <p class="stub-kicker">{html.escape(sec['label'].upper())}</p>
            <h1>{html.escape(title)}</h1>
            <p class="stub-lead">{html.escape(text)}</p>
            <p class="stub-badge"><i aria-hidden="true"></i>Under Development</p>
            <p class="stub-text">This page is being built as part of the new neuralcolindes.com. Check back soon.</p>
            <div class="stub-actions">
              <a class="btn btn-accent" href="{root}main.html">Back to home</a>
              <a class="btn btn-ghost" href="{root}Webpage_Framework/Pages/Company/contact.html">Contact us</a>
            </div>
          </div>
{related}
        </div>
      </div>
    </section>'''
    target = SITE / path
    if target.exists() and BUILT_MARKER in target.read_text(encoding='utf-8'):
        return False  # a real page now lives here (e.g. built by build_language_guide.py)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(page(root, title, text, body), encoding='utf-8')
    return True


def build_search():
    root = root_of(SEARCH)
    body = f'''    <section class="stub">
      <div class="section-inner">
        <nav class="stub-crumbs" aria-label="Breadcrumb">
          <a href="{root}main.html">Home</a><span>/</span><span aria-current="page">Search</span>
        </nav>
        <div class="stub-card">
          <div class="stub-icon">{icon('search', root)}</div>
          <div>
            <p class="stub-kicker">SEARCH</p>
            <h1>Search neuralcolindes.com</h1>
            <form class="search-field stub-search" action="{root}{SEARCH}" method="get" role="search">
              <label class="sr-only" for="page-search">Search neuralcolindes.com</label>
              <input id="page-search" name="q" type="search" placeholder="Search neuralcolindes.com" data-search-input>
              <button type="submit" aria-label="Submit search">{icon('search-white', root)}</button>
            </form>
            <p class="stub-badge"><i aria-hidden="true"></i>Under Development</p>
            <p class="stub-text" data-search-echo>Site search is under development.</p>
            <div class="stub-actions">
              <a class="btn btn-accent" href="{root}main.html">Back to home</a>
              <a class="btn btn-ghost" href="{root}Neural_Code/language-guide.html">Browse the Language Guide</a>
            </div>
          </div>
        </div>
      </div>
    </section>'''
    (SITE / SEARCH).write_text(
        page(root, 'Search', 'Search neuralcolindes.com.', body), encoding='utf-8')


def sync_chrome():
    """Copy the current header and footer from main.html into every other page."""
    header, footer = shared_parts()
    count = 0
    for page in SITE.rglob('*.html'):
        rel = page.relative_to(SITE)
        if rel.as_posix().startswith(('Webpage_Framework/Build_Tools', 'Icons/Brand/Source', 'Cloud_Storage/Documents/Sample_Data')) or rel == Path('main.html'):
            continue
        text = page.read_text(encoding='utf-8')
        if HEAD_START not in text or FOOT_START not in text:
            continue
        root = '../' * (len(rel.parts) - 1)
        a, b = text.index(HEAD_START), text.index(HEAD_END) + len(HEAD_END)
        text = text[:a] + localise(header, root) + text[b:]
        a, b = text.index(FOOT_START), text.index(FOOT_END) + len(FOOT_END)
        text = text[:a] + localise(footer, root) + text[b:]
        page.write_text(text, encoding='utf-8')
        count += 1
    return count


def main():
    made = 0
    for sec in SECTIONS.values():
        for pg in sec['pages']:
            made += build_stub(sec, pg)
    build_search()
    synced = sync_chrome()
    print(f'Built {made} placeholder pages and the search page; refreshed header/footer on {synced} pages.')


if __name__ == '__main__':
    main()
