"""Content of the Language Guide (Neural_Code/Language_Guide/).

Sources: Horizon_Test (A_01-A_08), Function_Test/Code/A_02_Function_Syntax_tests,
Function_Test/Code/A_05_Traditioal (non-English names, subscripts and superscripts),
the NC editor's letter tables (Astra_UniPro_01 .../language/replace/*.java, via
extract_letters.py) and the old Language Guide (matrices, complex numbers; since removed) and
Function_Test/Code/A_12_Lists_and_Dictionary (lists, ranges, dictionaries, N-dimensional arrays).
Every example is run through nc.exe by build_language_guide.py; the output shown
on the page is what nc printed.

Text fields may contain simple HTML (<code>, <strong>, <a>). `math` is LaTeX shown
as a display formula. `syntax` is shown as code but never run. A component with
`letters=True` also shows the letter finder built from lg_letters.json.

Each page has up to three tabs: About, Examples and (optional) Syntax Error. `errors` is a
list of err(...) cards; the wrong code and the corrected code are both run through nc.exe,
so the message and the output on the page are exactly what NC prints.
"""

SECTIONS = [
    ('getting-started', 'Getting Started', ['variable-types', 'variable-declaration', 'non-english-variables',
                                            'subscripts-superscripts', 'nc-primitives']),
    ('basics', 'Basics', ['arithmetic', 'lists', 'matrices', 'growing-matrices', 'n-dimensional-arrays', 'dictionaries',
                          'complex-numbers', 'loops', 'conditional-operators', 'binary-operators',
                          'logical-operators']),
    ('functions', 'Functions', ['customize-functions', 'defaults-named-inputs', 'overloads', 'line-continuation']),
    ('classes', 'Classes', ['default-class', 'constructors-methods', 'inherited-class', 'info-and-base']),
    ('errors-exceptions', 'Errors & Exceptions', ['try-except', 'success-always', 'escalate-because',
                                                 'assert-contracts', 'error-types']),
    ('signals', 'Signals', ['reading-signal', 'setup-signal']),
]


def comp(name, text, math=None, syntax=None, table=None, letters=False, figure=None):
    return {'name': name, 'text': text if isinstance(text, list) else [text],
            'math': math, 'syntax': syntax, 'table': table, 'letters': letters, 'figure': figure}


def fig(src, alt, caption):
    """A diagram for an About component. `src` is relative to the site root:
    Images/Neural_Code/Language_Guide/<Section_Folder>/<page>-NN.svg."""
    return {'src': src, 'alt': alt, 'caption': caption}


def ex(title, text, code):
    return {'title': title, 'text': text, 'code': code.strip('\n')}


def err(title, text, wrong, fix, fix_text=''):
    """A Syntax Error card: what goes wrong, the wrong code, and the corrected code."""
    return {'title': title, 'text': text, 'wrong': wrong.strip('\n'), 'fix': fix.strip('\n'), 'fix_text': fix_text}


PAGES = {}

# ============================================================== GETTING STARTED
PAGES['variable-types'] = {
    'title': 'Variable Types',
    'summary': 'Every value in NC has a type: a number, text, a true/false value, a complex number or a matrix. '
               'NC works the type out for you.',
    'about': [
        comp('Numbers', [
            'Whole numbers and decimals are the same type in NC: a 64-bit floating-point number, '
            '<code>float64</code>. You never declare it; writing the number is enough.',
            'Very large or very small values can be written in scientific notation, such as <code>1.5e3</code>.'],
            math=r'1.5\text{e}3 = 1.5 \times 10^{3} = 1500',
            syntax='A = 7;\nB = 2.5;\nC = 1.5e3;'),
        comp('Text', [
            'Text (a string) is written between double quotes. Its type is <code>text</code>.',
            'Join two pieces of text with <code>+</code>.'],
            syntax='name = "pump";\nlabel = "Neural" + " " + "Colindes";'),
        comp('True and false', [
            'A true/false value has the type <code>bool</code>. Write it as <code>true</code> or <code>false</code>, '
            'or get it from a comparison such as <code>A &gt; B</code>.'],
            syntax='ready = true;\nis_big = A > 100;'),
        comp('Complex numbers and matrices', [
            'A number with an imaginary part, such as <code>3 + 4i</code>, has the type <code>complex128</code>. '
            'A grid of numbers written in square brackets is a matrix. Both have their own pages: '
            '<a href="../Basics/complex-numbers.html">Complex Numbers</a> and <a href="../Basics/matrices.html">Matrices</a>.'],
            syntax='z = 3 + 4i;\nM = [1, 2; 3, 4];'),
        comp('Mixing number types', [
            'Plain numbers are <code>float64</code>. Data read from files, or made with <code>int8(x)</code>, '
            '<code>uint8(x)</code>, <code>float32(x)</code> and so on, keeps its own sized type, and NC applies the '
            'same rules to a single value and to every element of an array:'],
            table=[['Combination', 'Result'],
                   ['two values of the same sized type: <code>uint8 + uint8</code>', 'the same type; going outside its range is an error, never a silent wrap-around'],
                   ['two different whole-number types: <code>uint8 + int16</code>', 'an error: convert one side first'],
                   ['a sized type with a plain number: <code>int8(3) + 2.5</code>', '<code>float64</code> (5.5)'],
                   ['<code>float32</code> with a plain number', '<code>float32</code>'],
                   ['true/false with numbers: <code>int32(4) + true</code>', '<code>float64</code> (5)'],
                   ['a complex number with a real one: <code>(1 + 2i) + 3</code>', 'complex (4+2i)']],
            syntax='int8(3) + 2.5          # 5.5\nuint8(200) + uint8(50) # 250, still uint8\nint16(x) + int16(y)    # convert first when the types differ'),
        comp('true and false in arithmetic', [
            'In arithmetic, <code>true</code> counts as 1 and <code>false</code> as 0, as in C, NumPy and MATLAB. '
            'This makes counting easy: <code>sum(v &gt; 3)</code> is the number of elements above 3, and a '
            'true/false matrix multiplied element by element keeps only the chosen values.'],
            syntax='true + true                # 2\nsum([1, 5, 7, 2] > 3)     # 2\n[1, 2; 3, 4] *. [true, false; false, true]   # 1 0; 0 4'),
        comp('Text with text, text with numbers', [
            'Text never stands in for a number. Between two texts, <code>+</code> joins them and the comparisons '
            'use dictionary order; every other operator is an error. A text is never equal to a number, and text '
            'cannot be ordered against a number. To mix them, convert first: <code>str(x)</code> to join, '
            '<code>float(s)</code> to calculate.'],
            table=[['Expression', 'Result'],
                   ['<code>"5" + "1"</code>', '<code>"51"</code> (joined)'],
                   ['<code>"apple" &lt; "banana"</code>', '<code>true</code> (dictionary order)'],
                   ['<code>"5" == 5</code>', '<code>false</code> (text is never a number)'],
                   ['<code>"5" + 1</code>, <code>1 + "5"</code>, <code>"5" * 2</code>', 'error: convert first'],
                   ['<code>"a" - "b"</code>, <code>-"5"</code>, <code>"5"!</code>', 'error: only <code>+</code> works on text'],
                   ['<code>"5" &lt; 5</code>', 'error: text and numbers cannot be ordered'],
                   ['<code>"5" + str(1)</code>', '<code>"51"</code>'],
                   ['<code>float("5") + 1</code>', '<code>6</code>']]),
        comp('Checking a type', [
            '<code>type(x)</code> gives the type of any value as text. Besides <code>float64</code>, NC has sized '
            'number types (<code>int8</code> &hellip; <code>uint64</code>, <code>float8</code> &hellip; <code>float32</code>), '
            'and <code>timestamp</code> and <code>duration</code> for dates and times; see '
            '<a href="../../Default_Functions/Arrays_Data/inspecting-types.html">Inspecting Types</a>.'],
            syntax='type(x)'),
        comp('Converting between types', [
            '<code>int(x)</code> drops the fractional part, moving toward zero, so <code>int(-7.9)</code> is <code>-7</code>. '
            '<code>float(x)</code> gives a decimal number, <code>str(x)</code> gives text, and <code>bool(x)</code> '
            'gives <code>false</code> for zero and <code>true</code> for anything else. '
            '<code>int</code> and <code>float</code> also read numbers written as text.'],
            math=r'\operatorname{int}(x) = \operatorname{sign}(x)\,\big\lfloor |x| \big\rfloor',
            syntax='int(x)\nfloat(x)\nstr(x)\nbool(x)'),
    ],
    'examples': {
        'basic': ex('The four everyday types', 'Store one value of each type and ask NC what it is.', '''
A = 7;
B = 2.5;
name = "pump";
ready = true;
publish(type(A), type(B), type(name), type(ready));
'''),
        'mid': ex('Converting values', 'Read a number that arrived as text, then turn it back into text for a label.', '''
level_text = "42.75";
level = float(level_text);
publish(level + 1);
publish(int(level), int(-7.9));
publish("Level: " + str(level));
publish(bool(0), bool(1));
'''),
        'strong': ex('One result, every type', 'Work out a value, then view it as each type. '
                     'The last line checks that the conversions agree.', '''
A = 1.1; B = 1.2; C = 1.3; D = 1.45;
R = (A + B) ^ (C + D);
publish("value  :", R);
publish("type   :", type(R));
publish("int    :", int(R));
publish("float  :", float(R));
publish("text   :", str(R) + " units");
publish("checks :", int(R) == 9, float(int(R)) == 9.0);
'''),
    },
    'errors': [
        err('Reading a number from text that is not a number', '<code>int</code> and <code>float</code> read '
            'numbers written as text, but stop with an error when the text is not a number.', '''
level = int("abc");
''', '''
level = int("42");
publish(level + 1);
'''),
        err('Adding text and a number', 'When the left value is text, <code>+</code> joins text, so a number on '
            'the right is an error. The message offers both fixes.', '''
x = "5" + 2;
''', '''
joined = "5" + str(2);
added = float("5") + 2;
publish(joined, added);
'''),
        err('A number plus text', 'When the left value is a number, <code>+</code> adds numbers, so the text must be '
            'converted first.', 'x = 1 + "5";', 'x = 1 + float("5");\npublish(x);'),
        err('Multiplying text', 'Only <code>+</code> works on text. Convert the text to a number to multiply it.',
            'x = "5" * 2;', 'x = float("5") * 2;\npublish(x);'),
        err('Subtracting text', '<code>-</code> is not defined for text; only <code>+</code> joins two texts.',
            'x = "ab" - "b";', 'x = "a" + "b";\npublish(x);'),
        err('Negating text', 'Convert the text to a number first.', 'x = -"5";', 'x = -float("5");\npublish(x);'),
        err('The factorial of text', '<code>!</code> needs a number.', 'x = "5"!;', 'x = float("5")!;\npublish(x);'),
        err('Ordering text against a number', 'Text and numbers cannot be compared with <code>&lt;</code> or '
            '<code>&gt;</code>. (<code>==</code> works, and is always false.)', 'x = "5" < 5;',
            'x = float("5") < 5;\npublish(x, "5" == 5);'),
        err('A matrix plus text', 'The same rule as for a single number.', 'x = [1, 2] + "5";',
            'x = [1, 2] + float("5");\npublish(x);'),
        err('A fraction written as text', '<code>dec2frac</code> gives text such as "1/2"; turn it back into a number '
            'before calculating.', 'x = dec2frac(0.5) + 1;', 'x = frac2deci(dec2frac(0.5)) + 1;\npublish(x);'),
        err('Two different whole-number types', 'NC does not guess which type you want. Convert one side.',
            'x = uint8(3) + int16(4);', 'x = int16(uint8(3)) + int16(4);\npublish(x, type(x));'),
        err('Going past the range of a type', 'A uint8 holds 0 to 255. NC stops instead of wrapping around to a '
            'wrong value; convert to a wider type first.', 'x = uint8(200) + uint8(100);',
            'x = int16(uint8(200)) + int16(100);\npublish(x, type(x));'),
    ],
}

PAGES['variable-declaration'] = {
    'title': 'Variable Declaration',
    'summary': 'Create a variable by giving it a name and a value with <code>=</code>. NC has no separate declaration step.',
    'about': [
        comp('Assigning a value', [
            'Write the name, an equals sign and a value. NC works out the right-hand side first, then stores '
            'the result under the name. Assigning again replaces the old value.'],
            syntax='name = expression;'),
        comp('Semicolons and echo', [
            'A statement that ends with <code>;</code> runs quietly. Leave the semicolon off and NC '
            'echoes the variable: its name, then its value on the next line.'],
            syntax='x = 5;     # quiet\nx = 5      # shows  x =  5'),
        comp('Several statements on one line', [
            'Separate statements with semicolons to keep short, related assignments together.'],
            syntax='A = 1; B = 2; C = 3;'),
        comp('Naming rules', [
            'A name starts with a letter or an underscore and continues with letters, digits or underscores. '
            'Names are case-sensitive: <code>Speed</code> and <code>speed</code> are two variables.',
            'A name can also be a single Greek, Tamil, Sanskrit, Malayalam or Telugu letter, such as '
            '<code>μ</code>, <code>க</code> or <code>अ</code>: see '
            '<a href="non-english-variables.html">Non-English Variables</a>. A name can also carry a subscript and '
            'a superscript: see <a href="subscripts-superscripts.html">Variables with Subscripts and Superscripts</a>. '
            'A name cannot start with a digit.'],
            table=[('Name', 'Allowed?'), ('<code>total</code>, <code>_tmp</code>, <code>v2</code>', 'Yes'),
                   ('<code>μ</code>, <code>க</code>, <code>अ</code>', 'Yes: one non-English letter'),
                   ('<code>வேகம்</code>, <code>गति</code>', 'No: a non-English name is one letter'),
                   ('<code>V_$in</code>, <code>X_$a_@b</code>', 'Yes'),
                   ('<code>2a</code>', 'No: starts with a digit')]),
        comp('Comments', [
            'Everything after <code>#</code> on a line is a comment and is ignored.'],
            syntax='g = 9.81;   # gravity in m/s^2'),
        comp('Continuing a long line', [
            'End a line with <code>~~</code> to continue the same statement on the next line.'],
            syntax='total = first_value + ~~\n        second_value;'),
        comp('Showing values', [
            '<code>publish(a, b, ...)</code> prints its values on one line, separated by spaces.'],
            syntax='publish("label:", value);'),
    ],
    'examples': {
        'basic': ex('Assign and use', 'Three assignments on one line, then a calculation that uses them.', '''
A = 1; B = 2; C = 3;
total = A + B + C;
publish("total =", total);
'''),
        'mid': ex('Echo, reassigning and case', 'The first two lines have no semicolon, so NC echoes them. '
                  '<code>Speed</code> and <code>speed</code> are separate variables.', '''
speed = 12
speed = speed * 2
Speed = 5;
publish(speed, Speed);
'''),
        'strong': ex('Readable engineering names', 'A Greek letter for the friction coefficient, a Tamil label as '
                     'text, comments and a statement continued over two lines.', '''
# Friction force on a car
μ = 0.35;           # friction coefficient
mass_kg = 1200;
g = 9.81;           # m/s^2
v = 12;             # speed in m/s
label = "வேகம்";     # "speed" in Tamil
friction = μ * ~~
           mass_kg * g;
publish("friction force (N):", friction);
publish(label, "(m/s):", v);
'''),
    },
    'errors': [
        err('A name that starts with a digit', 'NC reads <code>2</code> as a number and then finds a name right after it.', '''
2a = 5;
''', '''
a2 = 5;
publish(a2);
''', 'Start the name with a letter or an underscore. Digits are fine after the first character.'),
        err('A missing value', 'Every <code>=</code> needs a value on its right-hand side.', '''
x = ;
''', '''
x = 0;
publish(x);
'''),
        err('Two statements without a semicolon', 'Statements that share a line must be separated by <code>;</code>.', '''
x = 5 y = 6;
''', '''
x = 5; y = 6;
publish(x, y);
'''),
        err('Using a name before it has a value', 'This error happens while the script runs: NC stops at the line '
            'that reads a variable that was never assigned. Names are case-sensitive, so <code>Speed</code> '
            'is not <code>speed</code>.', '''
speed = 12;
publish(Speed);
''', '''
speed = 12;
publish(speed);
'''),
    ],
}

PAGES['non-english-variables'] = {
    'title': 'Non-English Variables',
    'summary': 'Name a variable with a single Greek, Tamil, Sanskrit, Malayalam or Telugu letter, such as '
               '<code>α</code> or <code>க</code>. NC is Unicode (UTF-8) throughout, so text values can be '
               'written in any language: <code>A = "சக்தி";</code>',
    'about': [
        comp('One letter per name', [
            'A non-English variable name is <strong>one letter</strong>: a Greek letter, or one letter of Tamil, '
            'Sanskrit, Malayalam or Telugu. In these scripts one letter can be a vowel (<code>அ</code>), a '
            'consonant (<code>க</code>), a consonant with its vowel sign (<code>கி</code>) or a pure consonant '
            '(<code>ள்</code>): every tile in the letter finder below is one letter.',
            'Words are not names. To keep a word in another language, store it as a text value instead.',
            'The single letter can carry a subscript and a superscript, which is how you name related values: '
            '<code>α_$1</code>, <code>அ_$க_@உ</code> (see '
            '<a href="subscripts-superscripts.html">Variables with Subscripts and Superscripts</a>).'],
            table=[('Name', 'Allowed?'),
                   ('<code>α</code>, <code>θ</code>, <code>μ</code>', 'Yes: one Greek letter'),
                   ('<code>க</code>, <code>கி</code>, <code>ள்</code>', 'Yes: one Tamil letter'),
                   ('<code>अ</code>, <code>క</code>, <code>ഐ</code>', 'Yes: one Sanskrit, Telugu or Malayalam letter'),
                   ('<code>α_$1</code>, <code>அ_$க_@உ</code>', 'Yes: one letter with a subscript and superscript'),
                   ('<code>சக்தி</code>, <code>गति</code>', 'No: a word. Store it as text: <code>A = "சக்தி";</code>'),
                   ('<code>Aβக</code>', 'No: letters from different scripts joined into one name')]),
        comp('Text in any language (UTF-8)', [
            'NC is UTF-8 enabled: a text value, written between double quotes, can hold any Unicode character '
            'from any language, including symbols and emoji. Text is printed exactly as it is written.'],
            syntax='A = "சக்தி";\nB = "भारत";\nC = "ചേരരാജ്യം";\nD = "скорость ✓";'),
        comp('Typing the letters in the NC IDE', [
            'You do not need a special keyboard. In the NC IDE, type the letter\'s input command and the IDE '
            'replaces it with the letter <strong>as soon as you finish typing it</strong>. The command never stays '
            'in your script: the script only ever contains the letter.',
            'Greek letters use their English name. The other scripts put the language name around a short key; '
            'the letter finder below lists every key.'],
            table=[('Language', 'You type in the NC IDE', 'The IDE shows'),
                   ('Greek', '<kbd>\\var(\\alpha)</kbd>', '<span class="lg-glyph" lang="el">α</span>'),
                   ('Tamil', '<kbd>\\var(\\tamil(\\a))</kbd>', '<span class="lg-glyph" lang="ta">அ</span>'),
                   ('Sanskrit', '<kbd>\\var(\\sanskrit(\\ka))</kbd>', '<span class="lg-glyph" lang="sa">क</span>'),
                   ('Malayalam', '<kbd>\\var(\\malayalam(\\ka))</kbd>', '<span class="lg-glyph" lang="ml">ക</span>'),
                   ('Telugu', '<kbd>\\var(\\telugu(\\k))</kbd>', '<span class="lg-glyph" lang="te">క</span>')]),
        comp('Letters that cannot be used in names', [
            'Greek small omicron <code>ο</code> is not a name letter because it looks exactly like Latin '
            '<code>o</code>; use the Latin letter. The Malayalam sign <code>ം</code> (anusvara) is a vowel sign, '
            'so it cannot be a name on its own.']),
        comp('Letter finder', [
            'Every letter the NC IDE can insert, by language. Each tile shows the letter and its key, and the '
            'line above the tiles shows what to type in the IDE. Search by key (such as <code>ka</code>) or paste '
            'a letter. <strong>Click a tile to copy the letter</strong> and paste it anywhere.'],
            letters=True),
    ],
    'examples': {
        'basic': ex('Greek names for physics', 'The pressure under a column of water, written with the symbols '
                    'from the textbook formula: one Greek letter per name.', '''
ρ = 1000;      # density of water, kg/m^3
g = 9.81;      # m/s^2
h = 2.5;       # depth, m
p = ρ * g * h;
publish("pressure (Pa):", p);
'''),
        'mid': ex('One-letter names in five scripts', 'Numbers and text stored under single Greek, Tamil, '
                  'Sanskrit, Telugu and Malayalam letters. The text values are printed exactly as written, and '
                  'the last line has no semicolon, so NC echoes the name and its value.', '''
μ = 3.210;
அ = 21;
कि = "भारत";
ఎ = "భారత్";
ള് = "ചേരരാജ്യം";
publish(μ * அ);
publish(कि, ఎ, ള്);
கி = "சோழ நாடு"
'''),
        'strong': ex('Ohm\'s law with Tamil labels', 'One letter per name; the Tamil words are text values. '
                     'வ holds the voltage (மின்னழுத்தம்) and ச the power (சக்தி).', '''
I = 2.5;            # current, A
R = 48;             # resistance, Ω
வ = I * R;          # voltage
ச = வ * I;          # power
A = "மின்னழுத்தம்";
B = "சக்தி";
publish(A, "(V) →", வ);
publish(B, "(W) →", ச);
publish("Ω check ✓", வ / I == R);
'''),
    },
    'errors': [
        err('Greek omicron', 'Greek small omicron looks exactly like Latin <code>o</code>, so NC does not accept '
            'it in a name. NC names the character it rejected.', '''
ο = 1;
''', '''
o = 1;
publish(o);
'''),
        err('A letter from another script', 'Names use Latin letters or one Greek, Tamil, Sanskrit, Malayalam or '
            'Telugu letter. This name is Russian (Cyrillic), which is not a name script.', '''
скорость = 3;
''', '''
v = 3;
label = "скорость";
publish(label, v);
''', 'Use a supported letter for the name, and keep the word as a text value: text accepts every language.'),
        err('A vowel sign on its own', 'The Malayalam anusvara <code>ം</code> is a sign that belongs after a '
            'letter, so it cannot be a name.', '''
ം = 1;
''', '''
അ = 1;
publish(അ);
'''),
    ],
}

PAGES['subscripts-superscripts'] = {
    'title': 'Variables with Subscripts and Superscripts',
    'summary': 'Write names the way they appear in a textbook. In the NC IDE, <kbd>_$</kbd> starts a subscript and '
               '<kbd>_@</kbd> starts a superscript, and the IDE draws them straight away: type '
               '<kbd>X_$a_@b</kbd> and you see <ide>X_$a_@b</ide>.',
    'about': [
        comp('The IDE draws them as you type', [
            'Like the <a href="non-english-variables.html">non-English letters</a>, subscripts and superscripts are '
            'shown live in the NC IDE. Type a name, then <kbd>_$</kbd> and the subscript, or <kbd>_@</kbd> and the '
            'superscript: the IDE lowers or raises the text at once and hides the marker, so your code reads like '
            'the formula on paper.',
            'The code boxes on this page show names exactly as the IDE draws them. The '
            '<strong>Copy</strong> button copies what you type, with the markers, so the IDE draws it again when '
            'you paste it.'],
            table=[('You type in the NC IDE', 'The IDE shows', 'Read as'),
                   ('<kbd>A_$1</kbd>', '<ide>A_$1</ide>', 'A sub 1'),
                   ('<kbd>V_$out</kbd>', '<ide>V_$out</ide>', 'V sub out'),
                   ('<kbd>X_@2</kbd>', '<ide>X_@2</ide>', 'X sup 2'),
                   ('<kbd>X_$a_@b</kbd>', '<ide>X_$a_@b</ide>', 'X sub a, sup b'),
                   ('<kbd>ψ_$χ_@π</kbd>', '<ide>ψ_$χ_@π</ide>', 'psi sub chi, sup pi'),
                   ('<kbd>அ_$க_@உ</kbd>', '<ide>அ_$க_@உ</ide>', 'Tamil a sub ka, sup u')]),
        comp('Subscript', [
            'Type <kbd>_$</kbd> after the name, then the subscript. It can be letters, digits or both, Latin or one '
            'of the non-English scripts: <ide>V_$in</ide>, <ide>A_$1</ide>, <ide>μ_$k</ide>, <ide>ആ_$ah</ide>.'],
            syntax='V_$in = 5;\nA_$1 = 4;\nμ_$k = 0.3;'),
        comp('Superscript', [
            'Type <kbd>_@</kbd> after the name, then the superscript: <ide>X_@2</ide>, <ide>E_@k</ide>.'],
            syntax='X_@2 = 5;\nE_@k = 1.5;'),
        comp('Subscript and superscript together', [
            'Type the subscript first, then the superscript: <strong><kbd>_$</kbd> always comes before '
            '<kbd>_@</kbd></strong>. The IDE then stacks them, superscript over subscript: <ide>X_$a_@b</ide>. '
            'This order is part of NC\'s syntax, so typing <kbd>X_@b_$a</kbd> is an error (see the Syntax Error '
            'tab), and the IDE leaves it undrawn.'],
            syntax='X_$a_@b = 1.2;     # correct: subscript, then superscript\nX_@b_$a = 1.2;     # error: superscript first'),
        comp('A superscript is part of the name, not a power', [
            '<ide>X_@2</ide> is a separate variable whose name is drawn with a raised 2. It is not <code>X</code> '
            'squared: to raise a value to a power, use <code>^</code>.'],
            syntax='X = 3;\nX_@2 = 5;     # a separate variable\nX ^ 2         # 9: X squared'),
        comp('Rules', [
            'A name has at most one subscript and one superscript, and neither can be empty.'],
            table=[('You type', 'Allowed?'),
                   ('<kbd>X_$a</kbd>, <kbd>X_@b</kbd>, <kbd>X_$a_@b</kbd>', 'Yes'),
                   ('<kbd>X_@b_$a</kbd>', 'No: the subscript must come first'),
                   ('<kbd>X_$a_$b</kbd>, <kbd>X_@a_@b</kbd>', 'No: only one of each'),
                   ('<kbd>X_$</kbd>, <kbd>X_@</kbd>', 'No: nothing after the marker')]),
    ],
    'examples': {
        'basic': ex('Numbered values', 'Subscripts number related values. The first line has no semicolon, so '
                    'NC echoes the name, written with its marker.', '''
A_$1 = 4
A_$2 = 6;
total = A_$1 + A_$2;
publish("A1 + A2 =", total);
'''),
        'mid': ex('An amplifier, in textbook notation', 'Input and output voltages with word subscripts, and a '
                  'gain written with a Greek letter.', '''
V_$in = 0.25;          # V
V_$out = 5.0;          # V
η_$v = V_$out / V_$in;   # voltage gain
publish("gain η_v =", η_$v);
publish("gain in dB =", round(20 * log(η_$v) / log(10), 2));
'''),
        'strong': ex('Both markers, any script', 'Subscripts and superscripts in Latin, Greek, Tamil and Sanskrit '
                     'names, and a check that a superscript is a separate variable, not a power.', '''
A_$b_@c = 1.2;
ψ_$χ_@π = 2.31;
அ_$க_@உ = pi;
अ_$ए_@அ = 2;
publish(A_$b_@c + ψ_$χ_@π);
publish(round(அ_$க_@உ * अ_$ए_@அ, 4));

X = 3;
X_@2 = 5;
publish("X^2 =", X ^ 2, " but X_@2 =", X_@2);
'''),
    },
    'errors': [
        err('Superscript before subscript', 'The subscript (<code>_$</code>) must come first. NC tells you the '
            'order it expects.', '''
X_@b_$a = 1.2;
''', '''
X_$a_@b = 1.2;
publish(X_$a_@b);
'''),
        err('An empty subscript', 'A marker must be followed by the subscript or superscript itself.', '''
X_$ = 1;
''', '''
X_$0 = 1;
publish(X_$0);
'''),
        err('Two subscripts', 'A name can have only one subscript and one superscript. Put everything into one '
            'subscript instead.', '''
X_$a_$b = 1;
''', '''
X_$ab = 1;
publish(X_$ab);
'''),
        err('Two superscripts', 'The same rule applies to superscripts.', '''
E_@a_@b = 1;
''', '''
E_@ab = 1;
publish(E_@ab);
'''),
    ],
}

PAGES['nc-primitives'] = {
    'title': 'NC Primitives',
    'summary': 'The primitive operations that NC builds calculations from: squares and roots, factorials, '
               'logarithms, exponentials, absolute value, rounding and angle conversion.',
    'about': [
        comp('Square and square root', [
            '<code>sqr(x)</code> multiplies a number by itself; <code>sqrt(x)</code> undoes it. '
            'The square root of a negative number is a complex number (see '
            '<a href="../Basics/complex-numbers.html">Complex Numbers</a>).'],
            math=r'\operatorname{sqr}(x) = x^{2} \qquad \operatorname{sqrt}(x) = \sqrt{x}',
            syntax='sqr(x)\nsqrt(x)'),
        comp('Cube and cube root', [
            '<code>cube(x)</code> raises to the third power. <code>cbrt(x)</code> gives the real cube root, '
            'so <code>cbrt(-27)</code> is <code>-3</code>.'],
            math=r'\operatorname{cube}(x) = x^{3} \qquad \operatorname{cbrt}(x) = \sqrt[3]{x}',
            syntax='cube(x)\ncbrt(x)'),
        comp('Factorial', [
            'Write <code>!</code> after a value. For whole numbers it multiplies every whole number down to 1; '
            '<code>0!</code> is 1. For other values NC uses the gamma function, so <code>3.5!</code> works too. '
            '<code>!</code> is applied before <code>^</code>, <code>*</code> and <code>-</code>.'],
            math=r'n! = n \times (n-1) \times \cdots \times 1 \qquad x! = \Gamma(x+1)',
            syntax='n!\n(A + B)!'),
        comp('Logarithms', [
            '<code>log(x)</code> is the natural logarithm (base <em>e</em>). For another base, put the base in '
            'the name: <code>logb2(x)</code>, <code>logb3(x)</code>, <code>logb4(x)</code> and so on.'],
            math=r'\log(x) = \ln x \qquad \operatorname{logb}_n(x) = \frac{\ln x}{\ln n}',
            syntax='log(x)\nlogb2(x)\nlogb4(x)'),
        comp('Exponential', [
            '<code>e</code> is the constant 2.718281…, so <code>e^x</code> is the exponential function.'],
            math=r'e^{x} = \sum_{k=0}^{\infty} \frac{x^{k}}{k!}',
            syntax='e^x\ne^(A + B)'),
        comp('Absolute value', [
            'Put a value between vertical bars to drop its sign. Bars can be nested.'],
            math=r'|x| = \begin{cases} x & x \ge 0 \\ -x & x < 0 \end{cases}',
            syntax='|x|\n|A - B|'),
        comp('Rounding', [
            '<code>round(x)</code> rounds to the nearest whole number, with halves rounded away from zero. '
            '<code>round(x, n)</code> keeps <code>n</code> decimal places.'],
            syntax='round(x)\nround(x, n)'),
        comp('Angle conversion', [
            '<code>rad2dec(x)</code> converts radians to degrees and <code>dec2rad(x)</code> converts degrees '
            'to radians. <code>pi</code> is the constant π.'],
            math=r'\text{degrees} = \text{radians} \times \frac{180}{\pi}',
            syntax='rad2dec(x)\ndec2rad(x)'),
    ],
    'examples': {
        'basic': ex('Powers, roots and factorials', 'One line per pair of primitives.', '''
publish(sqr(5), sqrt(144));
publish(cube(3), cbrt(27), cbrt(-27));
publish(5!, 0!, |-6.9|);
'''),
        'mid': ex('Logs, exponentials and conversions', 'Apply several primitives to the same value.', '''
x = 8;
publish("log(x)    :", log(x));
publish("logb2(x)  :", logb2(x));
publish("e^(log x) :", round(e^log(x), 9));
publish("sqrt, 3dp :", round(sqrt(x), 3));
publish("pi/4 deg  :", rad2dec(pi / 4));
publish("90 deg    :", dec2rad(90));
'''),
        'strong': ex('Checking identities', 'Each line tests an identity between primitives, in the style of the '
                     'NC test scripts. <code>true</code> means the identity holds.', '''
A = 1.1; B = 1.2; P = 4.4; R = 144.144;
publish("sqrt(sqr(P)) == P   :", round(sqrt(sqr(P)), 9) == P);
publish("cbrt(cube(B)) == B  :", round(cbrt(cube(B)), 9) == B);
publish("e^log(R) == R       :", round(e^log(R), 9) == R);
publish("logb2(2^10) == 10   :", logb2(2^10) == 10);
publish("6! == 6 * 5!        :", 6! == 6 * 5!);
publish("|A - P| == |P - A|  :", |A - P| == |P - A|);
publish("3.5! (gamma)        :", 3.5!);
'''),
    },
}

# ============================================================== BASICS
PAGES['arithmetic'] = {
    'title': 'Arithmetic',
    'summary': 'The arithmetic operators, the order NC applies them in, and what happens with infinity, '
               'not-a-number and decimal rounding.',
    'about': [
        comp('Arithmetic operators', [
            'NC has the usual four operators plus power, whole-number division and remainder.'],
            table=[('Operator', 'Meaning', 'Example', 'Result'),
                   ('<code>+</code>', 'Addition', '<code>17 + 5</code>', '22'),
                   ('<code>-</code>', 'Subtraction', '<code>17 - 5</code>', '12'),
                   ('<code>*</code>', 'Multiplication', '<code>17 * 5</code>', '85'),
                   ('<code>/</code>', 'Division', '<code>17 / 5</code>', '3.4'),
                   ('<code>^</code>', 'Power', '<code>2 ^ 10</code>', '1024'),
                   ('<code>//</code>', 'Whole-number division (quotient)', '<code>17 // 5</code>', '3'),
                   ('<code>%</code>', 'Remainder', '<code>17 % 5</code>', '2')],
            syntax='A + B\nA - B\nA * B\nA / B\nA ^ B\nA // B\nA % B'),
        comp('Quotient and remainder', [
            '<code>a // b</code> divides and drops the fractional part, moving toward zero, so <code>-7 // 2</code> '
            'is <code>-3</code>. <code>a % b</code> is what is left over and takes the sign of <code>a</code>. '
            'Both work with decimals.'],
            math=r'q = \operatorname{trunc}\!\left(\frac{a}{b}\right) \qquad r = a - b\,q',
            syntax='q = a // b;\nr = a % b;'),
        comp('Order of operations', [
            'NC works out an expression in this order. Use brackets whenever you want a different order.',
            '1. Brackets <code>( )</code> and absolute value <code>| |</code>; 2. factorial <code>!</code>; '
            '3. power <code>^</code>, from right to left; 4. a leading minus sign; '
            '5. <code>*</code> <code>/</code> <code>//</code> <code>%</code>, left to right; '
            '6. <code>+</code> <code>-</code>, left to right.',
            'So <code>-2 ^ 2</code> is <code>-4</code>, and <code>2 ^ 3 ^ 2</code> is <code>2 ^ 9 = 512</code>.'],
            math=r'2^{3^{2}} = 2^{9} = 512 \qquad -2^{2} = -(2^{2}) = -4'),
        comp('Infinity and not-a-number', [
            'NC follows the IEEE 754 standard. Dividing a non-zero number by zero gives <code>inf</code> '
            '(or <code>-inf</code>). Forms with no defined value give <code>nan</code> (not a number). '
            'By the same standard, <code>1^inf</code>, <code>inf^0</code> and <code>0^0</code> are all 1.'],
            table=[('Form', 'Result'), ('<code>1/0</code>', 'inf'),
                   ('<code>0/0</code>, <code>inf/inf</code>', 'nan'),
                   ('<code>0 * inf</code>', 'nan'), ('<code>inf - inf</code>', 'nan'),
                   ('<code>1^inf</code>, <code>inf^0</code>, <code>0^0</code>', '1')]),
        comp('Decimal precision', [
            'Numbers are stored in binary, so most decimals are stored as a very close approximation. '
            '<code>0.1 + 0.2</code> prints as <code>0.3</code> but is not exactly equal to it. '
            'To compare decimals, round them first or check that the difference is tiny.'],
            math=r'|a - b| < \varepsilon',
            syntax='|a - b| < 1e-12\nround(a, 9) == round(b, 9)'),
    ],
    'examples': {
        'basic': ex('Every operator', 'Apply each arithmetic operator to the same two numbers.', '''
A = 17; B = 5;
publish(A + B, A - B, A * B, A / B);
publish(A ^ 2, A // B, A % B);
'''),
        'mid': ex('Order of operations', 'Each line shows an expression with and without brackets.', '''
publish(2 + 3 * 4, (2 + 3) * 4);
publish(-2 ^ 2, (-2) ^ 2);
publish(2 ^ 3 ^ 2, (2 ^ 3) ^ 2);
publish(100 / 10 / 2, 2 * 3!);
publish(-7 // 2, -7 % 3, 7.5 % 2);
'''),
        'strong': ex('Infinity, nan and precision', 'The special IEEE 754 forms, then a safe way to compare decimals.', '''
INF = 1 / 0;
publish("1/0       :", INF, -1 / 0);
publish("0/0       :", 0 / 0);
publish("inf - inf :", INF - INF);
publish("0 * inf   :", 0 * INF);
publish("inf ^ 0   :", INF ^ 0, 1 ^ INF);
x = 0.1 + 0.2;
publish("0.1 + 0.2 :", x, x == 0.3);
publish("close?    :", |x - 0.3| < 1e-12);
'''),
    },
    'errors': [
        err('A bracket that is never closed', 'Every <code>(</code> needs a matching <code>)</code>.', '''
y = (1 + 2 * 3;
''', '''
y = (1 + 2) * 3;
publish(y);
'''),
        err('Two operators in a row', 'Each operator needs a value on both sides.', '''
y = 5 +* 3;
''', '''
y = 5 * 3;
publish(y);
'''),
        err('Power written twice', 'NC writes a power with a single <code>^</code>.', '''
y = 2 ^^ 3;
''', '''
y = 2 ^ 3;
publish(y);
'''),
    ],
}

PAGES['matrices'] = {
    'title': 'Matrices',
    'summary': 'A matrix is a grid of numbers. NC writes matrices in square brackets and does arithmetic on whole '
               'matrices at once.',
    'about': [
        comp('Creating a matrix', [
            'Separate the values in a row with commas and the rows with semicolons. A matrix can span several '
            'lines. A single row is a row vector (see <a href="lists.html">Lists</a>). For three or more axes, see '
            '<a href="n-dimensional-arrays.html">N-Dimensional Arrays</a>.'],
            math=r'A = \begin{bmatrix} 1 & 2 & 3 \\ 4 & 5 & 6 \end{bmatrix}',
            syntax='A = [1, 2, 3;\n     4, 5, 6];\nv = [10, 20, 30];'),
        comp('Ranges', [
            '<code>[a:b]</code> counts from <code>a</code> to <code>b</code> in steps of 1. '
            '<code>[a:step:b]</code> uses your own step, which can be a decimal or negative.'],
            syntax='[1:5]          # 1 2 3 4 5\n[0:0.5:2]      # 0 0.5 1 1.5 2\n[10:-5:0]      # 10 5 0'),
        comp('Reading elements', [
            'Positions start at 0. <code>A[r][c]</code> and <code>A[r, c]</code> both give the element in '
            'row <code>r</code>, column <code>c</code>. <code>A[r]</code> gives a whole row and '
            '<code>A[:, c]</code> a whole column. In a single column, <code>v[r]</code> is already one number, '
            'so use <code>v[r, 0]</code> or <code>v[r]</code> rather than <code>v[r][0]</code>.'],
            syntax='A[1][2]\nA[1, 2]\nA[0]\nA[:, 1]'),
        comp('Changing elements', [
            'Assign to a position to change one element.'],
            syntax='A[1][0] = 9;\nA[0, 1] = 7;'),
        comp('Matrix arithmetic', [
            '<code>+</code> and <code>-</code> work element by element. <code>*</code> is the matrix product; '
            'for element-by-element multiplication use <code>*.</code>. A number times a matrix scales every '
            'element, and <code>A\'</code> is the transpose.'],
            math=r'(AB)_{ij} = \sum_{k} A_{ik}\,B_{kj} \qquad (A \odot B)_{ij} = A_{ij}\,B_{ij}',
            syntax="A + B\nA * B      # matrix product\nA *. B     # element by element\n2 * A\nA'         # transpose"),
    ],
    'examples': {
        'basic': ex('Create and read', 'Build a 2 × 3 matrix, then read an element, a row and a column.', '''
A = [1, 2, 3;
     4, 5, 6];
publish(A);
publish(A[1][2], A[1, 2]);
publish(A[0]);
publish(A[:, 1]);
'''),
        'mid': ex('Matrix arithmetic', 'The difference between the matrix product and element-by-element multiplication.', '''
A = [1, 2; 3, 4];
B = [5, 6; 7, 8];
publish(A + B);
publish(A * B);
publish(A *. B);
publish(A');
'''),
        'strong': ex('Daily cost from a parts order', 'Quantities of three parts ordered on two days, times the price '
                     'of each part, gives one total per day.', '''
qty = [10, 4, 0;
        2, 8, 5];
price = [2.5; 4; 12];
cost = qty * price;
publish(cost);
publish("day 1 total:", cost[0, 0]);
qty[1, 2] = 0;
new_cost = qty * price;
publish("day 2 without part 3:", new_cost[1, 0]);
publish("ranges:", [0:0.5:2]);
'''),
    },
    'errors': [
        err('Rows of different lengths', 'Every row of a matrix needs the same number of values.', '''
A = [1, 2; 3];
''', '''
A = [1, 2; 3, 4];
publish(A);
'''),
        err('Adding matrices of different sizes', '<code>+</code> works element by element, so both matrices '
            'must have the same size.', '''
A = [1, 2] + [1, 2, 3];
''', '''
A = [1, 2, 0] + [1, 2, 3];
publish(A);
'''),
        err('An index past the end', 'Indexes start at 0, so a 3-element matrix has the indexes 0, 1 and 2.', '''
A = [1, 2, 3];
publish(A[3]);
''', '''
A = [1, 2, 3];
publish(A[2], A[-1]);
'''),
        err('Matrix product with sizes that do not fit', '<code>*</code> is the matrix product: the columns of the '
            'left matrix must equal the rows of the right. For element-by-element multiplication use '
            '<code>*.</code>.', '''
A = [1, 2; 3, 4];
B = [1, 2, 3];
C = A * B;
''', '''
A = [1, 2; 3, 4];
B = [1, 2];
publish(B * A);
publish(B *. [10, 20]);
'''),
    ],
}

PAGES['growing-matrices'] = {
    'title': 'Growing Matrices',
    'summary': 'Add columns with <code>,=</code> and rows with <code>;=</code>: the quick way to build a matrix '
               'piece by piece, for example inside a loop.',
    'about': [
        comp('Adding columns: ,=', [
            '<code>M ,= X</code> appends X to the right of M. It is the same as <code>M = [M, X]</code>.'],
            syntax='M = [1, 2; 3, 4];\nM ,= [5; 6];        # [1, 2, 5; 3, 4, 6]',
            figure=fig('Images/Neural_Code/Language_Guide/Basics/growing-matrices-01.svg',
                       'M is a 2 by 2 matrix. M ,= a column adds a third column on the right. M ;= a row adds a '
                       'third row underneath.',
                       '<code>,=</code> grows a matrix to the right (more columns); <code>;=</code> grows it '
                       'downward (more rows).')),
        comp('Adding rows: ;=', [
            '<code>M ;= X</code> appends X below M. It is the same as <code>M = [M; X]</code>.'],
            syntax='A = [1, 2, 3; 4, 5, 6];\nA ;= [7, 8, 9];     # three rows'),
        comp('Building in a loop', [
            'Start with an empty matrix, <code>M = []</code>, and add one row (or column) on every pass. M must '
            'exist before the first <code>,=</code> or <code>;=</code>.'],
            syntax='R = [];\nfor i = [1:3]:\n   R ;= [i, i^2, i^3];\nfend'),
        comp('Single values and empty matrices', [
            'A single value is repeated along M: <code>M ,= 0</code> adds a column of zeros and <code>M ;= 9</code> '
            'a row of nines. An empty matrix changes nothing: <code>M ,= []</code> leaves M as it is, and '
            '<code>[] ,= X</code> gives X.'],
            syntax='Z = [1, 2; 3, 4];\nZ ,= 0;     # [1, 2, 0; 3, 4, 0]\nZ ;= 9;     # adds the row 9, 9, 9'),
        comp('What happens first', [
            'The value on the right is worked out before M is read, so <code>H ,= H</code> doubles H. Only M '
            'changes: another variable that was copied from M keeps its old value.'],
            syntax='H = [1; 2];\nH ,= H;     # [1, 1; 2, 2]'),
        comp('The rules for shapes and types', [
            'Shapes must fit exactly: NC never turns a row into a column to make it fit. The element types follow '
            'the matrix rules, so <code>[1, 2] ,= 2.5</code> gives decimals and timestamps can be collected too. '
            '<code>,=</code> and <code>;=</code> work on 2-D matrices, and only a plain variable name may stand on '
            'the left.'],
            syntax='T = [1, 2];\nT ,= 2.5;   # [1, 2, 2.5]'),
    ],
    'examples': {
        'basic': ex('Columns and rows', 'Grow one matrix to the right and another downward.', """
M = [1, 2; 3, 4];
M ,= [5; 6];
M ,= [7, 8; 9, 10];
M
A = [1, 2, 3; 4, 5, 6];
A ;= [7, 8, 9];
A ;= [0, 0, 0; 1, 1, 1];
A
"""),
        'mid': ex('A table built in a loop', 'Start empty and add one row per pass: n, n squared and n cubed.', """
R = [];
for i = [1:5]:
   R ;= [i, i^2, i^3];
fend
R
v = [];
for k = [1:6]:
   if k % 2 == 0:
      v ,= k;
   iend
fend
v
"""),
        'strong': ex('Inside a function, with single values and copies', 'A function that builds its result row by '
                     'row, a matrix padded with a column of zeros and a row of nines, self-extension, and a copy '
                     'that does not change.', """
function R = squares_table(n):
   R = [];
   for i = [1:n]:
      R ;= [i, i^2];
   fend
fnend
S = squares_table(4)

Z = [1, 2; 3, 4];
Z ,= 0;
Z ;= 9;
Z
H = [1; 2];
H ,= H;
H
P = [1, 2];
Q = P;
P ,= 3;
publish("P =", P, "  Q =", Q);
"""),
    },
    'errors': [
        err('A row where a column is needed', 'M has 3 rows, so a new column needs 3 values in a column. NC never '
            'turns a row into a column for you.', 'M = [1, 2; 3, 4; 5, 6];\nM ,= [7, 8, 9];',
            "M = [1, 2; 3, 4; 5, 6];\nM ,= [7; 8; 9];\npublish(M);"),
        err('A row of the wrong width', 'A has 3 columns, so a new row needs 3 values.',
            'A = [1, 2, 3; 4, 5, 6];\nA ;= [1; 2];', 'A = [1, 2, 3; 4, 5, 6];\nA ;= [1, 2, 3];\npublish(A);'),
        err('Growing a variable that does not exist', 'Start it empty first.', 'U ,= 1;',
            'U = [];\nU ,= 1;\npublish(U);'),
        err(',= inside brackets', '<code>,=</code> is a statement of its own, not part of an expression.',
            'x = [1, 2];\ny = [x ,= 3];', 'x = [1, 2];\nx ,= 3;\ny = x;\npublish(y);'),
        err(',= on an element', 'Only a plain variable name can be grown.', 'A = [1, 2; 3, 4];\nA[0] ,= 5;',
            'A = [1, 2; 3, 4];\nA ,= 5;\npublish(A);'),
        err(',= on an N-dimensional array', '<code>,=</code> and <code>;=</code> work on 2-D matrices.',
            'B = [1, 2; 3, 4 ;; 5, 6; 7, 8];\nB ,= 1;', 'B = [1, 2; 3, 4];\nB ,= 1;\npublish(B);'),
        err(',= inside a function call', 'Grow the variable first, then pass it.', 'y = max([1, 2] ,= 3);',
            'v = [1, 2];\nv ,= 3;\ny = max(v);\npublish(y);'),
    ],
}

PAGES['lists'] = {
    'title': 'Lists',
    'summary': 'A list is one row of values in square brackets. NC builds lists from ranges with open or closed '
               'ends, reads them by position and works on every item at once.',
    'about': [
        comp('Writing a list', [
            'Write the values between square brackets, separated by commas. Text items go in double or single '
            'quotes. A list is a matrix with one row, so everything on the '
            '<a href="matrices.html">Matrices</a> page works on lists too.',
            'A list holds one kind of value. If any item is text, NC keeps <em>every</em> item as text: in '
            '<code>[1, "two"]</code> the first item is the text <code>"1"</code>, not the number 1.'],
            syntax='X1 = [10, 20, 30];\nX2 = [\'a\', \'b\', \'c\'];\nnames = ["pump", "valve", "tank"];\nempty = [];'),
        comp('Ranges with closed and open ends', [
            'A range fills a list for you. A square bracket includes the value next to it; a round bracket '
            'leaves it out, just as in interval notation. The step is optional and is 1 when left out.'],
            math=r'[a, b] \qquad (a, b) \qquad (a, b] \qquad [a, b)',
            table=[('Written', 'Start', 'End', '<code>1:5</code> gives'),
                   ('<code>[1:5]</code>', 'included', 'included', '1 2 3 4 5'),
                   ('<code>(1:5)</code>', 'left out', 'left out', '2 3 4'),
                   ('<code>(1:5]</code>', 'left out', 'included', '2 3 4 5'),
                   ('<code>[1:5)</code>', 'included', 'left out', '1 2 3 4')],
            syntax='A1 = [1:100];       # 1, 2, ... 100\nA2 = [1:0.5:100];   # step 0.5\nA3 = (1:100);       # 2 ... 99\n'
                   'A5 = (1:100];       # 2 ... 100\nA6 = [1:100);       # 1 ... 99\nA7 = [10:-2:0];     # counts down'),
        comp('Reading items', [
            'Positions start at 0. A negative position counts from the end, so <code>X[-1]</code> is the last item. '
            '<code>X[a:b]</code> gives the items from position <code>a</code> to position <code>b</code>, '
            '<em>both included</em>; leave out <code>a</code> or <code>b</code> to run from the start or to the end. '
            '<code>X[a:step:b]</code> takes every <code>step</code>-th item, and <code>X[::-1]</code> is the list '
            'backwards. When <code>a</code> is larger than <code>b</code> (without a negative step) the result is '
            'empty: <code>X[2:0]</code> gives <code>[]</code>.'],
            syntax='X[0]        # first item\nX[-1]       # last item\nX[1:3]      # positions 1, 2 and 3\n'
                   'X[2:]       # from position 2 to the end\nX[0:2:8]    # every second item\nX[::-1]     # reversed'),
        comp('Changing and growing a list', [
            'Assign to a position to change an item. Assigning to the position just past the end adds an item, '
            'and <code>[X, v]</code> builds a new list with <code>v</code> added. To drop items, build a new list '
            'from the ones you keep.'],
            syntax='X[1] = "z";\nX[length(X)] = 6;    # add at the end\nY = [X, 7];          # joined copy\n'
                   'X = [X[0], X[2]];    # keep items 0 and 2'),
        comp('Working with the whole list', [
            '<code>length(X)</code> counts the items. <code>sum</code>, <code>min</code>, <code>max</code> and '
            '<code>mean</code> summarise a list of numbers; <code>sort</code>, <code>unique</code> and '
            '<code>flip</code> give a new list. Arithmetic with a number works on every item, and so does '
            '<code>*.</code> or <code>^.</code> between two lists.',
            'A comparison such as <code>X &gt; 2</code> gives a list of true/false values, and '
            '<code>sum(X &gt; 2)</code> counts how many items pass. <code>v in X</code> checks whether a value '
            'is in the list (see <a href="logical-operators.html">Logical Operators</a>).'],
            math=r'\bar{x} = \frac{1}{n}\sum_{k=0}^{n-1} x_k',
            syntax='length(X)\nsum(X)  min(X)  max(X)  mean(X)\nsort(X)  unique(X)  flip(X)\n'
                   'X + 1   X *. 2   X ^. 2\nX > 2\n"b" in X'),
    ],
    'examples': {
        'basic': ex('Make and read a list', 'A list of numbers, a list of text and a few ways to read them.', '''
X1 = [10, 20, 30, 40, 50];
X2 = ['a', 'b', 'c', 'd'];
publish(X1[0], X1[-1], length(X1));
publish(X1[1:3]);
publish(X2[::-1]);
X2[1] = 'z';
publish(X2);
'''),
        'mid': ex('Open and closed ranges', 'The same range written with each pair of brackets, then the count of '
                  'items each form gives for 1 to 100.', '''
A1 = [1:5];
A3 = (1:5);
A5 = (1:5];
A6 = [1:5);
publish("[1:5]   :", A1);
publish("(1:5)   :", A3);
publish("(1:5]   :", A5);
publish("[1:5)   :", A6);
publish("(1:0.5:3]:", (1:0.5:3]);
publish("[1:0.5:3):", [1:0.5:3));
publish("counts for 1 to 100:", length([1:100]), length((1:100)), length([1:0.5:100]), length((1:0.5:100)));
'''),
        'strong': ex('Sensor readings', 'Hourly readings from one sensor: add a late reading, summarise the list, '
                     'count the readings above a limit and check a tag list.', '''
readings = [21.5, 22.0, 23.4, 25.1, 24.8, 22.9];
readings[length(readings)] = 26.3;
publish("readings :", readings);
publish("count    :", length(readings));
publish("min/max  :", min(readings), max(readings));
publish("mean     :", mean(readings));
limit = 24;
publish("above 24 :", sum(readings > limit));
publish("sorted   :", sort(readings));
publish("last 3   :", readings[-3:]);
tags = ["T1", "T2", "T3"];
publish("T2 known :", "T2" in tags, "T9 known :", "T9" in tags);
'''),
    },
    'errors': [
        err('Arithmetic on a list of text', 'A list that holds any text keeps every item as text, so its items '
            'cannot be added as numbers.', '''
X = [1, "two", 3];
publish(X[0] + 1);
''', '''
X = [1, 2, 3];
publish(X[0] + 1);
''', 'Keep numbers and text in separate lists, or convert a text item with <code>float(...)</code>.'),
        err('An index past the end', 'A list of 3 items has the positions 0, 1 and 2.', '''
X = ["a", "b", "c"];
publish(X[3]);
''', '''
X = ["a", "b", "c"];
publish(X[2], X[-1]);
'''),
        err('Lists inside a list', 'NC does not nest lists with <code>[[...], [...]]</code>. Put the rows of a '
            'matrix in one pair of brackets, separated by <code>;</code>.', '''
X = [[1, 2], [3, 4]];
''', '''
X = [1, 2; 3, 4];
publish(X);
'''),
    ],
}

PAGES['n-dimensional-arrays'] = {
    'title': 'N-Dimensional Arrays',
    'summary': 'A matrix has rows and columns. An N-dimensional array stacks matrices into pages, and pages into '
               'blocks, so one value can hold data with three, four or more axes.',
    'about': [
        comp('Writing an N-dimensional array', [
            'Inside the brackets, <code>,</code> separates values and <code>;</code> separates rows, as in a '
            '<a href="matrices.html">matrix</a>. Each extra semicolon adds a dimension: <code>;;</code> separates '
            '2-D pages, giving a 3-D array, and <code>;;;</code> separates 3-D blocks, giving a 4-D array. '
            'Use <code>~~</code> to continue a long array on the next line.',
            'Every page must have the same number of rows and columns, and every block the same number of pages.'],
            math=r'A \in \mathbb{R}^{\,p \times r \times c} \qquad '
                 r'B \in \mathbb{R}^{\,b \times p \times r \times c}',
            syntax='A = [1, 2; 3, 4;; 5, 6; 7, 8];                       # 2 x 2 x 2\n'
                   'B = [1, 2; 3, 4;; 5, 6; 7, 8;;; 1, 2; 3, 4;; 5, 6; 7, 8];  # 2 x 2 x 2 x 2'),
        comp('Size and shape', [
            '<code>size(A)</code> lists the length of each axis, outermost first: for a 3-D array that is '
            'pages, rows, columns. <code>ndims(A)</code> gives the number of axes and <code>numel(A)</code> '
            'the number of values. <code>zeros(p, r, c)</code> and <code>ones(p, r, c)</code> make a filled '
            'array of any size.',
            'NC prints an N-D array one 2-D page at a time, each headed by its position, such as '
            '<code>A[1,:,:]</code>.'],
            math=r'\operatorname{numel}(A) = p \cdot r \cdot c',
            syntax='size(A)\nndims(A)\nnumel(A)\nzeros(2, 3, 4)\nones(2, 2, 2)'),
        comp('Reading values and slabs', [
            'Give one key per axis, outermost first: <code>A[p, r, c]</code> is page <code>p</code>, row '
            '<code>r</code>, column <code>c</code>. All positions start at 0. One key alone, <code>A[p]</code>, '
            'gives the whole page <code>p</code> as an ordinary matrix (a slab). Any other number of keys is '
            'an error.',
            '<code>:</code> keeps a whole axis: <code>A[:, 0, :]</code> is row 0 of every page and '
            '<code>A[:, 1, 1]</code> one value from each page.'],
            syntax='A[1, 0, 1]     # page 1, row 0, column 1\nA[1]           # page 1 as a 2-D matrix\n'
                   'A[:, 0, :]     # row 0 of every page\nB[1, 0, 1, 1]  # 4-D: one key per axis'),
        comp('Changing values', [
            'Assign to a full set of keys to change one value, or to a single key to replace a whole page.'],
            syntax='A[0, 0, 1] = 50;\nA[1] = [0, 0; 0, 0];'),
        comp('Arithmetic', [
            'Adding or subtracting arrays of the same size, multiplying by a number and the element-by-element '
            'operators <code>*.</code> and <code>^.</code> work on every value at once. The matrix product and '
            'functions such as <code>sum</code>, <code>max</code> and <code>mean</code> work on 2-D matrices, so '
            'apply them to a slab: <code>A[0] * A[1]</code>, <code>max(A[1])</code>.'],
            math=r'(A + B)_{prc} = A_{prc} + B_{prc}',
            syntax='A + 10\n2 * A\nA *. A\nA ^. 2\nA[0] * A[1]    # matrix product of two pages\nmax(A[1])'),
    ],
    'examples': {
        'basic': ex('A 3-D array', 'Two 2 × 2 pages joined with <code>;;</code>, then a value, a page and a '
                    'slice across both pages.', '''
A = [1, 2; 3, 4;; 5, 6; 7, 8];
publish(A);
publish(size(A), ndims(A), numel(A));
publish(A[1, 0, 1]);
publish(A[1]);
publish(A[:, 0, :]);
'''),
        'mid': ex('4-D arrays', 'A 2 × 2 × 2 × 2 array joined with <code>;;;</code>, and a 3 × 3 × 3 × 3 array '
                  'written over three lines with <code>~~</code>.', '''
A = [1, 2; 3, 4;; 5, 6; 7, 8;;; 10, 20; 30, 40;; 50, 60; 70, 80];
publish(A);
publish(size(A), A[1, 0, 1, 1]);
B = [1,2,3;4,5,6;7,8,9;;1,2,3;4,5,6;7,8,9;;1,2,3;4,5,6;7,8,9;;;~~
     1,2,3;4,5,6;7,8,9;;1,2,3;4,5,6;7,8,9;;1,2,3;4,5,6;7,8,9;;;~~
     1,2,3;4,5,6;7,8,9;;1,2,3;4,5,6;7,8,9;;1,2,3;4,5,6;7,8,9];
publish(size(B), numel(B));
'''),
        'strong': ex('Temperatures by day, sensor and hour', 'Two days (pages) of readings from three sensors '
                     '(rows) over four hours (columns). Read one reading, the first sensor on both days, the '
                     'hottest reading of day 2, then correct a sensor and convert to kelvin.', '''
T = [20, 22, 21, 25; 19, 23, 24, 26; 18, 20, 22, 21;;
     21, 24, 23, 27; 20, 25, 26, 28; 19, 21, 23, 22];
publish("size (days, sensors, hours):", size(T));
publish("day 2, sensor 3, hour 4:", T[1, 2, 3]);
publish(T[:, 0, :]);
publish("hottest on day 2:", max(T[1]));
publish("mean on day 1:", mean(T[0]));
T[1, 2, 0] = 20;
K = T + 273.15;
publish("day 2, sensor 3 in kelvin:", K[1, 2, 0]);
'''),
    },
    'errors': [
        err('Pages of different sizes', 'Every page joined by <code>;;</code> must have the same rows and '
            'columns.', '''
A = [1, 2; 3, 4;; 5, 6; 7];
''', '''
A = [1, 2; 3, 4;; 5, 6; 7, 8];
publish(size(A));
'''),
        err('The wrong number of keys', 'A 3-D array is read with one key (a page) or three keys (one value). '
            'Two keys are not enough.', '''
A = [1, 2; 3, 4;; 5, 6; 7, 8];
publish(A[0, 0]);
''', '''
A = [1, 2; 3, 4;; 5, 6; 7, 8];
publish(A[0, 0, 0]);
publish(A[0]);
'''),
        err('A 2-D function on an N-D array', '<code>sum</code>, <code>max</code> and similar functions work on '
            '2-D matrices. Apply them to one page.', '''
A = [1, 2; 3, 4;; 5, 6; 7, 8];
publish(sum(A));
''', '''
A = [1, 2; 3, 4;; 5, 6; 7, 8];
publish(sum(A[0]), sum(A[1]));
'''),
        err('An index past the end', 'A 2 × 2 × 2 array has the positions 0 and 1 on every axis.', '''
A = [1, 2; 3, 4;; 5, 6; 7, 8];
publish(A[2, 0, 0]);
''', '''
A = [1, 2; 3, 4;; 5, 6; 7, 8];
publish(A[1, 0, 0], A[-1, 0, 0]);
'''),
    ],
}

PAGES['dictionaries'] = {
    'title': 'Dictionaries',
    'summary': 'A dictionary stores values under keys, so you can look a value up by its name or number instead '
               'of its position.',
    'about': [
        comp('Making a dictionary', [
            '<code>dict()</code> makes an empty dictionary. Assign <code>d[key] = value</code> to add an entry; '
            'assigning to a key that already exists replaces its value. The type of a dictionary is '
            '<code>dict</code>.',
            'A value can be anything: a number, text, a list, a matrix or another dictionary.'],
            syntax='A = dict();\nA[1] = 100;\nA[2] = 85;\nB = dict();\nB["pump"] = [1:10];'),
        comp('Building one in a single line', [
            'Pass a list of keys and a list of values of the same length, either separated by a comma or '
            'by <code>:</code>. Name the entries directly with <code>dict(name = value, ...)</code>. With a '
            'matrix as the values, each key gets one row.'],
            syntax='dict(["a", "b", "c"], [1, 2, 3])\ndict(["a", "b"]: [1, 2])\ndict(x = 1, y = "two")\n'
                   'dict(["a", "b"], [1, 2; 3, 4])    # a: [1, 2], b: [3, 4]'),
        comp('Keys', [
            'A key is a number or text. The number <code>1</code> and the text <code>"1"</code> are the '
            '<em>same</em> key, so <code>d[1]</code> and <code>d["1"]</code> reach the same entry. Keys keep '
            'the order in which they were added.'],
            table=[('Key', 'Allowed?'),
                   ('<code>1</code>, <code>2.5</code>', 'Yes'),
                   ('<code>"pump"</code>, <code>\'1\'</code>', 'Yes'),
                   ('A list, matrix or dictionary', 'No')]),
        comp('Reading entries', [
            '<code>d[key]</code> gives the value stored under <code>key</code>. When the key is text that is also '
            'a valid name, <code>d.key</code> reads it too. Nested dictionaries read step by step: '
            '<code>d["T"]["min"]</code> or <code>d.T.min</code>. Reading a key that is not there is an error, so '
            'check first with <code>in</code>.'],
            syntax='d["pump"]\nd.pump\nd["T"]["min"]\nd.T.min\n"pump" in d'),
        comp('Looking inside', [
            '<code>keys(d)</code> and <code>values(d)</code> give the keys and the values as lists, and '
            '<code>size(d)</code> counts the entries; each can also be written as a method, '
            '<code>d.keys()</code>. <code>match_key(d, value)</code> finds the key that holds a value. '
            'Loop over <code>keys(d)</code> to visit every entry, and set several entries at once with '
            '<code>d["a", "b"] = [8, 9]</code>.'],
            syntax='keys(d)\nvalues(d)\nsize(d)\nmatch_key(d, value)\nfor k = keys(d):\n   publish(k, d[k]);\nfend'),
    ],
    'examples': {
        'basic': ex('Numbers and text as keys', 'One dictionary with number keys and one that stores a whole list '
                    'under each key. <code>B[2]</code> reaches the entry stored as <code>B["2"]</code>.', '''
A = dict();
A[1] = 100;
A[2] = 85;
publish(A);
publish(A[1], type(A));

X1 = [1:10];
B = dict();
B['1'] = X1;
B['2'] = X1 *. 2;
publish(B['2']);
publish(B[2][0:2]);
'''),
        'mid': ex('Build, look inside and loop', 'A stock count built in one line, changed, then listed entry by '
                  'entry.', '''
stock = dict(["bolt", "nut", "washer"], [120, 340, 95]);
stock["nut"] = 300;
stock["pin", "clip"] = [40, 60];
publish(keys(stock));
publish(values(stock));
publish("entries:", size(stock));
publish("who has 95:", match_key(stock, 95));
for k = keys(stock):
   publish(k, stock[k]);
fend
'''),
        'strong': ex('Material properties', 'A dictionary of dictionaries: look a material up by name, guard '
                     'against a missing one and work out a mass.', '''
steel = dict(density = 7850, E = 200e9, name = "Steel");
alu = dict(density = 2700, E = 69e9, name = "Aluminium");
materials = dict();
materials["steel"] = steel;
materials["aluminium"] = alu;

volume = 0.002;
for m = keys(materials):
   mass = materials[m]["density"] * volume;
   publish(materials[m].name, "mass:", mass, "kg");
fend

wanted = "titanium";
if wanted in materials:
   publish(materials[wanted].density);
else:
   publish(wanted, "is not in the table");
iend
'''),
    },
    'errors': [
        err('Reading a key that is not there', 'NC stops when a key is missing. Check with <code>in</code> first.', '''
B = dict(["a", "b"], [1, 2]);
publish(B["z"]);
''', '''
B = dict(["a", "b"], [1, 2]);
if "z" in B:
   publish(B["z"]);
else:
   publish("no key z");
iend
'''),
        err('Keys and values of different lengths', '<code>dict(keys, values)</code> pairs them up one by one, so '
            'both lists need the same length.', '''
B = dict(["a", "b"], [1, 2, 3]);
''', '''
B = dict(["a", "b", "c"], [1, 2, 3]);
publish(B);
'''),
        err('Too few values for several keys', 'Setting several keys at once needs one value per key.', '''
B = dict();
B["a", "b", "c"] = [8, 9];
''', '''
B = dict();
B["a", "b", "c"] = [8, 9, 10];
publish(B);
'''),
    ],
}

PAGES['complex-numbers'] = {
    'title': 'Complex Numbers',
    'summary': 'NC has complex numbers built in. Write them with <code>i</code> or <code>j</code>, and NC gives '
               'complex results where real math has no answer.',
    'about': [
        comp('Writing a complex number', [
            'Put <code>i</code> or <code>j</code> straight after a number for the imaginary part. '
            '<code>complex(a, b)</code> builds <em>a + bi</em> from two values. A variable called <code>i</code> '
            'does not change this: <code>3i</code> is always imaginary.'],
            math=r'z = a + b\,i \qquad i^{2} = -1',
            syntax='z = 3 + 4i;\nw = 2.5j;\nc = complex(2, -3);'),
        comp('Parts of a complex number', [
            '<code>real(z)</code> and <code>imag(z)</code> give the two parts. <code>|z|</code> is the distance '
            'from zero, <code>angle(z)</code> the angle in radians, and <code>conj(z)</code> flips the sign of '
            'the imaginary part.'],
            math=r'|z| = \sqrt{a^{2} + b^{2}} \qquad \arg z = \operatorname{atan2}(b, a) \qquad \bar{z} = a - b\,i',
            syntax='real(z)\nimag(z)\n|z|\nangle(z)\nconj(z)'),
        comp('Arithmetic', [
            'All the arithmetic operators work on complex numbers, and you can mix them with real numbers.'],
            math=r'(a + bi)(c + di) = (ac - bd) + (ad + bc)\,i',
            syntax='a + b\na * b\na / b\nz ^ 2'),
        comp('Complex results from real input', [
            'Where real math has no answer, NC gives the complex one: <code>sqrt(-4)</code> is <code>2i</code> '
            'and <code>log(-1)</code> is <em>πi</em>.'],
            math=r'\sqrt{-4} = 2i \qquad \ln(-1) = \pi i \qquad e^{i\pi/2} = i',
            syntax='sqrt(-4)\nlog(-1)'),
    ],
    'examples': {
        'basic': ex('Create and take apart', 'Write a complex number and read its parts.', '''
z = 3 + 4i;
publish(z, complex(2, -3));
publish(real(z), imag(z));
publish(|z|, conj(z));
publish(angle(1i));
'''),
        'mid': ex('Complex arithmetic', 'Combine two complex numbers with each operator.', '''
a = 2 + 3i;
b = 1 - 1i;
publish(a + b, a - b);
publish(a * b, a / b);
publish((1 + 1i) ^ 2, 1i * 1i);
publish(sqrt(-4), log(-1));
'''),
        'strong': ex('Roots of a quadratic', 'When the discriminant is negative, the roots are complex. '
                     'Putting a root back into the equation gives zero.', '''
a = 1; b = 2; c = 5;
D = sqr(b) - 4 * a * c;
x1 = (-b + sqrt(D)) / (2 * a);
x2 = (-b - sqrt(D)) / (2 * a);
publish("discriminant:", D);
publish("roots:", x1, x2);
publish("check x1:", a * sqr(x1) + b * x1 + c);
publish("conjugates?", x2 == conj(x1));
'''),
    },
    'errors': [
        err('The wrong imaginary unit', 'Only <code>i</code> and <code>j</code> mark the imaginary part.', '''
z = 3 + 4k;
''', '''
z = 3 + 4i;
publish(z);
'''),
    ],
}

PAGES['loops'] = {
    'title': 'Loops',
    'summary': 'Repeat statements with <code>for</code> (a set number of times) or <code>while</code> '
               '(as long as a condition holds). Every loop ends with its own keyword.',
    'about': [
        comp('for … fend', [
            'A <code>for</code> loop runs its body once for each value in a range or list. The header ends with '
            'a colon and the loop ends with <code>fend</code>.'],
            math=r'\sum_{k=1}^{100} k = 5050',
            syntax='for k = [1:5]:\n   # runs for k = 1, 2, 3, 4, 5\nfend'),
        comp('Steps and lists', [
            'Use <code>[a:step:b]</code> for another step, or give a list of values to loop over.'],
            syntax='for t = [0:0.5:2]:\n   ...\nfend\nfor v = [10, 20, 30]:\n   ...\nfend'),
        comp('while … wend', [
            'A <code>while</code> loop checks its condition before every pass and stops as soon as the condition '
            'is false. It ends with <code>wend</code>. Make sure the body changes something the condition '
            'depends on, or the loop never stops.'],
            syntax='while condition:\n   ...\nwend'),
        comp('while not', [
            '<code>while not</code> runs as long as the condition is false, so it stops as soon as the '
            'condition becomes true.'],
            syntax='while not condition:\n   ...\nwend'),
        comp('break and continue', [
            '<code>break</code> leaves the loop at once. <code>continue</code> skips the rest of this pass and '
            'goes on with the next one.'],
            syntax='for k = [1:10]:\n   if k == 4:\n      break;\n   iend\nfend'),
        comp('Loops inside loops', [
            'Loops can be nested to any depth, and you can mix <code>for</code>, <code>while</code>, '
            '<code>while not</code> and <code>if</code> blocks freely. Indent each level so the matching '
            '<code>fend</code> and <code>wend</code> are easy to see. The NC test scripts nest them up to '
            '100 levels deep.'],
            syntax='for i = [1:2]:\n   for j = [1:2]:\n      ...\n   fend\nfend'),
    ],
    'examples': {
        'basic': ex('Add up 1 to 100', 'A <code>for</code> loop that keeps a running total.', '''
total = 0;
for k = [1:100]:
   total = total + k;
fend
publish("sum of 1..100 =", total);
'''),
        'mid': ex('while and while not', 'Double a number until it passes 50, then count up until a level is reached.', '''
n = 1;
while n < 50:
   n = n * 2;
wend
publish("first power of 2 above 50:", n);

level = 0;
while not level >= 3:
   level = level + 1;
   publish("level", level);
wend
'''),
        'strong': ex('Nested loops, break and continue', 'Four nested loops of two passes each run the innermost '
                     'line 2⁴ = 16 times. The last loop skips odd numbers and stops at 8.', '''
count = 0;
for i1 = [1:2]:
   for i2 = [1:2]:
      for i3 = [1:2]:
         for i4 = [1:2]:
            count = count + 1;
         fend
      fend
   fend
fend
publish("nested passes:", count);

for k = [1:20]:
   if k % 2 == 1:
      continue;
   iend
   if k > 8:
      break;
   iend
   publish("even", k);
fend
'''),
    },
    'errors': [
        err('A loop without its end word', 'A <code>for</code> loop ends with <code>fend</code>.', '''
for k = [1:3]:
   publish(k);
''', '''
for k = [1:3]:
   publish(k);
fend
'''),
        err('A missing colon', 'The <code>for</code> line ends with <code>:</code>.', '''
for k = [1:3]
   publish(k);
fend
''', '''
for k = [1:3]:
   publish(k);
fend
'''),
        err('The wrong end word', 'Each block has its own end word: <code>while</code> ends with '
            '<code>wend</code>, not <code>iend</code> or <code>fend</code>.', '''
k = 0;
while k < 3:
   k = k + 1;
iend
''', '''
k = 0;
while k < 3:
   k = k + 1;
wend
publish(k);
'''),
    ],
}

PAGES['conditional-operators'] = {
    'title': 'Conditional Operators',
    'summary': 'Make decisions with <code>if</code>, <code>if not</code>, <code>elseif</code> and <code>else</code>. '
               'Every <code>if</code> block ends with <code>iend</code>.',
    'about': [
        comp('if … iend', [
            'The body runs only when the condition is true. The header ends with a colon, and the block ends '
            'with <code>iend</code>.'],
            syntax='if condition:\n   ...\niend'),
        comp('if not', [
            '<code>if not</code> runs the body when the condition is false.'],
            syntax='if not condition:\n   ...\niend'),
        comp('else', [
            'Add <code>else:</code> for what to do when the condition is false. One <code>iend</code> closes '
            'the whole block.'],
            syntax='if condition:\n   ...\nelse:\n   ...\niend'),
        comp('elseif', [
            'Test several conditions in turn with <code>elseif</code>. NC runs the first branch whose '
            'condition is true and skips the rest; <code>else</code> catches everything left over.'],
            syntax='if condition_1:\n   ...\nelseif condition_2:\n   ...\nelse:\n   ...\niend'),
        comp('Nested decisions', [
            'An <code>if</code> block can sit inside another, inside a loop, or both. Each one needs its own '
            '<code>iend</code>.'],
            syntax='if A == 1:\n   if B == 2:\n      ...\n   iend\niend'),
    ],
    'examples': {
        'basic': ex('A simple check', 'Print a warning only when the temperature is too high.', '''
temperature = 105;
if temperature > 100:
   publish("Warning: above boiling point");
iend
if not temperature > 120:
   publish("Below the safety limit");
iend
'''),
        'mid': ex('Grading with elseif', 'The first matching branch wins.', '''
for score = [95, 83, 71, 40]:
   if score >= 90:
      publish(score, "-> Grade A");
   elseif score >= 80:
      publish(score, "-> Grade B");
   elseif score >= 70:
      publish(score, "-> Grade C");
   else:
      publish(score, "-> Retake");
   iend
fend
'''),
        'strong': ex('Nested decisions', 'Six nested checks, in the style of the NC test scripts. The count shows '
                     'how many levels passed; the <code>else</code> chain does the same with the opposite tests.', '''
A = 1; B = 2; C = 3; D = 4; E = 5; F = 6;
count = 0;
if A == 1:
   count = count + 1;
   if B == 2:
      count = count + 1;
      if C == 3:
         count = count + 1;
         if not (D != 4):
            count = count + 1;
            if E == 5:
               count = count + 1;
               if F == 6:
                  count = count + 1;
               iend
            iend
         iend
      iend
   iend
iend
publish("levels passed:", count);

hits = 0;
if A != 1:
   hits = hits;
else:
   hits = hits + 1;
   if B != 2:
      hits = hits;
   elseif C == 3:
      hits = hits + 1;
   iend
iend
publish("else / elseif branches taken:", hits);
'''),
    },
    'errors': [
        err('An if without iend', 'Every <code>if</code> block is closed with <code>iend</code>.', '''
x = 5;
if x > 3:
   publish("big");
''', '''
x = 5;
if x > 3:
   publish("big");
iend
'''),
        err('= instead of ==', '<code>=</code> assigns a value; to compare, use <code>==</code>.', '''
x = 5;
if x = 5:
   publish("five");
iend
''', '''
x = 5;
if x == 5:
   publish("five");
iend
'''),
        err('else if written as two words', 'NC writes it as one word: <code>elseif</code>.', '''
x = 5;
if x > 7:
   publish("a");
else if x > 1:
   publish("b");
iend
''', '''
x = 5;
if x > 7:
   publish("a");
elseif x > 1:
   publish("b");
iend
'''),
    ],
}

PAGES['binary-operators'] = {
    'title': 'Binary Operators',
    'summary': 'Compare two values with <code>==</code>, <code>!=</code>, <code>&gt;</code>, <code>&lt;</code>, '
               '<code>&gt;=</code> and <code>&lt;=</code>. Each comparison gives <code>true</code> or <code>false</code>.',
    'about': [
        comp('The comparison operators', [
            'A comparison takes a value on each side and gives a true/false result.'],
            table=[('Operator', 'Meaning', 'Example', 'Result'),
                   ('<code>==</code>', 'equal to', '<code>5 == 5.0</code>', 'true'),
                   ('<code>!=</code>', 'not equal to', '<code>3 != 4</code>', 'true'),
                   ('<code>&gt;</code>', 'greater than', '<code>2 &gt; 3</code>', 'false'),
                   ('<code>&lt;</code>', 'less than', '<code>2 &lt; 3</code>', 'true'),
                   ('<code>&gt;=</code>', 'greater than or equal to', '<code>3 &gt;= 3</code>', 'true'),
                   ('<code>&lt;=</code>', 'less than or equal to', '<code>2 &lt;= 1</code>', 'false')],
            syntax='A == B\nA != B\nA > B\nA < B\nA >= B\nA <= B'),
        comp('Comparing expressions', [
            'Both sides can be full expressions; NC works them out before comparing. Arithmetic is done first, '
            'so <code>A + B == C</code> means <code>(A + B) == C</code>.'],
            math=r'(A + B) = C \;\Rightarrow\; \text{true}',
            syntax='(A + B) == C\nsqrt(S) > Z - 1'),
        comp('Storing and counting results', [
            'A result can be stored in a variable or collected in a list. In arithmetic, <code>true</code> '
            'counts as 1 and <code>false</code> as 0, so adding results counts how many passed.'],
            syntax='A1 = (A + B) == C;\npublish([A1, A2, A3]);\ncount = count + (A == 1);'),
        comp('Text and decimals', [
            'Text compares letter by letter, and capital letters differ from small ones. For decimal results, '
            'compare after rounding (see <a href="arithmetic.html">Arithmetic</a>).'],
            syntax='"abc" == "abc"\n"apple" < "banana"'),
    ],
    'examples': {
        'basic': ex('Every comparison', 'One comparison of each kind.', '''
publish(5 == 5.0, 3 != 4);
publish(2 > 3, 2 < 3);
publish(3 >= 3, 2 <= 1);
publish("NC" == "nc", "apple" < "banana");
'''),
        'mid': ex('Checking calculations', 'Compare primitive results against known values and collect the answers '
                  'in one list, as the NC test scripts do.', '''
A = 1; B = 2.0; C = 3.0; D = 4.0; E = 9.0;
S = 144.0; Z = 12.0; Y = 7.0; R = 343;
A1 = (A + B) == C;
A2 = sqrt(S) == Z;
A3 = cube(Y) == R;
A4 = (E // D) == B;
A5 = (E % D) == A;
A6 = 5! == 120.0;
publish("results:", [A1, A2, A3, A4, A5, A6]);
'''),
        'strong': ex('Counting passes in a loop', 'Add each comparison to its counter on every pass. '
                     '128 passes of each test should give 128 every time.', '''
A = 1; B = 2; C = 3; D = 4;
ecount = 0; necount = 0; gcount = 0; gecount = 0; lcount = 0; lecount = 0;
for k = [1:128]:
   ecount  = ecount  + (A == 1);
   necount = necount + (A != B);
   gcount  = gcount  + (D > C);
   gecount = gecount + (C >= (A + B));
   lcount  = lcount  + (A < C);
   lecount = lecount + (C <= (A + B));
fend
publish("==, !=, >, >=, <, <= :", ecount, necount, gcount, gecount, lcount, lecount);
'''),
    },
    'errors': [
        err('=< instead of <=', 'The comparison sign comes first: <code>&lt;=</code> and <code>&gt;=</code>.', '''
publish(3 =< 4);
''', '''
publish(3 <= 4);
'''),
        err('<> for "not equal"', 'NC writes "not equal" as <code>!=</code>.', '''
publish(3 <> 4);
''', '''
publish(3 != 4);
'''),
    ],
}

PAGES['logical-operators'] = {
    'title': 'Logical Operators',
    'summary': 'Combine true/false results with AND, OR, NAND, NOR and NOT, and test whether a value is in a list.',
    'about': [
        comp('AND, OR, NAND and NOR', [
            'Each operator takes two true/false values. NAND and NOR are the opposites of AND and OR. '
            'Wrap each comparison in brackets when you combine them, as in <code>(A &gt; 1) &amp;&amp; (B &lt; 5)</code>.'],
            math=r'A \land B \qquad A \lor B \qquad \lnot(A \land B) \qquad \lnot(A \lor B)',
            table=[('A', 'B', 'A &amp;&amp; B', 'A || B', 'A !&amp; B', 'A !| B'),
                   ('true', 'true', 'true', 'true', 'false', 'false'),
                   ('true', 'false', 'false', 'true', 'true', 'false'),
                   ('false', 'true', 'false', 'true', 'true', 'false'),
                   ('false', 'false', 'false', 'false', 'true', 'true')],
            syntax='A && B     # AND\nA || B     # OR\nA !& B     # NAND\nA !| B     # NOR'),
        comp('NOT', [
            '<code>not</code> flips a result. Inside an expression, put what it applies to in brackets: '
            '<code>not (x &gt; 3)</code>. In an <code>if</code> or <code>while</code> header the brackets are '
            'optional.'],
            math=r'\lnot\,\text{true} = \text{false}',
            syntax='not (condition)\nif not x > 3:'),
        comp('in and not in', [
            '<code>x in A</code> is true when <code>x</code> is found in <code>A</code>; <code>x not in A</code> is the '
            'opposite. <code>is_in</code> and <code>is_not_in</code> are older spellings of the same operators. What '
            '"found" means depends on <code>A</code>:'],
            math=r'x \in A \qquad x \notin A',
            table=[['A is ...', 'x in A is true when ...', 'Example'],
                   ['a vector or a matrix of any shape', 'x equals one of the elements', '<code>5 in [1, 5; 7, 8]</code>'],
                   ['a matrix, with x a row', 'x equals a whole row', '<code>[3, 4] in [1, 2; 3, 4]</code>'],
                   ['a dictionary', 'x is one of the keys', '<code>"a" in dict(["a", "b"], [1, 2])</code>'],
                   ['text', 'x is a piece of the text', '<code>"ell" in "hello"</code>'],
                   ['empty <code>[]</code>', 'never', '<code>5 in []</code> is false']],
            syntax='if x in L:\n   ...\niend\nif name not in ["red", "green"]:\n   ...\niend'),
        comp('in inside bigger expressions', [
            '<code>in</code> binds more loosely than arithmetic: <code>3 + 1 in L</code> checks 4. It combines with '
            '<code>&amp;&amp;</code> and <code>||</code> like any comparison. In a loop header, '
            '<code>for k in [1, 2, 3]:</code> keeps its meaning of "for each element".'],
            syntax='(3 in L) && (10 not in L)\nb = 3 + 1 in L;\nfor k in [1, 2, 3]:\n   ...\nfend'),
        comp('Checking for nan and empty', [
            '<code>is_nan(x)</code> checks for not-a-number and <code>is_empty(x)</code> checks for an empty '
            'list. They give 1 for yes and 0 for no.'],
            syntax='is_nan(0/0)\nis_empty([])'),
    ],
    'examples': {
        'basic': ex('Truth tables', 'Every combination of true and false for each operator.', '''
T = true; F = false;
publish("AND :", T && T, T && F, F && T, F && F);
publish("OR  :", T || T, T || F, F || T, F || F);
publish("NAND:", T !& T, T !& F, F !& T, F !& F);
publish("NOR :", T !| T, T !| F, F !| T, F !| F);
publish("NOT :", not (T), not (F));
'''),
        'mid': ex('Range and safety checks', 'Combine comparisons to check that readings are in range.', '''
temp = 72; pressure = 2.1;
in_range = (temp >= 20) && (temp <= 80);
alarm = (temp > 100) || (pressure > 3);
publish("in range:", in_range, " alarm:", alarm);
publish("neither high:", (temp > 100) !| (pressure > 3));
if (temp > 50) && not (pressure > 3):
   publish("warm but safe");
iend
'''),
        'strong': ex('Membership and special values', 'Check list membership, then find the forms that give '
                     'not-a-number.', '''
AA = [1:100];
publish("51 in 1..100     :", 51 in AA);
publish("121 not in 1..100:", 121 not in AA);
publish("colour check        :", "green" in ["red", "green", "blue"]);
publish("is_empty([])        :", is_empty([]));
INF = 1 / 0;
publish("nan forms:", [is_nan(0/0), is_nan(INF/INF), is_nan(INF - INF), is_nan(0 * INF)]);
publish("not nan  :", [is_nan(1/0), is_nan(INF + INF), is_nan(5)]);
'''),
    },
    'errors': [
        err('not without brackets inside an expression', 'Inside a larger expression, put the condition after '
            '<code>not</code> in brackets.', '''
x = 5;
y = not x > 3 && true;
''', '''
x = 5;
y = not (x > 3) && true;
publish(y);
'''),
        err('A single & for AND', 'AND is written <code>&amp;&amp;</code> and OR is written <code>||</code>.', '''
publish(true & false);
''', '''
publish(true && false, true || false);
'''),
        err('in with a number on the right', '<code>in</code> looks inside a matrix, a dict or text.', '''
publish(3 in 5);
''', '''
publish(3 in [1:5]);
'''),
    ],
}

# ============================================================== FUNCTIONS
IMG_F = 'Images/Neural_Code/Language_Guide/Functions/'
IMG_C = 'Images/Neural_Code/Language_Guide/Classes/'

SHAPE = '''class Shape():
   function base(w, h=1, label="shape"):
      base.w = w;
      base.h = h;
      base.label = label;
   fnend
   function A = area(scale=1):
      A = base.w * base.h * scale;
   fnend
csend
'''

G = '''function y = G(a, b=100, c=1000):
   y = a + b + c;
fnend
'''

INFO_CLASSES = '''class Shape():
   private secret;
   function base(w, h=1, label="shape"):
      base.w = w;
      base.h = h;
      base.label = label;
      base.ok = true;
      base.tags = [1, 2, 3];
      base.n = int32(5);
      base.secret = 42;
   fnend
   function A = area(scale=1):
      A = base.w * base.h * scale;
   fnend
   function [p, q] = dims():
      p = base.w;
      q = base.h;
   fnend
   function seeAll():
      publish("inside the class, base.base also shows the private field:", base.base);
   fnend
csend
'''

PAGES['customize-functions'] = {
    'title': 'Customize Functions',
    'summary': 'Write your own functions with <code>function … fnend</code>: inputs, one or several outputs, '
               'functions with no inputs, functions passed by name, and functions that call themselves.',
    'about': [
        comp('Defining a function', [
            'Start with <code>function</code>, name the output, the function and its inputs, end the header with '
            'a colon and close the body with <code>fnend</code>. Assign the output variable inside the body. '
            'A function with no output leaves out <code>output =</code>.'],
            math=r'y = f(a, b)',
            syntax='function y = Add(a, b):\n   y = a + b;\nfnend\n\nfunction show(x):\n   publish("x is", x);\nfnend'),
        comp('Where a function can go', [
            'NC reads every function definition before the script starts to run, so a function can be called '
            'on a line above its definition. Many scripts keep their functions at the bottom, after the main work.'],
            syntax='publish(twice(4));   # 8\n\nfunction y = twice(x):\n   y = 2 * x;\nfnend'),
        comp('Several outputs', [
            'List the outputs in square brackets in the header and receive them the same way.'],
            math=r'a = q \cdot b + r, \qquad 0 \le r < b',
            syntax='function [q, r] = divmod(a, b):\n   q = a // b;\n   r = a % b;\nfnend\n[q, r] = divmod(17, 5);   # 3 2'),
        comp('Functions with no inputs', [
            'A function that takes no inputs can be called by its name alone: <code>z = seven;</code> runs '
            '<code>seven()</code>. A header without brackets, <code>function hello:</code>, defines such a '
            'function too.'],
            syntax='function y = seven():\n   y = 7;\nfnend\nz = seven;'),
        comp('Passing a function by name', [
            '<code>@name</code> refers to a function without calling it, so it can be stored or passed on. '
            '<code>feval(@name, ...)</code> calls it with the values that follow.'],
            syntax='g = @Add;\ng(1, 2)\nfeval(@Add, 1, 2)'),
        comp('Recursion', [
            'A function can call itself. The factorial below carries its running product in a second input.'],
            math=r'n! = n \cdot (n-1)!,\qquad 1! = 1',
            syntax='function y = fact(n, acc=1):\n   if n <= 1:\n      y = acc;\n   else:\n      y = fact(n - 1, acc=acc * n);\n   iend\nfnend'),
        comp('More about inputs', [
            'Inputs can have default values and can be given by name: see '
            '<a href="defaults-named-inputs.html">Defaults &amp; Named Inputs</a>. One name can have several '
            'versions with different inputs: see <a href="overloads.html">Overloads</a>. Long headers and calls '
            'can be split over lines: see <a href="line-continuation.html">Line Continuation</a>.']),
    ],
    'examples': {
        'basic': ex('A first function', 'Define a function, call it, and use the result.', '''
function y = Add(a, b):
   y = a + b;
fnend

C = Add(10, 15);
publish("Add(10, 15) =", C);
publish("nested:", Add(Add(1, 2), 3));
'''),
        'mid': ex('Outputs, no inputs and references', 'Two outputs, a function called by name alone, and a '
                  'function passed with <code>@</code>.', '''
function [q, r] = divmod(a, b):
   q = a // b;
   r = a % b;
fnend
[q, r] = divmod(17, 5);
publish("divmod(17, 5) ->", q, r);

function y = seven():
   y = 7;
fnend
z = seven;
publish("z =", z);

function y = Add(a, b):
   y = a + b;
fnend
g = @Add;
publish("g(1, 2) =", g(1, 2), "  feval(@Add, 4, 5) =", feval(@Add, 4, 5));
'''),
        'strong': ex('Recursion and functions working together', 'A recursive factorial, a function that '
                     'uses two other functions, and calls made inside a loop.', '''
function y = fact(n, acc=1):
   if n <= 1:
      y = acc;
   else:
      y = fact(n - 1, acc=acc * n);
   iend
fnend

function y = choose(n, k):
   y = fact(n) / (fact(k) * fact(n - k));
fnend

function [lo, hi] = bounds(v):
   lo = min(v);
   hi = max(v);
fnend

publish("fact(5) =", fact(5), "  fact(10) =", fact(10));
row = [];
for k = [0:5]:
   row = [row, choose(5, k)];
fend
publish("row 5 of Pascal's triangle:", row);
[lo, hi] = bounds(row);
publish("smallest and largest:", lo, hi);
'''),
    },
    'errors': [
        err('A function without fnend', 'A function body is closed with <code>fnend</code>.', '''
function y = Add(a, b):
   y = a + b;
publish(Add(1, 2));
''', '''
function y = Add(a, b):
   y = a + b;
fnend
publish(Add(1, 2));
'''),
        err('A missing input in a multi-output call', '<code>b</code> has no default here, so it must be given. '
            '(Or give it a default: see <a href="defaults-named-inputs.html">Defaults &amp; Named Inputs</a>.)', '''
function [q, r] = divmod(a, b):
   q = a // b;
   r = a % b;
fnend
[q, r] = divmod(17);
''', '''
function [q, r] = divmod(a, b):
   q = a // b;
   r = a % b;
fnend
[q, r] = divmod(17, 3);
publish(q, r);
'''),
    ],
}


PAGES['defaults-named-inputs'] = {
    'title': 'Defaults & Named Inputs',
    'summary': 'Give an input a default value in the header, then call the function with plain values, with '
               '<code>name=value</code> pairs, or with a mix of both. The same rules hold for every built-in function.',
    'about': [
        comp('Defaults in the header', [
            'Write <code>name=value</code> in the function header to give an input a default. When a call leaves '
            'the input out, NC uses the default. Inputs without a default must always be given.',
            'Defaults can be any kind of value: a number, text, a matrix or an expression.'],
            syntax='function f(a=1, b=2, c="car"):\n   publish("a =", a, " b =", b, " c =", c);\nfnend\n\nf();              # a = 1  b = 2  c = car\nf(10);            # a = 10 b = 2  c = car\nf(10, 20, "bus"); # a = 10 b = 20 c = bus'),
        comp('Plain or named values', [
            'A plain value fills the next input in order. A named value, <code>name=value</code>, goes straight '
            'to the input with that name, so the order of named values does not matter.'],
            syntax='function C = Add(x1, x2):\n   C = x1 + x2;\nfnend\n\nC = Add(10, 15);\nC = Add(x1=10, x2=15);\nC = Add(x2=15, x1=10);   # same result'),
        comp('Mixing plain and named values', [
            'In one call you can mix both kinds, in any order. NC first places every named value, then the plain '
            'values fill the inputs that are still open, from left to right. Any input still empty after that '
            'takes its default.'],
            syntax='function F(A1, A2, A3, A4, A5):\n   ...\nfnend\nF(A2=10, A4=15, 1, 2, 3)',
            table=[['Call', 'A1', 'A2', 'A3', 'A4', 'A5'],
                   ['<code>F(A2=10, A4=15, 1, 2, 3)</code>', '1', '10', '2', '15', '3'],
                   ['<code>F(1, A3=5, 2, 3, 4)</code>', '1', '2', '5', '3', '4'],
                   ['<code>F(10, 20, A1=5, 30, 40)</code>', '5', '10', '20', '30', '40'],
                   ['<code>F(A5=5, A4=4, A3=3, A2=2, A1=1)</code>', '1', '2', '3', '4', '5']],
            figure=fig(IMG_F + 'defaults-named-inputs-01.svg',
                       'The call F(A2=10, A4=15, 1, 2, 3): named values go to A2 and A4 first, then 1, 2 and 3 '
                       'fill A1, A3 and A5 from left to right.',
                       'How NC places the values of <code>F(A2=10, A4=15, 1, 2, 3)</code>: step 1 places the named '
                       'values, step 2 fills the open inputs from left to right.')),
        comp('Skipping a default', [
            'Name the input you want to change and leave the others out. <code>G(1, c=0)</code> keeps the '
            'default of <code>b</code> and changes only <code>c</code>.'],
            syntax=G + '\nG(1)          # 1 + 100 + 1000 = 1101\nG(1, c=0)     # 1 + 100 + 0    = 101\nG(c=0, a=5)   # 5 + 100 + 0    = 105'),
        comp('Defaults that use other inputs', [
            'A default can be worked out from an earlier input, such as <code>b=a*2</code>. An input with a '
            'default may also come before one without; give the later one by name, or give both.'],
            syntax='function H(a, b=a*2):\n   ...\nfnend\nH(4)       # a = 4  b = 8\n\nfunction K(a=1, b):\n   ...\nfnend\nK(b=7)     # a = 1  b = 7\nK(5, 6)    # a = 5  b = 6'),
        comp('When a default is worked out', [
            'A default expression is worked out again at every call that needs it, inside the function: '
            '<code>t=sqrt(16)</code> gives 4 each time. Input names belong to the function only, so '
            '<code>Add(x2=x1, x1=10)</code> reads your variable <code>x1</code> for <code>x2</code> and leaves '
            'it unchanged.',
            'Only <code>name=</code> directly inside the call\'s brackets names an input. <code>G(1 == 1)</code> '
            'is still a comparison, and the text <code>"a=b"</code> is still text.'],
            syntax='function y = Fresh(t=sqrt(16)):\n   y = t;\nfnend\nFresh()      # 4\nFresh(1)     # 1'),
        comp('Built-in functions follow the same rules', [
            'Most default functions take named values too, using the input names shown on their reference '
            'pages: <code>allclose(A, B, atol=0.1)</code>, <code>round(x, decimals=2)</code>, '
            '<code>clip(v, lo=2, hi=6)</code>. A few, such as <code>sqrt</code>, take their values in order only '
            'for now; NC says so if you name one. The built-in functions are described in '
            '<a href="../../default-functions.html">Default Functions</a>.'],
            syntax='allclose(A, B, atol=0.1)\nround(3.14159, decimals=2)\nclip([1, 5, 9], lo=2, hi=6)'),
    ],
    'examples': {
        'basic': ex('Defaults in the header', 'One function called three ways: with no values, with one, and with all three.', '''
function f(a=1, b=2, c="car"):
   publish("a =", a, " b =", b, " c =", c);
fnend

f();
f(10);
f(10, 20, "bus");
'''),
        'mid': ex('Plain and named values together', 'The five-input function from the About tab, called four ways. '
                  'Named values are placed first; plain values fill the rest from left to right.', '''
function F(A1, A2, A3, A4, A5):
   publish("A1 =", A1, " A2 =", A2, " A3 =", A3, " A4 =", A4, " A5 =", A5);
fnend

F(A2=10, A4=15, 1, 2, 3);
F(1, A3=5, 2, 3, 4);
F(10, 20, A1=5, 30, 40);
F(A5=5, A4=4, A3=3, A2=2, A1=1);

function y = G(a, b=100, c=1000):
   y = a + b + c;
fnend
publish("G(1) =", G(1), "  G(1, c=0) =", G(1, c=0), "  G(c=0, a=5) =", G(c=0, a=5));
publish("G(1, a=2) =", G(1, a=2), " (a=2 is placed first, so 1 fills b)");
'''),
        'strong': ex('Defaults from other inputs, nested calls and built-ins', 'Defaults worked out from an earlier '
                     'input, a default before a required input, a named call inside a named call, input names that '
                     'stay inside the function, and named values on built-in functions.', '''
function H(a, b=a*2):
   publish("H: a =", a, " b =", b);
fnend
H(4);
H(4, 1);

function K(a=1, b):
   publish("K: a =", a, " b =", b);
fnend
K(b=7);
K(5, 6);

function y = inner(b=1):
   y = b * 100;
fnend
function y = outer(a, c=0):
   y = a + c;
fnend
publish("outer(c=inner(b=2), 1) =", outer(c=inner(b=2), 1));

x1 = 3;
function C = Add(x1, x2):
   C = x1 + x2;
fnend
publish("Add(x2=x1, x1=10) =", Add(x2=x1, x1=10), "  and x1 is still", x1);

function y = Fresh(t=sqrt(16)):
   y = t;
fnend
function y = M(v=[1, 2, 3], s="a=b"):
   y = s;
fnend
publish("Fresh() =", Fresh(), "  Fresh(1) =", Fresh(1), "  M() =", M());

A = [1, 1; 1, 1];
B = [1.05, 1; 1, 1];
publish("allclose:", allclose(A, B), allclose(A, B, atol=0.1), allclose(B=B, A=A, rtol=0.1));
publish("round:", round(3.14159), round(3.14159, decimals=2));
'''),
    },
    'errors': [
        err('A required input is missing', '<code>a</code> has no default, so every call must give it. NC quotes '
            'the header so you can see what the function expects.', G + 'r = G();', G + 'r = G(1);\npublish(r);'),
        err('Too many values', 'The header has three inputs; the call gives four.', G + 'r = G(1, 2, 3, 4);',
            G + 'r = G(1, 2, 3);\npublish(r);'),
        err('An input name that does not exist', 'A named value must use a name from the header. NC lists the '
            'names it has.', G + 'r = G(1, d=5);', G + 'r = G(1, c=5);\npublish(r);'),
        err('The same input given twice', 'Each input can be given once: either by position or by name.',
            G + 'r = G(a=1, a=2);', G + 'r = G(a=2);\npublish(r);'),
        err('Not enough open inputs for the plain values', 'Two values are named, which leaves one open input '
            'for two plain values.', G + 'r = G(b=1, c=2, 3, 4);', G + 'r = G(b=1, c=2, 3);\npublish(r);'),
        err('A built-in that does not take names yet', '<code>sqrt</code> takes its value in order only.',
            'r = sqrt(x=4);', 'r = sqrt(4);\npublish(r);'),
        err('A default that cannot be worked out', 'The default of <code>b</code> uses a variable that does not '
            'exist. NC reports it when a call needs the default; a call that gives <code>b</code> still works.', '''
function y = DefaultFails(a, b=nosuch+1):
   y = a + b;
fnend
r = DefaultFails(1);
''', '''
function y = DefaultFails(a, b=nosuch+1):
   y = a + b;
fnend
r = DefaultFails(1, 2);
publish(r);
'''),
        err('= with no default after it', 'In a header, <code>b=</code> must be followed by the default value. '
            'Leave out the <code>=</code> if <code>b</code> has no default.', '''
function y = Bad(a, b=):
   y = a;
fnend
''', '''
function y = Bad(a, b=0):
   y = a + b;
fnend
publish(Bad(5));
'''),
        err('A named value with nothing after =', 'In a call, <code>a=</code> must be followed by a value.',
            G + 'r = G(a=);', G + 'r = G(a=1);\npublish(r);'),
        err('The same input name twice in a header', 'Every input in a header needs its own name.', '''
function y = Twice(x, x):
   y = x;
fnend
''', '''
function y = Twice(x, k):
   y = x * k;
fnend
publish(Twice(4, 2));
'''),
    ],
}

PAGES['overloads'] = {
    'title': 'Overloads',
    'summary': 'One name can have several versions with different numbers of inputs. NC runs the version that '
               'fits each call; when several fit, the one that needs the fewest defaults wins.',
    'about': [
        comp('Several versions of one name', [
            'Define a function again with a different number of inputs and NC keeps both versions. Each call '
            'runs the version whose inputs fit it.'],
            syntax='function y = combine(a):\n   y = a;\nfnend\nfunction y = combine(a, b):\n   y = a + b;\nfnend\n\ncombine(1)      # 1\ncombine(1, 2)   # 3'),
        comp('How NC chooses a version', [
            'When more than one version fits a call, NC takes the one that needs the fewest defaults to be '
            'filled in. <code>P(9)</code> fits both versions below, but <code>P(a)</code> needs no default and '
            '<code>P(a, b=2)</code> needs one, so <code>P(a)</code> runs.'],
            syntax='function y = P(a):\n   y = 1;\nfnend\nfunction y = P(a, b=2):\n   y = 2;\nfnend',
            table=[['Call', 'Versions that fit', 'Defaults needed', 'Runs'],
                   ['<code>P(9)</code>', 'P(a), P(a, b=2)', '0 and 1', 'P(a) &rarr; 1'],
                   ['<code>P(9, 9)</code>', 'P(a, b=2)', '0', 'P(a, b) &rarr; 2'],
                   ['<code>Q()</code>', 'Q(a=1) (the other needs a)', '1', 'Q(a=1) &rarr; 1'],
                   ['<code>Q(5)</code>', 'Q(a=1), Q(a, b=2, c=3)', '0 and 2', 'Q(a=1) &rarr; 1'],
                   ['<code>Q(5, 6)</code>', 'Q(a, b=2, c=3)', '1', 'Q(a, b, c) &rarr; 3']],
            figure=fig(IMG_F + 'overloads-01.svg',
                       'Choosing a version: keep the versions that fit the call, then pick the one that needs '
                       'the fewest defaults.',
                       'Choosing a version of <code>P</code> for the call <code>P(9)</code>.')),
        comp('Redefining a function', [
            'Defining a function again with the <em>same</em> number of inputs replaces the earlier version. '
            'NC reads every definition before the script runs, so the last one in the script is used for '
            '<em>every</em> call, even a call written above it.'],
            syntax='function y = sq(x):\n   y = x * x;\nfnend\npublish(sq(5));   # 6, not 25\nfunction y = sq(x):\n   y = x + 1;\nfnend'),
        comp('Overloads with several outputs and references', [
            'Versions may have different outputs too. <code>feval(@name, ...)</code> chooses the version the same '
            'way as a direct call, and so does a call made inside a loop.'],
            syntax='feval(@combine, 4, 5)    # 9: the two-input version'),
    ],
    'examples': {
        'basic': ex('Two versions of one function', 'One name, two versions. Each call runs the version that fits.', '''
function y = combine(a):
   y = a;
fnend
function y = combine(a, b):
   y = a + b;
fnend
publish("combine(1) =", combine(1), "  combine(1, 2) =", combine(1, 2));
publish("feval(@combine, 4, 5) =", feval(@combine, 4, 5));
'''),
        'mid': ex('Fewest defaults wins', 'Calls that fit more than one version run the version that needs the '
                  'fewest defaults.', '''
function y = P(a):
   y = 1;
fnend
function y = P(a, b=2):
   y = 2;
fnend
publish("P(9) ->", P(9), "  P(9, 9) ->", P(9, 9), "  P(a=9, b=1) ->", P(a=9, b=1));

function y = Q(a=1):
   y = 1;
fnend
function y = Q(a, b=2, c=3):
   y = 3;
fnend
publish("Q() ->", Q(), "  Q(5) ->", Q(5), "  Q(5, 6) ->", Q(5, 6));
'''),
        'strong': ex('Area of several shapes', 'One name <code>area</code> for a circle (one input), a rectangle '
                     '(two) and a triangle (three, by Heron\'s formula), versions mixed inside a loop, and a version with a '
                     'default next to one without.', '''
function A = area(r):
   A = pi * r ^ 2;
fnend
function A = area(w, h):
   A = w * h;
fnend
function A = area(a, b, c):
   s = (a + b + c) / 2;
   A = sqrt(s * (s - a) * (s - b) * (s - c));
fnend
publish("circle r=1:", area(1), "  rectangle 2x3:", area(2, 3), "  triangle 3-4-5:", area(3, 4, 5));

total = 0;
for r = [1:3]:
   total = total + area(r) + area(r, 2 * r);
fend
publish("sum over r = 1, 2, 3 of a circle plus an r x 2r rectangle:", total);

function y = sq(x):
   y = x * x;
fnend
function y = sq(x, k=1):
   y = x * x * k;
fnend
publish("sq(5) ->", sq(5), "  sq(4, 10) ->", sq(4, 10));
'''),
    },
    'errors': [
        err('No version fits the call', 'Neither version of <code>combine</code> takes three values. NC lists the '
            'versions it has.', '''
function y = combine(a):
   y = a;
fnend
function y = combine(a, b):
   y = a + b;
fnend
r = combine(1, 2, 3);
''', '''
function y = combine(a):
   y = a;
fnend
function y = combine(a, b):
   y = a + b;
fnend
r = combine(combine(1, 2), 3);
publish(r);
'''),
        err('A new version with the same number of inputs', 'The second <code>Y</code> also has one input, so it '
            'replaces the first: the input <code>a</code> no longer exists. Give each version a different '
            'number of inputs, or a different name.', '''
function y = Y(a=1):
   y = 1;
fnend
function y = Y(b=2):
   y = 2;
fnend
r = Y(a=5);
''', '''
function y = Ya(a=1):
   y = 1;
fnend
function y = Yb(b=2):
   y = 2;
fnend
publish(Ya(a=5), Yb(b=5));
'''),
    ],
}

PAGES['line-continuation'] = {
    'title': 'Line Continuation',
    'summary': 'End a line with <code>~~</code> to carry a long header or a long call on to the next line. '
               'Named values and defaults read exactly as they would on one line.',
    'about': [
        comp('Continuing a line with ~~', [
            'Put <code>~~</code> at the end of a line to say that the statement goes on in the next line. It '
            'works between any two items: the inputs of a function header, the values of a call, the brackets of '
            'a class header and the parts of a long expression.',
            'Line up the continued lines however you like; NC ignores the spaces at their start.'],
            syntax='function y = f(a=1, ~~\n               b=2, ~~\n               c="car"):\n   y = a + b;\nfnend'),
        comp('Long calls', [
            'A call with many named values is easier to read one value per line.'],
            syntax='publish("f(b=10) =", f(b=10, ~~\n        a=5));'),
        comp('Class headers, constructors and parent(...)', [
            'The same works for a class header, a constructor\'s inputs, the call that creates an object and the '
            'call to <code>parent</code>.'],
            syntax='class Square(Shape ~~\n             ):\n   function base(side=2):\n      parent(side, ~~\n             h=side);\n   fnend\ncsend'),
        comp('Where ~~ goes', [
            '<code>~~</code> must be the last thing on its line. NC also joins the lines of a call or header that '
            'is still inside open brackets, but <code>~~</code> makes the intent clear to every reader.'],
            syntax='x = 1 + ~~\n    2;'),
    ],
    'examples': {
        'basic': ex('A long header and a long call', 'A function header and a call, each split over several lines.', '''
function y = f(a=1, ~~
               b=2, ~~
               c="car"):
   y = a + b;
fnend
publish("f() =", f());
publish("f(b=10) =", f(b=10, ~~
        a=5));
'''),
        'mid': ex('Classes over several lines', 'A class header, a constructor, an object and a '
                  '<code>parent</code> call, each continued with <code>~~</code>.', '''
class Shape( ~~
   ):
   function base(w, ~~
                 h=1, ~~
                 label="shape"):
      base.w = w;
      base.h = h;
   fnend
csend
s = Shape(h=3, ~~
    2);
publish("Shape:", s.w, s.h);

class Square(Shape ~~
             ):
   function base(side=2):
      parent(side, ~~
             h=side);
   fnend
csend
q = Square(side=7);
publish("Square:", q.w, q.h);
'''),
        'strong': ex('Several outputs and long expressions', 'A multi-output function and a long expression, both '
                     'continued.', '''
function [q, r] = divide(a, ~~
                         b=3):
   q = a // b;
   r = a % b;
fnend
[q, r] = divide(b=5, ~~
         17);
publish("divide(b=5, 17) ->", q, r);

total = 1 + 2 + 3 + ~~
        4 + 5 + 6;
label = "Neural" + " " + ~~
        "Colindes";
publish(total, label);
'''),
    },
    'errors': [
        err('~~ in the middle of a line', '<code>~~</code> must end its line; anything after it on the same line '
            'is not read as part of the header.', '''
function y = f(a=1, ~~ b=2):
   y = a + b;
fnend
''', '''
function y = f(a=1, ~~
               b=2):
   y = a + b;
fnend
publish(f());
'''),
    ],
}


# ============================================================== CLASSES
PAGES['default-class'] = {
    'title': 'Default Class',
    'summary': 'A class bundles data (fields) with the functions that work on it (methods). '
               'Define one with <code>class … csend</code>.',
    'about': [
        comp('Defining a class', [
            'Start with <code>class Name():</code> and end with <code>csend</code>. Inside, the function named '
            '<code>base</code> is the constructor: it runs when you create an object and sets up its fields '
            'as <code>base.field</code>.'],
            syntax='class Shape():\n   function base(w, h):\n      base.w = w;\n      base.h = h;\n   fnend\ncsend'),
        comp('Methods', [
            'Other functions inside the class are methods. They read and change the fields through '
            '<code>base</code>.'],
            syntax='   function A = area():\n      A = base.w * base.h;\n   fnend'),
        comp('Creating and using objects', [
            'Call the class name like a function to create an object. Read a field with <code>obj.field</code> '
            'and call a method with <code>obj.method()</code>. Each object keeps its own fields.'],
            syntax='s = Shape(2, 3);\ns.w\ns.area()'),
        comp('Defaults and named inputs', [
            'The constructor and methods accept default values and named inputs, exactly like '
            'custom functions. The details are on <a href="constructors-methods.html">Constructor &amp; Method Inputs</a>.'],
            syntax='function base(w, h=1, label="shape"):\ns = Shape(h=3, 2);'),
        comp('Private fields', [
            'Declare a field with <code>private name;</code> at the top of the class to keep it inside the '
            'class: methods can use it, but it is hidden from the outside.'],
            syntax='class Account():\n   private pin;\n   ...\ncsend'),
        comp('Chaining fields, indexes and methods', [
            'Fields, indexes and method calls can follow one another to any depth: <code>o.inn.m[1, 0]</code> reads '
            'element [1, 0] of the matrix <code>m</code> inside the object <code>inn</code> inside <code>o</code>, '
            'and <code>o.inn.twice()</code> calls a method on the inner object. The same works on dictionaries '
            '(<code>d["a"][1]</code>, <code>d.keys()</code>) and on the objects that <code>load_json</code> and the '
            'other <code>load_</code> functions give (<code>J.store.book[1].title</code>).',
            'A method that changes a field, such as <code>i.bump();</code>, changes the object in place; '
            '<code>i = i.bump();</code> gives the same result.'],
            syntax='o.inn.m[1, 0]\no.inn.twice()\no.list[2]\nd["a"][1]\nJ.store.book[1].title'),
        comp('Looking inside a class', [
            '<code>Class.info</code> lists the constructor and methods with their inputs, and <code>obj.base</code> '
            'shows an object\'s fields (private fields are left out). More on <a href="info-and-base.html">Looking Inside a Class</a>.'],
            syntax='Shape.info\ns.base'),
        comp('History: lineage and rewind', [
            '<code>obj.lineage()</code> lists the calls that have changed an object, starting with its creation. '
            'Declare the class as <code>reversible class</code> and <code>obj.rewind(n)</code> also gives the '
            'object as it was <code>n</code> changes ago.'],
            syntax='reversible class Counter():\n   ...\ncsend\nc.lineage()\nc = c.rewind(1);'),
    ],
    'examples': {
        'basic': ex('A first class', 'A rectangle with a width, a height and an area method.', '''
class Shape():
   function base(w, h):
      base.w = w;
      base.h = h;
   fnend
   function A = area():
      A = base.w * base.h;
   fnend
csend

s = Shape(2, 3);
publish("w =", s.w, " h =", s.h);
publish("area =", s.area());
'''),
        'mid': ex('Methods that change an object', 'A counter whose method updates a field. '
                  '<code>lineage</code> records each change; because the class is <code>reversible</code>, '
                  '<code>rewind</code> can step back.', '''
reversible class Counter():
   function base():
      base.n = 0;
   fnend
   function inc(k=1):
      base.n = base.n + k;
   fnend
csend

c = Counter();
c.inc(2);
c.inc(3);
c.inc();
publish("n =", c.n);
publish("history:", c.lineage());
c = c.rewind(1);
publish("after rewind(1): n =", c.n);
'''),
        'strong': ex('Defaults, names, info and privacy', 'A constructor with defaults and methods with named '
                     'inputs, then a look inside the class. The <code>Account</code> class keeps its PIN private: '
                     'it does not appear in <code>a.base</code>; reading it from outside is shown on the Syntax Error tab.', '''
class Shape():
   function base(w, h=1, label="shape"):
      base.w = w;
      base.h = h;
      base.label = label;
   fnend
   function A = area(scale=1):
      A = base.w * base.h * scale;
   fnend
   function grow(dw=1, dh=1):
      base.w = base.w + dw;
      base.h = base.h + dh;
   fnend
csend

s = Shape(h=3, 2);
publish("Shape(h=3, 2): w =", s.w, " h =", s.h, " label =", s.label);
publish("area() =", s.area(), "  area(scale=10) =", s.area(scale=10));
s.grow(dh=5);
publish("after grow(dh=5): w =", s.w, " h =", s.h);
t = Shape(4);
publish("Shape(4): w =", t.w, " h =", t.h, " label =", t.label);
Shape.info

class Account():
   private pin;
   function base(owner, pin):
      base.owner = owner;
      base.pin = pin;
   fnend
   function ok = check(p):
      ok = p == base.pin;
   fnend
csend
a = Account("asha", 1234);
publish(a.owner, a.check(1111), a.check(1234));
a.base
'''),
    },
    'errors': [
        err('Reading a private field from outside', 'A <code>private</code> field can be used by the class\'s own '
            'methods, but not read from outside. Ask the object through a method instead.', '''
class Account():
   private pin;
   function base(owner, pin):
      base.owner = owner;
      base.pin = pin;
   fnend
csend
a = Account("asha", 1234);
publish(a.pin);
''', '''
class Account():
   private pin;
   function base(owner, pin):
      base.owner = owner;
      base.pin = pin;
   fnend
   function ok = check(p):
      ok = p == base.pin;
   fnend
csend
a = Account("asha", 1234);
publish(a.check(1234));
'''),
        err('A class without csend', 'A class is closed with <code>csend</code>.', '''
class Shape():
   function base(w):
      base.w = w;
   fnend
s = Shape(2);
''', '''
class Shape():
   function base(w):
      base.w = w;
   fnend
csend
s = Shape(2);
publish(s.w);
'''),
    ],
}

PAGES['constructors-methods'] = {
    'title': 'Constructor & Method Inputs',
    'summary': 'A class\'s constructor (<code>base</code>) and its methods take inputs exactly like functions: '
               'defaults, names and mixtures. A default can even read another input or a field of the object.',
    'about': [
        comp('Constructor inputs', [
            'Creating an object calls the class\'s <code>base</code> function, so <code>Shape(h=3, 2)</code> '
            'follows the rules of <a href="../Functions/defaults-named-inputs.html">named inputs</a>: '
            '<code>h</code> is placed by name, then 2 fills <code>w</code>, and <code>label</code> keeps its '
            'default.'],
            syntax=SHAPE + '\ns = Shape(h=3, 2);    # w = 2  h = 3  label = shape\nt = Shape(4);         # w = 4  h = 1  label = shape'),
        comp('Method inputs', [
            'Methods take defaults and named values too: <code>s.area()</code> uses <code>scale=1</code>, '
            '<code>s.area(scale=10)</code> changes it, and <code>s.grow(dh=5)</code> changes one input of two.'],
            syntax='function grow(dw=1, dh=1):\n   base.w = base.w + dw;\n   base.h = base.h + dh;\nfnend\ns.grow(dh=5);'),
        comp('Defaults from fields and other inputs', [
            'A constructor default can use an earlier input (<code>h=w</code> makes a square by default), and a '
            'method default can read a field of the object (<code>scale=base.w</code>). The default is worked '
            'out at each call, from the object as it is at that moment.'],
            syntax='class Rect():\n   function base(w, h=w):\n      ...\n   fnend\n   function A = area(scale=base.w):\n      A = base.w * base.h * scale;\n   fnend\ncsend'),
        comp('Calls are recorded as written', [
            '<code>obj.lineage()</code> lists the calls that have touched an object exactly as they were made, '
            'names included, with the value each method returned.'],
            syntax='s.lineage()   # [init(h=3, 2),area() -> 6,area(scale=10) -> 60,grow(dh=5)]'),
    ],
    'examples': {
        'basic': ex('Constructor and methods with defaults', 'The constructor and the methods of <code>Shape</code>, '
                    'called with defaults, names and a mixture.', SHAPE.replace('csend\n', '''   function grow(dw=1, dh=1):
      base.w = base.w + dw;
      base.h = base.h + dh;
   fnend
csend
''') + '''
s = Shape(h=3, 2);
publish("Shape(h=3, 2): w =", s.w, " h =", s.h, " label =", s.label);
publish("area() =", s.area(), "  area(scale=10) =", s.area(scale=10));
s.grow(dh=5);
publish("after grow(dh=5): w =", s.w, " h =", s.h);
t = Shape(4);
publish("Shape(4): w =", t.w, " h =", t.h, " label =", t.label);
publish("lineage:", s.lineage());
'''),
        'mid': ex('Defaults that read other inputs and fields', '<code>h</code> defaults to <code>w</code>, and '
                  '<code>area</code>\'s <code>scale</code> defaults to the field <code>base.w</code>.', '''
class Rect():
   function base(w, h=w):
      base.w = w;
      base.h = h;
   fnend
   function A = area(scale=base.w):
      A = base.w * base.h * scale;
   fnend
csend

r = Rect(3);
publish("Rect(3): h =", r.h, "  area() =", r.area(), "  area(scale=1) =", r.area(scale=1));
r2 = Rect(h=2, 5);
publish("Rect(h=2, 5): w =", r2.w, " h =", r2.h, "  area() =", r2.area());
'''),
        'strong': ex('A water tank', 'A tank with a default level and unit. <code>fill</code> has a default amount '
                     'and a limit that defaults to the tank\'s volume; <code>percent</code> rounds to a chosen '
                     'number of digits. The lineage shows every call as it was written.', '''
class Tank():
   function base(volume, level=0, unit="L"):
      base.volume = volume;
      base.level = level;
      base.unit = unit;
   fnend
   function fill(amount=10, limit=base.volume):
      lvl = base.level + amount;
      if lvl > limit:
         lvl = limit;
      iend
      base.level = lvl;
   fnend
   function p = percent(digits=1):
      p = round(100 * base.level / base.volume, decimals=digits);
   fnend
csend

t = Tank(level=20, 280);
t.fill();
publish("after fill():", t.level, t.unit);
t.fill(amount=50, limit=60);
publish("after fill(amount=50, limit=60):", t.level, t.unit);
publish("percent() =", t.percent(), "  percent(digits=0) =", t.percent(digits=0));
t.fill(amount=500);
publish("after fill(amount=500):", t.level, t.unit, " (stopped at the volume)");
publish("lineage:", t.lineage());
'''),
    },
    'errors': [
        err('A constructor input is missing', '<code>w</code> has no default, so creating a <code>Shape</code> '
            'needs it, even when other inputs are named.', SHAPE + 'u = Shape(label="x");',
            SHAPE + 'u = Shape(1, label="x");\npublish(u.w, u.label);'),
        err('A method input is missing', '<code>inc(k)</code> has no default for <code>k</code>.', '''
class Counter():
   function base():
      base.n = 0;
   fnend
   function inc(k):
      base.n = base.n + k;
   fnend
csend
c = Counter();
c.inc();
''', '''
class Counter():
   function base():
      base.n = 0;
   fnend
   function inc(k=1):
      base.n = base.n + k;
   fnend
csend
c = Counter();
c.inc();
publish(c.n);
'''),
        err('Too many values for a method', '<code>inc</code> takes one input.', '''
class Counter():
   function base():
      base.n = 0;
   fnend
   function inc(k):
      base.n = base.n + k;
   fnend
csend
c = Counter();
c.inc(1, 2);
''', '''
class Counter():
   function base():
      base.n = 0;
   fnend
   function inc(k):
      base.n = base.n + k;
   fnend
csend
c = Counter();
c.inc(1);
c.inc(2);
publish(c.n);
'''),
        err('A method that does not exist', 'The class has no method with that name. <code>Shape.info</code> lists '
            'the methods it has (see <a href="info-and-base.html">Looking Inside a Class</a>).',
            SHAPE + 's = Shape(2);\ns.nosuch(a=1);', SHAPE + 's = Shape(2);\npublish(s.area(scale=2));'),
        err('Named values on a value that is not an object', '<code>x</code> is a number, so '
            '<code>x.area(...)</code> is read as a built-in function call, and built-ins called this way take '
            'their values in order.', SHAPE + 'x = 5;\nx.area(scale=1);',
            SHAPE + 'x = Shape(5);\npublish(x.area(scale=1));'),
        err('rewind on a class that is not reversible', 'Only a <code>reversible class</code> keeps the copies '
            'that <code>rewind</code> needs.', '''
class Counter():
   function base():
      base.n = 0;
   fnend
   function inc(k):
      base.n = base.n + k;
   fnend
csend
c = Counter();
c.inc(2);
c = c.rewind(1);
''', '''
reversible class Counter():
   function base():
      base.n = 0;
   fnend
   function inc(k):
      base.n = base.n + k;
   fnend
csend
c = Counter();
c.inc(2);
c = c.rewind(1);
publish(c.n);
'''),
    ],
}

PAGES['inherited-class'] = {
    'title': 'Inherited Class',
    'summary': 'Build a new class on top of an existing one. The new class inherits every method and can '
               'add or replace methods of its own.',
    'about': [
        comp('Inheriting from a class', [
            'Put the parent class in the brackets of the header: <code>class Square(Shape):</code>. Objects of '
            'the new class have all of the parent\'s methods.'],
            syntax='class Square(Shape):\n   ...\ncsend'),
        comp('Calling the parent constructor', [
            'Inside the new constructor, <code>parent(...)</code> runs the parent\'s constructor so its fields are '
            'set up. It takes plain and named inputs like any call.'],
            syntax='function base(side=2):\n   parent(side, label="square", h=side);\nfnend',
            figure=fig(IMG_C + 'inherited-class-01.svg',
                       'Square(side=7) runs Square\'s base with side 7, which calls parent(7, label="square", h=7), '
                       'which runs Shape\'s base with w 7, h 7 and label square. area() then comes from Shape.',
                       'What happens on <code>Square(side=7)</code>: each step is an ordinary call, so names and '
                       'defaults work at every level, and methods the child does not replace come from the parent.')),
        comp('Replacing a method', [
            'A method with the same name in the new class replaces the parent\'s version for objects of the new '
            'class. Methods it does not replace still come from the parent.'],
            syntax='function A = area(scale=1):\n   A = 3.14159 * base.r * base.r * scale;\nfnend'),
        comp('Several levels', [
            'A class can inherit from a class that itself inherits from another. <code>Class.info</code> shows '
            'which class each method comes from.'],
            syntax='class Dog(Animal):\n   ...\ncsend\nclass Kid(Dog):\n   ...\ncsend'),
        comp('Abstract classes', [
            'Mark a class <code>abstract</code> when it only describes what child classes must provide. '
            'You cannot create an object from it directly; create one of its child classes instead.'],
            syntax='abstract class Animal():\n   function s = speak():\n   fnend\ncsend'),
    ],
    'examples': {
        'basic': ex('A square is a shape', '<code>Square</code> sets up a <code>Shape</code> through '
                    '<code>parent</code> and inherits its <code>area</code> method.', '''
class Shape():
   function base(w, h=1, label="shape"):
      base.w = w;
      base.h = h;
      base.label = label;
   fnend
   function A = area(scale=1):
      A = base.w * base.h * scale;
   fnend
csend

class Square(Shape):
   function base(side=2):
      parent(side, label="square", h=side);
   fnend
csend

q1 = Square();
publish("Square(): w =", q1.w, " h =", q1.h, " label =", q1.label);
q2 = Square(side=7);
publish("Square(side=7): area =", q2.area());
'''),
        'mid': ex('Replacing a method', '<code>Circle</code> replaces <code>area</code> but still inherits '
                  '<code>grow</code>.', '''
class Shape():
   function base(w, h=1):
      base.w = w;
      base.h = h;
   fnend
   function A = area():
      A = base.w * base.h;
   fnend
   function grow(dw=1):
      base.w = base.w + dw;
   fnend
csend

class Circle(Shape):
   function base(r=1):
      parent(r, r);
      base.r = r;
   fnend
   function A = area():
      A = 3.14159 * base.r * base.r;
   fnend
csend

s = Shape(2, 3);
c = Circle(r=2);
publish("shape area :", s.area());
publish("circle area:", c.area());
c.grow(dw=5);
publish("circle w after grow:", c.w);
'''),
        'strong': ex('Abstract parent, three levels', '<code>Animal</code> is abstract, <code>Dog</code> provides '
                     '<code>speak</code>, and <code>Kid</code> adds an age. (Creating an <code>Animal</code> '
                     'directly is shown on the Syntax Error tab.)', '''
abstract class Animal():
   function s = speak():
   fnend
csend

class Dog(Animal):
   function base(name):
      base.name = name;
   fnend
   function s = speak():
      s = "woof";
   fnend
csend

class Kid(Dog):
   function base(name, age):
      parent(name);
      base.age = age;
   fnend
csend

d = Dog("rex");
publish(d.name, "says", d.speak());
k = Kid("tom", 3);
publish(k.name, "is", k.age, "and says", k.speak());
'''),
    },
    'errors': [
        err('Creating an object from an abstract class', 'An abstract class only describes what its child '
            'classes provide. Create an object of a child class instead.', '''
abstract class Animal():
   function s = speak():
   fnend
csend
a = Animal();
''', '''
abstract class Animal():
   function s = speak():
   fnend
csend
class Dog(Animal):
   function base(name):
      base.name = name;
   fnend
   function s = speak():
      s = "woof";
   fnend
csend
d = Dog("rex");
publish(d.name, "says", d.speak());
'''),
    ],
}

PAGES['info-and-base'] = {
    'title': 'Looking Inside a Class',
    'summary': '<code>Class.info</code> lists every constructor and method with its inputs, defaults and outputs. '
               '<code>Class.base</code> and <code>obj.base</code> show the fields: their types, or their values.',
    'about': [
        comp('Class.info: every way to call a class', [
            'Write <code>Shape.info</code> (no brackets) to see a table of the class\'s functions: whether each is '
            'the constructor or a method, how to call it with its defaults, its outputs, and the class it comes '
            'from.'],
            syntax='Shape.info',
            table=[['Column', 'Shows'],
                   ['kind', '<code>constructor</code> or <code>method</code>'],
                   ['call', 'the call with every input and its default, e.g. <code>Shape(w, h=1, label="shape")</code>'],
                   ['outputs', 'the output names, or <code>-</code> when there are none'],
                   ['from', 'the class that defines it (useful with inheritance)']]),
        comp('Class.base: the fields and their types', [
            '<code>Shape.base</code> lists the fields the constructor sets, with the type of each. A field whose '
            'type depends on the call (such as an input with no default) shows as <code>any</code>.'],
            syntax='CC = Shape.base   # {w: any, h: float64, label: string, ok: bool, ...}'),
        comp('obj.base: the values of one object', [
            'On an object, <code>.base</code> shows the values of its fields. Private fields are left out when '
            'you look from outside; inside the class\'s own methods, <code>base.base</code> shows them too.'],
            syntax='FF = Shape(2, 3);\nFF.base'),
        comp('Inherited classes', [
            'For a class built on another, <code>.info</code> also lists what it inherits. The <em>from</em> column '
            'says where each function is defined, and versions of one method with different inputs are listed '
            'one per line.'],
            syntax='class Circle(Shape):\n   ...\ncsend\nCircle.info'),
        comp('info as data', [
            'Assign <code>.info</code> to a variable to use it in a script. It is a dictionary with entries such '
            'as <code>count</code> (number of functions), <code>parent</code> and <code>functions</code>.'],
            syntax='I = Circle.info;\nI["count"]\nI["parent"]'),
        comp('Defaults are shown as written', [
            '<code>.info</code> shows every default exactly as it is written in the header: expressions, text with '
            'quotes, matrices, complex numbers and negations.'],
            syntax='function base(a=-1, b=a*2+1, c=sqrt(16), d=true, e="say \\"hi\\"", f=[1, 2; 3, 4], g=3i, h=-(a+1), k=!d):'),
    ],
    'examples': {
        'basic': ex('A first look inside', 'The types of the fields, the table of functions, and the values of one '
                    'object (the private field <code>secret</code> stays hidden from outside).', INFO_CLASSES + '''
CC = Shape.base
Shape.info
FF = Shape(2, 3);
FF.base
FF.seeAll();
'''),
        'mid': ex('An inherited class', '<code>Circle</code> builds on <code>Shape</code>, replaces '
                  '<code>area</code> and adds a second version of it. <code>.info</code> shows where each function '
                  'comes from, and its result can be read like a dictionary.', INFO_CLASSES + '''
class Circle(Shape):
   function base(r=1, color="red"):
      parent(r, r, label="circle");
      base.r = r;
      base.color = color;
   fnend
   function A = area(scale=1):
      A = 3.14159 * base.r * base.r * scale;
   fnend
   function A = area(scale, offset):
      A = 3.14159 * base.r * base.r * scale + offset;
   fnend
csend

Circle.info
c = Circle(color="blue");
c.base
I = Circle.info;
publish("count =", I["count"], " parent =", I["parent"]);
'''),
        'strong': ex('Every kind of default', 'A constructor whose defaults use expressions, other inputs, text '
                     'with quotes, a matrix, a complex number and a negation. <code>.info</code> prints them as '
                     'written; <code>.base</code> gives the field types.', '''
class D():
   function base(a=-1, b=a*2+1, c=sqrt(16), d=true, e="say \\"hi\\"", f=[1, 2; 3, 4], g=3i, h=-(a+1), k=!d):
      base.a = a;
      base.b = b;
      base.c = c;
      base.d = d;
      base.e = e;
      base.g = g;
      base.k = k;
   fnend
csend
D.info
D.base
x = D();
publish("a =", x.a, " b =", x.b, " c =", x.c, " k =", x.k, " e =", x.e);
'''),
    },
    'errors': [
        err('info with brackets', '<code>.info</code> takes no values.', SHAPE + 'Shape.info(1)',
            SHAPE + 'Shape.info'),
        err('Assigning to base', 'After a dot, <code>base</code> is reserved: it lists the fields. Choose another '
            'field name.', SHAPE + 's = Shape(2);\ns.base = 3;',
            SHAPE + 's = Shape(2);\ns.size = 3;\npublish(s.size);'),
        err('.base on a value that is not an object', '<code>z</code> is a number, so it has no fields.',
            'z = 5;\nz.base', SHAPE + 'z = Shape(5);\nz.base'),
    ],
}


# ============================================================== SIGNALS
PAGES['reading-signal'] = {
    'title': 'Reading Signal', 'pending': True,
    'summary': 'Reading signals into NC.',
}
PAGES['setup-signal'] = {
    'title': 'Setup Signal', 'pending': True,
    'summary': 'Setting up signals in NC.',
}

LANDING = {
    'title': 'Language Guide',
    'summary': 'Everything you need to write NC programs: variables and types, arithmetic, matrices, '
               'loops and decisions, operators, functions, classes, and errors and exceptions.',
}

from lg_errors import PAGES as _errors  # noqa: E402

PAGES.update(_errors)
