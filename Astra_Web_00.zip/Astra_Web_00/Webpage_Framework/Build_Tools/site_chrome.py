"""Shared site chrome: the header (ribbon bar) and footer (useful-link bar + footer bar).

main.html is the single source of truth for both. Every other page gets a copy whose
relative links are rewritten for that page's folder depth (see `localise`).
"""
import re
from pathlib import Path

SITE = Path(__file__).resolve().parents[2]          # repository root (holds main.html)
FRAMEWORK = SITE / 'Webpage_Framework'

HEAD_START, HEAD_END = '  <a class="skip-link"', '</header>'
FOOT_START, FOOT_END = '  <footer class="site-footer">', '</footer>'


def shared_parts():
    """Return (header, footer) HTML exactly as written in main.html."""
    page = (SITE / 'main.html').read_text(encoding='utf-8')
    header = page[page.index(HEAD_START):page.index(HEAD_END) + len(HEAD_END)]
    footer = page[page.index(FOOT_START):page.index(FOOT_END) + len(FOOT_END)]
    return header, footer


BUILT_MARKER = '<meta name="nc-page" content="built">'


def page(root, title, description, body, extra_head=''):
    """A complete page: shared <head>, header, `body` inside <main>, footer.

    root        -- '../' repeated once per folder level between the page and the site root
    extra_head  -- extra lines for <head> (page-specific CSS/JS), already indented
    """
    import html
    header, footer = shared_parts()
    return f'''<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{html.escape(title)} | Neural Colindes</title>
  <meta name="description" content="{html.escape(description, quote=True)}">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="icon" href="{root}Icons/Brand/favicon.svg" type="image/svg+xml">
  <link rel="icon" href="{root}Icons/Brand/favicon.ico" sizes="48x48">
  <link rel="apple-touch-icon" href="{root}Icons/Brand/apple-touch-icon.png">
  <meta name="theme-color" content="#0E3B6E">
  <meta property="og:image" content="{root}Icons/Brand/og-image.png">
  <link rel="stylesheet" href="{root}Control_Sheet/control-sheet.css">
  <link rel="stylesheet" href="{root}Webpage_Framework/Styles/layout.css">
  <link rel="stylesheet" href="{root}Webpage_Framework/Styles/site.css">
{extra_head}  <script>document.documentElement.classList.add('js');</script>
</head>
<body>
{localise(header, root)}

  <main id="main">
{body}
  </main>

{localise(footer, root)}

  <script src="{root}Webpage_Framework/Scripts/site.js"></script>
</body>
</html>
'''


def localise(part, root):
    """Rewrite main.html's relative links so they work from a page `root` levels down.

    Every relative href/src/action gets the `root` prefix ('../', '../../', ...);
    `#anchor` links point back at main.html. Absolute URLs, bare "#", "#main" and
    links that already start with "../" are left alone.
    """
    def fix(match):
        attr, url = match.group(1), match.group(2)
        if url in ('#', '#main') or re.match(r'[a-z][a-z0-9+.-]*:|/|\.\./', url):
            return match.group(0)
        if url.startswith('#'):
            return f'{attr}="{root}main.html{url}"'
        return f'{attr}="{root}{url}"'
    return re.sub(r'\b(href|src|action)="([^"]*)"', fix, part)
