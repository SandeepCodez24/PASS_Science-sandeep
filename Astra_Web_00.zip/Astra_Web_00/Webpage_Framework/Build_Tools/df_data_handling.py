"""Default Functions - Data Handling (source: Function_Test/Code/A_04_Data_Handling/scripts 01..31 and
scripts/errors e01..e38).

The examples read the published sample files (Cloud_Storage/Documents/Sample_Data/Data_Handling, copied
to data/ in the folder the examples run in) and write to out/. Formats with binary content (images,
sound, video, MATLAB, HDF5 ...) are written by the example itself first, so every example runs anywhere.
Script 13 (chained access) is in the Language Guide (Default Class); script 28's typed-arithmetic rules
are in Variable Types.
"""
from df_helpers import err, ex, fig, fn, reference

IMG = 'Images/Neural_Code/Default_Functions/Data_Handling/'
ZIP = '../../../Cloud_Storage/Documents/Sample_Data/data-handling-samples.zip'
LG = '../../Language_Guide/'
PAGES = {}

SAMPLES_NOTE = (f'The examples read small sample files from a folder named <code>data</code> next to the script: '
                f'<a href="{ZIP}">download the sample files</a> (zip) and unpack them there. Files the examples '
                f'write go to a folder named <code>out</code>.')

# ================================================================== 1. Overview
PAGES['reading-loading-saving'] = {
    'title': 'Reading, Loading & Saving',
    'summary': 'One pattern for more than fifty file formats: <code>read_</code> gives the data, <code>load_</code> '
               'gives an object to explore, <code>save_</code> writes. Info boxes, partial reads, typed data and '
               'missing values work the same way everywhere.',
    'about': [
        fn('Three verbs for every format', 'For a format such as CSV there are three functions. '
           '<code>read_csv(file)</code> gives the data as a matrix or table. <code>load_csv(file)</code> gives an '
           'object whose parts are reached with dots (<code>D.Temp</code>, <code>D.sheets</code>, '
           '<code>D.boxes</code>). <code>save_csv(file, data)</code> writes and gives back the number of bytes '
           'written.',
           more=[SAMPLES_NOTE],
           table=None,
           figure=fig(IMG + 'reading-loading-saving-01.svg',
                      'A file in the middle. read_ turns it into a matrix or table; load_ turns it into an object with '
                      'dot access to its sheets, columns, metadata and info boxes; save_ writes data back to a file. '
                      'The second output of read_ is an info dictionary.',
                      'The three verbs. <code>[T, info] = read_…</code> also returns what the reader found: columns, '
                      'types, sheets and info boxes.'),
           syntax='T = read_csv("data/sensors.csv")\n[T, info] = read_csv("data/sensors.csv");\nD = load_csv("data/sensors.csv");\nn = save_csv("out/copy.csv", T)'),
        fn('Info boxes', 'Lines that describe a file rather than hold data (a title line, "Note: end of log", '
           '<code>_meta</code> keys in JSON, XML comments) are kept apart as <em>info boxes</em>: '
           '<code>info.boxes</code> or <code>D.boxes</code>. Every <code>save_</code> takes <code>boxes=</code> to '
           'write them back, and every <code>read_</code> takes <code>box=false</code> to leave them in the data.',
           syntax='[T, info] = read_csv("data/sensors.csv");\ninfo.boxes\nsave_csv("out/c.csv", T, boxes=["Project: Agni"])'),
        fn('Options every reader shares', 'Most readers accept the same options by name.',
           table=[['Option', 'Meaning'],
                  ['<code>cols=</code>', 'columns by name, position or range: <code>["ID", "Temp"]</code>, <code>[2:3]</code>'],
                  ['<code>rows=</code>', 'rows by number or range, 1-based: <code>[1:2]</code>'],
                  ['<code>hdr=</code>', '<code>false</code> or 0: no header row; n: row n is the header'],
                  ['<code>na=</code>', 'texts that mean "missing", e.g. <code>["NA", ""]</code>'],
                  ['<code>box=</code>', '<code>false</code>: keep info boxes in the data'],
                  ['<code>enc=</code>', 'text encoding, e.g. <code>"latin-1"</code>, <code>"utf-16"</code>'],
                  ['<code>path=</code>, <code>xpath=</code>, <code>slice=</code>, <code>roi=</code>, <code>sheet=</code>',
                   'read only a part of the file: the reader skips the rest']]),
        fn('Options every writer shares', 'Most <code>save_</code> functions accept these.',
           table=[['Option', 'Meaning'],
                  ['<code>boxes=</code>', 'info boxes to write'],
                  ['<code>mode=</code>', '<code>"w"</code> to write (default) or <code>"a"</code> to append'],
                  ['<code>compress=</code>, <code>level=</code>', 'compression and its level, where the format has it'],
                  ['<code>max_size=</code>', 'stop with an error if the file would be bigger, e.g. <code>"2kb"</code>'],
                  ['<code>enc=</code>', 'text encoding of the file']],
           more=['A save that fails leaves the old file as it was.']),
        fn('Typed data and missing values', 'Data keeps the type it has in the file: image pixels come back as '
           '<code>uint8</code>, sound samples as <code>int16</code>, HDF5 datasets in their own type. Arithmetic on '
           'them follows the rules on <a href="' + LG + 'Getting_Started/variable-types.html">Variable Types</a>.',
           more=['An empty or "NA" cell is <em>missing</em>. It behaves like NaN, but <code>ismissing(x)</code> tells '
                 'it apart from a NaN you computed, <code>fillmissing(T, v)</code> replaces it, and the columnar '
                 'formats write it back as null.'],
           syntax='U = read_csv("data/sensors.csv", na=["NA"]);\nismissing(U)\nfillmissing(U, -1)'),
        fn('Every format', 'The formats and the pages that describe them.',
           table=[['Formats', 'Page'],
                  ['csv, tsv, txt, dat', '<a href="delimited-text.html">Delimited Text</a>'],
                  ['json, ndjson', '<a href="json.html">JSON</a>'],
                  ['xml, html, htm', '<a href="xml-html.html">XML &amp; HTML</a>'],
                  ['yaml, yml, ini', '<a href="yaml-ini.html">YAML &amp; INI</a>'],
                  ['bin, custom', '<a href="binary-custom.html">Binary &amp; Custom Layouts</a>'],
                  ['xlsx, xls, xlsm, xlsb', '<a href="spreadsheets.html">Spreadsheets</a>'],
                  ['png, jpg, jpeg, tiff, bmp, gif, dicom', '<a href="images.html">Images</a>'],
                  ['wav, flac, ogg, mp3, mp4, avi, m4v, mov', '<a href="audio-video.html">Audio &amp; Video</a>'],
                  ['mat, fig, fits, fit', '<a href="matlab-fits.html">MATLAB &amp; FITS</a>'],
                  ['h5, hdf, he5, nc, cdf', '<a href="hdf5-netcdf.html">HDF5 &amp; NetCDF</a>'],
                  ['parquet, feather, orc', '<a href="columnar-files.html">Columnar Files</a>'],
                  ['sqlite, postgresql, mysql', '<a href="databases.html">Databases</a>'],
                  ['shp, shx, dbf, tif, geotiff, gpx, kml, kmz', '<a href="maps-gps.html">Maps &amp; GPS</a>'],
                  ['(not sure)', '<a href="finding-readers.html">Finding the Right Reader</a>']]),
    ],
    'examples': {
        'basic': ex('Read, look, save, read back', 'A CSV with a title line, a comment and a note: the data, what '
                    'the reader found, and a round trip through a new file.', '''
[T, info] = read_csv("data/sensors.csv");
T
publish("columns:", info.cols);
publish("info boxes:", info.boxes);
n = save_csv("out/copy.csv", T, boxes=["Project: Agni"]);
publish("bytes written:", n);
back = read_csv("out/copy.csv")
'''),
        'mid': ex('The object view', '<code>load_csv</code> gives an object: columns by name, the sheets, the info '
                  'boxes and the comments.', '''
D = load_csv("data/sensors.csv");
publish("sheets:", D.sheets, "  rows:", D.rows);
publish("Temp column:", D.Temp);
publish("Name column:", D.Main.Name);
publish("info boxes:", D.boxes);
publish("comments:", D.comments);
'''),
        'strong': ex('Missing cells', 'NA becomes a missing value: it acts like NaN in arithmetic, but '
                     '<code>ismissing</code> knows it was missing in the file, and <code>fillmissing</code> replaces '
                     'it. A NaN you compute is not missing.', '''
U = read_csv("data/sensors.csv", na=["NA"], cols=["ID", "Temp"])
m = ismissing(U)
F = fillmissing(U, -1)
z = 0 / 0;
publish("0/0 is NaN:", isnan(z), "  but missing:", ismissing(z));
'''),
    },
    'errors': [
        err('A file that does not exist', 'NC names the file it looked for.', 'T = read_csv("data/nope.csv");',
            'T = read_csv("data/sensors.csv");\npublish(size(T));'),
        err('An unknown write mode', 'mode is "w" (write) or "a" (append).', 'n = save_csv("out/e.csv", [1, 2], mode="x");',
            'n = save_csv("out/e.csv", [1, 2], mode="a");\npublish(n > 0);'),
        err('A file bigger than max_size', 'NC suggests compression or a larger limit.',
            'n = save_csv("out/e.csv", [1, 2; 3, 4], max_size="4b");', 'n = save_csv("out/e.csv", [1, 2; 3, 4], max_size="1kb");\npublish(n);'),
        err('A method a loaded object does not have', 'NC names the kind of object.',
            'D = load_csv("data/sensors.csv");\nx = D.nosuch(1);', 'D = load_csv("data/sensors.csv");\npublish(D.sheets);'),
    ],
}

# ================================================================== 2. Finding the right reader
PAGES['finding-readers'] = {
    'title': 'Finding the Right Reader',
    'summary': 'List the formats, detect what a file is, see the options of a function, preview the first rows, '
               'and get the line of code that reads a file. These are the functions behind the IDE\'s Import window.',
    'about': reference('Use these when you are not sure which reader a file needs, or to write the read call for '
                       'you.', [
        fn('io_formats([category])', 'The format names NC knows, optionally of one category such as '
           '"structured".', inputs=[('category', 'a category name', 'all')], syntax='io_formats("structured")'),
        fn('io_detect(file)', 'What a file is: <code>.format</code>, <code>.category</code>, '
           '<code>.confidence</code>, <code>.read</code> (the function to use) and <code>.reason</code>. The content '
           'is checked, not only the extension.', inputs=[('file', 'path', '')],
           syntax='d = io_detect("data/catalog.xml");\nd.format\nd.read'),
        fn('io_options(format, verb)', 'The options of <code>read</code> or <code>save</code> for a format, as a '
           'table: name, default and meaning.', inputs=[('format', 'e.g. "csv"', ''), ('verb', '"read" or "save"', '')],
           syntax='io_options("json", "read")'),
        fn('io_preview(file, n[, format])', 'The first n rows without reading the whole file: <code>.kind</code>, '
           '<code>.cols</code>, <code>.rows</code>, <code>.boxes</code>, <code>.total_rows</code>, <code>.code</code>.',
           inputs=[('file', 'path', ''), ('n', 'rows to show', ''), ('format', 'force a format', 'detected')],
           syntax='p = io_preview("data/sensors.csv", 2);\np.rows'),
        fn('io_code(file[, verb[, name[, format]]])', 'The line of NC code that reads, loads or saves the file.',
           inputs=[('file', 'path', ''), ('verb', '"read", "load" or "save"', '"read"'),
                   ('name', 'the variable name to use', '"T"'), ('format', 'force a format', 'detected')],
           syntax='io_code("data/weather.json", "load", "W")'),
    ]),
    'examples': {
        'basic': ex('What is this file?', 'Detection by content, for several sample files.', '''
d = io_detect("data/catalog.xml");
publish(d.format, d.category, d.confidence, d.read);
publish(io_detect("data/sensors.csv").format, io_detect("data/laps.tsv").format, io_detect("data/config.yaml").format);
publish(io_detect("data/config.ini").format, io_detect("data/weather.json").format, io_detect("data/launches.html").format);
publish(io_detect("data/small.csv.gz").reason);
publish(io_detect("not_there.parquet").reason);
'''),
        'mid': ex('Formats and options', 'The structured formats, how many formats there are, and the read '
                  'options of JSON.', '''
publish(io_formats("structured"));
publish(size(io_formats()));
o = io_options("json", "read")
'''),
        'strong': ex('Preview and code', 'Look at the first rows of two files, then let NC write the calls.', '''
p = io_preview("data/sensors.csv", 2);
publish(p.kind, p.cols);
publish(p.rows);
publish("total rows:", p.total_rows, "  code:", p.code);
q = io_preview("data/config.yaml", 3);
publish(q.kind);
publish(io_code("data/sensors.csv"));
publish(io_code("data/weather.json", "load", "W"));
publish(io_code("out/report.html", "save", "T"));
'''),
    },
}

# ================================================================== 3. Delimited text
PAGES['delimited-text'] = {
    'title': 'Delimited Text: CSV, TSV, TXT, DAT',
    'summary': 'Tables in plain text, separated by commas, tabs, runs of spaces or any character: headers, '
               'comments, info boxes, several sheets in one file, encodings and compressed files.',
    'about': reference('The four formats share their options; they differ in the default delimiter: comma '
                       '(<code>csv</code>), tab (<code>tsv</code>), runs of blanks (<code>txt</code>), or detected '
                       'from the content (<code>dat</code>). ' + SAMPLES_NOTE, [
        fn('read_csv(file, cols, rows, hdr, na, box, sheet, dlm, cmt, skip, enc)', 'The table in the file; with two '
           'outputs also an info dictionary (<code>.cols</code>, <code>.schema</code>, <code>.boxes</code>, '
           '<code>.comments</code>, <code>.header_line</code>, <code>.sheets</code>). A <code>.gz</code> file is read '
           'directly.',
           inputs=[('cols, rows', 'parts to read (names, positions or ranges)', 'all'),
                   ('hdr', 'false / 0: no header; n: row n is the header', 'detected'),
                   ('na', 'texts that mean missing', '"NA", ""'),
                   ('box', 'false: keep info boxes as data', 'true'),
                   ('sheet', 'a section <code># [Sheet: NAME]</code> by name, or its number (1-based)', 'the first'),
                   ('dlm, cmt', 'delimiter and comment character', '"," and "#"'),
                   ('skip', 'lines to skip first', '0'), ('enc', 'encoding, e.g. "latin-1"', '"utf-8"')],
           syntax='a = read_csv("data/sensors.csv", cols=["ID", "Temp"], rows=[1:2])\nq = read_csv("data/multi.csv", sheet="Flow")',
           short='a table from a comma-separated file'),
        fn('load_csv(file, ...)', 'An object: columns by name (<code>D.Temp</code>), sheets by name '
           '(<code>D.Flow.valve</code>) or number (<code>D.sheet(1)</code>), and <code>.sheets</code>, '
           '<code>.cols</code>, <code>.rows</code>, <code>.schema</code>, <code>.boxes</code>, '
           '<code>.comments</code>, <code>.raw_lines</code>.', syntax='M = load_csv("data/multi.csv");\nM.Flow.valve',
           short='an object with columns and sheets by name'),
        fn('save_csv(file, data, boxes, quote, float_fmt, hdr, dlm, sheets, sec_fmt, split, compress, level, enc, max_size, mode)',
           'Writes a matrix, a table or several sheets; gives the number of bytes written.',
           inputs=[('data', 'matrix or table (first row = header)', ''),
                   ('sheets', 'a dict of name &rarr; table: several sections in one file', ''),
                   ('split', 'true: one file per sheet instead', 'false'),
                   ('quote', '"all": quote every cell', 'when needed'),
                   ('float_fmt', 'number format, e.g. "%.3f"', 'shortest exact'),
                   ('compress, level', '"gz" and 1&ndash;9', 'none')],
           syntax='save_csv("out/c3.csv", ["Name", "Age"; "Ann", 30], quote="all")\nsave_csv("out/c6.csv", sheets=sh)',
           short='write a table, or several sheets'),
        fn('read_tsv / load_tsv / save_tsv', 'The same, with a tab as the delimiter.',
           syntax='T = read_tsv("data/laps.tsv")', short='tab-separated tables'),
        fn('read_txt / load_txt / save_txt', 'The same, with runs of spaces as the delimiter: for aligned columns.',
           syntax='W = load_txt("data/spectrum.txt");\nW.intensity', short='space-aligned tables'),
        fn('read_dat / load_dat / save_dat', 'The same, with the delimiter detected from the content.',
           syntax='T = read_dat("data/probe.dat", cmt="%")', short='delimiter detected automatically'),
    ]),
    'examples': {
        'basic': ex('Reading parts of a CSV', 'Columns by name and range, rows by range, without a header, and '
                    'with another header row.', '''
a = read_csv("data/sensors.csv", cols=["ID", "Temp"], rows=[1:2])
b = read_csv("data/sensors.csv", cols=[2:3])
d = read_csv("data/sensors.csv", hdr=false, rows=[1:2])
[f, fi] = read_csv("data/sensors.csv", box=false, na=["NA", "Pump B"]);
publish(fi.boxes);
'''),
        'mid': ex('Sheets, delimiters and encodings', 'Sections of one file, a semicolon file with % comments, a '
                  'Latin-1 file and a compressed one.', '''
q = read_csv("data/multi.csv", sheet="Flow")
r = read_csv("data/multi.csv", sheet=2, cols=["valve"])
g = read_csv("data/probe.dat", dlm=";", cmt="%")
k = read_csv("data/latin1_real.csv", enc="latin-1")
m = read_csv("data/small.csv.gz")
M = load_csv("data/multi.csv");
publish(M.sheets, M.Pressure.rows);
'''),
        'strong': ex('Writing every way and reading back', 'Several sheets in one file and in separate files, '
                     'formats, compression and appending, each read back.', '''
sh = dict();
sh["S1"] = [1, 2; 3, 4];
sh["S2"] = ["k", "v"; "a", 1];
n6 = save_csv("out/c6.csv", sheets=sh);
publish(read_csv("out/c6.csv", sheet="S2"));
n8 = save_csv("out/c8.csv", sheets=sh, split=true);
publish(read_csv("out/c8.csv_S2.csv"));
n4 = save_csv("out/c4.csv", [0.1234567, 2], float_fmt="%.3f", hdr=false);
publish(read_csv("out/c4.csv", hdr=0));
D = load_csv("data/sensors.csv");
n9 = save_csv("out/c9.csv.gz", D.default, compress="gz", level=9);
publish(read_csv("out/c9.csv.gz", cols=["Temp"]));
n12 = save_csv("out/c12.csv", [5, 6], mode="w");
n12 = save_csv("out/c12.csv", [7, 8], mode="a");
publish(read_csv("out/c12.csv", hdr=0));
L = load_tsv("data/laps.tsv");
publish("tsv:", L.name, L.time);
W = load_txt("data/spectrum.txt");
publish("txt:", W.intensity);
'''),
    },
    'errors': [
        err('A sheet that does not exist', 'NC lists the sheets.', 'T = read_csv("data/multi.csv", sheet="Nope");',
            'T = read_csv("data/multi.csv", sheet="Flow");\npublish(T);'),
        err('A column that does not exist', 'NC lists the columns.', 'T = read_csv("data/sensors.csv", cols=["ID", "Nope"]);',
            'T = read_csv("data/sensors.csv", cols=["ID", "Name"]);\npublish(T);'),
        err('A compression that is not built in', 'CSV files are compressed with gzip.',
            'n = save_csv("out/e.csv", [1, 2], compress="zstd");', 'n = save_csv("out/e.csv.gz", [1, 2], compress="gz");\npublish(n > 0);'),
    ],
}

# ================================================================== 4. JSON
PAGES['json'] = {
    'title': 'JSON',
    'summary': 'JSON and line-by-line NDJSON: whole documents, parts chosen with JSONPath, tables made from lists '
               'of records, and objects explored with dots.',
    'about': reference('Comments and trailing commas (JSON5) are accepted. Keys that start with <code>_meta</code> '
                       'become info boxes. ' + SAMPLES_NOTE, [
        fn('read_json(file, path, as_table, lines, box)', 'The document as a dictionary, or a table when it is a '
           'list of records; <code>path=</code> picks a part with JSONPath.',
           inputs=[('path', 'JSONPath such as <code>"$.store.book[*]"</code>, <code>"$..price"</code>, '
                            '<code>"$.store.book[?(@.price &lt; 20)].title"</code>', 'the whole document'),
                   ('as_table', 'false: keep a list of records as a list', 'true'),
                   ('lines', 'true: NDJSON, one record per line', 'false'),
                   ('box', 'false: keep _meta in the data', 'true')],
           syntax='books = read_json("data/weather.json", path="$.store.book[*]")\ncheap = read_json("data/weather.json", path="$.store.book[?(@.price < 20)].title")',
           short='a dictionary or table; parts by JSONPath'),
        fn('load_json(file)', 'An object with dot access at any depth (<code>D.sensor.calibration.gain</code>, '
           '<code>D.store.book[2].title</code>), plus <code>.keys()</code>, <code>.get(key)</code> for keys that are '
           'not names (<code>"my-key"</code>, also <code>D.my_key</code>), <code>.query(jsonpath)</code> and '
           '<code>.to_table(path)</code>.', syntax='D = load_json("data/weather.json");\nD.store.book[2].title\nD.query("$..price")'),
        fn('save_json(file, data, indent, sort_keys, minify, lines, nan_mode, boxes, compress, max_size)', 'Writes a '
           'dictionary, an object, a table or a matrix.',
           inputs=[('indent', 'spaces per level', '2'), ('sort_keys', 'true: keys in alphabetical order', 'false'),
                   ('minify', 'true: no spaces at all', 'false'), ('lines', 'true: NDJSON', 'false'),
                   ('nan_mode', '"str": write NaN and inf as text (JSON has no NaN)', 'null')],
           syntax='save_json("out/j2.json", T, indent=4, sort_keys=true)'),
    ]),
    'examples': {
        'basic': ex('Parts of a document', 'JSONPath picks values, lists and filtered records.', '''
gain = read_json("data/weather.json", path="$.sensor.calibration.gain")
prices = read_json("data/weather.json", path="$..price")
cheap = read_json("data/weather.json", path="$.store.book[?(@.price < 20)].title")
active = read_json("data/weather.json", path="$.store.book[?(@.active==true && @.price > 10)].title")
first2 = read_json("data/weather.json", path="$.store.book[0:2].title")
grid = read_json("data/weather.json", path="grid")
'''),
        'mid': ex('The object view', 'Dot access, awkward keys, queries and a table made from a list of records.', '''
D = load_json("data/weather.json");
publish(D.sensor.calibration.gain, D.store.book[2].title, D._meta.source);
publish(D.keys());
publish(D.get("my-key"), D.my_key);
publish(D.query("$.store.book[?(@.active==false)].title"));
T = D.to_table("$.store.book");
publish(T.cols, T.price);
'''),
        'strong': ex('NDJSON and writing', 'Line-by-line records with a null, then writing with indentation, as '
                     'NDJSON and with NaN kept as text.', '''
[E, ei] = read_json("data/events.ndjson", lines=true);
E
n3 = save_json("out/j3.json", [1, 2; 3, 4], minify=true);
publish(read_json("out/j3.json"));
n4 = save_json("out/j4.ndjson", E, lines=true);
publish(read_json("out/j4.ndjson", lines=true));
n5 = save_json("out/j5.json", [1, nan, inf], nan_mode="str");
publish(read_json("out/j5.json"));
'''),
    },
    'errors': [
        err('A JSON file with a syntax error', 'NC names the line.', 'J = read_json("data/bad.json");',
            'J = read_json("data/weather.json", path="$.sensor.name");\npublish(J);'),
    ],
}

# ================================================================== 5. XML and HTML
PAGES['xml-html'] = {
    'title': 'XML & HTML',
    'summary': 'Records in XML become tables; XPath and namespaces pick parts; XML Schema checks a file. Tables, '
               'text, links and images come out of HTML pages, and tables can be written as styled pages.',
    'about': reference(SAMPLES_NOTE, [
        fn('read_xml(file, xpath, ns, attr_prefix, validate_xsd, box)', 'Repeating records become a table (attributes '
           'as <code>@id</code> columns); comments and headers become info boxes.',
           inputs=[('xpath', 'an XPath such as <code>"//book[price&gt;20]"</code>, <code>"//book/@id"</code>', 'the records'),
                   ('ns', 'prefix &rarr; namespace dictionary', ''), ('attr_prefix', 'prefix of attribute columns', '"@"'),
                   ('validate_xsd', 'an XML Schema file to check against', '')],
           syntax='titles = read_xml("data/catalog.xml", xpath="//book[@active=\'1\']/title")'),
        fn('load_xml(file)', 'The element tree: <code>D.catalog.book[1].title.text</code>, <code>.attrs</code>, '
           '<code>.root.tag</code>, <code>.comments</code>, <code>.namespaces</code>, and <code>.xpath(...)</code> '
           'on the document or any element.', syntax='D = load_xml("data/catalog.xml");\nD.catalog.book[1].title.text'),
        fn('save_xml(file, data, root, row_tag, indent, cdata, boxes, compress, enc)', 'Writes a table (one element '
           'per row), a loaded tree or a dictionary (<code>"@name"</code> keys become attributes).',
           syntax='save_xml("out/x2.xml", T, root="Sensors", row_tag="Sensor", cdata=["Name"])'),
        fn('read_html(file, table, css, xpath, links, box) / read_htm', 'The first <code>&lt;table&gt;</code> by '
           'default (row spans and numbers such as 1,500 handled); or a table by index, id or caption, elements by '
           'CSS selector or XPath, or the links.',
           inputs=[('table', 'index, id or caption', 'the first'), ('css', 'a CSS selector such as "div.card &gt; p"', ''),
                   ('xpath', 'an XPath', ''), ('links', 'true: the links of the page', 'false')],
           syntax='T = read_html("data/launches.html", table="Launch results")\ncards = read_html("data/launches.html", css="div.card > p")',
           short='tables, elements or links from a web page'),
        fn('load_html(file) / load_htm', 'The page: <code>.title</code>, <code>.tables</code>, '
           '<code>.table_names</code>, <code>.table(name)</code>, <code>.meta</code>, <code>.links</code>, '
           '<code>.images</code>, <code>.text</code>, <code>.select(css)</code>, <code>.xpath(...)</code>.',
           syntax='W = load_html("data/launches.html");\nW.table("Launch").Year'),
        fn('save_html(file, data, title, theme, boxes, minify, embed_img, mode) / save_htm', 'A table (or an HTML '
           'fragment) as a page; <code>mode="a"</code> adds another table to the page.',
           inputs=[('theme', '"light", "minimal" ...', ''), ('minify', 'true: no extra spaces', 'false')],
           syntax='save_html("out/h2.html", T, title="Launch Report", theme="light")'),
    ]),
    'examples': {
        'basic': ex('Records to a table', 'Books become rows; XPath picks titles, ids and expensive books.', '''
[T, info] = read_xml("data/catalog.xml");
T
publish("root:", info.root, "  boxes:", info.boxes);
ids = read_xml("data/catalog.xml", xpath="//book/@id")
pricey = read_xml("data/catalog.xml", xpath="//book[price>20]")
pt = read_xml("data/catalog.xml", xpath="//geo:point", ns=dict(["geo"], ["http://example.org/geo"]))
'''),
        'mid': ex('A web page', 'The results table with a row span, cards, a column by XPath, and the page\'s parts.', '''
[T, info] = read_html("data/launches.html");
T
publish("title:", info.title);
cards = read_html("data/launches.html", css="div.card > p")
years = read_html("data/launches.html", xpath="//table//tr/td[3]")
W = load_html("data/launches.html");
publish(W.table_names, W.links, W.images);
'''),
        'strong': ex('Trees, schemas and writing', 'Walk the XML tree, check the file against its schema, and write '
                     'a table as XML and as a styled HTML page.', '''
D = load_xml("data/catalog.xml");
publish(D.catalog.book[1].title.text, D.catalog.book[0].attrs, D.root.tag);
publish(D.xpath("//book[price>20]/title/text()"));
[v, vi] = read_xml("data/catalog.xml", validate_xsd="data/catalog.xsd", box=false);
publish("valid, rows:", size(v));
named = load_csv("data/sensors.csv");
n2 = save_xml("out/x2.xml", named.default, root="Sensors", row_tag="Sensor", indent=4, cdata=["Name"]);
publish(read_xml("out/x2.xml"));
n3 = save_html("out/h2.html", named.default, title="Sensor Report", theme="light");
publish(load_html("out/h2.html").title);
'''),
    },
    'errors': [
        err('Tags that do not match', 'NC names the tags and the line.', 'X = read_xml("data/bad.xml");',
            'X = read_xml("data/catalog.xml", xpath="//book/@id");\npublish(X);'),
        err('A file that fails its schema', 'The schema requires an id on every book.',
            'X = read_xml("data/bad_catalog.xml", validate_xsd="data/catalog.xsd");',
            'X = read_xml("data/catalog.xml", validate_xsd="data/catalog.xsd");\npublish(size(X));'),
        err('A column name that is not a valid tag', 'XML tags have no spaces.',
            'n = save_xml("out/e.xml", ["Max Temp", "ok"; 1, 2]);', 'n = save_xml("out/e.xml", ["Max_Temp", "ok"; 1, 2]);\npublish(n > 0);'),
        err('A page without a table', 'read_html looks for <code>&lt;table&gt;</code> by default; use css= or xpath= '
            'for other elements.', 'T = read_html("data/notable.html");', 'T = load_html("data/notable.html");\npublish(T.title);'),
    ],
}

# ================================================================== 6. YAML and INI
PAGES['yaml-ini'] = {
    'title': 'YAML & INI',
    'summary': 'Configuration files: YAML with anchors, merge keys, environment variables and several documents; '
               'INI with sections, defaults and interpolation.',
    'about': reference(SAMPLES_NOTE, [
        fn('read_yaml(file, path, doc, env, box) / read_yml', 'The document as a dictionary; '
           '<code>path=</code> picks a part (<code>"solver.methods[1].iters"</code>).',
           inputs=[('path', 'dotted path with [index]', 'all'), ('doc', 'which document: 0, 1 ... or "all"', '0'),
                   ('env', 'false: leave <code>${NAME:-default}</code> as written', 'true')],
           more=['Anchors (<code>&amp;base</code>) and merge keys (<code>&lt;&lt;: *base</code>) are resolved; block '
                 'scalars (<code>|</code>) keep their line breaks.'],
           syntax='read_yaml("data/config.yaml", path="solver.methods[1].iters")\nread_yaml("data/config.yaml", doc="all")',
           short='a configuration as a dictionary'),
        fn('load_yaml(file) / load_yml', 'An object: <code>D.database.host</code>, <code>.sections</code>, '
           '<code>.docs</code>, <code>.anchors</code>, <code>.comments</code>, <code>.env_vars</code>.',
           syntax='D = load_yaml("data/config.yaml");\nD.solver.methods[0].name'),
        fn('save_yaml(file, data, indent, sort_keys, flow, multi_doc, boxes, mode) / save_yml', 'Writes a dictionary '
           'or several documents.', inputs=[('flow', 'true: compact {a: 1} style', 'false'),
                                            ('multi_doc', 'true: a list becomes several documents', 'false')],
           syntax='save_yaml("out/y2.yaml", C, indent=4, sort_keys=true)'),
        fn('read_ini(file, sec, key, interp, box)', 'All sections, one section, or one key; '
           '<code>%(name)s</code> references are filled in from the same section or [DEFAULT].',
           inputs=[('sec', 'a section', 'all'), ('key', 'a key (in sec, or the first section that has it)', 'all'),
                   ('interp', 'false: leave %(name)s as written', 'true')],
           syntax='read_ini("data/config.ini", sec="Database", key="path")'),
        fn('load_ini(file) / save_ini(file, data, sec, delim, boxes, mode)', 'An object '
           '(<code>D.Database.port</code>, <code>.defaults</code>, <code>.sections</code>); writing takes a '
           'section &rarr; key &rarr; value dictionary, or a flat one with <code>sec=</code>.',
           syntax='D = load_ini("data/config.ini");\nD.Database.enabled', short='INI as an object; writing INI'),
    ]),
    'examples': {
        'basic': ex('YAML parts', 'Merged keys, an environment variable with a default, a list item and a second '
                    'document.', '''
C = read_yaml("data/config.yaml");
publish(C["database"]);
publish(read_yaml("data/config.yaml", path="server.db"));
publish(read_yaml("data/config.yaml", path="server.db", env=false));
publish(read_yaml("data/config.yaml", path="solver.methods[1].iters"));
publish(read_yaml("data/config.yaml", doc=1));
'''),
        'mid': ex('INI sections and interpolation', 'One key with and without interpolation, a key from [DEFAULT], '
                  'and the object view.', '''
db = read_ini("data/config.ini", sec="Database")
p = read_ini("data/config.ini", sec="Database", key="path")
raw = read_ini("data/config.ini", sec="Database", key="path", interp=false)
t = read_ini("data/config.ini", key="timeout")
D = load_ini("data/config.ini");
publish(D.Database.port, D.Database.enabled, D.sections);
'''),
        'strong': ex('Objects and writing', 'Explore a YAML file, write it with sorted keys and in flow style, and '
                     'write an INI file from dictionaries.', '''
D = load_yaml("data/config.yaml");
publish(D.database.host, D.database.port, D.solver.methods[0].name);
publish(D.server.notes);
C = read_yaml("data/config.yaml");
n2 = save_yaml("out/y2.yaml", C, indent=4, sort_keys=true);
publish(read_yaml("out/y2.yaml", path="solver.tol"));
n3 = save_yaml("out/y3.yaml", C, flow=true);
publish(read_yaml("out/y3.yaml", path="database.name"));
flat = dict(["user", "retries"], ["admin", 3]);
n4 = save_ini("out/i2.ini", flat, sec="Login", delim=": ");
publish(read_ini("out/i2.ini"));
P = load_yml("data/config.yml");
publish(P.pipeline.filter.cutoff_hz, P.pipeline.stages);
'''),
    },
    'errors': [
        err('A tab used for indentation', 'YAML needs spaces.', 'Y = read_yaml("data/tab.yaml");',
            'Y = read_yaml("data/config.yaml", path="database.name");\npublish(Y);'),
        err('A nested dictionary in INI', 'INI holds section &rarr; key &rarr; value only.',
            'd = dict();\ninner = dict();\ninner["deep"] = dict(["x"], [1]);\nd["S"] = inner;\nn = save_ini("out/e.ini", d);',
            'd = dict();\nd["S"] = dict(["x"], [1]);\nn = save_ini("out/e.ini", d);\npublish(read_ini("out/e.ini"));'),
    ],
}

# ================================================================== 7. Binary and custom layouts
PAGES['binary-custom'] = {
    'title': 'Binary & Custom Layouts',
    'summary': 'Raw binary files of any number type and byte order, records laid out like C structures, and '
               'custom files that carry their own layout description.',
    'about': reference('Types are written <code>"float32"</code>, <code>"uint16"</code> ... or, for records, as '
                       'fields <code>"id:i4,val:f8,name:8s"</code> (i4 = int32, f8 = float64, 8s = 8 bytes of text). '
                       'A value that does not fit the type is an error, never a silent overflow.', [
        fn('read_bin(file, dtype, shape, offset, box_bytes, count, stride, endian, align)', 'The values in the file; '
           'with two outputs also <code>.boxes</code> (the header bytes) and <code>.records</code>.',
           inputs=[('dtype', 'number type or record layout', '"uint8"'), ('shape', 'reshape the values', 'one row'),
                   ('offset', 'bytes to skip first', '0'), ('box_bytes', 'bytes of header kept as an info box', '0'),
                   ('count', 'how many values', 'all'), ('stride', 'bytes from one value to the next', 'the type size'),
                   ('endian', '"little" or "big"', '"little"'), ('align', 'record alignment in bytes', '1')],
           syntax='B = read_bin("out/b1.bin", dtype="float32", shape=[2, 3], box_bytes=12)'),
        fn('save_bin(file, data, dtype, endian, align, pad_byte, boxes, compress, mode)', 'Writes values or records; '
           '<code>boxes=</code> writes a header first.', syntax='save_bin("out/b2.bin", [1, 256, 65535], dtype="uint16", endian="big")'),
        fn('load_bin(file, dtype, ...)', 'An object: fields by name, <code>.size</code>, <code>.endian</code>, '
           '<code>.records</code>, <code>.header</code>, and <code>.slice_bytes(start, n)</code>, '
           '<code>.view(type, count, shape)</code> to look at the bytes another way.',
           syntax='D = load_bin("out/b3.bin", dtype="id:i4,val:f8,name:8s");\nD.name\nD.view("uint8", shape=[2, 2])'),
        fn('read_custom / load_custom / save_custom', 'Like the binary functions, but the layout travels in a '
           'companion file <code>&lt;file&gt;.schema.json</code>, so reading needs no arguments.',
           syntax='save_custom("out/s1.custom", T, dtype="t:f8,v:i2")\nC = read_custom("out/s1.custom")',
           short='binary files with their layout in a companion file'),
    ]),
    'examples': {
        'basic': ex('Numbers in a binary file', 'float32 values behind a 12-byte header, and the same bytes read '
                    'in different ways.', '''
A = [1.5, 2, 3; 4, 5, 6.25];
n1 = save_bin("out/b1.bin", A, dtype="float32", boxes="MAGIC_HDR_v1");
B = read_bin("out/b1.bin", dtype="float32", shape=[2, 3], box_bytes=12)
[raw, info] = read_bin("out/b1.bin", box_bytes=12, count=4);
publish(raw, info.boxes);
mid = read_bin("out/b1.bin", dtype="float32", offset=12, count=2)
'''),
        'mid': ex('Byte order and records', 'The same uint16 bytes read big- and little-endian, and records with '
                  'a number, a decimal and a text field.', '''
n2 = save_bin("out/b2.bin", [1, 256, 65535], dtype="uint16", endian="big");
be = read_bin("out/b2.bin", dtype="uint16", endian="big")
le = read_bin("out/b2.bin", dtype="uint16")
recs = ["id", "val", "name"; 1, 2.5, "alpha"; 2, -7.25, "beta"];
n3 = save_bin("out/b3.bin", recs, dtype="id:i4,val:f8,name:8s");
R = read_bin("out/b3.bin", dtype="id:i4,val:f8,name:8s")
'''),
        'strong': ex('Objects, views and self-describing files', 'Explore records as an object, view raw bytes, '
                     'then write a custom file whose layout travels with it.', '''
recs = ["id", "val", "name"; 1, 2.5, "alpha"; 2, -7.25, "beta"];
n3 = save_bin("out/b3.bin", recs, dtype="id:i4,val:f8,name:8s");
D = load_bin("out/b3.bin", dtype="id:i4,val:f8,name:8s");
publish(D.size, D.endian, D.name, D.val);
publish(D.slice_bytes(0, 4), D.view("int32", count=1));
T = ["t", "v"; 0.1, 10; 0.2, 20; 0.3, 30];
n = save_custom("out/s1.custom", T, dtype="t:f8,v:i2", boxes="SENSOR01");
[C, info] = read_custom("out/s1.custom");
C
publish(info.schema, info.boxes);
'''),
    },
    'errors': [
        err('A value that does not fit the type', 'uint8 holds 0 to 255.', 'n = save_bin("out/e.bin", [12, 300], dtype="uint8");',
            'n = save_bin("out/e.bin", [12, 300], dtype="uint16");\npublish(read_bin("out/e.bin", dtype="uint16"));'),
        err('Bytes that do not divide into the type', 'Three bytes cannot be read as 2-byte int16 values.',
            'n = save_bin("out/e.bin", [1, 2, 3], dtype="int8");\nx = read_bin("out/e.bin", dtype="int16");',
            'n = save_bin("out/e.bin", [1, 2, 3], dtype="int8");\nx = read_bin("out/e.bin", dtype="int8");\npublish(x);'),
    ],
}

# ================================================================== 8. Spreadsheets
PAGES['spreadsheets'] = {
    'title': 'Spreadsheets',
    'summary': 'Excel workbooks (xlsx, xls, xlsm, xlsb): sheets, ranges, formulas and their values, styles, frozen '
               'headers and notes.',
    'about': reference('The four formats share their functions; <code>.xlsb</code> can be read but not written.', [
        fn('read_xlsx(file, sheet, range, hdr, cols, eval_fml) / read_xls / read_xlsm / read_xlsb', 'A sheet as a '
           'table; formulas give their values.',
           inputs=[('sheet', 'name or number (1-based)', 'the first'), ('range', 'e.g. "A1:B2"', 'the used area'),
                   ('eval_fml', 'false: give formulas as written', 'true')],
           syntax='read_xlsx("out/w1.xlsx", sheet=2, range="A1:B2", hdr=0)', short='a sheet or range as a table'),
        fn('load_xlsx(file) / load_xls / load_xlsm', 'An object: <code>.sheets</code>, sheets by name, columns by '
           'name, and <code>.cell("F5")</code> with <code>.val</code>, <code>.fml</code>, <code>.style</code>; '
           '<code>.merged</code> lists merged cells.', syntax='D = load_xlsx("out/w1.xlsx");\nD.ABC.cell("F5").val'),
        fn('save_xlsx(file, data, sheet, sheets, fml, boxes, freeze, start, fit_cols, mode, level) / save_xls / save_xlsm',
           'Writes one sheet or several; <code>fml=</code> adds formulas by cell, <code>boxes=</code> notes by cell, '
           '<code>freeze="A2"</code> freezes the header, <code>mode="a"</code> adds sheets to a workbook.',
           syntax='save_xlsx("out/w1.xlsx", T, sheet="ABC", fml=f, freeze="A2", fit_cols=true)',
           short='write sheets with formulas, notes and frozen headers'),
    ]),
    'examples': {
        'basic': ex('A workbook with formulas', 'A table with two formulas and a note, read back as values.', '''
T = load_csv("data/sensors.csv");
f = dict();
f["F2"] = "=C2*2";
f["F5"] = "=SUM(C2:C4)";
b = dict();
b["H2"] = "Note: calibrated";
n = save_xlsx("out/w1.xlsx", T.default, sheet="ABC", fml=f, boxes=b, freeze="A2", fit_cols=true);
[R, info] = read_xlsx("out/w1.xlsx");
R
publish(info.cols, info.boxes);
'''),
        'mid': ex('Several sheets and ranges', 'Add sheets to the workbook, then read by name, by number with a range, '
                  'and with formulas as written.', '''
n = save_xlsx("out/w1.xlsx", [1, 2; 3, 4], sheet="Main");
sh = dict();
sh["S1"] = [1, 2; 3, 4];
sh["S2"] = ["k", "v"; "a", 1];
n2 = save_xlsx("out/w1.xlsx", sheets=sh, mode="a");
D = load_xlsx("out/w1.xlsx");
publish(D.sheets);
publish(read_xlsx("out/w1.xlsx", sheet="S2"));
publish(read_xlsx("out/w1.xlsx", sheet=2, range="A1:B2", hdr=0));
'''),
        'strong': ex('Cells, formulas and other formats', 'Values, formulas and styles of single cells, and the same '
                     'table as an old-style .xls and a macro-enabled .xlsm.', '''
T = load_csv("data/sensors.csv");
f = dict();
f["F5"] = "=SUM(C2:C4)";
n = save_xlsx("out/w1.xlsx", T.default, sheet="ABC", fml=f);
D = load_xlsx("out/w1.xlsx");
publish(D.ABC.Temp);
publish(D.ABC.cell("F5").val, D.ABC.cell("F5").fml);
publish(read_xlsx("out/w1.xlsx", eval_fml=false, cols=["Temp"]));
x = save_xls("out/w2.xls", T.default, fml=f);
L = load_xls("out/w2.xls");
publish(L.default.cell("F5").val);
m = save_xlsm("out/w3.xlsm", [1, 2; 3, 4], level=9);
publish(read_xlsm("out/w3.xlsm", hdr=0));
'''),
    },
    'errors': [
        err('Writing .xlsb', 'Save as .xlsx: Excel opens both the same way.', 'n = save_xlsb("out/x.xlsb", [1, 2]);',
            'n = save_xlsx("out/x.xlsx", [1, 2]);\npublish(n > 0);'),
    ],
}

# ================================================================== 9. Images
PAGES['images'] = {
    'title': 'Images',
    'summary': 'PNG, JPEG, TIFF, BMP, GIF and DICOM images: pixels as an array, regions, channels, scaling, '
               'resolution and metadata.',
    'about': reference('An image is an array of rows x columns x channels; pixels come back as <code>uint8</code> '
                       'unless you ask for another <code>dtype</code>. PNG, TIFF and BMP store pixels exactly; JPEG and '
                       'GIF stay close.', [
        fn('read_png(file, roi, channels, dtype, scale) / read_jpg / read_jpeg / read_tiff / read_bmp / read_gif / read_dicom',
           'The pixels, or a part of them.',
           inputs=[('roi', '[x, y, width, height] in pixels', 'the whole image'),
                   ('channels', '"gray", "rgb", "rgba"', 'as stored'), ('dtype', '"uint8", "float32", "float64"', 'as stored'),
                   ('scale', '[width, height] to resize to', 'none')],
           more=['Only the rows (or tiles) a region covers are decoded.'],
           syntax='P = read_png("out/t.png", roi=[30, 20, 4, 6], channels="gray", dtype="float32");',
           short='pixels as an array; regions, channels, scaling'),
        fn('load_png(file) / load_…', 'An image object: <code>.width</code>, <code>.channels</code>, the DICOM '
           '<code>.patient</code> and <code>.modality</code>, ...', syntax='L = load_png("out/t.png");\nL.width'),
        fn('save_png(file, I, dpi, boxes, level) / save_jpg(quality) / save_jpeg(progressive, subsampling) / '
           'save_tiff(codec) / save_bmp / save_gif / save_dicom(patient, anonymize)', 'Writes an image; each format has '
           'its own options.', syntax='save_png("out/t.png", I, dpi=300)\nsave_jpg("out/t.jpg", I, quality=90)',
           short='write in any of the seven formats'),
    ]),
    'examples': {
        'basic': ex('Make, save and read an image', 'A synthetic 48 x 64 colour image, saved as PNG and read back '
                    'exactly, with its type and resolution.', '''
I = zeros([48, 64, 3]);
I[:, :, 0] = 200;
I[0:23, :, 1] = 120;
I[:, 0:31, 2] = 60;
n1 = save_png("out/t.png", I, dpi=300, boxes=dict(["Title"], ["Fig1"]), level=9);
P = read_png("out/t.png");
publish("size:", size(P), "  type:", type(P));
publish("exact:", max(abs(flatten(P) - flatten(I))) == 0);
'''),
        'mid': ex('Lossless and lossy formats', 'The same image in five more formats: PNG, TIFF and BMP give the '
                  'pixels back exactly; JPEG and GIF stay within a few levels.', '''
I = zeros([48, 64, 3]);
I[:, :, 0] = 200;
I[0:23, :, 1] = 120;
I[:, 0:31, 2] = 60;
n2 = save_jpg("out/t.jpg", I, quality=90);
n4 = save_tiff("out/t.tiff", I, codec="deflate");
n5 = save_bmp("out/t.bmp", I);
n6 = save_gif("out/t.gif", I);
publish("tiff exact:", max(abs(flatten(read_tiff("out/t.tiff")) - flatten(I))) == 0);
publish("bmp exact :", max(abs(flatten(read_bmp("out/t.bmp")) - flatten(I))) == 0);
publish("jpg close :", mean(abs(flatten(read_jpg("out/t.jpg")) - flatten(I))) < 3);
publish("gif close :", mean(abs(flatten(read_gif("out/t.gif")) - flatten(I))) < 3);
'''),
        'strong': ex('Regions, channels and DICOM', 'A small grey region as decimals, a scaled copy, and a medical '
                     'DICOM file with patient data.', '''
I = zeros([48, 64, 3]);
I[:, :, 0] = 200;
I[0:23, :, 1] = 120;
n1 = save_png("out/t.png", I, dpi=300);
[P, pi] = read_png("out/t.png", roi=[30, 20, 4, 6], channels="gray", dtype="float32");
publish(size(P), type(P), pi.dpi);
publish(size(read_png("out/t.png", scale=[32, 24])));
L = load_png("out/t.png");
publish(L.width, L.channels);
n7 = save_dicom("out/t.dicom", read_png("out/t.png", channels="gray"), patient=dict(["Name"], ["Doe^J"]), anonymize=false);
D = load_dicom("out/t.dicom");
publish(D.patient, D.modality);
'''),
    },
}

# ================================================================== 10. Audio and video
TONE = '''t = [0:44099] / 44100;
st = transpose([sin(2 * pi * 440 * t); 0.5 * sin(2 * pi * 660 * t)]);
'''
FRAMES = '''F = zeros([6, 48, 64, 3]);
for k in [0:5]:
  F[k, :, :, 0] = 40 * k;
  F[k, 0:23, :, 1] = 200;
  F[k, :, 0:31, 2] = 120;
fend
'''
PAGES['audio-video'] = {
    'title': 'Audio & Video',
    'summary': 'Sound as an array of samples (WAV, FLAC; tags and length of OGG and MP3) and video as an array of '
               'frames (MP4, AVI, M4V, MOV), with time windows, regions and audio tracks.',
    'about': reference('Sound is samples x channels; video is frames x rows x columns x colours, frames numbered from '
                       '0. Times are in seconds.', [
        fn('[y, fs, info] = read_wav(file, dtype, start, dur, mono, fs) / read_flac', 'The samples, the sample rate '
           'and an info dictionary (tags as info boxes).',
           inputs=[('dtype', '"auto" (the file\'s own type, e.g. int16), "float32", "float64" (&minus;1 to 1)', '"auto"'),
                   ('start, dur', 'a time window in seconds', 'all'), ('mono', 'true: mix to one channel', 'false'),
                   ('fs', 'resample to this rate', 'as stored')],
           syntax='[a, afs, ai] = read_wav("out/s.wav", dtype="float64");', short='samples and sample rate'),
        fn('save_wav(file, y, fs, bits, norm, boxes) / save_flac(file, y, fs, bits, max_size)', 'Writes sound; FLAC is '
           'compressed without loss.', syntax='save_flac("out/s.flac", st, fs=44100, bits=24)'),
        fn('load_flac(file) / load_wav', 'A sound object: <code>.duration</code>, <code>.left</code>, '
           '<code>.slice(t0, t1)</code>.', syntax='D = load_flac("out/s.flac");\nS = D.slice(0.25, 0.5);'),
        fn('[V, info] = read_mp4(file, frames, time, stride, roi, scale, gray, audio) / read_avi / read_m4v / read_mov',
           'The frames, or some of them; <code>audio=true</code> also gives the sound track in '
           '<code>info.audio</code>.',
           inputs=[('frames', 'frame numbers', 'all'), ('time', '[t0, t1] in seconds', 'all'),
                   ('stride', 'every n-th frame', '1'), ('roi', '[x, y, width, height]', 'all'),
                   ('scale', '[width, height]', 'none'), ('gray', 'true: one channel', 'false')],
           syntax='V = read_avi("out/v.avi", frames=[0, 2, 4], roi=[10, 10, 20, 16]);', short='frames as an array'),
        fn('save_mp4(file, F, fps, codec, crf, bitrate, max_size, audio, boxes) / save_avi / save_m4v / save_mov',
           'Writes video: H.264 (exact, large) or MJPEG (compact); MOV and AVI can carry PCM audio; '
           '<code>boxes=</code> become subtitles.', syntax='save_avi("out/v.avi", F, fps=10, codec="mjpeg", crf=18)',
           short='write video, with sound and subtitles'),
        fn('load_avi(file) / load_mp4 / …', 'A video object: <code>.codec</code>, <code>.count</code>, '
           '<code>.fps</code>, <code>.frame(k)</code>, <code>.at_time(t)</code>, <code>.read(frames=...)</code>.',
           syntax='D = load_avi("out/v.avi");\nD.frame(5)'),
    ]),
    'examples': {
        'basic': ex('A stereo tone', 'One second of 440 Hz and 660 Hz, saved as WAV and FLAC, read back.', TONE + '''
n1 = save_wav("out/s.wav", st, fs=44100, boxes=dict(["title"], ["TestTone"]));
n2 = save_flac("out/s.flac", st, fs=44100, bits=24);
[a, afs, ai] = read_wav("out/s.wav", dtype="float64");
publish("rate:", afs, "  tags:", ai.boxes, "  close:", max(abs(flatten(a) - flatten(st))) < 0.0001);
publish("default type:", type(read_wav("out/s.wav")));
[b, bfs, bi] = read_flac("out/s.flac", dtype="float64");
publish("flac close:", max(abs(flatten(b) - flatten(st))) < 0.00001);
'''),
        'mid': ex('Windows of sound', 'A tenth of a second from the middle, mixed to mono and resampled; and a slice '
                  'of a loaded file.', TONE + '''
n2 = save_flac("out/s.flac", st, fs=44100, bits=24);
publish(size(read_flac("out/s.flac", start=0.5, dur=0.1, mono=true, fs=8000)));
D = load_flac("out/s.flac");
S = D.slice(0.25, 0.5);
publish(D.duration, S.duration, size(S.left));
'''),
        'strong': ex('A short video', 'Six frames that brighten, saved as MP4 and as MJPEG with sound, then read in '
                     'parts.', FRAMES + '''
n1 = save_mp4("out/v.mp4", F, fps=10, boxes=["hello", "world"]);
[V, info] = read_mp4("out/v.mp4");
publish(size(V), info.subtitles);
publish(V[3, 10, 50, :]);
n3 = save_mov("out/v.mov", F, fps=10, codec="mjpeg", audio=[0:4409] / 4410);
publish(size(read_mov("out/v.mov", time=[0.1, 0.4], stride=2, scale=[32, 24], gray=true)));
[W, wi] = read_mov("out/v.mov", frames=[0], audio=true, box=false);
publish(wi.audio.fs);
n2 = save_avi("out/v.avi", F, fps=10, codec="mjpeg", crf=18);
D = load_avi("out/v.avi");
publish(D.codec, D.count, D.fps);
'''),
    },
    'errors': [
        err('A codec that is not built in', 'Use "h264" or "mjpeg".', 'n = save_mp4("out/e.mp4", zeros([2, 16, 16, 3]), codec="hevc");',
            'n = save_mp4("out/e.mp4", zeros([2, 16, 16, 3]), codec="mjpeg");\npublish(n > 0);'),
        err('An odd frame size for H.264', 'H.264 needs an even height and width.', 'n = save_mp4("out/e.mp4", zeros([2, 15, 16, 3]));',
            'n = save_mp4("out/e.mp4", zeros([2, 16, 16, 3]));\npublish(n > 0);'),
        err('Sound in an MP4', 'MP4 sound needs AAC, which is not built in: use MOV or AVI.',
            'n = save_mp4("out/e.mp4", zeros([2, 16, 16, 3]), codec="mjpeg", audio=[0, 0.1, 0.2]);',
            'n = save_mov("out/e.mov", zeros([2, 16, 16, 3]), codec="mjpeg", audio=[0, 0.1, 0.2]);\npublish(n > 0);'),
        err('A WAV file read as MP3', 'The reader checks the content.', 'n = save_wav("out/e.wav", [0, 0.5, -0.5]);\ny = read_mp3("out/e.wav");',
            'n = save_wav("out/e.wav", [0, 0.5, -0.5]);\ny = read_wav("out/e.wav", dtype="float64");\npublish(y);'),
    ],
}

# ================================================================== 11. MATLAB and FITS
PAGES['matlab-fits'] = {
    'title': 'MATLAB & FITS',
    'summary': 'MATLAB data files (v5, v7, v7.3) and figures, and FITS files from astronomy with several HDUs, '
               'header keywords and sky coordinates.',
    'about': reference('A MAT file holds named variables: write a dictionary, read back a dictionary or chosen '
                       'variables. A FITS file holds HDUs: a primary image, tables and more images.', [
        fn('read_mat(file, vars, slice, struct_as) / load_mat / save_mat(file, vars, ver, boxes, mode)', 'MATLAB '
           'variables: all or some, with a slice of a large one; structs as dictionaries or objects. '
           '<code>ver</code> is "v5", "v7" or "v7.3".',
           syntax='x = read_mat("out/m1.mat", vars=["x"])\nsave_mat("out/m3.mat", v, ver="v7.3")', short='MATLAB data files'),
        fn('read_fig(file, series, props) / load_fig / save_fig(file, fig, boxes)', 'MATLAB figures: the plotted data '
           '(<code>G.axes[0].lines[0].y</code>), titles and labels.', syntax='G = load_fig("out/f1.fig");\nG.axes[0].title',
           short='MATLAB figures'),
        fn('read_fits(file, hdu, cols, slice) / read_fit', 'An HDU by number or name: an image, or a table with '
           'chosen columns.', inputs=[('hdu', 'number (0 = primary) or name', '0'), ('cols', 'table columns', 'all'),
                                      ('slice', 'part of an image, 1-based: "1:2, 2:3"', 'all')],
           syntax='read_fits("out/a.fits", hdu="CAT", cols=["FLUX"])', short='an image or a table from a FITS file'),
        fn('load_fits(file) / save_fits(file, data, header, bitpix, hdu_name, compress, boxes, mode) / save_fit',
           'The file as an object (<code>.hdu_names</code>, <code>.primary.header.TELESCOP</code>, '
           '<code>.CAT.FLUX</code>, <code>.primary.pix2world(x, y)</code> for sky coordinates); writing adds HDUs '
           'with <code>mode="a"</code>.', syntax='D = load_fits("out/a.fits");\nD.primary.pix2world(1, 1)',
           short='FITS as an object; writing HDUs'),
    ]),
    'examples': {
        'basic': ex('Variables in a MAT file', 'A matrix, a range, a struct, text and a cell list, written and read '
                    'back whole and in part.', '''
cfg = dict();
cfg["gain"] = 1.25;
cfg["name"] = "rig";
v = dict();
v["x"] = [1, 2, 3; 4, 5, 6];
v["y"] = [10:15];
v["cfg"] = cfg;
v["note"] = "hello";
n1 = save_mat("out/m1.mat", v);
M = read_mat("out/m1.mat")
x = read_mat("out/m1.mat", vars=["x"])
s = read_mat("out/m1.mat", vars=["x"], slice=dict(["x"], ["1:2, 2:3"]))
'''),
        'mid': ex('Versions, objects and figures', 'The same variables as v5 and v7.3, a struct as an object, and a '
                  'MATLAB figure.', '''
v = dict();
v["x"] = [1, 2, 3; 4, 5, 6];
cfg = dict();
cfg["gain"] = 1.25;
v["cfg"] = cfg;
n2 = save_mat("out/m2.mat", v, ver="v5");
n3 = save_mat("out/m3.mat", v, ver="v7.3");
publish(load_mat("out/m2.mat").version, load_mat("out/m3.mat").version);
[r, info] = read_mat("out/m3.mat", vars=["cfg"], struct_as="object");
publish(r.gain);
f = dict();
f["x"] = [0:10];
f["y"] = [0:10] * 2;
f["title"] = "Ramp";
n4 = save_fig("out/f1.fig", f);
G = load_fig("out/f1.fig");
publish(G.axes[0].title, G.axes[0].lines[0].y);
'''),
        'strong': ex('A FITS file with three HDUs', 'An image with a sky-coordinate header, a source catalogue and a '
                     'compressed science image, then read by HDU and turned into sky coordinates.', '''
img = [1, 2, 3; 4, 5, 6] * 1000;
h = dict();
h["TELESCOP"] = "HST";
h["CRPIX1"] = 1;
h["CRPIX2"] = 1;
h["CRVAL1"] = 150.0;
h["CRVAL2"] = 2.0;
h["CD1_1"] = -0.0001;
h["CD2_2"] = 0.0001;
h["CTYPE1"] = "RA---TAN";
h["CTYPE2"] = "DEC--TAN";
n1 = save_fits("out/a.fits", img, header=h, bitpix=16);
cat = ["RA", "DEC", "FLUX"; 150.1, 2.2, 31.5; 150.2, 2.3, 12.25];
n2 = save_fits("out/a.fits", cat, hdu_name="CAT", mode="a");
n3 = save_fits("out/a.fits", img, hdu_name="SCI", bitpix=32, compress="rice", mode="a");
D = load_fits("out/a.fits");
publish(D.hdu_names, D.primary.header.TELESCOP);
publish(read_fits("out/a.fits", hdu="CAT", cols=["FLUX"]));
publish(read_fits("out/a.fits", hdu=0, slice="1:2, 2:3"));
publish(D.primary.pix2world(1, 1), D.primary.pix2world(101, 1));
'''),
    },
}

# ================================================================== 12. HDF5 and NetCDF
GRID = '''lat = [10, 12.5, 15, 17.5, 20];
lon = [75, 80, 85];
temp = reshape([1:30], [2, 5, 3]) + 270;
cs = dict();
cs["lat"] = lat;
cs["lon"] = lon;
'''
PAGES['hdf5-netcdf'] = {
    'title': 'HDF5 & NetCDF',
    'summary': 'Large scientific datasets: HDF5 groups, datasets, attributes, chunks and compression (also HDF-EOS5), '
               'and NetCDF variables on named dimensions with coordinates and units.',
    'about': reference('Slices are written as text and are 1-based, like the files\' own tools: '
                       '<code>"1:2, 2, 3:4"</code>; a single index drops that dimension. Only the slice is read from '
                       'the file.', [
        fn('read_h5(file, path, slice, attr, box) / read_hdf', 'A dataset; with two outputs also '
           '<code>.datasets</code>, <code>.shape</code>, <code>.boxes</code>.',
           inputs=[('path', 'dataset path such as "/grid"', 'the first'), ('slice', 'a part, 1-based', 'all'),
                   ('attr', 'false: skip the attributes', 'true')],
           syntax='read_h5("out/b.h5", path="/grid", slice="1:2, 2, 3:4")', short='a dataset, or part of one'),
        fn('save_h5(file, data, path, attrs, chunks, compress, level, shuffle, boxes, mode) / save_hdf', 'One array '
           '(to /data) or a dictionary (one dataset per key); <code>mode="a"</code> adds datasets.',
           inputs=[('compress', '"gzip", "lzf" or "none"', '"gzip"'), ('chunks', 'chunk shape, or "none"', 'automatic')],
           syntax='save_h5("out/b.h5", d, attrs=dict(["units"], ["K"]), chunks=[1, 2], level=6)'),
        fn('load_h5(file) / load_hdf', 'The file as an object: datasets and groups by name with '
           '<code>.shape</code>, <code>.data</code>, <code>.chunks</code>, <code>.compression</code>, '
           '<code>.attrs</code>, and <code>.read(slice)</code> to read a part later.',
           syntax='D = load_h5("out/b.h5");\nD.grid.read("1, :, 1")'),
        fn('read_he5 / load_he5 / save_he5', 'HDF-EOS5 (earth-observation HDF5): data goes into swaths.',
           syntax='read_he5("out/e.he5", swath="Swath1", path="temp")', short='HDF-EOS5 swaths'),
        fn('read_nc(file, var, coords, slice, scale, box) / read_cdf', 'A variable; <code>coords=</code> selects by '
           'coordinate value (nearest), <code>scale=false</code> skips scale_factor / add_offset.',
           inputs=[('var', 'variable name', 'the main one'), ('coords', 'dictionary of coordinate values', 'all'),
                   ('slice', 'a part, 1-based', 'all')],
           syntax='cc = dict();\ncc["lat"] = [12, 18];\nread_nc("out/w4.nc", coords=cc)', short='a variable, by coordinates or slice'),
        fn('save_nc(file, data, var, dims, coords, units, fill_val, unlimited, format, compress, level, boxes) / save_cdf',
           'Writes a variable on named dimensions with coordinates; <code>format</code> is "netcdf4" (compressed), '
           '"classic" or "64bit".', syntax='save_nc("out/w4.nc", temp, var="temp", dims=["time", "lat", "lon"], coords=cs, units="K")'),
        fn('load_nc(file) / load_cdf', 'An object: <code>.vars</code>, <code>.dims</code>, <code>.coords</code>, '
           '<code>.attrs</code>, and per variable <code>.sel(lat=13, lon=80)</code> and <code>.fill_val</code>.',
           syntax='D = load_nc("out/w4.nc");\nD.temp.sel(lat=13, lon=80)'),
    ]),
    'examples': {
        'basic': ex('Datasets in an HDF5 file', 'A dictionary of three datasets with attributes and chunks, read '
                    'whole and in slices.', '''
d = dict();
d["temp"] = [10.5, 11.5, 12.5, 13.5];
d["name"] = "run 7";
d["grid"] = reshape([1:24], [2, 3, 4]);
n2 = save_h5("out/b.h5", d, attrs=dict(["units"], ["K"]), boxes="Run notes", chunks=[1, 2], level=6);
[T, info] = read_h5("out/b.h5");
publish(info.datasets, info.boxes);
s = read_h5("out/b.h5", path="/grid", slice="1:2, 2, 3:4")
'''),
        'mid': ex('The HDF5 object', 'Shapes, chunks, lazy reads, and a compressed dataset added to the file.', '''
d = dict();
d["temp"] = [10.5, 11.5, 12.5, 13.5];
d["grid"] = reshape([1:24], [2, 3, 4]);
n2 = save_h5("out/b.h5", d, chunks=[1, 2]);
D = load_h5("out/b.h5");
publish(D.datasets, D.temp.shape, D.grid.chunks);
publish(D.grid.read("1, :, 1"));
publish(D.read("temp", "2:3"));
n3 = save_h5("out/b.h5", [7, 8, 9], path="/extra/v", mode="a", compress="lzf");
E = load_h5("out/b.h5");
publish(E.extra.v.data, E.extra.v.compression);
'''),
        'strong': ex('A NetCDF temperature grid', 'Two times on a 5 x 3 latitude-longitude grid, in three NetCDF '
                     'formats, read by coordinate value.', GRID + '''
n1 = save_nc("out/w4.nc", temp, var="temp", dims=["time", "lat", "lon"], coords=cs, units="K", fill_val=-9999, unlimited="time", boxes=dict(["title"], ["Ocean Model"]));
n2 = save_nc("out/wc.nc", temp, var="temp", dims=["time", "lat", "lon"], coords=cs, units="K", format="classic");
n3 = save_cdf("out/w64.cdf", temp, var="temp", dims=["time", "lat", "lon"], coords=cs, format="64bit", compress="none");
for f in ["out/w4.nc", "out/wc.nc", "out/w64.cdf"]:
  D = load_nc(f);
  publish(D.format, D.dims, D.temp.sel(lat=13, lon=80));
fend
[T, info] = read_nc("out/w4.nc");
publish(info.units, info.coords);
cc = dict();
cc["lat"] = [12, 18];
cc["lon"] = 85;
publish(read_nc("out/w4.nc", coords=cc, slice="2"));
'''),
    },
    'errors': [
        err('A compression that is not built in', 'HDF5 files use gzip or lzf.', 'n = save_h5("out/e.h5", [1, 2, 3], compress="zstd");',
            'n = save_h5("out/e.h5", [1, 2, 3], compress="lzf");\npublish(read_h5("out/e.h5"));'),
        err('A slice outside the dataset', 'The dataset has 3 elements.', 'n = save_h5("out/e.h5", [1, 2, 3]);\nx = read_h5("out/e.h5", path="/data", slice="1:5");',
            'n = save_h5("out/e.h5", [1, 2, 3]);\nx = read_h5("out/e.h5", path="/data", slice="1:3");\npublish(x);'),
        err('A coordinate of the wrong length', 'lat has 2 values but the data is 3 long along lat.',
            'c = dict();\nc["lat"] = [1, 2];\nx = save_nc("out/e.nc", zeros([2, 3]), dims=["time", "lat"], coords=c);',
            'c = dict();\nc["lat"] = [1, 2, 3];\nx = save_nc("out/e.nc", zeros([2, 3]), dims=["time", "lat"], coords=c);\npublish(x > 0);'),
        err('A variable that does not exist', 'NC lists the variables.', 'n = save_nc("out/e.nc", [1, 2, 3], var="temp");\nx = read_nc("out/e.nc", var="pressure");',
            'n = save_nc("out/e.nc", [1, 2, 3], var="temp");\nx = read_nc("out/e.nc", var="temp");\npublish(x);'),
    ],
}

# ================================================================== 13. Columnar files
TABLE = 'T = ["time", "sensor_1", "site", "ok"; 1, 0.25, "north", true; 2, 0.75, "south", false; 3, 0.5, "north", true; 4, 0.9, "east", true];\n'
PAGES['columnar-files'] = {
    'title': 'Columnar Files: Parquet, Feather, ORC',
    'summary': 'Column-oriented files for large tables: codecs, row groups, filters applied while reading, '
               'statistics, footer metadata, partitioned folders and split files.',
    'about': reference('All three formats keep the type of each column and write missing cells as null. A filter '
                       '(<code>where=</code>) and a row window (<code>rows=</code>) skip the row groups they do not '
                       'need.', [
        fn('read_parquet(file, cols, where, rows, groups, threads, mmap)', 'The table, or a part of it; a folder of '
           'partitioned files is read as one table.',
           inputs=[('cols', 'columns', 'all'), ('where', 'a filter such as "sensor_1 &gt; 0.5"', 'none'),
                   ('rows', 'rows: [1:1], "5:8", "-2:-1" or "1:4:11" (with a step)', 'all'),
                   ('groups', 'row groups to read (1-based)', 'all'), ('threads', 'threads to decode with', 'all cores')],
           syntax='read_parquet("out/a.parquet", cols=["sensor_1", "time"], where="sensor_1 > 0.5")',
           short='a table, filtered while reading'),
        fn('save_parquet(file, T, compress, level, group_rows, dict_enc, part_by, split_size, boxes)', 'Writes a '
           'table; <code>part_by</code> writes one folder per value of a column (Hive partitions); '
           '<code>boxes=</code> become footer metadata.',
           inputs=[('compress', '"snappy", "gzip", "lz4", "zstd" or "none"', '"snappy"'),
                   ('group_rows', 'rows per row group', 'automatic')],
           syntax='save_parquet("out/ds", T, part_by="site")'),
        fn('load_parquet(file)', 'An object: columns by name, <code>.stats</code> per column (min, max, nulls), '
           '<code>.kv_meta</code>, <code>.groups</code>.', syntax='D = load_parquet("out/a.parquet");\nD.stats.sensor_1'),
        fn('read_feather / load_feather / save_feather', 'Arrow IPC files; codecs "zstd", "lz4" or "none".',
           syntax='save_feather("out/f.feather", T, compress="zstd", group_rows=3)', short='Arrow IPC (Feather) files'),
        fn('read_orc / load_orc / save_orc', 'ORC files; codecs "zstd", "snappy", "lz4", "zlib" or "none".',
           syntax='read_orc("out/o.orc", where="time >= 3")', short='ORC files'),
    ]),
    'examples': {
        'basic': ex('Write, inspect, filter', 'A small table to Parquet, its column types and codec, and a filtered '
                    'read.', TABLE + '''
n = save_parquet("out/a.parquet", T, boxes=dict(["author"], ["PASS"]));
[d, info] = read_parquet("out/a.parquet");
d
publish(info.cols, info.types, info.codec, info.boxes);
publish(read_parquet("out/a.parquet", cols=["sensor_1", "time"], where="sensor_1 > 0.5"));
'''),
        'mid': ex('Codecs and row groups', 'The same table with every Parquet codec in row groups of two, and the '
                  'second group read on its own; statistics from the object view.', TABLE + '''
for c in ["snappy", "gzip", "lz4", "none"]:
  m = save_parquet("out/a_" + c + ".parquet", T, compress=c, group_rows=2);
  publish(c, read_parquet("out/a_" + c + ".parquet", groups=[2]));
fend
D = load_parquet("out/a_snappy.parquet");
publish(D.site, D.stats.sensor_1, D.groups[0].rows);
'''),
        'strong': ex('Partitions and the other formats', 'One folder per site, read back as one table; then Feather '
                     'and ORC with filters and row windows.', TABLE + '''
p = save_parquet("out/ds", T, part_by="site");
publish(read_parquet("out/ds"));
m = save_feather("out/f.feather", T, compress="zstd", group_rows=3);
publish(read_feather("out/f.feather", groups=[1]));
publish(read_feather("out/f.feather", rows="-2:-1"));
o = save_orc("out/o.orc", T, compress="zlib", group_rows=3);
publish(read_orc("out/o.orc", where="time >= 3"));
publish(load_orc("out/o.orc").stats.time);
'''),
    },
    'errors': [
        err('A column that does not exist', 'NC lists the columns.', 'n = save_parquet("out/e.parquet", ["a", "b"; 1, 2]);\nx = read_parquet("out/e.parquet", cols=["zz"]);',
            'n = save_parquet("out/e.parquet", ["a", "b"; 1, 2]);\nx = read_parquet("out/e.parquet", cols=["b"]);\npublish(x);'),
        err('A codec Feather does not have', 'Arrow IPC has no snappy.', 'n = save_feather("out/e.feather", ["a"; 1; 2], compress="snappy");',
            'n = save_feather("out/e.feather", ["a"; 1; 2], compress="lz4");\npublish(read_feather("out/e.feather"));'),
    ],
}

# ================================================================== 14. Databases
USERS = 'T = ["id", "name", "age"; 1, "ann", 31; 2, "bob", 22; 3, "cy", 45; 4, "dee", 28];\nn = save_sqlite("out/t.sqlite", T, table="users", pk="id", index="age");\n'
PAGES['databases'] = {
    'title': 'Databases',
    'summary': 'SQLite files directly, PostgreSQL and MySQL servers over their own protocols: tables, SQL queries '
               'with parameters, filters, and writing with append, replace and upsert.',
    'about': reference('SQLite needs no server: the database is one file. For PostgreSQL and MySQL give a URL such '
                       'as <code>"postgresql://user:password@host:5432/db"</code> instead of a file. Oracle and SQL '
                       'Server are not built in.', [
        fn('read_sqlite(file, table, query, params, where, cols, limit)', 'A table, or the result of an SQL query; '
           '<code>?</code> in the query is filled from <code>params</code> (safe against SQL injection).',
           syntax='read_sqlite("out/t.sqlite", query="SELECT name, age FROM users WHERE age > ?", params=[25])',
           short='a table or a query result'),
        fn('save_sqlite(file, T, table, pk, index, batch, mode, boxes)', 'Writes a table; <code>mode</code> is '
           '"append", "replace", "upsert" (update rows with the same key, add the rest) or "fail".',
           syntax='save_sqlite("out/t.sqlite", T, table="users", mode="upsert", pk="id")', short='write a table'),
        fn('load_sqlite(file)', 'An object: <code>.tables</code>, per table <code>.cols</code>, <code>.pk</code>, '
           '<code>.types</code>, <code>.filter(sql)</code>, <code>.limit(n)</code>, and <code>.query(sql)</code>.',
           syntax='D = load_sqlite("out/t.sqlite");\nD.users.filter("age > 25").limit(2)'),
        fn('read_postgresql / save_postgresql / read_mysql / save_mysql', 'The same, on a database server.',
           syntax='T = read_postgresql("postgresql://user:pw@host/db", table="users")', short='database servers'),
    ]),
    'examples': {
        'basic': ex('A table in SQLite', 'Write a table with a primary key and an index, then read it.', USERS + '''
publish(read_sqlite("out/t.sqlite", table="users"));
publish(read_sqlite("out/t.sqlite", table="users", where="age >= 28", cols=["name"], limit=2));
'''),
        'mid': ex('Queries', 'A query with a parameter, chained filters and an aggregate.', USERS + '''
publish(read_sqlite("out/t.sqlite", query="SELECT name, age FROM users WHERE age > ? ORDER BY age DESC", params=[25]));
D = load_sqlite("out/t.sqlite");
publish(D.tables, D.users.cols, D.users.pk, D.users.types);
Q = D.users.filter("age > 25").limit(2);
publish(Q.rows, Q.name);
publish(D.query("SELECT COUNT(*) AS n, AVG(age) AS a FROM users").data);
'''),
        'strong': ex('Upsert and replace', 'Update one row and add another in one call, then add a second table.', USERS + '''
u = save_sqlite("out/t.sqlite", ["id", "name", "age"; 2, "BOB", 23; 5, "eve", 50], table="users", mode="upsert", pk="id");
publish(read_sqlite("out/t.sqlite", table="users"));
r = save_sqlite("out/t.sqlite", ["k"; 1; 2], table="small", mode="replace", boxes="lookup table");
D = load_sqlite("out/t.sqlite");
publish(D.tables, D.small.comment);
'''),
    },
    'errors': [
        err('An unknown write mode', 'NC lists the four modes.', 'n = save_sqlite("out/e.sqlite", ["a"; 1], mode="merge");',
            'n = save_sqlite("out/e.sqlite", ["a"; 1], table="t", mode="replace");\npublish(read_sqlite("out/e.sqlite", table="t"));'),
        err('A server that does not answer', 'NC names the address it tried.',
            'T = read_postgresql("postgresql://u:p@127.0.0.1:1/db", table="x");',
            'n = save_sqlite("out/e.sqlite", ["a"; 1], table="x");\npublish(read_sqlite("out/e.sqlite", table="x"));'),
        err('Oracle', 'Oracle\'s protocol is not built in: export the table, or reach it through PostgreSQL.',
            'T = read_oracle("oracle://user:pw@localhost:1521/XE", table="t");',
            'n = save_sqlite("out/e.sqlite", ["a"; 1], table="t");\npublish(read_sqlite("out/e.sqlite", table="t"));'),
    ],
}

# ================================================================== 15. Maps and GPS
CITIES = ('T = ["NAME", "POP", "geometry"; "Chennai", 7088000, "POINT (80.27 13.08)"; "Pune", 3124000, "POINT (73.86 18.52)"; '
          '"Leh", 30870, "POINT (77.58 34.16)"];\nn = save_shp("out/cities.shp", T);\n')
TREK = 'la = [30.9, 30.92, 30.95, 30.98];\nlo = [79.0, 79.02, 79.05, 79.08];\nel = [3000, 3400, 3800, 4000];\n'
PAGES['maps-gps'] = {
    'title': 'Maps & GPS',
    'summary': 'Shapefiles with points, lines and polygons; GeoTIFF rasters placed on the map; GPX and KML tracks, '
               'waypoints and areas. Coordinates can be reprojected and filtered by area.',
    'about': reference('Geometry is written as text (WKT): <code>"POINT (80.27 13.08)"</code>, '
                       '<code>"POLYGON ((...), (hole))"</code>. Coordinates are longitude then latitude. Built-in '
                       'reprojections: WGS84 (EPSG:4326), Web Mercator (3857) and UTM (326xx / 327xx).', [
        fn('read_shp(file, where, bbox, cols, rows, crs) / load_shp / save_shp(file, T, crs, geom_type, boxes)',
           'Shapefiles: a table with a geometry column. <code>bbox=[xmin, ymin, xmax, ymax]</code> keeps features in '
           'an area; <code>crs=</code> reprojects.', syntax='read_shp("out/cities.shp", where="POP > 100000")\nread_shp("out/cities.shp", crs="EPSG:32644")',
           short='shapefiles: features with attributes'),
        fn('read_shx / read_dbf / load_dbf / save_shx / save_dbf', 'The companion files on their own: the index and '
           'the attribute table.', syntax='read_dbf("out/cities.dbf")', short='the shapefile companions'),
        fn('read_tif(file, window, bands, bbox, overview, mask_nodata) / read_geotiff', 'A raster: all of it, a '
           'pixel window, chosen bands or a map area.', syntax='read_tif("out/g.tif", window=[1, 1, 2, 2])',
           short='a GeoTIFF raster, or part of it'),
        fn('save_tif(file, R, crs, bbox, transform, nodata, compress, tile, cog, boxes) / save_geotiff', 'Writes a '
           'raster placed on the map by <code>bbox</code> or a 6-number <code>transform</code> (GDAL order); '
           '<code>cog=true</code> adds overviews (Cloud-Optimised GeoTIFF).',
           syntax='save_tif("out/g.tif", R, crs="EPSG:32644", bbox=[400000, 1400000, 400400, 1400300], nodata=12)'),
        fn('load_tif(file) / load_geotiff', 'An object: <code>.crs</code>, <code>.bounds</code>, <code>.nodata</code>, '
           '<code>.count</code>, <code>.overviews</code>, and <code>.sample(x, y)</code> at a map position.',
           syntax='G = load_tif("out/g.tif");\nG.sample(400150, 1400250)'),
        fn('read_gpx(file, layer, bbox, time_range) / load_gpx / save_gpx(file, lat, lon, ele, name, mode_type, color)',
           'GPS tracks, routes and waypoints; the object view gives <code>.tracks[0].distance_km</code>.',
           syntax='save_gpx("out/trek.gpx", lat=la, lon=lo, ele=el, name="Trek")\nG = load_gpx("out/trek.gpx");',
           short='GPS tracks, routes and waypoints'),
        fn('read_kml / load_kml / save_kml(file, lat, lon, ele, mode_type, kmz)', 'KML and zipped KMZ: lines, points '
           'and polygons as placemarks.', syntax='save_kml("out/area.kml", lat=la, lon=lo, mode_type="polygon")',
           short='KML / KMZ placemarks'),
    ]),
    'examples': {
        'basic': ex('Cities in a shapefile', 'Three points with names and populations: filtered by attribute and by '
                    'area, reprojected to UTM, and read through the object view.', CITIES + '''
[S, info] = read_shp("out/cities.shp", where="POP > 100000");
S
publish(info.crs);
publish(read_shp("out/cities.shp", bbox=[70, 10, 81, 20], cols=["NAME"]));
publish(read_shp("out/cities.shp", crs="EPSG:32644", rows=[1:1], box=false));
D = load_shp("out/cities.shp");
publish(D.NAME, D.bbox);
'''),
        'mid': ex('A raster on the map', 'A 3 x 4 grid placed in UTM, with a NoData value, read with its transform, '
                  'sampled at a map position, and read through a window.', '''
R = reshape([1:12], [3, 4]);
g = save_tif("out/g.tif", R, crs="EPSG:32644", bbox=[400000, 1400000, 400400, 1400300], nodata=12);
[A, gi] = read_tif("out/g.tif");
A
publish(gi.transform, gi.bounds, gi.res);
G = load_tif("out/g.tif");
publish(G.crs, G.nodata, G.sample(400150, 1400250));
publish(read_tif("out/g.tif", window=[1, 1, 2, 2], mask_nodata=false));
'''),
        'strong': ex('A mountain trek', 'Four GPS points as a track, waypoints, a KMZ of points and a KML polygon; the '
                     'track length and filtered waypoints.', TREK + '''
n1 = save_gpx("out/trek.gpx", lat=la, lon=lo, ele=el, name="Gaumukh_Trek", boxes=["Basecamp Note: 4000m"]);
n2 = save_gpx("out/wpt.gpx", lat=la, lon=lo, mode_type="waypoint");
G = load_gpx("out/trek.gpx");
publish(G.tracks[0].name, G.tracks[0].distance_km, G.tracks[0].ele);
publish(read_gpx("out/wpt.gpx", layer="waypoints", bbox=[79.01, 30.91, 79.06, 30.96]));
n5 = save_kml("out/pts.kmz", lat=la, lon=lo, mode_type="point", kmz=true);
publish(read_kml("out/pts.kmz", layer="placemarks"));
n6 = save_kml("out/area.kml", lat=la, lon=lo, mode_type="polygon");
K = load_kml("out/area.kml");
publish(K.placemarks[0].type);
'''),
    },
    'errors': [
        err('Mixed shape types in one shapefile', 'Save points and lines to separate files.',
            'n = save_shp("out/e.shp", ["geometry"; "POINT (1 2)"; "LINESTRING (0 0, 1 1)"]);',
            'n = save_shp("out/e.shp", ["geometry"; "POINT (1 2)"; "POINT (0 0)"]);\npublish(read_shp("out/e.shp"));'),
        err('A reprojection that is not built in', 'NC lists the systems it can reproject between.',
            'n = save_shp("out/e.shp", ["geometry"; "POINT (1 2)"]);\nx = read_shp("out/e.shp", crs="EPSG:27700");',
            'n = save_shp("out/e.shp", ["geometry"; "POINT (1 2)"]);\nx = read_shp("out/e.shp", crs="EPSG:3857");\npublish(x);'),
        err('A raster without a place on the map', 'Give bbox= or transform=.', 'n = save_tif("out/e.tif", [1, 2; 3, 4]);',
            'n = save_tif("out/e.tif", [1, 2; 3, 4], bbox=[0, 0, 1, 1]);\npublish(read_tif("out/e.tif"));'),
        err('A band that does not exist', 'This raster has one band.', 'n = save_tif("out/e.tif", [1, 2; 3, 4], bbox=[0, 0, 1, 1]);\nx = read_tif("out/e.tif", bands=[2]);',
            'n = save_tif("out/e.tif", [1, 2; 3, 4], bbox=[0, 0, 1, 1]);\nx = read_tif("out/e.tif", bands=[1]);\npublish(x);'),
        err('A latitude beyond 90', 'Latitudes run from -90 to 90.', 'n = save_gpx("out/e.gpx", lat=[95, 30], lon=[79, 79]);',
            'n = save_gpx("out/e.gpx", lat=[29, 30], lon=[79, 79]);\npublish(n > 0);'),
    ],
}

# ================================================================== 16. Preparing data
PAGES['preparing-data'] = {
    'title': 'Preparing Data',
    'summary': 'Clean a table before analysis: convert types, tidy text, handle missing values and outliers, '
               'normalise columns, sort rows, and encode categories as numbers.',
    'about': reference('These are the functions behind the IDE\'s Process Data window. Functions with an axis use '
                       '0 for "per column" and 1 for "per row".', [
        fn('astype(A, type)', 'A converted to a type ("string", "float32", "int16", "bool", ...); text that holds '
           'numbers converts to numbers; float8 saturates at its range.',
           inputs=[('A', 'array', ''), ('type', 'type name', '')], syntax='astype([1.5, -2], "string")\nastype(["1", "2"], "int16")'),
        fn('lower, upper, swapcase, lstrip, rstrip, replace, split', 'Text functions that work on every element of a '
           'text array; <code>split</code> gives one row per text.', syntax='swapcase(["  Ab ", "cD  "])\nsplit(["a,b", "c"], ",")',
           short='text clean-up on whole arrays'),
        fn('ismissing(A[, "nan"]) / fillmissing(A, v[, "nan"]) / rmmissing(A, "nan")', 'Find, fill or remove missing '
           'cells. With "nan", every NaN counts as missing. <code>fillmissing</code> takes a value or a method: '
           '"mean" (per column), "linear" (nearest at the ends), "mode" (also for text).',
           syntax='fillmissing(X, "mean", "nan")\nrmmissing(X, "nan")', short='find, fill or remove missing cells'),
        fn('outliers(A, method, limits, action)', 'Find values outside a range and "clip" them to it or "drop" their '
           'rows. Methods: "iqr" (k &times; the inter-quartile range), "percentile" ([lo, hi]), "bounds" ([lo, hi]).',
           math=r'\text{iqr: keep } [Q_1 - k\,\mathrm{IQR},\; Q_3 + k\,\mathrm{IQR}]',
           syntax='outliers([1, 2, 3, 4, 100], "iqr", 1.5, "clip")   # 1 2 3 4 7'),
        fn('normalize(A, method[, axis])', 'Rescale: "minmax" to 0&ndash;1, "zscore" to mean 0 and deviation 1, '
           '"robust" by median and IQR, "gauss" to normal scores.',
           math=r'z = \frac{x - \bar{x}}{\sigma}, \qquad m = \frac{x - \min}{\max - \min}',
           syntax='normalize(M, "minmax", 0)'),
        fn('tril, triu, expand_dims, squeeze, sortrows(A, col, order)', 'Triangles of a matrix (type kept), adding '
           'or removing length-1 axes, and sorting the rows of a table by a column.',
           syntax='sortrows([3, 1; 1, 2; 2, 0], 1, "descending")', short='triangles, axes and row sorting'),
        fn('onehot, label_encode, count_encode, ordinal_encode, binary_encode, hash_encode, loo_encode, catboost_encode',
           'Categories as numbers: one column per category (<code>onehot</code>, with "drop_first" for dummies), one '
           'number per category (label, count, ordinal with a given order), bits, hashing, or target statistics '
           '(leave-one-out, CatBoost).', syntax='onehot(["red", "blue", "red", "green"])\nlabel_encode(["red", "blue", "red", "green"])',
           short='encode categories as numbers'),
        fn('to_time(texts, layout, zone)', 'Timestamps from text in a given layout; text that does not fit becomes '
           'missing.', syntax='to_time(["2026-11-17", "bad"], "yyyy-MM-dd", "UTC")'),
    ]),
    'examples': {
        'basic': ex('Types and text', 'Numbers as text and back, and text arrays tidied in one call each.', '''
a = astype([1.5, -2; 3, 1000], "string")
b = astype(["1", "2"], "int16")
f8 = astype([1, 500, -1000], "float8")
T = ["  Ab ", "cD  "];
publish(lower(T), upper(T), swapcase(T));
publish(lstrip(T), rstrip(T));
s = split(["a,b", "c"], ",")
'''),
        'mid': ex('Missing values and outliers', 'Fill gaps by value, column mean and straight lines; remove rows '
                  'with gaps; clip and drop an outlier.', '''
X = [1, nan; 3, 4; nan, 8; 7, nan];
v = fillmissing(X, 0, "nan")
m = fillmissing(X, "mean", "nan")
l = fillmissing(X, "linear", "nan")
r = rmmissing(X, "nan")
Y = [1, 2, 3, 4, 100];
clipped = outliers(Y, "iqr", 1.5, "clip")
dropped = outliers(Y, "iqr", 1.5, "drop")
'''),
        'strong': ex('Ready for a model', 'Normalise numeric columns three ways, sort rows, and encode a colour '
                     'column several ways.', '''
M = [1, 10; 2, 20; 3, 30];
mm = normalize(M, "minmax", 0)
z = normalize(M, "zscore", 0)
s = sortrows([3, 1; 1, 2; 2, 0], 1, "descending")
C = ["red", "blue", "red", "green"];
oh = onehot(C)
dummy = onehot(C, "drop_first")
lab = label_encode(C)
cnt = count_encode(C)
ord = ordinal_encode(["low", "high", "mid"], ["low", "mid", "high"])
'''),
    },
}
