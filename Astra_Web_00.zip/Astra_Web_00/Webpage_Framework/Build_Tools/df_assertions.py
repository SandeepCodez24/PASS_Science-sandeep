"""Default Functions - Assertions & Exceptions (source: Function_Test/Code/A_09_Assertions/Exception_Handling,
eh_18 to eh_45: warn and the warning types, trace / publish_trace / inspect_fail, and the 22 assert_* checks).

The language part of A_09 (try, except, success, always, escalate, because, assert, require, ensure and the
error types) is in the Language Guide, section Errors & Exceptions (lg_errors.py).
"""
from df_helpers import comp, err, ex, fig, fn, reference

IMG = 'Images/Neural_Code/Default_Functions/Assertions/'
LG = '../../Language_Guide/Errors_Exceptions/'
PAGES = {}

MSG = ('message', 'text added to the failure message after " - "', 'none')


# ================================================================== 1. Error reports
PAGES['error-reports'] = {
    'title': 'Error Reports',
    'summary': 'Read the error a try block handled: as text with <code>trace()</code>, printed with '
               '<code>publish_trace()</code>, or as a value with <code>inspect_fail()</code>.',
    'about': reference('Inside an except block these functions describe the error being handled. After the try '
                       'block they describe the <em>last</em> error a try block (or <code>assert_fail</code>) handled. '
                       'The error itself is explained in the Language Guide, '
                       '<a href="' + LG + 'try-except.html">Try &amp; Except</a>.', [
        fn('trace()', 'The error as text: its type, message and line, then one "caused by" line for each cause. '
           '<code>""</code> when no error has been handled yet.',
           more=['<code>trace</code> with no inputs is this function; <code>trace(A)</code> is still the trace of '
                 'a matrix, the sum of its diagonal.'],
           syntax='t = trace();\n# ValueError: bad input (line 12)\n#   caused by: KeyError: ... (line 9)',
           short='the handled error as text'),
        fn('publish_trace()', 'Prints what <code>trace()</code> gives, as <code>publish</code> prints a value, and '
           'gives back true. Before any error it prints <code>No error has been handled yet.</code>',
           syntax='except KeyError:\n   publish_trace();', short='print the handled error'),
        fn('inspect_fail()', 'The error itself, the dictionary <code>{type, message, line, cause}</code>; '
           '<code>{}</code> when there has been none. Inside nested except blocks it is the innermost error being '
           'handled.',
           more=['Useful after a bare <code>except:</code>, which gives the error no name, and after '
                 '<code>assert_fail</code>, which handles the error itself.'],
           syntax='except:\n   e = inspect_fail();\n   publish(e.type, e.line);', short='the handled error as a value'),
    ], lead=[
        comp('Python and MATLAB', ['The same tools elsewhere:'],
             table=[['NC', 'Python', 'MATLAB'],
                    ['<code>trace()</code>', '<code>traceback.format_exc()</code>', '<code>getReport(ME)</code>'],
                    ['<code>publish_trace()</code>', '<code>traceback.print_exc()</code>', '<code>disp(getReport(ME))</code>'],
                    ['<code>inspect_fail()</code>', '<code>sys.exc_info()</code>', '<code>lasterror</code>']]),
    ]),
    'examples': {
        'basic': ex('Before and after an error', 'Nothing has been handled at the start. After one handled error, '
                    'all three functions describe it.', '''
publish("before:  trace() is empty:", trace() == "", "  inspect_fail():", inspect_fail());
publish_trace();

try:
   escalate ValueError("bad input");
except ValueError:
   t = trace();
tend
publish("trace:", t);
e = inspect_fail();
publish("type:", e.type, " line:", e.line);
publish("trace(A) is still the matrix trace:", trace([1, 2; 3, 4]));
'''),
        'mid': ex('Report and carry on', '<code>publish_trace()</code> inside an except block prints the report and '
                  'the script goes on; a chain of causes is printed line by line.', '''
d = dict();
d["a"] = 1;
try:
   v = d["missing"];
except KeyError:
   publish_trace();
tend

try:
   try:
      escalate KeyError("inner");
   except KeyError as e:
      escalate ValueError("outer") because e;
   tend
except ValueError:
   publish_trace();
tend
publish("still running");
'''),
        'strong': ex('A bare except and nested handlers', '<code>inspect_fail()</code> names the error a bare '
                     '<code>except:</code> handled, and inside nested handlers it is always the innermost one.', '''
function r = safe_ratio(a, b):
   try:
      r = a / b;
      if is_nan(r):
         escalate ValueError("0 / 0 has no value");
      iend
   except:
      e = inspect_fail();
      publish("   ", e.type, "on line", e.line, ":", e.message);
      r = 0;
   tend
fnend
publish(safe_ratio(6, 3), safe_ratio(0, 0));

try:
   escalate KeyError("outer");
except KeyError:
   try:
      escalate IndexError("inner");
   except IndexError:
      publish("inside the inner handler:", inspect_fail().type);
   tend
   publish("back in the outer handler:", inspect_fail().type);
tend
'''),
    },
}

# ================================================================== 2. Warnings
PAGES['warnings'] = {
    'title': 'Warnings',
    'summary': 'Say that something looks wrong without stopping the script: <code>warn</code>, '
               '<code>UserWarning</code> and <code>LegacyWarning</code>.',
    'about': reference('A warning is printed and the script carries on, as Python\'s <code>warnings.warn</code> and '
                       'MATLAB\'s <code>warning</code> do. A try block does not treat a warning as an error. To make it '
                       'an error, escalate it. Tests can require a warning with '
                       '<a href="expected-failures.html#assert-warn-type-f-values"><code>assert_warn</code></a>.', [
        fn('warn(message, type=UserWarning)', 'Prints <code>Warning: UserWarning: message</code> and gives back true.',
           inputs=[('message', 'the text, or a warning value such as <code>LegacyWarning("...")</code>', ''),
                   ('type', '<code>UserWarning</code> or <code>LegacyWarning</code>; any other type is a TypeError', 'UserWarning')],
           syntax='warn("the step size is large");\nwarn("use new_filter() instead", LegacyWarning);\nwarn(LegacyWarning("old_filter() will be removed"));',
           short='print a warning and carry on'),
        fn('UserWarning(message)', 'A warning value of the type <code>warn</code> uses when none is named: a '
           'dictionary <code>{type, message, line, cause}</code>, like an error value.',
           syntax='w = UserWarning("check the units");\nwarn(w);\nescalate UserWarning("now it is an error");',
           short='the everyday warning type'),
        fn('LegacyWarning(message)', 'A warning that something still works but is on its way out: an old function '
           'name, an old option. Python calls it <code>DeprecationWarning</code>.',
           syntax='function y = old_scale(x):\n   warn("old_scale() is replaced by scale()", LegacyWarning);\n   y = 2 * x;\nfnend',
           short='something on its way out'),
    ]),
    'examples': {
        'basic': ex('A warning does not stop anything', 'Two warnings are printed; the script goes on, and the try '
                    'block does not see the warning as an error.', '''
r = warn("the step size is large");
publish("warn gave back", r);
warn("use new_filter() instead", LegacyWarning);

ran_except = false;
try:
   warn("inside try");
except:
   ran_except = true;
tend
publish("except block ran:", ran_except);
'''),
        'mid': ex('An old function that still works', 'The old name gives the right result and says what replaces '
                  'it. A test checks for the warning without printing it.', '''
function y = scale(x):
   y = 2 * x;
fnend
function y = old_scale(x):
   warn("old_scale() is replaced by scale()", LegacyWarning);
   y = scale(x);
fnend

publish("old_scale(4) =", old_scale(4));
publish("warns as expected:", assert_warn(LegacyWarning, @old_scale, 1));
'''),
        'strong': ex('From warning to error', 'A value above the limit is clipped with a warning. When a strict mode '
                     'is on, the same warning is escalated instead, and the caller handles it as an error.', '''
function y = clip_reading(x, strict):
   y = x;
   if x > 100:
      w = UserWarning("reading " + str(x) + " clipped to 100");
      if strict:
         escalate w;
      iend
      warn(w);
      y = 100;
   iend
fnend

publish(clip_reading(80, false), clip_reading(250, false));
try:
   y = clip_reading(250, true);
except UserWarning as err:
   publish("strict mode:", err.type, "-", err.message);
tend
'''),
    },
    'errors': [
        err('Only warning types can be warned', 'An error type is not a warning. Use a warning type, or escalate the '
            'error.', '''
warn("x is negative", ValueError);''', '''
warn("x is negative", UserWarning);
publish("carried on");'''),
    ],
}

# ================================================================== 3. Writing checks (overview)
EQ = 'equality-identity.html'
TT = 'truth-emptiness-types.html'
OC = 'order-containers-patterns.html'
XF = 'expected-failures.html'
PAGES['writing-checks'] = {
    'title': 'Writing Checks',
    'summary': 'Twenty-two <code>assert_*</code> functions for tests: each passes quietly or raises an '
               'AssertionError that says exactly what differed.',
    'about': [
        comp('One rule for every check', [
            'Every <code>assert_*</code> function checks one thing. When it holds, the function gives back '
            '<code>true</code> and nothing is printed. When it does not, it raises an <code>AssertionError</code> '
            'whose message shows the values, such as <code>3 != 4</code> or <code>9 is not in [1,2,3]</code>, so a '
            'failing test explains itself.',
            'Each one takes an optional last input, a message, which is added after <code>" - "</code>: '
            '<code>assert_eq(1, 2, "counts differ")</code> fails with <code>1 != 2 - counts differ</code>. A '
            'wrong call, such as <code>assert_eq(1)</code>, is a TypeError, never a failed check.',
            'For a quick condition in ordinary code, the <a href="' + LG + 'assert-contracts.html"><code>assert</code> '
            'statement</a> is shorter; the functions below say more when they fail.'],
            syntax='assert_eq(total, 60);\nassert_eq(total, 60, "the three readings must add up");'),
        comp('The checks', ['Grouped as on the following pages, with the Python <code>unittest</code> name of each.'],
             table=[['Check', 'Passes when', 'Python', 'Page'],
                    ['<code>assert_eq(a, b)</code>', 'a == b', 'assertEqual', f'<a href="{EQ}">Equality</a>'],
                    ['<code>assert_neq(a, b)</code>', 'a != b', 'assertNotEqual', f'<a href="{EQ}">Equality</a>'],
                    ['<code>assert_same(a, b)</code>', 'equal and of the same type', 'assertIs', f'<a href="{EQ}">Equality</a>'],
                    ['<code>assert_not_same(a, b)</code>', 'different value or type', 'assertIsNot', f'<a href="{EQ}">Equality</a>'],
                    ['<code>assert_elements_eq(a, b)</code>', 'same elements, any order', 'assertCountEqual', f'<a href="{EQ}">Equality</a>'],
                    ['<code>assert_true(x)</code>', 'x is true, as in <code>if</code>', 'assertTrue', f'<a href="{TT}">Truth</a>'],
                    ['<code>assert_false(x)</code>', 'x is false', 'assertFalse', f'<a href="{TT}">Truth</a>'],
                    ['<code>assert_null(x)</code>', 'x is empty', 'assertIsNone', f'<a href="{TT}">Truth</a>'],
                    ['<code>assert_not_null(x)</code>', 'x is not empty', 'assertIsNotNone', f'<a href="{TT}">Truth</a>'],
                    ['<code>assert_type(x, t)</code>', 'x is of type t', 'assertIsInstance', f'<a href="{TT}">Truth</a>'],
                    ['<code>assert_not_type(x, t)</code>', 'x is not of type t', 'assertNotIsInstance', f'<a href="{TT}">Truth</a>'],
                    ['<code>assert_gt / gte / lt / lte(a, b)</code>', 'a &gt; b, a &ge; b, a &lt; b, a &le; b', 'assertGreater &hellip;', f'<a href="{OC}">Order</a>'],
                    ['<code>assert_contains(c, item)</code>', 'item in c', 'assertIn', f'<a href="{OC}">Order</a>'],
                    ['<code>assert_excludes(c, item)</code>', 'item not in c', 'assertNotIn', f'<a href="{OC}">Order</a>'],
                    ['<code>assert_match(text, p)</code>', 'the pattern is found', 'assertRegex', f'<a href="{OC}">Order</a>'],
                    ['<code>assert_not_match(text, p)</code>', 'the pattern is not found', 'assertNotRegex', f'<a href="{OC}">Order</a>'],
                    ['<code>assert_fail(@f, &hellip;)</code>', 'the call fails', 'assertRaises', f'<a href="{XF}">Failures</a>'],
                    ['<code>assert_fail_match(p, @f, &hellip;)</code>', 'it fails with a matching message', 'assertRaisesRegex', f'<a href="{XF}">Failures</a>'],
                    ['<code>assert_warn(@f, &hellip;)</code>', 'the call warns', 'assertWarns', f'<a href="{XF}">Failures</a>']]),
        comp('A test script', [
            'A test script is a list of checks. Wrap each one in a try block to run them all and count the '
            'failures, instead of stopping at the first; <code>err.message</code> tells what went wrong. The strong '
            'example below is such a script.']),
    ],
    'examples': {
        'basic': ex('Checks that pass give back true', 'Four passing checks, then one failing check whose message is '
                    'printed.', '''
total = 10 + 20 + 30;
publish(assert_eq(total, 60), assert_gt(total, 0), assert_contains([10, 20, 30], 20), assert_type(total, "number"));
try:
   assert_eq(total, 61, "the three readings must add up");
except AssertionError as err:
   publish("failed:", err.message);
tend
'''),
        'mid': ex('Testing a function', 'The function under test, and five checks on it: a value, a type, a range, '
                  'an error for a bad input and an unchanged input.', '''
function y = normalise(v):
   if max(abs(v)) == 0:
      escalate ValueError("cannot normalise a zero vector");
   iend
   y = v / max(abs(v));
fnend

v = [2, -4, 1];
y = normalise(v);
assert_eq(y, [0.5, -1, 0.25]);
assert_type(y, "matrix");
assert_lte(abs(y), 1);
assert_fail(ValueError, @normalise, [0, 0, 0]);
assert_eq(v, [2, -4, 1], "the input must not change");
publish("normalise: 5 checks passed");
'''),
        'strong': ex('A small test runner', 'Six cases, each checked inside its own try block. <code>clamp</code> has '
                     'a bug on purpose: above the range it gives the lower limit. Only the case that pins the exact '
                     'value catches it; the two range checks still pass.', '''
function y = clamp(x, lo, hi):
   y = x;
   if x < lo:
      y = lo;
   iend
   if x > hi:
      y = lo;
   iend
fnend

passed = 0;
failed = 0;
for k = [1:6]:
   try:
      if k == 1:
         assert_eq(clamp(5, 0, 10), 5, "inside the range");
      elseif k == 2:
         assert_eq(clamp(-3, 0, 10), 0, "below the range");
      elseif k == 3:
         assert_eq(clamp(42, 0, 10), 10, "above the range");
      elseif k == 4:
         assert_same(clamp(int8(3), 0, 10), int8(3), "the type is kept");
      elseif k == 5:
         assert_gte(clamp(1000, 0, 10), 0);
      else:
         assert_lte(clamp(1000, 0, 10), 10);
      iend
      passed = passed + 1;
   except AssertionError as err:
      failed = failed + 1;
      publish("case", k, "FAILED:", err.message);
   tend
fend
publish(passed, "passed,", failed, "failed");
'''),
    },
}

# ================================================================== 4. Equality and identity
PAGES['equality-identity'] = {
    'title': 'Equality & Identity',
    'summary': 'Check that two values are equal, different, the same value of the same type, or hold the same '
               'elements in any order.',
    'about': reference('All of these compare whole values: numbers, text, whole matrices, dictionaries and objects. '
                       'Each takes an optional message as its last input.', [
        fn('assert_eq(actual, expected, message)', 'Passes when the two values are equal, by the same rule as '
           '<code>==</code>: whole matrices must have the same shape and the same elements. Otherwise it fails with '
           '<code>actual != expected</code>.',
           inputs=[('actual', 'the value you computed', ''), ('expected', 'the value it should be', ''), MSG],
           more=['The comparison is exact, so <code>assert_eq(0.1 + 0.2, 0.3)</code> fails, as in Python; use '
                 '<code>assert_true(allclose(a, b))</code> for computed decimals. <code>5</code> and '
                 '<code>int8(5)</code> are equal; see <code>assert_same</code> for types.'],
           syntax='assert_eq([1, 2; 3, 4]\', [1, 3; 2, 4]);\nassert_eq(1, 2, "counts differ");   # 1 != 2 - counts differ',
           short='equal values'),
        fn('assert_neq(a, b, message)', 'Passes when the two values are not equal. Otherwise it fails with '
           '<code>a == b</code>. A number is never equal to text: <code>assert_neq(1, "1")</code> passes.',
           syntax='assert_neq([1, 2], [2, 1]);', short='different values'),
        fn('assert_same(a, b, message)', 'Passes when the values are equal <em>and</em> of the same type. NC values '
           'have no identity of their own (assigning copies the value), so this is what "the same" means. '
           '<code>5</code> and <code>int8(5)</code> are equal but not the same; neither are <code>true</code> and '
           '<code>1</code>.', syntax='assert_same(int32(7), int32(7));\nassert_same(5, int8(5));   # fails',
           short='equal and of the same type'),
        fn('assert_not_same(a, b, message)', 'Passes when the values differ in value or in type. Otherwise it '
           'fails with <code>&hellip; is the same as &hellip;</code>.', syntax='assert_not_same(5, int8(5));',
           short='different value or type'),
        fn('assert_elements_eq(a, b, message)', 'Passes when both hold the same elements, each the same number of '
           'times, in any order. Matrices of any shape (the elements are compared, not the shape), texts (their '
           'characters) and dictionaries (their keys).',
           syntax='assert_elements_eq([1, 2; 3, 4], [4, 3, 2, 1]);\nassert_elements_eq("listen", "silent");',
           short='same elements, any order'),
    ]),
    'examples': {
        'basic': ex('Equal and not equal', 'Passing checks give back true; the failing ones are handled to show '
                    'their messages.', '''
publish(assert_eq(2 + 2, 4), assert_eq("ab" + "c", "abc"), assert_eq(int8(5), 5));
publish(assert_neq(1, 2), assert_neq(1, "1"));
try:
   assert_eq([1, 2], [1, 3]);
except AssertionError as err:
   publish(err.message);
tend
try:
   assert_neq(5, 5, "ids must differ");
except AssertionError as err:
   publish(err.message);
tend
'''),
        'mid': ex('Equal is not the same', 'An int8 five equals a plain five, but its type differs, so only '
                  '<code>assert_eq</code> passes.', '''
a = [1, 2, 3];
b = a;
publish("copy is the same:", assert_same(a, b));
publish("5 == int8(5):", assert_eq(5, int8(5)));
try:
   assert_same(5, int8(5));
except AssertionError as err:
   publish(err.message);
tend
publish("5 and int8(5) are not the same:", assert_not_same(5, int8(5)));
'''),
        'strong': ex('Order does not matter', 'A sort is checked twice: the result is in order, and it holds the same '
                     'values as the input, each as often. A lost duplicate is caught.', '''
data = [7, 3, 9, 3, 1];
s = sort(data);
assert_lte(s[0:3], s[1:4]);
assert_elements_eq(s, data, "sort must keep every value");
publish("sorted:", s);

broken = [1, 3, 7, 9];
try:
   assert_elements_eq(broken, data, "sort must keep every value");
except AssertionError as err:
   publish(err.message);
tend
'''),
    },
    'errors': [
        err('Decimals compared exactly', '<code>assert_eq</code> is exact. A computed decimal is seldom exactly the '
            'written one.', '''
assert_eq(0.1 + 0.2, 0.3);''', '''
assert_true(allclose(0.1 + 0.2, 0.3));
publish("equal within tolerance");'''),
        err('Only one value', 'Every comparison needs two values. A wrong call is a TypeError, not a failed check.', '''
assert_eq(4);''', '''
assert_eq(2 + 2, 4);
publish("passed");'''),
    ],
}

# ================================================================== 5. Truth, emptiness and types
PAGES['truth-emptiness-types'] = {
    'title': 'Truth, Emptiness & Types',
    'summary': 'Check that a value is true or false, empty or not, and of the type you expect.',
    'about': reference('True and false follow the rules of <code>if</code>. "Empty" is NC\'s null: NC has no '
                       '<code>None</code>, so an empty matrix, empty text or an empty dictionary stands for "no '
                       'value".', [
        fn('assert_true(x, message)', 'Passes when x is true in the sense of <code>if</code>: a non-zero number, '
           'non-empty text, a matrix whose every element is true. Otherwise it fails with '
           '<code>false is not true</code>.', syntax='assert_true([1, 2, 3] > 0);', short='true, as in if'),
        fn('assert_false(x, message)', 'Passes when x is false: 0, false, empty text, a matrix with any false '
           'element. Otherwise it fails with <code>true is not false</code>.', syntax='assert_false(5 < 1);',
           short='false, as in if'),
        fn('assert_null(x, message)', 'Passes when x is empty: <code>[]</code>, <code>""</code> or an empty '
           'dictionary. <code>0</code> is a number, not null.', syntax='assert_null(err.cause);',
           short='empty'),
        fn('assert_not_null(x, message)', 'Passes when x is not empty: any number (0 too), non-empty text, a matrix '
           'with elements, a dictionary with keys, an object.', syntax='assert_not_null(name, "the name was not read");',
           short='not empty'),
        fn('assert_type(x, type, message)', 'Passes when x is of the type. Otherwise it fails with, for example, '
           '<code>[1,2] (matrix) is not a string</code>. A misspelt type name is a TypeError.',
           inputs=[('x', 'any value', ''),
                   ('type', 'a type name in quotes (see the table), a class name in quotes, or an error type', ''), MSG],
           table=None, syntax='assert_type(3.5, "float64");\nassert_type(rex, "Animal");\nassert_type(err, KeyError);',
           short='of a type'),
        fn('assert_not_type(x, type, message)', 'Passes when x is not of the type; the same type names.',
           syntax='assert_not_type(int8(1), "float");', short='not of a type'),
    ], lead=[
        comp('Type names', ['The names <code>assert_type</code> and <code>assert_not_type</code> accept:'],
             table=[['Kind', 'Names', 'Matches'],
                    ['exact', '<code>"float64"</code>, <code>"float32"</code>, <code>"int8"</code> &hellip; <code>"uint64"</code>, '
                     '<code>"bool"</code>, <code>"complex"</code>, <code>"string"</code>, <code>"matrix"</code>, <code>"array"</code>, '
                     '<code>"dict"</code>, <code>"function"</code>, <code>"timestamp"</code>, <code>"duration"</code>', 'that type only'],
                    ['group', '<code>"number"</code>', 'any single number'],
                    ['group', '<code>"integer"</code>, <code>"float"</code>', 'any sized integer, any float'],
                    ['group', '<code>"text"</code>', 'the same as <code>"string"</code>'],
                    ['group', '<code>"object"</code>, <code>"exception"</code>', 'any object, any error value'],
                    ['class', '<code>"ClassName"</code>', 'an object of the class or of a subclass'],
                    ['error type', '<code>ValueError</code>, <code>RuntimeError</code> &hellip; (no quotes)', 'error values of that type; NotImplemented is a RuntimeError']]),
    ]),
    'examples': {
        'basic': ex('True, false, empty', 'Truth follows <code>if</code>: one false element makes a matrix false. '
                    '<code>0</code> is a value, not null.', '''
publish(assert_true(3 > 2), assert_true("text"), assert_false(0), assert_false(""));
publish(assert_null([]), assert_null(""), assert_not_null(0), assert_not_null([0]));
try:
   assert_true([1, 0, 1]);
except AssertionError as err:
   publish(err.message);
tend
try:
   assert_null(0);
except AssertionError as err:
   publish(err.message);
tend
'''),
        'mid': ex('Exact types and groups', 'An int16 is an "int16", an "integer" and a "number", but not a '
                  '"float".', '''
x = int16(3);
publish(assert_type(x, "int16"), assert_type(x, "integer"), assert_type(x, "number"), assert_not_type(x, "float"));
publish(assert_type("hi", "text"), assert_type([1, 2; 3, 4], "matrix"), assert_type(3.5, "float64"));
try:
   assert_type([1, 2], "string");
except AssertionError as err:
   publish(err.message);
tend
try:
   assert_not_type("abc", "text");
except AssertionError as err:
   publish(err.message);
tend
'''),
        'strong': ex('Classes and error values', 'An object passes for its own class, its parent class and '
                     '"object". Error values are checked against error types, with NotImplemented counted as a '
                     'RuntimeError.', '''
class Animal():
   function base(name):
      base.name = name;
   fnend
csend
class Dog(Animal):
   function base(name):
      parent(name);
   fnend
csend

rex = Dog("Rex");
publish(assert_type(rex, "Dog"), assert_type(rex, "Animal"), assert_type(rex, "object"));
publish(assert_type(KeyError("k"), KeyError), assert_type(NotImplemented("n"), RuntimeError));
publish(assert_not_type(ValueError("v"), KeyError));
try:
   escalate ValueError("no cause here");
except ValueError as err:
   publish("no cause:", assert_null(err.cause));
tend
'''),
    },
    'errors': [
        err('A misspelt type name', 'An unknown type name is refused with a TypeError, so a typo never passes or '
            'fails silently.', '''
assert_type(1.5, "flaot64");''', '''
assert_type(1.5, "float64");
publish("passed");'''),
    ],
}

# ================================================================== 6. Order, containers and patterns
PAGES['order-containers-patterns'] = {
    'title': 'Order, Containers & Patterns',
    'summary': 'Check that values are in order, that a container holds (or lacks) an item, and that text matches '
               '(or avoids) a pattern.',
    'about': reference('The order checks use the comparison operators, the container checks use <code>in</code> '
                       'and <code>not in</code>, and the pattern checks use regular expressions.', [
        fn('assert_gt(a, b, message)', 'Passes when a &gt; b, by the rules of the <code>&gt;</code> operator: '
           'numbers, text in alphabetical order, and matrices element by element (every element must satisfy it). '
           'Otherwise it fails with <code>not a &gt; b</code>. Values that cannot be ordered, such as a number and '
           'text, give a TypeError.', syntax='assert_gt([4, 5, 6], 3);', short='a &gt; b'),
        fn('assert_gte(a, b, message)', 'Passes when a &ge; b.', syntax='assert_gte(n, 30, "too few samples");',
           short='a &ge; b'),
        fn('assert_lt(a, b, message)', 'Passes when a &lt; b. NaN is not less than anything (IEEE 754), so '
           '<code>assert_lt(nan, 1)</code> fails.', syntax='assert_lt(-inf, 0);', short='a &lt; b'),
        fn('assert_lte(a, b, message)', 'Passes when a &le; b.', syntax='assert_lte(abs(error), 1e-9);',
           short='a &le; b'),
        fn('assert_contains(container, item, message)', 'Passes when the container holds the item, by the rules of '
           '<code>item in container</code>. Otherwise it fails with <code>9 is not in [1,2,3]</code>.',
           inputs=[('container', 'a matrix (its elements, or the rows of a matrix), a dictionary (its keys) or text', ''),
                   ('item', 'what to look for', ''), MSG],
           more=['The container comes <em>first</em>, as in Python\'s <code>assertIn</code> read aloud: "assert that '
                 'the list contains 20". A plain number is not a container.'],
           syntax='assert_contains([10, 20, 30], 20);\nassert_contains([1, 2; 3, 4], [3, 4]);\nassert_contains("neural code", "code");',
           short='the item is in the container'),
        fn('assert_excludes(container, item, message)', 'Passes when the container does not hold the item. Otherwise '
           'it fails with <code>2 is in [1,2,3]</code>.', syntax='assert_excludes(settings, "debug");',
           short='the item is not in the container'),
        fn('assert_match(text, pattern, message)', 'Passes when the regular expression is found somewhere in the '
           'text; use <code>^</code> and <code>$</code> to match the whole text. Otherwise it fails with '
           '<code>pattern "^b" not found in "abc"</code>. Only text is accepted; an invalid pattern is a ValueError.',
           syntax='assert_match("2026-11-09", "^[0-9]{4}-[0-9]{2}-[0-9]{2}$");', short='the pattern is found'),
        fn('assert_not_match(text, pattern, message)', 'Passes when the pattern is found nowhere in the text.',
           syntax='assert_not_match("report.csv", "\\.txt$");', short='the pattern is not found'),
    ]),
    'examples': {
        'basic': ex('In order', 'Numbers, text and whole matrices against a limit. Equal is not greater, and NaN '
                    'orders as false.', '''
publish(assert_gt(5, 3), assert_gt("b", "a"), assert_gt([4, 5, 6], 3));
publish(assert_gte(3, 3), assert_lt(-inf, 0), assert_lte("abc", "abd"));
try:
   assert_gt(3, 3);
except AssertionError as err:
   publish(err.message);
tend
try:
   assert_lt(nan, 1);
except AssertionError as err:
   publish("nan < 1:", err.message);
tend
'''),
        'mid': ex('In a container', 'An element, a row, a key and a piece of text; then an item that is missing and '
                  'one that should not be there.', '''
d = dict();
d["x"] = 1;
publish(assert_contains([10, 20, 30], 20), assert_contains([1, 2; 3, 4], [3, 4]), assert_contains(d, "x"), assert_contains("neural code", "code"));
publish(assert_excludes([1, 2, 3], 7), assert_excludes(d, "y"), assert_excludes("neural", "z"));
try:
   assert_contains([1, 2, 3], 9);
except AssertionError as err:
   publish(err.message);
tend
try:
   assert_excludes([1, 2, 3], 2);
except AssertionError as err:
   publish(err.message);
tend
'''),
        'strong': ex('Validate a batch of names', 'Each file name must be a dated CSV name and must not contain '
                     'spaces. Bad names are listed with the check that failed.', '''
names = ["2026-11-09_run.csv", "run 7.csv", "2026-11-10_run.txt", "2026-11-11_run.csv"];
for k = [0:3]:
   n = names[k];
   try:
      assert_match(n, "^[0-9]{4}-[0-9]{2}-[0-9]{2}_", "no date at the start");
      assert_match(n, "\\.csv$", "not a CSV file");
      assert_not_match(n, " ", "contains a space");
      publish("ok:  ", n);
   except AssertionError as err:
      publish("bad: ", n, "-", err.message);
   tend
fend
'''),
    },
    'errors': [
        err('The item before the container', '<code>assert_contains</code> takes the container first. With the '
            'order swapped, NC is asked to search inside a number.', '''
assert_contains(20, [10, 20, 30]);''', '''
assert_contains([10, 20, 30], 20);
publish("20 is in the list");'''),
        err('A number given to a pattern check', 'Patterns search text. Convert a number with <code>str</code> '
            'first.', '''
assert_match(404, "^4");''', '''
assert_match(str(404), "^4");
publish("a 4xx code");'''),
    ],
}

# ================================================================== 7. Expected failures and warnings
PAGES['expected-failures'] = {
    'title': 'Expected Failures',
    'summary': 'Check that a call fails, fails with the right message, or gives a warning: '
               '<code>assert_fail</code>, <code>assert_fail_match</code> and <code>assert_warn</code>.',
    'about': reference('A test of error handling must call the function itself, so these checks take the '
                       'function as a reference, <code>@name</code>, followed by the values to call it with. Built-in '
                       'functions work too: <code>@zeros</code>, <code>@int8</code>.', [
        fn('assert_fail(type, @f, values...)', 'Calls <code>f(values...)</code> and passes when the call fails, with '
           'an error of the type when one is named. The error is handled by <code>assert_fail</code>: nothing is '
           'printed, and <code>inspect_fail()</code> gives it afterwards.',
           inputs=[('type', 'an error type, such as <code>ValueError</code>; leave it out for any error', 'any'),
                   ('@f', 'the function, as a reference', ''), ('values...', 'the inputs to call it with', 'none')],
           more=['A call that works fails the check with <code>&hellip; raised no error</code>; an error of another '
                 'type fails it with <code>&hellip; not a KeyError</code>.'],
           figure=fig(IMG + 'expected-failures-01.svg',
                      'assert_fail calls f with the values. If the call returns normally, the check fails: raised no '
                      'error. If it raises an error of another type, the check fails: not the expected type. If it '
                      'raises the expected type, the check passes, gives back true, and the error can be read with '
                      'inspect_fail.',
                      'The three outcomes of <code>assert_fail(ValueError, @f, x)</code>.'),
           syntax='assert_fail(@safe_sqrt, -1);\nassert_fail(ValueError, @safe_sqrt, -4);\nassert_fail(ValueError, @zeros, -1);',
           short='the call fails'),
        fn('assert_fail_match(type, pattern, @f, values...)', 'Like <code>assert_fail</code>, and the error message '
           'must also contain the pattern, a regular expression searched anywhere in the message. Otherwise it fails '
           'with <code>&hellip; not found in the error</code>; an invalid pattern is a ValueError.',
           syntax='assert_fail_match("negative", @check_age, -3);\nassert_fail_match(ValueError, "age -[0-9]+ is", @check_age, -12);',
           short='it fails with a matching message'),
        fn('assert_warn(type, @f, values...)', 'Calls <code>f(values...)</code> and passes when it gives a warning, '
           'of the type when one is named. The warnings are recorded, not printed. Otherwise it fails with '
           '<code>&hellip; gave no warning</code> or <code>&hellip; not a LegacyWarning</code>.',
           syntax='assert_warn(@clipped, 250);\nassert_warn(LegacyWarning, @old_api, 1);', short='the call warns'),
    ]),
    'examples': {
        'basic': ex('A function that refuses bad input', 'Two expected failures pass; a call that works fails the '
                    'check. The handled error is read back with <code>inspect_fail()</code>.', '''
function y = safe_sqrt(x):
   if x < 0:
      escalate ValueError("x must be >= 0");
   iend
   y = sqrt(x);
fnend

publish(assert_fail(@safe_sqrt, -1), assert_fail(ValueError, @safe_sqrt, -4));
e = inspect_fail();
publish("the error was", e.type, ":", e.message);
try:
   assert_fail(@safe_sqrt, 4);
except AssertionError as err:
   publish(err.message);
tend
'''),
        'mid': ex('The type and the message', 'A built-in function, a pattern with a type, and two checks that fail: '
                  'the wrong error type and a message that does not match.', '''
function check_age(a):
   if a < 0:
      escalate ValueError("age " + str(a) + " is negative");
   iend
fnend

publish(assert_fail(ValueError, @zeros, -1), assert_fail_match(ValueError, "age -[0-9]+ is", @check_age, -12));
try:
   assert_fail(KeyError, @check_age, -1);
except AssertionError as err:
   publish(err.message);
tend
try:
   assert_fail_match("too old", @check_age, -1);
except AssertionError as err:
   publish(err.message);
tend
'''),
        'strong': ex('Warnings under test', 'A clipping function warns only above its limit, and an old function '
                     'warns that it is on its way out. Nothing is printed by the passing checks.', '''
function y = clipped(x):
   y = x;
   if x > 100:
      warn("value clipped to 100");
      y = 100;
   iend
fnend
function y = old_api(x):
   warn("old_api() is replaced by new_api()", LegacyWarning);
   y = x;
fnend

publish(assert_warn(@clipped, 250), assert_warn(UserWarning, @clipped, 101), assert_warn(LegacyWarning, @old_api, 1));
try:
   assert_warn(@clipped, 5);
except AssertionError as err:
   publish(err.message);
tend
try:
   assert_warn(LegacyWarning, @clipped, 500);
except AssertionError as err:
   publish(err.message);
tend
'''),
    },
    'errors': [
        err('Calling the function instead of passing it', 'Without <code>@</code>, the function is called first, its '
            'error stops the script, and <code>assert_fail</code> never runs.', '''
function y = safe_sqrt(x):
   if x < 0:
      escalate ValueError("x must be >= 0");
   iend
   y = sqrt(x);
fnend
assert_fail(ValueError, safe_sqrt(-1));''', '''
function y = safe_sqrt(x):
   if x < 0:
      escalate ValueError("x must be >= 0");
   iend
   y = sqrt(x);
fnend
publish(assert_fail(ValueError, @safe_sqrt, -1));'''),
    ],
}
