#!/usr/bin/env python3
"""Turn the generated SciPy example scripts into Build_Tools/df_scipy_reference.json.

Source: Function_Test/Code/A_06_Scipy_Functions/examples/phase_*/NN_<section>.nc, made by the NC team's
gen_examples.py. Every function there has a header block

    # ------------------------------------------------------------------------------------------
    # dct(data, type=2, norm="")
    #   Computes the discrete cosine transform ...
    #   Inputs : data: Array (Int, Float); type: Int, optional ...
    #   Needs  : 1 to 3 inputs
    #   Returns: Array of Float
    #   SciPy  : fft.dct()
    # ------------------------------------------------------------------------------------------

followed by optional "Data used by the next examples" code and numbered calls, each with the output
nc.exe printed ("# prints:"). The JSON keeps, per section, every function with its header and its
first calls, and the data blocks the calls need, so the site builds without the test folder.

    python Webpage_Framework/Build_Tools/extract_scipy_reference.py [path to the examples folder]
"""
import json
import re
import sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
DEFAULT = Path(r'D:/My Research Works/PASS Science Works/Function_Test/Code/A_06_Scipy_Functions/examples')
OUT = TOOLS / 'df_scipy_reference.json'
RULE = re.compile(r'^# -{20,}\s*$')
FIELD = re.compile(r'^#\s{3}(Inputs|Needs|Returns|SciPy)\s*:\s?(.*)$')
CALL = re.compile(r'^# (\d+)\) (.*)$')
MAX_CALLS = 3


def parse(path):
    lines = path.read_text(encoding='utf-8').splitlines()
    entries, data_blocks = [], []
    i, current_data = 0, None
    while i < len(lines):
        if not RULE.match(lines[i]):
            i += 1
            continue
        # header: rule, signature, description and fields, rule
        j = i + 1
        if j >= len(lines) or not lines[j].startswith('# ') or RULE.match(lines[j]):
            i += 1
            continue
        sig = lines[j][2:].strip()
        j += 1
        desc, fields, last = [], {}, None
        while j < len(lines) and not RULE.match(lines[j]):
            m = FIELD.match(lines[j])
            if m:
                last = m.group(1)
                fields[last] = m.group(2).strip()
            elif lines[j].startswith('#     ') and last:
                fields[last] += ' ' + lines[j][1:].strip()
            elif lines[j].startswith('#   '):
                desc.append(lines[j][4:].strip())
            j += 1
        if 'Needs' not in fields:          # the file's own title block, not a function
            i = j
            continue
        j += 1
        # body: data, then calls
        calls, data = [], None
        while j < len(lines) and not RULE.match(lines[j]):
            line = lines[j]
            if line.startswith('# Data used by the next examples'):
                code = []
                j += 1
                while j < len(lines) and not CALL.match(lines[j]) and not RULE.match(lines[j]):
                    if lines[j].strip():
                        code.append(lines[j])
                    j += 1
                data = '\n'.join(code).strip('\n')
                data_blocks.append(data)
                current_data = len(data_blocks) - 1
                continue
            m = CALL.match(line)
            if m:
                label = m.group(2)
                code, out = [], []
                j += 1
                while j < len(lines) and not lines[j].startswith('# prints') and not CALL.match(lines[j]) and not RULE.match(lines[j]):
                    if lines[j].strip() and not lines[j].startswith('#'):
                        code.append(lines[j])
                    j += 1
                if j < len(lines) and lines[j].startswith('# prints'):
                    j += 1
                    while j < len(lines) and lines[j].startswith('#') and not CALL.match(lines[j]) and not RULE.match(lines[j]) \
                            and not lines[j].startswith('# Data used'):
                        if lines[j].startswith('# (the result is long'):
                            out.append('...')
                            j += 1
                            continue
                        out.append(lines[j][1:][2:] if lines[j].startswith('#  ') else lines[j][1:].lstrip())
                        j += 1
                if len(calls) < MAX_CALLS:
                    calls.append({'label': label, 'code': '\n'.join(code), 'out': '\n'.join(out).rstrip()})
                continue
            j += 1
        name = sig.split('(')[0].strip()
        entries.append({'name': name, 'sig': sig, 'desc': ' '.join(desc), 'inputs': fields.get('Inputs', ''),
                        'needs': fields.get('Needs', ''), 'returns': fields.get('Returns', ''),
                        'scipy': fields.get('SciPy', ''), 'data': current_data, 'calls': calls})
        i = j
    return entries, data_blocks


def main():
    src = Path(sys.argv[1]) if len(sys.argv) > 1 else DEFAULT
    sections = {}
    for f in sorted(src.glob('phase_*/[0-9][0-9]_*.nc')):
        key = re.sub(r'^\d+_', '', f.stem)
        entries, data = parse(f)
        sections[key] = {'file': f'{f.parent.name}/{f.name}', 'entries': entries, 'data': data}
        print(f'{key:34s} {len(entries):4d} functions, {len(data):3d} data blocks')
    OUT.write_text(json.dumps(sections, ensure_ascii=False, indent=0), encoding='utf-8')
    total = sum(len(s['entries']) for s in sections.values())
    print(f'Wrote {OUT.name}: {len(sections)} sections, {total} functions, {OUT.stat().st_size // 1024} KB')


if __name__ == '__main__':
    main()
