"""Default Functions - Dates & Times (source: Function_Test/Code/A_03_Numpy_Rest_of_All, time_01..06).

A timestamp prints in the local time of the computer that runs the script, so the examples build their
timestamps without a zone (they then print as built) or show UTC ones through format_time(..., "UTC").
Every example and error card is run through nc.exe by build_default_functions.py.
"""
from df_helpers import err, ex, fig, fn, reference

IMG = 'Images/Neural_Code/Default_Functions/Dates_Times/'
PAGES = {}
T12 = 't1 = timestamp(2026, 10, 28, 14, 30, 0, "UTC");\nt2 = t1 + hours(1);\n'

# ================================================================== 1. Time values
PAGES['time-values'] = {
    'title': 'Timestamps, Durations & Time Zones',
    'summary': 'The two time types, timestamp (a point in time) and duration (a length of time): building them '
               'from parts or text, in any time zone, and how they print.',
    'about': reference('A timestamp is stored in UTC, to the nanosecond, and prints in the computer\'s local time; a '
                       'duration prints as hours:minutes:seconds. Supported years are about 1678 to 2261. Every '
                       'function works element by element on a matrix and keeps its shape.', [
        fn('timestamp(y, mo, d[, h, mi, s][, zone])', 'A timestamp from its parts: midnight when only the date is '
           'given; seconds may have a fraction.',
           inputs=[('y, mo, d', 'year, month, day (numbers or vectors)', ''), ('h, mi, s', 'hour, minute, second', '0, 0, 0'),
                   ('zone', 'an IANA time zone name such as "UTC", "Asia/Kolkata", "Europe/Berlin"', 'the computer\'s zone')],
           more=['During the autumn change to winter time a local time happens twice; NC takes the earlier one. In the '
                 'spring change a local time can be skipped, and asking for it is an error.'],
           figure=fig(IMG + 'time-values-01.svg',
                      'One instant shown on three clocks: 14:30 in UTC, 20:00 in Kolkata and 15:30 in Berlin, all '
                      'the same timestamp.',
                      'One timestamp, three ways of writing it. NC stores the instant; the zone only decides how it '
                      'is written.'),
           syntax='timestamp(2026, 10, 28)                  # midnight, local time\ntimestamp(2026, 10, 28, 14, 30, 0, "UTC")',
           short='a timestamp from year, month, day, time and zone'),
        fn('to_timestamp(text[, zone])', 'A timestamp from ISO 8601 text: "2026-10-28", "2026-10-28 14:30:00", '
           '"2026-10-28T14:30:00", with an optional fraction ".250" and an optional "Z" or "+05:30".',
           inputs=[('text', 'ISO 8601 text, or a matrix of it', ''), ('zone', 'zone for text without an offset', 'local')],
           more=['An offset written in the text wins over the zone argument.'],
           syntax='to_timestamp("2026-10-28T14:30:00Z")\nto_timestamp("2026-10-28 20:00:00+05:30")'),
        fn('get_timestamp()', 'Now.', syntax='now = get_timestamp();'),
        fn('seconds(n) / minutes(n) / hours(n) / days(n)', 'Durations; <code>days(1)</code> is exactly 24 hours. '
           'Hours are not wrapped at 24.', inputs=[('n', 'a number or matrix; may be negative or fractional', '')],
           syntax='minutes(90)     # 01:30:00\nhours(30)       # 30:00:00\nseconds(1.25)   # 00:00:01.250',
           short='durations from a number'),
    ]),
    'examples': {
        'basic': ex('Building timestamps and durations', 'A date, a date and time, a fractional second, a leap day, '
                    'and durations.', '''
t1 = timestamp(2026, 10, 28, 14, 30, 0)
d0 = timestamp(2026, 10, 28)
leap = timestamp(2024, 2, 29)
frac = timestamp(2026, 10, 28, 14, 30, 1.25)
publish(minutes(90), hours(30), days(1), minutes(-90), seconds(1.25));
'''),
        'mid': ex('Reading text', 'ISO 8601 in its usual forms, and a matrix of texts at once.', '''
a = to_timestamp("2026-10-28 14:30:00")
b = to_timestamp("2026-10-28T14:30:00")
c = to_timestamp("2026-10-28")
f = to_timestamp("2026-10-28 14:30:00.25")
P = to_timestamp(["2026-01-01", "2026-06-30 12:00:00"])
Y = timestamp([2024, 2025, 2026], 1, 1)
'''),
        'strong': ex('One instant, many zones', 'The same instant written in UTC, with a "Z", with an offset and in a '
                     'named zone; then the double hour when Berlin turns its clocks back.', '''
u = timestamp(2026, 10, 28, 14, 30, 0, "UTC");
publish(u == to_timestamp("2026-10-28T14:30:00Z"));
publish(u == to_timestamp("2026-10-28 20:00:00+05:30"));
publish(u == timestamp(2026, 10, 28, 20, 0, 0, "Asia/Kolkata"));
publish(u == to_timestamp("2026-10-28T14:30:00Z", "Asia/Tokyo"), " (the Z wins over Tokyo)");
publish("in Berlin:", format_time(u, "YYYY-MM-DD hh:mm", "Europe/Berlin"));
amb = timestamp(2026, 10, 25, 2, 30, 0, "Europe/Berlin");
publish("02:30 on 25 Oct in Berlin happens twice; NC takes", format_time(amb, "hh:mm", "UTC"), "UTC");
'''),
    },
    'errors': [
        err('A month that does not exist', 'Months run from 1 to 12.', 'x = timestamp(2026, 13, 1);',
            'x = timestamp(2026, 12, 1);\npublish(x);'),
        err('29 February in a normal year', 'NC names the valid range for that month.', 'x = timestamp(2026, 2, 29);',
            'x = timestamp(2026, 2, 28);\npublish(x);'),
        err('Hour 24', 'Hours run from 0 to 23; midnight is hour 0 of the next day.', 'x = timestamp(2026, 1, 1, 24, 0, 0);',
            'x = timestamp(2026, 1, 2, 0, 0, 0);\npublish(x);'),
        err('Text that is not a date', 'The text must be ISO 8601.', 'x = to_timestamp("2026-13-40");',
            'x = to_timestamp("2026-12-31");\npublish(x);'),
        err('A misspelt time zone', 'Zone names are the IANA names.', 'x = timestamp(2026, 1, 1, "Asia/Kolkatta");',
            'x = timestamp(2026, 1, 1, "Asia/Kolkata");\npublish(x == timestamp(2025, 12, 31, 18, 30, 0, "UTC"));'),
        err('A local time that is skipped', 'On 29 March 2026 Berlin jumps from 02:00 to 03:00.',
            'x = timestamp(2026, 3, 29, 2, 30, 0, "Europe/Berlin");',
            'x = timestamp(2026, 3, 29, 3, 30, 0, "Europe/Berlin");\npublish(format_time(x, "hh:mm", "UTC"));'),
        err('A year out of range', 'Timestamps cover about 1678 to 2261.', 'x = timestamp(2300, 1, 1);',
            'x = timestamp(2200, 1, 1);\npublish(x);'),
        err('A timestamp and a number in one matrix', 'A matrix holds one kind of value.',
            't1 = timestamp(2026, 10, 28);\nx = [t1, 5];', 't1 = timestamp(2026, 10, 28);\nx = [t1, t1 + days(5)];\npublish(x);'),
        err('A duration from text', 'Durations are made from numbers.', 'x = seconds("5");', 'x = seconds(5);\npublish(x);'),
    ],
}

# ================================================================== 2. Time arithmetic
PAGES['time-arithmetic'] = {
    'title': 'Time Arithmetic',
    'summary': 'Subtract timestamps to get a duration, move a timestamp by a duration, scale and divide durations, '
               'and compare times. Daylight saving is taken into account.',
    'about': reference('In the table, t is a timestamp, d a duration and k a number.', [
        fn('t2 - t1', 'A duration: the real time that passed, including any daylight-saving change.',
           math=r'd = t_2 - t_1', syntax='t2 - t1          # 01:30:15',
           figure=fig(IMG + 'time-arithmetic-01.svg',
                      'A time line with two timestamps t1 and t2. The gap between them is the duration d = t2 - t1; '
                      't1 + d lands on t2 and t2 - d on t1. Below, Berlin noon to noon across the spring clock change '
                      'is 23 hours.',
                      'Timestamps are points, durations are gaps. Across a clock change, noon to noon is 23 or 25 '
                      'hours, because NC counts the real time that passed.'),
           short='a duration: the time between two timestamps'),
        fn('t + d,  d + t,  t - d', 'A timestamp moved later or earlier.', syntax='t1 + hours(2) + minutes(30)',
           short='a timestamp moved by a duration'),
        fn('d1 + d2,  d1 - d2,  -d,  |d|,  abs(d)', 'Durations added, subtracted, negated, or made positive.',
           syntax='hours(1) - minutes(45)   # 00:15:00', short='duration arithmetic'),
        fn('d * k,  k * d,  d / k', 'A duration scaled; the result is rounded to the nearest nanosecond.',
           syntax='minutes(90) * 2   # 03:00:00\nhours(1) / 4      # 00:15:00', short='durations scaled by a number'),
        fn('d1 / d2', 'A number: how many d2 fit in d1.', math=r'\frac{90\ \text{min}}{15\ \text{min}} = 6',
           syntax='minutes(90) / minutes(15)   # 6', short='the ratio of two durations'),
        fn('==  !=  <  <=  >  >=', 'Comparisons between two timestamps or two durations. Two timestamps are equal '
           'when they are the same instant, whatever zone they were written in.',
           syntax='minutes(59) < hours(1)   # true', short='compare two timestamps or two durations'),
        fn('Matrices of times', 'Matrices follow the numeric rules: equal shapes element by element, or one value '
           'against every element. Between two matrices use <code>*.</code> and <code>/.</code>; '
           '<code>*</code> would be the matrix product, which has no meaning for time. Comparing two matrices gives '
           'one true/false; comparing with a single value gives one per element.',
           syntax='M = minutes([1, 2; 3, 4]);\nM *. [1, 2; 3, 4]\nM > minutes(2)', short='element by element on matrices'),
    ]),
    'examples': {
        'basic': ex('Gaps and moves', 'The gap between two times, and moving a time by a gap.', '''
t1 = timestamp(2026, 10, 28, 14, 30, 0);
t2 = timestamp(2026, 10, 28, 16, 0, 15);
d = t2 - t1
back = t1 - t2
later = t1 + hours(2) + minutes(30)
same = (t1 + d) == t2
'''),
        'mid': ex('Working with durations', 'Adding, scaling, dividing and comparing durations.', '''
a = minutes(90) + minutes(30)
b = hours(1) - minutes(45)
c = minutes(90) * 2
q = hours(1) / 4
n = minutes(90) / minutes(15)
r = minutes(1) / seconds(40)
publish(minutes(59) < hours(1), abs(minutes(-5)) == minutes(5));
'''),
        'strong': ex('Clock changes, matrices and laps', 'Noon to noon across both Berlin clock changes, element-wise '
                     'work on a matrix of durations, and lap times collected with <code>,=</code>.', '''
a = timestamp(2026, 3, 28, 12, 0, 0, "Europe/Berlin");
b = timestamp(2026, 3, 29, 12, 0, 0, "Europe/Berlin");
publish("spring, noon to noon:", b - a);
c = timestamp(2026, 10, 24, 12, 0, 0, "Europe/Berlin");
e = timestamp(2026, 10, 25, 12, 0, 0, "Europe/Berlin");
publish("autumn, noon to noon:", e - c);
M = minutes([1, 2; 3, 4]);
W = M *. [1, 2; 3, 4]
ratio = M /. minutes([1, 1; 1, 2])
big = M > minutes(2)
laps = [];
laps ,= minutes(4) + seconds(12);
laps ,= minutes(4) + seconds(5);
laps ,= minutes(3) + seconds(58);
publish("laps:", laps, "  total:", laps[0, 0] + laps[0, 1] + laps[0, 2]);
'''),
    },
    'errors': [
        err('Adding two timestamps', 'Two points in time cannot be added; their difference is the gap.',
            T12 + 'x = t1 + t2;', T12 + 'x = t2 - t1;\npublish(x);'),
        err('A timestamp plus a plain number', 'A number has no unit: say seconds, minutes, hours or days.',
            T12 + 'x = t1 + 5;', T12 + 'x = t1 + minutes(5);\npublish(x == t1 + seconds(300));'),
        err('A duration minus a plain number', 'The same rule for durations.', 'x = minutes(5) - 3;',
            'x = minutes(5) - minutes(3);\npublish(x);'),
        err('Multiplying a timestamp', 'A point in time cannot be scaled.', T12 + 'x = t1 * 2;',
            T12 + 'x = (t2 - t1) * 2;\npublish(x);'),
        err('Multiplying two durations', 'Time times time has no meaning here.', 'x = minutes(1) * minutes(2);',
            'x = minutes(1) * 2;\npublish(x);'),
        err('A timestamp compared with a duration', 'Compare like with like.', T12 + 'x = t1 < minutes(5);',
            T12 + 'x = t2 - t1 < minutes(90);\npublish(x);'),
        err('Dividing by zero', 'A duration cannot be divided by 0.', 'x = minutes(5) / 0;', 'x = minutes(5) / 2;\npublish(x);'),
        err('The matrix product of durations', 'Use *. for element by element.', 'D = minutes([1, 2; 3, 4]);\nx = D * D;',
            'D = minutes([1, 2; 3, 4]);\nx = D *. [1, 2; 3, 4];\npublish(x);'),
        err('A duration minus a timestamp', 'Write the timestamp first: t - d.', T12 + 'x = minutes(1) - t1;',
            T12 + 'x = t1 - minutes(1);\npublish(x == t1 - seconds(60));'),
    ],
}

# ================================================================== 3. Parts, text, conversions and the stopwatch
PAGES['parts-conversions'] = {
    'title': 'Parts, Text & the Stopwatch',
    'summary': 'Read and change the date and time of day, write timestamps and durations as text, turn durations '
               'into numbers, and time your code with tic and toc.',
    'about': reference('A time zone name at the end is optional: without it, parts are read and written in the '
                       'computer\'s zone. A single timestamp gives one row; N timestamps give N rows.', [
        fn('get_date(t[, zone]) / get_time(t[, zone])', '[year, month, day] / [hour, minute, second]; the second '
           'keeps its fraction.', inputs=[('t', 'timestamp(s)', ''), ('zone', 'time zone name', 'local')],
           syntax='get_date(t1, "UTC")             # 2026 10 28\nget_time(t1, "Asia/Kolkata")    # 20 0 0',
           short='the date / the time of day as numbers'),
        fn('set_date(t, y, mo, d[, zone]) / set_time(t, h, m, s[, zone])', 'A new timestamp with the date (or the '
           'time of day) changed and the rest kept. t itself does not change.',
           inputs=[('t', 'timestamp(s)', ''), ('y, mo, d / h, m, s', 'the new parts', ''), ('zone', 'time zone name', 'local')],
           syntax='set_time(t1, 9, 0, 0, "UTC")', short='a new timestamp with the date / time of day changed'),
        fn('today([zone])', 'The start (00:00:00) of today.', inputs=[('zone', 'time zone name', 'local')],
           syntax='today("UTC")'),
        fn('format_time(t[, pattern[, zone]])', 'A timestamp as text. YYYY year, MM month, DD day, hh hour '
           '(00&ndash;23), mm minute, ss second, fff milliseconds; any other character is copied.',
           inputs=[('t', 'timestamp(s)', ''), ('pattern', 'text', '"YYYY-MM-DD hh:mm:ss"'), ('zone', 'time zone name', 'local')],
           syntax='format_time(t1, "DD.MM.YYYY", "UTC")   # 28.10.2026'),
        fn('format_duration(d)', 'A duration as text: "01:30:15", "-01:30:00", "123:00:00", "00:00:01.250".',
           inputs=[('d', 'duration(s)', '')], syntax='format_duration(minutes(90))'),
        fn('in_seconds(d) / in_minutes / in_hours / in_days', 'A duration as a number of seconds, minutes, hours or '
           'days.', inputs=[('d', 'duration(s)', '')], syntax='in_minutes(minutes(90) + seconds(15))   # 90.25',
           short='a duration as a number'),
        fn('in_hms(d) / in_hrs_min_sec(d)', '[h, m, s]: whole hours and minutes, seconds with their fraction, every '
           'part with the sign of d, hours not wrapped at 24.', inputs=[('d', 'duration(s)', '')],
           math=r'3600\,h + 60\,m + s = \text{in\_seconds}(d)', syntax='in_hms(-minutes(90))   # -1 -30 0',
           short='a duration as hours, minutes, seconds'),
        fn('tic() / toc()', '<code>tic()</code> starts the stopwatch (again from zero if it was running) and gives '
           'back the time it started; <code>toc()</code> gives the time since then, as a duration, and the stopwatch '
           'keeps running.',
           more=['There is one stopwatch for the whole session. It runs on the computer\'s monotonic clock, which '
                 'never jumps: changing the clock, a time-server sync or daylight saving cannot disturb a measurement.'],
           syntax='tic();\n... work ...\nelapsed = toc();\npublish(in_seconds(elapsed));', short='measure elapsed time'),
    ]),
    'examples': {
        'basic': ex('Reading and changing parts', 'Parts in two zones, a matrix of timestamps, and new timestamps '
                    'with the time or date changed.', T12.replace('t2 = t1 + hours(1);', 't2 = timestamp(2026, 10, 28, 16, 0, 15, "UTC");') + '''
d = get_date(t1, "UTC")
t = get_time(t1, "UTC")
k = get_time(t1, "Asia/Kolkata")
T = [t1; t2];
both = get_time(T, "UTC")
t3 = set_time(t1, 9, 0, 0, "UTC");
t4 = set_date(t1, 2024, 2, 29, "UTC");
publish(get_time(t3, "UTC"), get_date(t4, "UTC"), get_time(t1, "UTC"));
'''),
        'mid': ex('Writing as text', 'Patterns for timestamps, and durations written out.', T12 + '''
publish(format_time(t1, "YYYY-MM-DD hh:mm:ss", "UTC"));
publish(format_time(t1, "DD.MM.YYYY", "UTC"));
publish(format_time(t1 + seconds(0.25), "hh:mm:ss.fff", "UTC"));
publish(format_time(t1, "YYYY/MM/DD at hh h", "UTC"));
publish(format_duration(minutes(90) + seconds(15)), format_duration(-minutes(90)), format_duration(hours(123)));
'''),
        'strong': ex('Durations as numbers, and timing code', 'Convert one duration every way, then time a loop with '
                     'the stopwatch and record lap times.', '''
d = minutes(90) + seconds(15);
publish("seconds", in_seconds(d), " minutes", in_minutes(d), " hours", round(in_hours(d), decimals=6));
h = in_hms(d)
neg = in_hms(-minutes(90))
check = h[0, 0] * 3600 + h[0, 1] * 60 + h[0, 2] == in_seconds(d)

started = tic();
laps = [];
for k = [1:3]:
   s = 0;
   for i = [1:20000]:
      s = s + i;
   fend
   laps ,= toc();
fend
publish("3 laps recorded:", numel(laps) == 3, "  laps grow:", laps[0, 0] <= laps[0, 1] && laps[0, 1] <= laps[0, 2]);
publish("all under a minute:", laps[0, 2] < minutes(1), "  started before now:", started <= get_timestamp());
'''),
    },
    'errors': [
        err('A timestamp where a duration is needed', 'in_minutes converts durations.', T12 + 'x = in_minutes(t1);',
            T12 + 'x = in_minutes(t2 - t1);\npublish(x);'),
        err('A duration where a timestamp is needed', 'get_time reads a point in time.', 'x = get_time(minutes(5));',
            'x = in_hms(minutes(5));\npublish(x);'),
        err('An hour that does not exist', 'Hours run from 0 to 23.', T12 + 'x = set_time(t1, 25, 0, 0, "UTC");',
            T12 + 'x = set_time(t1, 23, 0, 0, "UTC");\npublish(get_time(x, "UTC"));'),
        err('format_duration of a timestamp', 'Use format_time for timestamps.', T12 + 'x = format_duration(t1);',
            T12 + 'x = format_time(t1, "hh:mm", "UTC");\npublish(x);'),
        err('toc before tic', 'Start the stopwatch first.', 'x = toc();', 'tic();\nx = toc();\npublish(x >= seconds(0));'),
        err('A number with toc', 'toc() is a duration; add a duration, not a number.', 'tic();\nx = toc() + 5;',
            'tic();\nx = toc() + seconds(5);\npublish(x >= seconds(5));'),
    ],
}

# ================================================================== 4. Calendar and business days
WEEK = ('mon = timestamp(2026, 10, 26);\ntue = timestamp(2026, 10, 27);\nfri = timestamp(2026, 10, 30);\n'
        'sat = timestamp(2026, 10, 31);\nnext_mon = timestamp(2026, 11, 2);\n')
PAGES['calendar-business-days'] = {
    'title': 'Calendar & Business Days',
    'summary': 'Ranges of dates, and business-day tests, counts and offsets with any working week, holidays and '
               'time zone.',
    'about': reference('The business-day functions take three options by name, in any order: '
                       '<code>weekmask</code>, <code>holidays</code> and <code>zone</code>. Every function works '
                       'element by element on a matrix of timestamps.', [
        fn('date_range(start, stop[, step])', 'Timestamps from start, every step, up to but not including stop, as '
           'one row; a negative step counts down.',
           inputs=[('start, stop', 'timestamps', ''), ('step', 'a duration', 'days(1)')],
           syntax='date_range(mon, next_mon)             # 7 days\ndate_range(mon, fri, hours(36))'),
        fn('is_busday(t, weekmask, holidays, zone)', 'True when t falls on a business day.',
           inputs=[('t', 'timestamp(s)', ''),
                   ('weekmask', 'seven digits Monday to Sunday ("1111100"), or day names ("Sun Mon Tue Wed Thu")', '"1111100"'),
                   ('holidays', 'timestamps, or dates as text ["2026-12-25", ...]', 'none'),
                   ('zone', 'the time zone whose calendar decides the day', 'local')],
           more=['Any country\'s week can be written: a Sunday-to-Thursday week is "1111001" or '
                 '"Sun Mon Tue Wed Thu".'],
           syntax='is_busday(sat)                                   # false\nis_busday(sun, weekmask="Sun Mon Tue Wed Thu")   # true'),
        fn('busday_count(begin, end, ...)', 'The business days from begin up to but not including end; negative when '
           'end is before begin.', inputs=[('begin, end', 'timestamps', ''), ('weekmask, holidays, zone', 'as is_busday', '')],
           syntax='busday_count(mon, fri)   # 4'),
        fn('busday_offset(t, n, roll="raise", ...)', 'The business day n business days after t (n &lt; 0: before), as '
           'the start of that day.',
           inputs=[('t', 'timestamp(s)', ''), ('n', 'whole number of business days', ''),
                   ('roll', 'what to do when t is not a business day: "raise", "forward", "backward", '
                            '"modifiedfollowing", "modifiedpreceding" (may be named)', '"raise"'),
                   ('weekmask, holidays, zone', 'as is_busday', '')],
           more=['"modifiedfollowing" rolls forward unless that leaves the month, then backward.'],
           figure=fig(IMG + 'calendar-business-days-01.svg',
                      'Two weeks of a calendar from Monday 26 October 2026. Weekdays are business days, the weekend '
                      'is shaded, and Wednesday 28 October is marked as a holiday. Arrows show Friday plus one business '
                      'day landing on Monday, and Tuesday plus one business day skipping the holiday to Thursday.',
                      'Business days in a calendar: weekends are skipped, and a holiday is skipped too when it is '
                      'listed in <code>holidays</code>.'),
           syntax='busday_offset(fri, 1)                       # next Monday\nbusday_offset(sat, 0, roll="backward")      # Friday'),
    ]),
    'examples': {
        'basic': ex('Date ranges', 'A week of days, every 36 hours, counting down, and an empty range.', WEEK + '''
week = date_range(mon, next_mon);
publish("days:", numel(week), "  first:", week[0, 0], "  last:", week[0, 6]);
r36 = date_range(mon, fri, hours(36))
down = date_range(fri, mon, days(-2))
none = numel(date_range(fri, mon))
'''),
        'mid': ex('Which days are business days?', 'A normal week, holidays, other working weeks, and a time zone '
                  'that moves the day.', WEEK + '''
sun = timestamp(2026, 11, 1);
week = date_range(mon, next_mon);
b = is_busday(week)
publish("Friday as a holiday:", is_busday(fri, holidays=["2026-10-30"]));
publish("Sunday in a Sun-Thu week:", is_busday(sun, weekmask="Sun Mon Tue Wed Thu"));
publish("Saturday in a six-day week:", is_busday(sat, weekmask="1111110"));
late = timestamp(2026, 10, 30, 23, 0, 0, "UTC");
publish("23:00 UTC Friday is a business day in UTC:", is_busday(late, zone="UTC"), "  in Tokyo:", is_busday(late, zone="Asia/Tokyo"));
'''),
        'strong': ex('Counting and offsetting', 'Business days between dates, offsets in both directions, rolling '
                     'from a weekend, and a delivery date that skips Christmas.', WEEK + '''
publish("two weeks:", busday_count(mon, timestamp(2026, 11, 9)), "  with a holiday:", busday_count(mon, timestamp(2026, 11, 9), holidays=[fri]));
publish("to tue, fri, next mon:", busday_count(mon, [tue, fri, next_mon]));
publish("Friday + 1 is Monday:", busday_offset(fri, 1) == next_mon);
publish("Monday - 1 is Friday 23rd:", busday_offset(mon, -1) == timestamp(2026, 10, 23));
publish("from Saturday, forward:", get_date(busday_offset(sat, 0, roll="forward")), " modifiedfollowing:", get_date(busday_offset(sat, 0, roll="modifiedfollowing")));
order = timestamp(2026, 12, 23, 16, 0, 0);
delivery = busday_offset(order, 3, holidays=["2026-12-25", "2026-12-26"]);
publish("order 23 Dec + 3 business days:", format_time(delivery, "DD.MM.YYYY"));
'''),
    },
    'errors': [
        err('An offset from a weekend day', 'Saturday is not a business day: say which way to roll.', WEEK + 'x = busday_offset(sat, 1);',
            WEEK + 'x = busday_offset(sat, 1, roll="forward");\npublish(get_date(x));'),
        err('A weekmask with four days', 'It needs seven digits, Monday to Sunday.', WEEK + 'x = is_busday(mon, weekmask="1111");',
            WEEK + 'x = is_busday(mon, weekmask="1111100");\npublish(x);'),
        err('A misspelt day name', '"Fry" is not a day.', WEEK + 'x = is_busday(mon, weekmask="Mon Fry");',
            WEEK + 'x = is_busday(mon, weekmask="Mon Fri");\npublish(x);'),
        err('An unknown roll', 'NC lists the five rolls.', WEEK + 'x = busday_offset(mon, 1, roll="sideways");',
            WEEK + 'x = busday_offset(mon, 1, roll="forward");\npublish(x == tue);'),
        err('Half a business day', 'n must be whole.', WEEK + 'x = busday_offset(mon, 1.5);',
            WEEK + 'x = busday_offset(mon, 2);\npublish(get_date(x));'),
        err('A date given as text', 'Convert it with to_timestamp first.', 'x = is_busday("2026-10-26");',
            'x = is_busday(to_timestamp("2026-10-26"));\npublish(x);'),
        err('A zero step', 'A range needs a step.', WEEK + 'x = date_range(mon, sat, days(0));',
            WEEK + 'x = date_range(mon, sat, days(2));\npublish(numel(x));'),
        err('A step that is a number', 'The step is a duration.', WEEK + 'x = date_range(mon, sat, 5);',
            WEEK + 'x = date_range(mon, sat, days(5));\npublish(numel(x));'),
        err('Holidays as numbers', 'Holidays are timestamps or dates as text.', WEEK + 'x = is_busday(mon, holidays=[1, 2]);',
            WEEK + 'x = is_busday(mon, holidays=["2026-10-26"]);\npublish(x);'),
    ],
}
