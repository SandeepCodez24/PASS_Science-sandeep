"""Content of the Default Functions chapter (Neural_Code/default-functions.html and
Neural_Code/Default_Functions/<Domain_Folder>/<page>.html).

Sources: D:/My Research Works/PASS Science Works/Function_Test/Code, folders A_02 to A_10
(one domain per folder). A_01 (function and class calling rules) is NOT here: it is part of the
Language Guide (Functions and Classes sections, lg_content.py). Domains with no pages yet are
listed with their planned topics and marked "soon".

The page format is the Language Guide's (see lg_content.py): `about` components, three
examples (basic / mid / strong) and optional Syntax Error cards. Every example, and the
wrong and corrected code of every error card, is run through nc.exe by
build_default_functions.py; the output on the page is what NC printed.

A component may carry `figure=fig(src, alt, caption)`. `src` is
relative to the site root and must live under Images/ in the folder that mirrors the
page (Images/Neural_Code/Default_Functions/<Domain_Folder>/<page>-NN.svg).

Each domain's pages live in their own file, df_<domain>.py (helpers in df_helpers.py), and are
merged into PAGES at the end of this file.
"""
from df_helpers import fig  # noqa: F401


# Sample files the examples of a domain read, published for download (site-relative folders).
SAMPLES = {'data-handling': 'Cloud_Storage/Documents/Sample_Data/Data_Handling'}

# (slug, title, source folder, one-line description, planned topics, page slugs)
# A domain with no page slugs is shown as "soon".
DOMAINS = [
    ('core-math', 'Core Math Functions', 'A_02',
     'About 90 everyday numeric functions, from max and round to eigenvalues and polynomials, each with its '
     'inputs, maths and examples.',
     [], ['calling-built-ins', 'comparing-values', 'powers-logarithms', 'rounding-signs-limits', 'angles-complex',
          'integers-bits', 'floating-point', 'products', 'norms-decompositions', 'solving-systems', 'polynomials']),
    ('arrays-data', 'Arrays & Data', 'A_03',
     'Create, inspect, reshape, combine, select and summarise arrays; random numbers, missing data, histograms '
     'and text.',
     [], ['creating-arrays', 'random-numbers', 'inspecting-types', 'adding-removing', 'combining-splitting',
          'sorting-reshaping', 'indexing-selecting', 'reductions', 'missing-data', 'histograms-bins', 'sequences',
          'text-functions']),
    ('dates-times', 'Dates & Times', 'A_03',
     'Timestamps and durations in any time zone, time arithmetic, parts and text, the stopwatch, and business days.',
     [], ['time-values', 'time-arithmetic', 'parts-conversions', 'calendar-business-days']),
    ('data-handling', 'Data Handling', 'A_04',
     'Read, explore and write more than fifty file formats with one pattern: text tables, JSON, XML, spreadsheets, '
     'images, sound, video, scientific files, columnar files, databases and maps.',
     [], ['reading-loading-saving', 'finding-readers', 'delimited-text', 'json', 'xml-html', 'yaml-ini',
          'binary-custom', 'spreadsheets', 'images', 'audio-video', 'matlab-fits', 'hdf5-netcdf', 'columnar-files',
          'databases', 'maps-gps', 'preparing-data']),
    ('traditional-math', 'Traditional Mathematics', 'A_05',
     'School and university mathematics written the way it is on paper: trigonometry, shapes and solids, '
     'statistics and tests, matrices, calculus with Green\'s and Stokes\'s theorems, vectors and physical constants.',
     [], ['trigonometry', 'shapes-solids', 'descriptive-statistics', 'relationships-tests', 'matrix-functions',
          'calculus', 'vectors', 'universal-constants']),
    ('scientific-library', 'Scientific Library', 'A_06',
     'About 2,100 functions that match SciPy: Fourier transforms, signal and image processing, interpolation, '
     'optimization, linear algebra, sparse matrices and graphs, special functions, statistics and probability '
     'distributions, each with a searchable reference.',
     [], ['library-overview', 'clustering', 'integration-odes', 'fourier-transforms', 'interpolation', 'file-io',
          'linear-algebra', 'image-processing', 'optimization', 'signal-processing', 'window-functions',
          'sparse-graphs', 'spatial', 'special-functions', 'statistics', 'distributions', 'blas-lapack',
          'removed-functions']),
    ('engineering-math', 'Engineering Mathematics', 'A_07',
     'Engineering mathematics from the textbook, chapter by chapter: vector calculus, ODE tools, Laplace transforms, '
     'Fourier series, PDEs, complex analysis and quality control.',
     [], ['vector-calculus', 'ode-analysis', 'laplace-transforms', 'fourier-series', 'pdes', 'complex-functions',
          'residues-conformal', 'probability-quality']),
    ('ndat-data', 'NDAT Data Files', 'A_08',
     "NC's own data bundle: save, read and load any value exactly, with slices and columns, whole workspaces, "
     'entry information and export to other formats.',
     [], ['saving-reading', 'workspaces-export']),
    ('assertions', 'Assertions & Exceptions', 'A_09',
     'Twenty-two assert_* checks for tests, expected failures and warnings, and reports of the errors a try block '
     'handled. The try / except syntax itself is in the Language Guide.',
     [], ['writing-checks', 'equality-identity', 'truth-emptiness-types', 'order-containers-patterns',
          'expected-failures', 'warnings', 'error-reports']),
    ('null-sets', 'Null Sets', 'A_10',
     'One call makes a whole set of letters into variables with the value 0: Tamil, Malayalam, Sanskrit and Telugu '
     'vowels, or twelve Greek letters.',
     [], ['nullset-functions']),
]

LANDING = {
    'title': 'Default Functions',
    'summary': 'Every function that ships with NC, grouped by domain. Each one is called the same way as a '
               'function you write yourself, and each one is built to use every core of your machine.',
}

# Landing-page sections (HTML allowed).
MULTICORE = {
    'intro': [
        'NC\'s default functions are written for multicore, multithreaded machines. When you call '
        '<code>sin(A)</code> on a large matrix, <code>sum(v)</code> on a long vector or a matrix product, '
        'NC cuts the work into blocks and hands the blocks to the cores of your machine. You do not write '
        'threads, locks or pragmas: you write the call, and NC decides how many cores to use.',
        'The same parallel layer runs on Windows, Linux and macOS (OpenMP, or a pool of standard C++ threads '
        'where OpenMP is not available), and the linear-algebra library shares the same threads.'],
    'promises': [
        ('Same answer on 1 or 28 threads', "NC's own kernels "
         ' (element-wise functions, sums and other reductions) cut '
         'their blocks from the size of the work alone and combine partial results in order, so the result is '
         'identical to the last bit whatever the thread count. Matrix products come from the linear-algebra '
         'library, where the last digit can differ.'),
        ('No overhead on small work', 'Work that takes less than about 200 microseconds runs on one core: '
         'starting threads would cost more than it saves.'),
        ('Errors read like a plain loop', 'If a block fails, NC reports the error of the earliest element, '
         'exactly as a one-core loop would.'),
        ('Stop means stop', "The IDE's Stop button"
         ' ends a long call between blocks, within a fraction of a '
         'millisecond of work.'),
    ],
    'kinds': [
        ['Kind of work', 'Examples', 'Threads used'],
        ['Stream: reads and writes large arrays', '<code>A + B</code>, copy, transpose', 'up to 8'],
        ['Reduce: many values in, one value out', '<code>sum</code>, <code>dot</code>, <code>norm</code>', 'up to 16'],
        ['Compute: heavy work per element', '<code>sin</code>, <code>exp</code>, <code>lgamma</code>', 'every core'],
        ['Task: uneven pieces of work', 'file decoding, FFT column by column', 'every core'],
    ],
    'figure': fig('Images/Neural_Code/default-functions-01.svg',
                  'One call such as sin(A) split into blocks, processed on several cores, and combined in order.',
                  'One call, many cores: the work is cut into equal blocks, the cores take blocks as they become '
                  'free, and the results are put back together in their original order.'),
    'control_text': 'You can see and change the number of threads from a script. <code>thread_info()</code> '
                    'describes the machine and the build, <code>get_threads()</code> gives the current count, '
                    'and <code>set_threads(n)</code> changes it (<code>set_threads(0)</code> goes back to the '
                    'default: every logical processor). The example times the same two calls on one thread and on '
                    'all of them.',
    'control_code': '''info = thread_info();
publish("backend:", info.backend, "  build:", info.build);
publish("threads in use:", get_threads(), "of", info.logical_processors);

A = ones(3000, 3000) *. 0.5;
M = ones(1500, 1500) *. 0.001;
set_threads(1);
tic();
E1 = exp(A);
te1 = toc();
tic();
P1 = M * M;
tp1 = toc();
set_threads(0);
tic();
E2 = exp(A);
te2 = toc();
tic();
P2 = M * M;
tp2 = toc();
publish("exp(A), 9 million values:  1 thread", round(in_seconds(te1), decimals=3), "s,  all threads", round(in_seconds(te2), decimals=3), "s");
publish("M * M, 1500 x 1500:        1 thread", round(in_seconds(tp1), decimals=3), "s,  all threads", round(in_seconds(tp2), decimals=3), "s");
publish("exp gives the same bits:", sum(E1) == sum(E2), "   M * M agrees:", allclose(P1, P2));''',
    'workout_text': 'To watch every core at work, run this one-to-two-minute workout in the IDE with the Analysis '
                    'windows open (Cores &amp; threads). Phase 1 is a loop whose work grows with every pass, so its '
                    'run time grows as n&sup2;; phase 2 runs element-wise kernels and sums on a 3000 x 3000 matrix; '
                    'phase 3 multiplies 2000 x 2000 matrices in the linear-algebra library. The checksums do not '
                    'depend on the thread count, only the times do: try <code>set_threads(1)</code> first to '
                    'compare. On a 28-thread PC a Release build takes about 66 s (21 s + 30 s + 15 s).',
    'workout_code': '''info = thread_info();
publish("nc build:", info.build);
publish("threads:", get_threads(), "of", info.logical_processors, "logical processors");

# ---- Phase 1: growing work, O(n^2) ------------------------------------
tic();
s1 = 0;
for i = [1:230]:
    x = ones(40000 * i, 1) *. (1 / i);
    s1 = s1 + sum(sqrt(x + 1) *. log(x + 2));
fend
t1 = toc();
publish("phase 1 (growing loop) done, checksum", s1);

# ---- Phase 2: element-wise kernels and reductions -----------------------
tic();
A = ones(3000, 3000) *. 0.5;
s2 = 0;
for k = [1:200]:
    B = sin(A) *. cos(A) + exp(-A);
    s2 = s2 + sum(B);
fend
t2 = toc();
publish("phase 2 (element-wise kernels) done, checksum", s2);

# ---- Phase 3: matrix products ---------------------------------------
tic();
M = ones(2000, 2000) *. 0.001;
s3 = 0;
for k = [1:90]:
    C = M * M;
    s3 = s3 + sum(C);
fend
t3 = toc();
publish("phase 3 (matrix products) done, checksum", s3);

publish("phase times:", t1, t2, t3);''',
}

CALLING = {
    'text': 'A default function is called exactly like a function you write yourself: values in order, values '
            'by name, or a mix of both. The rules are explained in the Language Guide, on '
            '<a href="Language_Guide/Functions/defaults-named-inputs.html">Defaults &amp; Named Inputs</a> and '
            '<a href="Language_Guide/Functions/overloads.html">Overloads</a>, and they hold for every function '
            'in this chapter.',
    'code': '''A = [1, 1; 1, 1];
B = [1.05, 1; 1, 1];
publish(allclose(A, B), allclose(A, B, atol=0.1));
publish(round(3.14159, decimals=2));
publish(clip([1, 5, 9], lo=2, hi=6));
x = 16;
publish(x.sqrt());''',
}

PAGES = {}

from df_core_math import PAGES as _core_math  # noqa: E402

PAGES.update(_core_math)
from df_arrays_data import PAGES as _arrays_data  # noqa: E402
from df_dates_times import PAGES as _dates_times  # noqa: E402

PAGES.update(_arrays_data)
PAGES.update(_dates_times)
from df_data_handling import PAGES as _data_handling  # noqa: E402

PAGES.update(_data_handling)
from df_traditional_math import PAGES as _traditional_math  # noqa: E402

PAGES.update(_traditional_math)
from df_scientific_library import PAGES as _scientific_library  # noqa: E402

PAGES.update(_scientific_library)
from df_engineering_math import PAGES as _engineering_math  # noqa: E402

PAGES.update(_engineering_math)
from df_ndat_data import PAGES as _ndat_data  # noqa: E402

PAGES.update(_ndat_data)
from df_assertions import PAGES as _assertions  # noqa: E402

PAGES.update(_assertions)
from df_null_sets import PAGES as _null_sets  # noqa: E402

PAGES.update(_null_sets)
