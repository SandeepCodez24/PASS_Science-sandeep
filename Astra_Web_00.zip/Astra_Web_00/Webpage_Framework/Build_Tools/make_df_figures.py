#!/usr/bin/env python3
"""Draw the plot-type diagrams of the Default Functions chapter (matplotlib, SVG; the Scientific Library
figures use SciPy, which NC matches).

Hand-drawn diagrams (arrows, boxes) are plain SVG files written by hand; this script makes
only the ones that are plots of real functions or data, so they are exact. The numbers used
are the same as in the page examples.

    python Webpage_Framework/Build_Tools/make_df_figures.py

Output: Images/Neural_Code/Default_Functions/<Domain_Folder>/<page>-NN.svg
"""
import sys
sys.dont_write_bytecode = True
import warnings
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

SITE = Path(__file__).resolve().parents[2]
OUT = SITE / 'Images' / 'Neural_Code' / 'Default_Functions'

NAVY, ACCENT, GREEN, GREY, ORANGE, PLUM = '#0E3B6E', '#2A74C0', '#1F7A4D', '#5E6873', '#B4570F', '#9C2F6B'
LINE, PANEL = '#CFD6DE', '#F6F8FA'

warnings.filterwarnings('ignore', message='.*findfont.*')
plt.rcParams.update({
    'svg.fonttype': 'none',                      # keep text as text: the browser draws it with the site fonts
    'svg.hashsalt': 'nc-docs',                   # stable ids, so a re-run gives the same file
    'font.family': 'sans-serif',
    'font.sans-serif': ['Inter', 'Segoe UI', 'Arial', 'DejaVu Sans'],
    'font.size': 11,
    'axes.edgecolor': GREY, 'axes.labelcolor': '#1F2328', 'axes.titleweight': 'bold', 'axes.titlecolor': NAVY,
    'axes.titlesize': 12, 'xtick.color': GREY, 'ytick.color': GREY, 'axes.spines.top': False,
    'axes.spines.right': False, 'axes.grid': True, 'grid.color': '#E3E7EC', 'grid.linewidth': 0.8,
    'legend.frameon': False, 'figure.facecolor': 'white', 'axes.facecolor': 'white',
})


def save(fig, domain, name):
    path = OUT / domain / name
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, format='svg', bbox_inches='tight', pad_inches=0.15, metadata={'Date': None})
    plt.close(fig)
    print('wrote', path.relative_to(SITE).as_posix())


# ------------------------------------------------------------------ Core Math
def tolerance_band():
    b = np.linspace(0, 10, 200)
    atol, rtol = 0.5, 0.1
    fig, axes = plt.subplots(1, 2, figsize=(9.2, 3.4), sharey=True)
    for ax, (a, r, title) in zip(axes, [(atol, 0, 'atol = 0.5, rtol = 0'), (atol, rtol, 'atol = 0.5, rtol = 0.1')]):
        half = a + r * np.abs(b)
        ax.fill_between(b, b - half, b + half, color=ACCENT, alpha=0.15, lw=0, label='close to B')
        ax.plot(b, b, color=NAVY, lw=2, label='A = B')
        ax.plot(b, b + half, color=ACCENT, lw=1, ls='--')
        ax.plot(b, b - half, color=ACCENT, lw=1, ls='--')
        pts_b = np.array([2, 4, 6, 8, 9])
        pts_a = np.array([2.3, 3.3, 6.9, 8.6, 10.6])
        inside = np.abs(pts_a - pts_b) <= a + r * np.abs(pts_b)
        ax.scatter(pts_b[inside], pts_a[inside], color=GREEN, zorder=3, s=30, label='inside: close')
        ax.scatter(pts_b[~inside], pts_a[~inside], color=PLUM, marker='x', zorder=3, s=40, label='outside')
        ax.set_title(title)
        ax.set_xlabel('B')
    axes[0].set_ylabel('A')
    axes[1].legend(loc='upper left', fontsize=9.5)
    fig.suptitle('|A - B| <= atol + rtol |B|', color=NAVY, fontsize=12, y=1.02)
    save(fig, 'Core_Math', 'comparing-values-01.svg')


def rounding_steps():
    x = np.linspace(-3, 3, 1201)
    fig, ax = plt.subplots(figsize=(9.2, 3.8))
    ax.plot(x, x, color=LINE, lw=1.2, label='x')
    curves = [(np.floor(x), NAVY, 'floor'), (np.ceil(x), ORANGE, 'ceil'), (np.trunc(x), GREEN, 'fix / trunc'),
              (np.sign(x) * np.floor(np.abs(x) + 0.5), PLUM, 'round')]
    for k, (y, color, label) in enumerate(curves):
        jumps = np.where(np.abs(np.diff(y)) > 0.5)[0] + 1
        ys = np.insert(y.astype(float), jumps, np.nan)
        xs = np.insert(x, jumps, np.nan)
        ax.plot(xs, ys + (k - 1.5) * 0.06, color=color, lw=2, label=label)
    ax.set_xticks(range(-3, 4))
    ax.set_yticks(range(-3, 4))
    ax.set_xlabel('x')
    ax.legend(loc='upper left', ncol=5, fontsize=9.5)
    ax.set_title('Four ways to a whole number (curves nudged apart where they agree)')
    save(fig, 'Core_Math', 'rounding-signs-limits-01.svg')


def anglewrap_plot():
    k = np.arange(8)
    unwrapped = 1.2 * k
    wrapped = np.angle(np.exp(1j * unwrapped))
    fig, ax = plt.subplots(figsize=(9.2, 3.6))
    ax.axhspan(-np.pi, np.pi, color=PANEL, zorder=0)
    ax.axhline(np.pi, color=LINE, lw=1)
    ax.axhline(-np.pi, color=LINE, lw=1)
    ax.plot(k, wrapped, color=ORANGE, marker='o', lw=1.6, label='angle(z): wrapped into -π to π')
    ax.plot(k, unwrapped, color=NAVY, marker='o', lw=2, label='anglewrap(angle(z)): continuous')
    ax.text(7.15, np.pi, 'π', color=GREY, va='center')
    ax.text(7.15, -np.pi, '-π', color=GREY, va='center')
    ax.set_xlabel('step k')
    ax.set_ylabel('phase (radians)')
    ax.set_xticks(k)
    ax.legend(loc='upper left', fontsize=9.5)
    ax.set_title('A phasor turning 1.2 radians per step')
    save(fig, 'Core_Math', 'angles-complex-02.svg')


def float_spacing():
    # A toy binary format with 3 mantissa bits: 8 values between each pair of powers of two.
    vals = [m * 2.0 ** e for e in range(0, 3) for m in np.arange(1, 2, 1 / 8)] + [8.0]
    fig, ax = plt.subplots(figsize=(9.2, 2.0))
    ax.set_ylim(-1, 1.2)
    ax.set_xlim(0.8, 8.3)
    ax.axhline(0, color=GREY, lw=1)
    for v in vals:
        major = float(v).is_integer() and int(v) in (1, 2, 4, 8)
        ax.plot([v, v], [-0.28 if major else -0.16, 0.28 if major else 0.16], color=NAVY if major else ACCENT,
                lw=2 if major else 1.4)
    for lo, hi, gap in [(1, 2, '1/8'), (2, 4, '1/4'), (4, 8, '1/2')]:
        ax.annotate('', xy=(lo, 0.62), xytext=(hi, 0.62), arrowprops=dict(arrowstyle='<->', color=GREY, lw=1))
        ax.text((lo + hi) / 2, 0.78, f'gap {gap}', ha='center', color=GREEN, fontsize=10, fontweight='bold')
    for v in (1, 2, 4, 8):
        ax.text(v, -0.62, str(v), ha='center', color=NAVY, fontsize=11, fontweight='bold')
    ax.axis('off')
    ax.set_title('Representable numbers in a toy format with 3 mantissa bits (doubles have 52)', fontsize=11)
    save(fig, 'Core_Math', 'floating-point-01.svg')


def svd_ellipse():
    A = np.array([[2.0, 1.0], [1.0, 1.5]])
    U, S, Vt = np.linalg.svd(A)
    t = np.linspace(0, 2 * np.pi, 400)
    circle = np.vstack([np.cos(t), np.sin(t)])
    ell = A @ circle
    fig, axes = plt.subplots(1, 2, figsize=(9.2, 4.0))
    for ax in axes:
        ax.set_aspect('equal')
        ax.axhline(0, color=LINE, lw=1)
        ax.axvline(0, color=LINE, lw=1)
        ax.grid(False)
    a0, a1 = axes
    a0.plot(circle[0], circle[1], color=NAVY, lw=2)
    for k, color in ((0, ACCENT), (1, ORANGE)):
        v = Vt[k] * np.sign(Vt[k][0] or 1)
        a0.annotate('', xy=v, xytext=(0, 0), arrowprops=dict(arrowstyle='-|>', color=color, lw=2))
        a0.text(*(v * 1.22), f'v{k + 1}', color=color, ha='center', va='center', fontsize=12, fontweight='bold')
    a0.set_xlim(-1.6, 1.6)
    a0.set_ylim(-1.6, 1.6)
    a0.set_title('the unit circle')
    a1.plot(ell[0], ell[1], color=NAVY, lw=2)
    for k, color in ((0, ACCENT), (1, ORANGE)):
        sign = np.sign(Vt[k][0] or 1)
        u = U[:, k] * S[k] * sign
        a1.annotate('', xy=u, xytext=(0, 0), arrowprops=dict(arrowstyle='-|>', color=color, lw=2))
        where = u + (np.array([-0.2, 0.45]) if k == 0 else np.array([0.25, -0.35]))
        a1.text(*where, f'σ{k + 1} u{k + 1}   (σ{k + 1} = {S[k]:.2f})', color=color,
                ha='center' if k == 0 else 'left', va='center', fontsize=10.5, fontweight='bold')
    a1.set_xlim(-3.3, 3.3)
    a1.set_ylim(-3.0, 3.0)
    a1.set_title('A sends the circle to this ellipse: A = [2, 1; 1, 1.5]')
    save(fig, 'Core_Math', 'norms-decompositions-01.svg')


def lstsq_fit():
    t = np.array([0, 1, 2, 3.0])
    y = np.array([-1, 0.2, 0.9, 2.1])
    slope, icept = np.linalg.lstsq(np.vstack([t, np.ones(4)]).T, y, rcond=None)[0]
    fig, ax = plt.subplots(figsize=(9.2, 3.6))
    tt = np.linspace(-0.3, 3.3, 10)
    ax.plot(tt, slope * tt + icept, color=NAVY, lw=2, label=f'best line: y = {slope:.2f} t {icept:+.2f}')
    for ti, yi in zip(t, y):
        ax.plot([ti, ti], [yi, slope * ti + icept], color=ORANGE, lw=1.6)
    ax.plot([], [], color=ORANGE, lw=1.6, label='residuals (their squares are summed)')
    ax.scatter(t, y, color=ACCENT, zorder=3, s=40, label='measurements')
    ax.set_xlabel('t')
    ax.set_ylabel('y')
    ax.legend(loc='upper left', fontsize=9.5)
    ax.set_title('lstsq(Xa, Y) with Xa = [t, 1]')
    save(fig, 'Core_Math', 'solving-systems-01.svg')


def polynomial_plot():
    x = np.linspace(-2.2, 1.2, 300)
    p = 2 * x ** 2 + 3 * x + 1
    d = 4 * x + 3
    fig, ax = plt.subplots(figsize=(9.2, 3.8))
    ax.axhline(0, color=GREY, lw=1)
    ax.plot(x, p, color=NAVY, lw=2.2, label='P(x) = 2x² + 3x + 1')
    ax.plot(x, d, color=ORANGE, lw=1.6, ls='--', label="polyder(P) = 4x + 3")
    ax.scatter([-1, -0.5], [0, 0], color=GREEN, zorder=3, s=45, label='P.roots: -1, -0.5')
    ax.scatter([-0.75], [2 * 0.5625 - 2.25 + 1], color=PLUM, zorder=3, s=45, label='lowest point: x = -0.75')
    ax.plot([-0.75, -0.75], [-0.125, 0], color=PLUM, lw=1, ls=':')
    ax.set_ylim(-3, 4.5)
    ax.set_xlabel('x')
    ax.legend(loc='upper center', ncol=2, fontsize=9.5)
    ax.set_title('A poly1d, its roots and its derivative')
    save(fig, 'Core_Math', 'polynomials-01.svg')


# ------------------------------------------------------------------ Arrays & Data
def distributions():
    from math import comb, exp, factorial, gamma as G
    fig, axes = plt.subplots(2, 3, figsize=(9.6, 5.2))
    k = np.arange(0, 11)
    ax = axes[0, 0]
    ax.bar(k, [comb(10, int(i)) * 0.5 ** 10 for i in k], color=ACCENT, width=0.7)
    ax.set_title('rand_binomial(10, 0.5)')
    ax = axes[0, 1]
    ax.bar(k, [3 ** int(i) * exp(-3) / factorial(int(i)) for i in k], color=ACCENT, width=0.7)
    ax.set_title('rand_poisson(3)')
    x = np.linspace(0, 10, 300)
    ax = axes[0, 2]
    ax.plot(x, np.exp(-x / 2) / 2, color=NAVY, lw=2)
    ax.fill_between(x, np.exp(-x / 2) / 2, color=NAVY, alpha=0.08)
    ax.set_title('rand_exponential(2)')
    u = np.linspace(0, 1, 300)
    ax = axes[1, 0]
    b = u * (1 - u) ** 2 * G(5) / (G(2) * G(3))
    ax.plot(u, b, color=NAVY, lw=2)
    ax.fill_between(u, b, color=NAVY, alpha=0.08)
    ax.set_title('rand_beta(2, 3)')
    g = np.linspace(0, 30, 300)
    ax = axes[1, 1]
    gd = g * np.exp(-g / 3) / (G(2) * 3 ** 2)
    ax.plot(g, gd, color=NAVY, lw=2)
    ax.fill_between(g, gd, color=NAVY, alpha=0.08)
    ax.set_title('rand_gamma(2, 3)')
    ax = axes[1, 2]
    ax.plot([0, 1, 4], [0, 0.5, 0], color=NAVY, lw=2)
    ax.fill_between([0, 1, 4], [0, 0.5, 0], color=NAVY, alpha=0.08)
    ax.set_title('rand_triangular(0, 1, 4)')
    for a in axes.flat:
        a.set_yticks([])
        a.spines['left'].set_visible(False)
    fig.tight_layout()
    save(fig, 'Arrays_Data', 'random-numbers-01.svg')


def fill_methods():
    log = np.array([5, np.nan, np.nan, 8, 9, np.nan, 6])
    k = np.arange(len(log))
    known = ~np.isnan(log)
    filled = {
        'ffill': [5, 5, 5, 8, 9, 9, 6],
        'bfill': [5, 8, 8, 8, 9, 6, 6],
        'linear': [5, 6, 7, 8, 9, 7.5, 6],
        'mean': [5, 7, 7, 8, 9, 7, 6],
    }
    fig, axes = plt.subplots(1, 4, figsize=(9.6, 2.9), sharey=True)
    for ax, (name, vals) in zip(axes, filled.items()):
        vals = np.array(vals, float)
        ax.plot(k, vals, color=LINE, lw=1.5, zorder=1)
        ax.scatter(k[known], vals[known], color=NAVY, s=36, zorder=3, label='reading')
        ax.scatter(k[~known], vals[~known], color=ORANGE, marker='D', s=36, zorder=3, label='filled')
        ax.set_title(f'method="{name}"')
        ax.set_xticks(k)
        ax.set_ylim(3.5, 10)
    axes[0].legend(loc='upper left', fontsize=9)
    fig.tight_layout()
    save(fig, 'Arrays_Data', 'missing-data-01.svg')


def histogram_plot():
    data = [1, 2, 2, 3, 3, 3]
    edges = np.array([1, 5 / 3, 7 / 3, 3])
    counts = [1, 2, 3]
    fig, ax = plt.subplots(figsize=(9.2, 3.4))
    ax.bar(edges[:-1], counts, width=np.diff(edges), align='edge', color=ACCENT, alpha=0.25, edgecolor=ACCENT, lw=1.5)
    for left, c in zip(edges[:-1], counts):
        ax.text(left + (edges[1] - edges[0]) / 2, c + 0.08, str(c), ha='center', color=NAVY, fontweight='bold')
    for e in edges:
        ax.axvline(e, color=NAVY, lw=1, ls=':')
    ax.set_xticks(edges)
    ax.set_xticklabels(['1', '1.667', '2.333', '3'])
    ys = {1: [0.3], 2: [0.3, 0.6], 3: [0.3, 0.6, 0.9]}
    for v, yy in ys.items():
        ax.scatter([v] * len(yy), yy, color=ORANGE, zorder=3, s=30)
    ax.set_ylim(0, 3.6)
    ax.set_xlim(0.8, 3.2)
    ax.set_ylabel('count')
    ax.set_title('histogram([1, 2, 2, 3, 3, 3], bins=3): edges and counts (dots are the data)')
    ax.grid(False)
    save(fig, 'Arrays_Data', 'histograms-bins-01.svg')


def trapz_interp():
    fig, (a0, a1) = plt.subplots(1, 2, figsize=(9.6, 3.4))
    t = np.array([0, 2, 4, 6, 8, 10.0])
    v = np.array([0, 6, 11, 15, 18, 20.0])
    for i in range(len(t) - 1):
        a0.fill([t[i], t[i + 1], t[i + 1], t[i]], [0, 0, v[i + 1], v[i]], color=ACCENT if i % 2 else '#8EC0F0',
                alpha=0.35, lw=0)
    a0.plot(t, v, color=NAVY, marker='o', lw=2)
    a0.set_title('trapz(v, x=t) = 120  (sum of the trapezoids)')
    a0.set_xlabel('t (s)')
    a0.set_ylabel('v (m/s)')
    xp = np.array([1, 2, 3.0])
    fp = np.array([3, 2, 0.0])
    a1.plot([0, 1], [3, 3], color=GREY, ls='--', lw=1.4)
    a1.plot([3, 4], [0, 0], color=GREY, ls='--', lw=1.4)
    a1.plot(xp, fp, color=NAVY, lw=2)
    a1.scatter(xp, fp, color=NAVY, s=40, zorder=3, label='known points (xp, fp)')
    q = np.array([0.5, 1.5, 2.5, 3.5])
    a1.scatter(q, np.interp(q, xp, fp), color=ORANGE, marker='D', s=40, zorder=3, label='interp(x, xp, fp)')
    a1.set_title('interp: straight lines between points')
    a1.text(0.1, 3.2, 'left: end value', color=GREY, fontsize=9.5)
    a1.text(3.05, 0.2, 'right: end value', color=GREY, fontsize=9.5)
    a1.set_ylim(-0.5, 3.8)
    a1.legend(loc='lower left', fontsize=9)
    fig.tight_layout()
    save(fig, 'Arrays_Data', 'sequences-01.svg')


# ------------------------------------------------------------------ Traditional Mathematics
TM = 'Traditional_Math'
SX = np.array([2.5, 3.1, 4.7, 4.7, 5.0, 6.2, 8.8, 9.4, 12.1, 15.6])
SY = np.array([1.2, 2.4, 2.2, 3.9, 4.1, 6.5, 7.7, 9.9, 10.1, 16.0])


def trig_curves():
    fig, (a0, a1) = plt.subplots(1, 2, figsize=(9.6, 3.6))
    x = np.linspace(-2 * np.pi, 2 * np.pi, 2000)
    a0.plot(x, np.sin(x), color=NAVY, lw=2, label='sin')
    a0.plot(x, np.cos(x), color=ORANGE, lw=2, label='cos')
    t = np.tan(x)
    t[np.abs(t) > 4] = np.nan
    a0.plot(x, t, color=GREEN, lw=1.6, label='tan')
    a0.set_ylim(-3, 3)
    a0.set_xticks([-2 * np.pi, -np.pi, 0, np.pi, 2 * np.pi])
    a0.set_xticklabels(['-2π', '-π', '0', 'π', '2π'])
    a0.legend(loc='lower left', ncol=3, fontsize=9)
    a0.set_title('sin, cos, tan (radians)')
    h = np.linspace(-2, 2, 400)
    a1.plot(h, np.sinh(h), color=NAVY, lw=2, label='sinh')
    a1.plot(h, np.cosh(h), color=ORANGE, lw=2, label='cosh')
    a1.plot(h, np.tanh(h), color=GREEN, lw=2, label='tanh')
    a1.set_ylim(-3, 4)
    a1.legend(loc='upper left', fontsize=9)
    a1.set_title('sinh, cosh, tanh')
    fig.tight_layout()
    save(fig, TM, 'trigonometry-01.svg')


def stats_box():
    q1, med, q3, mean = 4.7, 5.6, 9.4, 7.21
    fig, ax = plt.subplots(figsize=(9.2, 2.6))
    ax.add_patch(plt.Rectangle((q1, 0.35), q3 - q1, 0.5, facecolor='#E4F0FB', edgecolor=ACCENT, lw=1.5))
    ax.plot([med, med], [0.35, 0.85], color=NAVY, lw=2.5)
    ax.plot([mean, mean], [0.2, 1.0], color=ORANGE, lw=2, ls='--')
    ax.plot([SX.min(), q1], [0.6, 0.6], color=GREY, lw=1.2)
    ax.plot([q3, SX.max()], [0.6, 0.6], color=GREY, lw=1.2)
    ax.scatter(SX, np.full_like(SX, 0.05) + np.array([0, 0, 0, 0.08, 0, 0, 0, 0, 0, 0]), color=NAVY, s=28, zorder=3)
    for xv, lab, col, yv in [(q1, 'Q1 4.7', ACCENT, 1.02), (med, 'median 5.6', NAVY, 1.18), (q3, 'Q3 9.4', ACCENT, 1.02),
                             (mean, 'mean 7.21', ORANGE, 1.18)]:
        ax.text(xv, yv, lab, ha='center', color=col, fontsize=10, fontweight='bold')
    ax.annotate('', xy=(q1, 0.27), xytext=(q3, 0.27), arrowprops=dict(arrowstyle='<->', color=ACCENT))
    ax.text((q1 + q3) / 2, 0.14, 'IQR 4.7', ha='center', color=ACCENT, fontsize=9.5)
    ax.set_xlim(1.5, 16.5)
    ax.set_ylim(-0.05, 1.35)
    ax.set_yticks([])
    ax.spines['left'].set_visible(False)
    ax.grid(False)
    ax.set_title('X = [2.5, 3.1, 4.7, 4.7, 5.0, 6.2, 8.8, 9.4, 12.1, 15.6]', fontsize=11)
    save(fig, TM, 'descriptive-statistics-01.svg')


def regression():
    a, b = -1.3485, 1.07469
    fig, ax = plt.subplots(figsize=(9.2, 3.6))
    ax.scatter(SX, SY, color=ACCENT, s=40, zorder=3, label='(X, Y)')
    xx = np.linspace(1.5, 16.5, 10)
    ax.plot(xx, a + b * xx, color=NAVY, lw=2, label='lsm(X, Y): y = -1.3485 + 1.07469x')
    ax.text(11, 4, 'corr_coeff(X, Y) = 0.979', color=GREEN, fontsize=10.5, fontweight='bold')
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.legend(loc='upper left', fontsize=9.5)
    save(fig, TM, 'relationships-tests-01.svg')


def taylor_plot():
    from math import factorial
    x = np.linspace(-2, 2.5, 300)
    fig, ax = plt.subplots(figsize=(9.2, 3.6))
    ax.plot(x, np.exp(x), color=NAVY, lw=2.6, label='eˣ')
    for n, col in [(2, PLUM), (3, ORANGE), (4, GREEN), (6, ACCENT)]:
        s = sum(x ** k / factorial(k) for k in range(n))
        ax.plot(x, s, color=col, lw=1.5, ls='--', label=f'{n} terms')
    ax.set_ylim(-1, 10)
    ax.legend(loc='upper left', fontsize=9.5)
    ax.set_title('taylor_series(@f_exp, 0, x, n)')
    save(fig, TM, 'calculus-03.svg')


def vector_projection():
    fig, (a0, a1) = plt.subplots(1, 2, figsize=(9.2, 3.8))
    a, b = np.array([4, 1.0]), np.array([2, 2.0])
    p = a.dot(b) / b.dot(b) * b
    for ax in (a0, a1):
        ax.set_aspect('equal')
        ax.axhline(0, color=LINE, lw=1)
        ax.axvline(0, color=LINE, lw=1)
    def arrow(ax, v, col, lab, off):
        ax.annotate('', xy=v, xytext=(0, 0), arrowprops=dict(arrowstyle='-|>', color=col, lw=2.2))
        ax.text(v[0] + off[0], v[1] + off[1], lab, color=col, fontsize=11, fontweight='bold')
    arrow(a0, a, NAVY, 'a = (4, 1)', (0.1, -0.35))
    arrow(a0, b, ORANGE, 'b = (2, 2)', (-1.9, 0.0))
    arrow(a0, p, GREEN, 'proj(a, b) = (2.5, 2.5)', (0.15, 0.1))
    a0.plot([a[0], p[0]], [a[1], p[1]], color=GREY, ls=':', lw=1.4)
    a0.set_xlim(-0.5, 5)
    a0.set_ylim(-0.6, 3.4)
    a0.set_title('projection')
    v = np.array([3, 4.0])
    arrow(a1, v, NAVY, '(3, 4)', (0.1, 0.1))
    arrow(a1, np.array([-4, 3.0]), GREEN, 'orthogonal: (-4, 3)', (-2.6, 0.35))
    arrow(a1, np.array([-0.8, 0.6]), ORANGE, 'orthonormal', (-1.9, -0.6))
    a1.set_xlim(-5, 4.5)
    a1.set_ylim(-1, 5)
    a1.set_title('a right angle')
    fig.tight_layout()
    save(fig, TM, 'vectors-01.svg')


# ------------------------------------------------------------------ Scientific Library (drawn with SciPy 1.18, which NC matches)
SL = 'Scientific_Library'


def sl_fft():
    fs = 64
    t = np.arange(64) / fs
    x = np.sin(2 * np.pi * 5 * t) + 0.5 * np.sin(2 * np.pi * 12 * t)
    X = np.fft.rfft(x)
    f = np.fft.rfftfreq(64, 1 / fs)
    amp = np.abs(X) * 2 / 64
    fig, (a0, a1) = plt.subplots(2, 1, figsize=(9.2, 5.0))
    a0.plot(t, x, color=NAVY, lw=1.8, marker='o', ms=3)
    a0.set_xlabel('time (s)')
    a0.set_title('x = sin(2π·5t) + 0.5·sin(2π·12t), 64 samples at 64 Hz')
    a1.vlines(f, 0, amp, color=ACCENT, lw=2)
    a1.scatter(f, amp, color=ACCENT, s=14, zorder=3)
    for fk, lab in [(5, '5 Hz, amplitude 1'), (12, '12 Hz, amplitude 0.5')]:
        a1.annotate(lab, xy=(fk, amp[fk]), xytext=(fk + 1.5, amp[fk] + 0.08), color=GREEN, fontsize=10, fontweight='bold')
    a1.set_xlabel('frequency (Hz) = rfftfreq(64, 1/64)')
    a1.set_ylabel('abs(rfft(x)) · 2/64')
    a1.set_ylim(0, 1.25)
    fig.tight_layout()
    save(fig, SL, 'fourier-transforms-01.svg')


def sl_clustering():
    from scipy.cluster.hierarchy import linkage, dendrogram
    P = np.array([[1, 1], [1.2, 0.8], [0.9, 1.1], [5, 5], [5.2, 4.8], [4.9, 5.1]])
    fig, (a0, a1) = plt.subplots(1, 2, figsize=(9.2, 3.6))
    a0.scatter(P[:3, 0], P[:3, 1], color=ACCENT, s=40, label='group 1')
    a0.scatter(P[3:, 0], P[3:, 1], color=ORANGE, s=40, label='group 2')
    c = np.array([[1.033333, 0.966667], [5.033333, 4.966667]])
    a0.scatter(c[:, 0], c[:, 1], color=NAVY, marker='X', s=140, label='centroids (kmeans)')
    a0.set_xlim(0, 6.2)
    a0.set_ylim(0, 6.2)
    a0.set_aspect('equal')
    a0.legend(loc='upper left', fontsize=9)
    a0.set_title('kmeans(P, 2)')
    Z = linkage(P, 'single')
    dendrogram(Z, ax=a1, color_threshold=1, above_threshold_color=GREY, link_color_func=lambda k: NAVY)
    a1.set_title('dendrogram of linkage(P, "single")')
    a1.set_ylabel('join distance')
    fig.tight_layout()
    save(fig, SL, 'clustering-01.svg')


def sl_interp():
    from scipy.interpolate import CubicSpline, PchipInterpolator
    x = np.arange(7)
    y = np.array([0, 0, 0, 1, 1, 1, 1.0])
    xx = np.linspace(0, 6, 300)
    fig, ax = plt.subplots(figsize=(9.2, 3.4))
    ax.plot(xx, np.interp(xx, x, y), color=GREY, lw=1.4, label='linear')
    ax.plot(xx, CubicSpline(x, y)(xx), color=ORANGE, lw=2, label='cubic_spline (overshoots)')
    ax.plot(xx, PchipInterpolator(x, y)(xx), color=NAVY, lw=2, label='pchip (stays within the data)')
    ax.scatter(x, y, color=NAVY, s=40, zorder=3)
    ax.legend(loc='upper left', fontsize=9.5)
    save(fig, SL, 'interpolation-01.svg')


def sl_image():
    from scipy import ndimage as ndi
    img = np.array([[0, 0, 0, 0, 0], [0, 9, 9, 0, 0], [0, 9, 9, 0, 0], [0, 0, 0, 0, 7], [0, 0, 0, 0, 7.0]])
    panels = [(img, 'img', 'Blues'), (ndi.gaussian_filter(img, 1), 'gaussian_filter(img, 1)', 'Blues'),
              (ndi.sobel(img, 0), 'sobel(img, 0)', 'RdBu_r'), (ndi.label(img > 0)[0], 'img_label(img > 0).labels', 'Set2')]
    fig, axes = plt.subplots(1, 4, figsize=(9.6, 2.9))
    for ax, (a, title, cmap) in zip(axes, panels):
        ax.imshow(a, cmap=cmap, interpolation='nearest')
        for (r, cc), v in np.ndenumerate(a):
            ax.text(cc, r, f'{v:.0f}' if title.startswith(('img', 'sobel')) else f'{v:.1f}', ha='center', va='center',
                    fontsize=7.5, color='#1F2328')
        ax.set_title(title, fontsize=10)
        ax.set_xticks([])
        ax.set_yticks([])
        ax.grid(False)
    fig.tight_layout()
    save(fig, SL, 'image-processing-01.svg')


def sl_optim():
    from scipy.optimize import minimize, rosen
    xs = np.linspace(-1.6, 1.6, 300)
    ys = np.linspace(-0.6, 1.6, 300)
    X, Y = np.meshgrid(xs, ys)
    Z = (1 - X) ** 2 + 100 * (Y - X ** 2) ** 2
    path = [np.array([-1.2, 1.0])]
    minimize(rosen, path[0], method='BFGS', callback=lambda xk: path.append(np.array(xk)))
    path = np.array(path)
    fig, ax = plt.subplots(figsize=(9.2, 3.8))
    ax.contour(X, Y, np.log10(Z + 1e-3), levels=18, colors=LINE, linewidths=0.9)
    ax.plot(path[:, 0], path[:, 1], color=ORANGE, marker='o', ms=3, lw=1.5, label='minimize path (BFGS)')
    ax.scatter([1], [1], color=GREEN, s=80, zorder=4, marker='*', label='minimum (1, 1)')
    ax.scatter([-1.2], [1], color=NAVY, s=40, zorder=4, label='start (-1.2, 1)')
    ax.legend(loc='lower right', fontsize=9.5)
    ax.set_title('rosen(x) = (1 - x)² + 100 (y - x²)²')
    ax.grid(False)
    save(fig, SL, 'optimization-01.svg')


def sl_signal():
    from scipy import signal
    fig, (a0, a1) = plt.subplots(2, 1, figsize=(9.2, 5.2))
    for n, col in [(2, GREY), (4, ACCENT), (8, NAVY)]:
        b, a = signal.butter(n, 0.2)
        w, h = signal.freqz(b, a, worN=512)
        a0.plot(w / np.pi, np.abs(h), color=col, lw=2, label=f'order {n}')
    a0.axvline(0.2, color=ORANGE, ls='--', lw=1)
    a0.text(0.21, 0.9, 'cutoff 0.2', color=ORANGE, fontsize=9.5)
    a0.set_xlabel('frequency (fraction of Nyquist)')
    a0.set_ylabel('gain')
    a0.legend(loc='upper right', fontsize=9)
    a0.set_title('butter(n, 0.2, "low"): gain from freqz')
    t = np.linspace(0, 1, 200)
    clean = np.sin(2 * np.pi * 3 * t)
    x = clean + 0.3 * np.sin(2 * np.pi * 40 * t)
    b, a = signal.butter(4, 0.1)
    a1.plot(t, x, color=LINE, lw=1.2, label='signal with ripple')
    a1.plot(t, signal.filtfilt(b, a, x), color=NAVY, lw=2, label='filtfilt(b, a, x)')
    a1.legend(loc='upper right', fontsize=9)
    a1.set_xlabel('t')
    fig.tight_layout()
    save(fig, SL, 'signal-processing-01.svg')


def sl_windows():
    from scipy.signal import windows as W
    n = 64
    fig, ax = plt.subplots(figsize=(9.2, 3.6))
    for w, lab, col in [(W.boxcar(n), 'boxcar', GREY), (W.hann(n), 'hann', NAVY), (W.hamming(n), 'hamming', ACCENT),
                        (W.blackman(n), 'blackman', PLUM), (W.kaiser(n, 8), 'kaiser β=8', ORANGE),
                        (W.tukey(n, 0.5), 'tukey α=0.5', GREEN)]:
        ax.plot(w, color=col, lw=2, label=lab)
    ax.set_xlabel('n')
    ax.set_ylim(-0.05, 1.12)
    ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.18), ncol=6, fontsize=9)
    save(fig, SL, 'window-functions-01.svg')


def sl_graph():
    from scipy.sparse.csgraph import dijkstra
    G = np.array([[0, 4, 1, 0, 0], [4, 0, 2, 5, 0], [1, 2, 0, 8, 10], [0, 5, 8, 0, 2], [0, 0, 10, 2, 0.0]])
    d, pred = dijkstra(G, directed=False, indices=0, return_predecessors=True)
    pos = {0: (0, 1), 1: (1.4, 1.8), 2: (1.4, 0.2), 3: (2.9, 1.6), 4: (3.6, 0.3)}
    path, k = [], 4
    while k != 0:
        path.append((pred[k], k))
        k = pred[k]
    on = {tuple(sorted(e)) for e in path}
    fig, ax = plt.subplots(figsize=(9.2, 3.6))
    for i in range(5):
        for j in range(i + 1, 5):
            if G[i, j]:
                hot = (i, j) in on
                ax.plot(*zip(pos[i], pos[j]), color=ORANGE if hot else LINE, lw=3.5 if hot else 1.6, zorder=1)
                mx, my = (pos[i][0] + pos[j][0]) / 2, (pos[i][1] + pos[j][1]) / 2
                ax.text(mx, my + 0.07, f'{G[i, j]:.0f}', color=GREY, fontsize=10, ha='center')
    for i, (x, y) in pos.items():
        ax.scatter([x], [y], s=520, color=NAVY if i in (0, 4) else ACCENT, zorder=3)
        ax.text(x, y, str(i), color='white', ha='center', va='center', fontweight='bold', zorder=4)
        ax.text(x, y - 0.27, f'dist {d[i]:.0f}', color=GREEN, ha='center', fontsize=9.5)
    ax.set_title('dijkstra(G, 0): shortest distances; the path 0 → 2 → 1 → 3 → 4 (length 10) in orange')
    ax.axis('off')
    ax.set_xlim(-0.4, 4.0)
    ax.set_ylim(-0.2, 2.2)
    save(fig, SL, 'sparse-graphs-01.svg')


def sl_spatial():
    from scipy.spatial import Delaunay, ConvexHull
    rng = np.random.default_rng(3)
    P = rng.uniform(0, 10, (10, 2))
    tri = Delaunay(P)
    hull = ConvexHull(P)
    fig, ax = plt.subplots(figsize=(9.2, 3.8))
    ax.triplot(P[:, 0], P[:, 1], tri.simplices, color=LINE, lw=1.2)
    v = list(hull.vertices) + [hull.vertices[0]]
    ax.plot(P[v, 0], P[v, 1], color=NAVY, lw=2.4, label='convex_hull')
    ax.plot([], [], color=LINE, lw=1.2, label='delaunay triangles')
    ax.scatter(P[:, 0], P[:, 1], color=ORANGE, s=40, zorder=3)
    ax.set_aspect('equal')
    ax.legend(loc='upper left', bbox_to_anchor=(1.02, 1.0), fontsize=9.5)
    ax.grid(False)
    save(fig, SL, 'spatial-01.svg')


def sl_special():
    from scipy.special import jv, gamma
    fig, (a0, a1) = plt.subplots(1, 2, figsize=(9.6, 3.6))
    x = np.linspace(0, 15, 400)
    for n, col in [(0, NAVY), (1, ORANGE), (2, GREEN)]:
        a0.plot(x, jv(n, x), color=col, lw=2, label=f'jv({n}, x)')
    a0.axhline(0, color=LINE, lw=1)
    a0.legend(loc='upper right', fontsize=9)
    a0.set_title('Bessel functions J0, J1, J2')
    g = np.linspace(0.15, 5.2, 400)
    a1.plot(g, gamma(g), color=NAVY, lw=2, label='gamma(x)')
    k = np.arange(1, 6)
    a1.scatter(k, gamma(k), color=ORANGE, s=40, zorder=3, label='(n - 1)!')
    for kk in k:
        a1.text(kk, gamma(kk) + 1.2, f'{gamma(kk):.0f}', ha='center', color=ORANGE, fontsize=9.5)
    a1.set_ylim(0, 30)
    a1.legend(loc='upper left', fontsize=9)
    a1.set_title('gamma extends the factorial')
    fig.tight_layout()
    save(fig, SL, 'special-functions-01.svg')


def sl_distributions():
    from scipy.stats import norm
    x = np.linspace(-4, 4, 400)
    q = norm.ppf(0.95)
    fig, (a0, a1) = plt.subplots(1, 2, figsize=(9.6, 3.6))
    a0.plot(x, norm.pdf(x), color=NAVY, lw=2, label='norm_pdf(x)')
    xs = x[x <= q]
    a0.fill_between(xs, norm.pdf(xs), color=ACCENT, alpha=0.25, label='area = norm_cdf(1.645) = 0.95')
    a0.axvline(q, color=ORANGE, ls='--', lw=1.2)
    a0.legend(loc='upper left', fontsize=8.8)
    a0.set_title('density')
    a1.plot(x, norm.cdf(x), color=NAVY, lw=2, label='norm_cdf(x)')
    a1.plot([-4, q], [0.95, 0.95], color=ORANGE, ls='--', lw=1.2)
    a1.plot([q, q], [0, 0.95], color=ORANGE, ls='--', lw=1.2)
    a1.text(q + 0.15, 0.45, 'norm_ppf(0.95)\n= 1.645', color=ORANGE, fontsize=9.5)
    a1.legend(loc='upper left', fontsize=9)
    a1.set_title('cumulative probability')
    fig.tight_layout()
    save(fig, SL, 'distributions-01.svg')


# ------------------------------------------------------------------ Engineering Mathematics
EM = 'Engineering_Math'


def em_helix():
    t = np.linspace(0, 2 * np.pi, 300)
    fig = plt.figure(figsize=(9.2, 4.2))
    ax = fig.add_subplot(111, projection='3d')
    ax.plot(np.cos(t), np.sin(t), t, color=NAVY, lw=2)
    for tk in (0.6, 2.6, 4.6):
        p = np.array([np.cos(tk), np.sin(tk), tk])
        T = np.array([-np.sin(tk), np.cos(tk), 1]) / np.sqrt(2)
        N = np.array([-np.cos(tk), -np.sin(tk), 0])
        B = np.cross(T, N)
        for v, col, lab in ((T, ACCENT, 'T'), (N, ORANGE, 'N'), (B, GREEN, 'B')):
            ax.quiver(*p, *(0.7 * v), color=col, lw=2, arrow_length_ratio=0.25)
            if tk == 0.6:
                ax.text(*(p + 0.85 * v), lab, color=col, fontweight='bold')
    ax.set_xlabel('x')
    ax.set_ylabel('y')
    ax.set_zlabel('z')
    ax.set_title('helix r(t) = [cos t, sin t, t]: κ = τ = 1/2')
    ax.view_init(elev=18, azim=-60)
    save(fig, EM, 'vector-calculus-01.svg')


def em_direction_field():
    xg = np.linspace(-2, 2, 17)
    yg = np.linspace(-2, 2, 17)
    X, Y = np.meshgrid(xg, yg)
    S = X - Y
    U, V = 1 / np.sqrt(1 + S ** 2), S / np.sqrt(1 + S ** 2)
    fig, ax = plt.subplots(figsize=(9.2, 4.0))
    ax.quiver(X, Y, U, V, color=GREY, angles='xy', scale=30, width=0.003, headwidth=0, headlength=0, pivot='mid')
    x = np.linspace(-2, 2, 200)
    for c, col in [(-2, ACCENT), (0.5, ORANGE), (3, GREEN)]:          # y = x - 1 + C e^{-x}
        y = x - 1 + c * np.exp(-x - 2) * np.exp(2)
        ax.plot(x, np.clip(y, -3, 3), color=col, lw=2)
    ax.plot(x, x - 1, color=NAVY, lw=1.5, ls='--', label='y = x - 1')
    ax.set_xlim(-2, 2)
    ax.set_ylim(-2, 2)
    ax.legend(loc='upper left', fontsize=9.5)
    ax.set_title("direction_field of y' = x - y, with three solutions")
    save(fig, EM, 'ode-analysis-01.svg')


def em_resonance():
    w = np.linspace(0, 4, 400)
    fig, ax = plt.subplots(figsize=(9.2, 3.6))
    for c, col in [(0.25, NAVY), (0.5, ACCENT), (1.0, ORANGE)]:
        amp = 1 / np.sqrt((4 - w ** 2) ** 2 + (c * w) ** 2)
        ax.plot(w, amp, color=col, lw=2, label=f'c = {c}')
        wp = np.sqrt(4 - c ** 2 / 2)
        ax.scatter([wp], [1 / np.sqrt((4 - wp ** 2) ** 2 + (c * wp) ** 2)], color=col, s=25, zorder=3)
    ax.set_xlabel('ω')
    ax.set_ylabel('amplitude C(ω)')
    ax.set_ylim(0, 2.2)
    ax.legend(loc='upper right', fontsize=9.5)
    ax.set_title("resonance_peak: y'' + c y' + 4 y = cos ωt")
    save(fig, EM, 'ode-analysis-02.svg')


def em_pendulum():
    x1 = np.linspace(-2.2 * np.pi, 2.2 * np.pi, 400)
    x2 = np.linspace(-3, 3, 300)
    X1, X2 = np.meshgrid(x1, x2)
    E = 0.5 * X2 ** 2 - np.cos(X1)
    fig, ax = plt.subplots(figsize=(9.2, 3.8))
    ax.contour(X1, X2, E, levels=np.linspace(-0.95, 3, 14), colors=ACCENT, linewidths=1)
    ax.contour(X1, X2, E, levels=[1], colors=ORANGE, linewidths=2)
    ax.scatter([-2 * np.pi, 0, 2 * np.pi], [0, 0, 0], color=GREEN, s=50, zorder=3, label='centers')
    ax.scatter([-np.pi, np.pi], [0, 0], color=PLUM, marker='X', s=70, zorder=3, label='saddles')
    ax.set_xticks([-2 * np.pi, -np.pi, 0, np.pi, 2 * np.pi])
    ax.set_xticklabels(['-2π', '-π', '0', 'π', '2π'])
    ax.set_xlabel('x1 (angle)')
    ax.set_ylabel('x2 (angular velocity)')
    ax.legend(loc='upper right', fontsize=9)
    ax.set_title("phase plane of x1' = x2, x2' = -sin x1 (orange: the separatrix)")
    ax.grid(False)
    save(fig, EM, 'ode-analysis-03.svg')


def em_gibbs():
    x = np.linspace(-np.pi, np.pi, 2000)
    sq = np.sign(x)
    fig, ax = plt.subplots(figsize=(9.2, 3.6))
    ax.plot(x, sq, color=GREY, lw=1.5, label='square wave')
    for N, col in [(1, ORANGE), (3, ACCENT), (15, NAVY)]:
        s = sum(4 / (np.pi * n) * np.sin(n * x) for n in range(1, 2 * N, 2))
        ax.plot(x, s, color=col, lw=1.8, label=f'{N} term{"s" if N > 1 else ""}')
    ax.axhline(1.0895, color=PLUM, ls=':', lw=1)
    ax.text(1.9, 1.13, 'overshoot ≈ 9 %', color=PLUM, fontsize=9.5)
    ax.set_xticks([-np.pi, 0, np.pi])
    ax.set_xticklabels(['-π', '0', 'π'])
    ax.set_ylim(-1.5, 1.5)
    ax.legend(loc='lower right', fontsize=9, ncol=2)
    ax.set_title('fourier_coeffs_real(@square, 2π, N): partial sums')
    save(fig, EM, 'fourier-series-01.svg')


def em_pde():
    x = np.linspace(0, 1, 200)
    fig, (a0, a1) = plt.subplots(1, 2, figsize=(9.6, 3.6))
    for k, t in enumerate([0, 0.1, 0.2, 0.25, 0.4, 0.5]):
        a0.plot(x, np.sin(np.pi * x) * np.cos(2 * np.pi * t), color=plt.cm.Blues(0.35 + 0.1 * k), lw=2, label=f't = {t}')
    a0.set_title('wave: u = sin πx · cos 2πt (c = 2)')
    a0.legend(fontsize=8, loc='lower left', ncol=2)
    for k, t in enumerate([0, 0.02, 0.05, 0.1, 0.2, 0.4]):
        a1.plot(x, np.sin(np.pi * x) * np.exp(-np.pi ** 2 * t), color=plt.cm.Oranges(0.35 + 0.1 * k), lw=2, label=f't = {t}')
    a1.set_title('heat: u = sin πx · exp(-π² t)')
    a1.legend(fontsize=8, loc='upper right')
    for a in (a0, a1):
        a.set_xlabel('x')
        a.set_ylim(-1.1, 1.1)
    fig.tight_layout()
    save(fig, EM, 'pdes-01.svg')


def em_contour():
    th = np.linspace(0, 2 * np.pi, 300)
    fig, ax = plt.subplots(figsize=(9.2, 3.8))
    ax.plot(np.cos(th), np.sin(th), color=NAVY, lw=2.2)
    for a in (0.3, 1.9, 3.5, 5.1):
        ax.annotate('', xy=(np.cos(a + 0.15), np.sin(a + 0.15)), xytext=(np.cos(a), np.sin(a)),
                    arrowprops=dict(arrowstyle='-|>', color=NAVY, lw=2))
    ax.scatter([0], [0], color=GREY, s=20)
    ax.text(0.04, -0.12, '0', color=GREY)
    ax.scatter([0.35], [0.25], color=ORANGE, s=60, zorder=3)
    ax.text(0.42, 0.28, 'z0', color=ORANGE, fontsize=12, fontweight='bold')
    ax.axhline(0, color=LINE, lw=1)
    ax.axvline(0, color=LINE, lw=1)
    ax.text(1.45, 0.75, 'closed integral of dz / z = 2πi', color=NAVY, fontsize=12)
    ax.text(1.45, 0.35, 'f(z0) = 1/(2πi) × closed integral of f(z)/(z - z0) dz', color=ORANGE, fontsize=11)
    ax.text(1.45, -0.05, 'C: generate_contour("circle", [0, 1])', color=GREY, fontsize=10.5)
    ax.set_xlim(-1.4, 6.4)
    ax.set_ylim(-1.3, 1.3)
    ax.set_aspect('equal')
    ax.set_xlabel('Re z')
    ax.set_ylabel('Im z')
    ax.grid(False)
    save(fig, EM, 'complex-functions-01.svg')


def em_conformal():
    fig, (a0, a1) = plt.subplots(1, 2, figsize=(9.6, 3.8))
    s = np.linspace(0.2, 1.6, 8)
    u = np.linspace(0.2, 1.6, 200)
    for c in s:
        a0.plot([c] * 2, [0.2, 1.6], color=ACCENT, lw=1.2)
        a0.plot([0.2, 1.6], [c] * 2, color=ORANGE, lw=1.2)
        w1 = (c + 1j * u) ** 2
        w2 = (u + 1j * c) ** 2
        a1.plot(w1.real, w1.imag, color=ACCENT, lw=1.2)
        a1.plot(w2.real, w2.imag, color=ORANGE, lw=1.2)
    a0.set_title('z-plane')
    a1.set_title('w = z²: lines become parabolas, still at right angles')
    for a in (a0, a1):
        a.set_aspect('equal')
        a.grid(False)
    save(fig, EM, 'residues-conformal-01.svg')


def em_cylinder():
    x = np.linspace(-3, 3, 400)
    y = np.linspace(-2, 2, 300)
    X, Y = np.meshgrid(x, y)
    Z = X + 1j * Y
    psi = (Z + 1 / Z).imag
    psi[np.abs(Z) < 1] = np.nan
    fig, ax = plt.subplots(figsize=(9.2, 3.6))
    ax.contour(X, Y, psi, levels=np.linspace(-2, 2, 21), colors=NAVY, linewidths=1, linestyles='solid')
    ax.add_patch(plt.Circle((0, 0), 1, color='#E4F0FB', ec=ACCENT, lw=2))
    ax.set_aspect('equal')
    ax.set_title('streamlines of F(z) = z + 1/z: flow round a cylinder')
    ax.grid(False)
    save(fig, EM, 'residues-conformal-02.svg')


def em_control_chart():
    D = np.array([[10.1, 9.8, 10.0, 10.3], [9.9, 10.2, 10.1, 9.7], [10.0, 10.4, 9.9, 10.1], [9.6, 10.0, 10.2, 10.0],
                  [10.2, 9.9, 10.1, 10.0]])
    m = D.mean(axis=1)
    cl, ucl, lcl = 10.025, 10.3747, 9.6753
    fig, ax = plt.subplots(figsize=(9.2, 3.4))
    ax.plot(range(1, 6), m, color=NAVY, marker='o', lw=2, label='sample means')
    for v, lab, col in [(ucl, 'UCL 10.375', PLUM), (cl, 'CL 10.025', GREEN), (lcl, 'LCL 9.675', PLUM)]:
        ax.axhline(v, color=col, ls='--' if v != cl else '-', lw=1.4)
        ax.text(5.15, v, lab, color=col, va='center', fontsize=9.5)
    ax.set_xlim(0.7, 5.9)
    ax.set_xticks(range(1, 6))
    ax.set_xlabel('sample')
    ax.set_title('control_chart_limits(D, "x_bar")')
    save(fig, EM, 'probability-quality-01.svg')


def em_oc():
    p = np.linspace(0, 0.5, 200)
    fig, ax = plt.subplots(figsize=(9.2, 3.4))
    for n, col in [(5, ORANGE), (10, ACCENT), (20, NAVY)]:
        ax.plot(p, (1 - p) ** n, color=col, lw=2, label=f'n = {n}, c = 0')
    ax.set_xlabel('defect fraction p')
    ax.set_ylabel('P(accept)')
    ax.legend(loc='upper right', fontsize=9.5)
    ax.set_title('operating_characteristic_curve(0, n, 0, p) (a very large lot)')
    save(fig, EM, 'probability-quality-02.svg')


def main():
    for f in (em_helix, em_direction_field, em_resonance, em_pendulum, em_gibbs, em_pde, em_contour, em_conformal,
              em_cylinder, em_control_chart, em_oc):
        f()
    for f in (sl_fft, sl_clustering, sl_interp, sl_image, sl_optim, sl_signal, sl_windows, sl_graph, sl_spatial,
              sl_special, sl_distributions):
        f()
    trig_curves()
    stats_box()
    regression()
    taylor_plot()
    vector_projection()
    distributions()
    fill_methods()
    histogram_plot()
    trapz_interp()
    tolerance_band()
    rounding_steps()
    anglewrap_plot()
    float_spacing()
    svd_ellipse()
    lstsq_fit()
    polynomial_plot()


if __name__ == '__main__':
    main()
