"""Language Guide - Errors & Exceptions section (source: Function_Test/Code/A_09_Assertions/Exception_Handling,
eh_01 to eh_17: try, except, success, always, escalate, because, assert and the built-in error types).

The functions of A_09 (warn, trace, inspect_fail and the assert_* checks) are in the Default Functions chapter,
domain "Assertions & Exceptions" (df_assertions.py).

Merged into lg_content.PAGES at the end of lg_content.py.
"""
from lg_content import comp, err, ex, fig

IMG = 'Images/Neural_Code/Language_Guide/Errors_Exceptions/'
DF = '../../Default_Functions/Assertions/'
PAGES = {}

TYPES = ('Exception, ValueError, TypeError, KeyError, IndexError, AttributeError, MissingResourceError, '
         'NotImplemented, RuntimeError, AssertionError, UserWarning, LegacyWarning')

# ================================================================== 1. try and except
PAGES['try-except'] = {
    'title': 'Try & Except',
    'summary': 'Run statements that might fail and handle the error yourself, instead of letting it stop the '
               'script: <code>try</code> &hellip; <code>except</code> &hellip; <code>tend</code>.',
    'about': [
        comp('try … except … tend', [
            '<code>try:</code> runs the block below it. If a statement in the block fails, the rest of the block '
            'is skipped and the first <code>except</code> block that fits the error runs. The script then carries '
            'on after <code>tend</code>, the word that closes the whole block.',
            'Without a <code>try</code>, the same error stops the script: NC prints '
            '<code>Error: IndexError: &hellip;</code> and the line it stopped on.'],
            table=[['NC', 'Python', 'MATLAB'],
                   ['<code>try</code>', '<code>try</code>', '<code>try</code>'],
                   ['<code>except</code>', '<code>except</code>', '<code>catch</code>'],
                   ['<code>success</code>', '<code>else</code>', '&mdash;'],
                   ['<code>always</code>', '<code>finally</code>', '<code>onCleanup</code>'],
                   ['<code>escalate</code>', '<code>raise</code>', '<code>error</code> / <code>throw</code>'],
                   ['<code>escalate &hellip; because</code>', '<code>raise &hellip; from</code>', '<code>addCause</code>'],
                   ['<code>tend</code>', '(indentation)', '<code>end</code>']],
            figure=fig(IMG + 'try-except-01.svg',
                       'Flow of a try block. The body runs. With no error, success runs, then always. With an error, '
                       'the first fitting except block runs, then always. With an error no except block fits, always '
                       'runs and the error goes on to the enclosing try block or stops the script.',
                       'The path through a try block. <code>success</code> and <code>always</code> are optional; '
                       'they are on the next page.'),
            syntax='try:\n   <statements>\nexcept <Type> as <name>:\n   <statements>\ntend'),
        comp('except blocks', [
            'An <code>except</code> block names the kinds of error it handles. A try block may have several; NC '
            'checks them from the top, and the <em>first</em> one that fits runs, even when a later one fits '
            'better. <code>except Exception</code> and a bare <code>except:</code> handle every error, so put '
            'them last; a bare <code>except:</code> must be the last block.'],
            table=[['Form', 'Handles'],
                   ['<code>except ValueError:</code>', 'errors of that type'],
                   ['<code>except ValueError as err:</code>', 'the same, and gives the error the name <code>err</code>'],
                   ['<code>except TypeError, KeyError as err:</code>', 'any of the types in the list'],
                   ['<code>except as err:</code>', 'every error, with a name'],
                   ['<code>except:</code>', 'every error (must be the last block)']],
            syntax='try:\n   v = settings["gain"];\nexcept KeyError as err:\n   v = 1;\nexcept TypeError, ValueError:\n   v = 0;\ntend'),
        comp('The error value', [
            'The name after <code>as</code> holds the error as a dictionary with four fields. When the error was '
            'an object of your own class, a fifth field, <code>value</code>, holds the object '
            '(see <a href="escalate-because.html">Escalate &amp; Because</a>).'],
            table=[['Field', 'What it holds'],
                   ['<code>err.type</code>', 'the kind of error, as text: <code>"IndexError"</code>'],
                   ['<code>err.message</code>', 'what went wrong'],
                   ['<code>err.line</code>', 'the line the error happened on'],
                   ['<code>err.cause</code>', 'the error it was raised <code>because</code> of, or <code>{}</code>']],
            syntax='except IndexError as err:\n   publish(err.type, "on line", err.line);\n   publish(err.message);'),
        comp('Where an error goes', [
            'An error is handled by the <em>nearest</em> try block around it. An error inside a function you call '
            'reaches the try block of the caller. When no except block of a try fits, the error goes on outwards '
            'to the next try block, and if there is none, it stops the script as usual. An error raised inside an '
            'except block is a new error: the try blocks further out see it.'],
            figure=fig(IMG + 'try-except-02.svg',
                       'Three nested boxes: the script, an outer try block that handles IndexError, and an inner try '
                       'block that handles KeyError. An IndexError raised in the inner body does not fit KeyError, so '
                       'it passes out to the outer try, whose except IndexError block handles it.',
                       'An error travels outwards until an <code>except</code> block fits it.')),
        comp('Loops and functions', [
            '<code>break</code> and <code>continue</code> inside a try block inside a loop work as usual, and '
            '<code>return</code> inside a try block leaves the function. A try block inside a loop is the usual way '
            'to keep a loop going past one bad item.'],
            syntax='for k = [0:9]:\n   try:\n      total = total + v[k];\n   except IndexError:\n      break;\n   tend\nfend'),
        comp('Context words', [
            '<code>try</code>, <code>except</code>, <code>success</code>, <code>always</code>, <code>tend</code> and '
            '<code>because</code> are <em>context words</em>, not reserved words: a variable may still be called '
            '<code>try</code> or <code>tend</code> (an end time, for example). <code>tend</code> closes a try block '
            'only when it stands alone on its line.'],
            syntax='tstart = 0;\ntend = 9.5;\nduration = tend - tstart;'),
        comp('Division by zero is not an error', [
            'NC follows IEEE 754 arithmetic, as MATLAB and NumPy do: <code>1 / 0</code> is <code>inf</code>, '
            '<code>-1 / 0</code> is <code>-inf</code> and <code>0 / 0</code> is <code>nan</code>. There is no '
            '<code>ZeroDivisionError</code>; test the divisor, or the result with <code>is_nan</code>, when it '
            'matters.'],
            syntax='publish(1 / 0, -1 / 0, 0 / 0);'),
    ],
    'examples': {
        'basic': ex('An index past the end', 'The third line of the body fails, so the fourth never runs. The except '
                    'block reports the error and the script goes on.', '''
v = [10, 20, 30];
reached = false;
try:
   w = v[7];
   reached = true;
except IndexError as err:
   publish("handled:", err.type, "on line", err.line);
   publish(err.message);
tend
publish("line after the error ran:", reached);
publish("the script carries on");
'''),
        'mid': ex('A lookup with a fallback', 'A function that reads a setting and falls back to a default when the '
                  'key is missing. The second part shows that the first fitting except block wins.', '''
function v = get_or(d, key, fallback):
   try:
      v = d[key];
   except KeyError:
      v = fallback;
   tend
fnend

settings = dict();
settings["rate"] = 50;
publish("rate:", get_or(settings, "rate", 10));
publish("gain:", get_or(settings, "gain", 1));

try:
   escalate ValueError("x");
except Exception:
   publish("except Exception ran first");
except ValueError:
   publish("except ValueError never runs here");
tend
'''),
        'strong': ex('Keep a batch going past bad records', 'Each record is converted inside its own try block. '
                     'Errors are counted by type with <code>err.type</code>; the good values are kept.', '''
records = dict();
records["a"] = "12.5";
records["b"] = "oops";
records["c"] = "7";
records["e"] = "-3";
wanted = ["a", "b", "c", "d", "e"];

good = [];
errors = dict();
for k = [0:4]:
   key = wanted[k];
   try:
      x = float64(records[key]);
      good ,= x;
   except KeyError, ValueError as err:
      if err.type in errors:
         errors[err.type] = errors[err.type] + 1;
      else:
         errors[err.type] = 1;
      iend
      publish("record", key, "skipped:", err.message);
   tend
fend
publish("kept:", good, " sum:", sum(good));
publish("errors by type:", errors);
'''),
    },
    'errors': [
        err('A try block without tend', 'Every try block ends with <code>tend</code> on a line of its own, after the '
            'last except (or success, or always) block.', '''
try:
   x = 1;
except:
   x = 2;
publish(x);''', '''
try:
   x = 1;
except:
   x = 2;
tend
publish(x);'''),
        err('catch instead of except', 'MATLAB writes <code>catch</code>; NC writes <code>except</code>.', '''
v = [1, 2];
try:
   x = v[5];
catch:
   x = 0;
tend''', '''
v = [1, 2];
try:
   x = v[5];
except:
   x = 0;
tend
publish(x);'''),
        err('A bare except before others', 'A bare <code>except:</code> handles everything, so any block after it '
            'could never run. NC refuses the script before running it.', '''
v = [1];
try:
   x = v[3];
except:
   x = 0;
except IndexError:
   x = 1;
tend''', '''
v = [1];
try:
   x = v[3];
except IndexError:
   x = 1;
except:
   x = 0;
tend
publish(x);'''),
        err('The name without as', 'The error is named with <code>as</code>, as in Python.', '''
try:
   escalate ValueError("bad");
except ValueError err:
   publish(err.message);
tend''', '''
try:
   escalate ValueError("bad");
except ValueError as err:
   publish(err.message);
tend'''),
        err('try with nothing to handle the error', 'A try block needs at least one except block (or an always '
            'block, see the next page).', '''
try:
   x = 1;
tend''', '''
try:
   x = 1;
except:
   x = 0;
tend
publish(x);'''),
        err('An error type that does not exist', 'There is no <code>ZeroDivisionError</code> in NC (division by '
            'zero gives inf or nan). NC lists the types it knows.', '''
try:
   r = 1 / 0;
except ZeroDivisionError:
   r = 0;
tend''', '''
r = 1 / 0;
if is_inf(r):
   r = 0;
iend
publish(r);'''),
    ],
}

# ================================================================== 2. success and always
PAGES['success-always'] = {
    'title': 'Success & Always',
    'summary': 'Two optional blocks of a try: <code>success</code> runs only when nothing failed, '
               '<code>always</code> runs every time, to tidy up.',
    'about': [
        comp('success:', [
            'The <code>success</code> block runs only when the try body finished <em>without</em> an error. It is '
            'Python\'s <code>else</code>. Code placed there is not protected by the except blocks of the same try, '
            'so an error in it is never mistaken for an error of the body: it goes on to the try blocks further '
            'out.',
            '<code>success</code> comes after the except blocks and needs at least one of them. It does not run '
            'when the body left with <code>break</code>, <code>continue</code> or <code>return</code>.'],
            syntax='try:\n   x = read_value();\nexcept ValueError:\n   x = 0;\nsuccess:\n   publish("read", x);\ntend'),
        comp('always:', [
            'The <code>always</code> block runs last, every time: after a body that succeeded, after an except '
            'block, and even when the error was not handled. In that last case the error goes on <em>after</em> '
            'the always block has run. Use it to tidy up: reset a setting, close a file, write a log line.',
            'A try may have an always block and no except block at all. A <code>break</code>, <code>continue</code> '
            'or <code>return</code> in the body waits for the always block, then happens.'],
            syntax='set_threads(1);\ntry:\n   result = long_job();\nalways:\n   set_threads(0);\ntend'),
        comp('Which blocks run', ['The four ways a try body can end, and the blocks that run for each:'],
            table=[['The body &hellip;', 'except', 'success', 'always', 'then'],
                   ['finishes with no error', '&mdash;', 'runs', 'runs', 'the line after <code>tend</code>'],
                   ['fails, an except block fits', 'the first that fits', '&mdash;', 'runs', 'the line after <code>tend</code>'],
                   ['fails, no except block fits', '&mdash;', '&mdash;', 'runs', 'the error goes outwards'],
                   ['leaves with break / continue / return', '&mdash;', '&mdash;', 'runs', 'the break, continue or return']]),
        comp('Order of the blocks', [
            'The blocks always come in this order; each one is optional except that there must be at least one '
            'except or always block, and success needs an except block before it.'],
            syntax='try:\n   ...\nexcept ValueError as err:\n   ...\nexcept:\n   ...\nsuccess:\n   ...\nalways:\n   ...\ntend'),
    ],
    'examples': {
        'basic': ex('success runs only after a clean body', 'The same block, once with a good index and once with a '
                    'bad one.', '''
v = [4, 8, 15];
for i = [1, 9]:
   try:
      x = v[i];
   except IndexError:
      publish("index", i, ": no such element");
   success:
      publish("index", i, ": read", x);
   always:
      publish("index", i, ": done");
   tend
fend
'''),
        'mid': ex('always runs before an error moves on', 'The inner try cannot handle a KeyError. Its always block '
                  'still runs first, then the outer try handles the error.', '''
log = "";
try:
   try:
      escalate KeyError("no key 'gain'");
   except ValueError:
      log = log + "inner except, ";
   always:
      log = log + "inner always, ";
   tend
except KeyError as err:
   log = log + "outer except (" + err.message + ")";
tend
publish(log);
'''),
        'strong': ex('Reset a setting whatever happens', 'A function lowers the thread count for one job and puts it '
                     'back in <code>always</code>: after a result, after an error, and even when '
                     '<code>return</code> leaves early.', '''
function r = one_thread_job(x):
   set_threads(1);
   try:
      if x == 0:
         r = 0;
         return;
      iend
      if x < 0:
         escalate ValueError("x must be >= 0");
      iend
      r = sqrt(x);
   always:
      set_threads(0);
      publish("   threads back to", get_threads());
   tend
fnend

publish("result:", one_thread_job(16));
publish("result:", one_thread_job(0));
try:
   r = one_thread_job(-1);
except ValueError as err:
   publish("handled:", err.message);
tend
'''),
    },
    'errors': [
        err('success with no except block', '<code>success</code> means "no except block ran", so it needs one '
            'before it.', '''
try:
   x = 1;
success:
   x = 2;
tend''', '''
try:
   x = 1;
except:
   x = 0;
success:
   x = 2;
tend
publish(x);'''),
        err('except after always', 'The blocks have a fixed order: except blocks, then success, then always.', '''
try:
   x = 1;
always:
   x = 2;
except:
   x = 3;
tend''', '''
try:
   x = 1;
except:
   x = 3;
always:
   x = 2;
tend
publish(x);'''),
        err('finally instead of always', 'Python writes <code>finally</code>; NC writes <code>always</code>.', '''
try:
   x = 1;
except:
   x = 2;
finally:
   x = 3;
tend''', '''
try:
   x = 1;
except:
   x = 2;
always:
   x = 3;
tend
publish(x);'''),
    ],
}

# ================================================================== 3. escalate and because
PAGES['escalate-because'] = {
    'title': 'Escalate & Because',
    'summary': 'Raise an error on purpose with <code>escalate</code>, and keep the original error as its cause '
               'with <code>because</code>.',
    'about': [
        comp('escalate', [
            '<code>escalate</code> raises an error on purpose. Unless a try block handles it, the script stops with '
            'the usual message, for example <code>Error: ValueError: x must be positive</code>. It is Python\'s '
            '<code>raise</code> and MATLAB\'s <code>error</code>.'],
            table=[['Form', 'Raises'],
                   ['<code>escalate ValueError("message");</code>', 'an error of that type, with a message'],
                   ['<code>escalate ValueError;</code>', 'the type with an empty message'],
                   ['<code>escalate "message";</code>', 'an <code>Exception</code> with that message'],
                   ['<code>escalate err;</code>', 'an error value kept earlier (from <code>as err</code> or <code>ValueError("&hellip;")</code>)'],
                   ['<code>escalate obj;</code>', 'an object of your class: the class is the type, its <code>message</code> field the message'],
                   ['<code>escalate;</code>', 'inside an except block: the error being handled, again'],
                   ['<code>escalate X because err;</code>', 'X, with <code>err</code> kept as its cause']],
            syntax='function a = circle_area(r):\n   if r < 0:\n      escalate ValueError("radius must be >= 0");\n   iend\n   a = pi * r ^ 2;\nfnend'),
        comp('Raising the same error again', [
            'A bare <code>escalate;</code> inside an except block passes the error being handled on, unchanged: '
            'useful to note something and let the caller decide. Outside an except block there is nothing to '
            'raise again, and it is an error.'],
            syntax='except KeyError as err:\n   publish("lookup failed:", err.message);\n   escalate;'),
        comp('Your own error classes', [
            'Any object can be raised. Its class name becomes the error type, so <code>except BadReading</code> '
            'handles it, and its <code>message</code> field becomes the message. The object itself is in '
            '<code>err.value</code>, with all its fields.'],
            syntax='class BadReading():\n   function base(sensor):\n      base.sensor = sensor;\n      base.message = "sensor " + sensor + " gave no data";\n   fnend\ncsend\n\nescalate BadReading("T1");'),
        comp('because: keeping the cause', [
            '<code>escalate X because err;</code> raises a new error and keeps the original one inside it, so a '
            'reader sees both the high-level problem and what actually went wrong. It is Python\'s '
            '<code>raise &hellip; from</code>. The cause is in <code>err.cause</code>; a cause may have its own '
            'cause, so the errors form a chain. Without <code>because</code>, <code>err.cause</code> is an empty '
            'dictionary.',
            'When a chained error is not handled, NC prints the whole chain, newest first:'],
            figure=fig(IMG + 'escalate-because-01.svg',
                       'Three error cards linked by because arrows: RuntimeError "could not start the run" on line '
                       '15, caused by ValueError "settings file is incomplete" on line 8, caused by KeyError "dict '
                       'key gain not found" on line 2. Below, the printed report lists them in the same order with '
                       '"caused by" lines.',
                       'The chain built by the strong example below. Each <code>because</code> adds one link; '
                       '<code>err.cause.cause</code> walks back along it.'),
            syntax='Error: RuntimeError: could not load the settings (line 5)\n'
                   '  caused by: KeyError: dict key \'gain\' not found in \'settings\' (line 3)'),
    ],
    'examples': {
        'basic': ex('Refuse a bad input', 'A function escalates a ValueError for a negative radius; the caller handles '
                    'it. The second call shows <code>escalate "text"</code>.', '''
function a = circle_area(r):
   if r < 0:
      escalate ValueError("radius must be >= 0, got " + str(r));
   iend
   a = pi * r ^ 2;
fnend

publish(round(circle_area(2), decimals=4));
try:
   a = circle_area(-2);
except ValueError as err:
   publish(err.type, ":", err.message);
tend
try:
   escalate "something failed";
except Exception as err:
   publish(err.type, ":", err.message);
tend
'''),
        'mid': ex('Note it, then pass it on', 'The inner except block writes a log line and raises the same error again '
                  'with a bare <code>escalate;</code>. An object of the script\'s own class is raised and handled by '
                  'its class name.', '''
class BadReading():
   function base(sensor):
      base.sensor = sensor;
      base.message = "sensor " + sensor + " gave no data";
   fnend
csend

try:
   try:
      escalate BadReading("T1");
   except BadReading as err:
      publish("log:", err.message);
      escalate;
   tend
except BadReading as err:
   publish("type:", err.type, "  sensor:", err.value.sensor);
tend
'''),
        'strong': ex('A chain of causes', 'Three levels each add their own explanation. The top level prints the '
                     'chain with <code>trace()</code>, then walks it with <code>err.cause</code>.', '''
function g = read_gain(s):
   g = s["gain"];
fnend
function c = check_settings(s):
   try:
      c = read_gain(s);
   except KeyError as low:
      escalate ValueError("settings file is incomplete") because low;
   tend
fnend
function start_run(s):
   try:
      c = check_settings(s);
   except ValueError as mid:
      escalate RuntimeError("could not start the run") because mid;
   tend
fnend

settings = dict();
settings["rate"] = 50;
try:
   start_run(settings);
except RuntimeError as err:
   publish(trace());
   e = err;
   depth = 0;
   while not is_empty(e):
      publish(depth, e.type);
      e = e.cause;
      depth = depth + 1;
   wend
tend
'''),
    },
    'errors': [
        err('raise instead of escalate', 'Python\'s <code>raise</code> is not an NC word; the line reads as two '
            'values side by side.', '''
raise ValueError("x must be positive");''', '''
try:
   escalate ValueError("x must be positive");
except ValueError as err:
   publish(err.message);
tend'''),
        err('escalate; with nothing to raise again', 'A bare <code>escalate;</code> only works inside an except '
            'block. Elsewhere, say what to raise.', '''
x = -1;
if x < 0:
   escalate;
iend''', '''
x = -1;
try:
   if x < 0:
      escalate ValueError("x must be >= 0");
   iend
except ValueError as err:
   publish(err.message);
tend'''),
        err('because needs an error', 'The cause after <code>because</code> must be an error value, such as the name '
            'given by <code>as</code>.', '''
escalate RuntimeError("failed") because 5;''', '''
try:
   try:
      escalate KeyError("k");
   except KeyError as low:
      escalate RuntimeError("failed") because low;
   tend
except RuntimeError as err:
   publish(err.message, "<-", err.cause.type);
tend'''),
    ],
}

# ================================================================== 4. assert, require and ensure
PAGES['assert-contracts'] = {
    'title': 'Assert, Require & Ensure',
    'summary': 'State what must be true and let NC check it: <code>assert</code> anywhere, <code>require</code> '
               'and <code>ensure</code> at the start and end of a function.',
    'about': [
        comp('assert', [
            '<code>assert</code> checks that a condition holds. A true condition passes quietly; a false one raises '
            'an <code>AssertionError</code>, which stops the script unless a try block handles it. There is a '
            'statement form and a call form; both do the same, and both take an optional message.'],
            table=[['Form', 'Message when the condition is false'],
                   ['<code>assert x > 0;</code>', '<code>assertion failed: x > 0</code> (the condition itself)'],
                   ['<code>assert x > 0, "x must be positive";</code>', '<code>x must be positive</code>'],
                   ['<code>assert(x > 0);</code>', '<code>assertion failed</code>'],
                   ['<code>assert(x > 0, "x must be positive");</code>', '<code>x must be positive</code>']],
            syntax='assert n > 0;\nassert abs(sum(p) - 1) < 1e-12, "probabilities must add up to 1";'),
        comp('Matrix conditions', [
            'A condition on a matrix is true only when <em>every</em> element is true, as in an <code>if</code>: '
            '<code>assert v > 0;</code> checks every element of <code>v</code>. For exact equality of whole '
            'matrices, <code>A == B</code> already gives one true/false value.'],
            syntax='assert [1, 2, 3] > 0;      # passes\nassert [1, 2, 0] > 0;      # fails: one element is 0'),
        comp('require and ensure', [
            'Inside a function, <code>require</code> states a <em>precondition</em> (what the inputs must satisfy) '
            'and <code>ensure</code> a <em>postcondition</em> (what the result must satisfy). Both raise an '
            '<code>AssertionError</code>; the message says which kind of check failed and shows the condition.',
            'They make a function\'s promises visible in its first and last lines, and keep the checks next to '
            'the code they protect.'],
            table=[['Line', 'Message when it fails'],
                   ['<code>require x >= 0, "x must not be negative";</code>',
                    '<code>precondition failed: x must not be negative (x >= 0)</code>'],
                   ['<code>ensure y >= 0, "result must be >= 0";</code>',
                    '<code>postcondition failed: result must be >= 0 (y >= 0)</code>']],
            syntax='function y = root(x):\n   require x >= 0, "x must not be negative";\n   y = sqrt(x);\n   ensure y >= 0;\nfnend'),
        comp('Check functions', [
            'For tests there is a family of check functions that say more when they fail: '
            '<code>assert_eq(3, 4)</code> fails with <code>3 != 4</code>, <code>assert_fail</code> checks that a '
            'call fails, <code>assert_warn</code> that it warns. They are in the Default Functions chapter: '
            '<a href="' + DF + 'writing-checks.html">Assertions &amp; Exceptions</a>.']),
    ],
    'examples': {
        'basic': ex('Checks that pass and one that fails', 'Three true conditions pass quietly. The false one is '
                    'handled, so its message can be printed.', '''
x = 5;
assert x > 0;
assert(x == 5);
assert x < 10, "x is small";
publish("three checks passed");

try:
   assert x > 100;
except AssertionError as err:
   publish(err.message);
tend
try:
   assert(x > 100, "x must be above 100");
except AssertionError as err:
   publish(err.message);
tend
'''),
        'mid': ex('A function with a contract', '<code>require</code> checks the input, <code>ensure</code> the '
                  'result. A wrong call is reported as a precondition that failed.', '''
function h = hypotenuse(a, b):
   require a > 0 && b > 0, "sides must be positive";
   h = sqrt(a ^ 2 + b ^ 2);
   ensure h >= a && h >= b;
fnend

publish(hypotenuse(3, 4));
try:
   h = hypotenuse(3, -4);
except AssertionError as err:
   publish(err.message);
tend
'''),
        'strong': ex('Check a computation as it runs', 'Each inverse is checked with <code>assert</code>. The '
                     'singular matrix fails earlier, inside <code>inv</code>, with a ValueError; the loop goes on '
                     'either way, and <code>success</code> reports the matrices that passed.', '''
mats = dict();
mats["A"] = [4, 1; 2, 3];
mats["B"] = [1, 2; 2, 4];
mats["C"] = [2, 0; 0, 5];
for name = keys(mats):
   M = mats[name];
   try:
      Mi = inv(M);
      assert max(abs(M * Mi - unit_matrix(2))) < 1e-12, name + " * inv(" + name + ") is not I";
   except AssertionError as err:
      publish(name, "check failed:", err.message);
   except as err:
      publish(name, "could not be inverted:", err.type);
   success:
      publish(name, "inverse checked, det =", round(det(M), decimals=6));
   tend
fend
'''),
    },
    'errors': [
        err('A failed assert stops the script', 'Outside a try block, a false condition ends the run with an '
            'AssertionError and its message.', '''
x = 3;
assert(x > 4, "x must be above 4");
publish("never printed");''', '''
x = 5;
assert(x > 4, "x must be above 4");
publish("x passed the check");'''),
        err('A result that breaks the promise', '<code>ensure</code> checks the result when the function ends; here '
            'the function forgot the absolute value.', '''
function y = magnitude(x):
   y = x;
   ensure y >= 0, "result must be >= 0";
fnend
publish(magnitude(-2));''', '''
function y = magnitude(x):
   y = abs(x);
   ensure y >= 0, "result must be >= 0";
fnend
publish(magnitude(-2));'''),
        err('Exact equality of decimals', '<code>0.1 + 0.2</code> is not exactly <code>0.3</code> in binary floating '
            'point, so an exact check fails. Compare with a tolerance.', '''
assert 0.1 + 0.2 == 0.3;''', '''
assert abs((0.1 + 0.2) - 0.3) < 1e-12;
publish("equal within 1e-12");'''),
    ],
}

# ================================================================== 5. error types
PAGES['error-types'] = {
    'title': 'Error Types',
    'summary': 'The kinds of error NC knows, which mistakes give which type, and how to make error values '
               'yourself.',
    'about': [
        comp('The family of types', [
            'Every error has a type. <code>Exception</code> is the type every error belongs to, so '
            '<code>except Exception</code> handles any of them. <code>NotImplemented</code> is a kind of '
            '<code>RuntimeError</code>, so <code>except RuntimeError</code> handles it too. The two warning types '
            'are errors only when they are escalated; <code>warn</code> just prints them (see '
            '<a href="' + DF + 'warnings.html">Warnings</a>).'],
            figure=fig(IMG + 'error-types-01.svg',
                       'A tree. Exception at the top. Under it: ValueError, TypeError, KeyError, IndexError, '
                       'AttributeError, MissingResourceError, AssertionError, RuntimeError, and the warnings '
                       'UserWarning and LegacyWarning. Under RuntimeError: NotImplemented.',
                       'The built-in error types. A class of your own script can be raised as well.')),
        comp('Which mistake gives which type', [
            'nc.exe gives each of its own errors a type from what went wrong. The table lists typical causes.'],
            table=[['Type', 'Typical cause', 'For example'],
                   ['<code>ValueError</code>', 'the right kind of value, but an unusable one', '<code>zeros(-1)</code>, <code>[1, 2] + [1, 2, 3]</code>, <code>int8("x")</code>'],
                   ['<code>TypeError</code>', 'a value of the wrong kind', '<code>1 < "a"</code>, <code>"abc" + 5</code>, <code>sqrt("nine")</code>'],
                   ['<code>KeyError</code>', 'a dictionary key that is not there', '<code>d["gamma"]</code>, <code>d.delta</code>'],
                   ['<code>IndexError</code>', 'an index outside a matrix', '<code>v[10]</code> of 3 elements, <code>A[5, 0]</code> of a 2 x 2'],
                   ['<code>AttributeError</code>', 'a field or method an object does not have, or a private one', '<code>m.torque</code>, <code>m.secret</code>'],
                   ['<code>MissingResourceError</code>', 'a file or folder that is not there', '<code>read_csv("missing.csv")</code>'],
                   ['<code>NotImplemented</code>', 'something planned but not there yet', '<code>float128(1)</code>, a method left for subclasses'],
                   ['<code>RuntimeError</code>', 'anything that fits no narrower type', 'an undefined name, an unknown function'],
                   ['<code>AssertionError</code>', 'a check that did not hold', '<code>assert</code>, <code>require</code>, <code>ensure</code>, <code>assert_eq</code>']]),
        comp('Making error values', [
            'Each type is also a function that makes an error value: <code>ValueError("bad")</code> is the dictionary '
            '<code>{type: ValueError, message: bad, line: 0, cause: {}}</code>. The bare name, '
            '<code>ValueError</code>, is the same with an empty message. Keep such a value, test it, or raise it '
            'later with <code>escalate</code>.'],
            syntax='e = ValueError("bad");\npublish(e.type, e.message);\nescalate e;'),
        comp('The type comes from the error, not from a name', [
            'An undefined variable called <code>assert_count</code> is a <code>RuntimeError</code> (an undefined '
            'name), not an <code>AssertionError</code>: NC decides the type from the kind of failure, never from '
            'words that happen to appear in a quoted name.']),
        comp('Names an except block accepts', [
            'An except block may name: ' + TYPES + ', or a class the script defines. Any other name is refused when '
            'the try block is reached, with the list of valid names.']),
    ],
    'examples': {
        'basic': ex('One handler for every kind', 'Four different failures, all handled by '
                    '<code>except Exception</code>; <code>err.type</code> keeps the specific type.', '''
d = dict();
d["alpha"] = 1;
v = [10, 20, 30];
for k = [1:4]:
   try:
      if k == 1:
         x = v[10];
      elseif k == 2:
         x = 1 < "a";
      elseif k == 3:
         x = d["gamma"];
      else:
         x = never_defined_name + 1;
      iend
   except Exception as err:
      publish(k, err.type);
   tend
fend
'''),
        'mid': ex('Fall back to default data', 'A missing calibration file is a MissingResourceError; the function '
                  'returns default values instead.', '''
function T = load_or_default(path):
   try:
      T = read_csv(path);
   except MissingResourceError as err:
      publish("using defaults:", err.message);
      T = [0, 0, 0];
   tend
fnend

cal = load_or_default("calibration_missing.csv");
publish(cal);
'''),
        'strong': ex('Left for subclasses', 'A base class says that <code>area()</code> is for each shape to write. '
                     'A subclass that writes it works; the base class raises NotImplemented, which '
                     '<code>except RuntimeError</code> handles too.', '''
class Shape():
   function base():
      base.kind = "shape";
   fnend
   function a = area():
      escalate NotImplemented("area() is defined by each shape");
   fnend
csend
class Square(Shape):
   function base(side):
      parent();
      base.side = side;
   fnend
   function a = area():
      a = base.side ^ 2;
   fnend
csend

publish("square:", Square(3).area());
try:
   a = Shape().area();
except RuntimeError as err:
   publish(err.type, ":", err.message);
tend
'''),
    },
    'errors': [
        err('A type name that is not an error type', 'Only the built-in types and the script\'s own classes can '
            'follow <code>except</code>. NC names the valid ones.', '''
try:
   x = int8("x");
except ParseError:
   x = 0;
tend''', '''
try:
   x = int8("x");
except ValueError:
   x = 0;
tend
publish(x);'''),
        err('Handling the wrong type', 'A missing key is a KeyError, not an IndexError, so this except block does not '
            'fit and the error stops the script.', '''
d = dict();
d["a"] = 1;
try:
   x = d["b"];
except IndexError:
   x = 0;
tend''', '''
d = dict();
d["a"] = 1;
try:
   x = d["b"];
except KeyError:
   x = 0;
tend
publish(x);'''),
    ],
}
