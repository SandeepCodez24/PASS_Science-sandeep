"""Default Functions - Arrays & Data (source: Function_Test/Code/A_03_Numpy_Rest_of_All, numpy_01..08).

The type rules (00_type_rules) and the ,= / ;= operators (00_extend_operators) of the same folder are
language features: they are in the Language Guide (Variable Types, Growing Matrices).
Every example and error card is run through nc.exe by build_default_functions.py.
"""
from df_helpers import err, ex, fig, fn, reference

IMG = 'Images/Neural_Code/Default_Functions/Arrays_Data/'
LG = '../../Language_Guide/'
PAGES = {}

AXIS_NOTE = ('Positions are 0-based and a negative position counts from the end. <code>axis=0</code> works on whole '
             'rows, <code>axis=1</code> on whole columns; <code>-1</code> is always the columns and <code>-2</code> '
             'the rows, for a matrix of any number of dimensions.')

# ================================================================== 1. Creating arrays
PAGES['creating-arrays'] = {
    'title': 'Creating Arrays',
    'summary': 'Arrays shaped like another one, Vandermonde matrices, coordinate grids and index grids, and a check '
               'that an array holds only finite numbers.',
    'about': reference('Functions that make a new array from a size, a vector or another array. For random arrays '
                       'see <a href="random-numbers.html">Random Numbers</a>.', [
        fn('zeros_like(A) / ones_like(A)', 'Zeros or ones with the shape and element type of A.',
           inputs=[('A', 'any array', '')], syntax='zeros_like([1, 2; 3, 4])   # 0 0; 0 0'),
        fn('check_finite(A)', 'A itself, or an error if A holds NaN or infinity.', inputs=[('A', 'numbers', '')],
           more=['Use it at the start of a calculation that must not run on missing or overflowing data.'],
           syntax='x = check_finite(data);'),
        fn('vander(x, N=0, increasing=false)', 'The Vandermonde matrix: its columns are powers of x, highest first.',
           inputs=[('x', 'vector', ''), ('N', 'number of columns; 0 = one per element of x (may be named)', '0'),
                   ('increasing', 'true: lowest power first (may be named)', 'false')],
           more=['Multiplying it by polynomial coefficients evaluates the polynomial at every x, which is why it '
                 'appears in polynomial fitting.'],
           math=r'V_{ij} = x_i^{\,N-1-j}', syntax='vander([1, 2, 3])   # 1 1 1; 4 2 1; 9 3 1'),
        fn('[X, Y] = meshgrid(x, y, indexing="xy")', 'Coordinate grids: X repeats x down the rows, Y repeats y '
           'across the columns, so a function of two variables can be worked out on every grid point at once.',
           inputs=[('x, y', 'vectors of coordinates', ''),
                   ('indexing', '"xy" (x along the columns) or "ij" (x along the rows) (may be named)', '"xy"')],
           syntax='[X, Y] = meshgrid([1, 2, 3], [10, 20]);\nZ = X + Y;', short='coordinate grids for a function of x and y'),
        fn('[R, C] = indices([r, c])', 'Two grids holding the row number and the column number of every position.',
           inputs=[('[r, c]', 'the shape', '')], math=r'R_{ij} = i, \qquad C_{ij} = j',
           syntax='[R, C] = indices([2, 3])', short='row and column numbers of every position'),
    ]),
    'examples': {
        'basic': ex('Shaped like another array', 'Zeros and ones in the shape of an existing array, and a finite '
                    'check that passes.', '''
A = [1, 2.5; -3, 4];
z = zeros_like(A)
o = ones_like([5, 6, 7])
ok = check_finite(A)
'''),
        'mid': ex('Vandermonde matrices', 'Powers of x as columns, with a chosen number of columns and order. '
                  'Multiplying by coefficients evaluates the polynomial.', '''
V = vander([1, 2, 3])
V2 = vander([1, 2, 3], N=2, increasing=true)
V4 = vander([2, 3], N=4)
p = V * [2; 3; 1]
'''),
        'strong': ex('A function on a grid', '<code>meshgrid</code> turns two coordinate vectors into grids; '
                     'the height of a dome is then worked out at every point in one line. <code>indices</code> '
                     'gives the positions themselves. (Comparing a matrix with one value gives one answer per '
                     'element; comparing two matrices gives one answer: are they equal?)', '''
[X, Y] = meshgrid([-1, 0, 1], [-1, 0, 1]);
H = 2 - X *. X - Y *. Y
[I, J] = meshgrid([1, 2, 3], [10, 20], indexing="ij")
[R, C] = indices([2, 3])
diag_mask = (R - C) == 0
'''),
    },
    'errors': [
        err('A NaN in check_finite', 'NC names the first bad element.', 'x = check_finite([1, nan, 3]);',
            'x = check_finite(fill_nan([1, nan, 3], method="linear"));\npublish(x);'),
        err('An unknown indexing', 'indexing is "xy" or "ij".', '[X, Y] = meshgrid([1, 2], [3, 4], indexing="xyz");',
            '[X, Y] = meshgrid([1, 2], [3, 4], indexing="ij");\npublish(X);'),
    ],
}

# ================================================================== 2. Random numbers
PAGES['random-numbers'] = {
    'title': 'Random Numbers',
    'summary': 'Random choices, shuffles and permutations, and samples from eleven probability distributions, all '
               'repeatable with one seed.',
    'about': reference('Every function here draws from one random engine. Call <code>nexus_seed(n)</code> first to '
                       'get the same numbers on every run. <code>size</code> is 1 (one value, the default), n (a row '
                       'of n) or <code>[r, c]</code> (an r x c matrix).', [
        fn('nexus_seed(n)', 'Seeds the random engine: after the same seed, every random function gives the same '
           'numbers again.', inputs=[('n', 'whole number', '')], syntax='nexus_seed(7);',
           short='makes random results repeatable'),
        fn('rand_choice(a, size=1, replace=true, p)', 'Random elements of a; a whole number a means 0 to a&minus;1.',
           inputs=[('a', 'a vector (numbers or text), or a whole number', ''),
                   ('size', '1, n or [r, c] (may be named)', '1'),
                   ('replace', 'false: each element at most once (may be named)', 'true'),
                   ('p', 'one probability per element, adding up to 1 (may be named)', 'all equal')],
           syntax='rand_choice(100, size=10)\nrand_choice(["heads", "tails"], size=5)\nrand_choice([1, 2, 3], p=[0.2, 0.3, 0.5])'),
        fn('shuffle(A[, axis])', 'A shuffled copy: a vector along its length, a matrix by whole rows '
           '(<code>axis=1</code>: by whole columns).', inputs=[('A', 'array', ''), ('axis', '0 or 1', '0')],
           syntax='shuffle([1, 2, 3, 4, 5, 6])'),
        fn('permutation(x)', '0 to x&minus;1 in random order, or a shuffled copy of a vector x.',
           inputs=[('x', 'whole number, or vector', '')], syntax='permutation(8)'),
        fn('rand_binomial(n, p, size=1)', 'Successes in n trials, each with probability p.',
           inputs=[('n', 'trials', ''), ('p', 'probability, 0 to 1', '')],
           math=r'P(k) = \binom{n}{k} p^k (1-p)^{n-k}, \qquad \text{mean } np',
           figure=fig(IMG + 'random-numbers-01.svg',
                      'Six panels showing the shape of each distribution: binomial with n 10 and p 0.5, Poisson '
                      'with mean 3, exponential with mean 2, beta with a 2 and b 3, gamma with shape 2 and scale 3, '
                      'and triangular from 0 to 4 with its peak at 1.',
                      'The shapes of six of the distributions, with the parameters used in the examples. Bars are '
                      'whole-number counts; curves are continuous values.')),
        fn('rand_poisson(lam, size=1)', 'Counts of events with mean lam (calls per minute, defects per metre).',
           inputs=[('lam', 'mean count', '')], math=r'P(k) = \frac{\lambda^k e^{-\lambda}}{k!}'),
        fn('rand_exponential(scale=1, size=1)', 'Waiting times with mean <code>scale</code>.',
           inputs=[('scale', 'the mean', '1')], math=r'f(x) = \tfrac{1}{s} e^{-x/s}'),
        fn('rand_beta(a, b, size=1)', 'Numbers between 0 and 1 with mean a/(a+b): fractions and proportions.',
           inputs=[('a, b', 'positive shape numbers', '')]),
        fn('rand_gamma(shape, scale=1, size=1)', 'Positive numbers with mean shape &times; scale.',
           inputs=[('shape', 'positive', ''), ('scale', 'positive', '1')]),
        fn('rand_lognormal(mean=0, sigma=1, size=1)', 'e raised to a normal number: always positive, skewed to the '
           'right.', inputs=[('mean, sigma', 'of the underlying normal number', '0, 1')]),
        fn('rand_chisquare(df, size=1)', 'Chi-square numbers with <code>df</code> degrees of freedom (mean df).',
           inputs=[('df', 'degrees of freedom', '')]),
        fn('rand_triangular(left, mode, right, size=1)', 'Numbers between left and right, most likely near mode.',
           inputs=[('left, mode, right', 'left &le; mode &le; right, left &lt; right', '')],
           math=r'\text{mean} = (l + m + r)/3'),
        fn('rand_geometric(p, size=1)', 'The number of trials up to and including the first success: 1, 2, 3, ...',
           inputs=[('p', 'probability of success', '')], math=r'\text{mean} = 1/p'),
        fn('rand_multinomial(n, pvals, size=1)', 'Counts per category for n trials; one row per draw.',
           inputs=[('n', 'trials', ''), ('pvals', 'one probability per category', '')]),
        fn('rand_mvnormal(mean, cov, size=1)', 'Points of a multivariate normal distribution, one row per point.',
           inputs=[('mean', 'row of means', ''), ('cov', 'symmetric positive semi-definite covariance matrix', '')]),
    ]),
    'examples': {
        'basic': ex('Repeatable choices', 'The same seed gives the same numbers. Choices with and without '
                    'replacement, from numbers and from text.', '''
nexus_seed(7);
first = rand_choice(100, size=10)
nexus_seed(7);
again = rand_choice(100, size=10)
same = equal(first, again)
d = rand_choice([10, 20, 30, 40], size=4, replace=false)
w = rand_choice(["heads", "tails"], size=6)
'''),
        'mid': ex('Shuffles and permutations', 'Shuffle a vector, shuffle a matrix by whole rows, and permute '
                  'indices to reorder two vectors the same way.', '''
nexus_seed(3);
s = shuffle([1, 2, 3, 4, 5, 6])
M = [1, 2; 3, 4; 5, 6];
S = shuffle(M)
p = permutation(5)
names = ["a", "b", "c", "d", "e"];
scores = [10, 20, 30, 40, 50];
publish(take(names, p), take(scores, p));
'''),
        'strong': ex('Checking the distributions', 'Twenty thousand samples from several distributions: the means '
                     'land close to the values the formulas give.', '''
nexus_seed(2026);
publish("binomial(10, 0.5)  mean", round(mean(rand_binomial(10, 0.5, size=20000)), decimals=3), " expected 5");
publish("poisson(3)         mean", round(mean(rand_poisson(3, size=20000)), decimals=3), " expected 3");
publish("exponential(2)     mean", round(mean(rand_exponential(2, size=20000)), decimals=3), " expected 2");
publish("beta(2, 3)         mean", round(mean(rand_beta(2, 3, size=20000)), decimals=3), " expected 0.4");
publish("gamma(2, 3)        mean", round(mean(rand_gamma(2, 3, size=20000)), decimals=3), " expected 6");
publish("triangular(0,1,4)  mean", round(mean(rand_triangular(0, 1, 4, size=20000)), decimals=3), " expected 1.667");
publish("geometric(0.25)    mean", round(mean(rand_geometric(0.25, size=20000)), decimals=3), " expected 4");
m = rand_multinomial(10, [0.2, 0.3, 0.5], size=3)
v = rand_mvnormal([0, 10], [1, 0; 0, 0], size=3)
'''),
    },
    'errors': [
        err('More choices than elements without replacement', 'Each element can be taken once.',
            'x = rand_choice([1, 2, 3], size=5, replace=false);', 'x = rand_choice([1, 2, 3], size=3, replace=false);\npublish(sort_asc(x));'),
        err('Probabilities that do not add up to 1', 'NC shows the sum.', 'x = rand_choice([1, 2], p=[0.5, 0.6]);',
            'nexus_seed(1);\nx = rand_choice([1, 2], p=[0.4, 0.6]);\npublish(x >= 1);'),
        err('A probability above 1', '<code>p</code> must lie between 0 and 1.', 'x = rand_binomial(10, 1.5);',
            'nexus_seed(1);\nx = rand_binomial(10, 0.5);\npublish(x <= 10);'),
        err('A negative shape', 'Gamma needs a positive shape.', 'x = rand_gamma(-1);',
            'nexus_seed(1);\nx = rand_gamma(1);\npublish(x > 0);'),
        err('Triangular limits in the wrong order', 'left &le; mode &le; right is needed.', 'x = rand_triangular(2, 1, 3);',
            'nexus_seed(1);\nx = rand_triangular(1, 2, 3);\npublish(x >= 1 && x <= 3);'),
        err('A covariance that is not symmetric', 'A covariance matrix equals its transpose.',
            'x = rand_mvnormal([0, 0], [1, 2; 0, 1]);', 'nexus_seed(1);\nx = rand_mvnormal([0, 0], [1, 0.5; 0.5, 1]);\npublish(shape(x));'),
        err('A covariance with a negative eigenvalue', 'It must be positive semi-definite.',
            'x = rand_mvnormal([0, 0], [1, 2; 2, 1]);', 'nexus_seed(1);\nx = rand_mvnormal([0, 0], [2, 1; 1, 2]);\npublish(shape(x));'),
        err('A negative size', 'size holds whole numbers of 0 or more.', 'x = rand_poisson(3, size=[2, -1]);',
            'nexus_seed(1);\nx = rand_poisson(3, size=[2, 3]);\npublish(shape(x));'),
    ],
}

# ================================================================== 3. Inspecting types
PAGES['inspecting-types'] = {
    'title': 'Inspecting Types',
    'summary': 'How many dimensions an array has, whether a value is a single value, which elements are complex, '
               'the element type, and which type conversions are safe.',
    'about': reference('Type names: <code>bool</code>, <code>int8</code> &hellip; <code>int64</code>, '
                       '<code>uint8</code> &hellip; <code>uint64</code>, <code>float8</code> &hellip; '
                       '<code>float64</code>, <code>complex128</code>, <code>text</code>, <code>timestamp</code>, '
                       '<code>duration</code>. See also <a href="' + LG + 'Getting_Started/variable-types.html">'
                       'Variable Types</a> in the Language Guide.', [
        fn('ndim(A)', 'The number of dimensions: 0 for a single value, 2 for a matrix (a row such as '
           '<code>[1, 2, 3]</code> is a 1 x 3 matrix), N for an N-D matrix, 1 for a 1-D array from '
           '<code>space()</code>.', inputs=[('A', 'any value', '')], syntax='ndim(5)            # 0\nndim([1, 2, 3])    # 2'),
        fn('is_scalar(x)', 'True for one single value (number, true/false, text, timestamp ...); false for any '
           'matrix, even a 1 x 1 one like <code>[5]</code>.', inputs=[('x', 'any value', '')],
           syntax='is_scalar(3.5)   # true\nis_scalar([5])   # false'),
        fn('is_complex_each(A) / is_real_each(A)', 'For each element: true where the imaginary part is not 0 '
           '(complex) or is 0 (real).', inputs=[('A', 'numbers', '')],
           syntax='is_complex_each([1 + 2i, 3, 4i])   # true false true',
           short='per element: complex or real?'),
        fn('type(x)', 'The element type, as text.', inputs=[('x', 'any value', '')],
           syntax='type(int8([1, 2]))   # "int8"\ntype(minutes(5))     # "duration"'),
        fn('is_type(x, name)', 'Whether the type of x is <code>name</code>, or belongs to the group '
           '"integer", "float", "number", "complex" or "time".',
           inputs=[('x', 'any value', ''), ('name', 'a type name or a group', '')],
           more=['true/false values are not in the "number" group.'],
           syntax='is_type(uint8(7), "integer")   # true\nis_type(hours(1), "time")      # true'),
        fn('can_cast(from, to, casting="safe")', 'Whether values of type <code>from</code> (a value or a type name) '
           'can be turned into type <code>to</code> under a casting rule.',
           inputs=[('from', 'a value, or a type name', ''), ('to', 'a type name', ''),
                   ('casting', '"no", "equiv", "safe", "same_kind" or "unsafe" (may be named)', '"safe"')],
           more=['"safe": every value fits exactly (int8 &rarr; int16 yes, int16 &rarr; int8 no, int32 &rarr; '
                 'float64 yes, int32 &rarr; float32 no). "same_kind": also downward within a kind (float64 &rarr; '
                 'float32), but not float &rarr; int. "unsafe": any number to any number. "no": only the same type. '
                 'Time types never become numbers.'],
           figure=fig(IMG + 'inspecting-types-01.svg',
                      'Arrows between number types that can be converted safely: bool to every number type; int8 '
                      'to int16 to int32 to int64; uint8 to uint16 and int16; int32 and uint32 to float64; float '
                      'types upward; float64 to complex128.',
                      'Safe conversions go along the arrows: every value of the source fits exactly in the target.'),
           syntax='can_cast("int8", "int16")                          # true\ncan_cast("float64", "float32", casting="same_kind")'),
    ]),
    'examples': {
        'basic': ex('Dimensions and single values', 'A single value, a row, a matrix and an N-D matrix.', '''
publish(ndim(5), ndim([1, 2, 3]), ndim([1, 2; 3, 4]), ndim([1, 2; 3, 4 ;; 5, 6; 7, 8]));
publish(is_scalar(3.5), is_scalar("abc"), is_scalar([5]), is_scalar([1, 2]));
z = [1 + 2i, 3, 4i];
c = is_complex_each(z)
r = is_real_each(z)
'''),
        'mid': ex('Element types', '<code>type</code> names the element type; <code>is_type</code> also '
                  'understands groups.', '''
publish(type(2.5), type(int8([1, 2])), type(true), type("hello"));
publish(type(1 + 2i), type(float32(1.5)), type(timestamp(2026, 1, 1)), type(minutes(5)));
publish(is_type(int32(7), "int32"), is_type(uint8(7), "integer"), is_type([1.5, 2], "float"));
publish(is_type(true, "number"), is_type(hours(1), "time"), is_type(2.5, "int64"));
'''),
        'strong': ex('Which conversions are safe?', 'A table of <code>can_cast</code> answers under the four '
                     'casting rules, built row by row.', '''
pairs = ["int8", "int16"; "int16", "int8"; "int32", "float64"; "int32", "float32"; "float64", "float32"; "float64", "int8"; "complex128", "float64"];
publish("from        to           safe  same_kind  unsafe");
for k = [0:6]:
   a = pairs[k, 0];
   b = pairs[k, 1];
   publish(center(a, 11), center(b, 11), can_cast(a, b), can_cast(a, b, casting="same_kind"), can_cast(a, b, casting="unsafe"));
fend
publish("from a value:", can_cast(int8(5), "int32"), "  time to number:", can_cast("timestamp", "int64", casting="unsafe"));
'''),
    },
    'errors': [
        err('A misspelt type group', 'NC lists every type and group it knows.', 'x = is_type(5, "integr");',
            'x = is_type(5, "float");\npublish(x);'),
        err('An unknown type name', 'There is no int12.', 'x = can_cast("int8", "int12");',
            'x = can_cast("int8", "int16");\npublish(x);'),
        err('An unknown casting rule', 'Use one of the five rules.', 'x = can_cast("int8", "int16", casting="maybe");',
            'x = can_cast("int8", "int16", casting="same_kind");\npublish(x);'),
        err('Complex parts of text', 'These functions work on numbers.', 'x = is_complex_each(["a", "b"]);',
            'x = is_complex_each([1, 2i]);\npublish(x);'),
    ],
}

# ================================================================== 4. Adding and removing
A2 = 'A = [1, 2; 3, 4];\n'
PAGES['adding-removing'] = {
    'title': 'Adding & Removing Elements',
    'summary': 'Insert and repeat elements, pad an array with a border, trim zeros, keep the distinct values, and '
               'replace chosen elements.',
    'about': reference('Every function returns a new value; A itself never changes. Without an axis, '
                       '<code>insert</code>, <code>repeat</code> and <code>unique</code> take the elements of A row by '
                       'row and give one row. ' + AXIS_NOTE, [
        fn('insert(A, index, values[, axis])', 'Values put in before position <code>index</code>.',
           inputs=[('A', 'array', ''), ('index', 'a position, or several (0-based; negative from the end)', ''),
                   ('values', 'one value, a slice, or a block that fits', ''), ('axis', '0 = rows, 1 = columns', 'none')],
           syntax='insert([1, 2, 3], 1, 9)              # 1 9 2 3\ninsert(A, 1, [9, 9], axis=0)          # a new row'),
        fn('repeat(A, repeats[, axis])', 'Each element (or each row or column) repeated.',
           inputs=[('A', 'array', ''), ('repeats', 'one count, or one per element', ''), ('axis', '0 or 1', 'none')],
           syntax='repeat([1, 2], 3)             # 1 1 1 2 2 2\nrepeat([1, 2, 3], [0, 1, 2])  # 2 3 3'),
        fn('pad(A, width, mode="constant", value=0)', 'A border around A.',
           inputs=[('A', 'array', ''),
                   ('width', 'n (every side), [before, after] (every axis), or one [before, after] row per axis', ''),
                   ('mode', '"constant", "edge", "reflect", "symmetric" or "wrap" (may be named)', '"constant"'),
                   ('value', 'the border value for "constant" (may be named)', '0')],
           more=['To pad only the two ends of a row, give one row per axis: <code>[0, 0; 2, 2]</code> means '
                 'nothing above or below, two columns before and after.'],
           figure=fig(IMG + 'adding-removing-01.svg',
                      'The row 1 2 3 padded by two on each side in five modes: constant gives 0 0, edge repeats '
                      '1 1 and 3 3, reflect mirrors without the edge (3 2 and 2 1), symmetric mirrors with the edge '
                      '(2 1 and 3 2), wrap continues from the other end (2 3 and 1 2).',
                      'The five padding modes on <code>[1, 2, 3]</code> with width <code>[0, 0; 2, 2]</code>.'),
           syntax='pad(A, 1)                              # a ring of zeros\npad(v, [0, 0; 2, 2], mode="reflect")'),
        fn('trim_zeros(v, trim="fb")', 'Zeros taken off the front ("f"), the back ("b") or both ends ("fb") of a '
           'vector.', inputs=[('v', 'a row or a column', ''), ('trim', '"f", "b" or "fb" (may be named)', '"fb"')],
           syntax='trim_zeros([0, 0, 1, 2, 0, 3, 0])   # 1 2 0 3'),
        fn('unique(A[, axis])', 'The distinct elements, sorted; with an axis, the distinct rows or columns.',
           inputs=[('A', 'numbers or text', ''), ('axis', '0 = rows, 1 = columns', 'elements')],
           more=['NaN goes last, once. Text sorts alphabetically. For positions and counts as well, see '
                 '<code>unique_all</code> on <a href="histograms-bins.html">Histograms &amp; Counting</a>.'],
           syntax='unique([3, 1, 2, 3, 1])                # 1 2 3\nunique([1, 2; 1, 2; 0, 9], axis=0)     # 0 9; 1 2'),
        fn('put(A, indices, values)', 'A with the elements at flat positions (row by row) replaced; the values '
           'are repeated if there are fewer of them.',
           inputs=[('A', 'array', ''), ('indices', 'flat positions', ''), ('values', 'new values', '')],
           syntax='put([1, 2; 3, 4], [0, 3], [10, 40])   # 10 2; 3 40'),
        fn('replace_if(A, mask, value)', 'A with the elements where mask is true replaced.',
           inputs=[('A', 'array', ''), ('mask', 'true/false array of the same size', ''),
                   ('value', 'one value, or an array of the same size', '')],
           syntax='replace_if(A, A > 2, 0)   # 1 2; 0 0'),
        fn('fill_diagonal(A, value, wrap=false)', 'A with its main diagonal set.',
           inputs=[('A', 'matrix', ''), ('value', 'one value, or one per diagonal element', ''),
                   ('wrap', 'true: start again below the square part of a tall matrix (may be named)', 'false')],
           syntax='fill_diagonal(zeros(3, 3), 7)'),
        fn('nan_to_num(A, nan=0, posinf, neginf)', 'NaN and &plusmn;infinity replaced by numbers.',
           inputs=[('A', 'numbers', ''), ('nan', 'value for NaN (may be named)', '0'),
                   ('posinf, neginf', 'values for &plusmn;inf (may be named)', 'the largest finite numbers')],
           syntax='nan_to_num([nan, inf, -inf], nan=-1, posinf=99, neginf=-99)'),
    ]),
    'examples': {
        'basic': ex('Insert and repeat', 'Single values, several values, whole rows and columns.', A2 + '''v = [1, 2, 3];
a = insert(v, 1, 9)
b = insert(v, [0, 3], [7, 8])
c = insert(A, 1, [9, 9], axis=0)
d = insert(A, 1, [7, 8], axis=1)
e = repeat([1, 2, 3], [0, 1, 2])
f = repeat(A, [1, 3], axis=1)
'''),
        'mid': ex('Borders and trimming', 'A ring of zeros, the five padding modes on a row, and zeros trimmed off '
                  'the ends of a signal.', '''A = [1, 2; 3, 4];
P = pad(A, 1)
v = [1, 2, 3];
publish("constant ", pad(v, [0, 0; 2, 2]));
publish("edge     ", pad(v, [0, 0; 2, 2], mode="edge"));
publish("reflect  ", pad(v, [0, 0; 2, 2], mode="reflect"));
publish("symmetric", pad(v, [0, 0; 2, 2], mode="symmetric"));
publish("wrap     ", pad(v, [0, 0; 2, 2], mode="wrap"));
t = trim_zeros([0, 0, 1, 2, 0, 3, 0])
'''),
        'strong': ex('Cleaning a data block', 'Distinct readings and rows, out-of-range readings replaced, a '
                     'calibration diagonal, and missing and infinite values turned into numbers.', '''
readings = [4, 1, 4, 3, 1, 9];
u = unique(readings)
rows = unique([1, 2; 1, 2; 0, 9], axis=0)
fruit = unique(["pear", "apple", "pear"])
R = [12, 85; 47, 130];
clipped = replace_if(R, R > 100, 100)
marked = put(R, [0, 3], [-1, -1])
D = fill_diagonal(zeros(3, 3), [1, 2, 3])
W = fill_diagonal(zeros(5, 2), 1, wrap=true)
clean = nan_to_num([nan, 2, inf, -inf], nan=0, posinf=99, neginf=-99)
'''),
    },
    'errors': [
        err('A position beyond the end', '<code>insert</code> can put values at 0 to n.',
            'x = insert([1, 2, 3], 5, 9);', 'x = insert([1, 2, 3], 3, 9);\npublish(x);'),
        err('A slice of the wrong size', 'A new row of a 2 x 2 matrix needs 2 values.',
            'A = [1, 2; 3, 4];\nx = insert(A, 1, [1, 2, 3], axis=0);', 'A = [1, 2; 3, 4];\nx = insert(A, 1, [1, 2], axis=0);\npublish(x);'),
        err('Too many repeat counts', 'One count, or one per element.', 'x = repeat([1, 2], [1, 2, 3]);',
            'x = repeat([1, 2], [1, 2]);\npublish(x);'),
        err('An unknown pad mode', 'NC lists the five modes.', 'A = [1, 2; 3, 4];\nx = pad(A, 1, mode="mirror");',
            'A = [1, 2; 3, 4];\nx = pad(A, 1, mode="reflect");\npublish(x);'),
        err('A pad width with three numbers', 'Use n, [before, after], or one row per axis.',
            'A = [1, 2; 3, 4];\nx = pad(A, [1, 2, 3]);', 'A = [1, 2; 3, 4];\nx = pad(A, [1, 2]);\npublish(x);'),
        err('trim_zeros on a matrix', 'It works on a vector.', 'x = trim_zeros([1, 2; 3, 4]);',
            'x = trim_zeros([0, 1, 2, 0]);\npublish(x);'),
        err('A put position outside the array', 'A 2 x 2 matrix has positions 0 to 3.',
            'A = [1, 2; 3, 4];\nx = put(A, 4, 0);', 'A = [1, 2; 3, 4];\nx = put(A, 3, 0);\npublish(x);'),
        err('A mask of the wrong size', 'The mask needs one true/false per element.',
            'A = [1, 2; 3, 4];\nx = replace_if(A, [true, false], 0);', 'A = [1, 2; 3, 4];\nx = replace_if(A, A > 2, 0);\npublish(x);'),
    ],
}

# ================================================================== 5. Combining and splitting
PAGES['combining-splitting'] = {
    'title': 'Combining & Splitting',
    'summary': 'Join arrays along an existing axis or a new one, stack rows and columns, and cut an array into '
               'equal pieces or at chosen positions.',
    'about': reference('Joining "along axis k" means the result grows in direction k. Without an axis, '
                       '<code>concat</code> and <code>stack</code> use axis 0. Element types follow the matrix rules, '
                       'and an empty input <code>[]</code> is left out.', [
        fn('concat(A, B, ..., axis=0)', 'Joins arrays along an existing axis: axis 0 adds rows, axis 1 adds columns.',
           inputs=[('A, B, ...', 'arrays that match except along the axis', ''), ('axis', 'by name', '0')],
           figure=fig(IMG + 'combining-splitting-01.svg',
                      'Two 2 by 2 matrices A and B. concat along axis 0 puts B under A (4 by 2); along axis 1 puts '
                      'B beside A (2 by 4); stack puts them on two pages of a new axis (2 by 2 by 2).',
                      '<code>concat</code> grows an existing axis; <code>stack</code> makes a new one.'),
           syntax='concat(A, B)            # [A; B]\nconcat(A, B, axis=1)    # [A, B]'),
        fn('stack(A, B, ..., axis=0)', 'Joins arrays of the same size along a new axis: two 2 x 2 matrices become '
           'one 2 x 2 x 2 array.', inputs=[('A, B, ...', 'arrays of the same size', ''), ('axis', 'where the new axis goes', '0')],
           syntax='S = stack(A, B);   # S[0] is A, S[1] is B'),
        fn('row_stack(A, B, ...) / vstack', 'Rows below rows: the same as <code>[A; B]</code>, also on every page of '
           'an N-D array.', inputs=[('A, B, ...', 'arrays with the same number of columns', '')],
           syntax='row_stack([1, 2, 3], [4, 5, 6])   # 2 x 3', short='rows below rows: [A; B]'),
        fn('column_stack(A, B, ...) / hstack', 'Columns beside columns: the same as <code>[A, B]</code>.',
           inputs=[('A, B, ...', 'arrays with the same number of rows', '')],
           more=['Because <code>[1, 2, 3]</code> is a row, <code>column_stack([1, 2, 3], [4, 5, 6])</code> is the '
                 '1 x 6 row 1 2 3 4 5 6.'],
           syntax='column_stack([1; 2; 3], [1; 2; 3])   # 3 x 2', short='columns beside columns: [A, B]'),
        fn('matrix_split(A, n_or_positions, axis=0)', 'Cuts A into n equal pieces along an axis, or before the given '
           'positions.', inputs=[('A', 'array', ''), ('n_or_positions', 'number of pieces, or cut positions', ''),
                                 ('axis', 'by name', '0')],
           more=['Several names get one piece each (<code>[L, R] = hsplit(A, 2)</code>); one name gets them all as a '
                 'list (<code>P = matrix_split(A, 3)</code>, then <code>P[0]</code>, <code>P[1]</code> ...).'],
           syntax='[P1, P2, P3] = matrix_split(M, [1, 4], axis=1)', short='cut into equal pieces or at positions'),
        fn('vsplit(A, n_or_positions) / hsplit', 'Cuts between rows (vsplit) or between columns (hsplit).',
           inputs=[('A', 'array', ''), ('n_or_positions', 'as matrix_split', '')],
           syntax='[L, R] = hsplit(M, 2)\n[U, D] = vsplit(M, 2)', short='cut between rows / between columns'),
    ]),
    'examples': {
        'basic': ex('Rows and columns', 'Two rows joined both ways, and two columns side by side.', '''
a = [1, 2, 3];
b = [4, 5, 6];
r = row_stack(a, b)
c = column_stack(a, b)
col = [1; 2; 3];
cc = column_stack(col, col)
'''),
        'mid': ex('Along an axis, or a new one', '<code>concat</code> grows an existing axis; <code>stack</code> adds '
                  'one. Negative axes count from the end.', '''
A = [1, 2; 3, 4];
B = [5, 6; 7, 8];
down = concat(A, B)
across = concat(A, B, axis=-1)
S = stack(A, B);
sz = shape(S)
page1 = S[1]
pairs = stack(A, B, axis=2)[0]
'''),
        'strong': ex('Cutting and joining back', 'Split a 2 x 6 block in halves, at chosen columns and into a list '
                     'of three, then join the halves again.', '''
M = [1, 2, 3, 4, 5, 6; 7, 8, 9, 10, 11, 12];
[L, R] = hsplit(M, 2)
[U, D] = vsplit(M, 2);
[P1, P2, P3] = matrix_split(M, [1, 4], axis=1)
P = matrix_split(M, 3, axis=1);
publish("pieces:", numel(P), "  middle piece:", P[1]);
back = equal(column_stack(L, R), M)
'''),
    },
    'errors': [
        err('Sizes that do not match', 'For axis 0 the column counts must agree.', 'x = concat([1, 2; 3, 4], [1, 2, 3; 4, 5, 6]);',
            'x = concat([1, 2; 3, 4], [1, 2, 3; 4, 5, 6], axis=1);\npublish(x);'),
        err('stack with different sizes', 'stack needs equal sizes; concat joins along an existing axis.',
            'x = stack([1, 2; 3, 4], [1, 2, 3; 4, 5, 6]);', 'x = concat([1, 2; 3, 4], [1, 2, 3; 4, 5, 6], axis=1);\npublish(x);'),
        err('Pieces that cannot be equal', 'Three columns do not split into two equal parts; give a cut position.',
            'x = matrix_split([1, 2, 3; 4, 5, 6], 2, axis=1);', '[a, b] = matrix_split([1, 2, 3; 4, 5, 6], [2], axis=1);\npublish(a, b);'),
        err('A misspelt axis', 'NC lists the inputs.', 'x = concat([1, 2], [3, 4], axs=1);',
            'x = concat([1, 2], [3, 4], axis=1);\npublish(x);'),
        err('Numbers and timestamps together', 'A timestamp never joins a number.',
            'x = column_stack([1; 2], [timestamp(2026, 1, 1); timestamp(2026, 1, 2)]);',
            'x = column_stack([1; 2], [3; 4]);\npublish(x);'),
        err('Fewer names than pieces', 'Give one name per piece, or one name for the whole list.',
            '[a, b] = matrix_split([1, 2, 3, 4, 5, 6], 3, axis=1);', 'P = matrix_split([1, 2, 3, 4, 5, 6], 3, axis=1);\npublish(numel(P));'),
    ],
}

# ================================================================== 6. Sorting and reshaping
M = 'M = [3, 1, 2; 9, 7, 8];\n'
PAGES['sorting-reshaping'] = {
    'title': 'Sorting, Flipping & Rotating',
    'summary': 'Sort up or down along any axis, sort complex numbers, flatten, flip, rotate by quarter turns and '
               'roll elements around.',
    'about': reference('A vector is sorted along its length; any other matrix row by row (axis -1); '
                       '<code>axis=0</code> sorts every column. NaN always goes last, text sorts alphabetically, and '
                       'equal elements keep their order. Every function returns a new value.', [
        fn('sort_asc(A[, axis])', 'Sorted from smallest to largest.', inputs=[('A', 'numbers or text', ''), ('axis', '0 or 1', 'rows')],
           syntax='sort_asc([3, 1, 2; 9, 7, 8])            # 1 2 3; 7 8 9\nsort_asc([3, 8; 1, 9; 2, 7], axis=0)'),
        fn('sort_desc(A[, axis])', 'Sorted from largest to smallest (NaN still last).',
           inputs=[('A', 'numbers or text', ''), ('axis', '0 or 1', 'rows')], syntax='sort_desc([3, 1, 2])   # 3 2 1'),
        fn('sort_complex(A[, axis])', 'Sorted by real part, then by imaginary part; the result is complex.',
           inputs=[('A', 'numbers', '')], syntax='sort_complex([3, 1+2i, 1-1i, 2])   # 1-1i 1+2i 2 3'),
        fn('flatten(A, order="C")', 'Every element in one row: "C" row by row, "F" column by column.',
           inputs=[('A', 'array', ''), ('order', '"C" or "F" (may be named)', '"C"')],
           syntax='flatten(M)              # 3 1 2 9 7 8\nflatten(M, order="F")   # 3 9 1 7 2 8'),
        fn('flip(A[, axis])', 'Reversed along one axis; without an axis, along every axis.',
           inputs=[('A', 'array', ''), ('axis', '0 or 1', 'all axes')], syntax='flip([1, 2, 3, 4])   # 4 3 2 1'),
        fn('fliplr(A) / flipud(A)', 'Columns reversed (left &harr; right) or rows reversed (up &harr; down), on every '
           'page of an N-D array.', inputs=[('A', 'array', '')],
           figure=fig(IMG + 'sorting-reshaping-01.svg',
                      'The matrix 3 1 2 over 9 7 8 and what fliplr, flipud, rot90 and rot90 with k = -1 make of it.',
                      'One matrix, four rearrangements. <code>rot90</code> turns counter-clockwise; a negative k '
                      'turns clockwise.'),
           syntax='fliplr(M)   # 2 1 3; 8 7 9\nflipud(M)   # 9 7 8; 3 1 2', short='reverse the columns / the rows'),
        fn('rot90(A, k=1)', 'Turned 90&deg; counter-clockwise k times (k &lt; 0: clockwise).',
           inputs=[('A', 'array', ''), ('k', 'whole number of quarter turns', '1')], syntax='rot90(M)\nrot90(M, -1)'),
        fn('roll(A, shift[, axis])', 'Elements moved <code>shift</code> places around a cycle; what falls off one end '
           'comes back at the other.', inputs=[('A', 'array', ''), ('shift', 'places (negative: the other way)', ''),
                                               ('axis', '0 or 1', 'row-by-row order, shape kept')],
           syntax='roll([1, 2, 3, 4, 5], 2)   # 4 5 1 2 3'),
    ]),
    'examples': {
        'basic': ex('Sorting', 'Rows, columns, descending order, NaN and text.', M + '''
a = sort_asc(M)
b = sort_asc(M, axis=0)
c = sort_desc([3, 1, 2])
n = sort_asc([3, nan, 1])
t = sort_asc(["pear", "apple", "fig"])
z = sort_complex([3, 1+2i, 1-1i, 2])
'''),
        'mid': ex('Flattening and flipping', 'Two orders of flattening, and flips along each axis.', M + '''
f = flatten(M)
fF = flatten(M, order="F")
lr = fliplr(M)
ud = flipud(M)
whole = flip(M)
'''),
        'strong': ex('Rotations and rolling', 'Quarter turns in both directions, four turns giving M back, and '
                     'rolling a signal, rows and columns.', M + '''
r1 = rot90(M)
r2 = rot90(M, 2)
rc = rot90(M, -1)
same = equal(rot90(M, 4), M)
s = roll([1, 2, 3, 4, 5], 2)
sl = roll([1, 2, 3, 4, 5], -1)
rows = roll(M, 1, axis=0)
cols = roll(M, -1, axis=1)
'''),
    },
    'errors': [
        err('An axis that does not exist', 'A matrix has axes 0 and 1.', M + 'x = sort_asc(M, axis=2);',
            M + 'x = sort_asc(M, axis=1);\npublish(x);'),
        err('An unknown flatten order', 'Use "C" or "F".', M + 'x = flatten(M, order="K");',
            M + 'x = flatten(M, order="F");\npublish(x);'),
        err('A fraction of a quarter turn', 'k must be whole.', M + 'x = rot90(M, 1.5);', M + 'x = rot90(M, 2);\npublish(x);'),
        err('sort_complex of text', 'It works on numbers.', 'x = sort_complex(["a", "b"]);',
            'x = sort_complex([2, 1i, 1]);\npublish(x);'),
    ],
}

# ================================================================== 7. Indexing and selecting
A23 = 'A = [10, 20, 30; 40, 50, 60];\n'
PAGES['indexing-selecting'] = {
    'title': 'Indexing & Selecting',
    'summary': 'Take elements by flat position, choose between values with a condition, find where a condition '
               'holds, and get the positions of diagonals and triangles.',
    'about': reference('A flat position counts the elements row by row from 0. Functions that give positions return '
                       'one row of indices per axis; one name receives them all as a list. ' + AXIS_NOTE, [
        fn('take(A, indices[, axis])', 'The elements at flat positions (the result has the shape of indices); with '
           'an axis, whole rows or columns.',
           inputs=[('A', 'array', ''), ('indices', 'positions', ''), ('axis', '0 = rows, 1 = columns', 'flat')],
           figure=fig(IMG + 'indexing-selecting-01.svg',
                      'A 2 by 3 matrix with each cell labelled by its value and its flat position 0 to 5, next to '
                      'two 3 by 3 grids marking the lower triangle and the upper triangle above the diagonal.',
                      'Left: flat positions, row by row. Right: the positions <code>tril_indices(3)</code> and '
                      '<code>triu_indices(3, k=1)</code> give.'),
           syntax='take(A, [0, 4])           # 10 50\ntake(A, [2, 0], axis=1)   # columns 2 and 0'),
        fn('where(cond, x, y)', 'Element by element: x where cond is true, y where it is false.',
           inputs=[('cond', 'true/false array (or numbers, 0 = false)', ''),
                   ('x, y', 'arrays of the same size, or single values (numbers or text)', '')],
           syntax='where(A > 25, A, 0)\nwhere([true, false], "yes", "no")'),
        fn('[r, c] = where(cond) / nonzero(A)', 'The row and column of every true (non-zero) element.',
           inputs=[('cond / A', 'array', '')], syntax='[r, c] = nonzero([0, 1; 2, 0])   # r = 0 1, c = 1 0',
           short='positions where a condition holds'),
        fn('choose(idx, c0, c1, ...)', 'Element k taken from choice number idx[k].',
           inputs=[('idx', 'whole numbers 0 to (number of choices &minus; 1)', ''),
                   ('c0, c1, ...', 'arrays of the size of idx, or single values', '')],
           syntax='choose([2, 0, 1], "low", "mid", "high")   # high low mid'),
        fn('compress(cond, A[, axis])', 'The elements (or rows or columns) where cond is true.',
           inputs=[('cond', 'one true/false per element, row or column', ''), ('A', 'array', ''),
                   ('axis', '0 or 1', 'elements')], syntax='compress([1, 0, 1], A, axis=1)   # columns 0 and 2'),
        fn('extract(cond, A)', 'The elements of A where cond is true, as one row.',
           inputs=[('cond', 'true/false array of the size of A', ''), ('A', 'array', '')],
           syntax='extract(A > 25, A)   # 30 40 50 60'),
        fn('[r, c] = diag_indices(n)', 'The positions of the main diagonal of an n x n matrix.',
           inputs=[('n', 'size', '')], syntax='[r, c] = diag_indices(3)'),
        fn('[r, c] = tril_indices(n, k=0, m) / triu_indices', 'The positions of the lower (tril) or upper (triu) '
           'triangle; <code>k</code> shifts the diagonal (1 above it, &minus;1 below), <code>m</code> is the '
           'number of columns.',
           inputs=[('n', 'rows', ''), ('k', 'diagonal offset (may be named)', '0'), ('m', 'columns (may be named)', 'n')],
           syntax='[r, c] = tril_indices(3)\n[r, c] = triu_indices(3, k=1)', short='positions of a triangle'),
        fn('[r, c] = mask_indices(n, mask="triu", k=0)', 'The same, with the triangle chosen by name.',
           inputs=[('n', 'size', ''), ('mask', '"triu" or "tril"', '"triu"'), ('k', 'diagonal offset', '0')],
           syntax='[r, c] = mask_indices(3, mask="tril", k=-1)'),
        fn('ravel_index(index, dims)', 'The flat positions of multi-indices: one row per axis '
           '(<code>[rows; cols]</code>), or one point <code>[r, c]</code>.',
           inputs=[('index', 'one row per axis, or one point', ''), ('dims', 'the shape', '')],
           math=r'\text{flat} = r \cdot n_{\text{cols}} + c', syntax='ravel_index([1, 2], [3, 4])   # 6'),
    ]),
    'examples': {
        'basic': ex('Taking elements', 'By flat position, by row and by column.', A23 + '''
a = take(A, [0, 4])
b = take(A, [0, 4; 5, 1])
last = take(A, -1)
cols = take(A, [2, 0], axis=1)
rows = take(A, [1, 1], axis=0)
'''),
        'mid': ex('Conditions', 'Choose values with <code>where</code>, find positions, and keep only the matches.', A23 + '''
w = where(A > 25, A, 0)
label = where([true, false, true], "pass", "fail")
[r, c] = where(A > 35)
publish("first match:", A[r[0, 0], c[0, 0]]);
e = extract(A > 25, A)
k = compress([false, true], A, axis=0)
even = extract([1, 2, 3, 4, 5, 6] % 2 == 0, [1, 2, 3, 4, 5, 6])
'''),
        'strong': ex('Triangles, labels and positions', 'Sum the strictly upper triangle of a matrix through its '
                     'positions, name class numbers with <code>choose</code>, and convert between multi-indices and '
                     'flat positions.', '''
K = [1, 2, 3; 4, 5, 6; 7, 8, 9];
[ur, uc] = triu_indices(3, k=1);
upper = 0;
for j = [0:numel(ur) - 1]:
   upper = upper + K[ur[0, j], uc[0, j]];
fend
publish("upper triangle above the diagonal adds up to", upper);
[lr, lc] = tril_indices(3)
classes = choose([2, 0, 1, 1], "low", "mid", "high")
f = ravel_index([0, 1; 2, 3], [3, 4])
check = take(K, ravel_index([1, 2], [3, 3]))
'''),
    },
    'errors': [
        err('A position beyond the end', 'A 2 x 3 matrix has positions 0 to 5.', A23 + 'x = take(A, 6);',
            A23 + 'x = take(A, 5);\npublish(x);'),
        err('where with only one choice', 'Give both x and y, or only the condition.', A23 + 'x = where(A > 25, A);',
            A23 + 'x = where(A > 25, A, 0);\npublish(x);'),
        err('Sizes that do not match', 'cond, x and y must have the same size, or be single values.',
            'x = where([true, false], [1, 2, 3], 0);', 'x = where([true, false, true], [1, 2, 3], 0);\npublish(x);'),
        err('A choice that does not exist', 'With two choices, idx may be 0 or 1.', 'x = choose([0, 3], [1, 2], [3, 4]);',
            'x = choose([0, 1], [1, 2], [3, 4]);\npublish(x);'),
        err('A condition of the wrong length', 'One true/false per column.',
            A23 + 'x = compress([true, false, true, true], A, axis=1);', A23 + 'x = compress([true, false, true], A, axis=1);\npublish(x);'),
        err('An unknown mask', 'Use "triu" or "tril".', '[r, c] = mask_indices(3, mask="diag");',
            '[r, c] = diag_indices(3);\npublish(r, c);'),
        err('An index outside the shape', 'Column 5 does not exist in a 3 x 4 shape.', 'x = ravel_index([0, 5], [3, 4]);',
            'x = ravel_index([0, 3], [3, 4]);\npublish(x);'),
        err('A condition that is text', 'A condition holds true/false (or numbers).', 'x = where(["a", "b"], 1, 2);',
            'x = where(["a", "b"] == "a", 1, 2);\npublish(x);'),
    ],
}

# ================================================================== 8. Reductions and running totals
A6 = 'A = [1, 2, 3; 4, 5, 6];\n'
PAGES['reductions'] = {
    'title': 'Reductions & Running Totals',
    'summary': 'Weighted averages, products, positions of the smallest and largest, counts and logical tests, and '
               'running sums and products.',
    'about': reference('A reduction takes <code>axis="all"</code> (the default: every element, one result) or an '
                       'axis number: one result per column (<code>axis=0</code>) or per row (<code>axis=1</code>). '
                       'Running totals without an axis go through the elements row by row.', [
        fn('average(A, axis="all", weights=1)', 'The weighted mean; <code>weights=1</code> is the plain mean.',
           inputs=[('A', 'numbers', ''), ('axis', '"all", 0 or 1 (may be named)', '"all"'),
                   ('weights', 'one number, or one per element along the axis (may be named)', '1')],
           math=r'\bar{x}_w = \frac{\sum_i w_i x_i}{\sum_i w_i}',
           syntax='average([1, 2, 3], weights=[3, 1, 0])   # 1.25'),
        fn('prod(A, axis="all")', 'The product of the elements.', inputs=[('A', 'real numbers', ''), ('axis', '"all", 0 or 1', '"all"')],
           math=r'\prod_i a_i', syntax='prod(A)           # 720\nprod(A, axis=0)   # 4 10 18'),
        fn('argmin(A, axis="all") / argmax', 'The position of the smallest / largest element (a flat position for '
           '"all"); the first one when several are equal.',
           inputs=[('A', 'numbers', ''), ('axis', '"all", 0 or 1', '"all"')], syntax='argmax(A)   # 5',
           short='position of the smallest / largest'),
        fn('count_nonzero(A, axis="all")', 'How many elements are not 0.', inputs=[('A', 'numbers or true/false', '')],
           syntax='count_nonzero([0, 1, 2; 0, 0, 3], axis=0)   # 0 1 2'),
        fn('all(A, axis="all") / any', 'Whether every / at least one element is true (not 0).',
           inputs=[('A', 'true/false or numbers', '')], syntax='all([1, 2, 0])   # false\nany([0, 0, 1])   # true',
           short='is every / some element true?'),
        fn('cumsum(A, axis="all") / cumprod', 'Running sums / products.', inputs=[('A', 'numbers', '')],
           math=r'S_k = \sum_{i \le k} a_i', syntax='cumsum(A)            # 1 3 6 10 15 21\ncumsum(A, axis=1)    # along every row',
           short='running sums / products'),
        fn('cumulative_sum(A, axis="all", include_initial=false) / cumulative_prod', 'The same, optionally starting '
           'with the empty sum 0 (or product 1).',
           inputs=[('A', 'numbers', ''), ('include_initial', 'true: start with 0 / 1 (may be named)', 'false')],
           syntax='cumulative_sum([1, 2, 3], include_initial=true)   # 0 1 3 6',
           short='running totals with an optional starting 0 / 1'),
    ]),
    'examples': {
        'basic': ex('Over everything, per column, per row', 'The same reductions three ways.', A6 + '''
m = average(A)
mc = average(A, axis=0)
p = prod(A)
pc = prod(A, axis=0)
pr = prod(A, axis=1)
'''),
        'mid': ex('Where and how many', 'Positions of extremes, counts, and logical tests.', A6 + '''
i = argmax(A)
j = argmin([3, 1, 2; 0, 9, 9], axis=0)
first = argmax([1, 7, 7])
n = count_nonzero([0, 1, 2; 0, 0, 3], axis=0)
a = all([1, 1; 0, 1], axis=0)
s = any([0, 0, 1])
'''),
        'strong': ex('Grades and a running balance', 'A weighted course grade per student, a running account '
                     'balance with its starting value, and compound growth with <code>cumprod</code>.', '''
marks = [72, 85, 90; 64, 70, 58];
weights = [0.2, 0.3, 0.5];
grades = average(marks, axis=1, weights=weights)
best = argmax(grades)
moves = [100, -30, 45, -20];
balance = cumulative_sum(moves, include_initial=true)
growth = cumprod([1.05, 1.05, 1.05, 1.05])
'''),
    },
    'errors': [
        err('An axis given as a word', 'axis is a number or "all".', A6 + 'x = prod(A, axis="rows");',
            A6 + 'x = prod(A, axis=1);\npublish(x);'),
        err('Weights that add up to 0', 'The weighted mean divides by the sum of the weights.',
            'x = average([1, 2], weights=[1, -1]);', 'x = average([1, 2], weights=[1, 1]);\npublish(x);'),
        err('The wrong number of weights', 'One weight, or one per element.', A6 + 'x = average(A, weights=[1, 2]);',
            A6 + 'x = average(A, axis=1, weights=[1, 2, 1]);\npublish(x);'),
        err('The product of text', 'prod works on real numbers.', 'x = prod(["a", "b"]);', 'x = prod([2, 3]);\npublish(x);'),
    ],
}

# ================================================================== 9. Missing data
PAGES['missing-data'] = {
    'title': 'Missing Data (NaN)',
    'summary': 'Find NaN and infinity, compute statistics that skip missing values, and fill gaps by a value, '
               'the previous or next reading, the mean, or a straight line.',
    'about': reference('NaN ("not a number") marks a missing reading. The <code>nan_</code> functions take the same '
                       '<code>axis</code> as the reductions and simply leave NaN out.', [
        fn('is_nan_each(A) / is_inf / is_finite / is_posinf / is_neginf', 'True/false for every element; the shape '
           'is kept.', inputs=[('A', 'real numbers', '')], syntax='is_finite([1, nan, inf])   # true false false',
           more=['<code>is_nan(x)</code> remains for a single number.'], short='find NaN and infinity, element by element'),
        fn('nan_mean, nan_median, nan_sum, nan_prod (A, axis="all")', 'The statistic with NaN left out. The sum of '
           'nothing is 0, the product 1, the mean NaN.', inputs=[('A', 'numbers', ''), ('axis', '"all", 0 or 1', '"all"')],
           syntax='nan_mean([1, nan, 3])   # 2', short='mean, median, sum, product without NaN'),
        fn('nan_min, nan_max, nan_argmin, nan_argmax (A, axis="all")', 'Smallest / largest values and their '
           'positions, NaN left out.', inputs=[('A', 'numbers', '')], syntax='nan_argmax([nan, 2, 5, nan])   # 2',
           short='extremes and their positions without NaN'),
        fn('nan_var, nan_sd (A, axis="all", ddof=0)', 'Variance and standard deviation without NaN. '
           '<code>ddof=0</code> is the population value (like <code>pvar</code>, <code>psd</code>), '
           '<code>ddof=1</code> the sample estimate (like <code>var</code>, <code>sd</code>).',
           inputs=[('A', 'numbers', ''), ('ddof', '0 or 1 (may be named)', '0')],
           math=r'\sigma^2 = \frac{1}{n - \text{ddof}} \sum_i (x_i - \bar{x})^2', short='variance and deviation without NaN'),
        fn('nan_percentile(A, q) / nan_quantile(A, q)', 'Percentiles (q from 0 to 100) or quantiles (0 to 1) with '
           'linear interpolation, NaN left out.', inputs=[('A', 'numbers', ''), ('q', 'one value or several', ''),
                                                       ('axis', '"all", 0 or 1', '"all"')],
           syntax='nan_quantile([1, 2, 3, 4], 0.5)   # 2.5'),
        fn('nan_cumsum / nan_cumprod', 'Running totals in which NaN counts as 0 (sum) or 1 (product).',
           inputs=[('A', 'numbers', '')], syntax='nan_cumsum([1, nan, 2])   # 1 1 3'),
        fn('fill_nan(A, value=0, method="value", axis=-1)', 'NaN replaced: by a value, the last reading before it '
           '("ffill"), the next one after it ("bfill"), the mean of its line ("mean"), or the straight line between '
           'its neighbours ("linear").',
           inputs=[('A', 'numbers', ''), ('value', 'used for "value", and where a neighbour is missing', '0'),
                   ('method', '"value", "ffill", "bfill", "mean" or "linear" (may be named)', '"value"'),
                   ('axis', '-1: along every row; 0: down every column', '-1')],
           figure=fig(IMG + 'missing-data-01.svg',
                      'A series of readings with two gaps, filled four ways: forward fill holds the last reading, '
                      'backward fill takes the next one, linear draws straight lines across the gaps, and mean uses '
                      'the average of the readings.',
                      'The same gaps filled by four methods of <code>fill_nan</code>.'),
           syntax='fill_nan([1, nan, nan, 4], method="linear")   # 1 2 3 4'),
    ]),
    'examples': {
        'basic': ex('Finding missing and infinite values', 'Element-by-element tests, and counting the gaps.', '''
d = [1, nan; inf, 2];
n = is_nan_each(d)
i = is_inf([1, -inf, inf])
f = is_finite([1, nan, inf])
p = is_posinf([1, -inf, inf])
gaps = sum(is_nan_each([1, nan, 3, nan]))
'''),
        'mid': ex('Statistics that skip NaN', 'The same functions as usual, with the gaps left out.', '''
v = [1, 2, 3, 4, nan];
publish("mean", nan_mean(v), " median", nan_median(v), " sum", nan_sum(v), " max", nan_max(v));
publish("population var", nan_var(v), "  sample sd", round(nan_sd(v, ddof=1), decimals=4));
publish("25th percentile", nan_percentile(v, 25), "  0.5 quantile", nan_quantile(v, 0.5));
publish("running sum", nan_cumsum([1, nan, 2]), "  running product", nan_cumprod([2, nan, 3]));
M = [1, nan; 3, 0];
cm = nan_max(M, axis=0)
'''),
        'strong': ex('Filling gaps in a sensor log', 'One log, four ways to fill its gaps, and the mean of each row '
                     'of a table.', '''
log = [5, nan, nan, 8, 9, nan, 6];
publish("ffill  ", fill_nan(log, method="ffill"));
publish("bfill  ", fill_nan(log, method="bfill"));
publish("linear ", fill_nan(log, method="linear"));
publish("mean   ", round(fill_nan(log, method="mean"), decimals=2));
publish("value 0", fill_nan(log));
T = [1, nan, 3; nan, 4, 6];
rowmean = fill_nan(T, method="mean")
colmean = fill_nan(T, method="mean", axis=0)
'''),
    },
    'errors': [
        err('Every element is NaN', 'There is no smallest or largest value to point to.', 'x = nan_argmin([nan, nan]);',
            'x = nan_argmin([nan, 2, 1]);\npublish(x);'),
        err('A percentile above 100', 'q runs from 0 to 100 (use nan_quantile for 0 to 1).',
            'x = nan_percentile([1, 2], 150);', 'x = nan_percentile([1, 2], 50);\npublish(x);'),
        err('An unknown fill method', 'NC lists the five methods.', 'x = fill_nan([1, nan], method="nearest");',
            'x = fill_nan([1, nan], method="ffill");\npublish(x);'),
        err('NaN tests on text', 'These tests work on numbers.', 'x = is_nan_each(["a"]);', 'x = is_nan_each([1, nan]);\npublish(x);'),
        err('Infinity signs of a complex number', 'A complex number has no sign of infinity.', 'x = is_posinf(1 + 2i);',
            'x = is_posinf([1, inf]);\npublish(x);'),
    ],
}

# ================================================================== 10. Histograms, bins and counting
PAGES['histograms-bins'] = {
    'title': 'Histograms, Bins & Counting',
    'summary': 'Count values in bins in one, two or more dimensions, count whole numbers, find the bin of every '
               'value, and list distinct values with their positions and counts.',
    'about': reference('Every bin holds the values from its left edge up to, but not including, its right edge; '
                       'the last bin also holds its right edge.', [
        fn('[counts, edges] = histogram(a, bins=10, density=false, range)', 'Counts of the values in each bin, and '
           'the bin edges.',
           inputs=[('a', 'numbers (without NaN unless range is given)', ''),
                   ('bins', 'number of equal bins, or the edges themselves (may be named)', '10'),
                   ('density', 'true: scale so the bars have area 1 (may be named)', 'false'),
                   ('range', '[lo, hi]: values outside are left out (may be named)', 'min to max')],
           figure=fig(IMG + 'histograms-bins-01.svg',
                      'A histogram of six values in three bins, with the edges 1, 1.67, 2.33 and 3 marked and the '
                      'counts 1, 2 and 3 above the bars.',
                      '<code>histogram([1, 2, 2, 3, 3, 3], bins=3)</code>: three equal bins between the smallest and '
                      'largest value.'),
           syntax='[h, e] = histogram([1, 2, 2, 3, 3, 3], bins=3)', short='counts per bin, and the edges'),
        fn('bin_edges(a, bins=10, range)', 'The edges <code>histogram</code> would use.',
           inputs=[('a', 'numbers', ''), ('bins', 'number of bins', '10'), ('range', '[lo, hi]', 'min to max')],
           syntax='bin_edges([0, 10], bins=5)   # 0 2 4 6 8 10'),
        fn('[H, xedges, yedges] = histogram2d(x, y, bins=10, range)', 'Counts of (x, y) pairs in a grid of bins.',
           inputs=[('x, y', 'vectors of the same length', ''), ('bins', 'number of bins per axis', '10')],
           syntax='[H, xe, ye] = histogram2d([0, 1, 1], [0, 0, 1], bins=2)', short='counts of pairs in a 2-D grid'),
        fn('[H, edges] = histogramdd(sample, bins=10, range)', 'The same in any number of dimensions; one row per point.',
           inputs=[('sample', 'one row per point', ''), ('bins', 'number of bins per axis', '10')],
           syntax='[H, E] = histogramdd([0, 0; 1, 1; 1, 0], bins=2)', short='counts in an N-D grid'),
        fn('bincount(x, weights=1, minlength=0)', 'How often each whole number 0, 1, 2 ... occurs (or the sum of '
           'its weights).', inputs=[('x', 'whole numbers &ge; 0', ''), ('weights', 'one per element (may be named)', '1'),
                                   ('minlength', 'at least this many counts (may be named)', '0')],
           syntax='bincount([0, 1, 1, 3])   # 1 2 0 1'),
        fn('digitize(x, bins, right=false)', 'The bin number of each value: i means bins[i&minus;1] &le; x &lt; '
           'bins[i].', inputs=[('x', 'values', ''), ('bins', 'sorted edges (increasing or decreasing)', ''),
                               ('right', 'true: bins[i&minus;1] &lt; x &le; bins[i] (may be named)', 'false')],
           syntax='digitize([0.2, 6.4, 3.0, 1.6], [0, 1, 2.5, 4, 10])   # 1 4 3 2'),
        fn('[values, indices, inverse, counts] = unique_all(A)', 'The distinct values (sorted), where each first '
           'occurs, the place of every element in values, and how often each occurs.',
           inputs=[('A', 'array', '')], more=['<code>take(values, inverse)</code> rebuilds A.'],
           syntax='[v, i, inv, c] = unique_all([3, 1, 3, 2, 1, 3])', short='distinct values with positions and counts'),
    ]),
    'examples': {
        'basic': ex('A first histogram', 'Counts and edges, densities, and a fixed range.', '''
[h, e] = histogram([1, 2, 2, 3, 3, 3], bins=3)
[hd, ed] = histogram([1, 2, 2, 3, 3, 3], bins=3, density=true);
area = sum(hd) * (ed[0, 1] - ed[0, 0])
[hr, er] = histogram([0, 5, 15], bins=2, range=[0, 10])
[hb, eb] = histogram([1, 4, 6], bins=[0, 5, 10])
'''),
        'mid': ex('Counting whole numbers and finding bins', '<code>bincount</code> with weights, and '
                  '<code>digitize</code> both ways.', '''
c = bincount([0, 1, 1, 3])
w = bincount([0, 1, 1], weights=[0.5, 1, 2], minlength=4)
d = digitize([0.2, 6.4, 3.0, 1.6], [0, 1, 2.5, 4, 10])
dr = digitize([1, 2.5], [0, 1, 2.5, 4], right=true)
dd = digitize([0.2, 6.4], [10, 4, 2.5, 1, 0])
'''),
        'strong': ex('Grading and a 2-D count', 'Marks sorted into grade bands with <code>digitize</code> and '
                     'counted with <code>bincount</code>; distinct values with their bookkeeping; and a 2-D '
                     'histogram of points.', '''
marks = [35, 48, 52, 67, 71, 74, 88, 93];
band = digitize(marks, [0, 40, 60, 75, 101]);
publish("bands (1 = fail ... 4 = distinction):", band);
publish("students per band:", bincount(band, minlength=5));
data = [3, 1, 3, 2, 1, 3];
[v, i, inv, c] = unique_all(data)
rebuilt = equal(take(v, inv), data)
[H2, xe, ye] = histogram2d([0, 1, 1], [0, 0, 1], bins=2)
'''),
    },
    'errors': [
        err('NaN in a histogram', 'Remove NaN first, or give range=[lo, hi].', 'x = histogram([1, nan, 3]);',
            '[x, e] = histogram([1, nan, 3], range=[0, 4], bins=2);\npublish(x);'),
        err('Edges that go back', 'Bin edges must increase.', 'x = histogram([1, 2], bins=[0, 5, 3]);',
            '[x, e] = histogram([1, 2], bins=[0, 3, 5]);\npublish(x);'),
        err('A negative number in bincount', 'bincount counts whole numbers from 0.', 'x = bincount([1, -1]);',
            'x = bincount([1, 1]);\npublish(x);'),
        err('Unsorted bins in digitize', 'The edges must be sorted.', 'x = digitize([1], [0, 5, 3]);',
            'x = digitize([1], [0, 3, 5]);\npublish(x);'),
    ],
}

# ================================================================== 11. Sequences
PAGES['sequences'] = {
    'title': 'Gradients, Areas & Interpolation',
    'summary': 'Cross-correlation, the rate of change of sampled data, the area under a curve by the trapezoid '
               'rule, and straight-line interpolation.',
    'about': reference('Functions for data sampled along a line: a signal in time, a profile along a distance.', [
        fn('correlate(a, v, mode="valid")', 'The cross-correlation of two vectors: how well v matches a at each shift.',
           inputs=[('a, v', 'vectors', ''), ('mode', '"valid", "same" or "full" (may be named)', '"valid"')],
           math=r'c_k = \sum_n a_{n+k}\, v_n',
           syntax='correlate([1, 2, 3], [0, 1, 0.5], mode="full")   # 0.5 2 3.5 3 0'),
        fn('gradient(f, spacing=1, axis="all")', 'The rate of change: central differences inside, one-sided at the '
           'ends. A matrix gives two results, down the rows and across the columns.',
           inputs=[('f', 'samples', ''), ('spacing', 'one step size, or the coordinates (may be named)', '1'),
                   ('axis', '"all", 0 or 1', '"all"')],
           math=r"f'(x_i) \approx \frac{f_{i+1} - f_{i-1}}{x_{i+1} - x_{i-1}}",
           syntax='gradient([1, 2, 4, 7, 11])              # 1 1.5 2.5 3.5 4\n[gr, gc] = gradient([1, 2, 6; 3, 4, 5])'),
        fn('trapz(y, dx=1, axis=-1, x)', 'The area under the curve by the trapezoid rule; a matrix gives one area '
           'per row.', inputs=[('y', 'samples', ''), ('dx', 'step size (may be named)', '1'),
                               ('x', 'the coordinates, instead of dx (may be named, or the second value)', ''),
                               ('axis', 'which axis', '-1')],
           math=r'\int y\,dx \approx \sum_i \frac{y_i + y_{i+1}}{2}\,(x_{i+1} - x_i)',
           figure=fig(IMG + 'sequences-01.svg',
                      'Left: samples joined by straight lines with the trapezoids under them shaded; their total '
                      'area is what trapz gives. Right: three known points and interpolated values on the straight '
                      'lines between them, with values outside the range held at the end values.',
                      'Left: <code>trapz</code> adds up trapezoids. Right: <code>interp</code> reads values off the '
                      'straight lines between known points.'),
           syntax='trapz([1, 2, 3])               # 4\ntrapz([1, 2, 3], x=[4, 6, 8])  # 8'),
        fn('interp(x, xp, fp, left="end", right="end")', 'Straight-line interpolation: the value at x on the line '
           'through the points (xp, fp).',
           inputs=[('x', 'where to read', ''), ('xp', 'known x positions, increasing', ''), ('fp', 'known values', ''),
                   ('left, right', 'values to the left / right of xp (may be named)', 'the end values')],
           math=r'f(x) = f_i + \frac{f_{i+1} - f_i}{x_{i+1} - x_i}\,(x - x_i)',
           syntax='interp(1.5, [1, 2], [10, 20])   # 15'),
    ]),
    'examples': {
        'basic': ex('Areas and slopes', 'The trapezoid rule with steps and with coordinates, and gradients.', '''
a = trapz([1, 2, 3])
b = trapz([1, 2, 3], x=[4, 6, 8])
rows = trapz([1, 2, 3; 4, 5, 6])
g = gradient([1, 2, 4, 7, 11])
g2 = gradient([1, 2, 4, 7, 11], spacing=2)
gu = gradient([1, 2, 4, 7, 11], spacing=[0, 1, 1.5, 3.5, 4])
'''),
        'mid': ex('Interpolation and correlation', 'Reading values between points and outside them, and matching '
                  'a pattern.', '''
i = interp([2.5, 0, 9], [1, 2, 3], [3, 2, 0])
lr = interp([0, 9], [1, 2, 3], [3, 2, 0], left=-1, right=99)
cv = correlate([1, 2, 3], [0, 1, 0.5])
cs = correlate([1, 2, 3], [0, 1, 0.5], mode="same")
cf = correlate([1, 2, 3], [0, 1, 0.5], mode="full")
'''),
        'strong': ex('From speed to distance', 'A car\'s speed every 2 s: the distance travelled (area under the '
                     'speed), the acceleration (gradient of the speed), and the speed at 5 s read by interpolation.', '''
t = [0, 2, 4, 6, 8, 10];
v = [0, 6, 11, 15, 18, 20];
distance = trapz(v, x=t)
accel = gradient(v, spacing=2)
v5 = interp(5, t, v)
[gr, gc] = gradient([1, 2, 6; 3, 4, 5])
'''),
    },
    'errors': [
        err('An unknown correlate mode', 'Use "valid", "same" or "full".', 'x = correlate([1, 2], [1], mode="middle");',
            'x = correlate([1, 2], [1], mode="same");\npublish(x);'),
        err('A gradient of one point', 'A rate of change needs at least two points.', 'x = gradient([5]);',
            'x = gradient([5, 7]);\npublish(x);'),
        err('Too few coordinates', 'One x per sample.', 'x = trapz([1, 2, 3], x=[1, 2]);',
            'x = trapz([1, 2, 3], x=[1, 2, 3]);\npublish(x);'),
        err('Known positions that go back', 'xp must increase.', 'x = interp([1], [3, 2, 1], [1, 2, 3]);',
            'x = interp([1], [1, 2, 3], [3, 2, 1]);\npublish(x);'),
    ],
}

# ================================================================== 12. Text functions
PAGES['text-functions'] = {
    'title': 'Text Functions',
    'summary': 'Join, split, strip, search, count, pad and measure text, one text at a time or element by element '
               'on a matrix of text.',
    'about': reference('Lengths and positions count characters, not bytes ("日本語" has 3), and positions start at '
                       '0. <code>upper</code>, <code>lower</code>, <code>replace</code> and <code>substr</code> also '
                       'remain available.', [
        fn('str_concat(a, b)', 'a and b joined.', inputs=[('a, b', 'text, or matrices of text', '')],
           syntax='str_concat(["a", "b"], "!")   # a! b!'),
        fn('split_str(s, sep="", maxsplit=-1)', 'The parts of s, as a row of text. With <code>sep=""</code> it '
           'splits at runs of spaces and drops empty parts.',
           inputs=[('s', 'text', ''), ('sep', 'separator (may be named)', '"" (spaces)'),
                   ('maxsplit', 'at most this many splits; -1 = all (may be named)', '-1')],
           syntax='split_str("a,b,,c", sep=",")   # a  b  ""  c'),
        fn('join(sep, texts)', 'The texts joined with sep between them.', inputs=[('sep', 'text', ''), ('texts', 'row of text', '')],
           syntax='join("-", ["2026", "10", "28"])   # 2026-10-28'),
        fn('strip(T, chars="")', 'T without leading and trailing spaces (or the given characters).',
           inputs=[('T', 'text', ''), ('chars', 'characters to remove (may be named)', 'spaces')],
           syntax='strip("xxhixx", chars="x")   # hi'),
        fn('find_str(T, sub) / count_str(T, sub)', 'The first position of sub (&minus;1 when absent) / how often '
           'sub occurs, without overlapping.', inputs=[('T', 'text', ''), ('sub', 'text to look for', '')],
           syntax='find_str("hello", "l")     # 2\ncount_str("banana", "an")  # 2', short='position of / number of a part'),
        fn('starts_with(T, prefix) / ends_with(T, suffix)', 'Whether T begins / ends with the given text.',
           inputs=[('T', 'text', ''), ('prefix / suffix', 'text', '')], syntax='ends_with("report.nc", ".nc")   # true'),
        fn('center(T, width, fill=" ")', 'T in the middle of <code>width</code> characters.',
           inputs=[('T', 'text', ''), ('width', 'total width', ''), ('fill', 'one character (may be named)', '" "')],
           syntax='center("ab", 5, fill="*")   # **ab*'),
        fn('zfill(T, width)', 'Zeros added on the left, after any sign, up to <code>width</code> characters.',
           inputs=[('T', 'text', ''), ('width', 'total width', '')], syntax='zfill("-42", 5)   # -0042'),
        fn('is_digit(T) / str_len(T)', 'Whether T is non-empty and only the digits 0&ndash;9 / the number of '
           'characters.', inputs=[('T', 'text', '')], syntax='is_digit("123")   # true\nstr_len("日本語")  # 3',
           short='only digits? / number of characters'),
    ]),
    'examples': {
        'basic': ex('Splitting and joining', 'Split at spaces and at a separator, then join back.', '''
w = split_str("  the quick  brown fox ")
p = split_str("a,b,,c", sep=",")
m = split_str("a b c d", maxsplit=2)
d = join("-", ["2026", "10", "28"])
back = join(",", split_str("x,y,z", sep=","))
'''),
        'mid': ex('Searching and testing', 'Positions, counts, prefixes and suffixes, element by element.', '''
f = find_str(["hello", "world"], "o")
n = count_str("banana", "an")
s = starts_with(["apple", "banana"], "ap")
e = ends_with("report.nc", ".nc")
k = find_str("日本語テキスト", "テ")
l = str_len(["héllo", "日本語", ""])
'''),
        'strong': ex('Tidying a list of part numbers', 'Strip, test, pad and line up a column of entries typed by '
                     'hand.', '''
raw = ["  42 ", "7", " 1305", "x9 "];
codes = strip(raw)
ok = is_digit(codes)
publish("valid entries:", extract(ok, codes));
padded = zfill(extract(ok, codes), 6)
for k = [0:numel(padded) - 1]:
   publish("|" + center(padded[0, k], 10, fill=".") + "|");
fend
tagged = str_concat("PN-", padded)
'''),
    },
    'errors': [
        err('A number where text is needed', 'Turn numbers into text with str().', 'x = str_concat("a", 5);',
            'x = str_concat("a", str(5));\npublish(x);'),
        err('A fill of two characters', 'fill is exactly one character.', 'x = center("ab", 6, fill="**");',
            'x = center("ab", 6, fill="*");\npublish(x);'),
        err('Joining numbers', 'Every element must be text.', 'x = join("-", [1, 2]);', 'x = join("-", ["1", "2"]);\npublish(x);'),
        err('The length of a number', 'str_len counts the characters of text.', 'x = str_len(5);',
            'x = str_len(str(5));\npublish(x);'),
    ],
}
