"""Default Functions - Engineering Mathematics (source: Function_Test/Code/A_07_Engineering_Math, scripts 02-07 and
error_tests E1-E6; script 01 extends the Traditional Mathematics Calculus page).

The examples follow Kreyszig, Advanced Engineering Mathematics; every one is run through nc.exe by
build_default_functions.py and compared there with the textbook result.
"""
from df_helpers import err, ex, fig, fn, reference

IMG = 'Images/Neural_Code/Default_Functions/Engineering_Math/'
TM = '../Traditional_Math/'
PAGES = {}

GRID = 'x = space(0, 1, 11);\n[X, Y] = meshgrid(x, x);\n'

# ================================================================== 1. Vector calculus
CUBE = '''n = 6;
h = 1 / (n - 1);
U = zeros([n, n, n]);
V = zeros([n, n, n]);
W = zeros([n, n, n]);
for k = [0:n - 1]:
   for i = [0:n - 1]:
      for j = [0:n - 1]:
         U[k, i, j] = (j * h) * (i * h);
         V[k, i, j] = (i * h) * (k * h);
         W[k, i, j] = (k * h) * (j * h);
      fend
   fend
fend
'''
PAGES['vector-calculus'] = {
    'title': 'Vector Calculus',
    'summary': 'Curves with their length, curvature and torsion; directional derivatives; divergence and curl on grids; '
               'line, surface and volume integrals; conservative fields and potentials; and Gauss\'s divergence theorem.',
    'about': reference('Layouts: a <strong>curve</strong> is a matrix with one point per row, [x, y, z]; a <strong>2-D '
                       'grid</strong> has rows along y and columns along x (as <code>meshgrid</code> gives); a '
                       '<strong>3-D grid</strong> is an N-D matrix [nz, ny, nx]; a <strong>surface</strong> is three grids '
                       'X, Y, Z of one shape. Green\'s and Stokes\'s theorems are on <a href="' + TM + 'calculus.html">'
                       'Calculus</a>.', [
        fn('arc_length3(curve)', 'The cumulative arc length along the points, starting at 0.',
           inputs=[('curve', 'one point per row, [x, y] or [x, y, z]', '')], math=r's(t) = \int_{t_0}^{t} |r\'(\tau)|\,d\tau',
           syntax='s = arc_length3(C);   # s[end] is the length'),
        fn('frenet_frames(curve[, t])', 'The unit tangent T, normal N and binormal B at every point, and the curvature '
           '&kappa; and torsion &tau;: a dictionary {T, N, B, kappa, tau}.',
           inputs=[('curve', 'one point per row, at least 5 points', ''), ('t', 'the curve parameter', '0, 1, 2, ...')],
           math=r'\kappa = \frac{|r\' \times r\'\'|}{|r\'|^3}, \qquad \tau = \frac{(r\' \times r\'\') \cdot r\'\'\'}{|r\' \times r\'\'|^2}',
           figure=fig(IMG + 'vector-calculus-01.svg',
                      'A helix in 3-D with the tangent, normal and binormal arrows drawn at three points along it.',
                      'The helix r(t) = [cos t, sin t, t] with its Frenet frame T (tangent), N (normal), B (binormal). Its '
                      'curvature and torsion are both 1/2.'),
           short='tangent, normal, binormal, curvature, torsion'),
        fn('directional_deriv(@f, point, a) / directional_deriv(F, a, dx, dy[, dz])', 'The rate of change of a scalar field '
           'in the direction of a, at a point or over a grid.', math=r'D_a f = \nabla f \cdot \frac{a}{|a|}',
           syntax='directional_deriv(@f, [2, 1, 3], [1, 0, -2])', short='rate of change along a direction'),
        fn('div(U, V[, W], dx, dy[, dz]) / div(@F, point)', 'The divergence of a vector field on a 2-D or 3-D grid, or at a '
           'point.', math=r'\nabla \cdot F = \frac{\partial F_1}{\partial x} + \frac{\partial F_2}{\partial y} + \frac{\partial F_3}{\partial z}',
           syntax='D = div(U, V, W, h, h, h);', short='divergence'),
        fn('curl(U, V, W, dx, dy, dz)', 'The curl on a 3-D grid: a dictionary {x, y, z} of three grids (other forms on '
           '<a href="' + TM + 'calculus.html">Calculus</a>).', short='curl on a 3-D grid'),
        fn('integrate_line(@F, path)', 'The work integral of F along a path of straight segments (Simpson\'s rule on '
           'each).', inputs=[('F', 'a field F(x, y[, z]) returning its components', ''), ('path', 'one point per row', '')],
           math=r'\int_C F(r) \cdot dr', short='line integral (work)'),
        fn('is_conservative(U, V[, W], tol, dx, dy[, dz]) / potential_field(U, V[, W], spacing)', 'Whether curl F = 0 '
           '(path independence), and the potential f with &nabla;f = F, f = 0 at the first grid point.',
           math=r'F = \nabla f \iff \nabla \times F = 0 \;\text{(simply connected)}', short='conservative test and potential'),
        fn('integrate_surface(F, X, Y, Z)', 'The flux of F through a parametric surface r(u, v) with normal '
           'r<sub>u</sub> &times; r<sub>v</sub>; F is a function or a dictionary {x, y, z} of its values on the grid.',
           math=r'\iint_S F \cdot n\,dA = \iint F(r(u,v)) \cdot (r_u \times r_v)\,du\,dv', short='flux through a surface'),
        fn('integrate_volume(G, dx, dy[, dz])', 'A double or triple integral of a grid, by Simpson\'s rule.',
           math=r'\iiint_T f\,dV', short='double and triple integrals'),
        fn('eval_gauss_divergence(U, V[, W], dx, dy[, dz])', 'Both sides of the divergence theorem on the grid\'s box: '
           '{volume_integral, surface_flux}.',
           math=r'\iiint_T \nabla \cdot F\,dV = \iint_S F \cdot n\,dA',
           figure=fig(IMG + 'vector-calculus-02.svg',
                      'A box with arrows of a vector field leaving through its faces; the total outward flux through the six '
                      'faces equals the integral of the divergence over the inside of the box.',
                      'Gauss\'s theorem: what flows out through the faces equals what is produced inside.'),
           short='Gauss\'s divergence theorem, both sides'),
    ]),
    'examples': {
        'basic': ex('A helix', 'Length, curvature and torsion of one turn of r(t) = [cos t, sin t, t] (Kreyszig 9.5): '
                    '2&pi;&radic;2, 1/2 and 1/2.', '''
t = space(0, 2 * pi, 401);
C = transpose([cos(t); sin(t); t]);
s = arc_length3(C);
fr = frenet_frames(C, t);
publish("length:", s[400], "  2 pi sqrt(2) =", 2 * pi * sqrt(2));
publish("curvature:", fr["kappa"][200], "  torsion:", round(fr["tau"][200], decimals=6));
publish("directional derivative (Kreyszig 9.7):", directional_deriv(@ellipsoid, [2, 1, 3], [1, 0, -2]), " = -4/sqrt(5)");
function f = ellipsoid(x, y, z):
   f = 2 * x ^ 2 + 3 * y ^ 2 + z ^ 2;
fnend
'''),
        'mid': ex('Work and potentials', 'Line integrals from Kreyszig 10.1, a gradient field and its potential.', GRID + '''
function F = k101(x, y):
   F = [-1 * y, -1 * x * y];
fnend
function F = helix_field(x, y, z):
   F = [z, x, y];
fnend
q = space(0, pi / 2, 801);
quarter = transpose([cos(q); sin(q)]);
publish("quarter circle:", integrate_line(@k101, quarter), "  pi/4 - 1/3 =", pi / 4 - 1 / 3);
th = space(0, 2 * pi, 801);
hel = transpose([cos(th); sin(th); 3 * th]);
publish("helix:", integrate_line(@helix_field, hel), "  7 pi =", 7 * pi);
c1 = is_conservative(2 * X, 2 * Y, 1e-6, 0.1, 0.1);
c2 = is_conservative(-1 * Y, X, 1e-6, 0.1, 0.1);
publish("[2x, 2y] conservative:", c1["conservative"], "  [-y, x]:", c2["conservative"]);
pf = potential_field(2 * X, 2 * Y, [0.1, 0.1]);
publish("potential = x^2 + y^2:", allclose(pf, X ^. 2 + Y ^. 2, atol=1e-12));
'''),
        'strong': ex('Flux and Gauss\'s theorem', 'The flux through y = x<sup>2</sup> (Kreyszig 10.6: 72), a triple '
                     'integral, and both sides of the divergence theorem for F = [xy, yz, zx] on the unit cube (3/2).', CUBE + '''
function F = cyl(x, y, z):
   F = [3 * z ^ 2, 6, 6 * x * z];
fnend
[SU, SV] = meshgrid(space(0, 2, 21), space(0, 3, 31));
publish("flux through y = x^2:", integrate_surface(@cyl, SU, SU ^. 2, SV));
D = div(U, V, W, h, h, h);
publish("div at the centre slab corner:", D[2][0, 0]);
g = eval_gauss_divergence(U, V, W, h, h, h);
publish("volume integral of div F:", g["volume_integral"], "  outward flux:", g["surface_flux"]);
'''),
    },
    'errors': [
        err('Grids of different shapes', 'The components of a field must be grids of one shape.',
            'Z = [1, 2; 3, 4];\nv = div(Z, [1, 2, 3; 4, 5, 6]);', 'Z = [1, 2; 3, 4];\nv = div(Z, Z);\npublish(v);'),
        err('A curve written as a row', 'A curve has one point per row.', 'a = arc_length3([1, 2, 3, 4]);',
            'a = arc_length3([0, 0, 0; 1, 1, 1]);\npublish(a);'),
        err('Too few points for a Frenet frame', 'Curvature and torsion need at least 5 points.',
            'fr = frenet_frames([0, 0, 0; 1, 1, 1; 2, 2, 2]);',
            't = space(0, 1, 5);\nfr = frenet_frames(transpose([cos(t); sin(t); t]), t);\npublish(round(fr["kappa"], decimals=3));'),
        err('A zero direction', 'A direction needs a length.', 'Z = [1, 2; 3, 4];\ndd = directional_deriv(Z, [0, 0]);',
            'Z = [1, 2; 3, 4];\ndd = directional_deriv(Z, [1, 0]);\npublish(dd);'),
    ],
}

# ================================================================== 2. ODE analysis
PAGES['ode-analysis'] = {
    'title': 'ODEs: Fields, Phase Plane & Series',
    'summary': 'The qualitative and series tools for ordinary differential equations: direction fields, Picard '
               'iteration, Wronskians, variation of parameters, resonance, phase planes and critical points, power '
               'series, Frobenius roots and Sturm&ndash;Liouville eigenvalues.',
    'about': reference('To integrate an ODE step by step use <code>ode_solve</code> or <code>odeint</code> (see <a href="'
                       '../Scientific_Library/integration-odes.html">Derivatives, Integration &amp; ODEs</a>). Functions '
                       'are passed as <code>@f</code>; a system of two equations is one function returning '
                       '[x1&prime;, x2&prime;].', [
        fn('direction_field(@f, x, y) / orthogonal_trajectories(@f, x, y)', 'The slope field of y&prime; = f(x, y) on a '
           'grid as unit arrows {X, Y, U, V, slope}, and the field of the orthogonal family.',
           figure=fig(IMG + 'ode-analysis-01.svg',
                      'Short arrows on a grid showing the slope x - y everywhere, with three solution curves of y\' = x - y '
                      'following the arrows and approaching the line y = x - 1.',
                      'The direction field of y&prime; = x &minus; y and three solutions that follow it.'),
           short='slope fields'),
        fn('picard_iteration(@f, y0, t, n)', 'Picard\'s successive approximations of y&prime; = f(t, y); row k is '
           'y<sub>k</sub> on t.', math=r'y_{k+1}(t) = y_0 + \int_{t_0}^{t} f(s, y_k(s))\,ds', short='Picard iteration'),
        fn('wronskian(Y, t) / wronskian(["y1", "y2", ...], t)', 'The Wronskian of solutions given as samples or as '
           'function names; nonzero means independent.', math=r'W = \det\begin{pmatrix} y_1 & y_2 \\ y_1\' & y_2\' \end{pmatrix}'),
        fn('variation_of_parameters(y1, y2, r, x)', 'A particular solution of y&prime;&prime; + p y&prime; + q y = r from '
           'two independent solutions.', math=r'y_p = -y_1 \int \frac{y_2 r}{W}\,dx + y_2 \int \frac{y_1 r}{W}\,dx',
           short='particular solution'),
        fn('resonance_peak(m, c, k, omega_range[, F0])', 'The amplitude of m y&prime;&prime; + c y&prime; + k y = '
           'F<sub>0</sub> cos &omega;t against &omega;, and its maximum: {omega_peak, amplitude_peak, omega0, omega, '
           'amplitude, phase}.', math=r'C(\omega) = \frac{F_0}{\sqrt{(k - m\omega^2)^2 + c^2\omega^2}}',
           figure=fig(IMG + 'ode-analysis-02.svg',
                      'Amplitude curves of a forced oscillator with m = 1 and k = 4 for damping 0.25, 0.5 and 1: the '
                      'smaller the damping, the taller and sharper the peak near omega = 2.',
                      'Resonance: the response of m y&prime;&prime; + c y&prime; + k y = cos &omega;t for three dampings.'),
           short='resonance curve'),
        fn('phase_plane(F, x1, x2) / find_critical_points(F, box) / classify_critical_point(J)', 'The vector field of an '
           'autonomous system, its critical points in a box, and the type and stability of a critical point from its '
           'Jacobian (center, saddle, spiral, node).',
           math=r'p = \operatorname{tr} J,\quad q = \det J,\quad \Delta = p^2 - 4q',
           figure=fig(IMG + 'ode-analysis-03.svg',
                      'The phase plane of the undamped pendulum: closed orbits around the centers at 0 and plus or minus 2 '
                      'pi, saddles at plus and minus pi, and running orbits above and below.',
                      'The pendulum x&prime;&prime; = &minus;sin x in its phase plane: centers at 0, saddles at '
                      '&plusmn;&pi;.'),
           short='phase plane and critical points'),
        fn('power_series_coeffs(p, q, r, x0, N[, ic])', 'The first N coefficients of the power-series solutions of '
           'y&prime;&prime; + p y&prime; + q y = r around x0: {y1, y2, yp, y}.', short='power-series solutions'),
        fn('frobenius_roots(b0, c0)', 'The roots of the indicial equation and the case of Frobenius\'s theorem.',
           math=r'r(r-1) + b_0 r + c_0 = 0', short='indicial roots'),
        fn('sturm_liouville_solve(p, q, r, bc_a, bc_b, N[, M])', 'The first N eigenvalues and eigenfunctions of a '
           'Sturm&ndash;Liouville problem.', math=r'[p y\']\' + [q + \lambda r] y = 0', short='eigenvalue problems'),
    ]),
    'examples': {
        'basic': ex('Fields and Picard', 'A direction field, and Picard\'s approximations of y&prime; = y, which build '
                    'the series of e<sup>t</sup>.', '''
function s = slope(x, y):
   s = x - y;
fnend
function s = growth(t, y):
   s = y;
fnend
df = direction_field(@slope, space(-2, 2, 5), space(-1, 1, 3));
s = df["slope"]
t = space(0, 1, 101);
P = picard_iteration(@growth, 1, t, 4);
publish("y_4(1) =", P[4, 100], "  e =", exp(1));
'''),
        'mid': ex('Second-order equations', 'The Wronskian of cos and sin, a particular solution of y&prime;&prime; + y '
                  '= sec x (Kreyszig 2.10), and a resonance peak.', '''
function y = c1(x):
   y = cos(x);
fnend
function y = s1(x):
   y = sin(x);
fnend
function r = secant(x):
   r = 1 / cos(x);
fnend
publish("W(cos, sin):", wronskian(["c1", "s1"], [0, 0.5, 1]));
xv = space(0, 1.2, 241);
yp = variation_of_parameters(@c1, @s1, @secant, xv);
publish("matches cos x ln(cos x) + x sin x:", allclose(yp, cos(xv) *. log(cos(xv)) + xv *. sin(xv), atol=1e-6));
rp = resonance_peak(1, 0.5, 4, [0, 4]);
publish("peak at omega =", rp["omega_peak"], " amplitude", rp["amplitude_peak"]);
'''),
        'strong': ex('The pendulum, series and eigenvalues', 'Critical points of the pendulum and their types; power '
                     'series of cos and sin; the eigenvalues 1, 4, 9, 16 of y&prime;&prime; + &lambda;y = 0 on [0, &pi;].', '''
function d = pendulum(x1, x2):
   d = [x2, -1 * sin(x1)];
fnend
cp = find_critical_points(@pendulum, [-4, 4, -1, 1])
c0 = classify_critical_point([0, 1; -1, 0]);
c1 = classify_critical_point([0, 1; 1, 0]);
publish("at (0, 0):", c0["type"], "/", c0["stability"], "   at (pi, 0):", c1["type"]);
ps = power_series_coeffs(0, 1, 0, 0, 7);
publish("y1:", ps["y1"]);
fb = frobenius_roots(1, -0.25);
publish("Bessel 1/2 roots:", fb["r1"], fb["r2"], " case", fb["case"]);
sl = sturm_liouville_solve(1, 0, 1, [0, 1, 0], [pi, 1, 0], 4);
publish("eigenvalues:", round(sl["eigenvalues"], decimals=4));
'''),
    },
    'errors': [
        err('t that goes back', 'Picard iteration runs forwards in t.', 'function z = f2(t, y):\n   z = t * y;\nfnend\npc = picard_iteration(@f2, 1, [0, 1, 0.5], 3);',
            'function z = f2(t, y):\n   z = t * y;\nfnend\npc = picard_iteration(@f2, 1, [0, 0.5, 1], 3);\npublish(size(pc));'),
        err('Negative damping', 'The damping c cannot be negative.', 'rp = resonance_peak(1, -1, 4, [0, 4]);',
            'rp = resonance_peak(1, 1, 4, [0, 4]);\npublish(rp["omega_peak"]);'),
        err('A 3 x 3 Jacobian', 'classify_critical_point works on systems of two equations.',
            'cc = classify_critical_point([1, 2, 3; 4, 5, 6; 7, 8, 9]);', 'cc = classify_critical_point([0, 1; -1, 0]);\npublish(cc["type"]);'),
        err('An empty interval', 'Sturm&ndash;Liouville needs b &gt; a.', 'sl = sturm_liouville_solve(1, 0, 1, [0, 1, 0], [0, 1, 0], 3);',
            'sl = sturm_liouville_solve(1, 0, 1, [0, 1, 0], [pi, 1, 0], 3);\npublish(round(sl["eigenvalues"], decimals=3));'),
    ],
}

# ================================================================== 3. Laplace transforms
PAGES['laplace-transforms'] = {
    'title': 'Laplace Transforms & Integral Equations',
    'summary': 'The Laplace transform of a function and its numerical inverse, unit impulses, and Volterra integral '
               'equations.',
    'about': reference('The transform turns differential equations into algebra; the inverse brings the answer back.', [
        fn('laplace_transform(@f, s)', 'F(s) at the given s (real or complex).',
           math=r'F(s) = \mathcal{L}\{f\}(s) = \int_0^\infty e^{-st} f(t)\,dt',
           table=[['f(t)', 'F(s)'], ['1', '1/s'], ['e<sup>at</sup>', '1/(s &minus; a)'], ['sin &omega;t', '&omega;/(s<sup>2</sup> + &omega;<sup>2</sup>)'],
                  ['cos &omega;t', 's/(s<sup>2</sup> + &omega;<sup>2</sup>)'], ['t<sup>n</sup>', 'n!/s<sup>n+1</sup>']]),
        fn('inv_laplace_transform(@F, t[, method][, M])', 'f(t) from F(s): "talbot" (default, very accurate; F must '
           'accept complex s) or "stehfest" (real s only, about 4&ndash;5 digits).',
           inputs=[('t', 'positive times', ''), ('method', '"talbot" or "stehfest"', '"talbot"'), ('M', 'terms (even for Stehfest)', '14')],
           short='numerical inverse transform'),
        fn('dirac_delta_approx(t, t0, width[, shape])', 'A unit impulse at t0 on the samples t: "rect" (height 1/k on '
           '[t0, t0 + k)) or "gauss".', math=r'\int \delta(t - t_0)\,dt = 1', short='unit impulse'),
        fn('solve_volterra_eq(k, f, t)', 'The solution of a Volterra integral equation of the second kind; k(t &minus; '
           '&tau;) when k takes one input.', math=r'y(t) = f(t) + \int_{t_0}^{t} k(t, \tau)\,y(\tau)\,d\tau',
           short='Volterra integral equations'),
    ]),
    'examples': {
        'basic': ex('Transforms of simple functions', 'L(1), L(e<sup>2t</sup>) and L(sin t) against the table.', '''
function y = one(t):
   y = 1;
fnend
function y = sint(t):
   y = sin(t);
fnend
s = [1, 2, 3];
publish("L(1)     :", laplace_transform(@one, s), "  1/s:", 1 /. s);
publish("L(sin t) :", laplace_transform(@sint, s), "  1/(s^2+1):", 1 /. (s ^. 2 + 1));
'''),
        'mid': ex('Back again', 'Inverting 1/(s + 1) and 1/(s<sup>2</sup> + 1) with both methods.', '''
function F = lap_exp(s):
   F = 1 / (s + 1);
fnend
function F = lap_sin(s):
   F = 1 / (s ^ 2 + 1);
fnend
t = [0.5, 1, 2, 5];
publish("talbot  :", inv_laplace_transform(@lap_exp, t), "  e^-t:", exp(-1 * t));
publish("talbot  :", inv_laplace_transform(@lap_sin, t), "  sin t:", sin(t));
publish("stehfest:", inv_laplace_transform(@lap_exp, t, "stehfest"));
'''),
        'strong': ex('Impulses and an integral equation', 'Two impulses of area 1, and y &minus; &int; y(&tau;) '
                     'sin(t &minus; &tau;) d&tau; = t, whose solution is t + t<sup>3</sup>/6 (Kreyszig 6.5).', '''
function k = sine_kernel(u):
   k = sin(u);
fnend
function f = ramp(t):
   f = t;
fnend
td = space(0, 2, 2001);
publish("rect area:", round(sum(dirac_delta_approx(td, 1, 0.1)) * 0.001, decimals=3), "  gauss area:", round(sum(dirac_delta_approx(td, 1, 0.05, "gauss")) * 0.001, decimals=6));
tv = space(0, 1, 201);
yv = solve_volterra_eq(@sine_kernel, @ramp, tv);
publish("y(1) =", yv[200], "  exact 1 + 1/6 =", 1 + 1 / 6);
'''),
    },
    'errors': [
        err('A transform that does not converge', 'e<sup>&minus;st</sup> f(t) must decay: use a larger s.',
            'function y = f1(x):\n   y = x ^ 2;\nfnend\nlt = laplace_transform(@f1, -1);',
            'function y = f1(x):\n   y = x ^ 2;\nfnend\nlt = laplace_transform(@f1, 1);\npublish(lt);'),
        err('Time zero in the inverse', 'Every t must be positive.', 'function F = g(s):\n   F = 1 / (s + 1);\nfnend\nil = inv_laplace_transform(@g, [0, 1]);',
            'function F = g(s):\n   F = 1 / (s + 1);\nfnend\nil = inv_laplace_transform(@g, [0.5, 1]);\npublish(il);'),
        err('An unknown method', 'Use "talbot" or "stehfest".', 'function F = g(s):\n   F = 1 / (s + 1);\nfnend\nil = inv_laplace_transform(@g, [1], "euler");',
            'function F = g(s):\n   F = 1 / (s + 1);\nfnend\nil = inv_laplace_transform(@g, [1], "stehfest");\npublish(il);'),
        err('An odd number of Stehfest terms', 'Stehfest needs an even M.', 'function F = g(s):\n   F = 1 / (s + 1);\nfnend\nil = inv_laplace_transform(@g, [1], "stehfest", 13);',
            'function F = g(s):\n   F = 1 / (s + 1);\nfnend\nil = inv_laplace_transform(@g, [1], "stehfest", 14);\npublish(il);'),
    ],
}

# ================================================================== 4. Fourier series
SQUARE = '''function y = square(x):
   if x < 0:
      y = -1;
   else:
      y = 1;
   iend
fnend
'''
PAGES['fourier-series'] = {
    'title': 'Fourier Series & Integrals',
    'summary': 'Fourier coefficients of periodic functions (real and complex), half-range expansions, the Parseval '
               'error, forced oscillations under a periodic force, and continuous Fourier, cosine and sine transforms.',
    'about': reference('These work on a <em>function</em> (by adaptive integration). For sampled data use <code>fft'
                       '</code> (see <a href="../Scientific_Library/fourier-transforms.html">Fourier Transforms</a>). '
                       'Conventions are Kreyszig\'s: period p = 2L on [&minus;L, L].', [
        fn('fourier_coeffs_real(@f, p, N[, start])', 'a0 and a<sub>n</sub>, b<sub>n</sub> (n = 1&hellip;N): {a0, a, b}.',
           math=r'f(x) \sim a_0 + \sum_{n=1}^{\infty}\left(a_n \cos\frac{n\pi x}{L} + b_n \sin\frac{n\pi x}{L}\right)',
           figure=fig(IMG + 'fourier-series-01.svg',
                      'A square wave from minus pi to pi and its Fourier partial sums with 1, 3 and 15 terms; the sums '
                      'approach the square wave but overshoot by about 9 percent next to the jumps.',
                      'Partial sums of the square wave\'s Fourier series. The overshoot at the jumps (the Gibbs '
                      'phenomenon) does not shrink as terms are added; it only narrows.'),
           short='real Fourier coefficients'),
        fn('fourier_coeffs_complex(@f, p, N[, start])', 'c<sub>n</sub> for n = &minus;N&hellip;N: {n, c}.',
           math=r'f(x) \sim \sum_{n=-\infty}^{\infty} c_n e^{i n \pi x / L}', short='complex coefficients'),
        fn('half_range_extension(@f, L, N, "even" | "odd")', 'f given on (0, L) only, extended as an even function '
           '(cosine series {a0, a}) or an odd one (sine series {b}).', short='cosine or sine series'),
        fn('parseval_error(@f, coeffs, p[, start])', 'The minimum square error of the trigonometric polynomial with '
           'these coefficients.', math=r'E^{*} = \int f^2\,dx - L\left(2a_0^2 + \sum (a_n^2 + b_n^2)\right)',
           short='square error of a partial sum'),
        fn('forced_oscillation_fourier(coeffs, m, c, k, w)', 'The steady state of m y&prime;&prime; + c y&prime; + k y = '
           'r(t) for a periodic force with these Fourier coefficients: {A0, A, B, amplitude}.', short='response to a periodic force'),
        fn('fourier_transform_integral(@f, w[, limits])', 'The continuous Fourier transform at the frequencies w.',
           math=r'\hat f(\omega) = \frac{1}{\sqrt{2\pi}}\int_{-\infty}^{\infty} f(x)\,e^{-i\omega x}\,dx',
           short='Fourier transform'),
        fn('fourier_sine_cosine_transform(@f, w, "cos" | "sin"[, b])', 'The cosine or sine transform of f on (0, &infin;).',
           math=r'\hat f_c(\omega) = \sqrt{\tfrac{2}{\pi}}\int_0^\infty f(x)\cos\omega x\,dx', short='cosine and sine transforms'),
    ]),
    'examples': {
        'basic': ex('The square wave', 'Its coefficients b<sub>n</sub> = 4/(n&pi;) for odd n, and the square errors '
                    'of partial sums (Kreyszig 11.1, 11.6).', SQUARE + '''
F = fourier_coeffs_real(@square, 2 * pi, 5);
publish("b:", F["b"]);
publish("4/(n pi), odd n:", 4 / pi, 4 / (3 * pi), 4 / (5 * pi));
publish("E* with 1 term:", parseval_error(@square, fourier_coeffs_real(@square, 2 * pi, 1), 2 * pi), "  with 5:", parseval_error(@square, F, 2 * pi));
'''),
        'mid': ex('Complex coefficients and half-range series', 'e<sup>x</sup> on (&minus;&pi;, &pi;), and a triangle '
                  'given on (0, 2) expanded both ways.', '''
function y = expx(x):
   y = exp(x);
fnend
function y = triangle(x):
   if x < 1:
      y = x;
   else:
      y = 2 - x;
   iend
fnend
C = fourier_coeffs_complex(@expx, 2 * pi, 2);
publish("n:", C["n"]);
publish("c:", round(C["c"], decimals=4));
He = half_range_extension(@triangle, 2, 4, "even");
Ho = half_range_extension(@triangle, 2, 4, "odd");
publish("cosine series a0, a:", He["a0"], round(He["a"], decimals=5));
publish("sine series b:", round(Ho["b"], decimals=5));
'''),
        'strong': ex('Resonance with a harmonic, and transforms', 'A periodic force drives y&prime;&prime; + 0.05y&prime; '
                     '+ 25y; its 5th harmonic resonates (Kreyszig 11.3). Then the Gaussian, its own Fourier transform.', '''
function r = forcing(t):
   if t < 0:
      r = t + pi / 2;
   else:
      r = -1 * t + pi / 2;
   iend
fnend
function y = gauss(x):
   y = exp(-1 * x ^ 2 / 2);
fnend
R = fourier_coeffs_real(@forcing, 2 * pi, 7);
Y = forced_oscillation_fourier(R, 1, 0.05, 25, 1);
publish("amplitudes C_1..C_7:", round(Y["amplitude"], decimals=4));
w = [0.5, 1, 2];
publish("transform of exp(-x^2/2):", fourier_transform_integral(@gauss, w), "  exp(-w^2/2):", exp(-1 * w ^. 2 / 2));
'''),
    },
    'errors': [
        err('A zero period', 'The period must be positive.', SQUARE + 'fc = fourier_coeffs_real(@square, 0, 3);',
            SQUARE + 'fc = fourier_coeffs_real(@square, 2 * pi, 3);\npublish(fc["b"]);'),
        err('An unknown half-range type', 'Use "even" (cosine series) or "odd" (sine series).',
            SQUARE + 'hr = half_range_extension(@square, 1, 3, "middle");', SQUARE + 'hr = half_range_extension(@square, 1, 3, "odd");\npublish(hr["b"]);'),
        err('Coefficients that are not a dictionary', 'parseval_error takes the result of fourier_coeffs_real.',
            SQUARE + 'pe = parseval_error(@square, [1, 2], 2 * pi);',
            SQUARE + 'pe = parseval_error(@square, fourier_coeffs_real(@square, 2 * pi, 3), 2 * pi);\npublish(pe);'),
        err('A transform that does not converge', 'f must decay at infinity, or give limits [a, b].',
            'function y = f1(x):\n   y = x ^ 2;\nfnend\nft = fourier_transform_integral(@f1, [1]);',
            'function y = f1(x):\n   y = x ^ 2;\nfnend\nft = fourier_transform_integral(@f1, [1], [0, 1]);\npublish(ft);'),
    ],
}

# ================================================================== 5. Partial differential equations
MODES = '''function u = mode1(x):
   u = sin(pi * x);
fnend
function v = mode2(x):
   v = sin(2 * pi * x);
fnend
'''
PAGES['pdes'] = {
    'title': 'Partial Differential Equations',
    'summary': 'Classical solutions of the wave, heat and Laplace equations: vibrating strings and membranes, heat '
               'flow in finite and infinite bars, drums, and potentials in disks and spheres.',
    'about': reference('Initial and boundary data are functions (<code>@f</code>) or plain numbers (0 = at rest). Results '
                       'on a space-time grid have <strong>one row per time and one column per position</strong>: '
                       'U[i, j] = u(x<sub>j</sub>, t<sub>i</sub>).', [
        fn('solve_wave_1d_fourier(f, g, L, c, x, t, N)', 'A vibrating string with fixed ends, deflection f and velocity g '
           'at t = 0: the first N terms of its Fourier series.',
           math=r'u_{tt} = c^2 u_{xx}, \qquad u = \sum_{n=1}^{N} \left(B_n \cos\lambda_n t + B_n^* \sin\lambda_n t\right)\sin\frac{n\pi x}{L}, \quad \lambda_n = \frac{c n \pi}{L}',
           figure=fig(IMG + 'pdes-01.svg',
                      'Left: a string plucked into one sine arch, drawn at several times as it swings down and back. '
                      'Right: the temperature in a bar that starts as a sine arch and decays toward zero over time.',
                      'The same initial shape under the wave equation (left: it oscillates) and the heat equation '
                      '(right: it decays).'),
           short='vibrating string (Fourier series)'),
        fn('solve_wave_1d_dalembert(f, g, c, x, t)', 'D\'Alembert\'s solution on the whole line.',
           math=r'u = \frac{f(x + ct) + f(x - ct)}{2} + \frac{1}{2c}\int_{x-ct}^{x+ct} g(s)\,ds', short='D\'Alembert\'s solution'),
        fn('solve_heat_1d_fourier(f, L, c, x, t, N) / solve_heat_1d_fourier_integral(f, c, x, t)', 'Heat flow in a bar '
           'with ends at 0, and in an infinite bar.', math=r'u_t = c^2 u_{xx}, \qquad u = \sum B_n \sin\frac{n\pi x}{L}\,e^{-\lambda_n^2 t}',
           short='heat flow'),
        fn('pde_solve_laplace_transform(f, g0, gL, c, x, t[, M])', 'The heat equation with time-varying end '
           'temperatures, solved in the Laplace domain and inverted numerically (about 4&ndash;5 digits).',
           short='heat flow by Laplace transform'),
        fn('solve_wave_2d_rectangular(f, g, a, b, c, x, y, t, N, M)', 'A rectangular membrane: a double Fourier series. '
           'The result is [nt, ny, nx].', math=r'u_{tt} = c^2(u_{xx} + u_{yy})', short='rectangular membrane'),
        fn('solve_wave_2d_circular_bessel(f, g, R, c, r, t, N)', 'A circular drum, vibrations that do not depend on the '
           'angle: a series of Bessel functions J0.', math=r'u = \sum (A_m \cos\lambda_m t + B_m \sin\lambda_m t)\,J_0\!\left(\frac{\alpha_m r}{R}\right)',
           short='circular drum'),
        fn('solve_laplace_2d_polar(f, R, r, theta, N) / solve_laplace_3d_spherical(f, R, r, phi, N)', 'Laplace\'s '
           'equation inside (and outside) a disk or a sphere with given boundary values.',
           math=r'\nabla^2 u = 0, \qquad u = a_0 + \sum \left(\frac{r}{R}\right)^n (a_n \cos n\theta + b_n \sin n\theta)',
           short='potentials in a disk or sphere'),
    ]),
    'examples': {
        'basic': ex('A string and a bar', 'A string starting as sin(&pi;x) with velocity sin(2&pi;x), and the heat in a '
                    'bar starting as sin(&pi;x), each against its exact solution.', MODES + '''
x = space(0, 1, 11);
t = [0, 0.1, 0.25];
c = 2;
[XX, TT] = meshgrid(x, t);
U = solve_wave_1d_fourier(@mode1, @mode2, 1, c, x, t, 4);
exact = sin(pi * XX) *. cos(c * pi * TT) + sin(2 * pi * XX) *. sin(2 * c * pi * TT) / (2 * c * pi);
publish("string matches:", allclose(U, exact, atol=1e-12));
H = solve_heat_1d_fourier(@mode1, 1, 1, x, [0, 0.05, 0.2], 3);
publish("bar centre over time:", H[:, 5]');
'''),
        'mid': ex('Infinite domains', 'D\'Alembert\'s solution for a bump moving apart, and heat spreading in an '
                  'infinite bar.', '''
function u = bump(x):
   u = exp(-1 * x ^ 2);
fnend
xd = space(-2, 2, 9);
D = solve_wave_1d_dalembert(@bump, 0, 1, xd, [0, 1]);
publish("t = 0:", round(D[0, :], decimals=3));
publish("t = 1:", round(D[1, :], decimals=3));
I = solve_heat_1d_fourier_integral(@bump, 0.5, [0, 1], [0, 1]);
publish("infinite bar, centre and x = 1 at t = 0 and 1:", round(I, decimals=4));
'''),
        'strong': ex('Membranes and potentials', 'A square membrane at t = 0.3, the first mode of a drum, and Laplace\'s '
                     'equation in a disk with boundary values cos &theta; + sin 2&theta;.', '''
function u = plate(x, y):
   u = sin(pi * x) * sin(pi * y);
fnend
function u = drum(r):
   u = jv(0, 2.404825557695773 * r);
fnend
function u = ring(theta):
   u = cos(theta) + sin(2 * theta);
fnend
xm = space(0, 1, 6);
W = solve_wave_2d_rectangular(@plate, 0, 1, 1, 1, xm, xm, [0, 0.3], 3, 3);
publish("membrane centre-ish at t = 0.3:", round(W[1][2, 2], decimals=6), "  exact:", round(sin(pi * 0.4) ^ 2 * cos(pi * sqrt(2) * 0.3), decimals=6));
Dr = solve_wave_2d_circular_bessel(@drum, 0, 1, 1, [0, 0.5, 1], [0, 0.5], 5);
publish("drum:", round(Dr, decimals=5));
Lu = solve_laplace_2d_polar(@ring, 1, [0, 0.5, 1], [0, pi / 4, pi / 2], 4);
publish("disk potential:", round(Lu, decimals=5));
'''),
    },
    'errors': [
        err('A string of zero length', 'L must be positive.', MODES + 'w1 = solve_wave_1d_fourier(@mode1, 0, 0, 1, [0, 1], [0], 3);',
            MODES + 'w1 = solve_wave_1d_fourier(@mode1, 0, 1, 1, [0, 1], [0], 3);\npublish(w1);'),
        err('A negative time', 'Solutions start at t = 0.', MODES + 'w1 = solve_wave_1d_fourier(@mode1, 0, 1, 1, [0, 1], [-1], 3);',
            MODES + 'w1 = solve_wave_1d_fourier(@mode1, 0, 1, 1, [0, 0.5, 1], [1], 3);\npublish(w1);'),
        err('A radius outside the drum', 'Every r must be within 0 &le; r &le; R.', MODES + 'wb = solve_wave_2d_circular_bessel(@mode1, 0, 1, 1, [0, 2], [0], 3);',
            MODES + 'wb = solve_wave_2d_circular_bessel(@mode1, 0, 1, 1, [0, 1], [0], 3);\npublish(wb);'),
        err('x that goes back', 'Positions must increase.', MODES + 'pl = pde_solve_laplace_transform(@mode1, 0, 0, 1, [1, 0], [0.1]);',
            MODES + 'pl = pde_solve_laplace_transform(@mode1, 0, 0, 1, [0, 0.5, 1], [0.1]);\npublish(round(pl, decimals=4));'),
    ],
}

# ================================================================== 6. Complex functions and contour integrals
CPLX = 'g = space(-1, 1, 21);\n[X, Y] = meshgrid(g, g);\nZ = X + 1i * Y;\n'
PAGES['complex-functions'] = {
    'title': 'Complex Functions & Contour Integrals',
    'summary': 'Analytic functions and the Cauchy&ndash;Riemann equations, complex derivatives, continuous '
               'logarithms, contours, contour integrals, Cauchy\'s formulas, ML bounds, and Taylor coefficients.',
    'about': reference('Complex numbers are written 1 + 2i; a complex grid is Z = X + 1i * Y from <code>meshgrid</code>. '
                       'A contour is a row of complex points joined by straight segments. Functions given to these must '
                       'accept complex inputs (arithmetic, exp, sin, cos, sqrt and log all do).', [
        fn('is_analytic(F, dx, dy[, tol])', 'The Cauchy&ndash;Riemann check on a sampled grid: {analytic, max_residual, '
           'relative_residual, derivative}.', math=r'u_x = v_y, \qquad u_y = -v_x', short='Cauchy&ndash;Riemann test'),
        fn('complex_deriv(@f, z[, h])', 'f&prime;(z) at each z.', math=r"f'(z) = \lim_{h\to 0} \frac{f(z+h) - f(z)}{h}"),
        fn('branch_cut_unwrap(Z)', 'arg z followed continuously across the negative real axis: {phase, log, sqrt}.',
           short='continuous argument, log and sqrt'),
        fn('generate_contour(type, params)', 'Standard paths: "circle" [c, r(, n)], "arc" [c, r, t1, t2(, n)], "line" '
           '[z1, z2(, n)], "polygon" [z1, z2, ...], "rectangle" [x0, y0, x1, y1], "semicircle" [R(, n)]. Closed paths '
           'run counter-clockwise.', short='circles, arcs, lines, polygons'),
        fn('contour_integrate(@f, path)', 'The integral of f(z) dz along the path.',
           math=r'\oint_{|z|=1} \frac{dz}{z} = 2\pi i, \qquad \oint_C f(z)\,dz = 0 \text{ for analytic } f',
           figure=fig(IMG + 'complex-functions-01.svg',
                      'The unit circle traversed counter-clockwise around the origin, with z0 marked inside; the integral '
                      'of 1/z around it is 2 pi i, and Cauchy\'s formula recovers f(z0) from the values on the circle.',
                      'A closed contour around z<sub>0</sub>. Cauchy\'s integral formula reads f(z<sub>0</sub>) from the '
                      'values of f on the contour alone.'),
           short='contour integral'),
        fn('cauchy_eval(@f, z0, path) / cauchy_deriv(@f, z0, n, path)', 'Cauchy\'s integral formula for f(z0) and for '
           'its n-th derivative.', math=r'f^{(n)}(z_0) = \frac{n!}{2\pi i}\oint_C \frac{f(z)}{(z - z_0)^{n+1}}\,dz',
           short='Cauchy\'s integral formulas'),
        fn('ml_bound_estimate(@f, path)', 'The ML inequality: {M (largest |f|), L (length), bound = ML, max_at}.',
           math=r'\left|\int_C f\,dz\right| \le M L', short='ML bound'),
        fn('taylor_coeffs_cplx(@f, z0, N[, r])', 'The Taylor coefficients a<sub>0</sub>&hellip;a<sub>N&minus;1</sub> at '
           'z0 from Cauchy integrals on |z &minus; z0| = r; with <code>rad_of_con</code> they give the radius of '
           'convergence.', short='Taylor coefficients'),
    ]),
    'examples': {
        'basic': ex('Analytic or not', 'z<sup>2</sup> satisfies the Cauchy&ndash;Riemann equations; conj(z) does not.', CPLX + '''
function w = cube(z):
   w = z ^ 3;
fnend
A = is_analytic(Z ^. 2, 0.1, 0.1);
B = is_analytic(conj(Z), 0.1, 0.1);
publish("z^2:", A["analytic"], "  conj(z):", B["analytic"]);
publish("derivative of z^2 is 2z:", max(abs(A["derivative"] - 2 * Z)) < 1e-12);
publish("(z^3)' at 1 + i:", complex_deriv(@cube, 1 + 1i));
U = branch_cut_unwrap(exp(1i * space(0, 3 * pi, 31)));
publish("phase after 1.5 turns:", U["phase"][30], " = 3 pi:", 3 * pi);
'''),
        'mid': ex('Contour integrals', '1/z and z<sup>2</sup> round the unit circle, z<sup>2</sup> along a line, and an '
                  'ML bound.', '''
function w = recip(z):
   w = 1 / z;
fnend
function w = sq(z):
   w = z ^ 2;
fnend
circ = generate_contour("circle", [0, 1]);
publish("closed integral of 1/z:", contour_integrate(@recip, circ), "  2 pi i =", 2i * pi);
publish("closed integral of z^2:", round(contour_integrate(@sq, circ), decimals=12));
seg = generate_contour("line", [0, 1 + 1i]);
publish("z^2 from 0 to 1+i:", contour_integrate(@sq, seg), "  (1+i)^3/3 =", (1 + 1i) ^ 3 / 3);
ml = ml_bound_estimate(@sq, seg);
publish("M =", ml["M"], " L =", ml["L"], " bound =", ml["bound"]);
'''),
        'strong': ex('Cauchy\'s formulas and Taylor series', 'e<sup>z</sup> at 2 from a circle of radius 3, the second '
                     'derivative of cos at 0, and Taylor coefficients with their radius of convergence.', '''
function w = ez(z):
   w = exp(z);
fnend
function w = cz(z):
   w = cos(z);
fnend
function w = geometric(z):
   w = 1 / (1 - z);
fnend
big = generate_contour("circle", [0, 3]);
publish("e^2 by Cauchy:", cauchy_eval(@ez, 2, big), "  exp(2):", exp(2));
publish("cos'' at 0:", cauchy_deriv(@cz, 0, 2, big));
publish("e^z coefficients:", taylor_coeffs_cplx(@ez, 0, 5));
publish("radius of 1/(1 - z):", rad_of_con(taylor_coeffs_cplx(@geometric, 0, 16)));
'''),
    },
    'errors': [
        err('A path of one point', 'A path needs at least two points.', 'function w = f1(z):\n   w = z ^ 2;\nfnend\nci = contour_integrate(@f1, [1]);',
            'function w = f1(z):\n   w = z ^ 2;\nfnend\nci = contour_integrate(@f1, [0, 1 + 1i]);\npublish(ci);'),
        err('An unknown contour type', 'NC lists the six types.', 'gc = generate_contour("star", [1]);',
            'gc = generate_contour("circle", [0, 1]);\npublish(numel(gc));'),
        err('A negative radius', 'A circle needs a positive radius.', 'gc = generate_contour("circle", [0, -1]);',
            'gc = generate_contour("circle", [0, 1]);\npublish(numel(gc));'),
        err('A derivative order too high', 'cauchy_deriv takes n from 0 to 30.',
            'function w = f1(z):\n   w = z ^ 2;\nfnend\ncdv = cauchy_deriv(@f1, 0, 31, generate_contour("circle", [0, 1]));',
            'function w = f1(z):\n   w = z ^ 2;\nfnend\ncdv = cauchy_deriv(@f1, 0, 2, generate_contour("circle", [0, 1]));\npublish(cdv);'),
    ],
}

# ================================================================== 7. Residues, conformal maps, potential flow
PAGES['residues-conformal'] = {
    'title': 'Residues, Conformal Maps & Potential Flow',
    'summary': 'Laurent series, poles and residues, real integrals evaluated by residues, conformal and M&ouml;bius '
               'maps, harmonic conjugates, Poisson\'s integral, and complex potentials of ideal fluid flow.',
    'about': reference('Chapters 16 to 18 of Kreyszig. Functions passed as <code>@f</code> must accept complex inputs.', [
        fn('laurent_coeffs(@f, z0, r, N)', 'c<sub>&minus;N</sub>&hellip;c<sub>N</sub> of the Laurent series on the '
           'circle |z &minus; z0| = r: {n, c}.', math=r'f(z) = \sum_{n=-\infty}^{\infty} c_n (z - z_0)^n',
           short='Laurent series'),
        fn('find_poles(@f, domain[, n])', 'The poles of f in [x_min, x_max, y_min, y_max]: {poles, orders}.'),
        fn('complex_residue(@f, z0[, r])', 'The residue of f at z0 (the coefficient c<sub>&minus;1</sub>).',
           math=r'\oint_C f\,dz = 2\pi i \sum \operatorname{Res}_{z = z_k} f(z)', short='residue at a point'),
        fn('real_improper_integral(@f[, R, n]) / real_trig_integral(@F)', 'Real integrals by residues: over the whole '
           'real line (upper half-plane poles), and of F(&theta;) from 0 to 2&pi; (unit circle).',
           math=r'\int_{-\infty}^{\infty} \frac{dx}{1 + x^4} = \frac{\pi}{\sqrt 2}', short='real integrals by residues'),
        fn('conformal_map(@f, Z) / mobius_transform(z, a, b, c, d)', 'w = f(z) on a grid, and the M&ouml;bius map.',
           math=r'w = \frac{az + b}{cz + d}, \qquad ad - bc \ne 0',
           figure=fig(IMG + 'residues-conformal-01.svg',
                      'Left: a square grid in the z-plane. Right: its image under w = z squared, where the straight grid '
                      'lines become two families of parabolas that still cross at right angles.',
                      'A conformal map keeps angles: under w = z<sup>2</sup> the grid lines become parabolas that still '
                      'meet at right angles.'),
           short='conformal and M&ouml;bius maps'),
        fn('mobius_from_points(z, w) / cross_ratio(z1, z2, z3, z4)', 'The M&ouml;bius map that takes three points to '
           'three images ([a, b; c, d] with ad &minus; bc = 1), and the cross ratio it keeps.', short='three-point maps, cross ratio'),
        fn('harmonic_conjugate(u, dx, dy) / poisson_integral_disk(@f, r, theta[, R])', 'v with u + iv analytic; and '
           'the harmonic function in a disk with boundary values f.', short='harmonic functions'),
        fn('complex_potential(V, Z) / complex_velocity(@F, z) / joukowski_map(z, c)', 'Ideal flow: the complex potential '
           'F (potential and stream function), the velocity from F, and the Joukowski map that turns a circle into a '
           'wing-like profile.', math=r'F(z) = \Phi + i\Psi, \qquad V = \overline{F\'(z)}',
           figure=fig(IMG + 'residues-conformal-02.svg',
                      'Streamlines of ideal flow past a circular cylinder of radius 1: the lines bend smoothly around '
                      'the circle and are closest together above and below it, where the flow is fastest.',
                      'Flow round a cylinder: the stream function of F(z) = z + 1/z.'),
           short='ideal fluid flow'),
    ]),
    'examples': {
        'basic': ex('Laurent series and residues', 'The Laurent series of 1/(z<sup>3</sup> &minus; z<sup>4</sup>), the '
                    'poles of a function and residues from Kreyszig 16.3.', '''
function w = laurent_ex(z):
   w = 1 / (z ^ 3 - z ^ 4);
fnend
function w = two_poles(z):
   w = 1 / ((z - 1) * (z + 2i) ^ 2);
fnend
function w = res_ex(z):
   w = (9 * z + 1i) / (z * (z ^ 2 + 1));
fnend
L = laurent_coeffs(@laurent_ex, 0, 0.5, 4);
publish("c_-4 .. c_4:", round(real(L["c"]), decimals=8));
P = find_poles(@two_poles, [-3, 3, -3, 3]);
publish("poles:", P["poles"], "  orders:", P["orders"]);
publish("Res at i:", complex_residue(@res_ex, 1i), "  Res at 0:", complex_residue(@res_ex, 0));
'''),
        'mid': ex('Real integrals by residues', 'The integral of 1/(1 + x<sup>4</sup>) over the real line and of '
                  '1/(&radic;2 &minus; cos &theta;) over a period.', '''
function y = quartic(x):
   y = 1 / (1 + x ^ 4);
fnend
function y = trig_ex(theta):
   y = 1 / (sqrt(2) - cos(theta));
fnend
I = real_improper_integral(@quartic);
publish("by residues:", I["value"], "  pi/sqrt(2) =", pi / sqrt(2), "  numeric:", I["numeric"]);
publish("trig integral:", real_trig_integral(@trig_ex), "  2 pi =", 2 * pi);
'''),
        'strong': ex('Maps and flow', 'A M&ouml;bius map through three points (Kreyszig 17.3), the conservation of the '
                     'cross ratio, flow round a cylinder, and the Joukowski map of the unit circle.', '''
function F = cylinder_flow(z):
   F = z + 1 / z;
fnend
zp = [-1, 0, 1];
wp = [-1i, -1, 1i];
M = mobius_from_points(zp, wp);
publish("images:", mobius_transform(zp, M[0, 0], M[0, 1], M[1, 0], M[1, 1]));
z4 = [2, 1i, -2, 0.5 + 0.5i];
w4 = mobius_transform(z4, 2, 1, 1, 3);
publish("cross ratio kept:", abs(cross_ratio(w4[0], w4[1], w4[2], w4[3]) - cross_ratio(z4[0], z4[1], z4[2], z4[3])) < 1e-12);
cv = complex_velocity(@cylinder_flow, 2);
publish("velocity at z = 2:", cv["V"], "  speed:", cv["speed"]);
publish("Joukowski of the unit circle:", round(real(joukowski_map(exp(1i * space(0, pi, 5)), 1)), decimals=6));
'''),
    },
    'errors': [
        err('A M&ouml;bius map with ad &minus; bc = 0', 'The map would be constant.', 'mt = mobius_transform(1, 1, 2, 2, 4);',
            'mt = mobius_transform(1, 1, 2, 3, 4);\npublish(mt);'),
        err('Images that repeat', 'Three distinct points need three distinct images.', 'mp = mobius_from_points([1, 2, 3], [1, 1, 2]);',
            'mp = mobius_from_points([1, 2, 3], [1, 2, 4]);\npublish(round(mp, decimals=6));'),
        err('A residue without the point', 'complex_residue needs the function and the point.',
            'function w = f1(z):\n   w = 1 / z;\nfnend\nrr = complex_residue(@f1);',
            'function w = f1(z):\n   w = 1 / z;\nfnend\nrr = complex_residue(@f1, 0);\npublish(rr);'),
        err('A radius outside the disk', 'Every r must be in [0, R].', 'function u = f1(p):\n   u = cos(p);\nfnend\npi1 = poisson_integral_disk(@f1, [2], [0]);',
            'function u = f1(p):\n   u = cos(p);\nfnend\npi1 = poisson_integral_disk(@f1, [0.5], [0]);\npublish(pi1);'),
    ],
}

# ================================================================== 8. Probability and quality control
CHART = 'D = [10.1, 9.8, 10.0, 10.3; 9.9, 10.2, 10.1, 9.7; 10.0, 10.4, 9.9, 10.1; 9.6, 10.0, 10.2, 10.0; 10.2, 9.9, 10.1, 10.0];\n'
PAGES['probability-quality'] = {
    'title': 'Probability & Quality Control',
    'summary': 'Permutations and combinations, conditional distributions, confidence intervals for the mean and the '
               'variance, Shewhart control charts, operating characteristic curves, and the sign test.',
    'about': reference('Chapters 24 and 25 of Kreyszig. Other statistics are on <a href="' + TM +
                       'descriptive-statistics.html">Descriptive Statistics</a> and <a href="../Scientific_Library/'
                       'statistics.html">Statistics &amp; Tests</a>.', [
        fn('generate_permutations(elements[, r]) / generate_combinations(elements, r)', 'Every ordered (permutation) or '
           'unordered (combination) selection of r elements, one per row; elements may be numbers or text.',
           math=r'{}_nP_r = \frac{n!}{(n-r)!}, \qquad \binom{n}{r} = \frac{n!}{r!\,(n-r)!}', short='permutations and combinations'),
        fn('conditional_distribution(P, k, axis)', 'From a joint distribution P[i, j]: P(Y | X = x<sub>k</sub>) (axis 0) '
           'or P(X | Y = y<sub>k</sub>) (axis 1).', math=r'P(Y = y_j \mid X = x_k) = \frac{P(x_k, y_j)}{\sum_j P(x_k, y_j)}',
           short='conditional distributions'),
        fn('confidence_interval_mean(data, level[, known_variance]) / confidence_interval_var(data, level)', 'Intervals '
           'for the mean (normal with a known variance, Student\'s t otherwise) and for the variance (chi-square).',
           math=r'\bar x \pm c\,\frac{s}{\sqrt n}, \qquad \frac{(n-1)s^2}{c_2} \le \sigma^2 \le \frac{(n-1)s^2}{c_1}',
           short='confidence intervals'),
        fn('control_chart_limits(data[, type][, k])', 'A Shewhart chart for samples in rows: "x_bar", "r", "s" or "p"; '
           '{cl, ucl, lcl, values, out_of_control}.',
           figure=fig(IMG + 'probability-quality-01.svg',
                      'An x-bar control chart: the means of five samples plotted with the centre line and the upper and '
                      'lower control limits; all points lie within the limits.',
                      'An x&#772; chart of the example data: the process is in control.'),
           short='control charts'),
        fn('operating_characteristic_curve(N, n, c, p)', 'The probability of accepting a lot of N with defect fraction '
           'p, when a sample of n may hold at most c defectives (N = 0 for a very large lot).',
           figure=fig(IMG + 'probability-quality-02.svg',
                      'Operating characteristic curves for sampling plans n = 5, 10 and 20 with c = 0: the probability of '
                      'accepting a lot falls as the defect fraction rises, faster for larger samples.',
                      'OC curves: larger samples tell good lots from bad more sharply.'),
           short='acceptance sampling'),
        fn('sign_test(data, median0[, alternative]) / sign_test(x, y[, alternative])', 'The sign test for a median or '
           'for paired samples: {positives, negatives, n, p_value, alternative}.', short='sign test'),
    ]),
    'examples': {
        'basic': ex('Counting', 'Permutations and combinations, and an exact probability by listing the sample space.', '''
P = generate_permutations([1, 2, 3], 2)
C = generate_combinations(["a", "b", "c"], 2)
H = generate_combinations([1, 2, 3, 4, 5], 2);
even = 0;
for k = [0:9]:
   if (H[k, 0] + H[k, 1]) % 2 == 0:
      even = even + 1;
   iend
fend
publish("P(two cards have an even sum) =", even / 10);
'''),
        'mid': ex('Conditional probability and intervals', 'A joint table, a t-interval for a mean, an interval for a '
                  'variance, and a known-variance interval from Kreyszig 25.3.', '''
J = [0.1, 0.2; 0.3, 0.4];
publish("P(Y | X = x0):", conditional_distribution(J, 0, 0));
x = [1, 2, 3, 4, 5];
ct = confidence_interval_mean(x, 95);
publish("t interval:", round(ct["lower"], decimals=4), "to", round(ct["upper"], decimals=4), " c =", round(ct["c"], decimals=4));
cv = confidence_interval_var(x, 0.95);
publish("variance:", round(cv["lower"], decimals=4), "to", round(cv["upper"], decimals=4));
ci = confidence_interval_mean(5 * ones(1, 100), 0.95, 9);
publish("known variance:", round(ci["lower"], decimals=3), "to", round(ci["upper"], decimals=3));
'''),
        'strong': ex('Quality control', 'x&#772; and R charts of five samples of four, an acceptance plan (Kreyszig '
                     '25.6), and a sign test.', CHART + '''
xb = control_chart_limits(D, "x_bar");
rb = control_chart_limits(D, "r");
publish("x_bar chart: CL", round(xb["cl"], decimals=4), " UCL", round(xb["ucl"], decimals=4), " LCL", round(xb["lcl"], decimals=4), " out:", xb["out_of_control"]);
publish("R chart: CL", round(rb["cl"], decimals=4), " UCL", round(rb["ucl"], decimals=4));
publish("P(accept), N = 20, n = 5, c = 0, p = 0.1:", operating_characteristic_curve(20, 5, 0, [0.1]));
s = sign_test([5.6, 6.1, 5.9, 6.4, 5.7, 6.0, 6.3, 5.8, 6.2, 4.9], 5.5);
publish("sign test: above", s["positives"], " below", s["negatives"], " p =", s["p_value"]);
'''),
    },
    'errors': [
        err('More elements chosen than there are', 'From 3 elements, r runs from 1 to 3.', 'gp = generate_permutations([1, 2, 3], 4);',
            'gp = generate_permutations([1, 2, 3], 3);\npublish(size(gp));'),
        err('A condition with probability 0', 'Conditioning on an impossible event is not defined.',
            'cdd = conditional_distribution([0.5, 0.5; 0, 0], 1, 0);', 'cdd = conditional_distribution([0.5, 0.5; 0, 0], 0, 0);\npublish(cdd);'),
        err('A confidence level of 100%', 'Use a level below 1 (or below 100 as a percentage).',
            'cim = confidence_interval_mean([1, 2, 3], 100);', 'cim = confidence_interval_mean([1, 2, 3], 95);\npublish(round(cim["upper"], decimals=4));'),
        err('An unknown chart type', 'Use "x_bar", "r", "s" or "p".', 'ccl = control_chart_limits([1, 2; 3, 4], "u");',
            'ccl = control_chart_limits([1, 2; 3, 4], "r");\npublish(ccl["ucl"]);'),
    ],
}
