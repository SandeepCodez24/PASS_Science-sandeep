#!/usr/bin/env python3
"""Build the Language Guide: Neural_Code/language-guide.html and
Neural_Code/Language_Guide/<Section>/<page>.html, from Build_Tools/lg_content.py.

Each page has the tabs About, Examples and (when the page lists errors) Syntax Error.
The Non-English Variables page also gets the letter finder, from Build_Tools/lg_letters.json
(made by extract_letters.py from the NC editor's Java letter tables).

Example outputs come from the real NC interpreter. They are kept in
Build_Tools/lg_outputs.json so the pages can be rebuilt on a machine without nc.exe;
an example is re-run only when its code changes (or with --run). The wrong and the
corrected code of every Syntax Error card are run the same way.

    python Webpage_Framework/Build_Tools/build_language_guide.py          # re-run changed examples, rebuild pages
    python Webpage_Framework/Build_Tools/build_language_guide.py --run    # re-run every example
    set NC_EXE=C:\\path\\to\\nc.exe                 # if nc.exe is somewhere else

Then run build_pages.py (menus/chrome) and check_site.py from the same folder.
"""
import hashlib
import html
import json
import os
import re
import subprocess
import sys
sys.dont_write_bytecode = True  # keep Build_Tools free of __pycache__
import tempfile
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
from lg_content import LANDING, PAGES, SECTIONS  # noqa: E402
from site_chrome import BUILT_MARKER, SITE, page  # noqa: E402

NC_EXE = Path(os.environ.get('NC_EXE', r'D:\My Research Works\PASS Science Works\Main_Repository'
                                       r'\Astra_UniPro_01\src\main\cpp\nc.exe'))
OUTPUTS = TOOLS / 'lg_outputs.json'
LETTERS = TOOLS / 'lg_letters.json'
CODE = SITE / 'Neural_Code'
GUIDE = CODE / 'Language_Guide'
LEVELS = [('basic', 'Basic Example'), ('mid', 'Mid Level Example'), ('strong', 'Strong Example')]

KATEX = 'https://cdnjs.cloudflare.com/ajax/libs/KaTeX/0.16.9'


# ------------------------------------------------------------------ running examples
def jobs():
    """Every piece of code that is run: (cache key, code)."""
    for slug, pg in PAGES.items():
        if pg.get('pending'):
            continue
        for level, _ in LEVELS:
            yield f'{slug}/{level}', pg['examples'][level]['code']
        for n, e in enumerate(pg.get('errors', []), 1):
            yield f'{slug}/err{n}', e['wrong']
            yield f'{slug}/err{n}-fix', e['fix']


def run_examples(force=False):
    cache = json.loads(OUTPUTS.read_text(encoding='utf-8')) if OUTPUTS.exists() else {}
    have_nc = NC_EXE.exists()
    ran = missing = 0
    work = Path(tempfile.mkdtemp(prefix='nc_lg_'))
    for key, code in jobs():
        digest = hashlib.sha1(code.encode('utf-8')).hexdigest()
        if not force and cache.get(key, {}).get('sha1') == digest:
            continue
        if not have_nc:
            missing += 1
            continue
        script = work / 'example.nc'
        script.write_text(code + '\n', encoding='utf-8')
        result = subprocess.run([str(NC_EXE), str(script)], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, cwd=work, timeout=120)
        output = result.stdout.decode('utf-8', errors='replace')
        cache[key] = {'sha1': digest, 'exit': result.returncode, 'output': output.replace('\r\n', '\n')}
        ran += 1
    live = dict(jobs())
    cache = {k: v for k, v in cache.items() if k in live}     # drop outputs of code that no longer exists
    OUTPUTS.write_text(json.dumps(cache, ensure_ascii=False, indent=1, sort_keys=True), encoding='utf-8')
    if missing:
        print(f'WARNING: nc.exe not found at {NC_EXE}; {missing} example(s) have no up-to-date output.')
    print(f'Ran {ran} example(s) through nc.exe.')
    keys = dict(jobs())
    for key in sorted(keys):
        out, code = cache.get(key, {}).get('output', ''), cache.get(key, {}).get('exit')
        wrong = key.endswith(tuple(f'/err{n}' for n in range(1, 50)))
        if key in cache and wrong and code == 0:
            print(f'WARNING: {key} should fail but nc.exe ran it without an error')
        if key in cache and not wrong and code != 0:
            print(f'WARNING: {key} failed in nc.exe: {out.strip().splitlines()[-1] if out.strip() else ""}')
    return cache


# ------------------------------------------------------------------ syntax colouring
KEYWORDS = {'if', 'iend', 'elseif', 'else', 'not', 'for', 'fend', 'while', 'wend', 'break', 'continue',
            'function', 'fnend', 'class', 'csend', 'abstract', 'reversible', 'private', 'base', 'parent',
            'is_in', 'is_not_in'}
CONSTANTS = {'true', 'false', 'pi', 'e', 'inf', 'nan'}
TOKEN = re.compile(r'''
    (?P<comment>\#[^\n]*)
  | (?P<string>"(?:\\.|[^"\\])*")
  | (?P<number>\b\d+(?:\.\d+)?(?:e[+-]?\d+)?[ij]?\b|\.\d+)
  | (?P<word>[^\W\d](?:[\w$\u0300-\u036F\u0900-\u0DFF\u200C\u200D]|(?<=_)@)*)
  | (?P<op>~~|==|!=|<=|>=|&&|\|\||!&|!\||//|\*\.|[-+*/^%!<>=|@])
''', re.X)


def scripted_name(text):
    """Draw a name with _$ (subscript) and _@ (superscript) the way the NC IDE shows it.

    'A_$1' -> A with subscript 1; 'X_$a_@b' -> X with a stacked subscript a and superscript b.
    Names that break the rules (superscript first, two of a kind, empty) are left as typed.
    """
    sub = sup = None
    base, rest = text, ''
    if '_$' in text or '_@' in text:
        cut = min(i for i in (text.find('_$'), text.find('_@')) if i >= 0)
        base, rest = text[:cut], text[cut:]
    if rest.startswith('_$'):
        rest = rest[2:]
        sub, _, rest = rest.partition('_@')
        sup = rest if '_@' in text[cut + 2:] else None
    elif rest.startswith('_@'):
        sup = rest[2:]
    parts = [p for p in (sub, sup) if p is not None]
    if not base or any(not p or '_$' in p or '_@' in p for p in parts):
        return None
    e = html.escape
    if sub is not None and sup is not None:
        script = f'<span class="nm-pair"><sup>{e(sup)}</sup><sub>{e(sub)}</sub></span>'
    elif sub is not None:
        script = f'<sub>{e(sub)}</sub>'
    else:
        script = f'<sup>{e(sup)}</sup>'
    return f'<span class="nm" title="{e(text, quote=True)}">{e(base)}{script}</span>'


def highlight(code):
    out, pos = [], 0
    for m in TOKEN.finditer(code):
        out.append(html.escape(code[pos:m.start()]))
        text, kind = m.group(0), m.lastgroup
        cls = None
        if kind == 'comment':
            cls = 'c'
        elif kind == 'string':
            cls = 's'
        elif kind == 'number':
            cls = 'n'
        elif kind == 'word':
            following = code[m.end():m.end() + 1]
            drawn = scripted_name(text) if ('_$' in text or '_@' in text) else None
            if drawn:
                out.append(drawn)
                pos = m.end()
                continue
            if text in KEYWORDS:
                cls = 'k'
            elif text in CONSTANTS:
                cls = 'n'
            elif text in ('publish', 'print') or following == '(':
                cls = 'f'
        elif kind == 'op':
            cls = 'o'
        out.append(f'<span class="tk-{cls}">{html.escape(text)}</span>' if cls else html.escape(text))
        pos = m.end()
    out.append(html.escape(code[pos:]))
    return ''.join(out)


def render_output(text):
    lines = text.strip('\n').split('\n') if text.strip() else ['(no output)']
    rendered = []
    for line in lines:
        safe = html.escape(line.rstrip())
        if line.startswith(('Error', '\u2716', 'Warning')):
            safe = f'<span class="out-err">{safe}</span>'
        rendered.append(safe)
    return '\n'.join(rendered)


# ------------------------------------------------------------------ page parts
def flat_pages():
    return [(sec, slug) for sec, _, slugs in SECTIONS for slug in slugs]


def folder(sec):
    """Section slug -> its folder name ('getting-started' -> 'Getting_Started')."""
    return '_'.join(w.capitalize() for w in sec.split('-'))


def page_url(sec, slug, here):
    """Link from `here` ('landing' or a section slug) to a guide page."""
    if here == 'landing':
        return f'Language_Guide/{folder(sec)}/{slug}.html'
    return f'{slug}.html' if here == sec else f'../{folder(sec)}/{slug}.html'


def sidebar(here, current=None):
    home = 'language-guide.html' if here == 'landing' else '../../language-guide.html'
    rows = [f'        <a class="lg-nav-home" href="{home}"{" aria-current=\"page\"" if here == "landing" else ""}>'
            f'Language Guide home</a>']
    for sec, title, slugs in SECTIONS:
        rows.append(f'        <p class="lg-nav-section">{html.escape(title)}</p>')
        rows.append('        <ul>')
        for slug in slugs:
            mark = ' aria-current="page"' if slug == current else ''
            soon = ' <span class="lg-soon">soon</span>' if PAGES[slug].get('pending') else ''
            rows.append(f'          <li><a href="{page_url(sec, slug, here)}"{mark}>{html.escape(PAGES[slug]["title"])}</a>{soon}</li>')
        rows.append('        </ul>')
    links = '\n'.join(rows)
    return f'''      <aside class="lg-sidebar" aria-label="Language Guide">
        <button class="lg-nav-toggle" type="button" aria-expanded="false" aria-controls="lg-nav" data-lg-nav-toggle>Language Guide contents</button>
        <nav class="lg-nav" id="lg-nav">
{links}
        </nav>
      </aside>'''


def band(root, crumbs):
    trail = ''.join(f'<a href="{root}{href}">{html.escape(name)}</a><span>/</span>' if href else
                    f'<span>{html.escape(name)}</span><span>/</span>' for name, href in crumbs)
    return f'''    <div class="lg-band">
      <div class="lg-band-inner">
        <nav class="lg-crumbs" aria-label="Breadcrumb"><a href="{root}main.html">Home</a><span>/</span>{trail[:-len('<span>/</span>')]}</nav>
        <p class="lg-band-title">Language Guide</p>
      </div>
    </div>'''


SCRIPT_LANG = {'greek': 'el', 'tamil': 'ta', 'sanskrit': 'sa', 'malayalam': 'ml', 'telugu': 'te'}


def letter_tile(lang, pattern, key, glyph, small=False):
    import unicodedata
    command = pattern.replace('KEY', key)
    sign = len(glyph) == 1 and unicodedata.category(glyph) in ('Mn', 'Mc')
    title = f'{glyph}  -  type {command} in the NC IDE' + (' (a sign, not a name on its own)' if sign else '')
    return (f'<button class="lf-tile{" lf-small" if small else ""}{" lf-sign" if sign else ""}" type="button" '
            f'data-copy-text="{html.escape(glyph, quote=True)}" data-command="{html.escape(command, quote=True)}" '
            f'data-key="{html.escape(key, quote=True)}" '
            f'data-glyph="{html.escape(glyph, quote=True)}" title="{html.escape(title, quote=True)}">'
            f'<span class="lf-glyph" lang="{SCRIPT_LANG[lang]}">{html.escape(glyph)}</span>'
            f'<span class="lf-key">{html.escape(key)}</span></button>')


def letter_chart(L):
    """Consonant x vowel-sign table (Tamil, Malayalam)."""
    lang, pattern, chart = L['lang'], L['pattern'], L['chart']
    suffix = []
    for i in range(len(chart['cols'])):
        for row_key, _, cells in chart['rows']:
            cell = cells[i]
            if cell and row_key.endswith('a') and cell[0].startswith(row_key[:-1]):
                suffix.append(cell[0][len(row_key) - 1:])
                break
        else:
            suffix.append('')
    head = ''.join(f'<th scope="col"><span class="lf-sign-glyph" lang="{SCRIPT_LANG[lang]}">\u25CC{html.escape(sign)}</span>'
                   f'<span class="lf-key">{html.escape(suf)}</span></th>' for sign, suf in zip(chart['cols'], suffix))
    rows = []
    for key, glyph, cells in chart['rows']:
        tds = ''.join(f'<td>{letter_tile(lang, pattern, c[0], c[1], small=True) if c else ""}</td>' for c in cells)
        rows.append(f'<tr><th scope="row">{letter_tile(lang, pattern, key, glyph, small=True)}</th>{tds}</tr>')
    return (f'<section class="lf-group"><h4>Consonant + vowel sign <small>{len(chart["rows"])} &times; '
            f'{len(chart["cols"])}</small></h4><p class="lf-note">Rows: consonants. Columns: the vowel sign '
            f'(◌ marks where the consonant goes) and the ending added to the key.</p>'
            f'<div class="lf-chart-wrap"><table class="lf-chart"><thead><tr><th scope="col">Consonant</th>{head}</tr>'
            f'</thead><tbody>{"".join(rows)}</tbody></table></div></section>')


def letter_finder():
    data = json.loads(LETTERS.read_text(encoding='utf-8'))
    tabs, panels = [], []
    for i, L in enumerate(data):
        lang = L['lang']
        tabs.append(f'<button class="lf-tab" type="button" role="tab" id="t-lf-{lang}" aria-controls="p-lf-{lang}" '
                    f'aria-selected="{"true" if i == 0 else "false"}">{L["label"]}'
                    f'<span class="lf-native" lang="{SCRIPT_LANG[lang]}">{html.escape(L["native"])}</span>'
                    f'<span class="lf-count">{L["count"]}</span></button>')
        first_key, first_glyph = L['groups'][0]['items'][0]
        groups = ''.join(
            f'<section class="lf-group"><h4>{html.escape(g["name"])} <small>{len(g["items"])}</small></h4>'
            f'<div class="lf-grid">{"".join(letter_tile(lang, L["pattern"], k, gl) for k, gl in g["items"])}</div></section>'
            for g in L['groups'])
        chart = letter_chart(L) if L['chart'] else ''
        pattern = html.escape(L['pattern']).replace('KEY', '<em>key</em>')
        example = html.escape(L['pattern'].replace('KEY', first_key))
        panels.append(f'''<div class="lf-panel" role="tabpanel" id="p-lf-{lang}" aria-labelledby="t-lf-{lang}">
              <p class="lf-pattern">In the NC IDE, type <kbd>{pattern}</kbd>. For example, <kbd>{example}</kbd> turns into
                <span class="lf-inline" lang="{SCRIPT_LANG[lang]}">{html.escape(first_glyph)}</span>.</p>
              {groups}
              {chart}
            </div>''')
    return f'''<div class="lf" data-letter-finder>
            <div class="lf-bar">
              <label class="lf-search"><span class="sr-only">Find a letter</span>
                <input type="search" placeholder="Find a letter: type a key such as ka, or paste a letter" data-lf-search></label>
              <p class="lf-status" aria-live="polite" data-lf-status>Click any letter to copy it.</p>
            </div>
            <div data-tabs>
            <div class="lf-tabs" role="tablist" aria-label="Language">{"".join(tabs)}</div>
            {"".join(panels)}
            </div>
          </div>'''


def ide(text):
    """<ide>X_$a_@b</ide> in content text -> the name drawn the way the NC IDE shows it."""
    return re.sub(r'<ide>(.*?)</ide>',
                  lambda m: f'<span class="lg-ide">{scripted_name(html.unescape(m.group(1))) or m.group(1)}</span>', text)


def figure(f, root):
    """A diagram (image under Images/) with its caption."""
    return (f'<figure class="lg-figure"><img src="{root}{f["src"]}" alt="{html.escape(f["alt"], quote=True)}" '
            f'loading="lazy"><figcaption>{f["caption"]}</figcaption></figure>')


def component(c, index, root=''):
    parts = [f'<p>{ide(t)}</p>' for t in c['text']]
    if c['table']:
        head, *rows = [[ide(v) for v in row] for row in c['table']]
        parts.append('<div class="lg-table-wrap"><table class="lg-table"><thead><tr>' +
                     ''.join(f'<th>{h}</th>' for h in head) + '</tr></thead><tbody>' +
                     ''.join('<tr>' + ''.join(f'<td>{v}</td>' for v in row) + '</tr>' for row in rows) +
                     '</tbody></table></div>')
    if c['math']:
        parts.append(f'<div class="lg-math">\\[{html.escape(c["math"], quote=False)}\\]</div>')
    if c.get('letters'):
        parts.append(letter_finder())
    if c.get('figure'):
        parts.append(figure(c['figure'], root))
    if c['syntax']:
        parts.append('<p class="lg-syntax-label">Syntax</p>'
                     f'<pre class="lg-code lg-syntax"><code>{highlight(c["syntax"])}</code></pre>')
    body = '\n            '.join(parts)
    cid = re.sub(r'[^a-z0-9]+', '-', c['name'].lower()).strip('-')
    return f'''          <section class="lg-component" id="{cid}" aria-labelledby="{cid}-h">
            <h3 class="lg-comp-name" id="{cid}-h"><span>{index:02d}</span>{html.escape(c["name"])}</h3>
            <div class="lg-comp-body">
            {body}
            </div>
          </section>'''


COPY_BUTTON = ('<button class="lg-copy" type="button" data-copy aria-label="Copy code">'
               '<img src="{root}Icons/Interface/copy.svg" alt=""><span>Copy</span></button>')


def code_box(code, root, label='Code:', copy=True, cls=''):
    """A code block with its label and (optionally) a copy button at the top right."""
    button = COPY_BUTTON.format(root=root) if copy else ''
    return (f'<div class="lg-codehead"><p class="lg-box-label">{label}</p>{button}</div>'
            f'<pre class="lg-code{cls}" data-source="{html.escape(code, quote=True)}"><code>{highlight(code)}</code></pre>')


def out_box(result, label='Output:', cls=''):
    out = render_output(result.get('output', '(output not generated yet: run build_language_guide.py with nc.exe)'))
    return f'<p class="lg-box-label">{label}</p><pre class="lg-output{cls}"><samp>{out}</samp></pre>'


def error_kind(result):
    text = result.get('output', '')
    return 'Runtime error' if 'Runtime Error' in text else 'Syntax error'


def errors_panel(slug, pg, outputs, root):
    cards = []
    for n, e in enumerate(pg['errors'], 1):
        wrong, fixed = outputs.get(f'{slug}/err{n}', {}), outputs.get(f'{slug}/err{n}-fix', {})
        note = f'<p class="lg-err-note">{e["fix_text"]}</p>' if e['fix_text'] else ''
        cards.append(f'''            <article class="lg-err">
              <header class="lg-err-head">
                <span class="lg-err-num">{n:02d}</span>
                <h3>{html.escape(e["title"])}</h3>
                <span class="lg-err-kind">{error_kind(wrong)}</span>
              </header>
              <p class="lg-err-text">{e["text"]}</p>
              <div class="lg-err-grid">
                <div class="lg-err-side lg-err-wrong">
                  <p class="lg-err-tag"><img src="{root}Icons/Interface/cross-red.svg" alt="">Wrong</p>
                  {code_box(e["wrong"], root, label="Code:", copy=False, cls=" lg-code-wrong")}
                  {out_box(wrong, label="NC says:", cls=" lg-output-err")}
                </div>
                <div class="lg-err-side lg-err-right">
                  <p class="lg-err-tag"><img src="{root}Icons/Interface/check-green.svg" alt="">Correct</p>
                  {code_box(e["fix"], root, label="Code:")}
                  {out_box(fixed)}
                </div>
              </div>
              {note}
            </article>''')
    intro = ('<p class="lg-err-intro">Common mistakes with this topic. Each card shows the wrong code, the message '
             'NC prints for it, and the corrected code with its output.</p>')
    return '          <div class="lg-errors">\n            ' + intro + '\n' + '\n'.join(cards) + '\n          </div>'


def examples(slug, pg, outputs, root):
    tabs, panels = [], []
    for i, (level, label) in enumerate(LEVELS):
        e = pg['examples'][level]
        result = outputs.get(f'{slug}/{level}', {})
        selected = 'true' if i == 0 else 'false'
        tabs.append(f'<button class="lg-level lg-level-{level}" type="button" role="tab" id="t-{level}" '
                    f'aria-controls="p-{level}" aria-selected="{selected}">{label}</button>')
        panels.append(f'''            <div class="lg-example" role="tabpanel" id="p-{level}" aria-labelledby="t-{level}">
              <h3 class="lg-ex-title">{html.escape(label)}: {html.escape(e["title"])}</h3>
              <p class="lg-ex-text">{e["text"]}</p>
              <div class="lg-box">
                {code_box(e["code"], root)}
                {out_box(result)}
              </div>
            </div>''')
    return ('          <div class="lg-levels" data-tabs>\n'
            '            <div class="lg-level-list" role="tablist" aria-label="Example level">\n              ' +
            '\n              '.join(tabs) + '\n            </div>\n' + '\n'.join(panels) + '\n          </div>')


def pager(sec, slug):
    order = flat_pages()
    i = order.index((sec, slug))
    links = []
    if i > 0:
        s, p = order[i - 1]
        links.append(f'<a class="lg-prev" href="{page_url(s, p, sec)}"><span>Previous</span>{html.escape(PAGES[p]["title"])}</a>')
    else:
        links.append('<a class="lg-prev" href="../../language-guide.html"><span>Previous</span>Language Guide home</a>')
    if i < len(order) - 1:
        s, p = order[i + 1]
        links.append(f'<a class="lg-next" href="{page_url(s, p, sec)}"><span>Next</span>{html.escape(PAGES[p]["title"])}</a>')
    return '        <nav class="lg-pager" aria-label="Previous and next page">' + ''.join(links) + '</nav>'


def head(root, math=True):
    lines = [f'  <link rel="stylesheet" href="{root}Webpage_Framework/Styles/language-guide.css">', f'  {BUILT_MARKER}']
    if math:
        lines += [f'  <link rel="stylesheet" href="{KATEX}/katex.min.css">',
                  f'  <script defer src="{KATEX}/katex.min.js"></script>',
                  f'  <script defer src="{KATEX}/contrib/auto-render.min.js" '
                  'onload="renderMathInElement(document.body,{delimiters:[{left:\'\\\\[\',right:\'\\\\]\',display:true}]})"></script>']
    return '\n'.join(lines) + '\n'


# ------------------------------------------------------------------ pages
def build_page(sec, sec_title, slug, outputs):
    pg = PAGES[slug]
    root = '../../../'
    crumbs = [('Neural Code', 'Neural_Code/overview.html'), ('Language Guide', 'Neural_Code/language-guide.html'),
              (sec_title, None)]
    title = html.escape(pg['title'])
    if pg.get('pending'):
        content = f'''          <div class="lg-pending">
            <p class="lg-pending-badge"><i aria-hidden="true"></i>Under Development</p>
            <p>This part of the Language Guide is being written. Check back soon.</p>
          </div>'''
    else:
        about = '\n'.join(component(c, i, root) for i, c in enumerate(pg['about'], 1))
        err_tab = err_panel = ''
        if pg.get('errors'):
            err_tab = ('\n              <button class="lg-tab lg-tab-err" type="button" role="tab" id="t-errors" '
                       f'aria-controls="p-errors" aria-selected="false">Syntax Error<span class="lg-tab-count">'
                       f'{len(pg["errors"])}</span></button>')
            err_panel = ('\n            <div class="lg-panel" role="tabpanel" id="p-errors" aria-labelledby="t-errors">\n'
                         f'{errors_panel(slug, pg, outputs, root)}\n            </div>')
        content = f'''          <div class="lg-tabs" data-tabs>
            <div class="lg-tab-list" role="tablist" aria-label="{title}">
              <button class="lg-tab" type="button" role="tab" id="t-about" aria-controls="p-about" aria-selected="true">About</button>
              <button class="lg-tab" type="button" role="tab" id="t-examples" aria-controls="p-examples" aria-selected="false">Examples</button>{err_tab}
            </div>
            <div class="lg-panel" role="tabpanel" id="p-about" aria-labelledby="t-about">
{about}
            </div>
            <div class="lg-panel" role="tabpanel" id="p-examples" aria-labelledby="t-examples">
{examples(slug, pg, outputs, root)}
            </div>{err_panel}
          </div>'''
    body = f'''{band(root, crumbs)}
    <div class="lg-layout">
{sidebar(sec, slug)}
      <div class="lg-main">
        <header class="lg-head">
          <p class="lg-kicker">{html.escape(sec_title.upper())}</p>
          <h1>{title}</h1>
          <p class="lg-summary">{pg["summary"]}</p>
        </header>
{content}
{pager(sec, slug)}
      </div>
    </div>'''
    description = re.sub(r'<[^>]+>', '', pg['summary'])
    target = GUIDE / folder(sec) / f'{slug}.html'
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(page(root, f'{pg["title"]} - Language Guide', description, body,
                           head(root, not pg.get('pending'))), encoding='utf-8')


def build_landing():
    root = '../'
    cards = []
    for sec, title, slugs in SECTIONS:
        items = ''.join(
            f'<li><a href="{page_url(sec, s, "landing")}">{html.escape(PAGES[s]["title"])}</a>'
            f'{" <span class=\"lg-soon\">soon</span>" if PAGES[s].get("pending") else ""}</li>' for s in slugs)
        cards.append(f'''          <section class="lg-card">
            <h2>{html.escape(title)}</h2>
            <ul>{items}</ul>
          </section>''')
    first_sec, first_slug = flat_pages()[0]
    body = f'''{band(root, [('Neural Code', 'Neural_Code/overview.html'), ('Language Guide', None)])}
    <div class="lg-layout">
{sidebar('landing')}
      <div class="lg-main">
        <header class="lg-head">
          <p class="lg-kicker">NEURAL CODE</p>
          <h1>{html.escape(LANDING["title"])}</h1>
          <p class="lg-summary">{LANDING["summary"]}</p>
          <a class="btn btn-accent lg-start" href="{page_url(first_sec, first_slug, 'landing')}">Start with {html.escape(PAGES[first_slug]["title"])}</a>
        </header>
        <section class="lg-howto" aria-labelledby="howto">
          <h2 id="howto">How each page works</h2>
          <div class="lg-howto-grid">
            <div><p class="lg-howto-tab">About</p><p>Each part of the topic in turn: what it does, its maths written as a formula, and the syntax for using it.</p></div>
            <div><p class="lg-howto-tab">Examples</p><p>Three runnable examples &mdash; <strong>basic</strong>, <strong>mid level</strong> and <strong>strong</strong> &mdash; each with the output NC prints for it and a Copy button.</p></div>
            <div><p class="lg-howto-tab lg-howto-tab-err">Syntax Error</p><p>Common mistakes, where a topic has them: the wrong code, the message NC prints, and the corrected code.</p></div>
          </div>
        </section>
        <div class="lg-cards">
{chr(10).join(cards)}
        </div>
      </div>
    </div>'''
    target = CODE / 'language-guide.html'
    target.write_text(page(root, 'Language Guide', re.sub(r'<[^>]+>', '', LANDING['summary']), body,
                           head(root, math=False)), encoding='utf-8')


def main():
    outputs = run_examples(force='--run' in sys.argv)
    count = 0
    for sec, sec_title, slugs in SECTIONS:
        for slug in slugs:
            build_page(sec, sec_title, slug, outputs)
            count += 1
    build_landing()
    wanted = {GUIDE / folder(sec) / f'{slug}.html' for sec, _, slugs in SECTIONS for slug in slugs}
    for old in GUIDE.rglob('*.html'):
        if old not in wanted:
            old.unlink()
            print(f'Removed {old.relative_to(SITE).as_posix()} (no longer in the Language Guide)')
    for d in sorted(GUIDE.iterdir()):
        if d.is_dir() and not any(d.iterdir()):
            d.rmdir()
    print(f'Built the Language Guide home page and {count} pages.')


if __name__ == '__main__':
    main()
