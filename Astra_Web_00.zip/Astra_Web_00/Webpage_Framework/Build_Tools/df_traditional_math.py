"""Default Functions - Traditional Mathematics (source: Function_Test/Code/A_05_Traditioal, scripts 05-11).

Scripts 01-04 of the folder are language features and live in the Language Guide (non-English variables,
subscripts and superscripts, arithmetic, logical operators with in / not in).
Every example and error card is run through nc.exe by build_default_functions.py.
"""
from df_helpers import err, ex, fig, fn, reference

IMG = 'Images/Neural_Code/Default_Functions/Traditional_Math/'
LG = '../../Language_Guide/'
PAGES = {}

# ================================================================== 1. Trigonometry
PAGES['trigonometry'] = {
    'title': 'Trigonometry',
    'summary': 'Sine, cosine and tangent, their reciprocals and inverses, the hyperbolic functions, and versions '
               'that take degrees.',
    'about': reference('Every function works on a number, a vector or a matrix, element by element. Angles are in '
                       'radians; <code>sin_deg</code> and <code>cos_deg</code> take degrees, and <code>rad2dec</code> / '
                       '<code>dec2rad</code> convert (see <a href="' + LG + 'Basics/arithmetic.html">Arithmetic</a>).', [
        fn('sin(x) / cos(x) / tan(x)', 'The sine, cosine and tangent.', inputs=[('x', 'angle(s) in radians', '')],
           math=r'\sin^2 x + \cos^2 x = 1, \qquad \tan x = \frac{\sin x}{\cos x}',
           figure=fig(IMG + 'trigonometry-01.svg',
                      'Left: sin, cos and tan from minus 2 pi to 2 pi; tan has vertical asymptotes. Right: sinh, cosh '
                      'and tanh from minus 2 to 2; cosh is always at least 1 and tanh stays between minus 1 and 1.',
                      'The circular functions (left) repeat every 2&pi;; the hyperbolic functions (right) do not.'),
           syntax='sin(pi / 6)    # 0.5\ncos(0)         # 1', short='sine, cosine, tangent'),
        fn('cosec(x) / sec(x) / cot(x)', 'The reciprocals: 1/sin, 1/cos and cos/sin.',
           inputs=[('x', 'angle(s) in radians', '')],
           math=r'\csc x = \frac{1}{\sin x}, \quad \sec x = \frac{1}{\cos x}, \quad \cot x = \frac{\cos x}{\sin x}',
           more=['<code>cosec</code> is not the inverse sine: <code>cosec(0.5)</code> is 2.0858, '
                 '<code>arcsin(0.5)</code> is 0.5236.'], syntax='cosec(0.5)   # 2.085830', short='cosecant, secant, cotangent'),
        fn('arcsin(x) / arccos(x) / arctan(x)', 'The inverse functions, also spelt <code>inv_sin</code>, '
           '<code>inv_cos</code>, <code>inv_tan</code>. Outside the real range the answer is complex, as in NumPy and '
           'MATLAB.', inputs=[('x', 'values', '')],
           math=r'\arcsin(\sin x) = x \quad \text{for } -\tfrac{\pi}{2} \le x \le \tfrac{\pi}{2}',
           syntax='arcsin(0.5)   # 0.523599\narcsin(2)     # 1.570796+1.316958i', short='inverse sine, cosine, tangent'),
        fn('arccosec(x) / arcsec(x) / arccot(x)', 'Inverses of the reciprocals, also spelt <code>inv_cosec</code>, '
           '<code>inv_sec</code>, <code>inv_cot</code>.', inputs=[('x', 'values', '')],
           math=r'\operatorname{arccsc} x = \arcsin \tfrac{1}{x}, \quad \operatorname{arcsec} x = \arccos \tfrac{1}{x}, \quad \operatorname{arccot} x = \arctan \tfrac{1}{x}',
           syntax='arccosec(2)   # = arcsin(1/2)', short='inverse cosecant, secant, cotangent'),
        fn('sinh / cosh / tanh / cosech / sech / coth', 'The hyperbolic functions and their reciprocals.',
           inputs=[('x', 'values', '')],
           math=r'\sinh x = \frac{e^x - e^{-x}}{2}, \quad \cosh x = \frac{e^x + e^{-x}}{2}, \quad \cosh^2 x - \sinh^2 x = 1',
           syntax='cosh(0.5)^2 - sinh(0.5)^2   # 1', short='hyperbolic functions'),
        fn('sin_deg(x) / cos_deg(x)', 'Sine and cosine of angles in degrees.', inputs=[('x', 'angle(s) in degrees', '')],
           syntax='sin_deg(30)   # 0.5'),
    ]),
    'examples': {
        'basic': ex('The six functions', 'Sine, cosine and tangent, their reciprocals, and the identities that tie '
                    'them together.', '''
x = 0.5;
publish("sin, cos, tan      :", sin(x), cos(x), tan(x));
publish("cosec, sec, cot    :", cosec(x), sec(x), cot(x));
publish("sin^2 + cos^2      :", sin(x)^2 + cos(x)^2);
publish("tan = sin/cos      :", tan(x) == sin(x) / cos(x));
publish("degrees            :", sin_deg(30), cos_deg(60));
'''),
        'mid': ex('Inverses', 'Each inverse undoes its function; the two spellings are one function; outside its range '
                  'the inverse sine is complex.', '''
publish(arcsin(0.5), arccos(0.5), arctan(0.5));
publish("undo  :", arcsin(sin(0.7)), arccos(cos(0.7)), arctan(tan(0.7)));
publish("names :", arcsin(0.3) == inv_sin(0.3), arccot(3) == inv_cot(3));
publish("recip :", arccosec(2), arcsin(1 / 2));
v = arcsin([0, 0.5, 1])
z = arcsin(2)
'''),
        'strong': ex('A pendulum and a hanging cable', 'The swing of a pendulum at several times, then the sag of a '
                     'cable that hangs in a catenary curve, y = a cosh(x/a).', '''
theta0 = 0.2;
w = 2 * pi / 1.5;
t = [0, 0.25, 0.5, 0.75, 1.0];
angle = theta0 * cos(w * t)
a = 20;
x = [-10, -5, 0, 5, 10];
y = a * cosh(x / a)
sag = y[0, 0] - y[0, 2]
publish("cosh^2 - sinh^2 = 1:", allclose(cosh(0.5)^2 - sinh(0.5)^2, 1, atol=1e-12), "  coth = 1/tanh:", allclose(coth(0.5), 1 / tanh(0.5), atol=1e-12));
'''),
    },
    'errors': [
        err('The sine of text', 'Trigonometric functions take numbers.', 'y = sin("a");', 'y = sin(float("0.5"));\npublish(y);'),
    ],
}

# ================================================================== 2. Shapes and solids
PAGES['shapes-solids'] = {
    'title': 'Shapes & Solids',
    'summary': 'The area and perimeter of eighteen plane shapes, and the surface and volume of four solids, from '
               'their side lengths or radii.',
    'about': reference('Each <code>char_</code> function returns a dictionary: <code>{area, perimeter}</code> for '
                       'a plane shape, <code>{surface, volume}</code> for a solid. Read a value with '
                       '<code>r.area</code> or <code>r["area"]</code>. Lengths cannot be negative.', [
        fn('char_circle(r) / char_semicircle(r)', 'A circle or half circle of radius r.', inputs=[('r', 'radius', '')],
           math=r'A = \pi r^2,\quad P = 2\pi r; \qquad \text{half: } A = \tfrac{\pi r^2}{2},\; P = \pi r + 2r',
           figure=fig(IMG + 'shapes-solids-01.svg',
                      'Line drawings of the shapes with their inputs labelled: circle r, square a, rectangle l by w, '
                      'rhombus with diagonals d1 and d2, trapezoid with parallel sides a and b and height h, right '
                      'triangle with legs a and b, regular polygon with side s and n sides, ellipse with half-axes a '
                      'and b, and the solids cube a, sphere r, cylinder r and h, cone r and h.',
                      'What each input of the <code>char_</code> functions measures.'),
           syntax='r = char_circle(4);\nr.area    # 50.265482'),
        fn('char_square(a) / char_rectangle(l, w)', 'A square of side a; a rectangle l by w.',
           inputs=[('a / l, w', 'side lengths', '')], math=r'A = l\,w, \qquad P = 2(l + w)'),
        fn('char_triangle(a) / char_rtriangle(a, b)', 'An equilateral triangle of side a; a right triangle with legs a '
           'and b.', inputs=[('a, b', 'side lengths', '')],
           math=r'A = \tfrac{\sqrt 3}{4} a^2; \qquad A = \tfrac{a b}{2},\; P = a + b + \sqrt{a^2 + b^2}'),
        fn('char_rhombus(d1, d2)', 'A rhombus with diagonals d1 and d2.', inputs=[('d1, d2', 'the two diagonals', '')],
           math=r'A = \tfrac{d_1 d_2}{2}, \qquad P = 2\sqrt{d_1^2 + d_2^2}'),
        fn('char_trapezoid(a, b, h)', 'An isosceles trapezoid with parallel sides a and b and height h.',
           inputs=[('a, b', 'parallel sides', ''), ('h', 'height', '')],
           math=r'A = \tfrac{(a + b)}{2} h, \qquad P = a + b + 2\sqrt{\left(\tfrac{a-b}{2}\right)^2 + h^2}'),
        fn('char_pentagon(s) / char_hexagon(s) / char_heptagon(s) / char_nonagon(s)', 'Regular polygons with 5, 6, 7 '
           'or 9 sides of length s.', inputs=[('s', 'side length', '')], short='regular 5-, 6-, 7- and 9-gons'),
        fn('char_polygon(s, n)', 'A regular polygon with n sides of length s.',
           inputs=[('s', 'side length', ''), ('n', 'number of sides, 3 or more', '')],
           math=r'A = \frac{n s^2}{4} \cot\frac{\pi}{n}, \qquad P = n s'),
        fn('char_ellipse(a, b)', 'An ellipse with half-axes a and b; the perimeter by Ramanujan\'s approximation.',
           inputs=[('a, b', 'half-axes', '')],
           math=r'A = \pi a b, \qquad P \approx \pi\left[3(a+b) - \sqrt{(3a+b)(a+3b)}\right]'),
        fn('char_cube(a) / char_sphere(r)', 'A cube of side a; a sphere of radius r.', inputs=[('a / r', 'side / radius', '')],
           math=r'\text{cube: } S = 6a^2,\; V = a^3; \qquad \text{sphere: } S = 4\pi r^2,\; V = \tfrac43 \pi r^3'),
        fn('char_cylinder(r, h) / char_cone(r, h)', 'A cylinder or cone of radius r and height h (closed surfaces).',
           inputs=[('r', 'radius', ''), ('h', 'height', '')],
           math=r'\text{cylinder: } V = \pi r^2 h; \qquad \text{cone: } V = \tfrac13 \pi r^2 h,\; S = \pi r\left(r + \sqrt{r^2 + h^2}\right)'),
    ]),
    'examples': {
        'basic': ex('Plane shapes', 'Area and perimeter of five shapes, read from the dictionaries.', '''
c = char_circle(4)
s = char_square(4)
r = char_rectangle(4, 1)
t = char_triangle(3)
publish("circle area:", c.area, "  perimeter:", c["perimeter"]);
'''),
        'mid': ex('Less regular shapes', 'Rhombus, trapezoid, right triangle, a regular decagon and an ellipse.', '''
h = char_rhombus(4, 0.5235)
z = char_trapezoid(10, 6, 4)
rt = char_rtriangle(6, 4)
p = char_polygon(4, 10)
e = char_ellipse(4, 1)
'''),
        'strong': ex('A water tank', 'A cylindrical tank with a conical roof: total volume, the area to paint, and '
                     'how the volume of a sphere grows as its radius doubles.', '''
body = char_cylinder(4, 6);
roof = char_cone(4, 2);
publish("volume:", body.volume + roof.volume, "m^3");
base = char_circle(4).area;
paint = (body.surface - 2 * base) + (roof.surface - base);
publish("walls and roof to paint:", round(paint, decimals=2), "m^2");
for r = [1, 2, 4]:
   publish("sphere r =", r, "  volume", round(char_sphere(r).volume, decimals=3));
fend
'''),
    },
    'errors': [
        err('A negative radius', 'Lengths cannot be negative.', 'y = char_circle(-1);', 'y = char_circle(1);\npublish(y);'),
        err('A polygon with two sides', 'A polygon needs at least 3 sides.', 'y = char_polygon(4, 2);',
            'y = char_polygon(4, 3);\npublish(y);'),
    ],
}

# ================================================================== 3. Descriptive statistics
XY = 'X = [2.5, 3.1, 4.7, 4.7, 5.0, 6.2, 8.8, 9.4, 12.1, 15.6];\nY = [1.2, 2.4, 2.2, 3.9, 4.1, 6.5, 7.7, 9.9, 10.1, 16.0];\n'
PAGES['descriptive-statistics'] = {
    'title': 'Descriptive Statistics',
    'summary': 'The centre, spread and shape of data: means of several kinds, median and mode, variance and '
               'deviation for samples and populations, skewness, kurtosis, quartiles and percentiles.',
    'about': reference('The data can be a row, a column or a matrix; a matrix counts as the list of all its elements. '
                       'For per-column statistics with an axis and NaN handling see <a href="../Arrays_Data/'
                       'reductions.html">Reductions</a> and <a href="../Arrays_Data/missing-data.html">Missing Data</a>.', [
        fn('mean(A) / median(A) / mode(A)', 'The average, the middle value, and the most frequent value(s). '
           '<code>mode</code> gives every most-frequent value, or the text "No mode" when all values occur once.',
           inputs=[('A', 'vector or matrix', '')], math=r'\bar x = \frac{1}{n}\sum_i x_i',
           figure=fig(IMG + 'descriptive-statistics-01.svg',
                      'The ten values of X on a number line, with the mean 7.21, the median 5.6, the quartiles Q1 4.7 '
                      'and Q3 9.4 marked, and a box from Q1 to Q3 showing the inter-quartile range.',
                      'The data set X from the examples: centre (mean and median) and spread (quartiles and IQR).'),
           syntax='mean([1, 2, 3, 4])   # 2.5', short='average, middle, most frequent'),
        fn('geo_mean(A) / harmo_mean(A) / trim_mean(A)', 'The geometric and harmonic means (positive values only), and '
           'the mean after dropping 10% from each end.', inputs=[('A', 'vector or matrix', '')],
           math=r'G = \Big(\prod_i x_i\Big)^{1/n}, \qquad H = \frac{n}{\sum_i 1/x_i}', short='geometric, harmonic, trimmed means'),
        fn('var(A) / sd(A)', 'The sample variance and standard deviation (divide by n &minus; 1).',
           inputs=[('A', 'vector or matrix', '')], math=r's^2 = \frac{1}{n-1}\sum_i (x_i - \bar x)^2', short='sample variance and deviation'),
        fn('pvar(A) / psd(A)', 'The population variance and standard deviation (divide by n).',
           inputs=[('A', 'vector or matrix', '')], math=r'\sigma^2 = \frac{1}{n}\sum_i (x_i - \bar x)^2', short='population variance and deviation'),
        fn('coeff_var(A) / std_error(A)', 'The coefficient of variation (sd / mean, as a percentage) and the standard '
           'error of the mean.', inputs=[('A', 'vector or matrix', '')],
           math=r'CV = \frac{s}{\bar x}\times 100, \qquad SE = \frac{s}{\sqrt n}', short='relative spread, error of the mean'),
        fn('skew(A) / kurtosis(A)', 'Population skewness and excess kurtosis: how lopsided and how heavy-tailed the '
           'data is (0 for a normal distribution).', inputs=[('A', 'vector or matrix', '')],
           math=r'g_1 = \frac{m_3}{m_2^{3/2}}, \qquad g_2 = \frac{m_4}{m_2^2} - 3', short='asymmetry and tail weight'),
        fn('Q1(A) / Q2(A) / Q3(A) / IQR(A) / range(A)', 'Quartiles by the median-of-halves method, the inter-quartile '
           'range Q3 &minus; Q1, and max &minus; min.', inputs=[('A', 'vector or matrix', '')],
           syntax='Q1(X)\nIQR(X)', short='quartiles, IQR, range'),
        fn('percentile(A, p)', 'The p-th percentile by linear interpolation (NumPy\'s default).',
           inputs=[('A', 'vector or matrix', ''), ('p', '0 to 100', '')], syntax='percentile(X, 25)'),
    ]),
    'examples': {
        'basic': ex('Centre', 'Three means, median and mode of the numbers 1 to 15 and of uneven data.', XY + '''
A = [1:15];
publish("mean", mean(A), " median", median(A), " mode:", mode(A));
publish("mean", mean(X), " median", median(X), " mode", mode(X));
publish("geometric", geo_mean(X), " harmonic", harmo_mean(X), " trimmed", trim_mean(X));
m = mode([1, 1, 2, 2, 3])
'''),
        'mid': ex('Spread', 'Sample and population variance, deviation, relative spread and the error of the mean.', XY + '''
publish("sample     var", var(X), " sd", sd(X));
publish("population var", pvar(X), " sd", psd(X));
publish("coeff_var", coeff_var(X), "%  std_error", std_error(X));
publish("matrix input:", var([1, 2; 3, 4]), mean([1, 2; 3, 4]));
'''),
        'strong': ex('Shape and position', 'Skewness and kurtosis, the five-number summary and percentiles, and a '
                     'check that symmetric data has no skew.', XY + '''
publish("skew", skew(X), "  kurtosis", kurtosis(X));
publish("min", min(X), " Q1", Q1(X), " median", Q2(X), " Q3", Q3(X), " max", max(X));
publish("IQR", IQR(X), "  range", range(X), "  90th percentile", percentile(X, 90));
publish("symmetric data, skew:", skew([1:15]));
'''),
    },
    'errors': [
        err('A geometric mean of negative data', 'geo_mean and harmo_mean need positive values.', 'y = geo_mean([-1, 2]);',
            'y = geo_mean([1, 2]);\npublish(y);'),
        err('A statistic of a single number', 'The statistics take a vector or a matrix.', 'y = mean(5);',
            'y = mean([5]);\npublish(y);'),
        err('A percentile above 100', 'p runs from 0 to 100.', 'y = percentile([1, 2, 3], 120);',
            'y = percentile([1, 2, 3], 100);\npublish(y);'),
    ],
}

# ================================================================== 4. Relationships and tests
PAGES['relationships-tests'] = {
    'title': 'Relationships & Tests',
    'summary': 'Correlation and covariance between two data sets, the least-squares line, p-values, a decision on '
               'the null hypothesis, the chi-square statistic, and scaling data.',
    'about': reference('Two data sets must have the same number of values.', [
        fn('corr_coeff(A, B) / co_var(A, B)', 'The Pearson correlation (&minus;1 to 1) and the sample covariance.',
           inputs=[('A, B', 'vectors or matrices of the same length', '')],
           math=r'r = \frac{\sum (x_i - \bar x)(y_i - \bar y)}{\sqrt{\sum (x_i - \bar x)^2 \sum (y_i - \bar y)^2}}',
           figure=fig(IMG + 'relationships-tests-01.svg',
                      'A scatter plot of Y against X with the least-squares line y = -1.3485 + 1.07469 x drawn through '
                      'the points; the correlation is 0.979.',
                      'The data from the examples with <code>lsm(X, Y)</code> drawn through it.'),
           short='correlation and covariance'),
        fn('lsm(y) / lsm(x, y)', 'The least-squares straight line, as text "y = a + bx": through y against 0, 1, 2 '
           '..., or of y on x.', inputs=[('x, y', 'vectors of the same length', '')],
           math=r'b = \frac{\sum (x_i - \bar x)(y_i - \bar y)}{\sum (x_i - \bar x)^2}, \qquad a = \bar y - b \bar x',
           syntax='lsm([1, 2, 3], [6, 4, 2])   # "y = 8 - 2x"', short='least-squares line as text'),
        fn('p_val_cal(z) / p_val_cal(data)', 'A one-tailed p-value of a z-score; or, for data, the two-tailed p-value '
           'of the one-sample t-test of "mean = 0".', inputs=[('z / data', 'one number, or a vector', '')],
           syntax='p_val_cal(1.96)   # 0.025', short='p-value of a z-score or a t-test'),
        fn('null_hypo(p) / null_hypo(data)', '"Reject H0" when the p-value is below 5%, otherwise "Fail to Reject '
           'H0"; for data, the decision of the t-test.', inputs=[('p / data', 'a p-value, or a vector', '')],
           syntax='null_hypo(0.01)   # "Reject H0"', short='decision at the 5% level'),
        fn('chi_test(O, E)', 'The chi-square statistic of observed against expected counts. It is a statistic, not a '
           'p-value: do not pass it to <code>null_hypo</code>.', inputs=[('O, E', 'observed and expected values', '')],
           math=r'\chi^2 = \sum_i \frac{(O_i - E_i)^2}{E_i}', short='chi-square statistic'),
        fn('norm(A) / lnorm(A)', 'The Euclidean length of all the values (also <code>l2norm</code>); min-max scaling of '
           'every value into 0 to 1, keeping the shape.', inputs=[('A', 'vector or matrix', '')],
           math=r'\text{lnorm}(x) = \frac{x - \min}{\max - \min}', short='length and 0&ndash;1 scaling'),
    ]),
    'examples': {
        'basic': ex('Two data sets together', 'Correlation, covariance and the best straight line.', XY + '''
publish("correlation", corr_coeff(X, Y), "  covariance", co_var(X, Y));
publish(lsm(X, Y));
publish(lsm([1:15]), " | ", lsm([1, 2, 3], [6, 4, 2]));
'''),
        'mid': ex('p-values and decisions', 'From a z-score, from data around 10, and from data around 0.', '''
publish("z = 1.96 ->", p_val_cal(1.96));
d1 = [9.8, 10.3, 10.1, 9.7, 10.4, 10.0];
publish("data near 10:", p_val_cal(d1), null_hypo(d1));
d0 = [-1, 1, -2, 2, 0.5, -0.5];
publish("data near 0 :", p_val_cal(d0), null_hypo(d0));
publish(null_hypo(0.01), " / ", null_hypo(0.5));
'''),
        'strong': ex('Dice and scaling', 'Is a die fair? Observed counts against the expected 10 per face, with the '
                     'chi-square statistic compared to its 5% critical value for 5 degrees of freedom (11.07). Then '
                     'scaling and length.', XY + '''
observed = [8, 12, 9, 11, 6, 14];
expected = [10, 10, 10, 10, 10, 10];
chi = chi_test(observed, expected);
publish("chi-square =", chi, "  fair at 5%?", chi < 11.07);
s = lnorm([1, 2; 3, 5])
publish("first scaled X:", lnorm(X)[0:2], "  length of X:", norm(X));
'''),
    },
    'errors': [
        err('Data sets of different lengths', 'Pairs need the same number of values.', 'y = corr_coeff([1, 2, 3], [1, 2]);',
            'y = corr_coeff([1, 2, 3], [1, 2, 4]);\npublish(y);'),
        err('An expected count of zero', 'The chi-square statistic divides by each expected value.',
            'y = chi_test([1, 2], [1, 0]);', 'y = chi_test([1, 2], [1, 2]);\npublish(y);'),
    ],
}

# ================================================================== 5. Matrix functions
C4 = 'C = [2, 4, 9, 6; 8, 6, 7, 9; 9, 5, 9, 57; 1, 2, 3, 8];\n'
PAGES['matrix-functions'] = {
    'title': 'Matrix Functions',
    'summary': 'Rank, determinant, inverse, adjoint and pseudo-inverse; transposes and conjugates; special '
               'matrices; and tests for full rank, singularity and definiteness.',
    'about': reference('Matrices are written with commas between values and semicolons between rows: '
                       '<code>[1, 2; 3, 4]</code>. See also <a href="' + LG + 'Basics/matrices.html">Matrices</a> in the '
                       'Language Guide and <a href="../Core_Math/norms-decompositions.html">Norms &amp; Decompositions'
                       '</a>.', [
        fn('rank(A) / det(A) / trace(A)', 'The number of independent rows, the determinant (square matrices), and the '
           'sum of the diagonal.', inputs=[('A', 'matrix', '')], syntax='det(C)   # -2105', short='rank, determinant, trace'),
        fn('inv(A) / adj(A)', 'The inverse and the adjoint (adjugate) of a square matrix.', inputs=[('A', 'square matrix', '')],
           math=r'A^{-1} = \frac{\operatorname{adj}(A)}{\det A}', short='inverse and adjoint'),
        fn('pseudo_inverse(A) / pinv(A)', 'The Moore&ndash;Penrose pseudo-inverse; works for any shape.',
           inputs=[('A', 'matrix', '')], math=r'A\,A^{+}A = A', short='pseudo-inverse'),
        fn('transpose(A) / A\' / conjugate(A) / conj(A)', 'Rows and columns swapped; imaginary parts negated.',
           inputs=[('A', 'matrix', '')], syntax="transpose(C) == C'", short='transpose and conjugate'),
        fn('had_prod(A, B)', 'The Hadamard (element-by-element) product, the same as <code>A *. B</code>.',
           inputs=[('A, B', 'matrices of the same size', '')], math=r'(A \circ B)_{ij} = a_{ij} b_{ij}'),
        fn('norm(A)', 'The Frobenius norm, the same as <code>matrix_norm(A)</code>.', inputs=[('A', 'matrix', '')]),
        fn('unit_matrix(n) / zero_matrix(n[, m]) / diag(x)', 'The identity, a zero matrix, and diagonal matrices: '
           '<code>diag(n)</code> is n x n with n on the diagonal, <code>diag(v)</code> puts a vector on the diagonal, '
           '<code>diag(M)</code> gives the diagonal of a matrix.', inputs=[('n, m', 'sizes', ''), ('x', 'number, vector or matrix', '')],
           syntax='diag([1, 2])        # 1 0; 0 2\ndiag([1, 2; 3, 4])  # 1; 4', short='identity, zero and diagonal matrices'),
        fn('upper_triangular(x) / lower_triangular(x)', 'A triangle of ones of size n, or the upper / lower part of a '
           'matrix.', inputs=[('x', 'size n, or a matrix', '')], syntax='upper_triangular(3)', short='triangular matrices'),
        fn('full_rank_matrix(A) / singular_matrix(A)', '1 (yes) or 0 (no): is the rank as large as it can be? is the '
           'determinant zero?', inputs=[('A', 'matrix', '')], short='full rank? singular?'),
        fn('pd_matrix(A) / nd_matrix(A)', '1 (yes) or 0 (no): is A symmetric positive (negative) definite? A matrix '
           'that is not symmetric answers 0.', inputs=[('A', 'square matrix', '')],
           math=r'A \succ 0 \iff x^{T} A x > 0 \text{ for every } x \neq 0', short='positive / negative definite?'),
    ]),
    'examples': {
        'basic': ex('Rank, determinant, inverse', 'A 4 x 4 matrix: its numbers, inverse and adjoint, checked by '
                    'multiplication.', C4 + '''
publish("rank", rank(C), "  det", det(C), "  trace", trace(C));
I = inv(C);
publish("C * inv(C) is the unit matrix:", allclose(C * I, unit_matrix(4), atol=1e-9));
publish("inv = adj / det:", allclose(I, adj(C) / det(C), atol=1e-9));
publish("a singular matrix has rank", rank([1, 2, 3; 4, 5, 6; 7, 8, 9]));
'''),
        'mid': ex('Special matrices', 'Identity, zero, diagonal and triangular matrices, transposes and the Hadamard '
                  'product.', '''
U = unit_matrix(3)
Z = zero_matrix(2, 3)
D = diag([1, 2])
d = diag([1, 2; 3, 4])
L = lower_triangular(3)
H = had_prod([1, 2; 3, 4], [5, 6; 7, 8])
T = transpose([1, 2, 3; 4, 5, 6])
'''),
        'strong': ex('Tests and the pseudo-inverse', 'Which matrices are full rank, singular or definite; and the '
                     'pseudo-inverse of a matrix that is not square.', C4 + '''
PD = [2, -1, 0; -1, 2, -1; 0, -1, 2];
publish("full rank / singular C   :", full_rank_matrix(C), singular_matrix(C));
publish("full rank / singular 1..9:", full_rank_matrix([1, 2, 3; 4, 5, 6; 7, 8, 9]), singular_matrix([1, 2, 3; 4, 5, 6; 7, 8, 9]));
publish("PD: positive / negative definite:", pd_matrix(PD), nd_matrix(PD));
publish("-PD:", pd_matrix(-1 * PD), nd_matrix(-1 * PD), "  indefinite:", pd_matrix([1, 0; 0, -1]), nd_matrix([1, 0; 0, -1]));
D = [2, 4, 9, 6; 8, 6, 7, 9; 9, 5, 9, 57];
P = pseudo_inverse(D);
publish("D * pinv(D) * D == D:", allclose(D * P * D, D, atol=1e-9), "  size of pinv:", size(P));
'''),
    },
    'errors': [
        err('The inverse of a singular matrix', 'The second row is twice the first; use pinv for a best answer.',
            'y = inv([1, 2; 2, 4]);', 'y = pinv([1, 2; 2, 4]);\npublish(y);'),
        err('The determinant of a matrix that is not square', 'det, inv, adj and the definiteness tests need square '
            'matrices.', 'y = det([1, 2, 3; 4, 5, 6]);', 'y = det([1, 2; 4, 5]);\npublish(y);'),
        err('A Hadamard product of different sizes', 'Element by element needs the same size.',
            'y = had_prod([1, 2], [1, 2, 3]);', 'y = had_prod([1, 2], [3, 4]);\npublish(y);'),
    ],
}

# ================================================================== 6. Calculus
FUNCS = '''function y = f_cube(x):
   y = x ^ 3;
fnend
function z = f_xy(x, y):
   z = x ^ 2 * y;
fnend
'''
GRID = 'g = space(0, 1, 11);\n[X, Y] = meshgrid(g, g);\n'
PAGES['calculus'] = {
    'title': 'Calculus',
    'summary': 'Derivatives, partial derivatives, gradients, curl and the Laplacian, continuity, Green\'s and '
               'Stokes\'s theorems, Taylor series and the radius of convergence: on functions and on sampled data.',
    'about': reference('Most functions take either a function written with <code>function &hellip; fnend</code> and '
                       'passed as <code>@f</code>, or sampled data: a vector of values spaced h apart, or a grid Z with '
                       'rows along y and columns along x (as <code>meshgrid</code> gives). More vector calculus is in '
                       'the Engineering Mathematics domain.', [
        fn('ddt(@f, x) / ddt(Y, h) / ddt(Y, x) / ddt(f_plus, f_minus, h)', 'The derivative: of a function at a point; '
           'of samples spaced h apart (or at coordinates x); or the central difference from f(x+h) and f(x&minus;h).',
           math=r"f'(x) \approx \frac{f(x+h) - f(x-h)}{2h}", syntax='ddt(@f_cube, 2)   # about 12 (numerical)', short='derivative'),
        fn('pddt(@f, point, "x") / pddt(Z, "x" | "y", h)', 'A partial derivative with respect to x or y.',
           math=r'\frac{\partial}{\partial x}(x^2 y) = 2xy', syntax='pddt(@f_xy, [1, 2], "x")   # about 4', short='partial derivative'),
        fn('grad(@f, point) / grad(Y, h) / grad(Z, dx, dy)', 'The gradient: a vector at a point, the derivative of '
           'samples, or a dictionary {x: dZ/dx, y: dZ/dy} for a grid.', math=r'\nabla f = \left(\frac{\partial f}{\partial x}, \frac{\partial f}{\partial y}\right)',
           syntax='grad(@f_xy, [1, 2])   # about [4, 1]', short='gradient'),
        fn('curl(@F, point) / curl(U, V, dx, dy) / curl([Fx, Fy, Fz])', 'The curl of a vector field at a point, of a '
           '2-D field on a grid, or (old form) a cyclic difference of three values.',
           math=r'\nabla \times F = \left(\frac{\partial F_z}{\partial y} - \frac{\partial F_y}{\partial z},\; \frac{\partial F_x}{\partial z} - \frac{\partial F_z}{\partial x},\; \frac{\partial F_y}{\partial x} - \frac{\partial F_x}{\partial y}\right)',
           syntax='curl(@f_spin, [1, 2, 3])   # 0 0 2', short='curl'),
        fn('laplace(Y, h) / laplace(Z, dx, dy) / laplace([fxx, fyy, fzz])', 'The Laplacian: the sum of the second '
           'derivatives.', math=r'\nabla^2 f = \frac{\partial^2 f}{\partial x^2} + \frac{\partial^2 f}{\partial y^2}',
           syntax='laplace(X ^. 2 + Y ^. 2, 0.1, 0.1)   # 4 everywhere', short='Laplacian'),
        fn('div(@F, point) / div(U, V[, W], dx, dy[, dz])', 'The divergence of a vector field at a point or on a 2-D '
           'or 3-D grid (a 3-D grid is an N-D matrix [nz, ny, nx]). <code>grad</code>, <code>curl</code> and '
           '<code>laplace</code> take 3-D grids the same way. More on <a href="../Engineering_Math/vector-calculus.html">'
           'Vector Calculus</a>.', math=r'\nabla \cdot F = \frac{\partial F_1}{\partial x} + \frac{\partial F_2}{\partial y} + \frac{\partial F_3}{\partial z}',
           syntax='div(@F, [1, 2, 3])\ndiv(X ^. 2, Y ^. 2, 0.1, 0.1)   # 2x + 2y', short='divergence'),
        fn('continuity(@f, x0) / continuity(a)', '1 when f is continuous at x0 (or every value of a is finite), else 0.',
           syntax='continuity(@f_cube, 2)   # 1', short='continuity test'),
        fn('green_integral(@P, @Q, x0, x1, y0, y1) / green_integral(P, Q, dx, dy)', 'Green\'s theorem on a rectangle: '
           'the circulation of (P, Q) round the boundary, equal to the double integral of the curl inside.',
           math=r'\oint_{C} (P\,dx + Q\,dy) = \iint_{D} \left(\frac{\partial Q}{\partial x} - \frac{\partial P}{\partial y}\right) dA',
           figure=fig(IMG + 'calculus-01.svg',
                      'A region D in the plane with its boundary curve C traversed counter-clockwise. Arrows of the '
                      'field (P, Q) = (-y, x) circle round. The line integral round C equals the double integral of '
                      'dQ/dx - dP/dy over D; for this field and the unit square both are 2.',
                      'Green\'s theorem: what flows round the edge equals the total spin inside. For '
                      '(P, Q) = (&minus;y, x) on the unit square both sides are 2.'),
           syntax='green_integral(@f_P, @f_Q, 0, 1, 0, 1)   # 2', short='Green\'s theorem'),
        fn('stokes_integral(@F, X, Y, Z)', 'Stokes\'s theorem on a surface given by grids X, Y, Z: a dictionary with '
           'the surface integral of curl F and the circulation of F round the boundary, which are equal.',
           math=r'\iint_{S} (\nabla \times F) \cdot dS = \oint_{\partial S} F \cdot dr',
           figure=fig(IMG + 'calculus-02.svg',
                      'A curved surface S with its normal vector, the boundary curve dS traversed so the surface is on '
                      'the left, and the curl of the field crossing the surface. The flux of the curl through S equals '
                      'the circulation of F round the boundary.',
                      'Stokes\'s theorem: Green\'s theorem lifted onto a curved surface in space.'),
           syntax='S = stokes_integral(@f_spin, X, Y, zeros(11, 11));\nS["surface_integral"]\nS["circulation"]', short='Stokes\'s theorem'),
        fn('taylor_series(@f, x0, x, n)', 'The value at x of the first n terms of the Taylor series of f about x0.',
           math=r'f(x) \approx \sum_{k=0}^{n-1} \frac{f^{(k)}(x_0)}{k!}(x - x_0)^k',
           figure=fig(IMG + 'calculus-03.svg',
                      'The curve e to the x, and its Taylor approximations about 0 with 2, 3, 4 and 6 terms; each '
                      'extra term hugs the curve over a wider range.',
                      'Taylor approximations of e<sup>x</sup> about 0: more terms, a wider good range.'),
           syntax='taylor_series(@f_exp, 0, 1, 6)', short='Taylor series'),
        fn('rad_of_con([a0, a1, a2, ...])', 'The radius of convergence of the power series with these coefficients.',
           math=r'R = \lim_{n\to\infty} \left|\frac{a_n}{a_{n+1}}\right|', syntax='rad_of_con([1, 2, 4, 8, 16, 32])   # 0.5',
           short='radius of convergence'),
    ]),
    'examples': {
        'basic': ex('Derivatives and continuity', 'The derivative of x<sup>3</sup> at 2, of sampled data, a partial '
                    'derivative and a gradient.', FUNCS + '''
publish("d/dx x^3 at 2     :", ddt(@f_cube, 2));
publish("slope of 1..8     :", ddt([1, 2, 3, 4, 5, 6, 7, 8], 1));
publish("d/dx x^2 y at 1,2 :", pddt(@f_xy, [1, 2], "x"));
publish("grad x^2 y at 1,2 :", grad(@f_xy, [1, 2]));
publish("continuous at 2   :", continuity(@f_cube, 2), "  1/0 finite:", continuity(1 / 0));
'''),
        'mid': ex('Green\'s and Stokes\'s theorems', 'The field (&minus;y, x) spins once round the origin. On the unit '
                  'square, the circulation round the edge and the spin inside agree: 2 in both theorems, from '
                  'functions and from grids.', GRID + '''
function p = f_P(x, y):
   p = -y;
fnend
function q = f_Q(x, y):
   q = x;
fnend
function F = f_spin(x, y, z):
   F = [-y, x, 0];
fnend
publish("Green, functions:", green_integral(@f_P, @f_Q, 0, 1, 0, 1));
publish("Green, grids    :", green_integral(-1 * Y, X, 0.1, 0.1));
S = stokes_integral(@f_spin, X, Y, zeros(11, 11));
publish("Stokes: surface integral", S["surface_integral"], "  circulation", S["circulation"]);
publish("curl at a point:", curl(@f_spin, [1, 2, 3]));
'''),
        'strong': ex('Grids, Taylor series and convergence', 'Derivatives on a grid of x<sup>2</sup>y, the Laplacian '
                     'of x<sup>2</sup> + y<sup>2</sup>, Taylor approximations of e<sup>x</sup>, and radii of '
                     'convergence.', GRID + '''
function y = f_exp(x):
   y = exp(x);
fnend
Z = X ^. 2 *. Y;
G = grad(Z, 0.1, 0.1);
publish("dZ/dx = 2xy on the grid:", allclose(G["x"], 2 * X *. Y, atol=1e-9));
publish("dZ/dy = x^2:", allclose(pddt(Z, "y", 0.1), X ^. 2, atol=1e-9));
publish("laplace(x^2 + y^2) = 4:", allclose(laplace(X ^. 2 + Y ^. 2, 0.1, 0.1), 4 * ones(11, 11), atol=1e-9));
for n = [2, 4, 6, 10]:
   publish("e^1 with", n, "terms:", taylor_series(@f_exp, 0, 1, n), "  error", exp(1) - taylor_series(@f_exp, 0, 1, n));
fend
publish("R of 1, 2, 4, 8 ...:", rad_of_con([1, 2, 4, 8, 16, 32]), "  R of n + 1:", rad_of_con([1:8]));
'''),
    },
    'errors': [
        err('A Taylor series of a number', 'Pass a function reference with @.', 'y = taylor_series(5, 0, 2, 4);',
            'function y = f(x):\n   y = x ^ 3;\nfnend\ny = taylor_series(@f, 0, 2, 4);\npublish(y);'),
        err('A step of zero', 'The spacing h must be positive.', 'y = ddt([1, 2, 3], 0);', 'y = ddt([1, 2, 3], 1);\npublish(y);'),
        err('A series with one coefficient', 'The radius needs at least two coefficients.', 'y = rad_of_con([1]);',
            'y = rad_of_con([1, 1]);\npublish(y);'),
    ],
}

# ================================================================== 7. Vectors
PAGES['vectors'] = {
    'title': 'Vectors',
    'summary': 'Unit vectors, lengths and direction cosines, projections, perpendicular vectors, the triple '
               'product, eigenvalues and eigenvectors.',
    'about': reference('A vector is one row of values, such as <code>[3, 4]</code>. Two names differ from the '
                       'textbook meaning: <code>divergence(A)</code> is the sum of the elements and <code>curl(A)</code> '
                       'a cyclic difference of three values; neither differentiates a field (for that, see '
                       '<a href="calculus.html">Calculus</a>).', [
        fn('unit_vector(A) / dircos(A) / proj_vec(A)', 'The vector scaled to length 1; its components are the direction '
           'cosines.', inputs=[('A', 'vector', '')], math=r'\hat a = \frac{a}{\|a\|}', short='unit vector, direction cosines'),
        fn('norm(A)', 'The length of the vector.', inputs=[('A', 'vector', '')], math=r'\|a\| = \sqrt{\sum a_i^2}'),
        fn('proj(A, B)', 'The projection of A onto the direction of B.', inputs=[('A, B', 'vectors of the same length', '')],
           math=r'\operatorname{proj}_b a = \frac{a \cdot b}{b \cdot b}\, b',
           figure=fig(IMG + 'vectors-01.svg',
                      'Two arrows a = (4, 1) and b = (2, 2) from the origin. The projection of a onto b is the shadow of '
                      'a along b, (2.5, 2.5). The orthogonal vector to (3, 4) is (-4, 3), at right angles.',
                      'The projection of a on b, and the vector at right angles that <code>orthogonal</code> gives.'),
           syntax='proj([4, 1], [2, 2])   # 2.5  2.5'),
        fn('orthogonal(A) / orthonormal(A)', 'A 2-value vector turned 90&deg; counter-clockwise; orthonormal also scales '
           'it to length 1.', inputs=[('A', 'vector of 2 values', '')], syntax='orthogonal([3, 4])   # -4  3',
           short='the vector at right angles'),
        fn('vector_tp(a, b, c)', 'The scalar triple product (a &times; b) &middot; c of three 3-value vectors: the '
           'volume of the box they span.', inputs=[('a, b, c', 'vectors of 3 values', '')],
           math=r'[a, b, c] = (a \times b) \cdot c', short='triple product'),
        fn('eigen_value(M) / eigen_vector(M)', 'The eigenvalues of a square matrix, and the eigenvectors as columns '
           '(column k belongs to value k).', inputs=[('M', 'square matrix', '')], math=r'M v = \lambda v',
           short='eigenvalues and eigenvectors'),
        fn('divergence(A) / curl(A)', 'The sum of the elements; the cyclic difference of three values.',
           inputs=[('A', 'vector', '')], syntax='divergence([1:10])   # 55\ncurl([1, 2, 3])        # -1  2  -1',
           short='sum of elements; cyclic difference'),
    ]),
    'examples': {
        'basic': ex('Length and direction', 'A vector, its length, its unit vector and direction cosines.', '''
A = [3, 4];
publish("length", norm(A), "  unit", unit_vector(A), "  direction cosines", dircos(A));
publish("length of the unit vector:", norm(unit_vector([1:10])));
'''),
        'mid': ex('Projection and right angles', 'The projection of one vector on another, and perpendicular vectors.', '''
p = proj([4, 1], [2, 2])
o = orthogonal([3, 4])
n = orthonormal([3, 4])
publish("o is at right angles:", dot(o, [3, 4]) == 0);
publish("triple product:", vector_tp([1, 2, 3], [4, 5, 7], [7, 8, 10]));
'''),
        'strong': ex('Eigenvalues', 'A symmetric matrix and a rotation; the defining equation checked.', '''
M = [2, 1; 1, 2];
vals = eigen_value(M)
V = eigen_vector(M);
publish("M V == V diag(vals):", allclose(M * V, V * diag(vals), atol=1e-12));
publish("sum = trace:", allclose(sum(vals), trace(M), atol=1e-12));
W = eigen_value([0, -1; 1, 0])
'''),
    },
    'errors': [
        err('orthogonal of a 3-value vector', 'In three dimensions the perpendicular direction is not unique.',
            'y = orthogonal([1, 2, 3]);', 'y = cross([1, 2, 3], [0, 0, 1]);\npublish(y);'),
        err('A matrix written as a row', 'Write a 2 x 2 matrix with a semicolon.', 'y = eigen_value([1, 2, 3, 4]);',
            'y = eigen_value([1, 2; 3, 4]);\npublish(y);'),
    ],
}

# ================================================================== 8. Universal constants
CONSTS = [
    ('uc_pi', '&pi;', '3.141592653589793', ''), ('uc_gravity', 'standard gravity g', '9.80665', 'm/s<sup>2</sup>'),
    ('uc_gasconst', 'gas constant R', '8.31446261815324', 'J/(mol K)'), ('uc_avogadro', 'Avogadro number', '6.02214076e+23', '1/mol'),
    ('uc_planck', 'Planck constant h', '6.62607015e-34', 'J s'), ('uc_hbar', 'reduced Planck constant &#295;', '1.0545718176461565e-34', 'J s'),
    ('uc_gravitational', 'gravitational constant G', '6.6743e-11', 'm<sup>3</sup>/(kg s<sup>2</sup>)'),
    ('uc_stefanboltzmann', 'Stefan&ndash;Boltzmann constant', '5.6703744191844314e-08', 'W/(m<sup>2</sup> K<sup>4</sup>)'),
    ('uc_coulomb', 'Coulomb constant', '8987551786.170797', 'N m<sup>2</sup>/C<sup>2</sup>'),
    ('uc_electronmass', 'electron mass', '9.1093837139e-31', 'kg'), ('uc_protonmass', 'proton mass', '1.67262192595e-27', 'kg'),
    ('uc_neutronmass', 'neutron mass', '1.67492750056e-27', 'kg'), ('uc_molarmass', 'molar mass constant', '0.00100000000105', 'kg/mol'),
    ('uc_elementarycharge', 'elementary charge e', '1.602176634e-19', 'C'), ('uc_faraday', 'Faraday constant', '96485.33212331001', 'C/mol'),
    ('uc_speedoflight', 'speed of light c', '299792458', 'm/s'), ('uc_boltzmann', 'Boltzmann constant k', '1.380649e-23', 'J/K'),
    ('uc_vacuumpermittivity', 'vacuum permittivity &epsilon;<sub>0</sub>', '8.8541878188e-12', 'F/m'),
    ('uc_vacuumpermeability', 'vacuum permeability &mu;<sub>0</sub>', '1.25663706127e-06', 'N/A<sup>2</sup>'),
    ('uc_finestructure', 'fine-structure constant &alpha;', '0.0072973525643', ''), ('uc_rydberg', 'Rydberg constant', '10973731.568157', '1/m'),
    ('uc_bohrradius', 'Bohr radius', '5.29177210544e-11', 'm'), ('uc_hartreeenergy', 'Hartree energy', '4.359744722206e-18', 'J'),
    ('uc_magneticfluxquantum', 'magnetic flux quantum', '2.0678338484619295e-15', 'Wb'),
]
PAGES['universal-constants'] = {
    'title': 'Universal Constants',
    'summary': 'Twenty-four physical constants as plain names, in SI units, with the CODATA 2022 values.',
    'about': [
        fn('Using a constant', 'Every constant is a plain name, <code>uc_</code> followed by the name in lower case, '
           'with no brackets. The values are those of CODATA 2022 (as in <code>scipy.constants</code>).',
           more=['A variable you assign with the same name replaces the constant in that script, as for '
                 '<code>euler_gamma</code>.'],
           syntax='energy = uc_planck * uc_speedoflight / 500e-9;'),
        fn('The constants', 'Name, quantity, value and unit.',
           table=[['Name', 'Quantity', 'Value', 'Unit']] + [[f'<code>{n}</code>', q, v, u or '&mdash;'] for n, q, v, u in CONSTS]),
        fn('They agree with each other', 'The values are consistent through the laws of physics, for example:',
           math=r'R = N_A\,k, \quad F = N_A\,e, \quad h = 2\pi\hbar, \quad k_e = \frac{1}{4\pi\varepsilon_0}'),
    ],
    'examples': {
        'basic': ex('Reading constants', 'A few constants, printed in full.', '''
publish("c  =", uc_speedoflight, "m/s");
publish("g  =", uc_gravity, "m/s^2");
publish("h  =", uc_planck, "J s");
publish("NA =", uc_avogadro, "1/mol");
'''),
        'mid': ex('Physics with constants', 'The energy of a green photon, the weight of 70 kg, and the thermal '
                  'energy at room temperature.', '''
E = uc_planck * uc_speedoflight / 500e-9;
publish("photon at 500 nm:", E, "J =", E / uc_elementarycharge, "eV");
publish("weight of 70 kg:", 70 * uc_gravity, "N");
publish("kT at 300 K:", uc_boltzmann * 300, "J");
'''),
        'strong': ex('Checking the laws', 'Four relations between constants hold to the last digits.', '''
publish("R = NA k            :", allclose(uc_gasconst, uc_avogadro * uc_boltzmann, atol=0, rtol=1e-12));
publish("F = NA e            :", allclose(uc_faraday, uc_avogadro * uc_elementarycharge, atol=0, rtol=1e-12));
publish("h = 2 pi hbar       :", allclose(uc_planck, 2 * uc_pi * uc_hbar, atol=0, rtol=1e-12));
publish("ke = 1/(4 pi eps0)  :", allclose(uc_coulomb, 1 / (4 * uc_pi * uc_vacuumpermittivity), atol=0, rtol=1e-9));
'''),
    },
    'errors': [
        err('A constant name that does not exist', 'The speed of light is <code>uc_speedoflight</code>.',
            'y = uc_lightspeed;', 'y = uc_speedoflight;\npublish(y);'),
    ],
}
