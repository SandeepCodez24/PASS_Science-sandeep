"""Default Functions - NDAT Data Files (source: Function_Test/Code/A_08_ndat_data, 01_save_load_read.nc and
error_tests/E1_ndat_errors.nc; also A_03 time_05 (timestamps) and A_04 scripts 27-28 (part= and typed data)).

Every example and error card is run through nc.exe by build_default_functions.py, in a fresh folder; the files
they write appear there.
"""
from df_helpers import err, ex, fig, fn, reference

IMG = 'Images/Neural_Code/Default_Functions/Ndat_Data/'
DH = '../Data_Handling/'
PAGES = {}

SETUP = '''D = dict();
D["A"] = reshape(space(1, 40000, 40000), [200, 200]);
D["name"] = "run 7";
T = dict();
T["x"] = space(0, 1, 5000);
T["y"] = space(1, 2, 5000);
D["T"] = T;
save("ndt_err", D);
'''

# ================================================================== 1. Saving and reading
PAGES['saving-reading'] = {
    'title': 'Saving & Reading .ndat',
    'summary': 'NC\'s own data bundle: <code>save</code> any value, dictionary or table, and <code>read</code> it back '
               'exactly, whole, by entry, by slice or by column. <code>load</code> opens a file as an object.',
    'about': reference('A file name with no extension, or ending in <code>.ndat</code>, is an NC data bundle. Every entry '
                       'inside is stored the way that suits it best, and is checked to read back exactly before it is '
                       'written: <code>read(save(x))</code> is always x. For other formats use their own functions '
                       '(<a href="' + DH + 'reading-loading-saving.html">Data Handling</a>).', [
        fn('save(file, data, policy="auto", zip=false)', 'Writes data and gives the number of bytes. One value is stored as '
           'one entry; a dictionary as one entry per key.',
           inputs=[('file', 'name without extension, or ending in .ndat', ''), ('data', 'any value, dictionary or table', 'the whole workspace'),
                   ('policy', '"auto", "compact", "fast", "native", "hdf5", "parquet" or "arrow" (may be named)', '"auto"'),
                   ('zip', 'true: write <code>file.ndat.zip</code> instead, for sending; unpack it before reading (may be named)', 'false')],
           figure=fig(IMG + 'saving-reading-01.svg',
                      'One .ndat file holding four entries: a large smooth matrix stored as HDF5 (chunked, compressed, '
                      'sliceable), a table with text stored as Parquet, a numeric table stored as Arrow IPC, and small '
                      'values, text, dictionaries and noisy data stored native.',
                      'How <code>policy="auto"</code> stores each entry of one bundle.'),
           syntax='n = save("run", D);\nn = save("run", D, policy="native");', short='write data'),
        fn('read(file, name="", part="")', 'The data back: the whole file (the value itself for a one-entry file, a '
           'dictionary otherwise), one entry, or part of one.',
           inputs=[('name', 'an entry name (may be named)', 'all'),
                   ('part', 'a slice in quotes, 1-based and inclusive ("2:3, 1:4"), or table columns (["x", "y"])', 'all')],
           more=['A slice of an HDF5 entry reads only the chunks it needs; a native entry is cut in memory.'],
           syntax='x = read("run");\nA = read("run", "A");\nS = read("run", "A", "1:5, :");', short='read data back'),
        fn('load(file)', 'The file as an object: one field per entry (<code>D.A</code>, <code>D.name</code>), plus '
           '<code>D.ndat</code>, the information from <code>ndat_info</code>.', syntax='D = load("run");\nD.name'),
        fn('Reading table columns', 'For a table entry, <code>read(file, name, ["x", "y"])</code> reads only those '
           'columns and gives them as a dictionary: <code>read(file, "T", "y")["y"]</code> is the column itself. '
           'Very small tables are stored native and are read whole.', syntax='c = read("run", "T", "y");\ny = c["y"];',
           short='only some columns of a table'),
    ], lead=[
        fn('Which storage for which data', 'With the "auto" policy NC picks per entry:',
           table=[['Data', 'Stored as', 'Why'],
                  ['big numeric matrix or N-D matrix that compresses well', 'HDF5 (chunked, gzip)', 'small file, fast slices'],
                  ['table with text or true/false columns', 'Parquet (dictionary + zstd)', 'compact text columns'],
                  ['numeric table', 'Arrow IPC', 'fastest to read'],
                  ['small data, text, dictionaries, objects, sized integers, complex, timestamps, noise-like data', 'native NDAT', 'exact copy']]),
    ]),
    'examples': {
        'basic': ex('Any value comes back exactly', 'A number, text, a complex number, a sized integer and an N-D matrix '
                    'through save and read.', '''
values = dict();
values["number"] = 3.25;
values["text"] = "Kreyszig, 10th edition";
values["complex"] = 2 - 5i;
values["small int"] = int8(-7);
values["matrix"] = [1, 2, 3; 4, 5, 6];
for k = keys(values):
   save("ndt_one", values[k]);
   publish(k, ":", read("ndt_one") == values[k], " type", type(read("ndt_one")));
fend
N3 = reshape(space(1, 24, 24), [2, 3, 4]);
save("ndt_one", N3);
publish("N-D matrix:", read("ndt_one") == N3);
'''),
        'mid': ex('A dictionary, entry by entry', 'A run with a name, a smooth field, a noisy field and settings: what '
                  'each entry became, and reads of single entries and slices.', '''
run = dict();
run["name"] = "wind tunnel, run 7";
run["smooth"] = reshape(space(0, 1, 120000), [300, 400]);
nexus_seed(1);
run["noise"] = nexus_uniform([300, 400]);
run["settings"] = [0.5, 1.5, 2.5];
bytes = save("ndt_run", run);
E = ndat_info("ndt_run")["entries"];
publish(E.name, E.encoding);
publish("whole file:", read("ndt_run") == run, "  one entry:", read("ndt_run", "settings"));
S = run["smooth"];
publish("HDF5 slice:", read("ndt_run", "smooth", "2:3, 1:4") == S[1:2, 0:3]);
D = load("ndt_run");
publish("D.name:", D.name, "  version:", D.ndat["version"]);
'''),
        'strong': ex('Tables', 'A table with a text column goes to Parquet, a numeric one to Arrow; one column is read on '
                     'its own; the policy can be chosen by name.', '''
T = dict();
T["station"] = repeat(["north", "south", "east", "west", "centre"], 1000);
T["temp"] = space(10, 30, 5000);
save("ndt_table", T);
publish("text table:", ndat_info("ndt_table")["entries"].encoding[0], "  back:", read("ndt_table") == T);
publish("first temps:", read("ndt_table", "temp")[0:2]);
N = dict();
N["x"] = space(0, 1, 5000);
N["y"] = space(1, 2, 5000);
save("ndt_numeric", N);
publish("numeric table:", ndat_info("ndt_numeric")["entries"].encoding[0]);
n = save("ndt_named", N, policy="native");
publish("policy native:", ndat_info("ndt_named")["entries"].encoding[0], "  read(name=\\"x\\") first:", read("ndt_named", name="x")[0]);
'''),
    },
    'errors': [
        err('An unknown policy', 'NC lists the seven policies.', 'D = [1, 2, 3];\nn = save("run", D, "turbo");',
            'D = [1, 2, 3];\nn = save("run", D, "compact");\npublish(read("run"));'),
        err('A named input that does not exist', 'save takes file, data and policy.', 'D = [1, 2, 3];\nn = save("run", D, level=3);',
            'D = [1, 2, 3];\nn = save("run", D, policy="compact");\npublish(read("run"));'),
        err('save for a CSV file', 'save writes .ndat bundles; other formats have their own save_ functions.',
            'T = [1, 2; 3, 4];\nn = save("run.csv", T);', 'T = [1, 2; 3, 4];\nn = save_csv("run.csv", T);\npublish(read_csv("run.csv", hdr=0));'),
        err('An entry that does not exist', 'NC lists the entries.', SETUP + 'x = read("ndt_err", "B");',
            SETUP + 'x = read("ndt_err", "name");\npublish(x);'),
        err('A slice outside the data', 'Entry A has 200 rows.', SETUP + 'x = read("ndt_err", "A", "1:500, :");',
            SETUP + 'x = read("ndt_err", "A", "1:2, 1:3");\npublish(x);'),
        err('A slice without quotes', 'A part is a slice written as text.', SETUP + 'x = read("ndt_err", "A", 5);',
            SETUP + 'x = read("ndt_err", "A", "5, 1:3");\npublish(x);'),
        err('A column that does not exist', 'Table T has the columns x and y.', SETUP + 'x = read("ndt_err", "T", "z");',
            SETUP + 'x = read("ndt_err", "T", "y");\npublish(x["y"][0:2]);'),
        err('A file that does not exist', 'NC names the file it looked for.', 'x = read("no_such_file");',
            'save("no_such_file", 1);\nx = read("no_such_file");\npublish(x);'),
    ],
}

# ================================================================== 2. Workspaces, info and export
PAGES['workspaces-export'] = {
    'title': 'Workspaces, Info & Export',
    'summary': 'Save and restore every variable at once, look inside a bundle entry by entry, export one entry as a '
               'standalone HDF5, Parquet, JSON or other file, and read version-1 files.',
    'about': reference('A bundle keeps types exactly: sized integers, complex numbers, timestamps and durations come back '
                       'as they were, on any computer and in any time zone.', [
        fn('save(file)', 'With no data: every variable of the workspace.', syntax='save("session");'),
        fn('load_workspace(file)', 'Puts every variable of a workspace file back (<code>load(file)</code> would give them '
           'as fields of an object; <code>read(file)</code> as a dictionary).', syntax='load_workspace("session");'),
        fn('save_workspace(file) / version 1', 'The older writer; its version-1 files are read by <code>read</code>, '
           '<code>load</code> and <code>ndat_info</code> like any other.', short='version-1 files'),
        fn('ndat_info(file)', 'What a file holds: a dictionary with <code>version</code> and <code>entries</code>, a table '
           'with name, encoding, kind, shape, bytes and note for every entry.', syntax='info = ndat_info("run");\ninfo["entries"].encoding',
           short='what a file holds'),
        fn('ndat_export(file, name, out)', 'One entry as a standalone file, chosen by the extension of out. HDF5, Parquet '
           'and Arrow sections are copied byte for byte; anything else is written by that format\'s save function.',
           inputs=[('file', 'the bundle', ''), ('name', 'the entry', ''), ('out', 'output file: .h5, .parquet, .arrow, .csv, .json, .mat, ...', '')],
           figure=fig(IMG + 'workspaces-export-01.svg',
                      'An .ndat bundle with three entries; arrows show ndat_export copying the HDF5 entry to its own .h5 '
                      'file byte for byte, the Parquet entry to a .parquet file, and writing a native entry through '
                      'save_json to a .json file.',
                      '<code>ndat_export</code> takes one entry out of a bundle as an ordinary file other software can '
                      'open.'),
           short='one entry as its own file'),
    ]),
    'examples': {
        'basic': ex('Save and restore a workspace', 'Two variables saved, changed, and restored; then the same file read '
                    'as a dictionary.', '''
alpha = 41;
beta = "kept";
save("ndt_workspace");
alpha = 0;
beta = "";
load_workspace("ndt_workspace");
publish("after load_workspace:", alpha, beta);
W = read("ndt_workspace");
publish("as a dictionary, alpha =", W["alpha"]);
'''),
        'mid': ex('Types kept exactly', 'Timestamps, durations (with a negative one), sized integers and complex numbers '
                  'survive a round trip.', '''
d = dict();
d["t"] = timestamp(2026, 10, 28, 14, 30, 0, "UTC");
d["laps"] = minutes([1, -2; 3, 4]);
d["far"] = timestamp(1700, 1, 1, "UTC");
d["counts"] = uint16([1, 500, 65535]);
d["z"] = [1 + 2i, 3 - 4i];
save("ndt_types", d);
r = read("ndt_types");
for k = keys(d):
   publish(k, "comes back equal:", r[k] == d[k]);
fend
publish("types:", type(r["t"]), type(r["laps"]), type(r["counts"]), type(r["z"]));
publish("far date:", get_date(r["far"], "UTC"));
'''),
        'strong': ex('Look inside, then export', 'ndat_info on a mixed bundle, then each entry exported to the format '
                     'that suits it and read back with that format\'s own function.', '''
run = dict();
run["smooth"] = reshape(space(0, 1, 120000), [300, 400]);
run["settings"] = [0.5, 1.5, 2.5];
T = dict();
T["station"] = repeat(["north", "south"], 2500);
T["temp"] = space(10, 30, 5000);
run["table"] = T;
save("ndt_run", run);
info = ndat_info("ndt_run");
publish("version", info["version"], "  entries:", info["entries"].name, info["entries"].encoding);
ndat_export("ndt_run", "smooth", "smooth.h5");
publish("h5 back:", read_h5("smooth.h5", "/data") == run["smooth"]);
ndat_export("ndt_run", "table", "table.parquet");
publish("parquet rows:", load_parquet("table.parquet").rows);
ndat_export("ndt_run", "settings", "settings.json");
publish("json:", read_json("settings.json"));
'''),
    },
    'errors': [
        err('A workspace file with another extension', 'save writes .ndat; use save_mat for a MATLAB file.',
            'a = 1;\nsave("workspace.mat");', 'a = 1;\nsave("workspace");\npublish(read("workspace")["a"]);'),
        err('ndat_info of a CSV file', 'ndat_info reads .ndat bundles only.', 'save_csv("data.csv", [1, 2]);\ni = ndat_info("data.csv");',
            'save("data", [1, 2]);\ni = ndat_info("data");\npublish(i["version"]);'),
        err('Exporting to an unknown format', 'The extension must belong to a format with a save_ function.',
            SETUP + 'e = ndat_export("ndt_err", "name", "name.xyz");', SETUP + 'e = ndat_export("ndt_err", "name", "name.json");\npublish(read_json("name.json"));'),
        err('load with two inputs', 'load opens the whole file; use read for one entry.', SETUP + 'L = load("ndt_err", "A");',
            SETUP + 'A = read("ndt_err", "A", "1:2, 1:2");\npublish(A);'),
    ],
}
