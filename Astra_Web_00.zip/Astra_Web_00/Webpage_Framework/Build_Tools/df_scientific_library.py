"""Default Functions - Scientific Library (source: Function_Test/Code/A_06_Scipy_Functions).

About 2,100 functions that match SciPy. Each page has hand-written About / Examples / Syntax Error tabs and a
generated Reference tab: every function of its sections from df_scipy_reference.json, which
extract_scipy_reference.py makes from the generated example scripts in A_06/examples (signature, inputs,
returns, SciPy name and the output nc.exe printed). Error cards come from A_06/error_tests.
"""
from df_helpers import comp, err, ex, fig

IMG = 'Images/Neural_Code/Default_Functions/Scientific_Library/'
CORE = '../Core_Math/'
PAGES = {}


def page(title, summary, about, examples, reference, errors=(), titles=None):
    return {'title': title, 'summary': summary, 'about': about, 'examples': examples,
            'reference': reference, 'reference_titles': titles or {}, 'errors': list(errors)}


IN_ORDER = err('Naming the inputs of a library function', 'Scientific Library functions take their inputs in order '
               'only: write <code>butter(4, 0.2, "low")</code>, not <code>btype="low"</code>.',
               'f = butter(4, 0.2, btype="low");', 'f = butter(4, 0.2, "low");\npublish(f.b, f.a);')

# ================================================================== 1. Overview
PAGES['library-overview'] = page(
    'Overview, Constants & Datasets',
    'About 2,100 functions that match SciPy, from Fourier transforms to probability distributions, with the same '
    'results. How to call them, how to read the reference lists, physical constants and sample datasets.',
    [
        comp('How the library works', [
            'Every function has the name and the inputs of its SciPy counterpart, adapted to NC: '
            '<code>scipy.fft.dct</code> is <code>dct</code>, <code>scipy.stats.norm.cdf</code> is '
            '<code>norm_cdf</code>, <code>scipy.linalg.lapack.dgesv</code> is <code>lapack_gesv</code>. Every '
            'function was checked against SciPy 1.18.',
            '<strong>Inputs are given in order.</strong> Unlike the <a href="' + CORE + 'calling-built-ins.html">core '
            'functions</a>, these functions do not take <code>name=value</code> yet. An optional input you skip can be '
            'given as 0 so that a later one can still be passed.',
            'Functions that work on functions take a reference written with <code>@</code>: '
            '<code>integrate(@f, 0, 1)</code>.'],
            syntax='r = dct(sig, 2, "ortho");        # inputs in order\nv = integrate(@f, 0, 1);         # a function passed with @'),
        comp('Reading a reference list', [
            'The <strong>Reference</strong> tab of each page lists every function of the page. Type in the filter box '
            'to find one by name, description or SciPy name; click a function to see its inputs, how many it needs, '
            'what it returns, and one or two calls with the output NC printed. When the calls use shared data, a '
            '"Data" block at the top of the list holds it: run that first.']),
        comp('Physical constants', [
            'SciPy\'s constants are available by name (<code>speed_of_light</code>, <code>boltzmann</code>, '
            '<code>atm</code>, <code>day</code>, ...) and through functions: <code>constant_value("electron mass")'
            '</code>, <code>constant_unit</code>, <code>constant_precision</code> and <code>constant_find(word)'
            '</code>. Names are case-sensitive. The NC constants with the <code>uc_</code> prefix are on <a href="'
            '../Traditional_Math/universal-constants.html">Universal Constants</a>.'],
            syntax='constant_value("electron mass")\nconvert_temp([0, 100], "Celsius", "Kelvin")'),
        comp('Datasets', [
            '<code>dataset_ascent()</code>, <code>dataset_face()</code> and <code>dataset_ecg()</code> give SciPy\'s '
            'sample image and signal data for experiments.']),
    ],
    {
        'basic': ex('Constants by name and by lookup', 'Constants read directly and through the lookup functions.', '''
publish("c =", speed_of_light, "  k =", boltzmann, "  1 atm =", atm, "Pa");
publish(constant_value("electron mass"), constant_unit("electron mass"));
publish(constant_find("boltzmann"));
'''),
        'mid': ex('Conversions', 'Temperatures between scales, and wavelength and frequency of light.', '''
t = convert_temp([0, 100], "Celsius", "Kelvin")
f = convert_temp(98.6, "Fahrenheit", "Celsius")
nu = wavelength2freq(500e-9)
lam = freq2wavelength(nu)
'''),
        'strong': ex('A sample signal', 'The ECG dataset: its size, its range and a short summary.', '''
e = dataset_ecg();
publish("samples:", numel(e), "  min:", min(e), "  max:", max(e));
publish("mean:", round(mean(e), decimals=4), "  first five:", e[0:4]);
'''),
    },
    ['constants', 'datasets'],
    [
        err('A misspelt constant', 'Constant names are spelt exactly.', 'c = speed_of_lite;', 'c = speed_of_light;\npublish(c);'),
        err('A constant in the wrong case', 'Names are lower case: <code>boltzmann</code>, not SciPy\'s '
            '<code>Boltzmann</code>.', 'k = Boltzmann;', 'k = boltzmann;\npublish(k);'),
        IN_ORDER,
        err('A function from another language', 'NC has its own names: <code>nexus_uniform([3, 3])</code> for random '
            'numbers, <code>space(a, b, n)</code> for evenly spaced values.', 'r = arange(0, 16, 1);',
            'r = space(0, 15, 16);\npublish(r);'),
    ],
    {'constants': 'Constants', 'datasets': 'Datasets'})

# ================================================================== 2. Clustering
PTS = 'P = [1, 1; 1.2, 0.8; 0.9, 1.1; 5, 5; 5.2, 4.8; 4.9, 5.1];\n'
PAGES['clustering'] = page(
    'Clustering',
    'Group points that lie close together: k-means with centroids, and hierarchical clustering with linkage '
    'trees, dendrograms and flat clusters cut from the tree.',
    [
        comp('k-means', [
            '<code>kmeans(data, k, seed)</code> finds k centre points (centroids) so that each point is close to its '
            'nearest centre. <code>whiten(data)</code> scales every column to unit variance first, so that no feature '
            'dominates; <code>assign_clusters</code> assigns new points to the centres.'],
            math=r'\min_{c_1,\dots,c_k} \sum_i \min_j \|x_i - c_j\|^2',
            figure=fig(IMG + 'clustering-01.svg',
                       'Left: two groups of points with their k-means centroids marked. Right: the dendrogram of the '
                       'same points: pairs join at small heights, and the two groups join only at the top.',
                       'k-means (left) and hierarchical clustering (right) of the same six points.')),
        comp('Hierarchical clustering', [
            '<code>linkage(data, method)</code> joins the closest points and groups step by step; each row of the '
            'result records one join: the two groups, their distance and the new size. Methods: "single", '
            '"complete", "average", "weighted", "centroid", "median", "ward". <code>fcluster(Z, t, criterion)</code> '
            'cuts the tree into flat clusters; <code>dendrogram</code> gives the drawing order.']),
    ],
    {
        'basic': ex('k-means on two groups', 'Six points in two obvious groups.', PTS + '''
r = kmeans(P, 2, 1)
'''),
        'mid': ex('A linkage tree', 'Single linkage of the same points, then two flat clusters cut from it.', PTS + '''
Z = linkage(P, "single")
labels = fcluster(Z, 2, "maxclust")
'''),
        'strong': ex('Scaled features and checks', 'Whitened data, Ward linkage, and checks on the tree.', PTS + '''
W = whiten(P)
Z = linkage_ward(W);
publish("valid:", is_valid_linkage(Z), "  monotonic:", is_monotonic(Z), "  leaves:", leaves_list(Z));
'''),
    },
    ['clustering'],
    [err('Naming the inputs of kmeans', 'Library functions take their inputs in order.', 'P = [1, 2; 3, 4; 5, 6; 7, 8];\nr = kmeans(data=P, k=2);',
         'P = [1, 2; 3, 4; 5, 6; 7, 8];\nr = kmeans(P, 2, 1);\npublish(size(r));')])

# ================================================================== 3. Derivatives, integration, ODEs
PAGES['integration-odes'] = page(
    'Derivatives, Integration & ODEs',
    'Jacobians and Hessians, definite integrals in one to n dimensions, integrals of sampled data, and initial- '
    'and boundary-value problems for ordinary differential equations.',
    [
        comp('Integrals of functions', [
            '<code>integrate(@f, a, b)</code> integrates adaptively to a tolerance; <code>integrate2</code>, '
            '<code>integrate3</code> and <code>integrate_n</code> do double, triple and n-fold integrals. For smooth '
            'functions <code>integrate_tanhsinh</code> is very accurate; <code>integrate_qmc</code> uses quasi-random '
            'points for high dimensions.'],
            math=r'\int_a^b f(x)\,dx'),
        comp('Integrals of samples', [
            '<code>simpson(y, x)</code>, <code>romb(y, dx)</code> and the running versions <code>cumtrapz</code>, '
            '<code>cumsimpson</code> integrate data that is only known at sample points.']),
        comp('Ordinary differential equations', [
            '<code>ode_solve(@f, [t0, t1], u0, method)</code> solves u&prime; = f(t, u) from t0 to t1 (methods '
            '"RK45", "RK23", "DOP853", "Radau", "BDF", "LSODA"); <code>odeint(@f, u0, t)</code> is the classic '
            'interface, and like SciPy\'s it calls the function as <strong>f(u, t)</strong>, state first; '
            '<code>bvp_solve</code> solves boundary-value problems.'],
            math=r"\frac{du}{dt} = f(t, u), \qquad u(t_0) = u_0"),
        comp('Derivatives', [
            '<code>jacobian(@f, x)</code> and <code>hessian(@f, x)</code> give the matrix of first and second partial '
            'derivatives at x, worked out numerically.']),
    ],
    {
        'basic': ex('Definite integrals', 'One integral with a known answer, and a double integral.', '''
function y = f(x):
   y = x ^ 2;
fnend
v = integrate(@f, 0, 3)
function z = g(x, y):
   z = x * y;
fnend
v2 = integrate2(@g, 0, 1, 0, 2)
'''),
        'mid': ex('Integrals of samples', 'Simpson\'s rule and running integrals of sin on 0 to &pi;.', '''
x = space(0, pi, 9);
y = sin(x);
s = simpson(y, x)
c = cumtrapz(y, x)
'''),
        'strong': ex('An ODE: exponential decay', 'u&prime; = &minus;0.5 u from u(0) = 2, compared with the exact '
                     '2 e<sup>&minus;t/2</sup>. <code>odeint</code> calls the function as f(u, t), state first; '
                     '<code>ode_solve</code> as f(t, u).', '''
function du = decay(u, t):
   du = -0.5 * u;
fnend
t = [0, 1, 2, 4];
u = odeint(@decay, 2, t);
exact = 2 * exp(-0.5 * t);
publish("odeint:", round(u', decimals=6));
publish("exact :", round(exact, decimals=6));
publish("agree:", allclose(u', exact, atol=1e-6));
'''),
    },
    ['differentiation', 'integration_odes'],
    [IN_ORDER], {'differentiation': 'Derivatives', 'integration_odes': 'Integration and ODEs'})

# ================================================================== 4. Fourier transforms
SIG = 'fs = 64;\nt = [0:63] / fs;\nx = sin(2 * pi * 5 * t) + 0.5 * sin(2 * pi * 12 * t);\n'
PAGES['fourier-transforms'] = page(
    'Fourier Transforms',
    'The fast Fourier transform and its relatives: real and n-dimensional FFTs, frequency axes, cosine and sine '
    'transforms, the Hankel transform, and the legacy FFT tools for derivatives and convolution.',
    [
        comp('The discrete Fourier transform', [
            'The FFT writes a sampled signal as a sum of sines and cosines. Element k of <code>fft(x)</code> tells how '
            'much of the frequency k &middot; fs / N the signal holds (its size) and its phase (its angle). '
            '<code>ifft</code> goes back.'],
            math=r'X_k = \sum_{n=0}^{N-1} x_n\, e^{-2\pi i\, k n / N}, \qquad f_k = \frac{k\, f_s}{N}',
            figure=fig(IMG + 'fourier-transforms-01.svg',
                       'Top: a signal of 64 samples, the sum of a 5 hertz and a weaker 12 hertz sine wave. Bottom: the '
                       'size of its real FFT against frequency: two spikes, at 5 and 12 hertz, the second half the '
                       'height of the first.',
                       'A signal in time (top) and its spectrum <code>abs(rfft(x))</code> (bottom): each sine wave '
                       'becomes one spike at its frequency.')),
        comp('Real signals and frequency axes', [
            'For real data, <code>rfft</code> returns only the non-negative frequencies (N/2 + 1 values) and '
            '<code>rfftfreq(N, 1/fs)</code> gives their frequencies in hertz; <code>fftfreq</code> and '
            '<code>fftshift</code> do the same for the full FFT, with zero frequency moved to the middle.'],
            syntax='X = rfft(x);\nf = rfftfreq(64, 1 / fs);\namp = abs(X) * 2 / 64;'),
        comp('Cosine, sine and n-dimensional transforms', [
            '<code>dct</code> / <code>idct</code> and <code>dst</code> / <code>idst</code> (types 1&ndash;4) are '
            'used in compression and for solving equations; <code>fft2</code>, <code>fftn</code> and the '
            '<code>…n</code> versions work on images and volumes; <code>next_fast_len</code> picks a fast length for '
            'padding.']),
        comp('Legacy FFT tools', [
            '<code>fft_diff</code> differentiates a periodic signal through its spectrum, <code>fft_hilbert</code> '
            'gives the Hilbert transform, <code>fft_convolve</code> convolves quickly.']),
    ],
    {
        'basic': ex('The spectrum of two sine waves', 'A 5 Hz and a 12 Hz sine wave sampled at 64 Hz: the two largest '
                    'amplitudes in the spectrum sit at 5 and 12 Hz.', SIG + '''
X = rfft(x);
f = rfftfreq(64, 1 / fs);
amp = abs(X) * 2 / 64;
publish("amplitude at 5 Hz:", round(amp[0, 5], decimals=3), "  at 12 Hz:", round(amp[0, 12], decimals=3));
publish("frequencies 0..6:", f[0, 0:6]);
'''),
        'mid': ex('Round trips', 'fft then ifft gives the signal back; a DCT and its inverse do the same.', '''
s = [1, 5, 2, 8, 3, 1, 4, 9];
back = real(ifft(fft(s)))
d = dct(s, 2, "ortho");
back2 = idct(d, 2, "ortho")
n = next_fast_len(1000)
'''),
        'strong': ex('Differentiating through the spectrum', 'The derivative of sin on a full period, from its FFT, '
                     'agrees with cos.', '''
n = 16;
t = space(0, 15, 16) * 2 * pi / n;
d = fft_diff(sin(t));
publish("matches cos:", allclose(d, cos(t), atol=1e-9));
img = [1, 2, 3, 4; 5, 6, 7, 8; 9, 10, 11, 13];
F = fft2(img);
publish("2-D FFT size:", size(F), "  DC term:", real(F[0, 0]));
'''),
    },
    ['fourier_transforms', 'legacy_fft'],
    [err('A FFT of text', 'Transforms work on numbers.', 'X = fft("abc");', 'X = fft([1, 2, 3]);\npublish(X);')],
    {'fourier_transforms': 'Fourier transforms', 'legacy_fft': 'Legacy FFT tools'})

# ================================================================== 5. Interpolation
PAGES['interpolation'] = page(
    'Interpolation',
    'Values between known points: linear, cubic, monotone and Akima curves, splines with smoothing, rational and '
    'polynomial interpolation, scattered data in 2-D and n-D, and splines on a sphere.',
    [
        comp('Curves through points', [
            '<code>interp1d(x, y, xq, kind)</code> interpolates with kind "linear", "nearest", "cubic" and others; '
            '<code>cubic_spline</code> gives a smooth curve with continuous second derivative; <code>pchip</code> and '
            '<code>akima</code> never overshoot the data, which suits measurements that must stay positive or '
            'monotone.'],
            figure=fig(IMG + 'interpolation-01.svg',
                       'Seven data points with a step in them, and three curves through them: linear (straight '
                       'segments), cubic spline (smooth but overshooting around the step) and pchip (smooth and '
                       'staying within the data).',
                       'Three ways through the same points: a cubic spline can overshoot near a sudden change; pchip '
                       'does not.')),
        comp('Splines with control', [
            '<code>splrep</code> / <code>splev</code> build and evaluate a B-spline (with smoothing s), '
            '<code>splder</code>, <code>splantider</code> and <code>splint</code> differentiate and integrate it, '
            '<code>sproot</code> finds its roots.']),
        comp('Scattered data', [
            '<code>griddata(points, values, xi, method)</code> interpolates values known at scattered points in 2-D or '
            'n-D; <code>rbf_interp</code> uses radial basis functions; <code>grid_interp</code> works on regular '
            'grids.']),
    ],
    {
        'basic': ex('Between the points', 'Linear and cubic interpolation of a few samples of x<sup>2</sup>.', '''
x = [0, 1, 2, 3, 4];
y = x ^. 2;
l = interp1d(x, y, [0.5, 2.5], "linear")
c = cubic_spline(x, y, [0.5, 2.5])
'''),
        'mid': ex('No overshoot', 'Data with a step: the cubic spline swings below zero, pchip stays within the data.', '''
x = [0, 1, 2, 3, 4, 5, 6];
y = [0, 0, 0, 1, 1, 1, 1];
q = [1.5, 2.5, 3.5];
publish("cubic spline:", cubic_spline(x, y, q));
publish("pchip       :", pchip(x, y, q));
publish("akima       :", akima(x, y, q));
'''),
        'strong': ex('A B-spline and its calculus', 'Fit a spline to samples of sin, then evaluate its derivative and '
                     'integral.', '''
x = space(0, pi, 12);
tck = splrep(x, sin(x));
v = splev([0.5, 1.5], tck)
d = splev([0.5, 1.5], splder(tck))
area = splint(0, pi, tck)
'''),
    },
    ['interpolation'], [IN_ORDER])

# ================================================================== 6. File I/O
PAGES['file-io'] = page(
    'File I/O (SciPy formats)',
    'The file formats of scipy.io: Matrix Market and Harwell-Boeing sparse matrices, Fortran unformatted '
    'records, IDL save files, ARFF, NetCDF 3 and WAV.',
    [
        comp('SciPy\'s own formats', [
            'These are the readers and writers of <code>scipy.io</code>: <code>mm_read</code> / <code>mm_write</code> '
            '(Matrix Market), <code>hb_read</code> / <code>hb_write</code> (Harwell-Boeing), <code>fortran_read</code> '
            '/ <code>fortran_write</code> (unformatted Fortran records), <code>read_idl</code>, <code>load_arff</code>, '
            '<code>netcdf_read</code> / <code>netcdf_write</code>, <code>wav_read</code> / <code>wav_write</code>, and '
            'MAT-file helpers.',
            'For everyday formats (CSV, JSON, Excel, HDF5, Parquet, images ...) use the <a href="../Data_Handling/'
            'reading-loading-saving.html">Data Handling</a> functions.']),
    ],
    {
        'basic': ex('A Matrix Market file', 'Write a small matrix, look at the file header, read it back.', '''
A = [1, 0, 2; 0, 3, 0];
n = mm_write("mm_a.mtx", A);
publish(mm_info("mm_a.mtx"));
B = mm_read("mm_a.mtx")
'''),
        'mid': ex('Fortran records', 'Unformatted records as a Fortran program writes them.', '''
n = fortran_write("f_a.unf", [1.5, 2.5, 3.5]);
v = fortran_read("f_a.unf")
'''),
        'strong': ex('A WAV file', 'Write one second of a 440 Hz tone at 8 kHz and read its rate and length.', '''
t = [0:7999] / 8000;
y = sin(2 * pi * 440 * t);
n = wav_write("tone.wav", 8000, y);
w = wav_read("tone.wav");
publish("rate:", w.rate, "  samples:", numel(w.data));
'''),
    },
    ['input_output'])

# ================================================================== 7. Linear algebra
PAGES['linear-algebra'] = page(
    'Linear Algebra',
    'Decompositions (LU, Cholesky, LDL, QR updates, Schur, QZ, polar), special matrices (Toeplitz, Hankel, '
    'Hilbert, Pascal ...), structured solvers, matrix equations, null spaces and randomised low-rank methods.',
    [
        comp('Factorise once, solve many times', [
            '<code>lu_factor(A)</code> and <code>cho_factor(A)</code> factorise a matrix once; <code>lu_solve</code> '
            'and <code>cho_solve</code> then solve for any number of right-hand sides cheaply.'],
            math=r'A = P\,L\,U, \qquad A = L\,L^{T}'),
        comp('Structured matrices and solvers', [
            '<code>toeplitz</code>, <code>hankel</code>, <code>circulant</code>, <code>hilbert</code>, '
            '<code>pascal</code>, <code>hadamard</code>, <code>companion</code> and others build special matrices; '
            '<code>solve_toeplitz</code>, <code>solve_circulant</code>, <code>solve_banded</code> and '
            '<code>solve_triangular</code> exploit their structure.']),
        comp('Matrix equations', [
            '<code>solve_lyapunov</code>, <code>solve_sylvester</code>, <code>solve_care</code> and '
            '<code>solve_dare</code> solve the equations of control theory.'],
            math=r'A X + X A^{H} = Q \qquad A X + X B = Q'),
        comp('Subspaces', [
            '<code>null_space(A)</code> and <code>orth(A)</code> give orthonormal bases of the null space and the '
            'range; <code>subspace_angles</code> compares two subspaces. More decompositions are on <a href="' + CORE +
            'norms-decompositions.html">Norms &amp; Decompositions</a>.']),
    ],
    {
        'basic': ex('LU: factorise once', 'Factorise a 3 x 3 matrix and solve for two right-hand sides.', '''
A = [4, 3, 2; 2, 1, 3; 3, 2, 1];
f = lu_factor(A);
x1 = lu_solve(f, [1; 2; 3])
x2 = lu_solve(f, [0; 1; 0])
publish("check:", allclose(A * x1', [1; 2; 3], atol=1e-12));
'''),
        'mid': ex('Special matrices', 'A Toeplitz, a Hilbert and a Pascal matrix, and a Toeplitz system.', '''
T = toeplitz([1, 2, 3], [1, 4, 5])
H = hilbert(3)
P = pascal(4)
x = solve_toeplitz([2, 1, 0], [1, 2, 3])
'''),
        'strong': ex('Null space and a Lyapunov equation', 'The null space of a rank-1 matrix, and the solution of '
                     'A X + X A&prime; = Q checked by substitution.', '''
N = null_space([1, 2; 2, 4])
A = [-1, 0.5; 0, -2];
Q = [-1, 0; 0, -1];
X = solve_lyapunov(A, Q);
publish("A X + X A' = Q:", allclose(A * X + X * A', Q, atol=1e-10));
'''),
    },
    ['linear_algebra'], [err('cholesky with two inputs', 'cholesky takes one input.', 'A = [4, 1; 1, 3];\nr = cholesky(A, 1);',
                             'A = [4, 1; 1, 3];\nr = cholesky(A);\npublish(r);')])

# ================================================================== 8. Image processing
IMGD = 'img = [0, 0, 0, 0, 0; 0, 9, 9, 0, 0; 0, 9, 9, 0, 0; 0, 0, 0, 0, 7; 0, 0, 0, 0, 7];\n'
PAGES['image-processing'] = page(
    'Image Processing',
    'Filters (Gaussian, median, rank, Sobel, Laplace), morphology on binary and grey images, labelling and '
    'measuring objects, distance transforms, and geometric transforms: shift, rotate, zoom and affine.',
    [
        comp('Filters', [
            '<code>gaussian_filter(img, sigma)</code> blurs, <code>median_filter</code> removes speckle noise while '
            'keeping edges, <code>sobel</code> and <code>prewitt</code> find edges along an axis, '
            '<code>img_laplace</code> and <code>gaussian_laplace</code> find blobs. <code>mode</code> says how the '
            'border is extended.'],
            figure=fig(IMG + 'image-processing-01.svg',
                       'Four small panels: the original image of two bright objects, the Gaussian-blurred image, the '
                       'Sobel edge map, and the labelled objects coloured 1 and 2.',
                       'One image, three operations: blur, edges, and labelled objects.')),
        comp('Objects', [
            '<code>img_label(mask)</code> numbers the connected objects of a true/false image (a dictionary: '
            '<code>.labels</code> and <code>.count</code>); <code>find_objects'
            '</code>, <code>center_of_mass</code>, <code>img_sum</code> and <code>img_extrema</code> measure each one.']),
        comp('Morphology and transforms', [
            '<code>binary_erosion</code>, <code>binary_dilation</code>, <code>binary_opening</code> / '
            '<code>closing</code> and <code>binary_fill_holes</code> reshape masks; <code>grey_…</code> versions work '
            'on grey images. <code>img_shift</code>, <code>img_rotate</code>, <code>img_zoom</code> and '
            '<code>affine_transform</code> move and resample images.']),
    ],
    {
        'basic': ex('Blur and edges', 'A small image with two objects, blurred and edge-detected.', IMGD + '''
b = round(gaussian_filter(img, 1), decimals=2)
e = sobel(img, 0)
'''),
        'mid': ex('Labelling objects', 'Number the objects of a mask, then measure them.', IMGD + '''
mask = img > 0;
L = img_label(mask);
publish("objects:", L.count);
lab = L.labels
c = center_of_mass(img, lab, [1, 2])
s = img_sum(img, lab, [1, 2])
'''),
        'strong': ex('Morphology and noise', 'Dilate a mask, and remove a single noisy pixel with a median filter.', IMGD + '''
m = img > 0;
d = binary_dilation(m)
noisy = img;
noisy[0, 4] = 50;
clean = median_filter(noisy, 3)
'''),
    },
    ['image_processing'], [IN_ORDER])

# ================================================================== 9. Optimization
PAGES['optimization'] = page(
    'Optimization & Fitting',
    'Minimise functions with or without bounds and constraints, find roots, fit curves and models to data, solve '
    'linear and mixed-integer programmes and assignment problems, and search for global minima.',
    [
        comp('Minimising', [
            '<code>minimize(@f, x0, method)</code> finds a local minimum from a starting point (methods such as '
            '"BFGS", "Nelder-Mead", "L-BFGS-B", "SLSQP"); <code>minimize_scalar</code> does it in one dimension. For '
            'functions with many local minima use <code>differential_evolution</code>, <code>dual_annealing</code>, '
            '<code>basin_hopping</code> or <code>shgo</code>.'],
            math=r'x^{*} = \arg\min_x f(x)',
            figure=fig(IMG + 'optimization-01.svg',
                       'Contour lines of the Rosenbrock function, a curved valley, with the path of a minimiser '
                       'starting at (-1.2, 1) and ending at the minimum (1, 1).',
                       'The Rosenbrock function <code>rosen</code>: a curved valley that is easy to find and hard to '
                       'follow. The minimum is at (1, 1).')),
        comp('Roots', [
            '<code>root_scalar(@f, bracket)</code> finds a root of one equation; <code>root(@f, x0)</code> solves '
            'a system; <code>fixed_point</code> finds x = f(x).']),
        comp('Fitting', [
            '<code>curve_fit(@model, x, y, p0)</code> finds the parameters of a model that fit data best (least '
            'squares); <code>least_squares</code> is the general form with bounds; <code>odr_fit</code> also allows '
            'errors in x.'],
            math=r'\min_p \sum_i \bigl(y_i - f(x_i; p)\bigr)^2'),
        comp('Programming and assignment', [
            '<code>linprog</code> solves linear programmes, <code>milp</code> mixed-integer ones, '
            '<code>assignment(cost)</code> the assignment problem (each worker to one job at the least total cost).']),
    ],
    {
        'basic': ex('A minimum and a root', 'The minimum of the Rosenbrock function, and the root of x<sup>3</sup> '
                    '&minus; 2.', '''
r = minimize(@rosen, [-1.2, 1]);
publish(r);
function y = g(x):
   y = x ^ 3 - 2;
fnend
s = root_scalar(@g, [0, 2]);
publish(s);
'''),
        'mid': ex('Fitting a model', 'Noisy-free data from y = 2 e<sup>&minus;0.7x</sup>: curve_fit recovers the two '
                  'parameters.', '''
function y = model(x, a, b):
   y = a * exp(-b * x);
fnend
x = [0, 0.5, 1, 1.5, 2, 3];
y = 2 * exp(-0.7 * x);
p = curve_fit(@model, x, y, [1, 1]);
publish(p);
'''),
        'strong': ex('Assignment and a linear programme', 'Three workers and three jobs at the least total cost; then '
                     'maximise 3x + 2y with x + y &le; 4 and x + 3y &le; 6 (as a minimisation of &minus;3x &minus; 2y).', '''
cost = [4, 1, 3; 2, 0, 5; 3, 2, 2];
a = assignment(cost);
publish(a);
lp = linprog([-3, -2], [1, 1; 1, 3], [4; 6]);
publish(lp);
'''),
    },
    ['optimization_root_finding', 'orthogonal_distance_regression'], [IN_ORDER],
    {'optimization_root_finding': 'Optimization and root finding', 'orthogonal_distance_regression': 'Orthogonal distance regression'})

# ================================================================== 10. Signal processing
PAGES['signal-processing'] = page(
    'Signal Processing',
    'Design digital filters (Butterworth, Chebyshev, elliptic, Bessel, FIR), apply them forwards and backwards, '
    'find peaks, estimate spectra, convolve and resample, and work with linear systems.',
    [
        comp('Designing a filter', [
            '<code>butter(n, Wn, btype)</code> designs an order-n Butterworth filter with cutoff Wn (a fraction of '
            'the Nyquist frequency, or in Hz when fs is given) and gives a dictionary with its coefficients: '
            '<code>f.b</code> and <code>f.a</code>. '
            '<code>cheby1</code>, <code>cheby2</code>, <code>ellip</code> and <code>bessel</code> trade a steeper '
            'edge for ripple or better timing; <code>firwin</code> designs FIR filters. <code>freqz(b, a)</code> '
            'gives the frequency response.'],
            math=r'H(z) = \frac{b_0 + b_1 z^{-1} + \dots + b_M z^{-M}}{a_0 + a_1 z^{-1} + \dots + a_N z^{-N}}',
            figure=fig(IMG + 'signal-processing-01.svg',
                       'Top: the gain of Butterworth low-pass filters of order 2, 4 and 8 with cutoff at 0.2 of the '
                       'Nyquist frequency: higher orders fall off more steeply. Bottom: a noisy sine wave and the same '
                       'signal after filtfilt with the order-4 filter, smooth and not shifted in time.',
                       'Butterworth low-pass filters (top) and a noisy signal cleaned with <code>filtfilt</code> '
                       '(bottom).')),
        comp('Applying a filter', [
            '<code>lfilter(b, a, x)</code> runs the filter forwards (it delays the signal); <code>filtfilt(b, a, x)'
            '</code> runs it forwards and backwards, so the result is not shifted. <code>medfilt</code> removes '
            'spikes; <code>detrend</code> removes a trend; <code>decimate</code> and <code>resample</code> change the '
            'sampling rate.']),
        comp('Peaks and spectra', [
            '<code>find_peaks(x, height, distance, ...)</code> finds local maxima; <code>peak_prominences</code> and '
            '<code>peak_widths</code> measure them. <code>periodogram</code>, <code>welch</code>, <code>csd</code>, '
            '<code>coherence</code>, <code>stft</code> and <code>spectrogram</code> estimate how power is spread over '
            'frequency and time.']),
        comp('Systems', [
            '<code>lti_system</code>, <code>bode</code>, <code>impulse_response</code>, <code>lsim</code> and '
            '<code>cont2discrete</code> describe and simulate linear time-invariant systems.']),
    ],
    {
        'basic': ex('A low-pass filter', 'A 4th-order Butterworth filter with cutoff at 0.2 of Nyquist, and its gain '
                    'at a few frequencies.', '''
f = butter(4, 0.2, "low");
publish("b:", round(f.b, decimals=5));
publish("a:", round(f.a, decimals=5));
publish("b and a of a high-pass:", round(butter(2, 0.3, "high").b, decimals=4));
'''),
        'mid': ex('Smoothing a signal', 'A sine wave with a fast ripple on top; filtfilt removes the ripple without '
                  'shifting the wave.', '''
t = space(0, 1, 200);
clean = sin(2 * pi * 3 * t);
x = clean + 0.3 * sin(2 * pi * 40 * t);
f = butter(4, 0.1, "low");
y = filtfilt(f.b, f.a, x);
publish("largest error before:", round(max(abs(x - clean)), decimals=3), "  after:", round(max(abs(y - clean)), decimals=3));
'''),
        'strong': ex('Finding peaks', 'The local maxima of a signal, and how much each stands out.', '''
x = [0, 2, 1, 3, 1, 5, 0, 4, 1, 0];
p = find_peaks(x);
publish(p);
w = medfilt([1, 1, 9, 1, 1, 2, 2], 3)
d = detrend([1, 2.1, 2.9, 4.2, 5.0])
'''),
    },
    ['signal_processing'], [IN_ORDER])

# ================================================================== 11. Window functions
PAGES['window-functions'] = page(
    'Window Functions',
    'Tapers that smooth the ends of a signal segment before a Fourier transform: Hann, Hamming, Blackman, Kaiser, '
    'Tukey, flat-top, Chebyshev, DPSS and more.',
    [
        comp('Why windows', [
            'An FFT treats a segment as if it repeated forever; a jump between its ends spreads energy over all '
            'frequencies ("leakage"). Multiplying the segment by a window that falls to zero at the ends reduces '
            'leakage, at the price of slightly wider peaks. Every window has the form <code>name_win(n, ...)</code>; '
            '<code>get_window(name, n)</code> picks one by name.'],
            math=r'\text{Hann: } w_n = \tfrac12\left(1 - \cos\frac{2\pi n}{N-1}\right)',
            figure=fig(IMG + 'window-functions-01.svg',
                       'Six window shapes of 64 points on one plot: boxcar is flat; Hann, Hamming and Blackman are bell '
                       'shaped, Blackman the narrowest; Kaiser with beta 8 and Tukey with alpha 0.5, which is flat in the '
                       'middle.',
                       'Six windows of 64 points. Narrower windows leak less but blur peaks more.')),
    ],
    {
        'basic': ex('A few windows', 'Eight-point windows: their values and their sums.', '''
h = round(hann_win(8), decimals=4)
m = round(hamming_win(8), decimals=4)
publish("sums:", sum(hann_win(8)), sum(hamming_win(8)), sum(boxcar_win(8)));
'''),
        'mid': ex('Parameters', 'Kaiser windows get narrower as beta grows; Tukey has a flat middle.', '''
k2 = round(kaiser_win(7, 2), decimals=3)
k8 = round(kaiser_win(7, 8), decimals=3)
tk = round(tukey_win(8, 0.5), decimals=3)
'''),
        'strong': ex('Less leakage', 'A tone that does not fit the segment exactly: with a Hann window the energy far '
                     'from the tone drops sharply.', '''
n = 64;
t = [0:63];
x = sin(2 * pi * 10.5 * t / n);
raw = abs(rfft(x));
win = abs(rfft(x *. hann_win(n, 0)));
publish("far from the tone (bin 25), no window:", round(raw[0, 25], decimals=3), "  Hann:", round(win[0, 25], decimals=4));
'''),
    },
    ['window_functions'])

# ================================================================== 12. Sparse matrices and graphs
PAGES['sparse-graphs'] = page(
    'Sparse Matrices & Graphs',
    'Matrices that are mostly zeros, stored compactly in CSR, CSC, COO and other formats; sparse solvers and '
    'eigenvalues; and graph algorithms on them: shortest paths, spanning trees, flows and components.',
    [
        comp('Sparse matrices', [
            'A sparse matrix stores only its non-zero values. <code>sparse_csr</code>, <code>sparse_coo</code>, '
            '<code>sparse_diags</code> and <code>sparse_eye</code> make them; <code>sparse_to_dense</code> converts '
            'back; <code>sparse_nnz</code> counts the stored values. Arithmetic, <code>sparse_mul</code>, '
            '<code>sparse_kron</code> and the stacking functions keep them sparse.']),
        comp('Solving', [
            '<code>sparse_solve(A, b)</code> solves directly; <code>iter_solve(A, b, method)</code> solves '
            'iteratively ("gmres", "cg", "bicgstab" ...), which suits very large systems; <code>sparse_eigsh</code> '
            'and <code>sparse_svds</code> find a few eigenvalues or singular values.']),
        comp('Graphs', [
            'A graph is a matrix of edge weights (0 = no edge). <code>dijkstra</code>, <code>shortest_path</code>, '
            '<code>floyd_warshall</code> and <code>bellman_ford</code> find shortest paths; '
            '<code>min_spanning_tree</code>, <code>max_flow</code>, <code>graph_components</code>, '
            '<code>bfs_order</code> and <code>dfs_order</code> explore it.'],
            figure=fig(IMG + 'sparse-graphs-01.svg',
                       'A small weighted graph of five nodes with the shortest path from node 0 to node 4 highlighted '
                       'and its total length shown.',
                       'A weighted graph and the shortest path <code>dijkstra</code> finds from node 0.')),
    ],
    {
        'basic': ex('A sparse matrix', 'A tridiagonal matrix stored sparsely: how much is stored, and the dense view.', '''
S = sparse_diags([1, 1, 1, 1; -2, -2, -2, -2; 1, 1, 1, 1], [-1, 0, 1], [4, 4]);
publish("stored values:", sparse_nnz(S), "  format:", sparse_format(S));
D = sparse_to_dense(S)
'''),
        'mid': ex('Solving a sparse system', 'The same matrix, solved directly and iteratively.', '''
S = sparse_diags([1, 1, 1, 1; -4, -4, -4, -4; 1, 1, 1, 1], [-1, 0, 1], [4, 4]);
b = [1; 2; 3; 4];
x = sparse_solve(S, b)
x2 = iter_solve(S, b, "gmres")
'''),
        'strong': ex('Shortest paths', 'A road network as a weighted graph: the shortest distances from node 0 and the '
                     'minimum spanning tree.', '''
G = [0, 4, 1, 0, 0; 4, 0, 2, 5, 0; 1, 2, 0, 8, 10; 0, 5, 8, 0, 2; 0, 0, 10, 2, 0];
d = dijkstra(G, 0, 0);
publish(d);
T = min_spanning_tree(G);
publish(T);
'''),
    },
    ['sparse_matrices', 'sparse_linear_algebra', 'graph_routines'], [],
    {'sparse_matrices': 'Sparse matrices', 'sparse_linear_algebra': 'Sparse linear algebra', 'graph_routines': 'Graph routines'})

# ================================================================== 13. Spatial algorithms
PAGES['spatial'] = page(
    'Spatial Algorithms',
    'Distances between points with twenty metrics, nearest neighbours with k-d trees, convex hulls, Delaunay '
    'triangulation, Voronoi diagrams, and rotations in 3-D.',
    [
        comp('Distances', [
            '<code>cdist(A, B, metric)</code> gives every distance between two sets of points; <code>pdist</code> '
            'within one set (condensed), <code>squareform</code> turns that into a matrix. Single-pair metrics are '
            '<code>dist_…</code>: euclidean, cityblock, chebyshev, cosine, mahalanobis, jaccard, hamming and more.'],
            math=r'd_{\text{euclid}} = \sqrt{\textstyle\sum (u_i - v_i)^2}, \quad d_{\text{city}} = \textstyle\sum |u_i - v_i|, \quad d_{\text{cheb}} = \max |u_i - v_i|'),
        comp('Neighbours and geometry', [
            '<code>kdtree(points)</code> builds a tree for fast <code>kdtree_query</code> (k nearest) and '
            '<code>kdtree_ball</code> (all within a radius). <code>convex_hull</code>, <code>delaunay</code> and '
            '<code>voronoi</code> compute the classic structures of computational geometry.'],
            figure=fig(IMG + 'spatial-01.svg',
                       'Ten scattered points with their Delaunay triangulation drawn in light lines and their convex '
                       'hull drawn as a bold outline.',
                       'Delaunay triangles and the convex hull of ten points.')),
        comp('Rotations', [
            '<code>rot_from_euler</code>, <code>rot_from_quat</code> and <code>rot_from_rotvec</code> make a rotation; '
            '<code>rot_apply</code> rotates vectors; <code>rot_as_matrix</code> and <code>rot_as_euler</code> convert; '
            '<code>rot_slerp</code> interpolates between rotations.']),
    ],
    {
        'basic': ex('Distances', 'Three metrics between two points, and all pairwise distances of three points.', '''
u = [0, 0];
v = [3, 4];
publish(dist_sqeuclidean(u, v), dist_cityblock(u, v), dist_chebyshev(u, v));
P = [0, 0; 3, 4; 6, 8];
D = cdist(P, P, "euclidean")
'''),
        'mid': ex('Nearest neighbours', 'A k-d tree of five points, queried for the point nearest to (1.1, 0.9).', '''
P = [0, 0; 1, 1; 2, 2; 5, 5; 1, 0];
T = kdtree(P);
r = kdtree_query(T, [1.1, 0.9], 1);
publish(r);
'''),
        'strong': ex('Hull and rotation', 'The convex hull of a square with a point inside, and a 90&deg; rotation '
                     'about z.', '''
P = [0, 0; 1, 0; 1, 1; 0, 1; 0.5, 0.5];
h = convex_hull(P);
publish(h);
R = rot_from_euler("z", [90], 1);
v = round(rot_apply(R, [1, 0, 0]), decimals=12)
'''),
    },
    ['spatial_algorithms'])

# ================================================================== 14. Special functions
PAGES['special-functions'] = page(
    'Special Functions',
    'More than 300 mathematical functions of physics and statistics: gamma and beta, error functions, Bessel, '
    'Airy and Struve functions, elliptic integrals, orthogonal polynomials, hypergeometric and zeta functions.',
    [
        comp('Families', [
            'The functions follow scipy.special:'],
            table=[['Family', 'Examples'],
                   ['Gamma and beta', '<code>gamma</code>, <code>gammaln</code>, <code>gammainc</code>, <code>beta</code>, <code>betainc</code>, <code>digamma</code>, <code>polygamma</code>'],
                   ['Error functions', '<code>erf</code>, <code>erfc</code>, <code>erfinv</code>, <code>erfcx</code>, <code>wofz</code>, <code>dawsn</code>'],
                   ['Bessel functions', '<code>jv</code>, <code>yv</code>, <code>iv</code>, <code>kv</code>, <code>hankel1</code>, <code>spherical_jn</code>, <code>jn_zeros</code>'],
                   ['Airy, Struve, Kelvin', '<code>airy</code>, <code>struve</code>, <code>ber</code>, <code>kei</code>'],
                   ['Elliptic integrals', '<code>ellipk</code>, <code>ellipe</code>, <code>ellipkinc</code>, <code>elliprf</code>'],
                   ['Orthogonal polynomials', '<code>eval_legendre</code>, <code>eval_chebyt</code>, <code>eval_hermite</code>, <code>roots_legendre</code>'],
                   ['Hypergeometric, zeta', '<code>hyp2f1</code>, <code>hyp1f1</code>, <code>zeta</code>, <code>lambertw</code>'],
                   ['Statistics helpers', '<code>ndtr</code>, <code>ndtri</code>, <code>stdtr</code>, <code>chdtr</code>, <code>logit</code>, <code>expit</code>, <code>softmax</code>, <code>logsumexp</code>']],
            math=r'\Gamma(z) = \int_0^\infty t^{z-1} e^{-t}\,dt, \qquad J_\nu(x) = \sum_{m=0}^\infty \frac{(-1)^m}{m!\,\Gamma(m+\nu+1)}\left(\frac{x}{2}\right)^{2m+\nu}',
            figure=fig(IMG + 'special-functions-01.svg',
                       'Left: the Bessel functions J0, J1 and J2 from 0 to 15, decaying oscillations. Right: the '
                       'gamma function from 0.1 to 5, with the factorials 1, 1, 2, 6 and 24 marked at 1, 2, 3, 4 and 5.',
                       'Bessel functions of the first kind (left) and the gamma function, which extends the factorial '
                       '(right).')),
    ],
    {
        'basic': ex('Gamma and error functions', 'Gamma extends the factorial; erf gives normal probabilities.', '''
publish("gamma(5) =", gamma(5), " = 4!   gamma(0.5)^2 =", gamma(0.5)^2, " = pi");
publish("erf(1) =", erf(1), "  erfc(1) =", erfc(1), "  erfinv(0.5) =", erfinv(0.5));
publish("comb(10, 3) =", comb(10, 3, 1), "  perm(5, 2) =", perm(5, 2, 1));
'''),
        'mid': ex('Bessel functions', 'Values of J0 and J1, and the first zeros of J0 (the vibration modes of a drum).', '''
publish("J0(2.4) =", jv(0, 2.4), "  J1(1) =", jv(1, 1));
z = jn_zeros(0, 3)
publish("J0 at its zeros:", round(jv(0, z), decimals=10));
'''),
        'strong': ex('Polynomials, elliptic integrals and softmax', 'Legendre polynomials, the period of a pendulum '
                     'swinging to 60&deg; from the complete elliptic integral, and softmax.', '''
p = eval_legendre(2, [0, 0.5, 1])
k = sin_deg(30);
ratio = 2 / pi * ellipk(k ^ 2);
publish("period / small-angle period at 60 degrees:", ratio);
s = softmax([1, 2, 3])
'''),
    },
    ['special_functions'], [err('comb with a named input', 'Library functions take their inputs in order.',
                                'c = comb(10, 3, exact=1);', 'c = comb(10, 3, 1);\npublish(c);')])

# ================================================================== 15. Statistics
PAGES['statistics'] = page(
    'Statistics & Tests',
    'Hypothesis tests (t, Mann-Whitney, Kruskal, chi-square, Kolmogorov-Smirnov, Shapiro ...), correlations, '
    'descriptive statistics, resampling, quasi-Monte Carlo samples, and statistics with masked data.',
    [
        comp('Tests', [
            'Each test returns its statistic and p-value. <code>ttest_1samp</code>, <code>ttest_ind</code> and '
            '<code>ttest_rel</code> compare means; <code>mann_whitney</code>, <code>wilcoxon</code> and '
            '<code>kruskal</code> do the same without assuming normality; <code>chi2_contingency</code> tests a '
            'table; <code>ks_2samp</code> compares distributions; <code>shapiro</code> and <code>normal_test</code> '
            'test for normality.'],
            math=r't = \frac{\bar x - \mu_0}{s / \sqrt n}'),
        comp('Correlation and description', [
            '<code>pearsonr</code>, <code>spearmanr</code> and <code>kendalltau</code> measure association; '
            '<code>describe</code> summarises data; <code>bootstrap</code> and <code>permutation_test</code> '
            'resample. For the everyday statistics see <a href="../Traditional_Math/descriptive-statistics.html">'
            'Descriptive Statistics</a>.']),
        comp('Sampling', [
            '<code>sobol_sample</code>, <code>halton_sample</code> and <code>latin_hypercube</code> spread points evenly '
            'for simulations.']),
    ],
    {
        'basic': ex('Comparing two groups', 'Two machines\' cycle times: a t-test and the rank-based alternative.', '''
a = [12.1, 11.8, 12.4, 12.0, 12.3, 11.9];
b = [12.6, 12.9, 12.4, 12.8, 13.0, 12.7];
t = ttest_ind(a, b);
publish(t);
m = mann_whitney(a, b);
publish(m);
'''),
        'mid': ex('Correlation', 'Pearson and Spearman correlation of two related series.', '''
x = [1, 2, 3, 4, 5, 6];
y = [2.1, 3.9, 6.2, 8.1, 9.8, 12.2];
publish(pearsonr(x, y));
publish(spearmanr(x, y));
'''),
        'strong': ex('A contingency table and a summary', 'Is the defect rate related to the shift? And a quick '
                     'description of a sample.', '''
table = [20, 15; 30, 35];
c = chi2_contingency(table);
publish(c);
d = describe([2.5, 3.1, 4.7, 4.7, 5.0, 6.2, 8.8]);
publish(d);
'''),
    },
    ['statistics', 'masked_array_statistics'], [],
    {'statistics': 'Statistics', 'masked_array_statistics': 'Statistics with missing values'})

# ================================================================== 16. Probability distributions
PAGES['distributions'] = page(
    'Probability Distributions',
    'More than 130 continuous and discrete distributions, each with the same five functions: density (pdf or '
    'pmf), cumulative probability (cdf), survival (sf), quantile (ppf) and random samples (rvs).',
    [
        comp('One pattern for every distribution', [
            'For a distribution <em>name</em> there are <code>name_pdf</code> (or <code>name_pmf</code> for a discrete '
            'one), <code>name_cdf</code>, <code>name_sf</code> = 1 &minus; cdf, <code>name_ppf</code> (the inverse of '
            'the cdf) and <code>name_rvs</code>. The inputs are x (or q, or the sample size), then the shape '
            'parameters, then the optional <code>loc</code> and <code>scale</code>.'],
            math=r'F(x) = P(X \le x) = \int_{-\infty}^{x} f(t)\,dt, \qquad \text{ppf}(q) = F^{-1}(q), \qquad \text{sf}(x) = 1 - F(x)',
            figure=fig(IMG + 'distributions-01.svg',
                       'Left: the density of the standard normal distribution with the area up to 1.645 shaded, which '
                       'is the cdf, 0.95. Right: the cdf curve, with ppf(0.95) = 1.645 read back from it.',
                       'pdf, cdf and ppf of the normal distribution: cdf is the area under the pdf, ppf reads the cdf '
                       'backwards.'),
            syntax='norm_pdf(x, loc, scale)\ngamma_cdf(x, a, loc, scale)\nbinom_pmf(k, n, p)\nnorm_ppf(0.975)'),
        comp('loc and scale', [
            'Every continuous distribution can be shifted and stretched: with loc = m and scale = s, the value x is '
            'read as (x &minus; m) / s. <code>norm_cdf(x, 10, 2)</code> is the normal distribution with mean 10 and '
            'standard deviation 2.']),
    ],
    {
        'basic': ex('The normal distribution', 'Density, probability, quantile and survival.', '''
publish("pdf(0) =", norm_pdf(0), "  cdf(1.96) =", norm_cdf(1.96));
publish("ppf(0.975) =", norm_ppf(0.975), "  sf(1.96) =", norm_sf(1.96));
publish("mean 10, sd 2: P(X <= 13) =", norm_cdf(13, 10, 2));
'''),
        'mid': ex('A discrete distribution', 'Ten coin tosses: probabilities of exactly and at most k heads.', '''
publish("P(5 heads)    =", binom_pmf(5, 10, 0.5));
publish("P(<= 2 heads) =", binom_cdf(2, 10, 0.5));
publish("P(> 8 heads)  =", binom_sf(8, 10, 0.5));
'''),
        'strong': ex('Reliability with the Weibull distribution', 'Components whose life follows a Weibull '
                     'distribution with shape 1.5 and scale 1000 hours: the chance of surviving 500 hours, the time by '
                     'which 10% have failed, and samples.', '''
publish("survive 500 h:", weibull_min_sf(500, 1.5, 0, 1000));
publish("10% failed by:", weibull_min_ppf(0.1, 1.5, 0, 1000), "h");
nexus_seed(1);
r = weibull_min_rvs(1.5, 0, 1000, 5);
publish("five samples:", round(r, decimals=1));
'''),
    },
    ['probability_distributions'], [err('A matrix of distributions', 'A matrix holds numbers, true/false or text, not '
                                       'distribution objects: give each one as its own input.',
                                       'r = mixture_dist([normal_dist(0, 1), normal_dist(1, 1)], [0.5, 0.5]);',
                                       'r = mixture_dist(normal_dist(0, 1), normal_dist(1, 1), [0.5, 0.5]);\npublish(type(r));')],
    {'probability_distributions': 'Distributions'})

# ================================================================== 17. BLAS and LAPACK
PAGES['blas-lapack'] = page(
    'BLAS & LAPACK',
    'Direct access to the low-level linear-algebra routines: BLAS levels 1 to 3 and LAPACK solvers, '
    'factorisations, eigenvalue and singular-value drivers, with the SciPy wrapper names.',
    [
        comp('When to use them', [
            'Most work is easier with <a href="linear-algebra.html">Linear Algebra</a> and <a href="' + CORE +
            'solving-systems.html">Solving Linear Systems</a>. These wrappers expose the routines underneath, named '
            'after LAPACK without the type letter: <code>lapack_gesv</code> is dgesv / zgesv, <code>blas_gemm</code> '
            'is dgemm. The type is chosen from the data.'],
            table=[['Group', 'Examples'],
                   ['BLAS level 1 (vectors)', '<code>blas_dot</code>, <code>blas_axpy</code>, <code>blas_nrm2</code>, <code>blas_rot</code>'],
                   ['BLAS level 2 (matrix-vector)', '<code>blas_gemv</code>, <code>blas_ger</code>, <code>blas_trsv</code>'],
                   ['BLAS level 3 (matrix-matrix)', '<code>blas_gemm</code>, <code>blas_syrk</code>, <code>blas_trsm</code>'],
                   ['LAPACK solve', '<code>lapack_gesv</code>, <code>lapack_posv</code>, <code>lapack_gbsv</code>, <code>lapack_gels</code>'],
                   ['LAPACK factorise', '<code>lapack_getrf</code>, <code>lapack_potrf</code>, <code>lapack_geqrf</code>, <code>lapack_sytrf</code>'],
                   ['LAPACK eigen / SVD', '<code>lapack_syev</code>, <code>lapack_geev</code>, <code>lapack_gesdd</code>, <code>lapack_gesvd</code>'],
                   ['Workspace queries', '<code>lapack_…_lwork</code>: the optimal work-array size']]),
    ],
    {
        'basic': ex('BLAS level 1', 'A dot product, a scaled sum and a length.', '''
x = [1, 2, 3];
y = [4, 5, 6];
publish(blas_dot(x, y), blas_axpy(x, y, 2), blas_nrm2(x));
'''),
        'mid': ex('A matrix product with BLAS', 'gemm computes alpha A B.', '''
A = [1, 2; 3, 4];
B = [5, 6; 7, 8];
C = blas_gemm(1, A, B)
'''),
        'strong': ex('Solving with LAPACK', 'gesv solves A x = b by LU; the result matches solve.', '''
A = [4, 1; 2, 3];
r = lapack_gesv(A, [1; 2]);
publish(r);
publish("solve gives:", solve(A, [1; 2]));
'''),
    },
    ['blas_lapack_wrappers'], [err('Naming a LAPACK input', 'Library functions take their inputs in order.',
                                   'A = [4, 1; 2, 3];\nx = lapack_gesv(A, [1, 2], lwork=10);',
                                   'A = [4, 1; 2, 3];\nx = lapack_gesv(A, [1; 2]);\npublish(x);')])

# ================================================================== 18. Removed from SciPy
PAGES['removed-functions'] = page(
    'Removed from SciPy',
    'Functions that SciPy removed after version 1.8 (wavelets, some window and spline helpers, derivative and '
    'others). NC keeps them so that older scripts still run.',
    [
        comp('Why they are here', [
            'SciPy dropped these functions in recent versions; NC keeps them with their old behaviour, so code ported '
            'from older SciPy runs unchanged. For new work prefer the current equivalents named in each entry\'s '
            'description.']),
    ],
    {
        'basic': ex('Wavelets', 'The Ricker ("Mexican hat") wavelet and the quadrature mirror of a filter.', '''
w = round(ricker_wavelet([-3:3], 1), decimals=4)
q = qmf([1, 2, 3])
'''),
        'mid': ex('Central-difference weights', 'Weights for a 3-point first derivative.', '''
c = central_diff_weights(3, 1)
'''),
        'strong': ex('Counting and matrices', 'Distinct values with their counts, and a triangular matrix of ones.', '''
u = unique_counts([3, 1, 3, 2, 1, 3]);
publish(u);
T = tri(3, 4, 0)
'''),
    },
    ['removed_since_1_8'])

# The biggest lists show one example call per function, to keep the pages light.
for _slug in ('distributions', 'special-functions', 'blas-lapack'):
    PAGES[_slug]['reference_calls'] = 1
