"""Helpers shared by the Default Functions content files (df_<domain>.py).

A reference page is a Language Guide page (see lg_content.py) whose About tab holds:
  01  "Functions on this page" - one row per function, linking to its section
  02+ one section per function: what it does, its maths, its inputs (table) and its syntax
"""
import re

from lg_content import comp, err, ex, fig  # noqa: F401  (re-exported for the content files)


def anchor(name):
    """The id build_language_guide.component() gives a section with this name."""
    return re.sub(r'[^a-z0-9]+', '-', name.lower()).strip('-')


def fn(sig, does, inputs=(), more=(), math=None, syntax=None, figure=None, short=None, table=None):
    """One function's reference section.

    sig     the call as shown in the heading, e.g. 'max(A[, B], axis=k)'
    does    one sentence: what it gives back
    inputs  (name, meaning, default) rows; default '' = required, 'by name only' etc. allowed
    more    extra paragraphs
    short   the line used in the page's overview table (default: `does`)
    """
    if inputs:
        table = [['Input', 'What it is', 'Default']] + [[f'<code>{n}</code>', m, d or '&mdash;'] for n, m, d in inputs]
    c = comp(sig, [does, *more], math=math, syntax=syntax, table=table, figure=figure)
    c['short'] = short or does
    return c


def reference(intro, fns, lead=()):
    """About tab: overview table, optional lead sections (concepts), then the function sections."""
    rows = [['Function', 'What it does']]
    rows += [[f'<a href="#{anchor(f["name"])}"><code>{f["name"]}</code></a>', f['short']] for f in fns]
    overview = comp('Functions on this page', intro, table=rows)
    return [overview, *lead, *fns]
