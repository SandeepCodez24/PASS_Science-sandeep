#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
 NC LOGO  -  WEB / SIMPLE LINE VERSION
==============================================================================
 One-colour line version of the approved Phase 1 geometry, for web use.
 Geometry comes unchanged from nc_logo_phase1.Logo (keep both in one folder).

 Run:  python nc_logo_web.py  [--name "Neural Colindes"]
 Needs: fonttools, uharfbuzz   (pip install fonttools uharfbuzz)
        fonts/inter-latin-600-normal.woff  (Inter SemiBold, SIL OFL)

 Outputs (./NC_web_out):
   nc-logo-horizontal-dark.svg    navy page: white letters, navy circuit inside
   nc-logo-horizontal-light.svg   light page: white letters with navy outline
   nc-logo-horizontal-mono.svg    one colour (currentColor), circuit cut out
   alt-outline/                   line-only alternative
   nc-mark-dark.svg / -light.svg / -mono.svg   mark only
   favicon.svg, favicon-16/32/48.png, apple-touch-icon.png (180),
   icon-192.png, icon-512.png, favicon.ico, og-image.png (1200x630)
   head-snippet.html              <link> tags for the site <head>
 Text is converted to outlines, so the logo renders identically everywhere.
==============================================================================
"""
import argparse
import os
import subprocess

import nc_logo_phase1 as P1
from nc_logo_phase1 import Logo, path_d

HERE = os.path.dirname(os.path.abspath(__file__))
FONT = os.path.join(HERE, "fonts", "inter-latin-600-normal.woff")

NAVY = "#0E3B6E"
WHITE = "#FFFFFF"

# line weights (multiples of w) - heavier than the Phase 1 drawing, for screens
SW_CORE = 0.075     # letter outline
SW_BOUND = 0.035    # outer boundary line
SW_TRACE = 0.05     # traces
SW_NODE = 0.032     # node outlines (thinner so corners stay crisp)
NODE_D = 0.30       # web node size d (Phase 1 drawing uses 0.22 w) - larger for screens
WORD_CAP = 0.26     # wordmark cap height as a fraction of H
WORD_GAP = 0.75     # gap mark -> wordmark, in w


# =============================================================================
# text to outlines (Inter, kerned with HarfBuzz)
# =============================================================================
def text_outline(text, cap_height):
    from fontTools.ttLib import TTFont
    from fontTools.pens.svgPathPen import SVGPathPen
    from fontTools.pens.transformPen import TransformPen
    import uharfbuzz as hb

    font = TTFont(FONT)
    upem = font["head"].unitsPerEm
    cap = getattr(font["OS/2"], "sCapHeight", 0) or 0.727 * upem
    k = cap_height / cap
    gs = font.getGlyphSet()
    order = font.getGlyphOrder()

    # HarfBuzz shaping on the sfnt data (save woff as plain sfnt in memory)
    import io
    buf = io.BytesIO()
    font.flavor = None
    font.save(buf)
    blob = hb.Blob(buf.getvalue())
    hbfont = hb.Font(hb.Face(blob))
    b = hb.Buffer()
    b.add_str(text)
    b.guess_segment_properties()
    hb.shape(hbfont, b, {"kern": True, "liga": True})

    ds = []
    x = 0
    for info, pos in zip(b.glyph_infos, b.glyph_positions):
        name = order[info.codepoint]
        pen = SVGPathPen(gs)
        # font units (y-up) -> output units (y-down), origin on baseline
        tpen = TransformPen(pen, (k, 0, 0, -k, (x + pos.x_offset) * k, -pos.y_offset * k))
        gs[name].draw(tpen)
        d = pen.getCommands()
        if d:
            ds.append(d)
        x += pos.x_advance
    return " ".join(ds), x * k


# =============================================================================
# mark geometry -> SVG fragments (y-down, origin at boundary top-left)
# =============================================================================
class Mark:
    def __init__(s, lg):
        s.lg = lg
        pad = SW_CORE * lg.w
        x0, y0, x1, y1 = lg.bbox(lg.bound)
        s.x0, s.y1 = x0 - pad, y1 + pad
        s.width = (x1 - x0) + 2 * pad
        s.height = (y1 - y0) + 2 * pad

    def P(s, p):
        return (p[0] - s.x0, s.y1 - p[1])

    def d(s, prims):
        return path_d(prims, s.P, 1.0)

    def solid(s, col, bg, traces):
        """Icon style: letters filled, traces cut through in the background colour."""
        lg = s.lg
        out = [f'<path d="{s.d(lg.core)}" fill="{col}"/>',
               f'<g fill="none" stroke="{bg}" stroke-linecap="round" stroke-linejoin="round">']
        if traces == "x":
            out.append(f'<path d="{s.d(lg.trace_prims_raw["T5"][3:5])}" stroke-width="{0.16 * lg.w:.2f}"/>')
            out.append(f'<path d="{s.d(lg.trace_prims_raw["T6"][1:3])}" stroke-width="{0.16 * lg.w:.2f}"/>')
        else:
            for k, prims in lg.traces.items():
                out.append(f'<path d="{s.d(prims)}" stroke-width="{0.07 * lg.w:.2f}"/>')
            for nid, g in lg.nodes.items():
                if g["prims"]:
                    out.append(f'<path d="{s.d(g["prims"])}" stroke-width="{0.06 * lg.w:.2f}"/>')
                if g["fill"]:
                    out.append(f'<path d="{s.d(g["fill"])}" fill="{bg}" stroke="none"/>')
        out.append("</g>")
        return "\n".join(out)

    def _ink(s, ink):
        """Traces, nodes and dots stroked in `ink` (used inside the white letters)."""
        lg, w = s.lg, s.lg.w
        out = [f'<g fill="none" stroke="{ink}" stroke-linecap="round" stroke-linejoin="round">']
        for k, prims in lg.traces.items():
            out.append(f'<path d="{s.d(prims)}" stroke-width="{SW_TRACE * w:.2f}"/>')
        for nid, g in lg.nodes.items():
            if g["prims"]:
                out.append(f'<path d="{s.d(g["prims"])}" stroke-width="{SW_NODE * w:.2f}"/>')
            if g["fill"]:
                out.append(f'<path d="{s.d(g["fill"])}" fill="{ink}" stroke="none"/>')
        out.append("</g>")
        return "\n".join(out)

    def filled(s, line, fill, ink, edge=None, uid="m"):
        """White-inner style: boundary line in `line`, letters filled with `fill`,
        circuit drawn in `ink`. `edge` = optional outline round the letters.
        fill == "knockout": letters in `line` colour with the circuit cut out
        (transparent) - one colour, works on any background."""
        lg, w = s.lg, s.lg.w
        bound = f'<path d="{s.d(lg.bound)}" fill="none" stroke="{line}" stroke-width="{SW_BOUND * w:.2f}"/>'
        if fill == "knockout":
            return (f'<defs><mask id="{uid}" maskUnits="userSpaceOnUse" x="0" y="0" '
                    f'width="{s.width:.2f}" height="{s.height:.2f}">'
                    f'<rect width="{s.width:.2f}" height="{s.height:.2f}" fill="#fff"/>{s._ink("#000")}</mask></defs>\n'
                    f'{bound}\n<path d="{s.d(lg.core)}" fill="{line}" mask="url(#{uid})"/>')
        out = [bound, f'<path d="{s.d(lg.core)}" fill="{fill}"'
               + (f' stroke="{edge}" stroke-width="{SW_BOUND * w:.2f}"' if edge else "") + "/>", s._ink(ink)]
        return "\n".join(out)

    def body(s, col, detail=True, scale_w=1.0):
        lg = s.lg
        w = lg.w * scale_w
        out = [f'<g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round">',
               f'<path d="{s.d(lg.bound)}" stroke-width="{SW_BOUND * w:.2f}" stroke-linejoin="miter"/>',
               f'<path d="{s.d(lg.core)}" stroke-width="{SW_CORE * w:.2f}" stroke-linejoin="miter"/>']
        if detail:
            for k, prims in lg.traces.items():
                out.append(f'<path d="{s.d(prims)}" stroke-width="{SW_TRACE * w:.2f}"/>')
            for nid, g in lg.nodes.items():
                if g["prims"]:
                    out.append(f'<path d="{s.d(g["prims"])}" stroke-width="{SW_NODE * w:.2f}"/>')
                if g["fill"]:
                    out.append(f'<path d="{s.d(g["fill"])}" fill="{col}" stroke="none"/>')
        else:
            for k in ("T5", "T6"):
                out.append(f'<path d="{s.d(lg.trace_prims_raw[k][3:5])}" stroke-width="{SW_TRACE * 2.6 * lg.w:.2f}"/>')
        out.append("</g>")
        return "\n".join(out)


def svg_doc(wd, ht, inner, bg=None, title="NC logo", rx=0):
    bgr = f'<rect width="{wd:.2f}" height="{ht:.2f}" rx="{rx:.2f}" fill="{bg}"/>\n' if bg else ""
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {wd:.2f} {ht:.2f}" '
            f'role="img" aria-label="{title}">\n<title>{title}</title>\n{bgr}{inner}\n</svg>\n')


def horizontal(m, lg, name, col, bg, pad_frac=0.18, art=None):
    cap = WORD_CAP * lg.H
    d, tw = text_outline(name, cap)
    pad = pad_frac * m.height if bg else 0
    gap = WORD_GAP * lg.w
    wd = m.width + gap + tw + 2 * pad
    ht = m.height + 2 * pad
    base = pad + m.height / 2 + cap / 2           # text optically centred on the mark
    art = art if art is not None else m.body(col)
    inner = (f'<g transform="translate({pad:.2f},{pad:.2f})">\n{art}\n</g>\n'
             f'<path d="{d}" fill="{col}" transform="translate({pad + m.width + gap:.2f},{base:.2f})"/>')
    return svg_doc(wd, ht, inner, bg, title=f"NC - {name}")


def mark_only(m, col, bg, pad_frac=0.0, detail=True, rx=0, square=False, solid=None, art=None):
    wd, ht = m.width, m.height
    if square:
        side = max(wd, ht) * (1 + 2 * pad_frac)
        ox, oy = (side - wd) / 2, (side - ht) / 2
        art = m.solid(col, bg, solid) if solid else m.body(col, detail)
        inner = f'<g transform="translate({ox:.2f},{oy:.2f})">\n{art}\n</g>'
        return svg_doc(side, side, inner, bg, rx=rx * side)
    pad = pad_frac * ht
    art = art if art is not None else m.body(col, detail)
    inner = f'<g transform="translate({pad:.2f},{pad:.2f})">\n{art}\n</g>'
    return svg_doc(wd + 2 * pad, ht + 2 * pad, inner, bg)


def render(svg_path, png_path, w, h=None):
    cmd = ["rsvg-convert", "-w", str(w)] + (["-h", str(h)] if h else []) + [svg_path, "-o", png_path]
    subprocess.run(cmd, check=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", default="Neural Colindes", help="wordmark text")
    ap.add_argument("--out", default="NC_web_out")
    a = ap.parse_args()
    os.makedirs(os.path.join(a.out, "alt-outline"), exist_ok=True)
    o = lambda f: os.path.join(a.out, f)
    # same construction as Phase 1, only the node size is enlarged for screens;
    # traces re-clip to the larger outlines automatically
    P1.PARAMS = [(k, a_, b_, NODE_D if k == "d" else v) for k, a_, b_, v in P1.PARAMS]
    lg = Logo(100.0)
    ok, rep = lg.verify()
    if not ok:
        raise SystemExit("web node size breaks clearances:\n" + rep)
    m = Mark(lg)

    files = {
        # MAIN: white inner space, navy circuit
        "nc-logo-horizontal-dark.svg": horizontal(m, lg, a.name, WHITE, NAVY, art=m.filled(WHITE, WHITE, NAVY)),
        "nc-logo-horizontal-light.svg": horizontal(m, lg, a.name, NAVY, None,
                                                   art=m.filled(NAVY, WHITE, NAVY, edge=NAVY)),
        "nc-logo-horizontal-mono.svg": horizontal(m, lg, a.name, "currentColor", None,
                                                  art=m.filled("currentColor", "knockout", None, uid="ncmh")),
        "nc-mark-dark.svg": mark_only(m, WHITE, NAVY, pad_frac=0.12, art=m.filled(WHITE, WHITE, NAVY)),
        "nc-mark-light.svg": mark_only(m, NAVY, None, art=m.filled(NAVY, WHITE, NAVY, edge=NAVY)),
        "nc-mark-mono.svg": mark_only(m, "currentColor", None, art=m.filled("currentColor", "knockout", None, uid="ncmm")),
        # ALTERNATIVE: line-only version (previous draft)
        "alt-outline/nc-logo-horizontal-dark.svg": horizontal(m, lg, a.name, WHITE, NAVY),
        "alt-outline/nc-logo-horizontal-light.svg": horizontal(m, lg, a.name, NAVY, None),
        # small-size icon: letters + X only, on a rounded navy square
        "favicon.svg": mark_only(m, WHITE, NAVY, pad_frac=0.08, rx=0.18, square=True, solid="x"),
        "_icon_full.svg": mark_only(m, WHITE, NAVY, pad_frac=0.08, rx=0.18, square=True, solid="all"),
    }
    for f, s in files.items():
        with open(o(f), "w") as fh:
            fh.write(s)

    # rasters
    render(o("nc-logo-horizontal-dark.svg"), o("nc-logo-horizontal-dark.png"), 2400)
    render(o("nc-logo-horizontal-light.svg"), o("nc-logo-horizontal-light.png"), 2400)
    render(o("nc-mark-dark.svg"), o("nc-mark-dark.png"), 1600)
    for n in (16, 32, 48):
        render(o("favicon.svg"), o(f"favicon-{n}.png"), n, n)
    render(o("favicon.svg"), o("apple-touch-icon.png"), 180, 180)
    render(o("favicon.svg"), o("icon-192.png"), 192, 192)
    render(o("_icon_full.svg"), o("icon-512.png"), 512, 512)
    os.remove(o("_icon_full.svg"))
    try:
        from PIL import Image
        imgs = [Image.open(o(f"favicon-{n}.png")).convert("RGBA") for n in (16, 32, 48)]
        imgs[2].save(o("favicon.ico"), sizes=[(16, 16), (32, 32), (48, 48)], append_images=imgs[:2])
        # Open Graph / social preview 1200 x 630
        render(o("nc-logo-horizontal-dark.svg"), o("_og.png"), 1000)
        lock = Image.open(o("_og.png")).convert("RGBA")
        og = Image.new("RGBA", (1200, 630), NAVY)
        og.alpha_composite(lock, ((1200 - lock.width) // 2, (630 - lock.height) // 2))
        og.convert("RGB").save(o("og-image.png"))
        os.remove(o("_og.png"))
    except ImportError:
        print("Pillow not installed: skipped favicon.ico and og-image.png")

    with open(o("head-snippet.html"), "w") as fh:
        fh.write('<link rel="icon" href="/favicon.svg" type="image/svg+xml">\n'
                 '<link rel="icon" href="/favicon.ico" sizes="48x48">\n'
                 '<link rel="apple-touch-icon" href="/apple-touch-icon.png">\n'
                 f'<meta name="theme-color" content="{NAVY}">\n'
                 '<meta property="og:image" content="/og-image.png">\n'
                 '\n<!-- page header (light background). On a navy header use nc-logo-horizontal-dark.svg.\n'
                 '     To recolour with CSS, paste nc-logo-horizontal-mono.svg inline: it uses currentColor. -->\n'
                 f'<a class="brand" href="/"><img src="/nc-logo-horizontal-light.svg" alt="NC - {a.name}" height="48"></a>\n')
    print("written to", os.path.abspath(a.out))


if __name__ == "__main__":
    main()
