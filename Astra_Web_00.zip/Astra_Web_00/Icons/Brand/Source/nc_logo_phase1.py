#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
 NC LOGO  -  PHASE 1 : MATHEMATICAL FRAMEWORK & SKELETAL DESIGN
==============================================================================
 Pure Python (standard library only). Run:   python nc_logo_phase1.py

 Every dimension is derived from ONE base unit  w  (the letter stroke width).
 Change w, or any ratio in PARAMS below, and every sheet, coordinate table
 and CAD entity regenerates consistently.

 Outputs (folder ./NC_phase1_out unless --out is given):
   NC_P1_S1_construction.svg  Sheet 1  construction framework + parameter table
   NC_P1_S2_frame.svg         Sheet 2  letter frame, junction, boundary (dims)
   NC_P1_S3_traces.svg        Sheet 3  trace routing (dims + coordinate table)
   NC_P1_S4_nodes.svg         Sheet 4  node details with equations (3:1)
   NC_P1_S5_skeleton.svg      Sheet 5  clean skeleton
   NC_P1_skeleton.svg         skeleton only, 1:1 mm, for Phase 2 colouring
   NC_P1_geometry.dxf         CAD exchange (DXF R12, mm, layered)
   NC_P1_geometry.json        every computed point / arc / parameter
   NC_P1_report.txt           tangency + clearance verification

 Coordinate system
   Origin O = bottom-left corner of the N core.  +X right, +Y up, mm.
   Datum A = line Y = 0 (base line)   Datum B = line X = 0 (N left edge)
==============================================================================
"""
import argparse
import json
import math
import os
from math import sin, cos, tan, atan2, acos, asin, sqrt, hypot, pi, radians, degrees

TAU = 2 * pi
ELL_RATIO = 1.6          # ellipse node: major / minor axis
DATE = "2026-11-18"

# =============================================================================
# 1. PARAMETERS  (name, meaning, expression, multiplier of w)
# =============================================================================
PARAMS = [
    ("w",     "Letter stroke width (base unit)",        "w",        1.00),
    ("H",     "Cap height of N and C",                  "5.4 w",    5.40),
    ("W",     "Width of N",                             "4.6 w",    4.60),
    ("b",     "Outer boundary band (offset)",           "0.15 w",   0.15),
    ("g",     "Gap N stem to C outer circle (bridged)", "0.2 w",    0.20),
    ("rf",    "Junction fillet radius (bridge)",        "0.25 w",   0.25),
    ("d",     "Node circumscribed diameter",            "0.22 w",   0.22),
    ("t",     "Trace and node line weight",             "0.035 w",  0.035),
    ("dd",    "Dot diameter",                           "0.07 w",   0.07),
    ("e",     "Trace lane pitch",                       "0.2 w",    0.20),
    ("hn",    "Corner-node inset (solved: N1 vertex on diag. CL)", "solved", 0.30),
    ("gd",    "Terminator gap",                         "0.08 w",   0.08),
]
ANGLES = [
    ("tht",   "C terminal cut (radial), each side",     "45 deg",   45.0),
    ("thn",   "Lotus / droplet polar position on C",    "60 deg",   60.0),
    ("jog",   "Lane-change jog angle",                  "45 deg",   45.0),
]
# Trace levels, expressed from the horizontal axis Y = H/2 (in units of w)
LEVELS = [
    ("y_T1j", "T1 jog start (left stem)",               "H/2",           0.0),
    ("y_T2j", "T2 jog start (left stem)",               "H/2 - 0.5 w",  -0.5),
    ("y_N3",  "Circle node centre",                     "H/2 - 1.5 w",  -1.5),
    ("y_Rj",  "T4 / T5 parallel jog start (right stem)", "H/2 + 1.5 w",  1.5),
    ("y_T4e", "T4 trace end (before terminators)",      "H/2 + 0.9 w",   0.9),
    ("y_D2",  "Dot D2 (start of T5)",                   "H/2 + 2.0 w",   2.0),
]


def make_params(w):
    p = {k: m * w for k, _, _, m in PARAMS}
    p.update({k: v for k, _, _, v in ANGLES})
    for k, _, _, m in LEVELS:
        p[k] = p["H"] / 2 + m * w
    return p


# =============================================================================
# 2. GEOMETRY KERNEL  (segments, arcs, ellipses, offsets, intersections)
# =============================================================================
def dist(a, b):
    return hypot(a[0] - b[0], a[1] - b[1])


def polar(c, r, a):
    return (c[0] + r * cos(a), c[1] + r * sin(a))


class Seg:
    kind = "seg"

    def __init__(s, p0, p1):
        s.p0, s.p1 = tuple(p0), tuple(p1)

    def pt(s, t):
        return (s.p0[0] + (s.p1[0] - s.p0[0]) * t, s.p0[1] + (s.p1[1] - s.p0[1]) * t)

    def tan(s, t=0):
        dx, dy = s.p1[0] - s.p0[0], s.p1[1] - s.p0[1]
        L = hypot(dx, dy)
        return (dx / L, dy / L)

    def length(s):
        return dist(s.p0, s.p1)

    def sub(s, ta, tb):
        return Seg(s.pt(ta), s.pt(tb))


class Arc:
    """Circular arc. a0 start angle (rad), sw signed sweep (+ = CCW, y-up)."""
    kind = "arc"

    def __init__(s, c, r, a0, a1, ccw):
        s.c, s.r, s.a0 = tuple(c), r, a0
        if ccw:
            sw = (a1 - a0) % TAU
            s.sw = TAU if sw < 1e-12 else sw
        else:
            sw = (a0 - a1) % TAU
            s.sw = -TAU if sw < 1e-12 else -sw

    @classmethod
    def pts(cls, c, r, p0, p1, ccw):
        return cls(c, r, atan2(p0[1] - c[1], p0[0] - c[0]), atan2(p1[1] - c[1], p1[0] - c[0]), ccw)

    def pt(s, t):
        return polar(s.c, s.r, s.a0 + s.sw * t)

    def tan(s, t=0):
        a = s.a0 + s.sw * t
        g = 1 if s.sw > 0 else -1
        return (-sin(a) * g, cos(a) * g)

    def length(s):
        return abs(s.sw) * s.r

    def sub(s, ta, tb):
        n = Arc(s.c, s.r, 0, 0, True)
        n.a0, n.sw = s.a0 + s.sw * ta, s.sw * (tb - ta)
        return n


class Ell:
    """Full ellipse: semi-axis rx along local x, ry along local y, rotated rot (rad)."""
    kind = "ell"

    def __init__(s, c, rx, ry, rot=0.0):
        s.c, s.rx, s.ry, s.rot = tuple(c), rx, ry, rot

    def pt(s, t):
        a = TAU * t
        x, y = s.rx * cos(a), s.ry * sin(a)
        return (s.c[0] + x * cos(s.rot) - y * sin(s.rot), s.c[1] + x * sin(s.rot) + y * cos(s.rot))

    def length(s):
        a, b = s.rx, s.ry
        h = ((a - b) / (a + b)) ** 2
        return pi * (a + b) * (1 + 3 * h / (10 + sqrt(4 - 3 * h)))


def circ3(p1, p2, p3):
    ax, ay = p1
    bx, by = p2
    cx, cy = p3
    d = 2 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by))
    ux = ((ax * ax + ay * ay) * (by - cy) + (bx * bx + by * by) * (cy - ay) + (cx * cx + cy * cy) * (ay - by)) / d
    uy = ((ax * ax + ay * ay) * (cx - bx) + (bx * bx + by * by) * (ax - cx) + (cx * cx + cy * cy) * (bx - ax)) / d
    return (ux, uy), hypot(ax - ux, ay - uy)


def arc3(p0, pm, p1):
    c, r = circ3(p0, pm, p1)
    a0 = atan2(p0[1] - c[1], p0[0] - c[0])
    am = atan2(pm[1] - c[1], pm[0] - c[0])
    a1 = atan2(p1[1] - c[1], p1[0] - c[0])
    ccw = ((am - a0) % TAU) < ((a1 - a0) % TAU)
    return Arc(c, r, a0, a1, ccw)


def sample(prims, step=0.5):
    pts = []
    for pr in prims:
        n = max(2, int(pr.length() / step) + 1)
        for i in range(n + 1):
            pts.append(pr.pt(i / n))
    return pts


def pip(p, poly):
    x, y = p
    inside = False
    n = len(poly)
    j = n - 1
    for i in range(n):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / (yj - yi) + xi:
            inside = not inside
        j = i
    return inside


# ---- intersections of offset carriers ('line', p, dir) / ('circ', c, R) ----
def _ll(l1, l2):
    (_, p, d), (_, q, e) = l1, l2
    den = d[0] * e[1] - d[1] * e[0]
    if abs(den) < 1e-14:
        return []
    t = ((q[0] - p[0]) * e[1] - (q[1] - p[1]) * e[0]) / den
    return [(p[0] + t * d[0], p[1] + t * d[1])]


def _lc(l, c):
    (_, p, d), (_, o, R) = l, c
    fx, fy = p[0] - o[0], p[1] - o[1]
    B = 2 * (fx * d[0] + fy * d[1])
    C = fx * fx + fy * fy - R * R
    disc = B * B - 4 * C
    if disc < -1e-9:
        return []
    disc = sqrt(max(0.0, disc))
    return [(p[0] + t * d[0], p[1] + t * d[1]) for t in ((-B - disc) / 2, (-B + disc) / 2)]


def _cc(c1, c2):
    (_, o1, r1), (_, o2, r2) = c1, c2
    D = dist(o1, o2)
    if D < 1e-12 or D > r1 + r2 + 1e-9 or D < abs(r1 - r2) - 1e-9:
        return []
    a = (r1 * r1 - r2 * r2 + D * D) / (2 * D)
    h = sqrt(max(0.0, r1 * r1 - a * a))
    mx, my = o1[0] + a * (o2[0] - o1[0]) / D, o1[1] + a * (o2[1] - o1[1]) / D
    ox, oy = -(o2[1] - o1[1]) / D * h, (o2[0] - o1[0]) / D * h
    return [(mx + ox, my + oy), (mx - ox, my - oy)]


def intersect(c1, c2):
    if c1[0] == "line" and c2[0] == "line":
        return _ll(c1, c2)
    if c1[0] == "line":
        return _lc(c1, c2)
    if c2[0] == "line":
        return _lc(c2, c1)
    return _cc(c1, c2)


def offset_closed(prims, b):
    """Exact offset of a closed CCW path of Seg/Arc by distance b to the right
    (outside). Sharp corners are mitred, tangent joins stay tangent."""
    n = len(prims)
    car = []
    for pr in prims:
        if pr.kind == "seg":
            tx, ty = pr.tan()
            car.append(("line", (pr.p0[0] + b * ty, pr.p0[1] - b * tx), (tx, ty)))
        else:
            car.append(("circ", pr.c, pr.r + b if pr.sw > 0 else pr.r - b))
    joins = []
    for i in range(n):
        A, B = prims[i], prims[(i + 1) % n]
        V = A.pt(1)
        ta, tb = A.tan(1), B.tan(0)
        na, nb = (ta[1], -ta[0]), (tb[1], -tb[0])
        cross = ta[0] * tb[1] - ta[1] * tb[0]
        dot = ta[0] * tb[0] + ta[1] * tb[1]
        if abs(cross) < 1e-7 and dot > 0:          # tangent join
            joins.append((V[0] + b * na[0], V[1] + b * na[1]))
            continue
        k = 1 + na[0] * nb[0] + na[1] * nb[1]
        guess = (V[0] + b * (na[0] + nb[0]) / k, V[1] + b * (na[1] + nb[1]) / k)
        cands = intersect(car[i], car[(i + 1) % n])
        joins.append(min(cands, key=lambda q: dist(q, guess)))
    out = []
    for i, pr in enumerate(prims):
        J0, J1 = joins[i - 1], joins[i]
        if pr.kind == "seg":
            out.append(Seg(J0, J1))
        else:
            out.append(Arc.pts(pr.c, car[i][2], J0, J1, pr.sw > 0))
    return out


def clip_outside(prim, regions, n=3000):
    """Return sub-primitives of `prim` lying outside every region.
    regions: list of (centre, bounding radius, polygon)."""
    def inside(t):
        p = prim.pt(t)
        for c, rb, poly in regions:
            if dist(p, c) <= rb and pip(p, poly):
                return True
        return False

    ts = [i / n for i in range(n + 1)]
    fl = [inside(t) for t in ts]

    def refine(a, b, fa):
        for _ in range(50):
            m = (a + b) / 2
            if inside(m) == fa:
                a = m
            else:
                b = m
        return (a + b) / 2

    cuts = [0.0] + [refine(ts[i], ts[i + 1], fl[i]) for i in range(n) if fl[i] != fl[i + 1]] + [1.0]
    out = []
    state = fl[0]
    for i in range(len(cuts) - 1):
        if not state and cuts[i + 1] - cuts[i] > 1e-9:
            out.append(prim.sub(cuts[i], cuts[i + 1]))
        state = not state
    return out


# =============================================================================
# 3. NODE SHAPES  (all inscribed in a circle of radius r = d/2)
# =============================================================================
def reg_poly(c, r, n, rot_deg):
    v = [polar(c, r, radians(rot_deg + 360.0 * k / n)) for k in range(n)]
    return [Seg(v[k], v[(k + 1) % n]) for k in range(n)], v


def node_geometry(kind, c, r, rot=0.0):
    """Returns dict(prims=outline, hull=polygon for clipping, fill=filled prims,
    spec=dict of defining values)."""
    spec = {}
    fill = []
    if kind == "square":
        prims, v = reg_poly(c, r, 4, 45)
        spec = {"circumradius": r, "side": r * sqrt(2), "vertex_angles_deg": "45 + k*90"}
    elif kind == "triangle":
        prims, v = reg_poly(c, r, 3, 90)
        spec = {"circumradius": r, "side": r * sqrt(3), "inradius": r / 2, "vertex_angles_deg": "90 + k*120"}
    elif kind == "hexagon":
        prims, v = reg_poly(c, r, 6, rot)
        spec = {"circumradius": r, "side": r, "across_flats": r * sqrt(3), "vertex_angles_deg": f"{rot:.4f} + k*60"}
    elif kind == "octagon":
        prims, v = reg_poly(c, r, 8, -90)
        spec = {"circumradius": r, "side": 2 * r * sin(pi / 8), "vertex_angles_deg": "-90 + k*45"}
    elif kind == "circle":
        prims = [Arc(c, r, 0, 0, True)]
        spec = {"radius": r}
    elif kind == "ellipse":
        a, b_ = r, r / ELL_RATIO
        prims = [Ell(c, b_, a, radians(rot))]
        spec = {"semi_major_a": a, "semi_minor_b": b_, "ratio": ELL_RATIO,
                "major_axis_from_vertical_deg": rot}
    elif kind == "moon":
        k1, k2 = 0.5, 0.8
        c2 = (c[0], c[1] + k1 * r)
        hy = (1 - k2 * k2 + k1 * k1) / (2 * k1) * r
        hx = sqrt(r * r - hy * hy)
        HL, HR = (c[0] - hx, c[1] + hy), (c[0] + hx, c[1] + hy)
        prims = [Arc.pts(c, r, HL, HR, True), Arc.pts(c2, k2 * r, HR, HL, False)]
        spec = {"C1_centre_rel": (0, 0), "R1": r, "C2_centre_rel": (0, k1 * r), "R2": k2 * r,
                "horns_rel": (round(hx, 4), round(hy, 4))}
        hull = sample([Arc(c, r, 0, 0, True)], 0.25)
        return {"prims": prims, "hull": hull, "fill": fill, "spec": spec}
    elif kind == "droplet":
        rho, off = 0.6 * r, 0.4 * r
        cd = (c[0], c[1] - off)
        tip = (c[0], c[1] + r)
        g = acos(rho / (r + off))
        PR, PL = polar(cd, rho, pi / 2 - g), polar(cd, rho, pi / 2 + g)
        prims = [Seg(tip, PR), Arc.pts(cd, rho, PR, PL, False), Seg(PL, tip)]
        spec = {"tip_rel": (0, r), "circle_centre_rel": (0, -off), "rho": rho,
                "half_angle_deg": degrees(asin(rho / (r + off))), "tangent_angle_from_vertical_deg": degrees(g)}
    elif kind == "lotus":
        rv, s = 0.55 * r, 0.10 * r
        prims = []
        for k in range(8):
            th = radians(rot + 45 * k)
            T = polar(c, r, th)
            for sgn in (-1, 1):
                V = polar(c, rv, th + sgn * radians(22.5))
                p0, p1 = (V, T) if sgn < 0 else (T, V)
                mx, my = (p0[0] + p1[0]) / 2, (p0[1] + p1[1]) / 2
                L = dist(p0, p1)
                nx, ny = -(p1[1] - p0[1]) / L, (p1[0] - p0[0]) / L
                ax = (cos(th), sin(th))
                # bulge away from the petal axis
                side = (mx - c[0]) * (-ax[1]) + (my - c[1]) * ax[0]
                if (nx * (-ax[1]) + ny * ax[0]) * side < 0:
                    nx, ny = -nx, -ny
                prims.append(arc3(p0, (mx + nx * s, my + ny * s), p1))
        fill = [Arc(c, 0.15 * r, 0, 0, True)]
        spec = {"petals": 8, "tip_radius": r, "valley_radius": rv, "petal_side_sagitta": s,
                "tip_angles_deg": f"{rot:.4f} + k*45", "centre_disc_radius": 0.15 * r}
    elif kind == "dot":
        prims = []
        fill = [Arc(c, r, 0, 0, True)]
        spec = {"diameter": 2 * r}
        hull = sample(fill, 0.1)
        return {"prims": prims, "hull": hull, "fill": fill, "spec": spec}
    else:
        raise ValueError(kind)
    hull = sample(prims, 0.25)
    return {"prims": prims, "hull": hull, "fill": fill, "spec": spec}


# =============================================================================
# 4. THE LOGO MODEL
# =============================================================================
class Logo:
    def __init__(s, w=100.0):
        s.p = p = make_params(w)
        w, H, W = p["w"], p["H"], p["W"]
        s.w, s.H, s.W = w, H, W
        s.pts = {}           # named points for tables
        s.log = []

        # ---------------- N --------------------------------------------------
        L = W - 2 * w
        Rn = hypot(H, L)
        s.phi = phi = acos(w / Rn) - atan2(L, H)     # diagonal angle to horizontal
        s.yJ = L * tan(phi)                          # lower notch apex on x = w
        s.yD = H - L * tan(phi)                      # upper notch apex on x = W-w
        V = {
            "V0": (0, 0), "V1": (w, 0), "V2": (w, s.yJ), "V3": (W - w, 0), "V4": (W, 0),
            "V5": (W, H), "V6": (W - w, H), "V7": (W - w, s.yD), "V8": (w, H), "V9": (0, H),
        }
        s.V = V

        # ---------------- C --------------------------------------------------
        s.Ro = H / 2
        s.Ri = s.Ro - w
        s.Rm = (s.Ro + s.Ri) / 2
        s.cC = cC = (W + p["g"] + s.Ro, H / 2)
        th = radians(p["tht"])
        s.th = th

        # ---------------- junction fillets ------------------------------------
        rf = p["rf"]
        fx = W + rf
        dyf = sqrt((s.Ro + rf) ** 2 - (cC[0] - fx) ** 2)
        if cC[1] + dyf >= H or cC[1] - dyf <= 0:
            raise ValueError("Fillet radius too large: tangent point leaves the N stem")
        if 2 * rf <= p["g"]:
            raise ValueError("Fillets cannot bridge the gap: need rf > g/2")
        s.Fu, s.Fl = (fx, cC[1] + dyf), (fx, cC[1] - dyf)
        s.Tu, s.Tl = (W, s.Fu[1]), (W, s.Fl[1])

        def toward(c0, P, R):
            dd_ = dist(c0, P)
            return (c0[0] + (P[0] - c0[0]) * R / dd_, c0[1] + (P[1] - c0[1]) * R / dd_)
        s.Qu, s.Ql = toward(cC, s.Fu, s.Ro), toward(cC, s.Fl, s.Ro)
        s.dy0 = sqrt(max(0.0, s.Ro ** 2 - (cC[0] - W) ** 2))   # raw crossing (0 = gap)

        To_lo, Ti_lo = polar(cC, s.Ro, -th), polar(cC, s.Ri, -th)
        Ti_up, To_up = polar(cC, s.Ri, th), polar(cC, s.Ro, th)
        s.term = {"To_lo": To_lo, "Ti_lo": Ti_lo, "Ti_up": Ti_up, "To_up": To_up}

        # ---------------- core outline (union N u C), CCW --------------------
        s.core = [
            Seg(V["V0"], V["V1"]), Seg(V["V1"], V["V2"]), Seg(V["V2"], V["V3"]),
            Seg(V["V3"], V["V4"]), Seg(V["V4"], s.Tl),
            Arc.pts(s.Fl, rf, s.Tl, s.Ql, False),
            Arc.pts(cC, s.Ro, s.Ql, To_lo, True),
            Seg(To_lo, Ti_lo),
            Arc.pts(cC, s.Ri, Ti_lo, Ti_up, False),
            Seg(Ti_up, To_up),
            Arc.pts(cC, s.Ro, To_up, s.Qu, True),
            Arc.pts(s.Fu, rf, s.Qu, s.Tu, False),
            Seg(s.Tu, V["V5"]), Seg(V["V5"], V["V6"]), Seg(V["V6"], V["V7"]),
            Seg(V["V7"], V["V8"]), Seg(V["V8"], V["V9"]), Seg(V["V9"], V["V0"]),
        ]
        s.bound = offset_closed(s.core, p["b"])

        # ---------------- trace lanes & nodes ---------------------------------
        e = p["e"]
        xL, xR = w / 2, W - w / 2                   # stem centrelines
        s.xL, s.xR = xL, xR
        S = (W / 2, H / 2)                          # N centre of point symmetry
        s.S = S
        dv = (cos(phi), -sin(phi))                  # diagonal direction (down-right)
        s.r = p["d"] / 2

        # Corner-node height solved so that the triangle's lower-right vertex
        # lies exactly on the diagonal centre line (T3 leaves N1 at a vertex,
        # the same rule as the hexagon).  Diagonal CL: y = Sy - (x - Sx) tan(phi)
        r = p["d"] / 2
        xv = xL + r * sqrt(3) / 2
        yT = S[1] - (xv - S[0]) * tan(phi) + r / 2
        hn = H - yT
        p["hn"] = hn
        A = (xv, yT - r / 2)                         # N1 lower-right vertex (on CL)
        B = (2 * S[0] - A[0], 2 * S[1] - A[1])       # point-symmetric partner (N5 side)
        s.A, s.B = A, B
        thn = radians(p["thn"])
        Rm = s.Rm
        # ---------------- the X crossing (T5 / T6) ----------------------------
        # X sits exactly where N and C meet: mid-gap of the bridge, at H/2.
        s.X = X = (W + p["g"] / 2, H / 2)
        # Both crossing lines are the two TANGENTS from X to the C centre line
        # (circle Rm), so each trace joins the C with no kink (G1) and the X is
        # mirror-symmetric about Y = H/2.
        dX = cC[0] - X[0]
        s.tau = tau = acos(Rm / dX)                     # polar offset of tangent points from 180 deg
        s.beta = beta = pi / 2 - tau                    # line angle to horizontal
        s.P5 = P5 = polar(cC, Rm, pi + tau)             # T5 tangent point (lower)
        s.P6 = P6 = polar(cC, Rm, pi - tau)             # T6 tangent point (upper)
        tb = tan(beta)
        s.B5 = (xR, X[1] + (X[0] - xR) * tb)            # bends on stem centre line
        s.B6 = (xR, X[1] - (X[0] - xR) * tb)
        # Ellipse: centred on the T6 tangent point, major axis along the tangent,
        # i.e. it marks where the straight trace becomes the C centre line.
        s.thE = thE = pi - tau
        E = P6
        s.E = E

        nodes = [
            ("N1", "triangle", (xL, yT), 0),
            ("N2", "square",   (xL, hn), 0),
            ("N3", "circle",   (xL - e, p["y_N3"]), 0),
            ("N4", "hexagon",  S, -degrees(phi)),
            ("N5", "octagon",  (xR, hn), 0),
            ("N6", "moon",     (xR, yT), 0),
            ("N7", "ellipse",  E, degrees(thE) - 180),
            ("N8", "lotus",    polar(cC, s.Rm, thn), degrees(thn) + 90),
            ("N9", "droplet",  polar(cC, s.Rm, -thn), 0),
        ]
        names = {"N1": "Triangle", "N2": "Square", "N3": "Circle", "N4": "Hexagon", "N5": "Octagon",
                 "N6": "Crescent moon", "N7": "Ellipse", "N8": "Lotus (top view)", "N9": "Water droplet"}
        s.nodes = {}
        for nid, kind, c, rot in nodes:
            g = node_geometry(kind, c, r, rot)
            g.update(id=nid, kind=kind, c=c, rot=rot, name=names[nid])
            s.nodes[nid] = g

        rdot = p["dd"] / 2
        yE4 = p["y_T4e"]
        yD3 = yE4 - p["gd"] - rdot
        yD4 = yD3 - 2 * rdot - p["gd"]
        dots = [("D1", (xL + e, p["y_T1j"])), ("D2", (xR + e, p["y_D2"])),
                ("D3", (xR - e, yD3)), ("D4", (xR - e, yD4))]
        for did, c in dots:
            g = node_geometry("dot", c, rdot)
            g.update(id=did, kind="dot", c=c, rot=0, name="Dot")
            s.nodes[did] = g

        # ---------------- traces (centreline polylines / arcs) ----------------
        J = p["y_Rj"]
        s.traces_raw = {
            "T1": [(xL, yT), (xL, p["y_T1j"]), (xL - e, p["y_T1j"] - e), (xL - e, p["y_N3"])],
            "T2": [(xL + e, p["y_T1j"]), (xL + e, p["y_T2j"]), (xL, p["y_T2j"] - e), (xL, hn)],
            "T3": [A, S, (B[0] + r * dv[0], B[1] + r * dv[1])],   # ends inside N5, clipped
            "T4": [(xR, yT), (xR, J), (xR - e, J - e), (xR - e, yE4)],
            "T5": [(xR + e, p["y_D2"]), (xR + e, J), (xR, J - e), s.B5, X, P5],
            "T6": [(xR, hn), s.B6, X, P6],
            "T7": "arc",
        }
        s.T7 = Arc(cC, Rm, thn, thE, True)
        s.T5arc = Arc(cC, Rm, pi + tau, -thn, True)
        s.trace_desc = {
            "T1": "N1 Triangle -> left-stem centreline -> 45 deg jog -> N3 Circle",
            "T2": "D1 Dot -> lane +e -> 45 deg jog -> left-stem centreline -> N2 Square",
            "T3": "N1 Triangle (lower-right vertex) -> diagonal centre line -> N4 Hexagon -> N5 Octagon",
            "T4": "N6 Moon -> right-stem centreline -> 45 deg jog -> lane -e -> D3, D4 terminators",
            "T5": "D2 -> lane +e -> jog -> stem CL -> down through X, tangent to C CL (lower) -> C CL -> N9 Droplet",
            "T6": "N5 Octagon -> stem CL -> up through X, tangent to C CL (upper) -> N7 Ellipse",
            "T7": "N8 Lotus -> C centre line (CCW) -> N7 Ellipse",
        }
        s.trace_prims_raw = {}
        for k, v in s.traces_raw.items():
            if v == "arc":
                s.trace_prims_raw[k] = [s.T7]
            else:
                s.trace_prims_raw[k] = [Seg(v[i], v[i + 1]) for i in range(len(v) - 1)]
        s.trace_prims_raw["T5"].append(s.T5arc)
        regions = []
        for g in s.nodes.values():
            cx, cy = g["c"]
            rb = max(dist(g["c"], q) for q in g["hull"]) + 1e-6
            regions.append((g["c"], rb, g["hull"]))
        s.traces = {k: [q for pr in v for q in clip_outside(pr, regions)] for k, v in s.trace_prims_raw.items()}

    # ------------------------------------------------------------------------
    def bbox(s, prims):
        pts = sample(prims, 1.0)
        xs, ys = [q[0] for q in pts], [q[1] for q in pts]
        return min(xs), min(ys), max(xs), max(ys)

    def verify(s):
        rep = []
        ok = True
        p = s.p
        # tangency checks at fillets
        rep.append("TANGENCY")
        for name, F, T, Q in (("upper", s.Fu, s.Tu, s.Qu), ("lower", s.Fl, s.Tl, s.Ql)):
            e1 = abs(dist(F, T) - p["rf"])
            e2 = abs(dist(s.cC, F) - (s.Ro + p["rf"]))
            e3 = abs(F[0] - T[0] - p["rf"])
            rep.append(f"  {name} fillet: |FT|-rf={e1:.2e}  |cF|-(Ro+rf)={e2:.2e}  line tangency err={e3:.2e}")
            ok &= max(e1, e2, e3) < 1e-9
        # diagonal width
        n = (sin(s.phi), cos(s.phi))
        wd = (s.V["V8"][0] - s.V["V3"][0]) * n[0] + (s.V["V8"][1] - s.V["V3"][1]) * n[1]
        rep.append(f"  diagonal perpendicular width = {wd:.6f} (target {s.w:.6f})")
        ok &= abs(wd - s.w) < 1e-9
        # point symmetry of N traces / nodes
        sx = 2 * s.S[0] - s.nodes["N1"]["c"][0], 2 * s.S[1] - s.nodes["N1"]["c"][1]
        rep.append(f"  N1 <-> N5 point symmetry about S error = {dist(sx, s.nodes['N5']['c']):.2e}")
        # outline closure
        gaps = [dist(s.core[i].pt(1), s.core[(i + 1) % len(s.core)].pt(0)) for i in range(len(s.core))]
        gapsb = [dist(s.bound[i].pt(1), s.bound[(i + 1) % len(s.bound)].pt(0)) for i in range(len(s.bound))]
        rep.append(f"  core outline closure max gap = {max(gaps):.2e};  boundary closure max gap = {max(gapsb):.2e}")
        ok &= max(gaps) < 1e-9 and max(gapsb) < 1e-9

        # clearances
        rep.append("")
        rep.append("CLEARANCES (edge-to-edge, i.e. after line weight t)")
        t = p["t"]
        core_pts = sample(s.core, 0.5)
        cell = 10.0
        grid = {}
        for q in core_pts:
            grid.setdefault((int(q[0] // cell), int(q[1] // cell)), []).append(q)

        def near_core(q, R=60):
            best = 1e9
            gx, gy = int(q[0] // cell), int(q[1] // cell)
            k = int(R // cell) + 1
            for i in range(gx - k, gx + k + 1):
                for j in range(gy - k, gy + k + 1):
                    for c in grid.get((i, j), ()):
                        dd_ = dist(q, c)
                        if dd_ < best:
                            best = dd_
            return best
        worst = 1e9
        for k, prims in s.traces.items():
            m = min(near_core(q) for q in sample(prims, 0.5))
            rep.append(f"  {k} centreline to letter edge: {m:7.2f}  -> clear gap {m - t / 2:7.2f}")
            worst = min(worst, m - t / 2)
        for nid, g in s.nodes.items():
            pts_ = sample(g["prims"] or g["fill"], 0.3)
            m = min(near_core(q) for q in pts_)
            gap = m - (t / 2 if g["prims"] else 0)
            rep.append(f"  {nid} {g['name']:<18} to letter edge: clear gap {gap:7.2f}")
            worst = min(worst, gap)
        ok &= worst > 0.10 * s.w
        rep.append(f"  >> minimum clearance to letter edge = {worst:.2f}  ({worst / s.w:.3f} w)")

        rep.append("")
        rep.append("TRACE-TO-TRACE (pairs that do not share a node)")
        share = {("T1", "T3"), ("T3", "T6"), ("T5", "T6"), ("T6", "T7")}   # T5 x T6 = the X
        keys = list(s.traces)
        samp = {k: sample(v, 0.5) for k, v in s.traces.items()}
        worst2 = 1e9
        for i in range(len(keys)):
            for j in range(i + 1, len(keys)):
                a, b = keys[i], keys[j]
                if (a, b) in share:
                    continue
                m = min(dist(q1, q2) for q1 in samp[a][::2] for q2 in samp[b][::2])
                worst2 = min(worst2, m - t)
                rep.append(f"  {a}-{b}: clear gap {m - t:7.2f}")
        rep.append(f"  >> minimum trace-to-trace gap = {worst2:.2f}  ({worst2 / s.w:.3f} w)")
        ok &= worst2 > 0.05 * s.w
        rep.append("")
        rep.append("RESULT: " + ("ALL CHECKS PASSED" if ok else "CHECK FAILED"))
        return ok, "\n".join(rep)

    # ------------------------------------------------------------------------
    def table_points(s):
        P = {}
        for k, v in s.V.items():
            P[k] = v
        P.update({"Tl": s.Tl, "Ql": s.Ql, "Qu": s.Qu, "Tu": s.Tu, "Fl": s.Fl, "Fu": s.Fu, "C": s.cC})
        P.update(s.term)
        return P


# =============================================================================
# 5. SVG DRAWING SHEETS
# =============================================================================
FONT = "DejaVu Sans, Arial, Helvetica, sans-serif"
CSS = f"""
.geo{{fill:none;stroke:#000;stroke-width:.5;stroke-linejoin:miter}}
.bnd{{fill:none;stroke:#000;stroke-width:.3}}
.trc{{fill:none;stroke:#000;stroke-linecap:round;stroke-linejoin:round}}
.nod{{fill:none;stroke:#000;stroke-linejoin:round}}
.env{{fill:none;stroke:#cfd8dc;stroke-linecap:round;stroke-linejoin:round}}
.fil{{fill:#000;stroke:none}}
.cl{{fill:none;stroke:#c0392b;stroke-width:.18;stroke-dasharray:5 1 1 1}}
.con{{fill:none;stroke:#2e86c1;stroke-width:.18;stroke-dasharray:1.6 .9}}
.grd{{fill:none;stroke:#d6eaf8;stroke-width:.15}}
.dim{{fill:none;stroke:#1b2631;stroke-width:.18}}
.arw{{fill:#1b2631;stroke:none}}
.t{{font-family:{FONT};fill:#111}}
.dt{{font-family:{FONT};fill:#1b2631;paint-order:stroke;stroke:#fff;stroke-width:.8px;stroke-linejoin:round}}
.lab{{font-family:{FONT};fill:#2e86c1;font-weight:bold;paint-order:stroke;stroke:#fff;stroke-width:.8px}}
.red{{font-family:{FONT};fill:#c0392b;paint-order:stroke;stroke:#fff;stroke-width:.8px}}
.frm{{fill:none;stroke:#000;stroke-width:.7}}
.tbl{{fill:none;stroke:#000;stroke-width:.25}}
.hdr{{fill:#eef2f5;stroke:#000;stroke-width:.25}}
.mk{{fill:#c0392b;stroke:none}}
"""


def fmt(v, n=2):
    s_ = f"{v:.{n}f}"
    return "0.00" if s_ in ("-0.00", "-0.0") else s_


def path_d(prims, P, sc):
    out = []
    cur = None
    for pr in prims:
        p0 = P(pr.pt(0))
        if cur is None or dist(cur, p0) > 1e-6:
            out.append(f"M{p0[0]:.4f},{p0[1]:.4f}")
        if pr.kind == "seg":
            q = P(pr.p1)
            out.append(f"L{q[0]:.4f},{q[1]:.4f}")
        elif pr.kind == "arc":
            R = pr.r * sc
            pieces = [pr] if abs(pr.sw) < TAU - 1e-9 else [pr.sub(0, 0.5), pr.sub(0.5, 1)]
            for pc in pieces:
                q = P(pc.pt(1))
                large = 1 if abs(pc.sw) > pi else 0
                # model is y-up and drawn y-up, so a model CCW arc is visually CCW
                # = negative SVG angle direction -> sweep-flag 0
                sweep = 0 if pc.sw > 0 else 1
                out.append(f"A{R:.4f},{R:.4f} 0 {large} {sweep} {q[0]:.4f},{q[1]:.4f}")
        elif pr.kind == "ell":
            for tt in (0.5, 1.0):
                q = P(pr.pt(tt))
                out.append(f"A{pr.rx * sc:.4f},{pr.ry * sc:.4f} {-degrees(pr.rot):.4f} 0 1 {q[0]:.4f},{q[1]:.4f}")
        cur = P(pr.pt(1))
    if prims and dist(P(prims[0].pt(0)), cur) < 1e-6 and prims[0].kind != "ell":
        out.append("Z")                      # closed outline -> proper corner joins
    return " ".join(out)


class Sheet:
    def __init__(s, size=(420, 297)):
        s.Wp, s.Hp = size
        s.el = []
        s.sc, s.ox, s.oy = 1.0, 0.0, 0.0

    def view(s, sc, ox, oy):
        s.sc, s.ox, s.oy = sc, ox, oy

    def P(s, p):
        return (s.ox + s.sc * p[0], s.oy - s.sc * p[1])

    def add(s, x):
        s.el.append(x)

    # ---- primitive drawing (model space) -------------------------------------
    def prims(s, prims, cls, sw=None):
        st = f' style="stroke-width:{sw:.4f}"' if sw is not None else ""
        s.add(f'<path d="{path_d(prims, s.P, s.sc)}" class="{cls}"{st}/>')

    def fills(s, prims, cls="fil"):
        s.add(f'<path d="{path_d(prims, s.P, s.sc)}" class="{cls}"/>')

    def line(s, p, q, cls="dim"):
        a, b = s.P(p), s.P(q)
        s.add(f'<line x1="{a[0]:.4f}" y1="{a[1]:.4f}" x2="{b[0]:.4f}" y2="{b[1]:.4f}" class="{cls}"/>')

    def circle(s, c, r, cls="con"):
        a = s.P(c)
        s.add(f'<circle cx="{a[0]:.4f}" cy="{a[1]:.4f}" r="{r * s.sc:.4f}" class="{cls}"/>')

    # ---- paper-space helpers --------------------------------------------------
    def ptext(s, x, y, txt, size=2.5, anchor="start", cls="t", rot=0, weight="normal"):
        tr = f' transform="rotate({rot:.3f} {x:.3f} {y:.3f})"' if rot else ""
        txt = str(txt).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        s.add(f'<text x="{x:.3f}" y="{y:.3f}" font-size="{size}" text-anchor="{anchor}" '
              f'class="{cls}" font-weight="{weight}"{tr}>{txt}</text>')

    def text(s, p, txt, size=2.5, anchor="middle", cls="dt", rot=0, dx=0, dy=0, weight="normal"):
        a = s.P(p)
        s.ptext(a[0] + dx, a[1] + dy, txt, size, anchor, cls, rot, weight)

    def prect(s, x, y, w, h, cls="tbl"):
        s.add(f'<rect x="{x:.3f}" y="{y:.3f}" width="{w:.3f}" height="{h:.3f}" class="{cls}"/>')

    def pline(s, x1, y1, x2, y2, cls="tbl"):
        s.add(f'<line x1="{x1:.3f}" y1="{y1:.3f}" x2="{x2:.3f}" y2="{y2:.3f}" class="{cls}"/>')

    def arrow(s, tip_paper, ux, uy, L=2.6, hw=0.55):
        x, y = tip_paper
        bx, by = x - ux * L, y - uy * L
        s.add(f'<polygon points="{x:.3f},{y:.3f} {bx - uy * hw:.3f},{by + ux * hw:.3f} '
              f'{bx + uy * hw:.3f},{by - ux * hw:.3f}" class="arw"/>')

    def cmark(s, c, size=3.0):
        a = s.P(c)
        s.pline(a[0] - size, a[1], a[0] + size, a[1], "cl")
        s.pline(a[0], a[1] - size, a[0], a[1] + size, "cl")

    def mark(s, c, rr=0.55):
        a = s.P(c)
        s.add(f'<circle cx="{a[0]:.3f}" cy="{a[1]:.3f}" r="{rr}" class="mk"/>')

    # ---- dimensions (model-space anchors) --------------------------------------
    def dim(s, p1, p2, at, orient="h", txt=None, size=2.4, tpos=0.5, side=-1):
        """orient 'h': horizontal distance, dim line at model y=at.
        'v': vertical distance, dim line at model x=at.
        'a': aligned distance, dim line offset `at` (model) to the left of p1->p2."""
        gap, ovr = 0.8, 1.6
        if orient == "h":
            d1, d2 = (p1[0], at), (p2[0], at)
            val = abs(p2[0] - p1[0])
        elif orient == "v":
            d1, d2 = (at, p1[1]), (at, p2[1])
            val = abs(p2[1] - p1[1])
        else:
            L = dist(p1, p2)
            ux, uy = (p2[0] - p1[0]) / L, (p2[1] - p1[1]) / L
            nx, ny = -uy, ux
            d1 = (p1[0] + nx * at, p1[1] + ny * at)
            d2 = (p2[0] + nx * at, p2[1] + ny * at)
            val = L
        if txt is None:
            txt = fmt(val)
        # extension lines (paper)
        for p, dd_ in ((p1, d1), (p2, d2)):
            a, b = s.P(p), s.P(dd_)
            L = hypot(b[0] - a[0], b[1] - a[1])
            if L > gap + 0.1:
                ux, uy = (b[0] - a[0]) / L, (b[1] - a[1]) / L
                s.pline(a[0] + ux * gap, a[1] + uy * gap, b[0] + ux * ovr, b[1] + uy * ovr, "dim")
        A, B = s.P(d1), s.P(d2)
        L = hypot(B[0] - A[0], B[1] - A[1])
        ux, uy = (B[0] - A[0]) / L, (B[1] - A[1]) / L
        inside = L > 9
        if inside:
            s.pline(A[0], A[1], B[0], B[1], "dim")
            s.arrow(A, -ux, -uy)
            s.arrow(B, ux, uy)
        else:
            s.pline(A[0] - ux * 5, A[1] - uy * 5, B[0] + ux * 5, B[1] + uy * 5, "dim")
            s.arrow(A, ux, uy)
            s.arrow(B, -ux, -uy)
        ang = degrees(atan2(uy, ux))
        if ang > 90.01 or ang < -89.99:
            ang += 180
            ux, uy = -ux, -uy
        mx, my = A[0] + (B[0] - A[0]) * tpos, A[1] + (B[1] - A[1]) * tpos
        if not inside and tpos == 0.5:
            mx, my = B[0] + (B[0] - A[0]) / L * (8 + len(txt) * 0.8), B[1] + (B[1] - A[1]) / L * (8 + len(txt) * 0.8)
        nx, ny = uy, -ux                       # paper normal pointing "up" of text
        s.ptext(mx + nx * 0.9, my + ny * 0.9, txt, size, "middle", "dt", ang)

    def dim_rad(s, c, r, ang_deg, txt, from_center=True, ext=0.0, size=2.4, tfrac=0.55):
        a = radians(ang_deg)
        tip = polar(c, r, a)
        start = c if from_center else polar(c, r + ext, a)
        A, B = s.P(start), s.P(tip)
        s.pline(A[0], A[1], B[0], B[1], "dim")
        L = hypot(B[0] - A[0], B[1] - A[1])
        ux, uy = (B[0] - A[0]) / L, (B[1] - A[1]) / L
        s.arrow(B, ux, uy)
        ang = degrees(atan2(uy, ux))
        tx_, ty_ = A[0] + (B[0] - A[0]) * tfrac, A[1] + (B[1] - A[1]) * tfrac
        if ang > 90.01 or ang < -89.99:
            ang += 180
            ux, uy = -ux, -uy
        s.ptext(tx_ + uy * 0.9, ty_ - ux * 0.9, txt, size, "middle", "dt", ang)

    def dim_ang(s, c, r, a0_deg, a1_deg, txt, size=2.4, tr=1.0):
        a0, a1 = radians(a0_deg), radians(a1_deg)
        arc = Arc(c, r, a0, a1, True)
        s.prims([arc], "dim")
        for t_, sg in ((0, -1), (1, 1)):
            tp = s.P(arc.pt(t_))
            tg = arc.tan(t_)
            s.arrow(tp, sg * tg[0], -sg * tg[1], L=2.2, hw=0.5)
        am = (a0 + ((a1 - a0) % TAU) / 2)
        q = s.P(polar(c, r, am))
        s.ptext(q[0] + cos(am) * 3.2 * tr, q[1] - sin(am) * 3.2 * tr + 0.9, txt, size, "middle", "dt")

    def leader(s, target, txt_paper_offset, lines, size=2.3, cls="dt", arrow=True, anchor=None):
        a = s.P(target)
        bx, by = a[0] + txt_paper_offset[0], a[1] + txt_paper_offset[1]
        right = txt_paper_offset[0] >= 0
        shoulder = 4 if right else -4
        s.pline(a[0], a[1], bx, by, "dim")
        s.pline(bx, by, bx + shoulder, by, "dim")
        if arrow:
            L = hypot(a[0] - bx, a[1] - by)
            s.arrow(a, (a[0] - bx) / L, (a[1] - by) / L, L=2.2, hw=0.5)
        anc = anchor or ("start" if right else "end")
        xx = bx + shoulder + (0.8 if right else -0.8)
        if isinstance(lines, str):
            lines = [lines]
        for i, ln in enumerate(lines):
            s.ptext(xx, by + 0.9 + i * (size + 0.9), ln, size, anc, cls)

    # ---- sheet furniture -------------------------------------------------------
    def frame(s, title, subtitle, sheet_no, n_sheets, scale_txt):
        s.prect(10, 10, s.Wp - 20, s.Hp - 20, "frm")
        # title block (bottom right)
        x0, y0, wt, ht = s.Wp - 10 - 180, s.Hp - 10 - 36, 180, 36
        s.prect(x0, y0, wt, ht, "frm")
        s.pline(x0, y0 + 12, x0 + wt, y0 + 12)
        s.pline(x0, y0 + 24, x0 + wt, y0 + 24)
        s.pline(x0 + 110, y0 + 12, x0 + 110, y0 + 36)
        s.pline(x0 + 145, y0 + 12, x0 + 145, y0 + 36)
        s.ptext(x0 + 3, y0 + 5.2, "NC LOGO  |  PHASE 1  -  MATHEMATICAL FRAMEWORK & SKELETON", 3.0, weight="bold")
        s.ptext(x0 + 3, y0 + 10.0, title, 3.0)
        s.ptext(x0 + 3, y0 + 17.0, subtitle, 2.3)
        s.ptext(x0 + 3, y0 + 21.5, "All dimensions in mm. Parametric in w (stroke width) = 100.00", 2.0)
        s.ptext(x0 + 3, y0 + 29.0, "Origin O = N bottom-left corner; datum A: Y=0, datum B: X=0", 2.0)
        s.ptext(x0 + 3, y0 + 33.5, "Generated by nc_logo_phase1.py  -  do not scale drawing", 2.0)
        s.ptext(x0 + 112, y0 + 16.0, "SCALE", 1.8)
        s.ptext(x0 + 127.5, y0 + 21.5, scale_txt, 3.2, "middle", weight="bold")
        s.ptext(x0 + 147, y0 + 16.0, "SHEET", 1.8)
        s.ptext(x0 + 162.5, y0 + 21.5, f"{sheet_no} / {n_sheets}", 3.2, "middle", weight="bold")
        s.ptext(x0 + 112, y0 + 28.0, "DATE", 1.8)
        s.ptext(x0 + 127.5, y0 + 33.5, DATE, 2.4, "middle")
        s.ptext(x0 + 147, y0 + 28.0, "UNITS", 1.8)
        s.ptext(x0 + 162.5, y0 + 33.5, "mm", 2.6, "middle")

    def heading(s, txt, sub=None):
        s.ptext(16, 18, txt, 4.0, weight="bold")
        if sub:
            s.ptext(16, 23.5, sub, 2.4)

    def svg(s, extra_defs=""):
        return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{s.Wp}mm" height="{s.Hp}mm" '
                f'viewBox="0 0 {s.Wp} {s.Hp}">\n<style>{CSS}</style>\n{extra_defs}'
                f'<rect x="0" y="0" width="{s.Wp}" height="{s.Hp}" fill="#fff"/>\n'
                + "\n".join(s.el) + "\n</svg>\n")


def table(sh, x, y, cols, rows, size=2.0, rh=4.2, header_fill=True):
    """cols: list of (title, width, anchor)."""
    total = sum(c[1] for c in cols)
    sh.prect(x, y, total, rh, "hdr" if header_fill else "tbl")
    cx = x
    for title, wd, anc in cols:
        sh.ptext(cx + 1.2, y + rh - 1.2, title, size, "start", weight="bold")
        cx += wd
    for i, row in enumerate(rows):
        yy = y + rh * (i + 1)
        sh.prect(x, yy, total, rh)
        cx = x
        for (title, wd, anc), val in zip(cols, row):
            if anc == "end":
                sh.ptext(cx + wd - 1.2, yy + rh - 1.2, val, size, "end")
            else:
                sh.ptext(cx + 1.2, yy + rh - 1.2, val, size, "start")
            cx += wd
    cx = x
    for title, wd, anc in cols[:-1]:
        cx += wd
        sh.pline(cx, y, cx, y + rh * (len(rows) + 1))
    return y + rh * (len(rows) + 1)


def draw_logo(sh, lg, frame_cls="geo", bnd=True, true_weight=True, node_lw=None):
    sh.prims(lg.core, frame_cls)
    if bnd:
        sh.prims(lg.bound, "bnd")
    lw = lg.p["t"] * sh.sc if true_weight else 0.35
    for k, prims in lg.traces.items():
        sh.prims(prims, "trc", lw)
    for g in lg.nodes.values():
        if g["prims"]:
            sh.prims(g["prims"], "nod", node_lw or lw)
        if g["fill"]:
            sh.fills(g["fill"])


# -----------------------------------------------------------------------------
# Sheet 1 : construction
# -----------------------------------------------------------------------------
def sheet_construction(lg):
    p = lg.p
    sh = Sheet()
    sh.view(0.2, 50, 202)
    sh.frame("Sheet 1 - Construction framework", "Grids, centres, construction circles, lanes, parameter table", 1, 5, "1:5")
    sh.heading("SHEET 1 - CONSTRUCTION FRAMEWORK",
               "Every line below is derived from w. Blue = construction, red dash-dot = centre lines, black = result.")
    w, H, W = lg.w, lg.H, lg.W
    x_max = lg.bbox(lg.bound)[2]
    # w-grid
    for i in range(-1, int(x_max // w) + 2):
        sh.line((i * w, -0.6 * w), (i * w, H + 0.6 * w), "grd")
    for j in range(-1, int(H // w) + 2):
        sh.line((-0.6 * w, j * w), (x_max + 0.4 * w, j * w), "grd")
    sh.text((-0.4 * w, H + 0.45 * w), "grid = w", 2.0, "start", "lab")
    # axes
    sh.line((-0.5 * w, H / 2), (x_max + 0.3 * w, H / 2), "cl")
    sh.text((x_max + 0.32 * w, H / 2), "Y = H/2", 2.1, "start", "red", dy=0.8)
    sh.line((lg.cC[0], -0.5 * w), (lg.cC[0], H + 0.5 * w), "cl")
    sh.line((lg.xL, -0.4 * w), (lg.xL, H + 0.4 * w), "cl")
    sh.line((lg.xR, -0.4 * w), (lg.xR, H + 0.4 * w), "cl")
    for x in (lg.xL - p["e"], lg.xL + p["e"], lg.xR - p["e"], lg.xR + p["e"]):
        sh.line((x, -0.2 * w), (x, H + 0.2 * w), "con")
    # diagonal centre line and edges extended
    phi = lg.phi
    dv = (cos(phi), -sin(phi))
    S = lg.S
    ext = 4.2 * w
    sh.line((S[0] - dv[0] * ext, S[1] - dv[1] * ext), (S[0] + dv[0] * ext, S[1] + dv[1] * ext), "cl")
    # C construction circles
    for R in (lg.Ro, lg.Ri, lg.Rm):
        sh.circle(lg.cC, R, "con")
    sh.circle(lg.cC, lg.Ro + p["rf"], "con")
    for ang in (45, -45, 60, -60, 180):
        sh.line(lg.cC, polar(lg.cC, lg.Ro + 0.35 * w, radians(ang)), "cl")
    # fillets
    for F in (lg.Fu, lg.Fl):
        sh.circle(F, p["rf"], "con")
        sh.cmark(F, 2.0)
        sh.line(lg.cC, F, "con")
    sh.line((W + p["rf"], -0.3 * w), (W + p["rf"], H + 0.3 * w), "con")
    # result geometry
    draw_logo(sh, lg)
    # node circumcircles
    for g in lg.nodes.values():
        if g["kind"] != "dot":
            sh.circle(g["c"], lg.r, "con")
    # centres & labels
    sh.cmark(lg.cC, 3.5)
    sh.mark(lg.cC)
    sh.text(lg.cC, "C (centre of C)", 2.2, "start", "lab", dx=1.5, dy=-1.5)
    sh.mark(S)
    sh.text(S, "S (N centre of point symmetry)", 2.1, "start", "lab", dx=4.5, dy=4.0)
    sh.mark((0, 0))
    sh.text((0, 0), "O", 2.6, "end", "lab", dx=-1.2, dy=3.6)
    for nm in ("Fu", "Fl"):
        F = getattr(lg, nm)
        sh.text(F, nm, 2.1, "start", "lab", dx=1.8, dy=-1.2)
    sh.text((W + p["rf"], H + 0.3 * w), "X = W + rf (locus of fillet centres)", 1.9, "start", "lab", dx=1.0, dy=-1)
    sh.text(polar(lg.cC, lg.Ro + p["rf"], radians(100)), "R = Ro + rf (locus)", 1.9, "middle", "lab", dy=-1.2)
    lbl = {"N1": (-5, -3, "end"), "N2": (-5, 3, "end"), "N3": (-5, 1, "end"), "N4": (5, -3, "start"),
           "N5": (5, 4, "start"), "N6": (-5, -3, "end"), "N7": (4.5, -3, "start"), "N8": (5, -3, "start"),
           "N9": (5, 4, "start"), "D1": (2.5, -1.5, "start"), "D2": (2.5, -1.5, "start"),
           "D3": (-2.5, 1, "end"), "D4": (-2.5, 2, "end")}
    for nid, (dx, dy, anc) in lbl.items():
        sh.text(lg.nodes[nid]["c"], nid, 2.1, anc, "lab", dx=dx, dy=dy)
    for nm, txt, dx, dy in (("lane", "lanes  x = w/2 +/- e", 0, 0),):
        pass
    sh.text((lg.xL - p["e"], H + 0.2 * w), "-e", 1.8, "middle", "lab", dy=-1)
    sh.text((lg.xL + p["e"], H + 0.2 * w), "+e", 1.8, "middle", "lab", dy=-1)
    sh.text((lg.xR - p["e"], H + 0.2 * w), "-e", 1.8, "middle", "lab", dy=-1)
    sh.text((lg.xR + p["e"], H + 0.2 * w), "+e", 1.8, "middle", "lab", dy=-1)
    sh.text((S[0] - dv[0] * ext, S[1] - dv[1] * ext), "diagonal centre line", 1.9, "start", "red", dx=1, dy=-1)

    # parameter table
    rows = []
    for k, desc, expr, m in PARAMS:
        rows.append([k, desc, expr, fmt(p[k])])
    for k, desc, expr, v in ANGLES:
        rows.append([k, desc, expr, fmt(v) + " deg"])
    rows += [
        ["phi", "Diagonal angle: H cos(phi) - (W-2w) sin(phi) = w", "solved", fmt(degrees(lg.phi), 4) + " deg"],
        ["Ro", "C outer radius", "H/2", fmt(lg.Ro)],
        ["Ri", "C inner radius", "Ro - w", fmt(lg.Ri)],
        ["Rm", "C centre-line radius (trace T7)", "Ro - w/2", fmt(lg.Rm)],
        ["xc", "C centre X", "W + g + Ro", fmt(lg.cC[0])],
        ["yc", "C centre Y", "H/2", fmt(lg.cC[1])],
        ["r", "Node circumradius", "d/2", fmt(lg.r)],
        ["X", "Trace crossing T5 x T6 (bridge centre)", "W + g/2, H/2", f"{fmt(lg.X[0])}, {fmt(lg.X[1])}"],
        ["tau", "Tangent-point offset: cos(tau) = Rm/(xc - Xx)", "solved", fmt(degrees(lg.tau), 4) + " deg"],
        ["beta", "X line angle to horizontal", "90 - tau", fmt(degrees(lg.beta), 4) + " deg"],
        ["thE", "Ellipse polar angle (= T6 tangent point)", "180 - tau", fmt(degrees(lg.thE), 4) + " deg"],
        ["e_r", "Ellipse axis ratio a/b", "1.6", fmt(ELL_RATIO)],
    ]
    sh.ptext(262, 31, "PARAMETERS (all derived from w)", 2.2, weight="bold")
    table(sh, 262, 33, [("Sym", 11, "start"), ("Definition", 88, "start"), ("Expression", 23, "start"),
                        ("Value", 21, "end")], rows, size=1.8, rh=3.9)
    return sh


# -----------------------------------------------------------------------------
# Sheet 2 : frame dimensions
# -----------------------------------------------------------------------------
def sheet_frame(lg):
    p = lg.p
    sh = Sheet()
    sh.view(0.25, 52, 196)
    sh.frame("Sheet 2 - Letter frame, junction & boundary", "N, C, union fillets and offset boundary - dimensioned", 2, 5, "1:4")
    sh.heading("SHEET 2 - LETTER FRAME, JUNCTION & BOUNDARY",
               "Core = union of N and C with two tangent fillets. Boundary = exact offset of the core by b (mitred corners).")
    w, H, W = lg.w, lg.H, lg.W
    V = lg.V
    sh.line((lg.cC[0] - lg.Ro - 0.2 * w, H / 2), (lg.cC[0] + lg.Ro + 0.5 * w, H / 2), "cl")
    sh.line((lg.cC[0], -0.3 * w), (lg.cC[0], H + 0.3 * w), "cl")
    for ang in (45, -45):
        sh.line(lg.cC, polar(lg.cC, lg.Ro + 0.45 * w, radians(ang)), "cl")
    sh.circle(lg.Fu, p["rf"], "con")
    sh.circle(lg.Fl, p["rf"], "con")
    sh.cmark(lg.Fu, 2)
    sh.cmark(lg.Fl, 2)
    sh.cmark(lg.cC, 3.5)
    sh.prims(lg.core, "geo")
    sh.prims(lg.bound, "bnd")
    # original letter edges absorbed by the union (shown as construction)
    sh.prims([Arc.pts(lg.cC, lg.Ro, lg.Qu, lg.Ql, True)], "con")
    sh.line(lg.Tl, lg.Tu, "con")
    sh.leader((W + p["g"] * 0.5, H / 2 + 0.6 * w), (40, 30), ["bridge between N and C", "(no boundary in the junction)"], 1.9, "lab")

    xb0, yb0, xb1, yb1 = lg.bbox(lg.bound)
    # --- bottom chain ---
    sh.dim(V["V0"], V["V1"], -0.55 * w, "h")
    sh.dim(V["V1"], V["V3"], -0.55 * w, "h")
    sh.dim(V["V3"], V["V4"], -0.55 * w, "h")
    sh.dim(V["V0"], V["V4"], -0.95 * w, "h", f"{fmt(W)}  (W)")
    sh.dim(V["V0"], (lg.cC[0], 0), -1.35 * w, "h", f"{fmt(lg.cC[0])}  (xc = W + g + Ro)")
    sh.dim((lg.cC[0], 0), lg.term["To_lo"], -0.55 * w, "h")
    # --- left verticals ---
    sh.dim(V["V0"], V["V9"], -0.55 * w, "v", f"{fmt(H)}  (H)")
    sh.dim((xb0, yb0), (xb0, yb1), -0.95 * w, "v", f"{fmt(yb1 - yb0)}  (H + 2b)")
    # --- top ---
    sh.dim(V["V9"], V["V8"], H + 0.45 * w, "h")
    sh.dim(V["V6"], V["V5"], H + 0.45 * w, "h")
    sh.dim((xb0, yb1), (xb1, yb1), H + 0.85 * w, "h", f"{fmt(xb1 - xb0)}  (overall incl. boundary)")
    # --- notch apex heights ---
    sh.dim(V["V3"], V["V7"], V["V3"][0] - 0.35 * w, "v", f"{fmt(lg.yD)}")
    sh.dim(V["V8"], V["V2"], V["V2"][0] + 0.35 * w, "v", f"{fmt(H - lg.yJ)}")
    # --- diagonal width and angle ---
    n = (sin(lg.phi), cos(lg.phi))
    mid_lo = ((V["V2"][0] + V["V3"][0]) / 2, (V["V2"][1] + V["V3"][1]) / 2)
    mid_up = (mid_lo[0] + n[0] * w, mid_lo[1] + n[1] * w)
    sh.dim(mid_lo, mid_up, 0, "a", f"{fmt(w)}  (w)")
    sh.dim_ang(V["V3"], 0.9 * w, 180 - degrees(lg.phi), 180, f"phi = {fmt(degrees(lg.phi), 2)} deg", tr=1.6)
    # --- C radii ---
    sh.dim_rad(lg.cC, lg.Ro, 70, f"Ro = {fmt(lg.Ro)}  (H/2)", tfrac=0.62)
    sh.dim_rad(lg.cC, lg.Ri, 210, f"Ri = {fmt(lg.Ri)}", tfrac=0.55)
    sh.dim_ang(lg.cC, 1.1 * w, 0, 45, "45.00 deg")
    sh.dim_ang(lg.cC, 1.1 * w, -45, 0, "45.00 deg")
    sh.dim((lg.cC[0], 0), lg.cC, lg.cC[0] + 0.25 * w, "v", f"{fmt(lg.cC[1])}  (H/2)", tpos=0.35)
    sh.text(lg.cC, "C", 2.6, "start", "lab", dx=1.2, dy=-1.4)
    # --- gap g bridged by the fillets ---
    sh.dim((W, H / 2), (W + p["g"], H / 2), H / 2 - 0.35 * w, "h", f"g = {fmt(p['g'])}")
    sh.dim(lg.Tl, lg.Tu, W - 0.3 * w, "v", f"{fmt(lg.Tu[1] - lg.Tl[1])} fused", tpos=0.5)
    # --- fillets ---
    sh.dim_rad(lg.Fu, p["rf"], 25, f"R{fmt(p['rf'])}", tfrac=0.5)
    sh.dim_rad(lg.Fl, p["rf"], -25, f"R{fmt(p['rf'])}", tfrac=0.5)
    sh.leader(lg.Fu, (-36, -14), [f"Fu ({fmt(lg.Fu[0])}, {fmt(lg.Fu[1])})", "fillet centre, tangent to", "X = W and circle Ro"], 2.0, arrow=False)
    sh.leader(lg.Fl, (14, 7), [f"Fl ({fmt(lg.Fl[0])}, {fmt(lg.Fl[1])})"], 2.0, arrow=False)
    # --- boundary band ---
    sh.leader((0, H + p["b"]), (-8, -8), [f"b = {fmt(p['b'])}", "offset all round"], 2.0)
    # --- point labels ---
    pts = lg.table_points()
    off = {"V0": (-2.6, 3.4, "end"), "V1": (1.2, 3.4, "start"), "V2": (1.2, -1.0, "start"), "V3": (-1.2, 3.4, "end"),
           "V4": (1.2, 3.4, "start"), "V5": (-1.5, -1.6, "end"), "V6": (1.2, -1.6, "start"), "V7": (-1.6, 3.2, "end"),
           "V8": (1.2, -1.6, "start"), "V9": (-2.6, -1.6, "end"), "Tl": (-1.5, -0.6, "end"), "Tu": (-1.5, 2.6, "end"),
           "Ql": (1.4, 3.4, "start"), "Qu": (1.4, -1.6, "start"), "To_lo": (1.4, 3.6, "start"),
           "Ti_lo": (-1.4, -1.0, "end"), "Ti_up": (-1.4, 3.0, "end"), "To_up": (1.4, -1.6, "start")}
    for k, (dx, dy, anc) in off.items():
        sh.mark(pts[k], 0.45)
        sh.text(pts[k], k, 2.0, anc, "lab", dx=dx, dy=dy)
    # --- coordinate table (bottom-left) ---
    keys = ["V0", "V1", "V2", "V3", "V4", "V5", "V6", "V7", "V8", "V9", "Tl", "Ql", "Qu", "Tu",
            "Fl", "Fu", "C", "To_lo", "Ti_lo", "Ti_up", "To_up"]
    rows = [[k, fmt(pts[k][0]), fmt(pts[k][1])] for k in keys]
    cols = [("Pt", 11, "start"), ("X", 17, "end"), ("Y", 17, "end")]
    y0 = 241
    sh.ptext(16, y0 - 2, "CORE OUTLINE POINTS (from O)", 2.2, weight="bold")
    for gi in range(3):
        table(sh, 16 + gi * 47.5, y0, cols, rows[gi * 7:(gi + 1) * 7], size=1.8, rh=3.6)
    # path recipe
    rec = ["Core path (CCW): V0-V1-V2-V3-V4-Tl  arc(Fl,rf,CW)  Ql",
           "arc(C,Ro,CCW)  To_lo-Ti_lo  arc(C,Ri,CW)  Ti_up-To_up",
           "arc(C,Ro,CCW)  Qu  arc(Fu,rf,CW)  Tu-V5-V6-V7-V8-V9-V0",
           "Boundary = offset(core, +b); arcs R+b / R-b, corners mitred."]
    for i, r_ in enumerate(rec):
        sh.ptext(160, 245 + i * 3.6, r_, 1.85)
    return sh


# -----------------------------------------------------------------------------
# Sheet 3 : traces
# -----------------------------------------------------------------------------
def sheet_traces(lg):
    p = lg.p
    sh = Sheet()
    sh.view(0.25, 52, 205)
    sh.frame("Sheet 3 - Trace routing", "Centre-line routing of T1-T7, lanes, jogs, node positions", 3, 5, "1:4")
    sh.heading("SHEET 3 - TRACE ROUTING",
               "Traces run on the stroke centre line; they leave it only on 45 deg jogs where they meet another trace.")
    w, H, W = lg.w, lg.H, lg.W
    sh.prims(lg.core, "geo")
    sh.prims(lg.bound, "bnd")
    sh.line((-0.3 * w, H / 2), (lg.cC[0] + 0.5 * w, H / 2), "cl")
    sh.circle(lg.cC, lg.Rm, "con")
    sh.cmark(lg.cC, 3)
    for x in (lg.xL, lg.xR):
        sh.line((x, -0.25 * w), (x, H + 0.25 * w), "cl")
    lw = p["t"] * sh.sc
    for k, prims in lg.traces.items():
        sh.prims(prims, "trc", lw)
    for g in lg.nodes.values():
        if g["prims"]:
            sh.prims(g["prims"], "nod", lw)
        if g["fill"]:
            sh.fills(g["fill"])
    e = p["e"]
    # lane pitch
    sh.dim((lg.xL - e, 0.85 * w), (lg.xL + e, 0.85 * w), 0.6 * w, "h", f"2 x {fmt(e)} (e)")
    sh.dim((lg.xR - e, H - 1.6 * w), (lg.xR + e, H - 1.6 * w), H - 1.3 * w, "h", f"2 x {fmt(e)} (e)")
    # node insets
    sh.dim((lg.xL, H), lg.nodes["N1"]["c"], -0.45 * w, "v", fmt(p["hn"]))
    sh.dim((lg.xL, 0), lg.nodes["N2"]["c"], -0.45 * w, "v", fmt(p["hn"]))
    # levels on left side
    sh.dim((0, 0), (0, p["y_N3"]), -0.85 * w, "v", fmt(p["y_N3"]))
    sh.dim((0, 0), (0, p["y_T2j"]), -1.25 * w, "v", fmt(p["y_T2j"]))
    sh.dim((0, 0), (0, p["y_T1j"]), -1.65 * w, "v", fmt(p["y_T1j"]))
    # right stem levels (measured from base)
    J = p["y_Rj"]
    sh.dim((lg.xR + e, 0), (lg.xR + e, J), lg.xR + e + 0.17 * w, "v", fmt(J), tpos=0.35)
    # jog angle
    sh.dim_ang((lg.xL, p["y_T1j"]), 0.3 * w, 225, 270, "45 deg", size=2.0, tr=1.5)
    # the X
    X = lg.X
    bd = degrees(lg.beta)
    sh.mark(X, 0.6)
    sh.dim_ang(X, 0.5 * w, -bd, bd, f"{fmt(2 * bd)} deg", size=2.0, tr=1.6)
    sh.leader(X, (36, 80), [f"X ({fmt(X[0])}, {fmt(X[1])}) = (W + g/2, H/2)",
                            f"T5, T6 at +/-{fmt(bd)} deg, tangent to Rm"], 2.0, "dt")
    # tangent points (lines from X tangent to the C centre line)
    for P_, nm, off in ((lg.P5, "T5", (14, 50)), (lg.P6, "T6 / N7", (14, -30))):
        sh.line(lg.cC, P_, "cl")
        sh.mark(P_, 0.6)
    sh.leader(lg.P5, (14, 66), [f"T5 tangent point at {fmt(180 + degrees(lg.tau))} deg",
                               f"({fmt(lg.P5[0])}, {fmt(lg.P5[1])})"], 1.9, "dt")
    sh.dim_ang(lg.cC, 0.95 * w, degrees(lg.thE), 180, f"tau = {fmt(degrees(lg.tau))} deg", size=2.0, tr=1.3)
    sh.dim_ang(lg.cC, 0.95 * w, 180, 180 + degrees(lg.tau), f"{fmt(degrees(lg.tau))} deg", size=2.0, tr=1.3)
    # T7 radius & node angles
    sh.dim_rad(lg.cC, lg.Rm, 100, f"Rm = {fmt(lg.Rm)}", tfrac=0.55)
    sh.dim_ang(lg.cC, 0.8 * w, 0, p["thn"], f"{fmt(p['thn'])} deg", size=2.0)
    sh.dim_ang(lg.cC, 0.8 * w, -p["thn"], 0, f"{fmt(p['thn'])} deg", size=2.0)
    sh.line(lg.cC, lg.nodes["N8"]["c"], "cl")
    sh.line(lg.cC, lg.nodes["N9"]["c"], "cl")
    sh.line((lg.cC[0], H / 2), (lg.cC[0] + lg.Rm + 0.3 * w, H / 2), "cl")
    # trace labels
    tl = {"T1": ((lg.xL, 3.9 * w), (-7, 0)), "T2": ((lg.xL + e, 2.45 * w), (6, 5)),
          "T3": ((lg.S[0] - 0.9 * w * cos(lg.phi), lg.S[1] + 0.9 * w * sin(lg.phi)), (6, -4)),
          "T4": ((lg.xR - e, 3.75 * w), (-7, 4)), "T5": ((lg.xR + e, 4.55 * w), (6, -3)),
          "T6": ((lg.xR, 0.75 * w), (-8, 2)), "T7": (polar(lg.cC, lg.Rm, radians(120)), (5, -6))}
    for k, (pt, off) in tl.items():
        sh.leader(pt, off, k, 2.4, "lab", arrow=False)
    lbl = {"N1": (2.4, -2.6, "start"), "N2": (3.5, 1, "start"), "N3": (-3.5, 1, "end"), "N4": (4.5, -2.8, "start"),
           "N5": (3.5, 3.4, "start"), "N6": (-3.5, -2.0, "end"), "N7": (-3.2, -2.5, "end"), "N8": (4.5, -2.4, "start"),
           "N9": (4.5, 3.5, "start"), "D1": (2.2, 0.8, "start"), "D2": (2.2, -1.2, "start"),
           "D3": (-2.0, 0.9, "end"), "D4": (-2.0, 1.6, "end")}
    for nid, (dx, dy, anc) in lbl.items():
        sh.text(lg.nodes[nid]["c"], nid, 2.0, anc, "lab", dx=dx, dy=dy)

    # coordinate table
    rows = []
    for k in ("T1", "T2", "T3", "T4", "T5", "T6"):
        for i, q in enumerate(lg.traces_raw[k]):
            rows.append([f"{k}.{i}", fmt(q[0]), fmt(q[1])])
    rows.append(["T5 arc", f"{fmt(180 + degrees(lg.tau))} ->", f"{fmt(-p['thn'])} CCW"])
    rows.append(["T7 arc", f"{fmt(p['thn'])} ->", f"{fmt(degrees(lg.thE))} CCW"])
    rows2 = []
    for nid in ("N1", "N2", "N3", "N4", "N5", "N6", "N7", "N8", "N9", "D1", "D2", "D3", "D4"):
        c = lg.nodes[nid]["c"]
        rows2.append([nid, fmt(c[0]), fmt(c[1])])
    cols = [("Pt", 11, "start"), ("X", 15, "end"), ("Y", 17, "end")]
    sh.ptext(316, 31, "TRACE VERTICES (centre line)", 2.1, weight="bold")
    table(sh, 316, 33, cols, rows, size=1.75, rh=3.5)
    sh.ptext(363, 31, "NODE / DOT CENTRES", 2.1, weight="bold")
    yend = table(sh, 363, 33, cols, rows2, size=1.75, rh=3.5)
    notes = ["Traces are drawn to the node", "outline; vertex lists give the", "logical path through node", "centres. All jogs 45 deg.",
             "", "Line weight t = " + fmt(p["t"]), "Dot dia dd = " + fmt(p["dd"]),
             "All arcs centred on C use Rm.", "T3 passes hexagon N4 at", "two opposite vertices.",
             "X: tangents from bridge", "centre to the C centre line."]
    for i, n_ in enumerate(notes):
        sh.ptext(363, yend + 5 + i * 3.3, n_, 1.85)
    # description list bottom-left
    for i, k in enumerate(lg.trace_desc):
        sh.ptext(16, 250 + i * 3.4, f"{k}:  {lg.trace_desc[k]}", 1.9)
    return sh


# -----------------------------------------------------------------------------
# Sheet 4 : node details
# -----------------------------------------------------------------------------
def sheet_nodes(lg):
    p = lg.p
    sh = Sheet()
    sh.frame("Sheet 4 - Node details", "Nine nodes + dot. All nodes inscribed in circle d. Scale 2:1", 4, 5, "2:1")
    sh.heading("SHEET 4 - NODE DETAILS (2:1, dots 4:1)",
               f"All nodes fit one circumscribed circle  d = 0.22 w = {fmt(p['d'])}  (r = {fmt(lg.r)}).  "
               f"Grey band = rendered line weight t = {fmt(p['t'])}; black = geometry centre line.")
    r = lg.r
    order = ["N2", "N1", "N4", "N5", "N6", "N7", "N3", "N9", "N8", "D1"]
    cw, ch = 78.0, 110.0
    x0, y0 = 15.0, 28.0
    phi_d = degrees(lg.phi)
    sc = 2.0
    eqs = {
        "N2": ["Square, axis aligned", "vertices: r(cos a, sin a),", "   a = 45 + k*90 deg", f"side = r*sqrt(2) = {fmt(r * sqrt(2))}", "T2 enters top edge centre"],
        "N1": ["Equilateral triangle, apex up", "vertices: a = 90 + k*120 deg", f"side = r*sqrt(3) = {fmt(r * sqrt(3))}", "T1 leaves base centre;", "T3 leaves lower-right vertex"],
        "N4": ["Regular hexagon", f"vertices: a = -phi + k*60 deg", f"   (-phi = {fmt(-phi_d)} deg)", f"side = r = {fmt(r)}", "T3 enters & exits at vertices"],
        "N5": ["Regular octagon, vertex down", "vertices: a = -90 + k*45 deg", f"side = 2r sin(22.5) = {fmt(2 * r * sin(pi / 8))}", "T6 leaves the top vertex", "T3 arrives upper-left face"],
        "N6": ["Crescent = disc C1 - disc C2", f"C1: (0,0), R1 = r = {fmt(r)}", f"C2: (0, 0.5r), R2 = 0.8r = {fmt(0.8 * r)}",
               f"horns (+/-{fmt(0.7924 * r)}, {fmt(0.61 * r)})", "T4 leaves the bottom (0,-r)"],
        "N7": ["Ellipse  x^2/b^2 + y^2/a^2 = 1", f"a = r = {fmt(r)}, b = r/1.6 = {fmt(r / ELL_RATIO)}",
               f"major axis on C tangent:", f"  tilt {fmt(lg.nodes['N7']['rot'])} deg from vertical", "T7 above, T6 below (vertices)"],
        "N3": ["Circle  x^2 + y^2 = r^2", f"r = {fmt(r)}", "T1 enters at top (0, r)", "", ""],
        "N9": ["Tip T = (0, r)", f"circle: (0, -0.4r), rho = 0.6r = {fmt(0.6 * r)}", "sides tangent from T to circle",
               f"half-angle = asin(0.6/1.4) = {fmt(degrees(asin(0.6 / 1.4)))} deg", "T7 arrives lower-left"],
        "N8": ["8 petals, tips at r", f"tip angles = {fmt(p['thn'] + 90)} + k*45 deg", f"valleys at 0.55r = {fmt(0.55 * r)}",
               f"petal sides: arcs, sagitta 0.1r = {fmt(0.1 * r)}", f"centre disc 0.15r = {fmt(0.15 * r)}"],
        "D1": ["Dot D1-D4: filled disc", f"dia dd = 0.07w = {fmt(p['dd'])}", "Terminators D3, D4 below T4:",
               f"gap gd = 0.08w = {fmt(p['gd'])}", "trace end > gd > D3 > gd > D4"],
    }
    for idx, nid in enumerate(order):
        col, row = idx % 5, idx // 5
        cx0, cy0 = x0 + col * cw, y0 + row * ch
        sh.prect(cx0, cy0, cw - 2, ch - 4, "tbl")
        g = lg.nodes[nid]
        title = f"{nid}  {g['name']}" if nid != "D1" else "D1-D4  Dot / terminator"
        sh.ptext(cx0 + 2, cy0 + 5, title, 2.6, weight="bold")
        ccx, ccy = cx0 + (cw - 2) / 2, cy0 + 42
        c = g["c"]
        s_ = sc if nid != "D1" else 4.0
        sh.view(s_, ccx - s_ * c[0], ccy + s_ * c[1])
        if nid != "D1":
            sh.circle(c, r, "con")
        rc = (r if nid != "D1" else p["dd"] / 2) * 1.3
        sh.line((c[0] - rc, c[1]), (c[0] + rc, c[1]), "cl")
        sh.line((c[0], c[1] - rc), (c[0], c[1] + rc), "cl")
        tw = p["t"] * s_
        if g["prims"]:
            sh.prims(g["prims"], "env", tw)
            sh.prims(g["prims"], "geo")
        if g["fill"]:
            sh.fills(g["fill"], "fil")
        if nid != "D1":
            sh.dim_rad(c, r, 135, f"r = {fmt(r)}", tfrac=0.45)
        # node specific dimension
        if nid == "N2":
            sh.dim((c[0] - r / sqrt(2), c[1] - r / sqrt(2)), (c[0] + r / sqrt(2), c[1] - r / sqrt(2)), c[1] - r * 1.15, "h")
        elif nid == "N1":
            a_ = polar(c, r, radians(210))
            b_ = polar(c, r, radians(330))
            sh.dim(a_, b_, c[1] - r * 0.95, "h")
        elif nid == "N4":
            sh.dim_ang(c, r * 0.75, -phi_d, 0, f"phi", size=2.0)
            sh.line(c, polar(c, r * 1.35, radians(-phi_d)), "cl")
        elif nid == "N5":
            a_ = polar(c, r, radians(-90))
            b_ = polar(c, r, radians(-45))
            sh.dim(a_, b_, -2.2, "a")
        elif nid == "N6":
            c2 = (c[0], c[1] + 0.5 * r)
            sh.circle(c2, 0.8 * r, "con")
            sh.cmark(c2, 1.5)
            sh.dim_rad(c2, 0.8 * r, 30, f"R2 {fmt(0.8 * r)}", tfrac=0.5)
            sh.dim((c[0] + r * 1.15, c[1]), (c[0] + r * 1.15, c2[1]), c[0] + r * 1.15, "v", fmt(0.5 * r))
        elif nid == "N7":
            ro = radians(g["rot"])
            ma = (-sin(ro), cos(ro))                     # major-axis direction
            mi = (cos(ro), sin(ro))                      # minor-axis direction
            sh.line((c[0] - ma[0] * r * 1.3, c[1] - ma[1] * r * 1.3), (c[0] + ma[0] * r * 1.3, c[1] + ma[1] * r * 1.3), "cl")
            sh.dim((c[0] - ma[0] * r, c[1] - ma[1] * r), (c[0] + ma[0] * r, c[1] + ma[1] * r), -r * 1.15, "a", f"2a = {fmt(2 * r)}")
            bb = r / ELL_RATIO
            sh.dim((c[0] - mi[0] * bb, c[1] - mi[1] * bb), (c[0] + mi[0] * bb, c[1] + mi[1] * bb),
                   -r * 1.25, "a", f"2b = {fmt(2 * bb)}")
        elif nid == "N3":
            sh.dim((c[0] - r, c[1]), (c[0] + r, c[1]), c[1] - r * 1.2, "h", f"d = {fmt(2 * r)}")
        elif nid == "N9":
            cd = (c[0], c[1] - 0.4 * r)
            sh.circle(cd, 0.6 * r, "con")
            sh.cmark(cd, 1.5)
            sh.dim_rad(cd, 0.6 * r, -30, f"rho {fmt(0.6 * r)}", tfrac=0.5)
        elif nid == "N8":
            sh.circle(c, 0.55 * r, "con")
            sh.dim_rad(c, 0.55 * r, 15, f"0.55r", tfrac=0.5)
        elif nid == "D1":
            sh.dim((c[0] - p["dd"] / 2, c[1]), (c[0] + p["dd"] / 2, c[1]), c[1] - p["dd"] * 1.3, "h", f"dd = {fmt(p['dd'])}")
        for i, ln in enumerate(eqs[nid]):
            sh.ptext(cx0 + 2.5, cy0 + 82 + i * 4.2, ln, 2.15)
    sh.view(1, 0, 0)
    return sh


# -----------------------------------------------------------------------------
# Sheet 5 : clean skeleton
# -----------------------------------------------------------------------------
def sheet_skeleton(lg):
    sh = Sheet()
    xb0, yb0, xb1, yb1 = lg.bbox(lg.bound)
    sc = 1 / 3
    wd, ht = (xb1 - xb0) * sc, (yb1 - yb0) * sc
    ox = (420 - wd) / 2 - xb0 * sc
    oy = 30 + (215 - ht) / 2 + yb1 * sc
    sh.view(sc, ox, oy)
    sh.frame("Sheet 5 - Skeleton", "Final Phase 1 skeleton (frame + boundary + traces + nodes)", 5, 5, "1:3")
    sh.heading("SHEET 5 - SKELETON (PHASE 1 RESULT)", "Line-only master for Phase 2 colouring.")
    draw_logo(sh, lg)
    return sh


def skeleton_only(lg, pad=10.0):
    xb0, yb0, xb1, yb1 = lg.bbox(lg.bound)
    Wd, Hd = xb1 - xb0 + 2 * pad, yb1 - yb0 + 2 * pad
    sh = Sheet((Wd, Hd))
    sh.view(1.0, pad - xb0, pad + yb1)
    sh.el = []
    sh.prims(lg.core, "geo", 1.6)
    sh.prims(lg.bound, "bnd", 1.0)
    for k, prims in lg.traces.items():
        sh.add(f'<path id="{k}" d="{path_d(prims, sh.P, 1)}" class="trc" style="stroke-width:{lg.p["t"]}"/>')
    for nid, g in lg.nodes.items():
        if g["prims"]:
            sh.add(f'<path id="{nid}" d="{path_d(g["prims"], sh.P, 1)}" class="nod" style="stroke-width:{lg.p["t"]}"/>')
        if g["fill"]:
            sh.add(f'<path id="{nid}_fill" d="{path_d(g["fill"], sh.P, 1)}" class="fil"/>')
    return sh


# =============================================================================
# 6. DXF (R12) EXPORT
# =============================================================================
class DXF:
    def __init__(s):
        s.ent = []
        s.layers = {}

    def layer(s, name, color):
        s.layers[name] = color

    def _w(s, *pairs):
        for code, val in pairs:
            s.ent.append(f"{code}\n{val}")

    def line(s, a, b, ly):
        s._w((0, "LINE"), (8, ly), (10, f"{a[0]:.6f}"), (20, f"{a[1]:.6f}"), (30, 0),
             (11, f"{b[0]:.6f}"), (21, f"{b[1]:.6f}"), (31, 0))

    def arc(s, pr, ly):
        if abs(pr.sw) >= TAU - 1e-9:
            s._w((0, "CIRCLE"), (8, ly), (10, f"{pr.c[0]:.6f}"), (20, f"{pr.c[1]:.6f}"), (30, 0), (40, f"{pr.r:.6f}"))
            return
        a0, a1 = pr.a0, pr.a0 + pr.sw
        if pr.sw < 0:
            a0, a1 = a1, a0
        s._w((0, "ARC"), (8, ly), (10, f"{pr.c[0]:.6f}"), (20, f"{pr.c[1]:.6f}"), (30, 0), (40, f"{pr.r:.6f}"),
             (50, f"{degrees(a0) % 360:.6f}"), (51, f"{degrees(a1) % 360:.6f}"))

    def poly(s, pts, ly, closed=True):
        s._w((0, "POLYLINE"), (8, ly), (66, 1), (10, 0), (20, 0), (30, 0), (70, 1 if closed else 0))
        for q in pts:
            s._w((0, "VERTEX"), (8, ly), (10, f"{q[0]:.6f}"), (20, f"{q[1]:.6f}"), (30, 0))
        s._w((0, "SEQEND"), (8, ly))

    def text(s, p, h, txt, ly):
        s._w((0, "TEXT"), (8, ly), (10, f"{p[0]:.4f}"), (20, f"{p[1]:.4f}"), (30, 0), (40, h), (1, txt))

    def point(s, p, ly):
        s._w((0, "POINT"), (8, ly), (10, f"{p[0]:.6f}"), (20, f"{p[1]:.6f}"), (30, 0))

    def prims(s, prims, ly):
        for pr in prims:
            if pr.kind == "seg":
                s.line(pr.p0, pr.p1, ly)
            elif pr.kind == "arc":
                s.arc(pr, ly)
            else:
                s.poly([pr.pt(i / 360) for i in range(360)], ly)

    def save(s, path):
        out = ["0\nSECTION\n2\nHEADER", "9\n$ACADVER\n1\nAC1009", "9\n$INSUNITS\n70\n4",
               "9\n$MEASUREMENT\n70\n1", "0\nENDSEC",
               "0\nSECTION\n2\nTABLES",
               "0\nTABLE\n2\nLTYPE\n70\n1", "0\nLTYPE\n2\nCONTINUOUS\n70\n0\n3\nSolid line\n72\n65\n73\n0\n40\n0.0",
               "0\nENDTAB", f"0\nTABLE\n2\nLAYER\n70\n{len(s.layers)}"]
        for nm, col in s.layers.items():
            out.append(f"0\nLAYER\n2\n{nm}\n70\n0\n62\n{col}\n6\nCONTINUOUS")
        out += ["0\nENDTAB", "0\nENDSEC", "0\nSECTION\n2\nENTITIES"] + s.ent + ["0\nENDSEC", "0\nEOF"]
        with open(path, "w", newline="\n") as f:
            f.write("\n".join(out) + "\n")


def export_dxf(lg, path):
    dx = DXF()
    for nm, col in (("CORE_N_C", 7), ("BOUNDARY", 8), ("TRACE_CL", 5), ("NODES", 1), ("DOTS", 1),
                    ("CONSTRUCTION", 4), ("POINTS", 2)):
        dx.layer(nm, col)
    dx.prims(lg.core, "CORE_N_C")
    dx.prims(lg.bound, "BOUNDARY")
    for k, prims in lg.traces.items():
        dx.prims(prims, "TRACE_CL")
    for nid, g in lg.nodes.items():
        dx.prims(g["prims"], "NODES")
        dx.prims(g["fill"], "DOTS")
    for R in (lg.Rm,):
        dx.prims([Arc(lg.cC, R, 0, 0, True)], "CONSTRUCTION")
    dx.line((-0.5 * lg.w, lg.H / 2), (lg.cC[0] + lg.Ro + 0.5 * lg.w, lg.H / 2), "CONSTRUCTION")
    for k, q in lg.table_points().items():
        dx.point(q, "POINTS")
    for nid, g in lg.nodes.items():
        dx.point(g["c"], "POINTS")
    dx.save(path)


# =============================================================================
# 7. JSON
# =============================================================================
def prim_json(pr):
    if pr.kind == "seg":
        return {"type": "line", "p0": [round(v, 6) for v in pr.p0], "p1": [round(v, 6) for v in pr.p1]}
    if pr.kind == "arc":
        return {"type": "arc", "centre": [round(v, 6) for v in pr.c], "radius": round(pr.r, 6),
                "start_deg": round(degrees(pr.a0), 6), "sweep_deg": round(degrees(pr.sw), 6)}
    return {"type": "ellipse", "centre": [round(v, 6) for v in pr.c], "rx": round(pr.rx, 6), "ry": round(pr.ry, 6)}


def export_json(lg, path):
    def rnd(o):
        if isinstance(o, float):
            return round(o, 6)
        if isinstance(o, (list, tuple)):
            return [rnd(x) for x in o]
        if isinstance(o, dict):
            return {k: rnd(v) for k, v in o.items()}
        return o
    data = {
        "units": "mm", "origin": "N core bottom-left corner",
        "parameters": rnd(lg.p),
        "derived": rnd({"phi_deg": degrees(lg.phi), "yJ": lg.yJ, "yD": lg.yD, "Ro": lg.Ro, "Ri": lg.Ri, "Rm": lg.Rm,
                        "C_centre": lg.cC, "S": lg.S, "fillet_upper_centre": lg.Fu, "fillet_lower_centre": lg.Fl}),
        "points": rnd(lg.table_points()),
        "core_outline": [prim_json(q) for q in lg.core],
        "boundary_outline": [prim_json(q) for q in lg.bound],
        "traces_logical": rnd({k: v for k, v in lg.traces_raw.items() if v != "arc"}),
        "trace_T7": prim_json(lg.T7),
        "traces_clipped": {k: [prim_json(q) for q in v] for k, v in lg.traces.items()},
        "nodes": {nid: rnd({"name": g["name"], "kind": g["kind"], "centre": g["c"], "rotation_deg": g["rot"],
                            "spec": g["spec"]}) for nid, g in lg.nodes.items()},
    }
    with open(path, "w") as f:
        json.dump(data, f, indent=1)


# =============================================================================
# 8. MAIN
# =============================================================================
def main():
    ap = argparse.ArgumentParser(description="NC logo - Phase 1 generator")
    ap.add_argument("--w", type=float, default=100.0, help="base unit w in mm (default 100)")
    ap.add_argument("--out", default="NC_phase1_out")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    lg = Logo(a.w)
    ok, rep = lg.verify()
    sheets = [("NC_P1_S1_construction.svg", sheet_construction), ("NC_P1_S2_frame.svg", sheet_frame),
              ("NC_P1_S3_traces.svg", sheet_traces), ("NC_P1_S4_nodes.svg", sheet_nodes),
              ("NC_P1_S5_skeleton.svg", sheet_skeleton)]
    for fn, f in sheets:
        with open(os.path.join(a.out, fn), "w") as fh:
            fh.write(f(lg).svg())
    with open(os.path.join(a.out, "NC_P1_skeleton.svg"), "w") as fh:
        fh.write(skeleton_only(lg).svg())
    export_dxf(lg, os.path.join(a.out, "NC_P1_geometry.dxf"))
    export_json(lg, os.path.join(a.out, "NC_P1_geometry.json"))
    head = [f"NC LOGO PHASE 1 - verification report   (w = {fmt(lg.w)} mm)", "=" * 64,
            f"phi = {degrees(lg.phi):.6f} deg   yJ = {lg.yJ:.4f}   yD = {lg.yD:.4f}",
            f"C centre = ({lg.cC[0]:.4f}, {lg.cC[1]:.4f})  Ro = {lg.Ro:.4f}  Ri = {lg.Ri:.4f}  Rm = {lg.Rm:.4f}",
            f"Raw circle/stem crossing at y = H/2 +/- {lg.dy0:.4f}", ""]
    with open(os.path.join(a.out, "NC_P1_report.txt"), "w") as fh:
        fh.write("\n".join(head) + rep + "\n")
    print("\n".join(head) + rep)
    print(f"\nFiles written to {os.path.abspath(a.out)}")


if __name__ == "__main__":
    main()
