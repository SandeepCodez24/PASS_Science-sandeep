# Account_Services

Everything a signed-in user sees, plus the account back end. Future development.

| Item | Purpose |
|---|---|
| `sign-in.html` | Sign-in page (placeholder today) |
| `Authentication/` | Login, sign-up, password reset, session handling |
| `Payments/` | Checkout and licence purchase (through a payment provider) |
| `Notifications/` | Account windows and messages shown to the user |

Security rules for this folder: keep no secrets, keys or passwords in the repository; use HTTPS only; never store card data (leave that to the payment provider); and validate and authorise every request on the server side.
