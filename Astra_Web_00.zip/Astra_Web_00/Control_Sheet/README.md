# Control_Sheet

The one place for the site's design values. `control-sheet.css` defines:

1. **Font style**: `--sans` (Inter) and `--mono` (JetBrains Mono), loaded from Google Fonts at the top of the file.
2. **Font size**: `--fs-base` (16px body text) and the scale from `--fs-3xs` to `--fs-7xl`, plus fluid headings such as `--fs-poster-title`.
3. **Brand colours**: `--navy` #0E3B6E (the base colour of the first page), `--navy-deep`, `--accent`, `--accent-light`, `--teal`.
4. **Page and text colours**: backgrounds, borders and text greys.
5. **Status colours**: the "Under development" badge and errors.
6. **First page sections**: poster bar gradients, news badges and device pictures.
7. **Language Guide**: panel colours and code colouring.

Every page loads this file first. All other stylesheets use only these names, so changing a value here changes the whole site.
Space and column sizes are in `Webpage_Framework/Styles/layout.css`, not here.
