# Cloud_Storage

Downloadable items, to be served from cloud storage. Nothing here is connected yet.

| Folder | Holds |
|---|---|
| `Documents/` | PDF manuals, data sheets, papers |
| `Documents/Sample_Data/<Domain>/` | small sample files the Default Functions examples read (e.g. `Data_Handling/sensors.csv`), plus `<domain>-samples.zip`; build_default_functions.py copies them into its work folder and remakes the zip when they change |
| `Licenses/` | Licence files and licence terms |
| `Installers/Windows/` | `.exe` / `.msi` |
| `Installers/macOS/` | `.dmg` / `.pkg` |
| `Installers/Linux/` | `.deb` / `.rpm` / `.AppImage` |

When the cloud bucket is connected, keep the same folder names there, so a download link reads
`Cloud_Storage/Installers/Windows/<file>` locally and in the cloud. Large binaries should live only in the cloud bucket, never in the web repository.
