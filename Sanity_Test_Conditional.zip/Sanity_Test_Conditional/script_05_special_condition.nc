
#### we should follow the IEEE 754
#### https://chatgpt.com/share/6abcc647-b328-83ee-815c-c74f8d650cd0
A1 = 51;A2 = 121; A3=0^0;A4=[];
AA = [1:100];
publish("#############################################")
publish("is_in       :", A1 is_in AA);
publish("is_not_in   :",A2 is_not_in AA);
publish("is_nan      :",is_nan(A3));
publish("is_empty    :",is_empty(A4));
publish("#############################################")
############################################################## 
##############################################################
INF = 1/0; 
### Quotient Forms
IDF0 = 0/0;
IDF1 = INF/INF;
IDF2 = -INF/INF;
IDF3 = INF/-INF;
IDF4 = 0/INF;
### Product Forms
IDF5 = 0*INF; 
IDF6 = INF*INF;
### Difference Forms
IDF7 = INF-INF;
IDF8 = INF+(-INF);
IDF9 = -INF-(-INF);
IDF10 = INF+INF;
### Exponential Forms
IDF11 = 0^0; ### wrong one - error = IEEE 754
IDF12 = 1^INF; 
IDF13 = INF^0;
### Other than the mentioned cases all should follow IEEE 754
publish("Possible NaN Cases : ", [is_nan(IDF0),is_nan(IDF1),is_nan(IDF2),~~
                                   is_nan(IDF3),is_nan(IDF5),is_nan(IDF7),~~
                                   is_nan(IDF8),is_nan(IDF9)]);
publish("#############################################")
##############################################################
##############################################################

